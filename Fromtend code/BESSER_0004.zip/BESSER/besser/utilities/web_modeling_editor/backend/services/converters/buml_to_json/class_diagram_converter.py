"""
Domain model conversion from BUML to JSON format.
"""

import logging
import uuid
from besser.BUML.metamodel.structural import (
    Class, Property, Method, Parameter as StructuralParameter, DomainModel,
    PrimitiveDataType, Enumeration,
    EnumerationLiteral, BinaryAssociation, Generalization, Multiplicity,
    UNLIMITED_MAX_MULTIPLICITY, Constraint, AssociationClass, Metadata,
    MethodImplementationType
)

# Layout constants for auto-grid positioning
LAYOUT_GRID_WIDTH = 1200
LAYOUT_GRID_HEIGHT = 800
LAYOUT_X_SPACING = 300
LAYOUT_Y_SPACING = 200
LAYOUT_MAX_COLUMNS = 3

logger = logging.getLogger(__name__)
from besser.utilities.web_modeling_editor.backend.constants.constants import (
    VISIBILITY_MAP, RELATIONSHIP_TYPES
)
from besser.utilities.web_modeling_editor.backend.services.utils import (
    determine_connection_direction, calculate_connection_points,
    calculate_path_points, calculate_relationship_bounds
)


def _format_multiplicity_label(multiplicity):
    """Render a ``Multiplicity`` as its UML association-end label.

    Collapses an exact multiplicity (``min == max``) to a single value, matching
    UML convention (``1..1`` -> ``1``, ``5..5`` -> ``5``). An unbounded upper bound
    renders as ``*`` (``0..*``, ``1..*``). The result round-trips through
    ``parse_multiplicity`` (a bare ``N`` is read back as ``N..N``).
    """
    min_val = multiplicity.min
    if multiplicity.max == UNLIMITED_MAX_MULTIPLICITY:
        return f"{min_val}..*"
    if min_val == multiplicity.max:
        return f"{min_val}"
    return f"{min_val}..{multiplicity.max}"


def parse_buml_content(content: str) -> DomainModel:
    """Parse B-UML content from a Python file and return a DomainModel and OCL constraints."""
    try:
        # If caller already passed a DomainModel instance, return it directly.
        if isinstance(content, DomainModel):
            return content

        # Create a safe environment for eval without any generators.
        # __name__ is set to a sentinel (not "__main__") so any
        # ``if __name__ == "__main__":`` guarded blocks in user files are
        # skipped during import — matching normal Python import semantics.
        safe_globals = {
            "__name__": "besser_buml_import",
            "__builtins__": {
                "set": set,
                "list": list,
                "dict": dict,
                "tuple": tuple,
                "str": str,
                "int": int,
                "float": float,
                "bool": bool,
                "len": len,
                "range": range,
                "True": True,
                "False": False,
                "None": None,
                "print": lambda *a, **kw: None,  # no-op to prevent info leakage
            },
            "Class": Class,
            "Property": Property,
            "Method": Method,
            "Parameter": StructuralParameter,
            "PrimitiveDataType": PrimitiveDataType,
            "BinaryAssociation": BinaryAssociation,
            "Constraint": Constraint,
            "Multiplicity": Multiplicity,
            "UNLIMITED_MAX_MULTIPLICITY": UNLIMITED_MAX_MULTIPLICITY,
            "Generalization": Generalization,
            "Enumeration": Enumeration,
            "EnumerationLiteral": EnumerationLiteral,
            "DomainModel": DomainModel,
            "AssociationClass": AssociationClass,
            "Metadata": Metadata,
            "MethodImplementationType": MethodImplementationType,
            "set": set,
            "StringType": PrimitiveDataType("str"),
            "IntegerType": PrimitiveDataType("int"),
            "FloatType": PrimitiveDataType("float"),
            "BooleanType": PrimitiveDataType("bool"),
            "TimeType": PrimitiveDataType("time"),
            "DateType": PrimitiveDataType("date"),
            "DateTimeType": PrimitiveDataType("datetime"),
            "TimeDeltaType": PrimitiveDataType("timedelta"),
            "AnyType": PrimitiveDataType("any"),
            # No-op stub: project-exported files often end with a
            # `project = Project(name=..., models=[domain_model], ...)` tail.
            # The class converter only cares about the DomainModel; swallowing
            # the Project(...) call with a stub keeps the sandbox import-tolerant.
            "Project": lambda *args, **kwargs: None,
        }

        # Ensure we have a string before preprocessing
        if not isinstance(content, str):
            raise TypeError(f"Expected B-UML content as str or DomainModel, got {type(content)!r}")

        # Strip a leading UTF-8 BOM so the sandboxed exec does not fail with
        # "invalid non-printable character U+FEFF" for files saved with a BOM.
        if content.startswith("﻿"):
            content = content[1:]

        # Pre-process the content to remove import and generator-related lines.
        # All required types are already provided in safe_globals, so import
        # statements are unnecessary and would fail in the sandboxed environment.
        cleaned_lines = []
        in_import_block = False
        for line in content.splitlines():
            stripped = line.lstrip()
            if in_import_block:
                # Continue skipping until we find the closing parenthesis
                if ")" in line:
                    in_import_block = False
                continue
            if stripped.startswith(("import ", "from ")):
                # Check if this is a multi-line import (has open paren but no close)
                if "(" in line and ")" not in line:
                    in_import_block = True
                continue
            if any(gen in line for gen in ["Generator(", ".generate("]):
                continue
            cleaned_lines.append(line)
        cleaned_content = "\n".join(cleaned_lines)

        # Execute the cleaned B-UML content
        local_vars = {}
        exec(cleaned_content, safe_globals, local_vars)

        domain_name = "Imported_Domain_Model"
        for var_name, var_value in local_vars.items():
            if isinstance(var_value, DomainModel):
                domain_name = var_value.name

        domain_model = DomainModel(domain_name)
        # First pass: Add all classes and enumerations
        classes = {}
        for var_name, var_value in local_vars.items():
            if isinstance(var_value, (Class, Enumeration)):
                domain_model.types.add(var_value)
                classes[var_name] = var_value
            elif isinstance(var_value, Constraint):
                domain_model.constraints.add(var_value)

        # Second pass: Add associations and generalizations
        for var_name, var_value in local_vars.items():
            if isinstance(var_value, BinaryAssociation):
                domain_model.associations.add(var_value)
            elif isinstance(var_value, Generalization):
                domain_model.generalizations.add(var_value)

        return domain_model

    except Exception as e:
        logger.error("Error parsing B-UML content: %s", e)
        raise ValueError(f"Failed to parse B-UML content: {str(e)}")


def class_buml_to_json(domain_model):
    """Convert a B-UML DomainModel object to JSON format matching the frontend structure."""
    elements = {}
    relationships = {}
    # Retrieve method diagram reference mapping (populated by json_to_buml round-trip).
    # Keyed by (class_name, method_name) -> {"stateMachineId": ..., "quantumCircuitId": ...}
    method_diagram_refs = getattr(domain_model, 'method_diagram_refs', {})
    # Retrieve saved layout positions for round-trip fidelity (populated by json_to_buml).
    # Keyed by element name (classes/enums) or composite key (relationships).
    layout_positions = getattr(domain_model, '_layout_positions', {})
    # Default diagram size
    default_size = {
        "width": LAYOUT_GRID_WIDTH,
        "height": LAYOUT_GRID_HEIGHT,
    }

    # Grid layout configuration
    grid_size = {
        "x_spacing": LAYOUT_X_SPACING,
        "y_spacing": LAYOUT_Y_SPACING,
        "max_columns": LAYOUT_MAX_COLUMNS,
    }

    # Track position
    current_column = 0
    current_row = 0

    # Track comments to create
    comments_to_create = []  # [(comment_text, linked_class_id)]

    def get_position():
        nonlocal current_column, current_row
        x = -600 + (current_column * grid_size["x_spacing"])
        y = -300 + (current_row * grid_size["y_spacing"])

        # Move to next position
        current_column += 1
        if current_column >= grid_size["max_columns"]:
            current_column = 0
            current_row += 1

        return x, y

    # First pass: Create all class and enumeration elements
    class_id_map = {}  # Store mapping between Class objects and their IDs

    # Sort types/constraints by name for deterministic output across runs.
    for type_obj in sorted(
        (t for t in domain_model.types | domain_model.constraints if isinstance(t, (Class, Enumeration, Constraint))),
        key=lambda t: t.name,
    ):
            # Generate UUID for the element. OCL pre/post are emitted as
            # full text including the Class::method header, so element-id
            # stability is no longer required.
            element_id = str(uuid.uuid4())
            class_id_map[type_obj] = element_id

            # Use saved layout position if available, otherwise fall back to grid layout
            saved_bounds = layout_positions.get(type_obj.name)
            if saved_bounds:
                x = saved_bounds["x"]
                y = saved_bounds["y"]
                saved_width = saved_bounds.get("width", 160)
                saved_height = saved_bounds.get("height", 100)
            else:
                x, y = get_position()
                saved_width = None
                saved_height = None

            # Initialize lists for attributes and methods IDs
            attribute_ids = []
            method_ids = []

            # Header height must mirror the editor's UMLClassifier renderer
            # (stereotypeHeaderHeight=50, nonStereotypeHeaderHeight=40) so ELK
            # auto-layout and the headless SVG renderer agree on box geometry.
            # Enumerations and abstract classes carry a «stereotype» line, so
            # their header is one row taller and members start lower.
            is_stereotyped = isinstance(type_obj, Enumeration) or (
                isinstance(type_obj, Class) and getattr(type_obj, "is_abstract", False)
            )
            header_height = 50 if is_stereotyped else 40

            # Process attributes/literals
            y_offset = y + header_height  # Members start below the header
            if isinstance(type_obj, Class):
                for attr in sorted(type_obj.attributes, key=lambda a: a.name):
                    attr_id = str(uuid.uuid4())
                    attr_type = (
                        attr.type.name if hasattr(attr.type, "name") else str(attr.type)
                    )

                    attr_element = {
                        "id": attr_id,
                        "name": attr.name,
                        "type": "ClassAttribute",
                        "owner": element_id,
                        "bounds": {
                            "x": x + 0.5,
                            "y": y_offset,
                            "width": 159,
                            "height": 30,
                        },
                        "visibility": attr.visibility,
                        "attributeType": attr_type,
                        "isOptional": attr.is_optional,
                        "isId": attr.is_id,
                        "isExternalId": attr.is_external_id,
                        "isDerived": attr.is_derived,
                    }
                    if attr.default_value is not None:
                        # default_value may be an EnumerationLiteral (or other
                        # metamodel object); coerce it to a JSON-serialisable
                        # value — its name, else its string form — so the diagram
                        # JSON can be serialised when sent to the render service.
                        default_value = attr.default_value
                        if not isinstance(default_value, (str, int, float, bool)):
                            default_value = getattr(default_value, "name", None) or str(default_value)
                        attr_element["defaultValue"] = default_value
                    elements[attr_id] = attr_element
                    attribute_ids.append(attr_id)
                    y_offset += 30

                # Process methods
                for method in sorted(type_obj.methods, key=lambda m: m.name):
                    method_id = str(uuid.uuid4())
                    visibility_symbol = next(
                        k for k, v in VISIBILITY_MAP.items() if v == method.visibility
                    )

                    # Build method signature with parameters and return type
                    param_str = []
                    for param in method.parameters:
                        param_type = (
                            param.type.name
                            if hasattr(param.type, "name")
                            else str(param.type)
                        )
                        param_signature = f"{param.name}: {param_type}"
                        if (
                            hasattr(param, "default_value")
                            and param.default_value is not None
                        ):
                            param_signature += f" = {param.default_value}"
                        param_str.append(param_signature)

                    # Build complete method signature
                    method_signature = (
                        f"{visibility_symbol} {method.name}({', '.join(param_str)})"
                    )
                    if hasattr(method, "type") and method.type:
                        return_type = (
                            method.type.name
                            if hasattr(method.type, "name")
                            else str(method.type)
                        )
                        method_signature += f": {return_type}"

                    method_element = {
                        "id": method_id,
                        "name": method_signature,
                        "type": "ClassMethod",
                        "owner": element_id,
                        "bounds": {
                            "x": x + 0.5,
                            "y": y_offset,
                            "width": 159,
                            "height": 30,
                        },
                    }

                    # Add code attribute if it exists and is not empty
                    if hasattr(method, "code") and method.code:
                        method_element["code"] = method.code

                    # Add implementation type and diagram references
                    if hasattr(method, "implementation_type") and method.implementation_type:
                        impl_type_map = {
                            MethodImplementationType.NONE: "none",
                            MethodImplementationType.CODE: "code",
                            MethodImplementationType.BAL: "bal",
                            MethodImplementationType.STATE_MACHINE: "state_machine",
                            MethodImplementationType.QUANTUM_CIRCUIT: "quantum_circuit",
                        }
                        impl_type_str_map = {
                            "none": "none",
                            "code": "code",
                            "bal": "bal",
                            "state_machine": "state_machine",
                            "quantum_circuit": "quantum_circuit",
                        }
                        impl_type = method.implementation_type
                        if isinstance(impl_type, str):
                            normalized_impl_type = impl_type.strip()
                            if normalized_impl_type.startswith("MethodImplementationType."):
                                normalized_impl_type = normalized_impl_type.split(".", maxsplit=1)[1]
                            method_element["implementationType"] = impl_type_str_map.get(
                                normalized_impl_type.lower(), "none"
                            )
                        else:
                            method_element["implementationType"] = impl_type_map.get(impl_type, "none")

                    # Add state machine reference if present.
                    # First check the method_diagram_refs mapping (populated during
                    # json_to_buml conversion), then fall back to actual object references.
                    refs = method_diagram_refs.get((type_obj.name, method.name), {})
                    state_machine_id = refs.get("stateMachineId") or None
                    if not state_machine_id and hasattr(method, "state_machine") and method.state_machine:
                        # If we have an actual state machine object, use its name as ID
                        state_machine_id = method.state_machine.name
                    if state_machine_id:
                        method_element["stateMachineId"] = state_machine_id

                    quantum_circuit_id = refs.get("quantumCircuitId") or None
                    if not quantum_circuit_id and hasattr(method, "quantum_circuit") and method.quantum_circuit:
                        # If we have an actual quantum circuit object, use its name as ID
                        quantum_circuit_id = method.quantum_circuit.name
                    if quantum_circuit_id:
                        method_element["quantumCircuitId"] = quantum_circuit_id

                    elements[method_id] = method_element
                    method_ids.append(method_id)
                    y_offset += 30

            elif isinstance(type_obj, Enumeration):
                # Use preserved insertion order if available (from JSON round-trip),
                # otherwise fall back to alphabetical sort for deterministic output.
                ordered_literals = getattr(type_obj, '_ordered_literals', None)
                if ordered_literals is not None:
                    literals_iter = ordered_literals
                else:
                    literals_iter = sorted(type_obj.literals, key=lambda lit: lit.name)
                for literal in literals_iter:
                    literal_id = str(uuid.uuid4())
                    elements[literal_id] = {
                        "id": literal_id,
                        "name": literal.name,
                        "type": "ClassAttribute",  # We use ClassAttribute type for literals
                        "owner": element_id,
                        "bounds": {
                            "x": x + 0.5,
                            "y": y_offset,
                            "width": 159,
                            "height": 30,
                        },
                    }
                    attribute_ids.append(literal_id)
                    y_offset += 30

            # Create the element. Box height mirrors the renderer: header plus
            # one 30px row per attribute/method (see UMLClassifier.render). OCL
            # constraint boxes are not classifiers, so keep their legacy sizing.
            member_count = len(attribute_ids) + len(method_ids)
            if isinstance(type_obj, Constraint):
                computed_height = max(100, 30 * (member_count + 1))
            else:
                computed_height = header_height + 30 * member_count
            element_data = {
                "id": element_id,
                "name": type_obj.name,
                "type": (
                    "Enumeration"
                    if isinstance(type_obj, Enumeration)
                    else (
                        "ClassOCLConstraint"
                        if isinstance(type_obj, Constraint)
                        else "AbstractClass" if type_obj.is_abstract else "Class"
                    )
                ),
                "owner": None,
                "bounds": {
                    "x": x,
                    "y": y,
                    "width": saved_width if saved_width is not None else 160,
                    "height": saved_height if saved_height is not None else computed_height,
                },
                **(
                    {
                        "attributes": attribute_ids,
                        "methods": method_ids,
                        "stereotype": (
                            "enumeration" if isinstance(type_obj, Enumeration) else None
                        ),
                    }
                    if not isinstance(type_obj, Constraint)
                    # Class-level constraints are always invariants and their
                    # ``expression`` field already carries the full canonical
                    # ``context X inv name: body`` text (set at JSON-to-BUML
                    # parse time). Emit it verbatim — no reconstruction
                    # needed.
                    else {
                        "constraint": type_obj.expression,
                    }
                ),
            }

            # Surface natural-language constraint descriptions for the editor
            if isinstance(type_obj, Constraint) and getattr(type_obj, 'description', None):
                element_data["description"] = type_obj.description

            # Add metadata fields for classes if they exist
            if isinstance(type_obj, Class) and hasattr(type_obj, 'metadata') and type_obj.metadata:
                if type_obj.metadata.description:
                    element_data["description"] = type_obj.metadata.description
                    # Also create a comment element linked to this class
                    comments_to_create.append((type_obj.metadata.description, element_id))
                if type_obj.metadata.uri:
                    element_data["uri"] = type_obj.metadata.uri
                if type_obj.metadata.icon:
                    element_data["icon"] = type_obj.metadata.icon

            elements[element_id] = element_data

    # Second pass: Create relationships
    for association in sorted(domain_model.associations, key=lambda a: a.name):
        try:
            rel_id = str(uuid.uuid4())
            name = association.name if association.name else ""
            # Sort ends by name for deterministic source/target assignment
            # before applying the swap logic below.
            ends = sorted(association.ends, key=lambda e: e.name)
            if len(ends) == 2:
                source_prop, target_prop = ends

                # Check navigability and composition, swap if needed
                if source_prop.is_composite and not target_prop.is_composite:
                    source_prop, target_prop = target_prop, source_prop
                elif not source_prop.is_composite and not target_prop.is_composite:
                    if not source_prop.is_navigable and target_prop.is_navigable:
                        pass
                    elif source_prop.is_navigable and not target_prop.is_navigable:
                        source_prop, target_prop = target_prop, source_prop
                    elif not source_prop.is_navigable and not target_prop.is_navigable:
                        logger.warning("Both ends of association %s are not navigable. Skipping this association.", name)
                        continue

                source_class = source_prop.type
                target_class = target_prop.type

                if source_class in class_id_map and target_class in class_id_map:
                    # Determine relationship type.
                    # NOTE: ClassAggregation cannot be reconstructed here because the
                    # B-UML metamodel does not carry an aggregation flag on Property.
                    # Aggregation associations are round-tripped as ClassBidirectional.
                    rel_type = (
                        RELATIONSHIP_TYPES["composition"]
                        if target_prop.is_composite
                        else (
                            RELATIONSHIP_TYPES["bidirectional"]
                            if source_prop.is_navigable and target_prop.is_navigable
                            else RELATIONSHIP_TYPES["unidirectional"]
                        )
                    )

                    # Check for saved layout positions from a previous round-trip
                    saved_rel = layout_positions.get(f"rel_{name}")
                    if saved_rel:
                        # Restore saved layout
                        rel_bounds = saved_rel.get("bounds", {"x": 0, "y": 0, "width": 0, "height": 0})
                        path_points = saved_rel.get("path", [{"x": 0, "y": 0}, {"x": 0, "y": 0}])
                        is_manually_layouted = saved_rel.get("isManuallyLayouted", False)
                        source_bounds = saved_rel.get("source_bounds", {"x": 0, "y": 0, "width": 0, "height": 0})
                        source_dir = saved_rel.get("source_direction", "Right")
                        target_bounds = saved_rel.get("target_bounds", {"x": 0, "y": 0, "width": 0, "height": 0})
                        target_dir = saved_rel.get("target_direction", "Left")
                    else:
                        # Fall back to computing layout from element positions
                        source_element = elements[class_id_map[source_class]]
                        target_element = elements[class_id_map[target_class]]

                        source_dir, target_dir = determine_connection_direction(
                            source_element["bounds"], target_element["bounds"]
                        )
                        source_point = calculate_connection_points(
                            source_element["bounds"], source_dir
                        )
                        target_point = calculate_connection_points(
                            target_element["bounds"], target_dir
                        )
                        path_points = calculate_path_points(
                            source_point, target_point, source_dir, target_dir
                        )
                        rel_bounds = calculate_relationship_bounds(path_points)
                        is_manually_layouted = False
                        source_bounds = {
                            "x": source_point["x"],
                            "y": source_point["y"],
                            "width": 0,
                            "height": 0,
                        }
                        target_bounds = {
                            "x": target_point["x"],
                            "y": target_point["y"],
                            "width": 0,
                            "height": 0,
                        }

                    relationships[rel_id] = {
                        "id": rel_id,
                        "name": name,
                        "type": rel_type,
                        "source": {
                            "element": class_id_map[source_class],
                            "multiplicity": _format_multiplicity_label(source_prop.multiplicity),
                            "role": source_prop.name,
                            "direction": source_dir,
                            "bounds": source_bounds,
                        },
                        "target": {
                            "element": class_id_map[target_class],
                            "multiplicity": _format_multiplicity_label(target_prop.multiplicity),
                            "role": target_prop.name,
                            "direction": target_dir,
                            "bounds": target_bounds,
                        },
                        "bounds": rel_bounds,
                        "path": path_points,
                        "isManuallyLayouted": is_manually_layouted,
                    }
        except Exception as e:
            logger.error("Error converting relationship to JSON: %s", e, exc_info=True)
            continue

    # Handle generalizations
    for generalization in sorted(domain_model.generalizations, key=lambda g: (g.specific.name, g.general.name)):
        rel_id = str(uuid.uuid4())
        if (
            generalization.general in class_id_map
            and generalization.specific in class_id_map
        ):
            # Check for saved layout positions from a previous round-trip
            gen_key = f"gen_{generalization.specific.name}_{generalization.general.name}"
            saved_gen = layout_positions.get(gen_key)
            if saved_gen:
                gen_path = saved_gen.get("path", [
                    {"x": 0, "y": 0}, {"x": 50, "y": 0},
                    {"x": 50, "y": 50}, {"x": 100, "y": 50},
                ])
                gen_source_bounds = saved_gen.get("source_bounds", {"x": 0, "y": 0, "width": 0, "height": 0})
                gen_target_bounds = saved_gen.get("target_bounds", {"x": 0, "y": 0, "width": 0, "height": 0})
            else:
                gen_path = [
                    {"x": 0, "y": 0}, {"x": 50, "y": 0},
                    {"x": 50, "y": 50}, {"x": 100, "y": 50},
                ]
                gen_source_bounds = {"x": 0, "y": 0, "width": 0, "height": 0}
                gen_target_bounds = {"x": 0, "y": 0, "width": 0, "height": 0}

            relationships[rel_id] = {
                "id": rel_id,
                "type": "ClassInheritance",
                "source": {
                    "element": class_id_map[generalization.specific],
                    "bounds": gen_source_bounds,
                },
                "target": {
                    "element": class_id_map[generalization.general],
                    "bounds": gen_target_bounds,
                },
                "path": gen_path,
            }

    # Handle association classes
    for type_obj in sorted(domain_model.types, key=lambda t: t.name):
        if isinstance(type_obj, AssociationClass) and type_obj in class_id_map:
            # Track associations by name for easier lookup
            association_by_name = {}
            for rel_id, rel in relationships.items():
                if rel.get("type") in [
                    "ClassBidirectional",
                    "ClassUnidirectional",
                    "ClassComposition",
                ]:
                    association_by_name[rel.get("name", "")] = rel_id

            # Find the association relationship ID by name
            association_rel_id = association_by_name.get(type_obj.association.name)
            if association_rel_id:
                # Create a ClassLinkRel relationship
                rel_id = str(uuid.uuid4())

                relationships[rel_id] = {
                    "id": rel_id,
                    "name": "",
                    "type": "ClassLinkRel",
                    "owner": None,
                    "source": {"element": association_rel_id, "direction": "Center"},
                    "target": {"element": class_id_map[type_obj], "direction": "Up"},
                    "bounds": {"x": 0, "y": 0, "width": 0, "height": 0},
                    "path": [{"x": 0, "y": 0}, {"x": 0, "y": 0}],
                    "isManuallyLayouted": False,
                }

    # Handle OCL constraint links (visual-only relationships).
    # NOTE: The constraint DATA is stored in ClassOCLConstraint elements (created above
    # from domain_model.constraints). The ClassOCLLink relationships created here are
    # purely for the frontend to draw a visual link between the constraint box and the
    # class it applies to. On the json_to_buml side, ClassOCLLink relationships are
    # intentionally skipped (the context class is derived from the OCL expression text).
    # Both are needed: the element for data, the link for visual layout.
    for type_obj in sorted(domain_model.constraints, key=lambda c: c.name):
        if isinstance(type_obj, Constraint) and type_obj.context in class_id_map:
            rel_id = str(uuid.uuid4())
            relationships[rel_id] = {
                "id": rel_id,
                "name": "",
                "type": "ClassOCLLink",
                "owner": None,
                "source": {
                    "direction": "Left",
                    "element": class_id_map[type_obj],
                    "multiplicity": "",
                    "role": "",
                },
                "target": {
                    "direction": "Right",
                    "element": class_id_map[type_obj.context],
                    "multiplicity": "",
                    "role": "",
                },
                "bounds": {"x": 0, "y": 0, "width": 0, "height": 0},
                "path": [{"x": 0, "y": 0}, {"x": 0, "y": 0}],
                "isManuallyLayouted": False,
            }

    # Emit pre/post conditions anchored on Method.pre and Method.post.
    # These are stored on the metamodel as first-class fields (not inside
    # domain_model.constraints), so they need their own emission pass.
    # Each constraint becomes its own ClassOCLConstraint element + a
    # ClassOCLLink to the owning class. The textbox carries the full
    # ``context X::method(params) pre|post: body`` form — same shape the
    # ingest path now expects from a freshly-typed constraint.
    for cls in sorted(
        (t for t in domain_model.types if isinstance(t, Class)),
        key=lambda c: c.name,
    ):
        if cls not in class_id_map:
            continue
        for method in sorted(cls.methods, key=lambda m: m.name):
            for kind, constraints in (("precondition", getattr(method, "pre", []) or []),
                                       ("postcondition", getattr(method, "post", []) or [])):
                for constraint in constraints:
                    box_id = str(uuid.uuid4())
                    elements[box_id] = {
                        "id": box_id,
                        "type": "ClassOCLConstraint",
                        "owner": None,
                        "bounds": {"x": 0, "y": 0, "width": 200, "height": 100},
                        # ``expression`` carries the full canonical
                        # ``context X::method(params) pre|post: body`` text
                        # (set at JSON-to-BUML parse time). No reconstruction
                        # needed.
                        "constraint": constraint.expression,
                    }
                    # Mirror the invariant emit path: surface the
                    # natural-language description so JSON↔BUML round-trips
                    # are symmetric for method contracts too.
                    if getattr(constraint, "description", None):
                        elements[box_id]["description"] = constraint.description
                    rel_id = str(uuid.uuid4())
                    relationships[rel_id] = {
                        "id": rel_id,
                        "name": "",
                        "type": "ClassOCLLink",
                        "owner": None,
                        "source": {
                            "direction": "Left",
                            "element": box_id,
                            "multiplicity": "",
                            "role": "",
                        },
                        "target": {
                            "direction": "Right",
                            "element": class_id_map[cls],
                            "multiplicity": "",
                            "role": "",
                        },
                        "bounds": {"x": 0, "y": 0, "width": 0, "height": 0},
                        "path": [{"x": 0, "y": 0}, {"x": 0, "y": 0}],
                        "isManuallyLayouted": False,
                    }

    # Create comment elements from metadata descriptions
    for comment_text, linked_class_id in comments_to_create:
        comment_id = str(uuid.uuid4())
        x, y = get_position()

        # Create comment element
        elements[comment_id] = {
            "id": comment_id,
            "name": comment_text,
            "type": "Comments",
            "owner": None,
            "bounds": {
                "x": x,
                "y": y,
                "width": 160,
                "height": 100,
            },
        }

        # Create Link relationship from comment to class
        rel_id = str(uuid.uuid4())
        relationships[rel_id] = {
            "id": rel_id,
            "name": "",
            "type": "Link",
            "owner": None,
            "source": {
                "direction": "Right",
                "element": comment_id,
                "multiplicity": "",
                "role": "",
            },
            "target": {
                "direction": "Left",
                "element": linked_class_id,
                "multiplicity": "",
                "role": "",
            },
            "bounds": {"x": 0, "y": 0, "width": 0, "height": 0},
            "path": [{"x": 0, "y": 0}, {"x": 0, "y": 0}],
            "isManuallyLayouted": False,
        }

    # Handle domain model level comments (unlinked comments)
    if hasattr(domain_model, 'metadata') and domain_model.metadata and domain_model.metadata.description:
        comment_id = str(uuid.uuid4())
        x, y = get_position()

        elements[comment_id] = {
            "id": comment_id,
            "name": domain_model.metadata.description,
            "type": "Comments",
            "owner": None,
            "bounds": {
                "x": x,
                "y": y,
                "width": 160,
                "height": 100,
            },
        }

    # Create the final structure
    # Clean up implementation-related keys for attributes and empty values
    for elem in elements.values():
        if elem.get("type") == "ClassAttribute":
            elem.pop("implementationType", None)
            elem.pop("stateMachineId", None)
            elem.pop("quantumCircuitId", None)
        if elem.get("type") == "ClassMethod":
            if not elem.get("implementationType"):
                elem.pop("implementationType", None)
            if not elem.get("stateMachineId"):
                elem.pop("stateMachineId", None)
            if not elem.get("quantumCircuitId"):
                elem.pop("quantumCircuitId", None)

    result = {
        "version": "3.0.0",
        "type": "ClassDiagram",
        "size": default_size,
        "interactive": {"elements": {}, "relationships": {}},
        "elements": elements,
        "relationships": relationships,
        "assessments": {},
    }

    return result
