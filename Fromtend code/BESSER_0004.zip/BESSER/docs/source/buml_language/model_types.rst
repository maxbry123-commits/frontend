Model types
===========

.. toctree::
  :maxdepth: 1

  model_types/structural
  model_types/object
  model_types/user_diagram
  model_types/gui
  model_types/ocl
  model_types/deployment
  model_types/state_machine
  model_types/agent
  model_types/bpmn
  model_types/feature_model
  model_types/nn
  model_types/quantum
