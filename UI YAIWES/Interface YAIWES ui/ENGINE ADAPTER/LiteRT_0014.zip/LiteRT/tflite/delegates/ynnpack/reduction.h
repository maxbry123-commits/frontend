/* Copyright 2026 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#ifndef TENSORFLOW_LITE_DELEGATES_YNNPACK_REDUCTION_H_
#define TENSORFLOW_LITE_DELEGATES_YNNPACK_REDUCTION_H_

#include "ynnpack/include/ynnpack.h"  // from @XNNPACK
#include "tflite/core/c/common.h"
#include "tflite/delegates/ynnpack/utils.h"
#include "tflite/delegates/ynnpack/ynnpack_delegate.h"

namespace tflite {
namespace ynnpack {

TfLiteStatus IsReductionSupported(const TfLiteRegistration* registration,
                                  const TfLiteNode* node,
                                  TfLiteContext* context,
                                  const TfLiteYNNPackDelegateOptions& options);

TfLiteStatus DefineReductionNode(TfLiteContext* context,
                                 ynn_subgraph_t subgraph,
                                 TensorToValueIdMap& tensor_to_value_id,
                                 const NodeInfo& node);

}  // namespace ynnpack
}  // namespace tflite

#endif  // TENSORFLOW_LITE_DELEGATES_YNNPACK_REDUCTION_H_
