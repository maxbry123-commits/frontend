/* Copyright 2022 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include "tflite/delegates/utils/experimental/stable_delegate/tflite_settings_json_parser.h"

#include <cstdint>
#include <string>

#include <gtest/gtest.h>
#include "flatbuffers/buffer.h"  // from @flatbuffers
#include "flatbuffers/util.h"  // from @flatbuffers
#include "tflite/acceleration/configuration/configuration_generated.h"

namespace {

using tflite::TFLiteSettings;
using tflite::delegates::utils::TfLiteSettingsJsonParser;

TEST(TfLiteSettingsJsonParserTest, SuccessWithValidXNNPackDelegateSettings) {
  TfLiteSettingsJsonParser parser;

  const TFLiteSettings* tflite_settings = parser.Parse(
      "tflite/delegates/utils/experimental/"
      "stable_delegate/test_xnnpack_settings.json");

  EXPECT_NE(parser.GetBufferPointer(), nullptr);
  EXPECT_NE(parser.GetBufferSize(), 0);
  ASSERT_NE(tflite_settings, nullptr);
  EXPECT_EQ(tflite_settings->delegate(), tflite::Delegate_XNNPACK);
  ASSERT_NE(tflite_settings->xnnpack_settings(), nullptr);
  EXPECT_EQ(tflite_settings->xnnpack_settings()->num_threads(), 5);
}

TEST(TfLiteSettingsJsonParserTest, GetBufferPointerReturnsValidBufferPointers) {
  TfLiteSettingsJsonParser parser;
  parser.Parse(
      "tflite/delegates/utils/experimental/"
      "stable_delegate/test_xnnpack_settings.json");
  const uint8_t* buffer_pointer = parser.GetBufferPointer();

  ASSERT_NE(buffer_pointer, nullptr);
  ASSERT_NE(parser.GetBufferSize(), 0);
  const TFLiteSettings* tflite_settings =
      flatbuffers::GetRoot<TFLiteSettings>(buffer_pointer);
  ASSERT_NE(tflite_settings, nullptr);
  EXPECT_EQ(tflite_settings->delegate(), tflite::Delegate_XNNPACK);
  ASSERT_NE(tflite_settings->xnnpack_settings(), nullptr);
  EXPECT_EQ(tflite_settings->xnnpack_settings()->num_threads(), 5);
}

// This test passes the path to a JSON file that the content of the file cannot
// be parsed into the TFLiteSettings structure.
TEST(TfLiteSettingsJsonParserTest, FailedToParseInvalidSettings) {
  TfLiteSettingsJsonParser parser;

  EXPECT_EQ(
      parser.Parse("tflite/tools/delegates/experimental/"
                   "stable_delegate/test_invalid_settings.json"),
      nullptr);
  EXPECT_EQ(parser.GetBufferPointer(), nullptr);
  EXPECT_EQ(parser.GetBufferSize(), 0);
}

TEST(TfLiteSettingsJsonParserTest, FailedToParseWithDifferentRootType) {
  std::string temp_file_path =
      testing::TempDir() + "/test_corrupted_settings.json";
  std::string malicious_payload =
      "table FakeTFLiteSettings { fake_offset : int32 (id: 0); }\n"
      "root_type FakeTFLiteSettings;\n"
      "{ \"fake_offset\": 55555555 }\n";
  ASSERT_TRUE(flatbuffers::SaveFile(temp_file_path.c_str(),
                                    malicious_payload.c_str(),
                                    malicious_payload.size(), false));
  TfLiteSettingsJsonParser parser;
  EXPECT_EQ(parser.Parse(temp_file_path), nullptr);
  EXPECT_EQ(parser.GetBufferPointer(), nullptr);
  EXPECT_EQ(parser.GetBufferSize(), 0);
}
TEST(TfLiteSettingsJsonParserTest, FailedToVerifyDueToTooManyTables) {
  std::string temp_file_path =
      testing::TempDir() + "/test_too_many_tables.json";
  std::string payload;
  uint64_t n = 1000000;
  payload.reserve(100 + n * 3);
  payload += "{\"edgetpu_settings\":{\"inactive_power_configs\":[{}";
  for (uint64_t i = 1; i < n; ++i) {
    payload += ",{}";
  }
  payload += "]}}";
  ASSERT_TRUE(flatbuffers::SaveFile(temp_file_path.c_str(), payload.c_str(),
                                    payload.size(), false));
  TfLiteSettingsJsonParser parser;
  EXPECT_EQ(parser.Parse(temp_file_path), nullptr);
  EXPECT_EQ(parser.GetBufferPointer(), nullptr);
}
}  // namespace
