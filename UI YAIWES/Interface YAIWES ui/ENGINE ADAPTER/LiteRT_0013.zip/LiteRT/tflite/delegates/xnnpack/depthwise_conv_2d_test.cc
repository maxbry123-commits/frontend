/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <cstdint>
#include <functional>
#include <memory>
#include <random>

#include <gtest/gtest.h>
#include "tflite/delegates/xnnpack/depthwise_conv_2d_tester.h"
#include "tflite/delegates/xnnpack/fingerprint_test_helpers.h"
#include "tflite/delegates/xnnpack/xnnpack_delegate.h"

namespace tflite {
namespace xnnpack {

struct DepthwiseConv2D : DelegateTest {};

TEST_F(DepthwiseConv2D, 1x1) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(1)
      .KernelWidth(1)
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, 2x2) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(2)
      .KernelWidth(2)
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, 3x3) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(3)
      .KernelWidth(3)
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, 3x3Stride2) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(3)
      .KernelWidth(3)
      .StrideHeight(2)
      .StrideWidth(2)
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, 5x5) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(5)
      .KernelWidth(5)
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, 5x5Stride2) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(5)
      .KernelWidth(5)
      .StrideHeight(2)
      .StrideWidth(2)
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SmallKernelWithSamePadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 7), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SmallKernelWithValidPadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 7), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .ValidPadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, StrideWithSamePadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, StrideWithValidPadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ValidPadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, DilationWithSamePadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto dilation_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .DilationHeight(dilation_rng())
      .DilationWidth(dilation_rng())
      .SamePadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, DilationWithValidPadding) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto dilation_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .DilationHeight(dilation_rng())
      .DilationWidth(dilation_rng())
      .ValidPadding()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, DepthMultiplier) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));
  auto multiplier_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 8), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .DepthMultiplier(multiplier_rng())
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, FP16Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .FP16Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, TensorWiseQuantizedInt8Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .TensorWiseQuantizedInt8Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, ChannelWiseQuantizedInt8Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ChannelWiseQuantizedInt8Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SparseWeights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SparseWeights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SparseFP16Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SparseWeights()
      .FP16Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SparseTensorWiseQuantizedInt8Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SparseWeights()
      .TensorWiseQuantizedInt8Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, SparseChannelWiseQuantizedInt8Weights) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SparseWeights()
      .ChannelWiseQuantizedInt8Weights()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, ReluActivation) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ReluActivation()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, Relu6Activation) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .Relu6Activation()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, ReluMinus1To1Activation) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ReluMinus1To1Activation()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, DISABLED_TanhActivation) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .TanhActivation()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, DISABLED_SignBitActivation) {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .SignBitActivation()
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, MultiThreading) {
  TfLiteXNNPackDelegateOptions delegate_options =
      TfLiteXNNPackDelegateOptionsDefault();
  delegate_options.num_threads = 2;
  UseCustomDelegate(delegate_options);

  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, WeightsCache) {
  TfLiteXNNPackDelegateOptions delegate_options =
      TfLiteXNNPackDelegateOptionsDefault();
  std::unique_ptr<TfLiteXNNPackDelegateWeightsCache,
                  decltype(&TfLiteXNNPackDelegateWeightsCacheDelete)>
      weights_cache(TfLiteXNNPackDelegateWeightsCacheCreate(),
                    TfLiteXNNPackDelegateWeightsCacheDelete);
  delegate_options.weights_cache = weights_cache.get();
  UseCustomDelegate(delegate_options);

  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto batch_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 4), std::ref(rng));
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(10, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.BatchSize(batch_rng())
      .InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .WeightsCache(weights_cache.get())
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

TEST_F(DepthwiseConv2D, TransientIndirectionBuffer) {
  TfLiteXNNPackDelegateOptions xnnpack_options =
      TfLiteXNNPackDelegateOptionsDefault();
  xnnpack_options.num_threads = 2;
  xnnpack_options.flags |=
      TFLITE_XNNPACK_DELEGATE_FLAG_TRANSIENT_INDIRECTION_BUFFER;
  UseCustomDelegate(xnnpack_options);

  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_int_distribution<int32_t>(5, 25), std::ref(rng));
  auto kernel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 5), std::ref(rng));
  auto stride_rng =
      std::bind(std::uniform_int_distribution<int32_t>(2, 3), std::ref(rng));
  auto channel_rng =
      std::bind(std::uniform_int_distribution<int32_t>(3, 32), std::ref(rng));

  DepthwiseConv2DTester tester;
  tester.InputHeight(input_rng())
      .InputWidth(input_rng())
      .InputChannels(channel_rng())
      .KernelHeight(kernel_rng())
      .KernelWidth(kernel_rng())
      .StrideHeight(stride_rng())
      .StrideWidth(stride_rng())
      .ReuseGeneratedModel(true);
  tester.Test(xnnpack_delegate.get());
  // Second run to test cache lookup runs.
  tester.Test(xnnpack_delegate.get());
}

}  // namespace xnnpack
}  // namespace tflite
