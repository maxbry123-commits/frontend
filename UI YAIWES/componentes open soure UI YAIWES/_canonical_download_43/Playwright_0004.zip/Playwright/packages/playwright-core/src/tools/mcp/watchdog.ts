/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { gracefullyCloseAll, gracefullyCloseSet } from '@utils/processLauncher';
import { testDebug } from './log';

export function setupExitWatchdog() {
  let isExiting = false;
  const handleExit = async (signal: string) => {
    if (isExiting)
      return;
    isExiting = true;
    // eslint-disable-next-line no-restricted-properties
    setTimeout(() => process.exit(0), 15000);
    testDebug('gracefully closing ' + gracefullyCloseSet.size);
    await gracefullyCloseAll();
    // eslint-disable-next-line no-restricted-properties
    process.exit(0);
  };

  process.stdin.on('close', () => handleExit('close'));
  process.on('SIGINT', () => handleExit('SIGINT'));
  process.on('SIGTERM', () => handleExit('SIGTERM'));
}
