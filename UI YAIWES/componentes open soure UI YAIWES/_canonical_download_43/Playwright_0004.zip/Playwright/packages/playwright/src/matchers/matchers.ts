/**
 * Copyright Microsoft Corporation. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import colors from 'colors/safe';
import { asLocatorDescription } from '@isomorphic/locatorGenerators';
import { isTextualMimeType } from '@isomorphic/mimeType';
import { isRegExp } from '@isomorphic/rtti';
import { isString } from '@isomorphic/stringUtils';
import { pollAgainstDeadline } from '@isomorphic/timeoutRunner';
import { constructURLBasedOnBaseURL, isURLPattern } from '@isomorphic/urlMatch';
import { monotonicTime } from '@isomorphic/index';

import { expectTypes, formatMatcherMessage, MatcherResult } from './matcherHint';
import { toBeTruthy } from './toBeTruthy';
import { toEqual } from './toEqual';
import { toHaveURLWithPredicate } from './toHaveURL';
import { toMatchText } from './toMatchText';
import { toHaveScreenshotStepTitle } from './toMatchSnapshot';
import { expectConfig } from './expect';

import type { ExpectMatcherState } from '../../types/test';
import type { ExpectTestInfo } from './expect';
import type { InternalMatcherUtils } from './matcherHint';
import type { APIResponse, Locator, Frame, Page } from 'playwright-core';
import type { ExpectResult } from 'playwright-core/lib/client/frame';
import type { FrameExpectParams } from 'playwright-core/lib/client/types';
import type { ExpectMatcherUtils } from '../../types/test';
import type { URLPattern } from '@isomorphic/urlMatch';

export type ExpectMatcherStateInternal = Omit<ExpectMatcherState, 'utils'> & {
  utils: ExpectMatcherUtils & InternalMatcherUtils;
  title: string;
};

type ExpectedTextValue = {
  string?: string,
  regexSource?: string,
  regexFlags?: string,
  matchSubstring?: boolean,
  ignoreCase?: boolean,
  normalizeWhiteSpace?: boolean,
};

function serializeExpectedTextValues(items: (string | RegExp)[], options: { matchSubstring?: boolean, normalizeWhiteSpace?: boolean, ignoreCase?: boolean } = {}): ExpectedTextValue[] {
  return items.map(i => ({
    string: isString(i) ? i : undefined,
    regexSource: isRegExp(i) ? i.source : undefined,
    regexFlags: isRegExp(i) ? i.flags : undefined,
    matchSubstring: options.matchSubstring,
    ignoreCase: options.ignoreCase,
    normalizeWhiteSpace: options.normalizeWhiteSpace,
  }));
}

export interface LocatorEx extends Locator {
  _selector: string;
  _expect(expression: string, options: FrameExpectParams): Promise<ExpectResult>;
}

export interface FrameEx extends Frame {
  _expect(expression: string, options: FrameExpectParams): Promise<ExpectResult>;
}

interface APIResponseEx extends APIResponse {
  _fetchLog(): Promise<string[]>;
}

export function toBeAttached(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { attached?: boolean, timeout?: number, signal?: AbortSignal },
) {
  const attached = !options || options.attached === undefined || options.attached;
  const expected = attached ? 'attached' : 'detached';
  const arg = attached ? '' : '{ attached: false }';
  return toBeTruthy.call(this, 'toBeAttached', locator, 'Locator', expected, arg, async (isNot, timeout, signal) => {
    return await locator._expect(attached ? 'to.be.attached' : 'to.be.detached', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeChecked(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { checked?: boolean, indeterminate?: boolean, timeout?: number, signal?: AbortSignal },
) {
  const checked = options?.checked;
  const indeterminate = options?.indeterminate;
  const expectedValue = {
    checked,
    indeterminate,
  };
  let expected: string;
  let arg: string;
  if (options?.indeterminate) {
    expected = 'indeterminate';
    arg = `{ indeterminate: true }`;
  } else {
    expected = options?.checked === false ? 'unchecked' : 'checked';
    arg = options?.checked === false ? `{ checked: false }` : '';
  }
  return toBeTruthy.call(this, 'toBeChecked', locator, 'Locator', expected, arg, async (isNot, timeout, signal) => {
    return await locator._expect('to.be.checked', { isNot, timeout, expectedValue, signal, title: this.title });
  }, options);
}

export function toBeDisabled(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toBeTruthy.call(this, 'toBeDisabled', locator, 'Locator', 'disabled', '', async (isNot, timeout, signal) => {
    return await locator._expect('to.be.disabled', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeEditable(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { editable?: boolean, timeout?: number, signal?: AbortSignal },
) {
  const editable = !options || options.editable === undefined || options.editable;
  const expected = editable ? 'editable' : 'readOnly';
  const arg = editable ? '' : '{ editable: false }';
  return toBeTruthy.call(this, 'toBeEditable', locator, 'Locator', expected, arg, async (isNot, timeout, signal) => {
    return await locator._expect(editable ? 'to.be.editable' : 'to.be.readonly', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeEmpty(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toBeTruthy.call(this, 'toBeEmpty', locator, 'Locator', 'empty', '', async (isNot, timeout, signal) => {
    return await locator._expect('to.be.empty', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeEnabled(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { enabled?: boolean, timeout?: number, signal?: AbortSignal },
) {
  const enabled = !options || options.enabled === undefined || options.enabled;
  const expected = enabled ? 'enabled' : 'disabled';
  const arg = enabled ? '' : '{ enabled: false }';
  return toBeTruthy.call(this, 'toBeEnabled', locator, 'Locator', expected, arg, async (isNot, timeout, signal) => {
    return await locator._expect(enabled ? 'to.be.enabled' : 'to.be.disabled', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeFocused(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toBeTruthy.call(this, 'toBeFocused', locator, 'Locator', 'focused', '', async (isNot, timeout, signal) => {
    return await locator._expect('to.be.focused', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeHidden(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toBeTruthy.call(this, 'toBeHidden', locator, 'Locator', 'hidden', '', async (isNot, timeout, signal) => {
    return await locator._expect('to.be.hidden', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeVisible(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { visible?: boolean, timeout?: number, signal?: AbortSignal },
) {
  const visible = !options || options.visible === undefined || options.visible;
  const expected = visible ? 'visible' : 'hidden';
  const arg = visible ? '' : '{ visible: false }';
  return toBeTruthy.call(this, 'toBeVisible', locator, 'Locator', expected, arg, async (isNot, timeout, signal) => {
    return await locator._expect(visible ? 'to.be.visible' : 'to.be.hidden', { isNot, timeout, signal, title: this.title });
  }, options);
}

export function toBeInViewport(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  options?: { timeout?: number, ratio?: number, signal?: AbortSignal },
) {
  return toBeTruthy.call(this, 'toBeInViewport', locator, 'Locator', 'in viewport', '', async (isNot, timeout, signal) => {
    return await locator._expect('to.be.in.viewport', { isNot, expectedNumber: options?.ratio, timeout, signal, title: this.title });
  }, options);
}

export function toContainText(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp | (string | RegExp)[],
  options: { timeout?: number, useInnerText?: boolean, ignoreCase?: boolean, signal?: AbortSignal } = {},
) {
  if (Array.isArray(expected)) {
    return toEqual.call(this, 'toContainText', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues(expected, { matchSubstring: true, normalizeWhiteSpace: true, ignoreCase: options.ignoreCase });
      return await locator._expect('to.contain.text.array', { expectedText, isNot, useInnerText: options.useInnerText, timeout, signal, title: this.title });
    }, expected, { ...options, contains: true });
  } else {
    return toMatchText.call(this, 'toContainText', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues([expected], { matchSubstring: true, normalizeWhiteSpace: true, ignoreCase: options.ignoreCase });
      return await locator._expect('to.have.text', { expectedText, isNot, useInnerText: options.useInnerText, timeout, signal, title: this.title });
    }, expected, { ...options, matchSubstring: true });
  }
}

export function toHaveAccessibleDescription(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp,
  options?: { timeout?: number, ignoreCase?: boolean, signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveAccessibleDescription', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected], { ignoreCase: options?.ignoreCase, normalizeWhiteSpace: true });
    return await locator._expect('to.have.accessible.description', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveAccessibleName(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp,
  options?: { timeout?: number, ignoreCase?: boolean, signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveAccessibleName', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected], { ignoreCase: options?.ignoreCase, normalizeWhiteSpace: true });
    return await locator._expect('to.have.accessible.name', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveAccessibleErrorMessage(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp,
  options?: { timeout?: number; ignoreCase?: boolean, signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveAccessibleErrorMessage', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected], { ignoreCase: options?.ignoreCase, normalizeWhiteSpace: true });
    return await locator._expect('to.have.accessible.error.message', { expectedText: expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveAttribute(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  name: string,
  expected: string | RegExp | undefined | { timeout?: number },
  options?: { timeout?: number, ignoreCase?: boolean, signal?: AbortSignal },
) {
  if (!options) {
    // Update params for the case toHaveAttribute(name, options);
    if (typeof expected === 'object' && !isRegExp(expected)) {
      options = expected;
      expected = undefined;
    }
  }
  if (expected === undefined) {
    return toBeTruthy.call(this, 'toHaveAttribute', locator, 'Locator', 'have attribute', '', async (isNot, timeout, signal) => {
      return await locator._expect('to.have.attribute', { expressionArg: name, isNot, timeout, signal, title: this.title });
    }, options);
  }
  return toMatchText.call(this, 'toHaveAttribute', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected as (string | RegExp)], { ignoreCase: options?.ignoreCase });
    return await locator._expect('to.have.attribute.value', { expressionArg: name, expectedText, isNot, timeout, signal, title: this.title });
  }, expected as (string | RegExp), options);
}

export function toHaveClass(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp | (string | RegExp)[],
  options?: { timeout?: number, signal?: AbortSignal },
) {
  if (Array.isArray(expected)) {
    return toEqual.call(this, 'toHaveClass', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues(expected);
      return await locator._expect('to.have.class.array', { expectedText, isNot, timeout, signal, title: this.title });
    }, expected, options);
  } else {
    return toMatchText.call(this, 'toHaveClass', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues([expected]);
      return await locator._expect('to.have.class', { expectedText, isNot, timeout, signal, title: this.title });
    }, expected, options);
  }
}

export function toContainClass(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | string[],
  options?: { timeout?: number, signal?: AbortSignal },
) {
  if (Array.isArray(expected)) {
    if (expected.some(e => isRegExp(e)))
      throw new Error(`"expected" argument in toContainClass cannot contain RegExp values`);
    return toEqual.call(this, 'toContainClass', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues(expected);
      return await locator._expect('to.contain.class.array', { expectedText, isNot, timeout, signal, title: this.title });
    }, expected, options);
  } else {
    if (isRegExp(expected))
      throw new Error(`"expected" argument in toContainClass cannot be a RegExp value`);
    return toMatchText.call(this, 'toContainClass', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues([expected]);
      return await locator._expect('to.contain.class', { expectedText, isNot, timeout, signal, title: this.title });
    }, expected, options);
  }
}

export function toHaveCount(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: number,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toEqual.call(this, 'toHaveCount', locator, 'Locator', async (isNot, timeout, signal) => {
    return await locator._expect('to.have.count', { expectedNumber: expected, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveCSS(this: ExpectMatcherStateInternal, locator: LocatorEx, name: string, expected: string | RegExp, options?: { timeout?: number, pseudo?: 'before' | 'after', signal?: AbortSignal }): Promise<MatcherResult<any, any>>;
export function toHaveCSS(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  name: string,
  expected: string | RegExp,
  options?: { timeout?: number, pseudo?: 'before' | 'after', signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveCSS', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected]);
    return await locator._expect('to.have.css', { expressionArg: name, expectedText, isNot, pseudo: options?.pseudo, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveId(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveId', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected]);
    return await locator._expect('to.have.id', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveJSProperty(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  name: string,
  expected: any,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toEqual.call(this, 'toHaveJSProperty', locator, 'Locator', async (isNot, timeout, signal) => {
    return await locator._expect('to.have.property', { expressionArg: name, expectedValue: expected, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveRole(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string,
  options?: { timeout?: number, ignoreCase?: boolean, signal?: AbortSignal },
) {
  if (!isString(expected))
    throw new Error(`"role" argument in toHaveRole must be a string`);
  return toMatchText.call(this, 'toHaveRole', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected]);
    return await locator._expect('to.have.role', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveText(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp | (string | RegExp)[],
  options: { timeout?: number, useInnerText?: boolean, ignoreCase?: boolean, signal?: AbortSignal } = {},
) {
  if (Array.isArray(expected)) {
    return toEqual.call(this, 'toHaveText', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues(expected, { normalizeWhiteSpace: true, ignoreCase: options.ignoreCase });
      return await locator._expect('to.have.text.array', { expectedText, isNot, useInnerText: options?.useInnerText, timeout, signal, title: this.title });
    }, expected, options);
  } else {
    return toMatchText.call(this, 'toHaveText', locator, 'Locator', async (isNot, timeout, signal) => {
      const expectedText = serializeExpectedTextValues([expected], { normalizeWhiteSpace: true, ignoreCase: options.ignoreCase });
      return await locator._expect('to.have.text', { expectedText, isNot, useInnerText: options?.useInnerText, timeout, signal, title: this.title });
    }, expected, options);
  }
}

export function toHaveValue(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: string | RegExp,
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toMatchText.call(this, 'toHaveValue', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected]);
    return await locator._expect('to.have.value', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveValues(
  this: ExpectMatcherStateInternal,
  locator: LocatorEx,
  expected: (string | RegExp)[],
  options?: { timeout?: number, signal?: AbortSignal },
) {
  return toEqual.call(this, 'toHaveValues', locator, 'Locator', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues(expected);
    return await locator._expect('to.have.values', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveTitle(
  this: ExpectMatcherStateInternal,
  page: Page,
  expected: string | RegExp,
  options: { timeout?: number, signal?: AbortSignal } = {},
) {
  return toMatchText.call(this, 'toHaveTitle', page, 'Page', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected], { normalizeWhiteSpace: true });
    return await (page.mainFrame() as FrameEx)._expect('to.have.title', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export function toHaveURL(
  this: ExpectMatcherStateInternal,
  page: Page,
  expected: string | RegExp | URLPattern | ((url: URL) => boolean),
  options?: { ignoreCase?: boolean; timeout?: number, signal?: AbortSignal },
) {
  if (isURLPattern(expected))
    return toHaveURLWithPredicate.call(this, page, url => (expected as URLPattern).test(url.href), options);

  // Ports don't support predicates. Keep separate server and client codepaths
  if (typeof expected === 'function')
    return toHaveURLWithPredicate.call(this, page, expected, options);

  const baseURL = (page.context() as any)._options.baseURL;
  expected = typeof expected === 'string' ? constructURLBasedOnBaseURL(baseURL, expected) : expected;
  return toMatchText.call(this, 'toHaveURL', page, 'Page', async (isNot, timeout, signal) => {
    const expectedText = serializeExpectedTextValues([expected], { ignoreCase: options?.ignoreCase });
    return await (page.mainFrame() as FrameEx)._expect('to.have.url', { expectedText, isNot, timeout, signal, title: this.title });
  }, expected, options);
}

export async function toBeOK(
  this: ExpectMatcherStateInternal,
  response: APIResponseEx
) {
  const matcherName = 'toBeOK';
  expectTypes(response, ['APIResponse'], matcherName);

  const contentType = response.headers()['content-type'];
  const isTextEncoding = contentType && isTextualMimeType(contentType);
  const [log, text] = (this.isNot === response.ok()) ? await Promise.all([
    response._fetchLog(),
    isTextEncoding ? response.text() : null
  ]) : [];

  const message = () => formatMatcherMessage(this.utils, {
    isNot: this.isNot,
    promise: this.promise,
    matcherName,
    receiver: 'response',
    expectation: '',
    log,
  }) + (text === null ? '' : `\nResponse text:\n${colors.dim(text?.substring(0, 1000) || '')}`);

  const pass = response.ok();
  return { message, pass };
}

export async function toPass(
  this: ExpectMatcherState,
  callback: () => any,
  options: {
    intervals?: number[];
    timeout?: number,
  } = {},
) {
  const testInfo = expectConfig().testInfo;
  const timeout = options.timeout ?? expectConfig().toPass?.timeout ?? 0;
  const intervals = options.intervals ?? expectConfig().toPass?.intervals ?? [100, 250, 500, 1000];

  const { deadline, timeoutMessage } = deadlineForMatcher(testInfo, timeout);
  const result = await pollAgainstDeadline<Error|undefined>(async () => {
    if (testInfo && expectConfig().testInfo !== testInfo)
      return { continuePolling: false, result: undefined };
    try {
      await callback();
      return { continuePolling: !!this.isNot, result: undefined };
    } catch (e) {
      return { continuePolling: !this.isNot, result: e };
    }
  }, deadline, intervals);

  if (result.timedOut) {
    const message = result.result ? [
      result.result.message,
      '',
      `Call Log:`,
      `- ${timeoutMessage}`,
    ].join('\n') : timeoutMessage;
    return { message: () => message, pass: !!this.isNot };
  }
  return { pass: !this.isNot, message: () => '' };
}

export function computeMatcherTitleSuffix(matcherName: string, receiver: any, args: any[]): { titleSuffix?: string, subtitle?: string, params?: Record<string, any> } {
  if (matcherName === 'toHaveScreenshot') {
    const title = toHaveScreenshotStepTitle(...args);
    return { titleSuffix: title ? `(${title})` : '' };
  }
  if (receiver && typeof receiver === 'object' && (receiver as any)._apiName === 'Locator') {
    try {
      const locator = asLocatorDescription('javascript', (receiver as LocatorEx)._selector);
      return { subtitle: locator, params: { locator } };
    } catch {
    }
  }
  return {};
}

export function deadlineForMatcher(testInfo: ExpectTestInfo | null, timeout: number): { deadline: number; timeoutMessage: string } {
  const startTime = monotonicTime();
  const matcherDeadline = timeout ? startTime + timeout : 0;
  const matcherMessage = `Timeout ${timeout}ms exceeded while waiting on the predicate`;
  if (!testInfo)
    return { deadline: matcherDeadline, timeoutMessage: matcherMessage };
  const { deadline: testDeadline, timeout: testTimeout } = testInfo._deadline();
  const effectiveTestDeadline = testDeadline - 250;
  const testMessage = `Test timeout of ${testTimeout}ms exceeded`;
  if (!matcherDeadline)
    return { deadline: effectiveTestDeadline, timeoutMessage: testMessage };
  return { deadline: Math.min(effectiveTestDeadline, matcherDeadline), timeoutMessage: effectiveTestDeadline < matcherDeadline ? testMessage : matcherMessage };
}
