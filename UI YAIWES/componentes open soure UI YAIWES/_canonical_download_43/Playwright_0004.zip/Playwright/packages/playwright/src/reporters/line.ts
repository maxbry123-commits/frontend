/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { getAsBooleanFromENV } from '@utils/env';

import { markErrorsAsReported, TerminalReporter } from './base';

import type { LineReporterOptions } from '../../types/test';
import type { FullResult, Suite, TestCase, TestError, TestResult, TestStep } from '../../types/testReporter';
import type { CommonReporterOptions, TerminalReporterOptions } from './base';

class LineReporter extends TerminalReporter {
  private _current = 0;
  private _failures = 0;
  private _lastTest: TestCase | undefined;
  private _didBegin = false;

  constructor(options?: LineReporterOptions & CommonReporterOptions & TerminalReporterOptions) {
    super({ ...options, omitTags: getAsBooleanFromENV('PLAYWRIGHT_LINE_OMIT_TAGS', options?.omitTags) });
  }

  override onBegin(suite: Suite) {
    super.onBegin(suite);
    const startingMessage = this.generateStartingMessage();
    if (startingMessage) {
      this.writeLine(startingMessage);
      this.writeLine();
    }
    this._didBegin = true;
  }

  override onStdOut(chunk: string | Buffer, test?: TestCase, result?: TestResult) {
    super.onStdOut(chunk, test, result);
    this._dumpToStdio(test, chunk, this.screen.stdout);
  }

  override onStdErr(chunk: string | Buffer, test?: TestCase, result?: TestResult) {
    super.onStdErr(chunk, test, result);
    this._dumpToStdio(test, chunk, this.screen.stderr);
  }

  private _dumpToStdio(test: TestCase | undefined, chunk: string | Buffer, stream: NodeJS.WriteStream) {
    if (this.config.quiet)
      return;
    if (!process.env.PW_TEST_DEBUG_REPORTERS)
      stream.write(`\u001B[1A\u001B[2K`);
    if (test && this._lastTest !== test) {
      // Write new header for the output.
      const title = this.screen.colors.dim(this.formatTestTitle(test));
      stream.write(this.fitToScreen(title) + `\n`);
      this._lastTest = test;
    }

    stream.write(chunk);
    if (chunk[chunk.length - 1] !== '\n')
      this.writeLine();

    this.writeLine();
  }

  onTestBegin(test: TestCase, result: TestResult) {
    ++this._current;
    this._updateLine(test, result, undefined);
  }

  onStepBegin(test: TestCase, result: TestResult, step: TestStep) {
    if (this.screen.isTTY && step.category === 'test.step')
      this._updateLine(test, result, step);
  }

  onStepEnd(test: TestCase, result: TestResult, step: TestStep) {
    if (this.screen.isTTY && step.category === 'test.step')
      this._updateLine(test, result, step.parent);
  }

  async onTestPaused(test: TestCase, result: TestResult) {
    // without TTY, user cannot interrupt the pause. let's skip it.
    if (!process.stdin.isTTY && !process.env.PW_TEST_DEBUG_REPORTERS)
      return;

    if (!process.env.PW_TEST_DEBUG_REPORTERS)
      this.screen.stdout.write(`\u001B[1A\u001B[2K`);

    if (test.outcome() === 'unexpected') {
      this.writeLine(this.screen.colors.red(this.formatTestHeader(test, { indent: '  ', index: ++this._failures })));
      this.writeLine(this.formatResultErrors(test, result));
      markErrorsAsReported(result);
      this.writeLine(this.screen.colors.yellow(`    Paused on error. Press Ctrl+C to end.`) + '\n\n');
    } else {
      this.writeLine(this.screen.colors.yellow(this.formatTestHeader(test, { indent: '  ' })));
      this.writeLine(this.screen.colors.yellow(`    Paused at test end. Press Ctrl+C to end.`) + '\n\n');
    }

    this._updateLine(test, result, undefined);

    await new Promise<void>(() => {});
  }

  override onTestEnd(test: TestCase, result: TestResult) {
    super.onTestEnd(test, result);
    if (!this.willRetry(test) && (test.outcome() === 'flaky' || test.outcome() === 'unexpected' || result.status === 'interrupted')) {
      if (!process.env.PW_TEST_DEBUG_REPORTERS)
        this.screen.stdout.write(`\u001B[1A\u001B[2K`);
      this.writeLine(this.formatFailure(test, ++this._failures));
      this.writeLine();
    }
  }

  private _updateLine(test: TestCase, result: TestResult, step?: TestStep) {
    const retriesPrefix = result.retry ? ` (retries)` : ``;
    const prefix = `[${this._current}/${this.totalTestCount}]${retriesPrefix} `;
    const currentRetrySuffix = result.retry ? this.screen.colors.yellow(` (retry #${result.retry})`) : '';
    const title = this.formatTestTitle(test, step) + currentRetrySuffix;
    if (process.env.PW_TEST_DEBUG_REPORTERS)
      this.screen.stdout.write(`${prefix + title}\n`);
    else
      this.screen.stdout.write(`\u001B[1A\u001B[2K${prefix + this.fitToScreen(title, prefix)}\n`);
  }

  override onError(error: TestError): void {
    super.onError(error);

    const message = this.formatError(error).message + '\n';
    if (!process.env.PW_TEST_DEBUG_REPORTERS && this._didBegin)
      this.screen.stdout.write(`\u001B[1A\u001B[2K`);
    this.screen.stdout.write(message);
    this.writeLine();
  }

  override async onEnd(result: FullResult) {
    if (!process.env.PW_TEST_DEBUG_REPORTERS && this._didBegin)
      this.screen.stdout.write(`\u001B[1A\u001B[2K`);
    await super.onEnd(result);
    this.epilogue(false);
  }
}

export default LineReporter;
