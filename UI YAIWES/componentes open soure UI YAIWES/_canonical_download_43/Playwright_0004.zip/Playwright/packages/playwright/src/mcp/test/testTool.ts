/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { z } from 'zod';
import type { TestContext } from './testContext.js';
import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import type { tools } from 'playwright-core/lib/coreBundle';

export type TestTool<Input extends z.Schema = z.Schema> = {
  schema: tools.ToolSchema<Input>;
  handle: (context: TestContext, params: z.output<Input>, signal?: AbortSignal) => Promise<CallToolResult>;
};

export function defineTestTool<Input extends z.Schema>(tool: TestTool<Input>): TestTool<Input> {
  return tool;
}
