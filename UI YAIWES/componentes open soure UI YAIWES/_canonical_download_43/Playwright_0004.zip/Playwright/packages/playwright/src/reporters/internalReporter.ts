/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import fs from 'fs';

import { monotonicTime } from '@isomorphic/time';

import { internalScreen, prepareErrorStack, relativeFilePath } from './base';
import { Multiplexer } from './multiplexer';
import { test as testNs } from '../common';
import * as babel from '../transform/babelBundle';
import { wrapReporterAsV2 } from './reporterV2';

import type { AnyReporter, ReporterPreprocessParams, ReporterV2 } from './reporterV2';
import type { FullConfig, FullResult, TestCase, TestError, TestResult, TestStep, WorkerInfo } from '../../types/testReporter';

export class InternalReporter implements ReporterV2 {
  private _reporter: Multiplexer;
  private _didBegin = false;
  private _config!: FullConfig;
  private _startTime: Date | undefined;
  private _monotonicStartTime: number | undefined;

  constructor(reporters: AnyReporter[]) {
    this._reporter = new Multiplexer(reporters.map(wrapReporterAsV2));
  }

  version(): 'v2' {
    return 'v2';
  }

  hasReporterErrors(): boolean {
    return this._reporter.hasReporterErrors();
  }

  onConfigure(config: FullConfig) {
    this._config = config;
    this._startTime = new Date();
    this._monotonicStartTime = monotonicTime();
    this._reporter.onConfigure?.(config);
  }

  async preprocess(params: ReporterPreprocessParams) {
    await this._reporter.preprocess(params);
  }

  onBegin(suite: testNs.Suite) {
    this._didBegin = true;
    this._reporter.onBegin?.(suite);
  }

  onTestBegin(test: TestCase, result: TestResult) {
    this._reporter.onTestBegin?.(test, result);
  }

  onStdOut(chunk: string | Buffer, test?: TestCase, result?: TestResult) {
    this._reporter.onStdOut?.(chunk, test, result);
  }

  onStdErr(chunk: string | Buffer, test?: TestCase, result?: TestResult) {
    this._reporter.onStdErr?.(chunk, test, result);
  }

  async onTestPaused(test: TestCase, result: TestResult) {
    this._addSnippetToTestErrors(test, result);
    return await this._reporter.onTestPaused?.(test, result);
  }

  onTestEnd(test: TestCase, result: TestResult) {
    this._addSnippetToTestErrors(test, result);
    this._reporter.onTestEnd?.(test, result);
  }

  async onEnd(result: { status: FullResult['status'] }) {
    if (!this._didBegin) {
      // onBegin was not reported, emit it.
      this.onBegin(new testNs.Suite('', 'root'));
    }
    return await this._reporter.onEnd?.({
      ...result,
      startTime: this._startTime!,
      duration: monotonicTime() - this._monotonicStartTime!,
    });
  }

  async onExit() {
    await this._reporter.onExit?.();
  }

  onError(error: TestError, workerInfo?: WorkerInfo) {
    addLocationAndSnippetToError(this._config, error);
    this._reporter.onError?.(error, workerInfo);
  }

  onStepBegin(test: TestCase, result: TestResult, step: TestStep) {
    this._reporter.onStepBegin?.(test, result, step);
  }

  onStepEnd(test: TestCase, result: TestResult, step: TestStep) {
    this._addSnippetToStepError(test, step);
    this._reporter.onStepEnd?.(test, result, step);
  }

  printsToStdio() {
    return this._reporter.printsToStdio?.() ?? true;
  }

  private _addSnippetToTestErrors(test: TestCase, result: TestResult) {
    for (const error of result.errors)
      addLocationAndSnippetToError(this._config, error, test.location.file);
  }

  private _addSnippetToStepError(test: TestCase, step: TestStep) {
    if (step.error)
      addLocationAndSnippetToError(this._config, step.error, test.location.file);
  }
}

export function addLocationAndSnippetToError(config: FullConfig, error: TestError, file?: string) {
  if (error.stack && !error.location)
    error.location = prepareErrorStack(error.stack).location;
  const location = error.location;
  if (!location)
    return;

  if (!!error.snippet)
    return;

  try {
    const tokens = [];
    const source = fs.readFileSync(location.file, 'utf8');
    const codeFrame = babel.codeFrameColumns(source, { start: location }, { highlightCode: true });
    // Convert /var/folders to /private/var/folders on Mac.
    if (!file || fs.realpathSync(file) !== location.file) {
      tokens.push(internalScreen.colors.gray(`   at `) + `${relativeFilePath(internalScreen, config, location.file)}:${location.line}`);
      tokens.push('');
    }
    tokens.push(codeFrame);
    error.snippet = tokens.join('\n');
  } catch (e) {
    // Failed to read the source file - that's ok.
  }
}
