/**
 * Copyright Microsoft Corporation. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import 'playwright-core/lib/bootstrap';

import { ManualPromise } from '@isomorphic/manualPromise';
import { setTimeOrigin } from '@isomorphic/time';
import { startProfiling, stopProfiling } from '@utils/profiler';
import { setBoxedStackPrefixes } from '@utils/stackTrace';

import { packageRoot } from '../package';
import { serializeError } from '../util';

import type { EnvProducedPayload, ProcessInitParams, TestInfoErrorPayload } from './ipc';

export type ProtocolRequest = {
  id: number;
  method: string;
  params?: any;
};

export type ProtocolResponse = {
  id?: number;
  error?: TestInfoErrorPayload;
  method?: string;
  params?: any;
  result?: any;
};

export class ProcessRunner {
  async gracefullyClose(): Promise<void> { }

  protected dispatchEvent(method: string, params: any) {
    const response: ProtocolResponse = { method, params };
    sendMessageToParent({ method: '__dispatch__', params: response });
  }

  protected async sendRequest(method: string, params?: any): Promise<any> {
    return await sendRequestToParent(method, params);
  }

  protected async sendMessageNoReply(method: string, params?: any) {
    void sendRequestToParent(method, params).catch(() => {});
  }
}

let gracefullyCloseCalled = false;
let forceExitInitiated = false;

let processRunner: ProcessRunner | undefined;
let processName: string | undefined;
const startingEnv = { ...process.env };
setBoxedStackPrefixes([packageRoot]);

export function startProcessRunner(create: (params: any) => ProcessRunner) {
  sendMessageToParent({ method: 'ready' });

  process.on('disconnect', () => gracefullyCloseAndExit(true));
  process.on('SIGINT', () => {});
  process.on('SIGTERM', () => {});

  process.on('message', async (message: any) => {
    if (message.method === '__init__') {
      const { processParams, runnerParams } = message.params as { processParams: ProcessInitParams, runnerParams: any };
      void startProfiling();
      setTimeOrigin(processParams.timeOrigin);
      processRunner = create(runnerParams);
      processName = processParams.processName;
      return;
    }
    if (message.method === '__stop__') {
      const keys = new Set([...Object.keys(process.env), ...Object.keys(startingEnv)]);
      const producedEnv: EnvProducedPayload = [...keys].filter(key => startingEnv[key] !== process.env[key]).map(key => [key, process.env[key] ?? null]);
      sendMessageToParent({ method: '__env_produced__', params: producedEnv });
      await gracefullyCloseAndExit(false);
      return;
    }
    if (message.method === '__dispatch__') {
      const { id, method, params } = message.params as ProtocolRequest;
      try {
        const result = await (processRunner as any)[method](params);
        const response: ProtocolResponse = { id, result };
        sendMessageToParent({ method: '__dispatch__', params: response });
      } catch (e) {
        const response: ProtocolResponse = { id, error: serializeError(e) };
        sendMessageToParent({ method: '__dispatch__', params: response });
      }
    }
    if (message.method === '__response__')
      handleResponseFromParent(message.params as ProtocolResponse);
  });
}

const kForceExitTimeout = +(process.env.PWTEST_FORCE_EXIT_TIMEOUT || 30000);
const kHeartbeatInterval = 1000;

async function gracefullyCloseAndExit(forceExit: boolean) {
  if (forceExit && !forceExitInitiated) {
    forceExitInitiated = true;
    // Force exit after 30 seconds.
    // eslint-disable-next-line no-restricted-properties
    setTimeout(() => process.exit(0), kForceExitTimeout);
  }
  if (!gracefullyCloseCalled) {
    gracefullyCloseCalled = true;
    // Heartbeats tell the parent that graceful close is still running, e.g. a fixture
    // teardown with "timeout: 0", as opposed to a hung process that must be force-killed.
    const heartbeat = setInterval(() => sendMessageToParent({ method: '__heartbeat__' }), kHeartbeatInterval);
    heartbeat.unref();
    // Meanwhile, try to gracefully shutdown.
    await processRunner?.gracefullyClose().catch(() => {});
    clearInterval(heartbeat);
    if (processName)
      await stopProfiling(processName).catch(() => {});
    // eslint-disable-next-line no-restricted-properties
    process.exit(0);
  }
}

function sendMessageToParent(message: { method: string, params?: any }) {
  try {
    process.send!(message);
  } catch (e) {
    try {
      // By default, the IPC messages are serialized as JSON.
      JSON.stringify(message);
    } catch {
      // Always throw serialization errors.
      throw e;
    }
    // Can throw when closing.
  }
}

let lastId = 0;
const requestCallbacks = new Map<number, ManualPromise<any>>();

async function sendRequestToParent(method: string, params?: any): Promise<any> {
  const id = ++lastId;
  sendMessageToParent({ method: '__request__', params: { id, method, params } });
  const promise = new ManualPromise<any>();
  requestCallbacks.set(id, promise);
  return promise;
}

function handleResponseFromParent(response: ProtocolResponse) {
  const promise = requestCallbacks.get(response.id!);
  if (!promise)
    return;
  requestCallbacks.delete(response.id!);
  if (response.error)
    promise.reject(new Error(response.error.message));
  else
    promise.resolve(response.result);
}
