/*
 * Copyright © 2012 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "blorp_nir_builder.h"
#include "compiler/nir/nir_format_convert.h"

#include "blorp_priv.h"
#include "blorp_shaders.h"
#include "dev/intel_debug.h"
#include "dev/intel_device_info.h"

#include "util/u_math.h"

#define FILE_DEBUG_FLAG DEBUG_BLORP

static const bool split_blorp_blit_debug = false;

#pragma pack(push, 1)
struct blorp_blit_prog_key
{
   struct blorp_base_key base;

   isl_surf_usage_flags_t dst_usage;

   enum isl_aux_usage tex_aux_usage;

   /* Actual number of samples per pixel in the source image. */
   unsigned src_samples;

   /* Actual number of samples per pixel in the destination image. */
   unsigned dst_samples;

   /* Number of samples per pixel that have been configured in the surface
    * state for texturing from.
    */
   unsigned tex_samples;

   /* Number of samples per pixel that have been configured in the render
    * target.
    */
   unsigned rt_samples;

   /* Actual MSAA layout used by the source image. */
   enum isl_msaa_layout src_layout;

   /* Actual MSAA layout used by the destination image. */
   enum isl_msaa_layout dst_layout;

   /* MSAA layout that has been configured in the surface state for texturing
    * from.
    */
   enum isl_msaa_layout tex_layout;

   /* MSAA layout that has been configured in the render target. */
   enum isl_msaa_layout rt_layout;

   /* The swizzle to apply to the source in the shader */
   struct isl_swizzle src_swizzle;

   /* The swizzle to apply to the destination in the shader */
   struct isl_swizzle dst_swizzle;

   /* The format of the source if format-specific workarounds are needed
    * and 0 (ISL_FORMAT_R32G32B32A32_FLOAT) if the destination is natively
    * renderable.
    */
   enum isl_format src_format;

   /* The format of the destination if format-specific workarounds are needed
    * and 0 (ISL_FORMAT_R32G32B32A32_FLOAT) if the destination is natively
    * renderable.
    */
   enum isl_format dst_format;

   enum blorp_filter filter;

   /* Scale factors between the pixel grid and the grid of samples. We're
    * using grid of samples for bilinear filtering in multisample scaled blits.
    */
   float x_scale;
   float y_scale;

   /* If a compute shader is used, this is the local size y dimension.
    */
   uint8_t local_y;

   /* Type of the data to be read from the texture (one of
    * nir_type_(int|uint|float)).
    */
   nir_alu_type texture_data_type;

   /* True if the source requires normalized coordinates */
   bool src_coords_normalized;

   /* Whether or not the format workarounds are a bitcast operation */
   bool format_bit_cast;

   /** True if we need to perform SINT -> UINT clamping. */
   bool sint32_to_uint;

   /** True if we need to perform UINT -> SINT clamping. */
   bool uint32_to_sint;

   /* True if the source image is W tiled.  If true, the surface state for the
    * source image must be configured as Y tiled, and tex_samples must be 0.
    */
   bool src_tiled_w;

   /* True if the destination image is W tiled.  If true, the surface state
    * for the render target must be configured as Y tiled, and rt_samples must
    * be 0.
    */
   bool dst_tiled_w;

   /* True if the destination is an RGB format.  If true, the surface state
    * for the render target must be configured as red with three times the
    * normal width.  We need to do this because you cannot render to
    * non-power-of-two formats.
    */
   bool dst_rgb;

   /* True if the rectangle being sent through the rendering pipeline might be
    * larger than the destination rectangle, so the WM program should kill any
    * pixels that are outside the destination rectangle.
    */
   bool use_kill;

   /**
    * True if the WM program should be run in MSDISPMODE_PERSAMPLE with more
    * than one sample per pixel.
    */
   bool persample_msaa_dispatch;

   /* True if this blit operation may involve intratile offsets on the source.
    * In this case, we need to add the offset before texturing.
    */
   bool need_src_offset;

   /* True if this blit operation is unpacking the last few rows of the 2D image
    * from a 1D buffer. This is part of a workaround for performing buffer-to-image
    * copies when the source is straddling an extra page due to a misaligned cache.
    */
   bool need_src_buffer;

   /* True if this blit operation may involve intratile offsets on the
    * destination.  In this case, we need to add the offset to gl_FragCoord.
    */
   bool need_dst_offset;
};
#pragma pack(pop)

struct blorp_builder {
   const struct blorp_context *blorp;
   const struct blorp_blit_prog_key *key;

   nir_def *surface_states;
   nir_def *sampler_state;

   /* Input values from blorp_wm_inputs */
   nir_variable *v_bounds_rect;
   nir_variable *v_rect_grid;
   nir_variable *v_coord_transform;
   nir_variable *v_src_z;
   nir_variable *v_src_offset;
   nir_variable *v_dst_offset;
   nir_variable *v_src_inv_size;
   nir_variable *v_src_buffer_first_row;
   nir_variable *v_src_buffer_row_pitch;
};

static void
blorp_builder_init(struct blorp_builder *bb,
                   nir_builder *b,
                   const struct blorp_blit_prog_key *key,
                   const struct blorp_context *blorp)
{
   bb->key = key;
   bb->blorp = blorp;

   if (blorp->config.use_efficient_64bit) {
      if (b->shader->info.stage == MESA_SHADER_FRAGMENT) {
         bb->surface_states =
            nir_load_push_data_intel(b, 2, 32, nir_imm_int(b, 0),
                                     .base = 0, .range = 8);
         bb->sampler_state =
            nir_load_push_data_intel(b, 2, 32, nir_imm_int(b, 0),
                                     .base = 8, .range = 8);
      } else {
         bb->surface_states =
            nir_load_inline_data_intel(b, 2, 32, nir_imm_int(b, 0),
                                       .base = BLORP_INLINE_PARAM_SURFACES_LDW, .range = 8);
         bb->sampler_state =
            nir_load_inline_data_intel(b, 2, 32, nir_imm_int(b, 0),
                                       .base = BLORP_INLINE_PARAM_SAMPLER_LDW, .range = 8);
      }
   }

#define LOAD_INPUT(name, type)\
   bb->v_##name = BLORP_CREATE_NIR_INPUT(b->shader, blit.name, type);

   LOAD_INPUT(bounds_rect, glsl_vec4_type())
   LOAD_INPUT(rect_grid, glsl_vec4_type())
   LOAD_INPUT(coord_transform, glsl_vec4_type())
   LOAD_INPUT(src_z, glsl_float_type())
   LOAD_INPUT(src_offset, glsl_vector_type(GLSL_TYPE_UINT, 2))
   LOAD_INPUT(dst_offset, glsl_vector_type(GLSL_TYPE_UINT, 2))
   LOAD_INPUT(src_inv_size, glsl_vector_type(GLSL_TYPE_FLOAT, 2))
   LOAD_INPUT(src_buffer_first_row, glsl_uint_type())
   LOAD_INPUT(src_buffer_row_pitch, glsl_uint_type())

#undef LOAD_INPUT
}

static nir_def *
blorp_blit_get_frag_coords(nir_builder *b, struct blorp_builder *bb)
{
   nir_def *coord = nir_f2i32(b, nir_build_frag_coord(b, 2));

   /* Account for destination surface intratile offset
    *
    * Transformation parameters giving translation from destination to source
    * coordinates don't take into account possible intra-tile destination
    * offset.  Therefore it has to be first subtracted from the incoming
    * coordinates.  Vertices are set up based on coordinates containing the
    * intra-tile offset.
    */
   if (bb->key->need_dst_offset)
      coord = nir_isub(b, coord, nir_load_var(b, bb->v_dst_offset));

   if (bb->key->persample_msaa_dispatch) {
      b->shader->info.fs.uses_sample_shading = true;
      return nir_vec3(b, nir_channel(b, coord, 0), nir_channel(b, coord, 1),
                      nir_load_sample_id(b));
   } else {
      return coord;
   }
}

static nir_def *
blorp_blit_get_cs_dst_coords(nir_builder *b, struct blorp_builder *bb)
{
   nir_def *coord = nir_load_global_invocation_id(b, 32);

   /* Account for destination surface intratile offset
    *
    * Transformation parameters giving translation from destination to source
    * coordinates don't take into account possible intra-tile destination
    * offset.  Therefore it has to be first subtracted from the incoming
    * coordinates.  Vertices are set up based on coordinates containing the
    * intra-tile offset.
    */
   if (bb->key->need_dst_offset)
      coord = nir_isub(b, coord, nir_load_var(b, bb->v_dst_offset));

   assert(bb->blorp->isl_dev->info->ver >= 30 || !bb->key->persample_msaa_dispatch);
   return nir_trim_vector(b, coord, bb->key->dst_samples > 1 ? 3 : 2);
}

/**
 * Emit code to translate from destination (X, Y) coordinates to source (X, Y)
 * coordinates.
 */
static nir_def *
blorp_blit_apply_transform(nir_builder *b, nir_def *src_pos,
                           struct blorp_builder *bb)
{
   nir_def *coord_transform = nir_load_var(b, bb->v_coord_transform);

   nir_def *offset = nir_vec2(b, nir_channel(b, coord_transform, 1),
                                     nir_channel(b, coord_transform, 3));
   nir_def *mul = nir_vec2(b, nir_channel(b, coord_transform, 0),
                                  nir_channel(b, coord_transform, 2));

   return nir_fadd(b, nir_fmul(b, src_pos, mul), offset);
}

static bool
tex_needs_16bits(nir_texop op, struct blorp_builder *bb)
{
   const struct intel_device_info *devinfo = bb->blorp->isl_dev->info;

   return devinfo->verx10 >= 125 &&
      (op == nir_texop_txf_ms ||
       op == nir_texop_txf_ms_mcs_intel);
}

static nir_tex_instr *
blorp_create_nir_tex_instr(nir_builder *b, struct blorp_builder *bb,
                           nir_texop op, nir_def *pos, nir_tex_src src,
                           nir_alu_type dst_type,
                           enum blorp_binding binding)
{
   /* Add 3 sources for : coord, texture & sampler */
   nir_tex_instr *tex = nir_tex_instr_create(
      b->shader, (src.src.ssa != NULL ? 1 : 0) + 3);

   tex->op = op;
   tex->dest_type = dst_type | 32;
   tex->is_array = false;
   tex->is_shadow = false;

   unsigned src_idx = 0;
   if (src.src.ssa != NULL)
      tex->src[src_idx++] = src;
   if (bb->key->base.efficient_64bit) {
      tex->src[src_idx++] = nir_tex_src_for_ssa(
         nir_tex_src_texture_handle,
         nir_vec2(b,
                  nir_iadd_imm(b,
                               nir_channel(b, bb->surface_states, 0),
                               align(bb->blorp->isl_dev->ss.size,
                                     bb->blorp->isl_dev->ss.align) *
                               binding),
                  nir_channel(b, bb->surface_states, 1)));
      tex->src[src_idx++] = nir_tex_src_for_ssa(
         nir_tex_src_sampler_handle,
         bb->sampler_state);
   } else {
      tex->src[src_idx++] = nir_tex_src_for_ssa(
         nir_tex_src_texture_offset,
         nir_imm_int(b, binding));
      tex->src[src_idx++] = nir_tex_src_for_ssa(
         nir_tex_src_sampler_offset,
         nir_imm_int(b, BLORP_SAMPLER_INDEX));
   }

   /* To properly handle 3-D and 2-D array textures, we pull the Z component
    * from an input.  TODO: This is a bit magic; we should probably make this
    * more explicit in the future.
    */
   assert(pos->num_components >= 2);
   if (op == nir_texop_txf || op == nir_texop_txf_ms ||
       op == nir_texop_txf_ms_mcs_intel) {
      pos = nir_vec3(b, nir_channel(b, pos, 0), nir_channel(b, pos, 1),
                        nir_f2i32(b, nir_load_var(b, bb->v_src_z)));
   } else {
      pos = nir_vec3(b, nir_channel(b, pos, 0), nir_channel(b, pos, 1),
                        nir_load_var(b, bb->v_src_z));
   }

   tex->src[src_idx++] = nir_tex_src_for_ssa(
      nir_tex_src_coord,
      tex_needs_16bits(op, bb) ? nir_u2u16(b, pos) : pos);
   tex->coord_components = 3;

   nir_def_init(&tex->instr, &tex->def, 4, 32);
   nir_builder_instr_insert(b, &tex->instr);

   return tex;
}

static nir_def *
blorp_nir_tex(nir_builder *b, struct blorp_builder *bb, nir_def *pos)
{
   if (bb->key->need_src_offset)
      pos = nir_fadd(b, pos, nir_i2f32(b, nir_load_var(b, bb->v_src_offset)));

   /* If the sampler requires normalized coordinates, we need to compensate. */
   if (bb->key->src_coords_normalized)
      pos = nir_fmul(b, pos, nir_load_var(b, bb->v_src_inv_size));

   nir_tex_instr *tex = blorp_create_nir_tex_instr(
      b, bb, nir_texop_txl, pos,
      nir_tex_src_for_ssa(nir_tex_src_lod,
                          nir_imm_intN_t(b, 0, tex_needs_16bits(nir_texop_txl, bb) ? 16 : 32)),
      bb->key->texture_data_type,
      BLORP_TEXTURE_BT_INDEX);

   assert(pos->num_components == 2);
   tex->sampler_dim = GLSL_SAMPLER_DIM_2D;

   return &tex->def;
}

static nir_def *
blorp_nir_txf(nir_builder *b, struct blorp_builder *bb,
              nir_def *pos, nir_alu_type dst_type)
{
   nir_tex_instr *tex = blorp_create_nir_tex_instr(
      b, bb, nir_texop_txf, pos,
      nir_tex_src_for_ssa(nir_tex_src_lod, nir_imm_int(b, 0)),
      dst_type, BLORP_TEXTURE_BT_INDEX);

   tex->sampler_dim = GLSL_SAMPLER_DIM_3D;

   return &tex->def;
}

/* Same as blorp_nir_txf, except the last few rows may be loaded from a texel
 * buffer bound to BLORP_TEXBUF_BT_INDEX instead to avoid page faults due to
 * an unaligned source.
 */
static nir_def *
blorp_nir_txf_buf(nir_builder *b, struct blorp_builder *bb,
                  nir_def *pos, nir_alu_type dst_type)
{
   nir_def *buf_start = nir_load_var(b, bb->v_src_buffer_first_row);

   /* Just use if statements, non uniform texture access is expensive */
   nir_def *tex;
   nir_tex_instr *buf;
   nir_push_if(b, nir_ilt(b, nir_channel(b, pos, 1), buf_start));
   {
      tex = blorp_nir_txf(b, bb, pos, dst_type);
   }
   nir_push_else(b, NULL);
   {
      /* Get the offset into the buffer if we're beyond src_buffer_first_row */
      pos = nir_vec2(b,
                     nir_iadd(b,
                              nir_imul(b,
                                       nir_isub(b,
                                                nir_channel(b, pos, 1),
                                                buf_start),
                                    nir_load_var(b, bb->v_src_buffer_row_pitch)),
                              nir_channel(b, pos, 0)),
                     nir_imm_int(b, 0));

      buf = blorp_create_nir_tex_instr(b, bb, nir_texop_txf, pos,
                                       (nir_tex_src) {},
                                       dst_type, BLORP_TEXBUF_BT_INDEX);

      buf->sampler_dim = GLSL_SAMPLER_DIM_BUF;
   }
   nir_pop_if(b, NULL);
   return nir_if_phi(b, tex, &buf->def);
}

static nir_def *
blorp_nir_txf_ms(nir_builder *b, struct blorp_builder *bb,
                 nir_def *pos, nir_alu_type dst_type)
{
   const unsigned bit_size = tex_needs_16bits(nir_texop_txf_ms, bb) ? 16 : 32;
   nir_tex_instr *tex = blorp_create_nir_tex_instr(
      b, bb, nir_texop_txf_ms, pos,
      nir_tex_src_for_ssa(
         nir_tex_src_ms_index,
         pos->num_components == 2 ?
         nir_imm_intN_t(b, 0, bit_size) :
         nir_u2uN(b, nir_channel(b, pos, 2), bit_size)),
      dst_type, BLORP_TEXTURE_BT_INDEX);

   tex->sampler_dim = GLSL_SAMPLER_DIM_MS;

   return &tex->def;
}

static nir_def *
blorp_blit_txf_ms_mcs(nir_builder *b, struct blorp_builder *bb, nir_def *pos)
{
   nir_tex_instr *tex = blorp_create_nir_tex_instr(
      b, bb, nir_texop_txf_ms_mcs_intel, pos,
      (nir_tex_src) {}, nir_type_int, BLORP_TEXTURE_BT_INDEX);

   tex->sampler_dim = GLSL_SAMPLER_DIM_MS;

   return &tex->def;
}

/**
 * Emit code to compensate for the difference between Y and W tiling.
 *
 * This code modifies the X and Y coordinates according to the formula:
 *
 *   (X', Y', S') = detile(W-MAJOR, tile(Y-MAJOR, X, Y, S))
 *
 * (See blorp_build_nir_shader).
 */
static inline nir_def *
blorp_nir_retile_y_to_w(nir_builder *b, nir_def *pos)
{
   assert(pos->num_components == 2);
   nir_def *x_Y = nir_channel(b, pos, 0);
   nir_def *y_Y = nir_channel(b, pos, 1);

   /* Given X and Y coordinates that describe an address using Y tiling,
    * translate to the X and Y coordinates that describe the same address
    * using W tiling.
    *
    * If we break down the low order bits of X and Y, using a
    * single letter to represent each low-order bit:
    *
    *   X = A << 7 | 0bBCDEFGH
    *   Y = J << 5 | 0bKLMNP                                       (1)
    *
    * Then we can apply the Y tiling formula to see the memory offset being
    * addressed:
    *
    *   offset = (J * tile_pitch + A) << 12 | 0bBCDKLMNPEFGH       (2)
    *
    * If we apply the W detiling formula to this memory location, that the
    * corresponding X' and Y' coordinates are:
    *
    *   X' = A << 6 | 0bBCDPFH                                     (3)
    *   Y' = J << 6 | 0bKLMNEG
    *
    * Combining (1) and (3), we see that to transform (X, Y) to (X', Y'),
    * we need to make the following computation:
    *
    *   X' = (X & ~0b1011) >> 1 | (Y & 0b1) << 2 | X & 0b1         (4)
    *   Y' = (Y & ~0b1) << 1 | (X & 0b1000) >> 2 | (X & 0b10) >> 1
    */
   nir_def *x_W = nir_imm_int(b, 0);
   x_W = nir_mask_shift_or(b, x_W, x_Y, 0xfffffff4, -1);
   x_W = nir_mask_shift_or(b, x_W, y_Y, 0x1, 2);
   x_W = nir_mask_shift_or(b, x_W, x_Y, 0x1, 0);

   nir_def *y_W = nir_imm_int(b, 0);
   y_W = nir_mask_shift_or(b, y_W, y_Y, 0xfffffffe, 1);
   y_W = nir_mask_shift_or(b, y_W, x_Y, 0x8, -2);
   y_W = nir_mask_shift_or(b, y_W, x_Y, 0x2, -1);

   return nir_vec2(b, x_W, y_W);
}

/**
 * Emit code to compensate for the difference between Y and W tiling.
 *
 * This code modifies the X and Y coordinates according to the formula:
 *
 *   (X', Y', S') = detile(Y-MAJOR, tile(W-MAJOR, X, Y, S))
 *
 * (See blorp_build_nir_shader).
 */
static inline nir_def *
blorp_nir_retile_w_to_y(nir_builder *b, nir_def *pos)
{
   assert(pos->num_components == 2);
   nir_def *x_W = nir_channel(b, pos, 0);
   nir_def *y_W = nir_channel(b, pos, 1);

   /* Applying the same logic as above, but in reverse, we obtain the
    * formulas:
    *
    * X' = (X & ~0b101) << 1 | (Y & 0b10) << 2 | (Y & 0b1) << 1 | X & 0b1
    * Y' = (Y & ~0b11) >> 1 | (X & 0b100) >> 2
    */
   nir_def *x_Y = nir_imm_int(b, 0);
   x_Y = nir_mask_shift_or(b, x_Y, x_W, 0xfffffffa, 1);
   x_Y = nir_mask_shift_or(b, x_Y, y_W, 0x2, 2);
   x_Y = nir_mask_shift_or(b, x_Y, y_W, 0x1, 1);
   x_Y = nir_mask_shift_or(b, x_Y, x_W, 0x1, 0);

   nir_def *y_Y = nir_imm_int(b, 0);
   y_Y = nir_mask_shift_or(b, y_Y, y_W, 0xfffffffc, -1);
   y_Y = nir_mask_shift_or(b, y_Y, x_W, 0x4, -2);

   return nir_vec2(b, x_Y, y_Y);
}

/**
 * Emit code to compensate for the difference between MSAA and non-MSAA
 * surfaces.
 *
 * This code modifies the X and Y coordinates according to the formula:
 *
 *   (X', Y', S') = encode_msaa(num_samples, IMS, X, Y, S)
 */
static inline nir_def *
blorp_nir_encode_msaa(nir_builder *b, nir_def *pos,
                      unsigned num_samples, enum isl_msaa_layout layout)
{
   assert(pos->num_components == 2 || pos->num_components == 3);

   switch (layout) {
   case ISL_MSAA_LAYOUT_NONE:
      assert(pos->num_components == 2);
      return pos;
   case ISL_MSAA_LAYOUT_ARRAY:
      /* No translation needed */
      return pos;
   case ISL_MSAA_LAYOUT_INTERLEAVED: {
      nir_def *x_in = nir_channel(b, pos, 0);
      nir_def *y_in = nir_channel(b, pos, 1);
      nir_def *s_in = pos->num_components == 2 ? nir_imm_int(b, 0) :
                                                     nir_channel(b, pos, 2);

      nir_def *x_out = nir_imm_int(b, 0);
      nir_def *y_out = nir_imm_int(b, 0);
      switch (num_samples) {
      case 2:
      case 4:
         /* encode_msaa(2, IMS, X, Y, S) = (X', Y', 0)
          *   where X' = (X & ~0b1) << 1 | (S & 0b1) << 1 | (X & 0b1)
          *         Y' = Y
          *
          * encode_msaa(4, IMS, X, Y, S) = (X', Y', 0)
          *   where X' = (X & ~0b1) << 1 | (S & 0b1) << 1 | (X & 0b1)
          *         Y' = (Y & ~0b1) << 1 | (S & 0b10) | (Y & 0b1)
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffffe, 1);
         x_out = nir_mask_shift_or(b, x_out, s_in, 0x1, 1);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         if (num_samples == 2) {
            y_out = y_in;
         } else {
            y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffffe, 1);
            y_out = nir_mask_shift_or(b, y_out, s_in, 0x2, 0);
            y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
         }
         break;

      case 8:
         /* encode_msaa(8, IMS, X, Y, S) = (X', Y', 0)
          *   where X' = (X & ~0b1) << 2 | (S & 0b100) | (S & 0b1) << 1
          *              | (X & 0b1)
          *         Y' = (Y & ~0b1) << 1 | (S & 0b10) | (Y & 0b1)
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffffe, 2);
         x_out = nir_mask_shift_or(b, x_out, s_in, 0x4, 0);
         x_out = nir_mask_shift_or(b, x_out, s_in, 0x1, 1);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffffe, 1);
         y_out = nir_mask_shift_or(b, y_out, s_in, 0x2, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
         break;

      case 16:
         /* encode_msaa(16, IMS, X, Y, S) = (X', Y', 0)
          *   where X' = (X & ~0b1) << 2 | (S & 0b100) | (S & 0b1) << 1
          *              | (X & 0b1)
          *         Y' = (Y & ~0b1) << 2 | (S & 0b1000) >> 1 (S & 0b10)
          *              | (Y & 0b1)
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffffe, 2);
         x_out = nir_mask_shift_or(b, x_out, s_in, 0x4, 0);
         x_out = nir_mask_shift_or(b, x_out, s_in, 0x1, 1);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffffe, 2);
         y_out = nir_mask_shift_or(b, y_out, s_in, 0x8, -1);
         y_out = nir_mask_shift_or(b, y_out, s_in, 0x2, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
         break;

      default:
         UNREACHABLE("Invalid number of samples for IMS layout");
      }

      return nir_vec2(b, x_out, y_out);
   }

   default:
      UNREACHABLE("Invalid MSAA layout");
   }
}

/**
 * Emit code to compensate for the difference between MSAA and non-MSAA
 * surfaces.
 *
 * This code modifies the X and Y coordinates according to the formula:
 *
 *   (X', Y', S) = decode_msaa(num_samples, IMS, X, Y, S)
 */
static inline nir_def *
blorp_nir_decode_msaa(nir_builder *b, nir_def *pos,
                      unsigned num_samples, enum isl_msaa_layout layout)
{
   assert(pos->num_components == 2 || pos->num_components == 3);

   switch (layout) {
   case ISL_MSAA_LAYOUT_NONE:
      /* No translation necessary, and S should already be zero. */
      assert(pos->num_components == 2);
      return pos;
   case ISL_MSAA_LAYOUT_ARRAY:
      /* No translation necessary. */
      return pos;
   case ISL_MSAA_LAYOUT_INTERLEAVED: {
      assert(pos->num_components == 2);

      nir_def *x_in = nir_channel(b, pos, 0);
      nir_def *y_in = nir_channel(b, pos, 1);

      nir_def *x_out = nir_imm_int(b, 0);
      nir_def *y_out = nir_imm_int(b, 0);
      nir_def *s_out = nir_imm_int(b, 0);
      switch (num_samples) {
      case 2:
      case 4:
         /* decode_msaa(2, IMS, X, Y, 0) = (X', Y', S)
          *   where X' = (X & ~0b11) >> 1 | (X & 0b1)
          *         S = (X & 0b10) >> 1
          *
          * decode_msaa(4, IMS, X, Y, 0) = (X', Y', S)
          *   where X' = (X & ~0b11) >> 1 | (X & 0b1)
          *         Y' = (Y & ~0b11) >> 1 | (Y & 0b1)
          *         S = (Y & 0b10) | (X & 0b10) >> 1
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffffc, -1);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         if (num_samples == 2) {
            y_out = y_in;
            s_out = nir_mask_shift_or(b, s_out, x_in, 0x2, -1);
         } else {
            y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffffc, -1);
            y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
            s_out = nir_mask_shift_or(b, s_out, x_in, 0x2, -1);
            s_out = nir_mask_shift_or(b, s_out, y_in, 0x2, 0);
         }
         break;

      case 8:
         /* decode_msaa(8, IMS, X, Y, 0) = (X', Y', S)
          *   where X' = (X & ~0b111) >> 2 | (X & 0b1)
          *         Y' = (Y & ~0b11) >> 1 | (Y & 0b1)
          *         S = (X & 0b100) | (Y & 0b10) | (X & 0b10) >> 1
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffff8, -2);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffffc, -1);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
         s_out = nir_mask_shift_or(b, s_out, x_in, 0x4, 0);
         s_out = nir_mask_shift_or(b, s_out, y_in, 0x2, 0);
         s_out = nir_mask_shift_or(b, s_out, x_in, 0x2, -1);
         break;

      case 16:
         /* decode_msaa(16, IMS, X, Y, 0) = (X', Y', S)
          *   where X' = (X & ~0b111) >> 2 | (X & 0b1)
          *         Y' = (Y & ~0b111) >> 2 | (Y & 0b1)
          *         S = (Y & 0b100) << 1 | (X & 0b100) |
          *             (Y & 0b10) | (X & 0b10) >> 1
          */
         x_out = nir_mask_shift_or(b, x_out, x_in, 0xfffffff8, -2);
         x_out = nir_mask_shift_or(b, x_out, x_in, 0x1, 0);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0xfffffff8, -2);
         y_out = nir_mask_shift_or(b, y_out, y_in, 0x1, 0);
         s_out = nir_mask_shift_or(b, s_out, y_in, 0x4, 1);
         s_out = nir_mask_shift_or(b, s_out, x_in, 0x4, 0);
         s_out = nir_mask_shift_or(b, s_out, y_in, 0x2, 0);
         s_out = nir_mask_shift_or(b, s_out, x_in, 0x2, -1);
         break;

      default:
         UNREACHABLE("Invalid number of samples for IMS layout");
      }

      return nir_vec3(b, x_out, y_out, s_out);
   }

   default:
      UNREACHABLE("Invalid MSAA layout");
   }
}

/**
 * Count the number of trailing 1 bits in the given value.  For example:
 *
 * count_trailing_one_bits(0) == 0
 * count_trailing_one_bits(7) == 3
 * count_trailing_one_bits(11) == 2
 */
static inline int count_trailing_one_bits(unsigned value)
{
#ifdef HAVE___BUILTIN_CTZ
   return __builtin_ctz(~value);
#else
   return util_bitcount(value & ~(value + 1));
#endif
}

static nir_def *
blorp_nir_combine_samples(nir_builder *b, struct blorp_builder *bb,
                          nir_def *pos, unsigned tex_samples,
                          enum isl_aux_usage tex_aux_usage,
                          nir_alu_type dst_type,
                          enum blorp_filter filter)
{
   nir_variable *color =
      nir_local_variable_create(b->impl, glsl_vec4_type(), "color");

   nir_def *mcs = NULL;
   if (isl_aux_usage_has_mcs(tex_aux_usage))
      mcs = blorp_blit_txf_ms_mcs(b, bb, pos);

   nir_op combine_op;
   switch (filter) {
   case BLORP_FILTER_AVERAGE:
      assert(dst_type == nir_type_float);
      combine_op = nir_op_fadd;
      break;

   case BLORP_FILTER_MIN_SAMPLE:
      switch (dst_type) {
      case nir_type_int:   combine_op = nir_op_imin;  break;
      case nir_type_uint:  combine_op = nir_op_umin;  break;
      case nir_type_float: combine_op = nir_op_fmin;  break;
      default: UNREACHABLE("Invalid dst_type");
      }
      break;

   case BLORP_FILTER_MAX_SAMPLE:
      switch (dst_type) {
      case nir_type_int:   combine_op = nir_op_imax;  break;
      case nir_type_uint:  combine_op = nir_op_umax;  break;
      case nir_type_float: combine_op = nir_op_fmax;  break;
      default: UNREACHABLE("Invalid dst_type");
      }
      break;

   default:
      UNREACHABLE("Invalid filter");
   }

   /* If true, we inserted an if statement that we need to pop at at the end.
    */
   bool inserted_if = false;

   /* We add together samples using a binary tree structure, e.g. for 4x MSAA:
    *
    *   result = ((sample[0] + sample[1]) + (sample[2] + sample[3])) / 4
    *
    * This ensures that when all samples have the same value, no numerical
    * precision is lost, since each addition operation always adds two equal
    * values, and summing two equal floating point values does not lose
    * precision.
    *
    * We perform this computation by treating the texture_data array as a
    * stack and performing the following operations:
    *
    * - push sample 0 onto stack
    * - push sample 1 onto stack
    * - add top two stack entries
    * - push sample 2 onto stack
    * - push sample 3 onto stack
    * - add top two stack entries
    * - add top two stack entries
    * - divide top stack entry by 4
    *
    * Note that after pushing sample i onto the stack, the number of add
    * operations we do is equal to the number of trailing 1 bits in i.  This
    * works provided the total number of samples is a power of two, which it
    * always is for i965.
    *
    * For integer formats, we replace the add operations with average
    * operations and skip the final division.
    */
   nir_def *texture_data[5];
   texture_data[0] = NULL; /* Avoid maybe-uninitialized warning with GCC 10 */
   unsigned stack_depth = 0;
   for (unsigned i = 0; i < tex_samples; ++i) {
      assert(stack_depth == util_bitcount(i)); /* Loop invariant */

      /* Push sample i onto the stack */
      assert(stack_depth < ARRAY_SIZE(texture_data));

      nir_def *ms_pos = nir_vec3(b, nir_channel(b, pos, 0),
                                        nir_channel(b, pos, 1),
                                        nir_imm_int(b, i));
      texture_data[stack_depth++] = blorp_nir_txf_ms(b, bb, ms_pos, dst_type);

      if (i == 0 && isl_aux_usage_has_mcs(tex_aux_usage)) {
         /* The Ivy Bridge PRM, Vol4 Part1 p27 (Multisample Control Surface)
          * suggests an optimization:
          *
          *     "A simple optimization with probable large return in
          *     performance is to compare the MCS value to zero (indicating
          *     all samples are on sample slice 0), and sample only from
          *     sample slice 0 using ld2dss if MCS is zero."
          *
          * Note that in the case where the MCS value is zero, sampling from
          * sample slice 0 using ld2dss and sampling from sample 0 using
          * ld2dms are equivalent (since all samples are on sample slice 0).
          * Since we have already sampled from sample 0, all we need to do is
          * skip the remaining fetches and averaging if MCS is zero.
          *
          * It's also trivial to detect when the MCS has the magic clear color
          * value.  In this case, the txf we did on sample 0 will return the
          * clear color and we can skip the remaining fetches just like we do
          * when MCS == 0.
          */
         nir_def *mcs_zero = nir_ieq_imm(b, nir_channel(b, mcs, 0), 0);
         if (tex_samples == 16) {
            mcs_zero = nir_iand(b, mcs_zero,
               nir_ieq_imm(b, nir_channel(b, mcs, 1), 0));
         }
         nir_def *mcs_clear =
            blorp_nir_mcs_is_clear_color(b, mcs, tex_samples);

         nir_push_if(b, nir_ior(b, mcs_zero, mcs_clear));
         nir_store_var(b, color, texture_data[0], 0xf);

         nir_push_else(b, NULL);
         inserted_if = true;
      }

      for (int j = 0; j < count_trailing_one_bits(i); j++) {
         assert(stack_depth >= 2);
         --stack_depth;

         texture_data[stack_depth - 1] =
            nir_build_alu(b, combine_op,
                             texture_data[stack_depth - 1],
                             texture_data[stack_depth],
                             NULL, NULL);
      }
   }

   /* We should have just 1 sample on the stack now. */
   assert(stack_depth == 1);

   if (filter == BLORP_FILTER_AVERAGE) {
      assert(dst_type == nir_type_float);
      texture_data[0] = nir_fmul_imm(b, texture_data[0],
                                     1.0 / tex_samples);
   }

   nir_store_var(b, color, texture_data[0], 0xf);

   if (inserted_if)
      nir_pop_if(b, NULL);

   return nir_load_var(b, color);
}

static nir_def *
blorp_nir_manual_blend_bilinear(nir_builder *b, nir_def *pos,
                                unsigned tex_samples,
                                struct blorp_builder *bb)
{
   nir_def *pos_xy = nir_trim_vector(b, pos, 2);
   nir_def *rect_grid = nir_load_var(b, bb->v_rect_grid);
   nir_def *scale = nir_imm_vec2(b, bb->key->x_scale, bb->key->y_scale);

   /* Translate coordinates to lay out the samples in a rectangular  grid
    * roughly corresponding to sample locations.
    */
   pos_xy = nir_fmul(b, pos_xy, scale);
   /* Adjust coordinates so that integers represent pixel centers rather
    * than pixel edges.
    */
   pos_xy = nir_fadd_imm(b, pos_xy, -0.5);
   /* Clamp the X, Y texture coordinates to properly handle the sampling of
    * texels on texture edges.
    */
   pos_xy = nir_fmin(b, nir_fmax(b, pos_xy, nir_imm_float(b, 0.0)),
                        nir_trim_vector(b, rect_grid, 2));

   /* Store the fractional parts to be used as bilinear interpolation
    * coefficients.
    */
   nir_def *frac_xy = nir_ffract(b, pos_xy);
   /* Round the float coordinates down to nearest integer */
   pos_xy = nir_fdiv(b, nir_ftrunc(b, pos_xy), scale);

   nir_def *tex_data[4];
   for (unsigned i = 0; i < 4; ++i) {
      float sample_off_x = (float)(i & 0x1) / bb->key->x_scale;
      float sample_off_y = (float)((i >> 1) & 0x1) / bb->key->y_scale;
      nir_def *sample_off = nir_imm_vec2(b, sample_off_x, sample_off_y);

      nir_def *sample_coords = nir_fadd(b, pos_xy, sample_off);
      nir_def *sample_coords_int = nir_f2i32(b, sample_coords);

      /* Compute sample index and map the sample index to a sample number.
       * Sample index layout shows the numbering of slots in a rectangular
       * grid of samples with in a pixel. Sample number layout shows the
       * rectangular grid of samples roughly corresponding to the real sample
       * locations with in a pixel.
       *
       * In the case of 2x MSAA, the layout of sample indices is reversed from
       * the layout of sample numbers:
       *
       * sample index layout :  ---------    sample number layout :  ---------
       *                        | 0 | 1 |                            | 1 | 0 |
       *                        ---------                            ---------
       *
       * In case of 4x MSAA, layout of sample indices matches the layout of
       * sample numbers:
       *           ---------
       *           | 0 | 1 |
       *           ---------
       *           | 2 | 3 |
       *           ---------
       *
       * In case of 8x MSAA the two layouts don't match.
       * sample index layout :  ---------    sample number layout :  ---------
       *                        | 0 | 1 |                            | 3 | 7 |
       *                        ---------                            ---------
       *                        | 2 | 3 |                            | 5 | 0 |
       *                        ---------                            ---------
       *                        | 4 | 5 |                            | 1 | 2 |
       *                        ---------                            ---------
       *                        | 6 | 7 |                            | 4 | 6 |
       *                        ---------                            ---------
       *
       * Fortunately, this can be done fairly easily as:
       * S' = (0x17306425 >> (S * 4)) & 0xf
       *
       * In the case of 16x MSAA the two layouts don't match.
       * Sample index layout:                Sample number layout:
       * ---------------------               ---------------------
       * |  0 |  1 |  2 |  3 |               | 15 | 10 |  9 |  7 |
       * ---------------------               ---------------------
       * |  4 |  5 |  6 |  7 |               |  4 |  1 |  3 | 13 |
       * ---------------------               ---------------------
       * |  8 |  9 | 10 | 11 |               | 12 |  2 |  0 |  6 |
       * ---------------------               ---------------------
       * | 12 | 13 | 14 | 15 |               | 11 |  8 |  5 | 14 |
       * ---------------------               ---------------------
       *
       * This is equivalent to
       * S' = (0xe58b602cd31479af >> (S * 4)) & 0xf
       */
      nir_def *frac = nir_ffract(b, sample_coords);
      nir_def *sample =
         nir_fdot2(b, frac, nir_imm_vec2(b, bb->key->x_scale,
                                            bb->key->x_scale * bb->key->y_scale));
      sample = nir_f2i32(b, sample);

      if (tex_samples == 2) {
         sample = nir_isub_imm(b, 1, sample);
      } else if (tex_samples == 8) {
         sample = nir_iand_imm(b, nir_ishr(b, nir_imm_int(b, 0x64210573),
                                           nir_ishl_imm(b, sample, 2)),
                               0xf);
      } else if (tex_samples == 16) {
         nir_def *sample_low =
            nir_iand_imm(b, nir_ishr(b, nir_imm_int(b, 0xd31479af),
                                     nir_ishl_imm(b, sample, 2)),
                         0xf);
         nir_def *sample_high =
            nir_iand_imm(b, nir_ishr(b, nir_imm_int(b, 0xe58b602c),
                                     nir_ishl_imm(b, nir_iadd_imm(b, sample, -8),
                                                  2)),
                         0xf);

         sample = nir_bcsel(b, nir_ilt_imm(b, sample, 8),
                            sample_low, sample_high);
      }
      nir_def *pos_ms = nir_vec3(b, nir_channel(b, sample_coords_int, 0),
                                        nir_channel(b, sample_coords_int, 1),
                                        sample);
      tex_data[i] = blorp_nir_txf_ms(b, bb, pos_ms, bb->key->texture_data_type);
   }

   nir_def *frac_x = nir_channel(b, frac_xy, 0);
   nir_def *frac_y = nir_channel(b, frac_xy, 1);
   return nir_flrp(b, nir_flrp(b, tex_data[0], tex_data[1], frac_x),
                      nir_flrp(b, tex_data[2], tex_data[3], frac_x),
                      frac_y);
}

/** Perform a color bit-cast operation
 *
 * For copy operations involving CCS, we may need to use different formats for
 * the source and destination surfaces.  The two formats must both be UINT
 * formats and must have the same size but may have different bit layouts.
 * For instance, we may be copying from R8G8B8A8_UINT to R32_UINT or R32_UINT
 * to R16G16_UINT.  This function generates code to shuffle bits around to get
 * us from one to the other.
 */
static nir_def *
bit_cast_color(struct nir_builder *b, nir_def *color,
               const struct blorp_blit_prog_key *key)
{
   if (key->src_format == key->dst_format)
      return color;

   const struct isl_format_layout *src_fmtl =
      isl_format_get_layout(key->src_format);
   const struct isl_format_layout *dst_fmtl =
      isl_format_get_layout(key->dst_format);

   /* They must be formats with the same bit size */
   assert(src_fmtl->bpb == dst_fmtl->bpb);

   if (src_fmtl->bpb <= 32) {
      assert(src_fmtl->uniform_channel_type == ISL_UINT ||
             src_fmtl->uniform_channel_type == ISL_UNORM);
      assert(dst_fmtl->uniform_channel_type == ISL_UINT ||
             dst_fmtl->uniform_channel_type == ISL_UNORM);

      nir_def *packed = nir_imm_int(b, 0);
      for (unsigned c = 0; c < 4; c++) {
         if (src_fmtl->channels_array[c].bits == 0)
            continue;

         const unsigned chan_start_bit = src_fmtl->channels_array[c].start_bit;
         const unsigned chan_bits = src_fmtl->channels_array[c].bits;

         nir_def *chan =  nir_channel(b, color, c);
         if (src_fmtl->channels_array[c].type == ISL_UNORM) {

            /* Don't touch the alpha channel */
            if (c < 3 && src_fmtl->colorspace == ISL_COLORSPACE_SRGB)
               chan = nir_format_linear_to_srgb(b, chan);

            chan = nir_format_float_to_unorm(b, chan, &chan_bits);
         }

         packed = nir_ior(b, packed, nir_shift_imm(b, chan, chan_start_bit));
      }

      nir_def *chans[4] = { };
      for (unsigned c = 0; c < 4; c++) {
         if (dst_fmtl->channels_array[c].bits == 0) {
            chans[c] = nir_imm_int(b, 0);
            continue;
         }

         const unsigned chan_start_bit = dst_fmtl->channels_array[c].start_bit;
         const unsigned chan_bits = dst_fmtl->channels_array[c].bits;
         chans[c] = nir_iand_imm(b, nir_shift_imm(b, packed, -(int)chan_start_bit),
                                    BITFIELD_MASK(chan_bits));

         if (dst_fmtl->channels_array[c].type == ISL_UNORM) {
            chans[c] =
               dst_fmtl->format == ISL_FORMAT_R24_UNORM_X8_TYPELESS ?
               nir_format_unorm_to_float_precise(b, chans[c], &chan_bits) :
               nir_format_unorm_to_float(b, chans[c], &chan_bits);

            /* Don't touch the alpha channel */
            if (c < 3 && dst_fmtl->colorspace == ISL_COLORSPACE_SRGB)
               chans[c] = nir_format_srgb_to_linear(b, chans[c]);
         }
      }
      color = nir_vec(b, chans, 4);
   } else {
      /* This path only supports UINT formats */
      assert(src_fmtl->channels.r.type == ISL_UINT);
      assert(dst_fmtl->channels.r.type == ISL_UINT);

      const unsigned src_bpc = src_fmtl->channels.r.bits;
      const unsigned dst_bpc = dst_fmtl->channels.r.bits;

      assert(src_fmtl->channels.g.bits == 0 ||
             src_fmtl->channels.g.bits == src_fmtl->channels.r.bits);
      assert(src_fmtl->channels.b.bits == 0 ||
             src_fmtl->channels.b.bits == src_fmtl->channels.r.bits);
      assert(src_fmtl->channels.a.bits == 0 ||
             src_fmtl->channels.a.bits == src_fmtl->channels.r.bits);
      assert(dst_fmtl->channels.g.bits == 0 ||
             dst_fmtl->channels.g.bits == dst_fmtl->channels.r.bits);
      assert(dst_fmtl->channels.b.bits == 0 ||
             dst_fmtl->channels.b.bits == dst_fmtl->channels.r.bits);
      assert(dst_fmtl->channels.a.bits == 0 ||
             dst_fmtl->channels.a.bits == dst_fmtl->channels.r.bits);

      /* Restrict to only the channels we actually have */
      const unsigned src_channels =
         isl_format_get_num_channels(key->src_format);
      color = nir_trim_vector(b, color, src_channels);

      color = nir_format_bitcast_uvec_unmasked(b, color, src_bpc, dst_bpc);
   }

   /* Blorp likes to assume that colors are vec4s */
   nir_def *u = nir_undef(b, 1, 32);
   nir_def *chans[4] = { u, u, u, u };
   for (unsigned i = 0; i < color->num_components; i++)
      chans[i] = nir_channel(b, color, i);
   return nir_vec4(b, chans[0], chans[1], chans[2], chans[3]);
}

static nir_def *
select_color_channel(struct nir_builder *b, nir_def *color,
                     nir_alu_type data_type,
                     enum isl_channel_select chan)
{
   if (chan == ISL_CHANNEL_SELECT_ZERO) {
      return nir_imm_int(b, 0);
   } else if (chan == ISL_CHANNEL_SELECT_ONE) {
      switch (data_type) {
      case nir_type_int:
      case nir_type_uint:
         return nir_imm_int(b, 1);
      case nir_type_float:
         return nir_imm_float(b, 1);
      default:
         UNREACHABLE("Invalid data type");
      }
   } else {
      assert((unsigned)(chan - ISL_CHANNEL_SELECT_RED) < 4);
      return nir_channel(b, color, chan - ISL_CHANNEL_SELECT_RED);
   }
}

static nir_def *
swizzle_color(struct nir_builder *b, nir_def *color,
              struct isl_swizzle swizzle, nir_alu_type data_type)
{
   return nir_vec4(b,
                   select_color_channel(b, color, data_type, swizzle.r),
                   select_color_channel(b, color, data_type, swizzle.g),
                   select_color_channel(b, color, data_type, swizzle.b),
                   select_color_channel(b, color, data_type, swizzle.a));
}

static nir_def *
convert_color(struct nir_builder *b, nir_def *color,
              const struct blorp_blit_prog_key *key)
{
   /* All of our color conversions end up generating a single-channel color
    * value that we need to write out.
    */
   nir_def *value;

   if (key->dst_format == ISL_FORMAT_R24_UNORM_X8_TYPELESS) {
      /* The destination image is bound as R32_UINT but the data needs to be
       * in R24_UNORM_X8_TYPELESS.  The bottom 24 are the actual data and the
       * top 8 need to be zero.  We can accomplish this by simply multiplying
       * by a factor to scale things down.
       */
      unsigned factor = (1 << 24) - 1;
      value = nir_fsat(b, nir_channel(b, color, 0));
      value = nir_f2i32(b, nir_fmul_imm(b, value, factor));
   } else if (key->dst_format == ISL_FORMAT_L8_UNORM_SRGB) {
      value = nir_format_linear_to_srgb(b, nir_channel(b, color, 0));
   } else if (key->dst_format == ISL_FORMAT_R8G8B8_UNORM_SRGB) {
      value = nir_format_linear_to_srgb(b, color);
   } else if (key->dst_format == ISL_FORMAT_R9G9B9E5_SHAREDEXP) {
      value = nir_format_pack_r9g9b9e5(b, color);
   } else {
      UNREACHABLE("Unsupported format conversion");
   }

   nir_def *out_comps[4];
   for (unsigned i = 0; i < 4; i++) {
      if (i < value->num_components)
         out_comps[i] = nir_channel(b, value, i);
      else
         out_comps[i] = nir_undef(b, 1, 32);
   }
   return nir_vec(b, out_comps, 4);
}

/**
 * Generator for WM programs used in BLORP blits.
 *
 * The bulk of the work done by the WM program is to wrap and unwrap the
 * coordinate transformations used by the hardware to store surfaces in
 * memory.  The hardware transforms a pixel location (X, Y, S) (where S is the
 * sample index for a multisampled surface) to a memory offset by the
 * following formulas:
 *
 *   offset = tile(tiling_format, encode_msaa(num_samples, layout, X, Y, S))
 *   (X, Y, S) = decode_msaa(num_samples, layout, detile(tiling_format, offset))
 *
 * For a single-sampled surface, or for a multisampled surface using
 * INTEL_MSAA_LAYOUT_UMS, encode_msaa() and decode_msaa are the identity
 * function:
 *
 *   encode_msaa(1, NONE, X, Y, 0) = (X, Y, 0)
 *   decode_msaa(1, NONE, X, Y, 0) = (X, Y, 0)
 *   encode_msaa(n, UMS, X, Y, S) = (X, Y, S)
 *   decode_msaa(n, UMS, X, Y, S) = (X, Y, S)
 *
 * For a 4x multisampled surface using INTEL_MSAA_LAYOUT_IMS, encode_msaa()
 * embeds the sample number into bit 1 of the X and Y coordinates:
 *
 *   encode_msaa(4, IMS, X, Y, S) = (X', Y', 0)
 *     where X' = (X & ~0b1) << 1 | (S & 0b1) << 1 | (X & 0b1)
 *           Y' = (Y & ~0b1 ) << 1 | (S & 0b10) | (Y & 0b1)
 *   decode_msaa(4, IMS, X, Y, 0) = (X', Y', S)
 *     where X' = (X & ~0b11) >> 1 | (X & 0b1)
 *           Y' = (Y & ~0b11) >> 1 | (Y & 0b1)
 *           S = (Y & 0b10) | (X & 0b10) >> 1
 *
 * For an 8x multisampled surface using INTEL_MSAA_LAYOUT_IMS, encode_msaa()
 * embeds the sample number into bits 1 and 2 of the X coordinate and bit 1 of
 * the Y coordinate:
 *
 *   encode_msaa(8, IMS, X, Y, S) = (X', Y', 0)
 *     where X' = (X & ~0b1) << 2 | (S & 0b100) | (S & 0b1) << 1 | (X & 0b1)
 *           Y' = (Y & ~0b1) << 1 | (S & 0b10) | (Y & 0b1)
 *   decode_msaa(8, IMS, X, Y, 0) = (X', Y', S)
 *     where X' = (X & ~0b111) >> 2 | (X & 0b1)
 *           Y' = (Y & ~0b11) >> 1 | (Y & 0b1)
 *           S = (X & 0b100) | (Y & 0b10) | (X & 0b10) >> 1
 *
 * For X tiling, tile() combines together the low-order bits of the X and Y
 * coordinates in the pattern 0byyyxxxxxxxxx, creating 4k tiles that are 512
 * bytes wide and 8 rows high:
 *
 *   tile(x_tiled, X, Y, S) = A
 *     where A = tile_num << 12 | offset
 *           tile_num = (Y' >> 3) * tile_pitch + (X' >> 9)
 *           offset = (Y' & 0b111) << 9
 *                    | (X & 0b111111111)
 *           X' = X * cpp
 *           Y' = Y + S * qpitch
 *   detile(x_tiled, A) = (X, Y, S)
 *     where X = X' / cpp
 *           Y = Y' % qpitch
 *           S = Y' / qpitch
 *           Y' = (tile_num / tile_pitch) << 3
 *                | (A & 0b111000000000) >> 9
 *           X' = (tile_num % tile_pitch) << 9
 *                | (A & 0b111111111)
 *
 * (In all tiling formulas, cpp is the number of bytes occupied by a single
 * sample ("chars per pixel"), tile_pitch is the number of 4k tiles required
 * to fill the width of the surface, and qpitch is the spacing (in rows)
 * between array slices).
 *
 * For Y tiling, tile() combines together the low-order bits of the X and Y
 * coordinates in the pattern 0bxxxyyyyyxxxx, creating 4k tiles that are 128
 * bytes wide and 32 rows high:
 *
 *   tile(y_tiled, X, Y, S) = A
 *     where A = tile_num << 12 | offset
 *           tile_num = (Y' >> 5) * tile_pitch + (X' >> 7)
 *           offset = (X' & 0b1110000) << 5
 *                    | (Y' & 0b11111) << 4
 *                    | (X' & 0b1111)
 *           X' = X * cpp
 *           Y' = Y + S * qpitch
 *   detile(y_tiled, A) = (X, Y, S)
 *     where X = X' / cpp
 *           Y = Y' % qpitch
 *           S = Y' / qpitch
 *           Y' = (tile_num / tile_pitch) << 5
 *                | (A & 0b111110000) >> 4
 *           X' = (tile_num % tile_pitch) << 7
 *                | (A & 0b111000000000) >> 5
 *                | (A & 0b1111)
 *
 * For W tiling, tile() combines together the low-order bits of the X and Y
 * coordinates in the pattern 0bxxxyyyyxyxyx, creating 4k tiles that are 64
 * bytes wide and 64 rows high (note that W tiling is only used for stencil
 * buffers, which always have cpp = 1 and S=0):
 *
 *   tile(w_tiled, X, Y, S) = A
 *     where A = tile_num << 12 | offset
 *           tile_num = (Y' >> 6) * tile_pitch + (X' >> 6)
 *           offset = (X' & 0b111000) << 6
 *                    | (Y' & 0b111100) << 3
 *                    | (X' & 0b100) << 2
 *                    | (Y' & 0b10) << 2
 *                    | (X' & 0b10) << 1
 *                    | (Y' & 0b1) << 1
 *                    | (X' & 0b1)
 *           X' = X * cpp = X
 *           Y' = Y + S * qpitch
 *   detile(w_tiled, A) = (X, Y, S)
 *     where X = X' / cpp = X'
 *           Y = Y' % qpitch = Y'
 *           S = Y / qpitch = 0
 *           Y' = (tile_num / tile_pitch) << 6
 *                | (A & 0b111100000) >> 3
 *                | (A & 0b1000) >> 2
 *                | (A & 0b10) >> 1
 *           X' = (tile_num % tile_pitch) << 6
 *                | (A & 0b111000000000) >> 6
 *                | (A & 0b10000) >> 2
 *                | (A & 0b100) >> 1
 *                | (A & 0b1)
 *
 * Finally, for a non-tiled surface, tile() simply combines together the X and
 * Y coordinates in the natural way:
 *
 *   tile(untiled, X, Y, S) = A
 *     where A = Y * pitch + X'
 *           X' = X * cpp
 *           Y' = Y + S * qpitch
 *   detile(untiled, A) = (X, Y, S)
 *     where X = X' / cpp
 *           Y = Y' % qpitch
 *           S = Y' / qpitch
 *           X' = A % pitch
 *           Y' = A / pitch
 *
 * (In these formulas, pitch is the number of bytes occupied by a single row
 * of samples).
 */
static nir_shader *
blorp_build_nir_shader(struct blorp_context *blorp,
                       struct blorp_batch *batch, void *mem_ctx,
                       const struct blorp_blit_prog_key *key)
{
   const struct intel_device_info *devinfo = blorp->isl_dev->info;

   /* Compute MSAA is only available on Gfx30+ */
   if (key->base.shader_pipeline == BLORP_SHADER_PIPELINE_COMPUTE)
      assert(key->dst_samples == 1 || devinfo->ver >= 30);

   nir_def *src_pos, *dst_pos, *color;

   /* Sanity checks */
   if (key->dst_tiled_w && key->rt_samples > 1) {
      /* If the destination image is W tiled and multisampled, then the thread
       * must be dispatched once per sample, not once per pixel.  This is
       * necessary because after conversion between W and Y tiling, there's no
       * guarantee that all samples corresponding to a single pixel will still
       * be together.
       */
      assert(key->persample_msaa_dispatch);
   }

   if (key->persample_msaa_dispatch) {
      /* It only makes sense to do persample dispatch if the render target is
       * configured as multisampled.
       */
      assert(key->base.shader_pipeline == BLORP_SHADER_PIPELINE_RENDER ||
             devinfo->ver >= 30);
      assert(key->rt_samples > 0);
   }

   /* Make sure layout is consistent with sample count */
   assert((key->tex_layout == ISL_MSAA_LAYOUT_NONE) ==
          (key->tex_samples <= 1));
   assert((key->rt_layout == ISL_MSAA_LAYOUT_NONE) ==
          (key->rt_samples <= 1));
   assert((key->src_layout == ISL_MSAA_LAYOUT_NONE) ==
          (key->src_samples <= 1));
   assert((key->dst_layout == ISL_MSAA_LAYOUT_NONE) ==
          (key->dst_samples <= 1));

   nir_builder b;
   const bool compute =
      key->base.shader_pipeline == BLORP_SHADER_PIPELINE_COMPUTE;
   mesa_shader_stage stage =
      compute ? MESA_SHADER_COMPUTE : MESA_SHADER_FRAGMENT;
   blorp_nir_init_shader(&b, blorp, mem_ctx, stage, NULL);

   struct blorp_builder bb;
   blorp_builder_init(&bb, &b, key, blorp);

   dst_pos = compute ?
      blorp_blit_get_cs_dst_coords(&b, &bb) :
      blorp_blit_get_frag_coords(&b, &bb);

   /* Render target and texture hardware don't support W tiling until Gfx8. */
   const bool rt_tiled_w = false;
   const bool tex_tiled_w = devinfo->ver >= 8 && key->src_tiled_w;

   /* The address that data will be written to is determined by the
    * coordinates supplied to the WM thread and the tiling and sample count of
    * the render target, according to the formula:
    *
    * (X, Y, S) = decode_msaa(rt_samples, detile(rt_tiling, offset))
    *
    * If the actual tiling and sample count of the destination surface are not
    * the same as the configuration of the render target, then these
    * coordinates are wrong and we have to adjust them to compensate for the
    * difference.
    */
   if (rt_tiled_w != key->dst_tiled_w ||
       key->rt_samples != key->dst_samples ||
       key->rt_layout != key->dst_layout) {
      dst_pos = blorp_nir_encode_msaa(&b, dst_pos, key->rt_samples,
                                      key->rt_layout);
      /* Now (X, Y, S) = detile(rt_tiling, offset) */
      if (rt_tiled_w != key->dst_tiled_w)
         dst_pos = blorp_nir_retile_y_to_w(&b, dst_pos);
      /* Now (X, Y, S) = detile(rt_tiling, offset) */
      dst_pos = blorp_nir_decode_msaa(&b, dst_pos, key->dst_samples,
                                      key->dst_layout);
   }

   nir_def *comp = NULL;
   if (key->dst_rgb) {
      /* The destination image is bound as a red texture three times as wide
       * as the actual image.  Our shader is effectively running one color
       * component at a time.  We need to save off the component and adjust
       * the destination position.
       */
      assert(dst_pos->num_components == 2);
      nir_def *dst_x = nir_channel(&b, dst_pos, 0);
      comp = nir_umod_imm(&b, dst_x, 3);
      dst_pos = nir_vec2(&b, nir_idiv(&b, dst_x, nir_imm_int(&b, 3)),
                             nir_channel(&b, dst_pos, 1));
   }

   /* Now (X, Y, S) = decode_msaa(dst_samples, detile(dst_tiling, offset)).
    *
    * That is: X, Y and S now contain the true coordinates and sample index of
    * the data that the WM thread should output.
    *
    * If we need to kill pixels that are outside the destination rectangle,
    * now is the time to do it.
    */
   nir_if *bounds_if = NULL;
   if (key->use_kill) {
      nir_def *bounds_rect = nir_load_var(&b, bb.v_bounds_rect);
      nir_def *in_bounds =
         blorp_check_in_bounds(&b, bounds_rect,
                               nir_trim_vector(&b, dst_pos, 2));
      if (!compute)
         nir_discard_if(&b, nir_inot(&b, in_bounds));
      else
         bounds_if = nir_push_if(&b, in_bounds);
   }

   src_pos = blorp_blit_apply_transform(&b, nir_i2f32(&b, dst_pos), &bb);
   if (dst_pos->num_components == 3) {
      /* The sample coordinate is an integer that we want left alone but
       * blorp_blit_apply_transform() blindly applies the transform to all
       * three coordinates.  Grab the original sample index.
       */
      src_pos = nir_vec3(&b, nir_channel(&b, src_pos, 0),
                             nir_channel(&b, src_pos, 1),
                             nir_channel(&b, dst_pos, 2));
   }

   /* If the source image is not multisampled, then we want to fetch sample
    * number 0, because that's the only sample there is.
    */
   if (key->src_samples == 1)
      src_pos = nir_trim_vector(&b, src_pos, 2);

   /* X, Y, and S are now the coordinates of the pixel in the source image
    * that we want to texture from.  Exception: if we are blending, then S is
    * irrelevant, because we are going to fetch all samples.
    */
   switch (key->filter) {
   case BLORP_FILTER_NONE:
   case BLORP_FILTER_NEAREST:
   case BLORP_FILTER_SAMPLE_0:
      assert(!key->need_src_buffer || key->src_samples == 1);
      /* We're going to use texelFetch, so we need integers */
      if (src_pos->num_components == 2) {
         src_pos = nir_f2i32(&b, src_pos);
      } else {
         assert(src_pos->num_components == 3);
         src_pos = nir_vec3(&b, nir_channel(&b, nir_f2i32(&b, src_pos), 0),
                                nir_channel(&b, nir_f2i32(&b, src_pos), 1),
                                nir_channel(&b, src_pos, 2));
      }

      /* We aren't blending, which means we just want to fetch a single
       * sample from the source surface.  The address that we want to fetch
       * from is related to the X, Y and S values according to the formula:
       *
       * (X, Y, S) = decode_msaa(src_samples, detile(src_tiling, offset)).
       *
       * If the actual tiling and sample count of the source surface are
       * not the same as the configuration of the texture, then we need to
       * adjust the coordinates to compensate for the difference.
       */
      if (tex_tiled_w != key->src_tiled_w ||
          key->tex_samples != key->src_samples ||
          key->tex_layout != key->src_layout) {
         src_pos = blorp_nir_encode_msaa(&b, src_pos, key->src_samples,
                                         key->src_layout);
         /* Now (X, Y, S) = detile(src_tiling, offset) */
         if (tex_tiled_w != key->src_tiled_w)
            src_pos = blorp_nir_retile_w_to_y(&b, src_pos);
         /* Now (X, Y, S) = detile(tex_tiling, offset) */
         src_pos = blorp_nir_decode_msaa(&b, src_pos, key->tex_samples,
                                         key->tex_layout);
      }

      if (key->need_src_offset)
         src_pos = nir_iadd(&b, src_pos, nir_load_var(&b, bb.v_src_offset));

      /* Now (X, Y, S) = decode_msaa(tex_samples, detile(tex_tiling, offset)).
       *
       * In other words: X, Y, and S now contain values which, when passed to
       * the texturing unit, will cause data to be read from the correct
       * memory location.  So we can fetch the texel now.
       */
      if (key->need_src_buffer) {
         color = blorp_nir_txf_buf(&b, &bb, src_pos, key->texture_data_type);
      } else if (key->src_samples == 1) {
         color = blorp_nir_txf(&b, &bb, src_pos, key->texture_data_type);
      } else {
         color = blorp_nir_txf_ms(&b, &bb, src_pos, key->texture_data_type);
      }
      break;

   case BLORP_FILTER_BILINEAR:
      assert(!key->src_tiled_w);
      assert(!key->need_src_buffer);
      assert(key->tex_samples == key->src_samples);
      assert(key->tex_layout == key->src_layout);

      if (key->src_samples == 1) {
         color = blorp_nir_tex(&b, &bb, src_pos);
      } else {
         assert(!key->use_kill);
         color = blorp_nir_manual_blend_bilinear(
            &b, src_pos, key->src_samples, &bb);
      }
      break;

   case BLORP_FILTER_AVERAGE:
   case BLORP_FILTER_MIN_SAMPLE:
   case BLORP_FILTER_MAX_SAMPLE:
      assert(!key->src_tiled_w);
      assert(!key->need_src_buffer);
      assert(key->tex_samples == key->src_samples);
      assert(key->tex_layout == key->src_layout);

      /* Resolves (effecively) use texelFetch, so we need integers and we
       * don't care about the sample index if we got one.
       */
      src_pos = nir_f2i32(&b, nir_trim_vector(&b, src_pos, 2));

      if (devinfo->ver == 6) {
         /* Because gfx6 only supports 4x interleved MSAA, we can do all the
          * blending we need with a single linear-interpolated texture lookup
          * at the center of the sample. The texture coordinates to be odd
          * integers so that they correspond to the center of a 2x2 block
          * representing the four samples that maxe up a pixel.  So we need
          * to multiply our X and Y coordinates each by 2 and then add 1.
          */
         assert(key->src_coords_normalized);
         assert(key->filter == BLORP_FILTER_AVERAGE);
         src_pos = nir_fadd_imm(&b,
                                nir_i2f32(&b, src_pos),
                                0.5f);
         color = blorp_nir_tex(&b, &bb, src_pos);
      } else {
         /* Gfx7+ hardware doesn't automatically blend. */
         color = blorp_nir_combine_samples(&b, &bb, src_pos, key->src_samples,
                                           key->tex_aux_usage,
                                           key->texture_data_type,
                                           key->filter);
      }
      break;

   default:
      UNREACHABLE("Invalid blorp filter");
   }

   if (!isl_swizzle_is_identity(key->src_swizzle)) {
      color = swizzle_color(&b, color, key->src_swizzle,
                            key->texture_data_type);
   }

   if (!isl_swizzle_is_identity(key->dst_swizzle)) {
      color = swizzle_color(&b, color, isl_swizzle_invert(key->dst_swizzle),
                            nir_type_int);
   }

   if (key->format_bit_cast) {
      assert(isl_swizzle_is_identity(key->src_swizzle));
      assert(isl_swizzle_is_identity(key->dst_swizzle));
      color = bit_cast_color(&b, color, key);
   } else if (key->dst_format) {
      color = convert_color(&b, color, key);
   } else if (key->uint32_to_sint) {
      /* Normally the hardware will take care of converting values from/to
       * the source and destination formats.  But a few cases need help.
       *
       * The Skylake PRM, volume 07, page 658 has a programming note:
       *
       *    "When using SINT or UINT rendertarget surface formats, Blending
       *     must be DISABLED. The Pre-Blend Color Clamp Enable and Color
       *     Clamp Range fields are ignored, and an implied clamp to the
       *     rendertarget surface format is performed."
       *
       * For UINT to SINT blits, our sample operation gives us a uint32_t,
       * but our render target write expects a signed int32_t number.  If we
       * simply passed the value along, the hardware would interpret a value
       * with bit 31 set as a negative value, clamping it to the largest
       * negative number the destination format could represent.  But the
       * actual source value is a positive number, so we want to clamp it
       * to INT_MAX.  To fix this, we explicitly take min(color, INT_MAX).
       */
      color = nir_umin(&b, color, nir_imm_int(&b, INT32_MAX));
   } else if (key->sint32_to_uint) {
      /* Similar to above, but clamping negative numbers to zero. */
      color = nir_imax(&b, color, nir_imm_int(&b, 0));
   }

   if (key->dst_rgb) {
      /* The destination image is bound as a red texture three times as wide
       * as the actual image.  Our shader is effectively running one color
       * component at a time.  We need to pick off the appropriate component
       * from the source color and write that to destination red.
       */
      assert(dst_pos->num_components == 2);

      nir_def *color_component =
         nir_bcsel(&b, nir_ieq_imm(&b, comp, 0),
                       nir_channel(&b, color, 0),
                       nir_bcsel(&b, nir_ieq_imm(&b, comp, 1),
                                     nir_channel(&b, color, 1),
                                     nir_channel(&b, color, 2)));

      nir_def *u = nir_undef(&b, 1, 32);
      color = nir_vec4(&b, color_component, u, u, u);
   }

   if (compute) {
      nir_def *store_pos = nir_load_global_invocation_id(&b, 32);

      /* Load sample index for MSAA image store */
      nir_def *sample_idx = nir_imm_int(&b, 0);

      if (key->dst_samples > 1) {
         nir_def *num_layers_data =
            nir_load_inline_data_intel(
               &b, 1, 32, nir_imm_int(&b, 0),
               .base = BLORP_INLINE_PARAM_THREAD_GROUP_ID_Z_DIMENSION,
               .range = 4);

         nir_def *z_pos = nir_umod(&b, nir_channel(&b, store_pos, 2),
                                   num_layers_data);
         sample_idx = nir_idiv(&b, nir_channel(&b, store_pos, 2),
                               num_layers_data);

         store_pos = nir_vector_insert_imm(&b, store_pos, z_pos, 2);
      }
      if (key->base.efficient_64bit) {
         nir_bindless_image_store(&b, bb.surface_states,
                                  nir_pad_vector_imm_int(&b, store_pos, 0, 4),
                                  sample_idx,
                                  nir_pad_vector_imm_int(&b, color, 0, 4),
                                  nir_imm_int(&b, 0),
                                  .image_dim = key->dst_samples > 1 ?
                                               GLSL_SAMPLER_DIM_MS:
                                  GLSL_SAMPLER_DIM_2D,
                                  .image_array = true,
                                  .access = ACCESS_NON_READABLE);
      } else {
         nir_image_store(&b, nir_imm_int(&b, 0),
                         nir_pad_vector_imm_int(&b, store_pos, 0, 4),
                         sample_idx,
                         nir_pad_vector_imm_int(&b, color, 0, 4),
                         nir_imm_int(&b, 0),
                         .image_dim = key->dst_samples > 1 ?
                                      GLSL_SAMPLER_DIM_MS:
                                      GLSL_SAMPLER_DIM_2D,
                         .image_array = true,
                         .access = ACCESS_NON_READABLE);
      }
   } else if (key->dst_usage == ISL_SURF_USAGE_RENDER_TARGET_BIT) {
      nir_variable *color_out =
         nir_variable_create(b.shader, nir_var_shader_out,
                             glsl_vec4_type(), "gl_FragColor");
      color_out->data.location = FRAG_RESULT_DATA0;
      nir_store_var(&b, color_out, color, 0xf);
   } else if (key->dst_usage == ISL_SURF_USAGE_DEPTH_BIT) {
      nir_variable *depth_out =
         nir_variable_create(b.shader, nir_var_shader_out,
                             glsl_float_type(), "gl_FragDepth");
      depth_out->data.location = FRAG_RESULT_DEPTH;
      nir_store_var(&b, depth_out, nir_channel(&b, color, 0), 0x1);
   } else if (key->dst_usage == ISL_SURF_USAGE_STENCIL_BIT) {
      nir_variable *stencil_out =
         nir_variable_create(b.shader, nir_var_shader_out,
                             glsl_int_type(), "gl_FragStencilRef");
      stencil_out->data.location = FRAG_RESULT_STENCIL;
      nir_store_var(&b, stencil_out, nir_channel(&b, color, 0), 0x1);
   } else {
      UNREACHABLE("Invalid destination usage");
   }

   if (bounds_if)
      nir_pop_if(&b, bounds_if);

   return b.shader;
}

static bool
blorp_get_blit_kernel_fs(struct blorp_batch *batch,
                         struct blorp_params *params,
                         const struct blorp_blit_prog_key *key)
{
   struct blorp_context *blorp = batch->blorp;

   if (blorp->lookup_shader(batch, key, sizeof(*key),
                            &params->wm_prog_kernel, &params->fs_prog_data))
      return true;

   void *mem_ctx = ralloc_context(NULL);

   nir_shader *nir = blorp_build_nir_shader(blorp, batch, mem_ctx, key);
   assert(blorp_op_type_is_blit(params->op));

   nir->info.name =
      ralloc_strdup(nir, blorp_shader_type_to_name(key->base.shader_type));

   const bool multisample_fbo = key->rt_samples > 1;

   const struct blorp_program p =
      blorp_compile_fs(blorp, mem_ctx, nir, multisample_fbo, false, false,
                       key, sizeof(*key));

   bool result =
      blorp->upload_shader(batch, MESA_SHADER_FRAGMENT,
                           key, sizeof(*key),
                           p.kernel, p.kernel_size,
                           p.prog_data, p.prog_data_size,
                           &params->wm_prog_kernel, &params->fs_prog_data);
   assert(result);

   ralloc_free(mem_ctx);
   return result;
}

static bool
blorp_get_blit_kernel_cs(struct blorp_batch *batch,
                         struct blorp_params *params,
                         const struct blorp_blit_prog_key *prog_key)
{
   struct blorp_context *blorp = batch->blorp;

   if (blorp->lookup_shader(batch, prog_key, sizeof(*prog_key),
                            &params->cs_prog_kernel, &params->cs_prog_data))
      return true;

   void *mem_ctx = ralloc_context(NULL);

   nir_shader *nir = blorp_build_nir_shader(blorp, batch, mem_ctx,
                                                prog_key);
   assert(blorp_op_type_is_blit(params->op));

   nir->info.name = ralloc_strdup(nir, "BLORP-gpgpu-blit");
   blorp_set_cs_dims(nir, prog_key->local_y);

   assert(batch->blorp->isl_dev->info->ver >= 30 || prog_key->rt_samples == 1);

   const struct blorp_program p =
      blorp_compile_cs(blorp, mem_ctx, nir, prog_key, sizeof(*prog_key));

   bool result =
      blorp->upload_shader(batch, MESA_SHADER_COMPUTE,
                           prog_key, sizeof(*prog_key),
                           p.kernel, p.kernel_size,
                           p.prog_data, p.prog_data_size,
                           &params->cs_prog_kernel, &params->cs_prog_data);
   assert(result);

   ralloc_free(mem_ctx);
   return result;
}

static void
blorp_setup_coord_transform(struct blorp_coord_transform *xform,
                            float src0, float src1,
                            float dst0, float dst1,
                            bool mirror)
{
   double scale = (double)(src1 - src0) / (double)(dst1 - dst0);
   if (!mirror) {
      /* When not mirroring a coordinate (say, X), we need:
       *   src_x - src_x0 = (dst_x - dst_x0 + 0.5) * scale
       * Therefore:
       *   src_x = src_x0 + (dst_x - dst_x0 + 0.5) * scale
       *
       * blorp program uses "round toward zero" to convert the
       * transformed floating point coordinates to integer coordinates,
       * whereas the behaviour we actually want is "round to nearest",
       * so 0.5 provides the necessary correction.
       */
      xform->multiplier = scale;
      xform->offset = src0 + (-(double)dst0 + 0.5) * scale;
   } else {
      /* When mirroring X we need:
       *   src_x - src_x0 = dst_x1 - dst_x - 0.5
       * Therefore:
       *   src_x = src_x0 + (dst_x1 -dst_x - 0.5) * scale
       */
      xform->multiplier = -scale;
      xform->offset = src0 + ((double)dst1 - 0.5) * scale;
   }
}

static inline void
surf_get_intratile_offset_px(struct blorp_surface_info *info,
                             uint32_t *tile_x_px, uint32_t *tile_y_px)
{
   if (info->surf.msaa_layout == ISL_MSAA_LAYOUT_INTERLEAVED) {
      struct isl_extent2d px_size_sa =
         isl_get_interleaved_msaa_px_size_sa(info->surf.samples);
      assert(info->tile_x_sa % px_size_sa.width == 0);
      assert(info->tile_y_sa % px_size_sa.height == 0);
      *tile_x_px = info->tile_x_sa / px_size_sa.width;
      *tile_y_px = info->tile_y_sa / px_size_sa.height;
   } else {
      *tile_x_px = info->tile_x_sa;
      *tile_y_px = info->tile_y_sa;
   }
}

void
blorp_surf_convert_to_single_slice(const struct isl_device *isl_dev,
                                   struct blorp_surface_info *info)
{
   bool ok UNUSED;

   /* It would be insane to try and do this on a compressed surface */
   assert(info->aux_surf.size_B == 0);

   /* Just bail if we have nothing to do. */
   if (info->surf.dim == ISL_SURF_DIM_2D &&
       info->view.base_level == 0 && info->view.base_array_layer == 0 &&
       info->surf.levels == 1 && info->surf.logical_level0_px.array_len == 1)
      return;

   /* If this gets triggered then we've gotten here twice which.  This
    * shouldn't happen thanks to the above early return.
    */
   assert(info->tile_x_sa == 0 && info->tile_y_sa == 0);

   uint32_t layer = 0, z = 0;
   if (info->surf.dim == ISL_SURF_DIM_3D)
      z = info->view.base_array_layer + info->z_offset;
   else
      layer = info->view.base_array_layer;

   uint64_t offset_B;
   isl_surf_get_image_surf(isl_dev, &info->surf,
                           info->view.base_level, layer, z,
                           &info->surf,
                           &offset_B, &info->tile_x_sa, &info->tile_y_sa);
   info->addr.offset += offset_B;

   uint32_t tile_x_px, tile_y_px;
   surf_get_intratile_offset_px(info, &tile_x_px, &tile_y_px);

   /* Instead of using the X/Y Offset fields in RENDER_SURFACE_STATE, we place
    * the image at the tile boundary and offset our sampling or rendering.
    * For this reason, we need to grow the image by the offset to ensure that
    * the hardware doesn't think we've gone past the edge.
    */
   info->surf.logical_level0_px.w += tile_x_px;
   info->surf.logical_level0_px.h += tile_y_px;
   info->surf.phys_level0_sa.w += info->tile_x_sa;
   info->surf.phys_level0_sa.h += info->tile_y_sa;

   /* The view is also different now. */
   info->view.base_level = 0;
   info->view.levels = 1;
   info->view.base_array_layer = 0;
   info->view.array_len = 1;
   info->z_offset = 0;
}

/* Convert a Tile64/Yf/Ys surface to a single level or a single miptail. */
static void
blorp_surf_convert_to_single_level_tile(const struct isl_device *isl_dev,
                                        struct blorp_surface_info *info,
                                        bool with_scaling)
{
   if (!isl_tiling_is_64(info->surf.tiling) &&
       !isl_tiling_is_std_y(info->surf.tiling)) {
      UNREACHABLE("Use blorp_surf_convert_to_single_slice() instead");
   }

   /* If the requested level is not part of the miptail, we just offset to the
    * requested level. Because we're using standard tilings and aren't in the
    * miptail, arrays and 3D textures should just work so long as we have the
    * right array stride in the end.
    *
    * If the requested level is in the miptail, we instead offset to the base
    * of the miptail.  Because offsets into the miptail are fixed by the
    * tiling and don't depend on the actual size of the image, we can set the
    * level in the view to offset into the miptail regardless of the fact
    * minification yields different results for the unscaled and scaled
    * surface.
    */
   const struct isl_surf *surf = &info->surf;
   const struct isl_view *view = &info->view;
   const uint32_t base_level =
      MIN2(view->base_level, surf->miptail_start_level);
   assert(view->levels == 1);

   uint64_t offset_B;
   uint32_t x_offset_el;
   uint32_t y_offset_el;
   isl_surf_get_image_offset_B_tile_el(surf, base_level, 0, 0,
                                       &offset_B, &x_offset_el, &y_offset_el);

   /* Tile64, Ys and Yf should have no intratile X or Y offset */
   assert(x_offset_el == 0 && y_offset_el == 0);
   assert(info->tile_x_sa == 0 && info->tile_y_sa == 0);
   info->addr.offset += offset_B;

   /* Save off the array pitch */
   const uint32_t array_pitch_el_rows = surf->array_pitch_el_rows;

   const struct isl_format_layout *surf_fmtl =
      isl_format_get_layout(surf->format);
   const struct isl_format_layout *view_fmtl =
      isl_format_get_layout(view->format);
   assert(isl_format_block_is_1x1x1(view->format));
   assert(isl_format_block_is_1x1x1(surf->format));

   const uint32_t view_height_el =
      u_minify(surf->logical_level0_px.height, view->base_level);
   const uint32_t view_depth_el =
      u_minify(surf->logical_level0_px.depth, view->base_level);
   uint32_t view_width_el =
      u_minify(surf->logical_level0_px.width, view->base_level);

   if (with_scaling) {
      const int scale = view_fmtl->bpb / surf_fmtl->bpb;
      view_width_el = DIV_ROUND_UP(view_width_el, scale);
   } else {
      assert(view_fmtl->bpb == surf_fmtl->bpb);
   }

   /* We need to compute the size of the scaled surface we will create. If
    * we're not in the miptail, it is just the view size in surface
    * elements. If we are in a miptail, we need a size that will minify to
    * the view size in surface elements. This may not be the same as the
    * size of base_level, but that's not a problem. Slot offsets are fixed
    * in HW (see the tables used in isl_get_miptail_level_offset_el).
    */
   const uint32_t scaled_level = view->base_level - base_level;

   /* The > 1 check is here to prevent a change in the surface's overall
    * dimension (e.g. 2D->3D).
    *
    * Also having a base_level dimension = 1 doesn´t mean the HW will
    * ignore higher mip level. Once the dimension has reached 1, it'll stay
    * at 1 in the higher mip levels.
    */
   struct isl_extent3d scaled_surf_extent_el = {
      .w = view_width_el  > 1 ? view_width_el  << scaled_level : 1,
      .h = view_height_el > 1 ? view_height_el << scaled_level : 1,
      .d = view_depth_el  > 1 ? view_depth_el  << scaled_level : 1,
   };

   isl_surf_usage_flags_t usage = surf->usage;
   /* CCS-enabled surfaces can have different layout requirements than
    * surfaces without CCS support. Disable CCS support if the original
    * surface lacked it.
    */
   if (info->aux_usage == ISL_AUX_USAGE_NONE)
      usage |= ISL_SURF_USAGE_DISABLE_AUX_BIT;

   /* Aux-tt alignment only applies to the beginning of the resource. We
    * might be pointing to some other subresource however.
    */
   if (offset_B > 0)
      usage |= ISL_SURF_USAGE_NO_AUX_TT_ALIGNMENT_BIT;

   struct isl_surf *scaled_surf = &info->surf;
   struct isl_view *scaled_view = &info->view;
   bool ok UNUSED;
   ok = isl_surf_init(isl_dev, scaled_surf,
                      .dim = surf->dim,
                      .format = view->format,
                      .width = scaled_surf_extent_el.width,
                      .height = scaled_surf_extent_el.height,
                      .depth = scaled_surf_extent_el.depth,
                      .levels = scaled_level + 1,
                      .array_len = surf->logical_level0_px.array_len,
                      .samples = surf->samples,
                      .min_miptail_start_level =
                         (int) (view->base_level < surf->miptail_start_level),
                      .row_pitch_B = surf->row_pitch_B,
                      .usage = usage,
                      .tiling_flags = (1u << surf->tiling));
   assert(ok);

   /* Use the array pitch from the original surface.  This way 2D arrays and
    * 3D textures should work properly, just with one LOD.
    */
   assert(scaled_surf->array_pitch_el_rows <= array_pitch_el_rows);
   scaled_surf->array_pitch_el_rows = array_pitch_el_rows;

   /* The newly created image represents only the one miplevel so we need to
    * adjust the view accordingly.  Because we offset it to miplevel but used
    * a Z and array slice of 0, the array range can be left alone.
    */
   *scaled_view = *view;
   scaled_view->base_level -= base_level;
}

void
blorp_surf_fake_interleaved_msaa(const struct isl_device *isl_dev,
                                 struct blorp_surface_info *info)
{
   assert(info->surf.msaa_layout == ISL_MSAA_LAYOUT_INTERLEAVED);

   /* First, we need to convert it to a simple 1-level 1-layer 2-D surface */
   blorp_surf_convert_to_single_slice(isl_dev, info);

   info->surf.logical_level0_px = info->surf.phys_level0_sa;
   info->surf.samples = 1;
   info->surf.msaa_layout = ISL_MSAA_LAYOUT_NONE;
}

void
blorp_surf_retile_w_to_y(const struct isl_device *isl_dev,
                         struct blorp_surface_info *info)
{
   assert(info->surf.tiling == ISL_TILING_W);

   /* First, we need to convert it to a simple 1-level 1-layer 2-D surface */
   blorp_surf_convert_to_single_slice(isl_dev, info);

   /* On gfx7+, we don't have interleaved multisampling for color render
    * targets so we have to fake it.
    *
    * TODO: Are we sure we don't also need to fake it on gfx6?
    */
   if (isl_dev->info->ver > 6 &&
       info->surf.msaa_layout == ISL_MSAA_LAYOUT_INTERLEAVED) {
      blorp_surf_fake_interleaved_msaa(isl_dev, info);
   }

   /* Now that we've converted everything to a simple 2-D surface with only
    * one miplevel, we can go about retiling it.
    */
   const unsigned x_align = 8, y_align = info->surf.samples != 0 ? 8 : 4;
   info->surf.tiling = ISL_TILING_Y0;
   info->surf.logical_level0_px.width =
      align(info->surf.logical_level0_px.width, x_align) * 2;
   info->surf.logical_level0_px.height =
      align(info->surf.logical_level0_px.height, y_align) / 2;
   info->tile_x_sa *= 2;
   info->tile_y_sa /= 2;
}

static bool
can_shrink_surface(const struct blorp_surface_info *surf)
{
   /* The current code doesn't support offsets into the aux buffers. This
    * should be possible, but we need to make sure the offset is page
    * aligned for both the surface and the aux buffer surface. Generally
    * this mean using the page aligned offset for the aux buffer.
    *
    * Currently the cases where we must split the blit are limited to cases
    * where we don't have a aux buffer.
    */
   if (surf->aux_addr.buffer != NULL)
      return false;

   /* We can't support splitting the blit for gen <= 7, because the qpitch
    * size is calculated by the hardware based on the surface height for
    * gen <= 7. In gen >= 8, the qpitch is controlled by the driver.
    */
   if (surf->surf.msaa_layout == ISL_MSAA_LAYOUT_ARRAY)
      return false;

   return true;
}

static unsigned
get_max_surface_size(const struct intel_device_info *devinfo,
                     const struct blorp_surface_info *surf)
{
   const unsigned max = devinfo->ver >= 7 ? 16384 : 8192;
   if (split_blorp_blit_debug && can_shrink_surface(surf))
      return max >> 4; /* A smaller restriction when debug is enabled */
   else
      return max;
}

struct blt_axis {
   double src0, src1, dst0, dst1;
   bool mirror;
};

struct blt_coords {
   struct blt_axis x, y;
};

static enum isl_format
get_red_format_for_rgb_format(enum isl_format format)
{
   const struct isl_format_layout *fmtl = isl_format_get_layout(format);

   switch (fmtl->channels.r.bits) {
   case 8:
      switch (fmtl->channels.r.type) {
      case ISL_UNORM:
         return ISL_FORMAT_R8_UNORM;
      case ISL_SNORM:
         return ISL_FORMAT_R8_SNORM;
      case ISL_UINT:
         return ISL_FORMAT_R8_UINT;
      case ISL_SINT:
         return ISL_FORMAT_R8_SINT;
      default:
         UNREACHABLE("Invalid 8-bit RGB channel type");
      }
   case 16:
      switch (fmtl->channels.r.type) {
      case ISL_UNORM:
         return ISL_FORMAT_R16_UNORM;
      case ISL_SNORM:
         return ISL_FORMAT_R16_SNORM;
      case ISL_SFLOAT:
         return ISL_FORMAT_R16_FLOAT;
      case ISL_UINT:
         return ISL_FORMAT_R16_UINT;
      case ISL_SINT:
         return ISL_FORMAT_R16_SINT;
      default:
         UNREACHABLE("Invalid 8-bit RGB channel type");
      }
   case 32:
      switch (fmtl->channels.r.type) {
      case ISL_SFLOAT:
         return ISL_FORMAT_R32_FLOAT;
      case ISL_UINT:
         return ISL_FORMAT_R32_UINT;
      case ISL_SINT:
         return ISL_FORMAT_R32_SINT;
      default:
         UNREACHABLE("Invalid 8-bit RGB channel type");
      }
   default:
      UNREACHABLE("Invalid number of red channel bits");
   }
}

void
surf_fake_rgb_with_red(const struct isl_device *isl_dev,
                       struct blorp_surface_info *info)
{
   blorp_surf_convert_to_single_slice(isl_dev, info);

   info->surf.logical_level0_px.width *= 3;
   info->surf.phys_level0_sa.width *= 3;
   info->tile_x_sa *= 3;

   enum isl_format red_format =
      get_red_format_for_rgb_format(info->view.format);

   assert(isl_format_get_layout(red_format)->channels.r.type ==
          isl_format_get_layout(info->view.format)->channels.r.type);
   assert(isl_format_get_layout(red_format)->channels.r.bits ==
          isl_format_get_layout(info->view.format)->channels.r.bits);

   info->surf.format = info->view.format = red_format;
}

/**
 * Converts the overfetching part of a linear 2D surface to a 1D buffer, this
 * is part of a workaround for performing buffer-to-image-copies when source
 * straddles an extra page due to a misaligned sampler cache.
 */
static inline void
blorp_surf_convert_overfetch_to_buffer(struct blorp_batch *batch,
                                       struct blorp_surface_info *info)
{
   const struct isl_device *isl_dev = batch->blorp->isl_dev;

   blorp_assert_is_buffer(info->surf, info->view);
   assert(isl_format_block_is_1x1x1(info->view.format));

   uint64_t address = batch->blorp->get_surface_address(batch, info->addr);
   uint64_t max_size_B = info->page_limit - address;
   uint64_t overfetch_B =
      isl_surf_get_sampler_overfetch_size_B(isl_dev, &info->surf, &info->view);

   if (overfetch_B > max_size_B) {
      uint32_t rows = (uint32_t) DIV_ROUND_UP(overfetch_B - max_size_B,
                                              info->surf.row_pitch_B);

      /* We could overflow the subtraction below in some cases */
      rows = MIN2(rows, info->surf.logical_level0_px.h);

      info->buffer = true;
      info->buffer_rows = rows;
      info->surf.logical_level0_px.h -= rows;
      info->surf.phys_level0_sa.h -= rows;
      info->surf.size_B -= rows * info->surf.row_pitch_B;

      if (info->surf.logical_level0_px.h == 0) {
         info->surf.size_B = 0;
         return;
      }

      assert(isl_surf_get_sampler_overfetch_size_B(isl_dev,
               &info->surf, &info->view) <= max_size_B);
   }
}

enum blit_shrink_status {
   BLIT_NO_SHRINK = 0,
   BLIT_SRC_WIDTH_SHRINK   = (1 << 0),
   BLIT_DST_WIDTH_SHRINK   = (1 << 1),
   BLIT_SRC_HEIGHT_SHRINK  = (1 << 2),
   BLIT_DST_HEIGHT_SHRINK  = (1 << 3),
};

/* Try to blit. If the surface parameters exceed the size allowed by hardware,
 * then enum blit_shrink_status will be returned. If BLIT_NO_SHRINK is
 * returned, then the blit was successful.
 */
static enum blit_shrink_status
try_blorp_blit(struct blorp_batch *batch,
               struct blorp_params *params,
               struct blorp_blit_prog_key *key,
               struct blt_coords *coords)
{
   const struct intel_device_info *devinfo = batch->blorp->isl_dev->info;

   if (params->dst.surf.usage & ISL_SURF_USAGE_DEPTH_BIT) {
      if (devinfo->ver >= 7) {
         /* We can render as depth on Gfx5 but there's no real advantage since
          * it doesn't support MSAA or HiZ.  On Gfx4, we can't always render
          * to depth due to issues with depth buffers and mip-mapping.  On
          * Gfx6, we can do everything but we have weird offsetting for HiZ
          * and stencil.  It's easier to just render using the color pipe
          * on those platforms.
          */
         key->dst_usage = ISL_SURF_USAGE_DEPTH_BIT;
      } else {
         key->dst_usage = ISL_SURF_USAGE_RENDER_TARGET_BIT;
      }
   } else if ((params->dst.surf.usage & ISL_SURF_USAGE_STENCIL_BIT) ||
              params->dst.aux_usage == ISL_AUX_USAGE_STC_CCS) {
      assert(params->dst.surf.format == ISL_FORMAT_R8_UINT);
      if (devinfo->ver >= 9 && !(batch->flags & BLORP_BATCH_USE_COMPUTE)) {
         key->dst_usage = ISL_SURF_USAGE_STENCIL_BIT;
      } else {
         key->dst_usage = ISL_SURF_USAGE_RENDER_TARGET_BIT;
      }
   } else {
      key->dst_usage = ISL_SURF_USAGE_RENDER_TARGET_BIT;
   }

   if (isl_format_has_sint_channel(params->src.view.format)) {
      key->texture_data_type = nir_type_int;
   } else if (isl_format_has_uint_channel(params->src.view.format)) {
      key->texture_data_type = nir_type_uint;
   } else {
      key->texture_data_type = nir_type_float;
   }

   /* src_samples and dst_samples are the true sample counts */
   key->src_samples = params->src.surf.samples;
   key->dst_samples = params->dst.surf.samples;

   key->tex_aux_usage = params->src.aux_usage;

   /* src_layout and dst_layout indicate the true MSAA layout used by src and
    * dst.
    */
   key->src_layout = params->src.surf.msaa_layout;
   key->dst_layout = params->dst.surf.msaa_layout;

   /* Round floating point values to nearest integer to avoid "off by one texel"
    * kind of errors when blitting.
    */
   params->x0 = params->wm_inputs.blit.bounds_rect.x0 = round(coords->x.dst0);
   params->y0 = params->wm_inputs.blit.bounds_rect.y0 = round(coords->y.dst0);
   params->x1 = params->wm_inputs.blit.bounds_rect.x1 = round(coords->x.dst1);
   params->y1 = params->wm_inputs.blit.bounds_rect.y1 = round(coords->y.dst1);

   blorp_setup_coord_transform(&params->wm_inputs.blit.coord_transform[0],
                                   coords->x.src0, coords->x.src1,
                                   coords->x.dst0, coords->x.dst1,
                                   coords->x.mirror);
   blorp_setup_coord_transform(&params->wm_inputs.blit.coord_transform[1],
                                   coords->y.src0, coords->y.src1,
                                   coords->y.dst0, coords->y.dst1,
                                   coords->y.mirror);


   if (devinfo->ver == 4) {
      /* The MinLOD and MinimumArrayElement don't work properly for cube maps.
       * Convert them to a single slice on gfx4.
       */
      if (params->dst.surf.usage & ISL_SURF_USAGE_CUBE_BIT) {
         blorp_surf_convert_to_single_slice(batch->blorp->isl_dev, &params->dst);
         key->need_dst_offset = true;
      }

      if (params->src.surf.usage & ISL_SURF_USAGE_CUBE_BIT) {
         blorp_surf_convert_to_single_slice(batch->blorp->isl_dev, &params->src);
         key->need_src_offset = true;
      }
   }

   if (devinfo->ver > 6 &&
       !isl_surf_usage_is_depth_or_stencil(key->dst_usage) &&
       params->dst.surf.msaa_layout == ISL_MSAA_LAYOUT_INTERLEAVED) {
      assert(params->dst.surf.samples > 1);

      /* We must expand the rectangle we send through the rendering pipeline,
       * to account for the fact that we are mapping the destination region as
       * single-sampled when it is in fact multisampled.  We must also align
       * it to a multiple of the multisampling pattern, because the
       * differences between multisampled and single-sampled surface formats
       * will mean that pixels are scrambled within the multisampling pattern.
       * TODO: what if this makes the coordinates too large?
       *
       * Note: this only works if the destination surface uses the IMS layout.
       * If it's UMS, then we have no choice but to set up the rendering
       * pipeline as multisampled.
       */
      struct isl_extent2d px_size_sa =
         isl_get_interleaved_msaa_px_size_sa(params->dst.surf.samples);
      params->x0 = ROUND_DOWN_TO(params->x0, 2) * px_size_sa.width;
      params->y0 = ROUND_DOWN_TO(params->y0, 2) * px_size_sa.height;
      params->x1 = align(params->x1, 2) * px_size_sa.width;
      params->y1 = align(params->y1, 2) * px_size_sa.height;

      blorp_surf_fake_interleaved_msaa(batch->blorp->isl_dev, &params->dst);

      key->use_kill = true;
      key->need_dst_offset = true;
   }

   if (params->dst.surf.tiling == ISL_TILING_W &&
       key->dst_usage != ISL_SURF_USAGE_STENCIL_BIT) {
      /* We must modify the rectangle we send through the rendering pipeline
       * (and the size and x/y offset of the destination surface), to account
       * for the fact that we are mapping it as Y-tiled when it is in fact
       * W-tiled.
       *
       * Both Y tiling and W tiling can be understood as organizations of
       * 32-byte sub-tiles; within each 32-byte sub-tile, the layout of pixels
       * is different, but the layout of the 32-byte sub-tiles within the 4k
       * tile is the same (8 sub-tiles across by 16 sub-tiles down, in
       * column-major order).  In Y tiling, the sub-tiles are 16 bytes wide
       * and 2 rows high; in W tiling, they are 8 bytes wide and 4 rows high.
       *
       * Therefore, to account for the layout differences within the 32-byte
       * sub-tiles, we must expand the rectangle so the X coordinates of its
       * edges are multiples of 8 (the W sub-tile width), and its Y
       * coordinates of its edges are multiples of 4 (the W sub-tile height).
       * Then we need to scale the X and Y coordinates of the rectangle to
       * account for the differences in aspect ratio between the Y and W
       * sub-tiles.  We need to modify the layer width and height similarly.
       *
       * A correction needs to be applied when MSAA is in use: since
       * INTEL_MSAA_LAYOUT_IMS uses an interleaving pattern whose height is 4,
       * we need to align the Y coordinates to multiples of 8, so that when
       * they are divided by two they are still multiples of 4.
       *
       * Note: Since the x/y offset of the surface will be applied using the
       * SURFACE_STATE command packet, it will be invisible to the swizzling
       * code in the shader; therefore it needs to be in a multiple of the
       * 32-byte sub-tile size.  Fortunately it is, since the sub-tile is 8
       * pixels wide and 4 pixels high (when viewed as a W-tiled stencil
       * buffer), and the miplevel alignment used for stencil buffers is 8
       * pixels horizontally and either 4 or 8 pixels vertically (see
       * intel_horizontal_texture_alignment_unit() and
       * intel_vertical_texture_alignment_unit()).
       *
       * Note: Also, since the SURFACE_STATE command packet can only apply
       * offsets that are multiples of 4 pixels horizontally and 2 pixels
       * vertically, it is important that the offsets will be multiples of
       * these sizes after they are converted into Y-tiled coordinates.
       * Fortunately they will be, since we know from above that the offsets
       * are a multiple of the 32-byte sub-tile size, and in Y-tiled
       * coordinates the sub-tile is 16 pixels wide and 2 pixels high.
       *
       * TODO: what if this makes the coordinates (or the texture size) too
       * large?
       */
      const unsigned x_align = 8;
      const unsigned y_align = params->dst.surf.samples != 0 ? 8 : 4;
      params->x0 = ROUND_DOWN_TO(params->x0, x_align) * 2;
      params->y0 = ROUND_DOWN_TO(params->y0, y_align) / 2;
      params->x1 = align(params->x1, x_align) * 2;
      params->y1 = align(params->y1, y_align) / 2;

      /* Retile the surface to Y-tiled */
      blorp_surf_retile_w_to_y(batch->blorp->isl_dev, &params->dst);

      key->dst_tiled_w = true;
      key->use_kill = true;
      key->need_dst_offset = true;

      if (key->base.shader_pipeline == BLORP_SHADER_PIPELINE_RENDER &&
          params->dst.surf.samples > 1) {
         /* If the destination surface is a W-tiled multisampled stencil
          * buffer that we're mapping as Y tiled, then we need to arrange for
          * the WM program to run once per sample rather than once per pixel,
          * because the memory layout of related samples doesn't match between
          * W and Y tiling.
          */
         key->persample_msaa_dispatch = true;
      }
   }

   if (devinfo->ver < 8 && params->src.surf.tiling == ISL_TILING_W) {
      /* On Haswell and earlier, we have to fake W-tiled sources as Y-tiled.
       * Broadwell adds support for sampling from stencil.
       *
       * See the comments above concerning x/y offset alignment for the
       * destination surface.
       *
       * TODO: what if this makes the texture size too large?
       */
      blorp_surf_retile_w_to_y(batch->blorp->isl_dev, &params->src);

      key->src_tiled_w = true;
      key->need_src_offset = true;
   }

   /* tex_samples and rt_samples are the sample counts that are set up in
    * SURFACE_STATE.
    */
   key->tex_samples = params->src.surf.samples;
   key->rt_samples  = params->dst.surf.samples;

   /* tex_layout and rt_layout indicate the MSAA layout the GPU pipeline will
    * use to access the source and destination surfaces.
    */
   key->tex_layout = params->src.surf.msaa_layout;
   key->rt_layout = params->dst.surf.msaa_layout;

   if (params->src.surf.samples > 0 && params->dst.surf.samples > 1) {
      /* We are blitting from a multisample buffer to a multisample buffer, so
       * we must preserve samples within a pixel.  This means we have to
       * arrange for the WM program to run once per sample rather than once
       * per pixel.
       */
      key->persample_msaa_dispatch = true;
   }

   params->num_samples = params->dst.surf.samples;

   if ((key->filter == BLORP_FILTER_AVERAGE ||
        key->filter == BLORP_FILTER_BILINEAR) &&
       batch->blorp->isl_dev->info->ver <= 6) {
      /* Gfx4-5 don't support non-normalized texture coordinates */
      key->src_coords_normalized = true;
      params->wm_inputs.blit.src_inv_size[0] =
         1.0f / u_minify(params->src.surf.logical_level0_px.width,
                         params->src.view.base_level);
      params->wm_inputs.blit.src_inv_size[1] =
         1.0f / u_minify(params->src.surf.logical_level0_px.height,
                         params->src.view.base_level);
   }

   if (isl_format_get_layout(params->dst.view.format)->bpb % 3 == 0) {
      /* We can't render to  RGB formats natively because they aren't a
       * power-of-two size.  Instead, we fake them by using a red format
       * with the same channel type and size and emitting shader code to
       * only write one channel at a time.
       */
      params->x0 *= 3;
      params->x1 *= 3;

      /* If it happens to be sRGB, we need to force a conversion */
      if (params->dst.view.format == ISL_FORMAT_R8G8B8_UNORM_SRGB)
         key->dst_format = ISL_FORMAT_R8G8B8_UNORM_SRGB;

      surf_fake_rgb_with_red(batch->blorp->isl_dev, &params->dst);

      key->dst_rgb = true;
      key->need_dst_offset = true;
   } else if (isl_format_is_rgbx(params->dst.view.format)) {
      /* We can handle RGBX formats easily enough by treating them as RGBA */
      params->dst.view.format =
         isl_format_rgbx_to_rgba(params->dst.view.format);
   } else if (params->dst.view.format == ISL_FORMAT_R24_UNORM_X8_TYPELESS &&
              key->dst_usage != ISL_SURF_USAGE_DEPTH_BIT) {
      key->dst_format = params->dst.view.format;
      params->dst.view.format = ISL_FORMAT_R32_UINT;
   } else if (!isl_format_supports_rendering(devinfo, params->dst.view.format)
              && params->dst.view.format == ISL_FORMAT_A4B4G4R4_UNORM) {
      params->dst.view.swizzle =
         isl_swizzle_compose(params->dst.view.swizzle,
                             ISL_SWIZZLE(ALPHA, RED, GREEN, BLUE));
      params->dst.view.format = ISL_FORMAT_B4G4R4A4_UNORM;
   } else if (params->dst.view.format == ISL_FORMAT_L8_UNORM_SRGB) {
      key->dst_format = params->dst.view.format;
      params->dst.view.format = ISL_FORMAT_R8_UNORM;
   } else if (params->dst.view.format == ISL_FORMAT_R9G9B9E5_SHAREDEXP) {
      key->dst_format = params->dst.view.format;
      params->dst.view.format = ISL_FORMAT_R32_UINT;
   }

   if (devinfo->verx10 <= 70 &&
       !isl_swizzle_is_identity(params->src.view.swizzle)) {
      key->src_swizzle = params->src.view.swizzle;
      params->src.view.swizzle = ISL_SWIZZLE_IDENTITY;
   } else {
      key->src_swizzle = ISL_SWIZZLE_IDENTITY;
   }

   if (!isl_swizzle_supports_rendering(devinfo, params->dst.view.swizzle)) {
      key->dst_swizzle = params->dst.view.swizzle;
      params->dst.view.swizzle = ISL_SWIZZLE_IDENTITY;
   } else {
      key->dst_swizzle = ISL_SWIZZLE_IDENTITY;
   }

   if (params->src.tile_x_sa || params->src.tile_y_sa) {
      assert(key->need_src_offset);
      surf_get_intratile_offset_px(&params->src,
                                   &params->wm_inputs.blit.src_offset.x,
                                   &params->wm_inputs.blit.src_offset.y);
   }

   if (params->dst.tile_x_sa || params->dst.tile_y_sa) {
      assert(key->need_dst_offset);
      surf_get_intratile_offset_px(&params->dst,
                                   &params->wm_inputs.blit.dst_offset.x,
                                   &params->wm_inputs.blit.dst_offset.y);
      params->x0 += params->wm_inputs.blit.dst_offset.x;
      params->y0 += params->wm_inputs.blit.dst_offset.y;
      params->x1 += params->wm_inputs.blit.dst_offset.x;
      params->y1 += params->wm_inputs.blit.dst_offset.y;
   }

   /* For some texture types, we need to pass the layer through the sampler. */
   params->wm_inputs.blit.src_z = params->src.z_offset;

   const bool compute =
      key->base.shader_pipeline == BLORP_SHADER_PIPELINE_COMPUTE;
   if (compute) {
      key->local_y = blorp_get_cs_local_y(params);

      unsigned workgroup_width = 16 / key->local_y;
      unsigned workgroup_height = key->local_y;

      /* If the rectangle being drawn isn't an exact multiple of the
       * workgroup size, we'll get extra invocations that should not
       * perform blits.  We need to set use_kill to bounds check and
       * prevent those invocations from blitting.
       */
      if ((params->x0 % workgroup_width) != 0 ||
          (params->x1 % workgroup_width) != 0 ||
          (params->y0 % workgroup_height) != 0 ||
          (params->y1 % workgroup_height) != 0)
         key->use_kill = true;
   }

   if (batch->blorp->isl_dev->requires_padding &&
       (batch->flags & BLORP_BATCH_SRC_UNPADDED)) {
      params->src.view.usage |= ISL_SURF_USAGE_NO_ARRAY_OVERFETCH_BIT;
      blorp_surf_convert_overfetch_to_buffer(batch, &params->src);
   }

   key->need_src_buffer = params->src.buffer;
   if (key->need_src_buffer) {
      params->wm_inputs.blit.src_buffer_first_row =
         params->src.surf.logical_level0_px.h;
      params->wm_inputs.blit.src_buffer_row_pitch =
         params->src.surf.row_pitch_B /
         (isl_format_get_layout(params->src.view.format)->bpb / 8);
   }

   if (compute) {
      if (!blorp_get_blit_kernel_cs(batch, params, key)) {
         mesa_loge("%s: failed to get CS kernel", __func__);
         return 0;
      }
   } else {
      if (!blorp_get_blit_kernel_fs(batch, params, key)) {
         mesa_loge("%s: failed to get FS kernel", __func__);
         return 0;
      }

      if (!blorp_ensure_sf_program(batch, params)) {
         mesa_loge("%s: failed to get SF kernel", __func__);
         return 0;
      }
   }

   unsigned result = 0;
   unsigned max_src_surface_size = get_max_surface_size(devinfo, &params->src);
   if (params->src.surf.logical_level0_px.width > max_src_surface_size)
      result |= BLIT_SRC_WIDTH_SHRINK;
   if (params->src.surf.logical_level0_px.height > max_src_surface_size)
      result |= BLIT_SRC_HEIGHT_SHRINK;

   unsigned max_dst_surface_size = get_max_surface_size(devinfo, &params->dst);
   if (params->dst.surf.logical_level0_px.width > max_dst_surface_size)
      result |= BLIT_DST_WIDTH_SHRINK;
   if (params->dst.surf.logical_level0_px.height > max_dst_surface_size)
      result |= BLIT_DST_HEIGHT_SHRINK;

   if (result == 0) {
      if (key->dst_usage == ISL_SURF_USAGE_DEPTH_BIT) {
         params->depth = params->dst;
         memset(&params->dst, 0, sizeof(params->dst));
      } else if (key->dst_usage == ISL_SURF_USAGE_STENCIL_BIT) {
         params->stencil = params->dst;
         params->stencil_mask = 0xff;
         memset(&params->dst, 0, sizeof(params->dst));
      }

      batch->blorp->exec(batch, params);
   }

   return result;
}

/* Adjust split blit source coordinates for the current destination
 * coordinates.
 */
static void
adjust_split_source_coords(const struct blt_axis *orig,
                           struct blt_axis *split_coords,
                           double scale)
{
   /* When scale is greater than 0, then we are growing from the start, so
    * src0 uses delta0, and src1 uses delta1. When scale is less than 0, the
    * source range shrinks from the end. In that case src0 is adjusted by
    * delta1, and src1 is adjusted by delta0.
    */
   double delta0 = scale * (split_coords->dst0 - orig->dst0);
   double delta1 = scale * (split_coords->dst1 - orig->dst1);
   split_coords->src0 = orig->src0 + (scale >= 0.0 ? delta0 : delta1);
   split_coords->src1 = orig->src1 + (scale >= 0.0 ? delta1 : delta0);
}

static struct isl_extent2d
get_px_size_sa(const struct isl_surf *surf)
{
   static const struct isl_extent2d one_to_one = { .w = 1, .h = 1 };

   if (surf->msaa_layout != ISL_MSAA_LAYOUT_INTERLEAVED)
      return one_to_one;
   else
      return isl_get_interleaved_msaa_px_size_sa(surf->samples);
}

static void
shrink_surface_params(const struct isl_device *dev,
                      struct blorp_surface_info *info,
                      double *x0, double *x1, double *y0, double *y1)
{
   uint64_t start_offset_B;
   uint64_t end_offset_B;
   uint32_t x_offset_sa, y_offset_sa, size;
   struct isl_extent2d px_size_sa;
   struct isl_extent4d surf_size_sa;
   int adjust;

   blorp_surf_convert_to_single_slice(dev, info);

   px_size_sa = get_px_size_sa(&info->surf);

   /* Because this gets called after we lower compressed images, the tile
    * offsets may be non-zero and we need to incorporate them in our
    * calculations.
    */
   x_offset_sa = (uint32_t)*x0 * px_size_sa.w + info->tile_x_sa;
   y_offset_sa = (uint32_t)*y0 * px_size_sa.h + info->tile_y_sa;
   surf_size_sa = (struct isl_extent4d) {
      .w = (uint32_t)ceil(*x1) * px_size_sa.w + info->tile_x_sa,
      .h = (uint32_t)ceil(*y1) * px_size_sa.h + info->tile_y_sa,
      .d = 1,
      .a = 1,
   };

   uint32_t tile_z_sa, tile_a;
   isl_tiling_get_intratile_range_sa(info->surf.tiling, info->surf.dim,
                                     info->surf.msaa_layout,
                                     info->surf.format, info->surf.samples,
                                     info->surf.row_pitch_B,
                                     info->surf.array_pitch_el_rows,
                                     x_offset_sa, y_offset_sa, 0, 0,
                                     surf_size_sa,
                                     &start_offset_B,
                                     &end_offset_B,
                                     &info->tile_x_sa, &info->tile_y_sa,
                                     &tile_z_sa, &tile_a);
   assert(tile_z_sa == 0 && tile_a == 0);

   info->addr.offset += start_offset_B;

   adjust = (int)info->tile_x_sa / px_size_sa.w - (int)*x0;
   *x0 += adjust;
   *x1 += adjust;
   info->tile_x_sa = 0;

   adjust = (int)info->tile_y_sa / px_size_sa.h - (int)*y0;
   *y0 += adjust;
   *y1 += adjust;
   info->tile_y_sa = 0;

   size = MIN2((uint32_t)ceil(*x1), info->surf.logical_level0_px.width);
   info->surf.logical_level0_px.width = size;
   info->surf.phys_level0_sa.width = size * px_size_sa.w;

   size = MIN2((uint32_t)ceil(*y1), info->surf.logical_level0_px.height);
   info->surf.logical_level0_px.height = size;
   info->surf.phys_level0_sa.height = size * px_size_sa.h;

   info->surf.size_B = end_offset_B - start_offset_B;
   info->surf.usage |= ISL_SURF_USAGE_NO_OVERFETCH_PADDING_BIT;

   /* Stomp the 64B alignment because we set NO_OVERFETCH_PADDING_BIT */
   if (info->surf.tiling == ISL_TILING_LINEAR)
      info->surf.alignment_B = 1;
}

static void
do_blorp_blit(struct blorp_batch *batch,
              const struct blorp_params *orig_params,
              struct blorp_blit_prog_key *key,
              const struct blt_coords *orig)
{
   struct blorp_params params;
   struct blt_coords blit_coords;
   struct blt_coords split_coords = *orig;
   double w = orig->x.dst1 - orig->x.dst0;
   double h = orig->y.dst1 - orig->y.dst0;
   double x_scale = (orig->x.src1 - orig->x.src0) / w;
   double y_scale = (orig->y.src1 - orig->y.src0) / h;
   if (orig->x.mirror)
      x_scale = -x_scale;
   if (orig->y.mirror)
      y_scale = -y_scale;

   enum blit_shrink_status shrink = BLIT_NO_SHRINK;
   if (split_blorp_blit_debug) {
      if (can_shrink_surface(&orig_params->src))
         shrink |= BLIT_SRC_WIDTH_SHRINK | BLIT_SRC_HEIGHT_SHRINK;
      if (can_shrink_surface(&orig_params->dst))
         shrink |= BLIT_DST_WIDTH_SHRINK | BLIT_DST_HEIGHT_SHRINK;
   }

   bool x_done, y_done;
   do {
      params = *orig_params;
      blit_coords = split_coords;

      if (shrink & (BLIT_SRC_WIDTH_SHRINK | BLIT_SRC_HEIGHT_SHRINK)) {
         shrink_surface_params(batch->blorp->isl_dev, &params.src,
                               &blit_coords.x.src0, &blit_coords.x.src1,
                               &blit_coords.y.src0, &blit_coords.y.src1);
         key->need_src_offset = false;
      }

      if (shrink & (BLIT_DST_WIDTH_SHRINK | BLIT_DST_HEIGHT_SHRINK)) {
         shrink_surface_params(batch->blorp->isl_dev, &params.dst,
                               &blit_coords.x.dst0, &blit_coords.x.dst1,
                               &blit_coords.y.dst0, &blit_coords.y.dst1);
         key->need_dst_offset = false;
      }

      enum blit_shrink_status result =
         try_blorp_blit(batch, &params, key, &blit_coords);

      if (result & (BLIT_SRC_WIDTH_SHRINK | BLIT_SRC_HEIGHT_SHRINK))
         assert(can_shrink_surface(&orig_params->src));

      if (result & (BLIT_DST_WIDTH_SHRINK | BLIT_DST_HEIGHT_SHRINK))
         assert(can_shrink_surface(&orig_params->dst));

      if (result & (BLIT_SRC_WIDTH_SHRINK | BLIT_DST_WIDTH_SHRINK)) {
         w /= 2.0;
         assert(w >= 1.0);
         split_coords.x.dst1 = MIN2(split_coords.x.dst0 + w, orig->x.dst1);
         adjust_split_source_coords(&orig->x, &split_coords.x, x_scale);
      }
      if (result & (BLIT_SRC_HEIGHT_SHRINK | BLIT_DST_HEIGHT_SHRINK)) {
         h /= 2.0;
         assert(h >= 1.0);
         split_coords.y.dst1 = MIN2(split_coords.y.dst0 + h, orig->y.dst1);
         adjust_split_source_coords(&orig->y, &split_coords.y, y_scale);
      }

      if (result) {
         /* We may get less bits set on result than we had already, so make
          * sure we remember all the ways in which a resize is required.
          */
         shrink |= result;
         continue;
      }

      y_done = (orig->y.dst1 - split_coords.y.dst1 < 0.5);
      x_done = y_done && (orig->x.dst1 - split_coords.x.dst1 < 0.5);
      if (x_done) {
         break;
      } else if (y_done) {
         split_coords.x.dst0 += w;
         split_coords.x.dst1 = MIN2(split_coords.x.dst0 + w, orig->x.dst1);
         split_coords.y.dst0 = orig->y.dst0;
         split_coords.y.dst1 = MIN2(split_coords.y.dst0 + h, orig->y.dst1);
         adjust_split_source_coords(&orig->x, &split_coords.x, x_scale);
      } else {
         split_coords.y.dst0 += h;
         split_coords.y.dst1 = MIN2(split_coords.y.dst0 + h, orig->y.dst1);
         adjust_split_source_coords(&orig->y, &split_coords.y, y_scale);
      }
   } while (true);
}

bool
blorp_blit_supports_compute(struct blorp_context *blorp,
                            const struct isl_surf *src_surf,
                            const struct isl_surf *dst_surf,
                            enum isl_aux_usage dst_aux_usage)
{
   /* Platforms < Xe3 doesn't support typed image writes with MSAA. */
   if (blorp->isl_dev->info->ver < 30 && dst_surf->samples > 1)
      return false;

   if (blorp->isl_dev->info->ver >= 30) {
      return dst_aux_usage == ISL_AUX_USAGE_FCV_CCS_E ||
             dst_aux_usage == ISL_AUX_USAGE_CCS_E ||
             dst_aux_usage == ISL_AUX_USAGE_NONE;
   } else if (blorp->isl_dev->info->ver >= 12) {
      return dst_aux_usage == ISL_AUX_USAGE_CCS_E ||
             dst_aux_usage == ISL_AUX_USAGE_NONE;
   } else if (blorp->isl_dev->info->ver >= 7) {
      return dst_aux_usage == ISL_AUX_USAGE_NONE;
   } else {
      /* No compute shader support */
      return false;
   }
}

bool
blorp_blitter_supports_aux(const struct intel_device_info *devinfo,
                           enum isl_aux_usage aux_usage)
{
   switch (aux_usage) {
   case ISL_AUX_USAGE_NONE:
      return true;
   case ISL_AUX_USAGE_CCS_E:
   case ISL_AUX_USAGE_STC_CCS:
   case ISL_AUX_USAGE_ZCS:
      return devinfo->verx10 >= 125;
   default:
      return false;
   }
}

bool
blorp_copy_supports_blitter(struct blorp_context *blorp,
                            const struct isl_surf *src_surf,
                            const struct isl_surf *dst_surf,
                            enum isl_aux_usage src_aux_usage,
                            enum isl_aux_usage dst_aux_usage)
{
   const struct intel_device_info *devinfo = blorp->isl_dev->info;

   if (devinfo->ver < 12)
      return false;

   if (devinfo->verx10 == 120 &&
       (src_surf->tiling != ISL_TILING_LINEAR ||
        dst_surf->tiling != ISL_TILING_LINEAR)) {
      return false;
   }

   if (dst_surf->samples > 1 || src_surf->samples > 1)
      return false;

   if (!blorp_blitter_supports_aux(devinfo, dst_aux_usage))
      return false;

   if (!blorp_blitter_supports_aux(devinfo, src_aux_usage))
      return false;

   const struct isl_format_layout *fmtl =
      isl_format_get_layout(dst_surf->format);

   if (fmtl->bpb == 96) {
      /* XY_BLOCK_COPY_BLT mentions it doesn't support clear colors for 96bpp
       * formats, but none of them support CCS anyway, so it's a moot point.
       */
      if (devinfo->verx10 < 20) {
         assert(src_aux_usage == ISL_AUX_USAGE_NONE);
         assert(dst_aux_usage == ISL_AUX_USAGE_NONE);
      }

      /* We can only support linear mode for 96bpp. */
      if (src_surf->tiling != ISL_TILING_LINEAR ||
          dst_surf->tiling != ISL_TILING_LINEAR)
         return false;
   }

   return true;
}

void
blorp_blit(struct blorp_batch *batch,
           const struct blorp_surf *src_surf,
           unsigned src_level, float src_layer,
           enum isl_format src_format, struct isl_swizzle src_swizzle,
           const struct blorp_surf *dst_surf,
           unsigned dst_level, unsigned dst_layer,
           enum isl_format dst_format, struct isl_swizzle dst_swizzle,
           float src_x0, float src_y0,
           float src_x1, float src_y1,
           float dst_x0, float dst_y0,
           float dst_x1, float dst_y1,
           enum blorp_filter filter,
           bool mirror_x, bool mirror_y)
{
   struct blorp_params params;
   blorp_params_init(&params, batch->blorp);
   params.op = BLORP_OP_BLIT;
   const bool compute = batch->flags & BLORP_BATCH_USE_COMPUTE;
   if (compute) {
      assert(blorp_blit_supports_compute(batch->blorp,
                                         src_surf->surf, dst_surf->surf,
                                         dst_surf->aux_usage));
   }

   /* We cannot handle combined depth and stencil. */
   if (src_surf->surf->usage & ISL_SURF_USAGE_STENCIL_BIT)
      assert(src_surf->surf->format == ISL_FORMAT_R8_UINT);
   if (dst_surf->surf->usage & ISL_SURF_USAGE_STENCIL_BIT)
      assert(dst_surf->surf->format == ISL_FORMAT_R8_UINT);

   if (dst_surf->surf->usage & ISL_SURF_USAGE_STENCIL_BIT) {
      assert(src_surf->surf->usage & ISL_SURF_USAGE_STENCIL_BIT);
      /* Prior to Broadwell, we can't render to R8_UINT */
      if (batch->blorp->isl_dev->info->ver < 8) {
         src_format = ISL_FORMAT_R8_UNORM;
         dst_format = ISL_FORMAT_R8_UNORM;
      }
   }

   blorp_surface_info_init(batch, &params.src, src_surf, src_level,
                           src_layer, src_format, false);
   blorp_surface_info_init(batch, &params.dst, dst_surf, dst_level,
                           dst_layer, dst_format, true);

   params.src.view.swizzle = src_swizzle;
   params.dst.view.swizzle = dst_swizzle;

   const struct isl_format_layout *src_fmtl =
      isl_format_get_layout(params.src.view.format);

   struct blorp_blit_prog_key key;
   BLORP_KEY_INIT(key, batch->blorp, BLORP_SHADER_TYPE_BLIT,
                  (compute ? BLORP_SHADER_PIPELINE_COMPUTE :
                             BLORP_SHADER_PIPELINE_RENDER));
   key.filter = filter;
   key.sint32_to_uint = src_fmtl->channels.r.bits == 32 &&
                     isl_format_has_sint_channel(params.src.view.format) &&
                     isl_format_has_uint_channel(params.dst.view.format);
   key.uint32_to_sint = src_fmtl->channels.r.bits == 32 &&
                     isl_format_has_uint_channel(params.src.view.format) &&
                     isl_format_has_sint_channel(params.dst.view.format);

   params.shader_type = key.base.shader_type;
   params.shader_pipeline = key.base.shader_pipeline;

   /* Scaling factors used for bilinear filtering in multisample scaled
    * blits.
    */
   if (params.src.surf.samples == 16)
      key.x_scale = 4.0f;
   else
      key.x_scale = 2.0f;
   key.y_scale = params.src.surf.samples / key.x_scale;

   params.wm_inputs.blit.rect_grid.x1 =
      u_minify(params.src.surf.logical_level0_px.width, src_level) *
      key.x_scale - 1.0f;
   params.wm_inputs.blit.rect_grid.y1 =
      u_minify(params.src.surf.logical_level0_px.height, src_level) *
      key.y_scale - 1.0f;

   struct blt_coords coords = {
      .x = {
         .src0 = src_x0,
         .src1 = src_x1,
         .dst0 = dst_x0,
         .dst1 = dst_x1,
         .mirror = mirror_x
      },
      .y = {
         .src0 = src_y0,
         .src1 = src_y1,
         .dst0 = dst_y0,
         .dst1 = dst_y1,
         .mirror = mirror_y
      }
   };

   do_blorp_blit(batch, &params, &key, &coords);
}

static enum isl_format
get_copy_format_for_bpb(const struct isl_device *isl_dev, unsigned bpb)
{
   /* The choice of UNORM and UINT formats is very intentional here.  Most
    * of the time, we want to use a UINT format to avoid any rounding error
    * in the blit.  For stencil blits, R8_UINT is required by the hardware.
    * (It's the only format allowed in conjunction with W-tiling.)  Also we
    * intentionally use the 4-channel formats whenever we can.  This is so
    * that, when we do a RGB <-> RGBX copy, the two formats will line up
    * even though one of them is 3/4 the size of the other.  The choice of
    * UNORM vs. UINT is also very intentional because we don't have 8 or
    * 16-bit RGB UINT formats until Sky Lake so we have to use UNORM there.
    * Fortunately, the only time we should ever use two different formats in
    * the table below is for RGB -> RGBA blits and so we will never have any
    * UNORM/UINT mismatch.
    */
   if (ISL_GFX_VER(isl_dev) >= 9) {
      switch (bpb) {
      case 8:  return ISL_FORMAT_R8_UINT;
      case 16: return ISL_FORMAT_R8G8_UINT;
      case 24: return ISL_FORMAT_R8G8B8_UINT;
      case 32: return ISL_FORMAT_R8G8B8A8_UINT;
      case 48: return ISL_FORMAT_R16G16B16_UINT;
      case 64: return ISL_FORMAT_R16G16B16A16_UINT;
      case 96: return ISL_FORMAT_R32G32B32_UINT;
      case 128:return ISL_FORMAT_R32G32B32A32_UINT;
      default:
         UNREACHABLE("Unknown format bpb");
      }
   } else {
      switch (bpb) {
      case 8:  return ISL_FORMAT_R8_UINT;
      case 16: return ISL_FORMAT_R8G8_UINT;
      case 24: return ISL_FORMAT_R8G8B8_UNORM;
      case 32: return ISL_FORMAT_R8G8B8A8_UNORM;
      case 48: return ISL_FORMAT_R16G16B16_UNORM;
      case 64: return ISL_FORMAT_R16G16B16A16_UNORM;
      case 96: return ISL_FORMAT_R32G32B32_UINT;
      case 128:return ISL_FORMAT_R32G32B32A32_UINT;
      default:
         UNREACHABLE("Unknown format bpb");
      }
   }
}

/** Returns a UINT format that is CCS-compatible with the given format
 *
 * The PRM's say absolutely nothing about how render compression works.  The
 * only thing they provide is a list of formats on which it is and is not
 * supported.  Empirical testing indicates that the compression is only based
 * on the bit-layout of the format and the channel encoding doesn't matter.
 * So, while texture views don't work in general, you can create a view as
 * long as the bit-layout of the formats are the same.
 *
 * Fortunately, for every render compression capable format, the UINT format
 * with the same bit layout also supports render compression.  This means that
 * we only need to handle UINT formats for copy operations.  In order to do
 * copies between formats with different bit layouts, we attach both with a
 * UINT format and use bit_cast_color() to generate code to do the bit-cast
 * operation between the two bit layouts.
 */
static enum isl_format
get_ccs_compatible_uint_format(const struct isl_format_layout *fmtl)
{
   switch (fmtl->format) {
   case ISL_FORMAT_R32G32B32A32_FLOAT:
   case ISL_FORMAT_R32G32B32A32_SINT:
   case ISL_FORMAT_R32G32B32A32_UINT:
   case ISL_FORMAT_R32G32B32A32_UNORM:
   case ISL_FORMAT_R32G32B32A32_SNORM:
   case ISL_FORMAT_R32G32B32X32_FLOAT:
      return ISL_FORMAT_R32G32B32A32_UINT;

   case ISL_FORMAT_R16G16B16A16_UNORM:
   case ISL_FORMAT_R16G16B16A16_SNORM:
   case ISL_FORMAT_R16G16B16A16_SINT:
   case ISL_FORMAT_R16G16B16A16_UINT:
   case ISL_FORMAT_R16G16B16A16_FLOAT:
   case ISL_FORMAT_R16G16B16X16_UNORM:
   case ISL_FORMAT_R16G16B16X16_FLOAT:
      return ISL_FORMAT_R16G16B16A16_UINT;

   case ISL_FORMAT_R32G32_FLOAT:
   case ISL_FORMAT_R32G32_SINT:
   case ISL_FORMAT_R32G32_UINT:
   case ISL_FORMAT_R32G32_UNORM:
   case ISL_FORMAT_R32G32_SNORM:
      return ISL_FORMAT_R32G32_UINT;

   case ISL_FORMAT_B8G8R8A8_UNORM:
   case ISL_FORMAT_B8G8R8A8_UNORM_SRGB:
   case ISL_FORMAT_R8G8B8A8_UNORM:
   case ISL_FORMAT_R8G8B8A8_UNORM_SRGB:
   case ISL_FORMAT_R8G8B8A8_SNORM:
   case ISL_FORMAT_R8G8B8A8_SINT:
   case ISL_FORMAT_R8G8B8A8_UINT:
   case ISL_FORMAT_B8G8R8X8_UNORM:
   case ISL_FORMAT_B8G8R8X8_UNORM_SRGB:
   case ISL_FORMAT_R8G8B8X8_UNORM:
   case ISL_FORMAT_R8G8B8X8_UNORM_SRGB:
      return ISL_FORMAT_R8G8B8A8_UINT;

   case ISL_FORMAT_R16G16_UNORM:
   case ISL_FORMAT_R16G16_SNORM:
   case ISL_FORMAT_R16G16_SINT:
   case ISL_FORMAT_R16G16_UINT:
   case ISL_FORMAT_R16G16_FLOAT:
      return ISL_FORMAT_R16G16_UINT;

   case ISL_FORMAT_R32_SINT:
   case ISL_FORMAT_R32_UINT:
   case ISL_FORMAT_R32_FLOAT:
   case ISL_FORMAT_R32_UNORM:
   case ISL_FORMAT_R32_SNORM:
      return ISL_FORMAT_R32_UINT;

   case ISL_FORMAT_R11G11B10_FLOAT:
      return ISL_FORMAT_R8G8B8A8_UINT;

   case ISL_FORMAT_B10G10R10A2_UNORM:
   case ISL_FORMAT_B10G10R10A2_UNORM_SRGB:
   case ISL_FORMAT_R10G10B10A2_UNORM:
   case ISL_FORMAT_R10G10B10A2_UINT:
      return ISL_FORMAT_R10G10B10A2_UINT;

   case ISL_FORMAT_R16_SNORM:
   case ISL_FORMAT_R16_SINT:
   case ISL_FORMAT_R16_FLOAT:
      return ISL_FORMAT_R16_UINT;

   case ISL_FORMAT_R8G8_SNORM:
   case ISL_FORMAT_R8G8_SINT:
      return ISL_FORMAT_R8G8_UINT;

   case ISL_FORMAT_R8_SNORM:
   case ISL_FORMAT_R8_SINT:
      return ISL_FORMAT_R8_UINT;

   default:
      UNREACHABLE("Not a compressible format");
   }
}

enum isl_format
blorp_copy_get_color_format(const struct isl_device *isl_dev,
                            enum isl_format surf_format)
{
   const struct isl_format_layout *fmtl = isl_format_get_layout(surf_format);

   if (ISL_GFX_VER(isl_dev) >= 9 && ISL_GFX_VER(isl_dev) <= 12 &&
       fmtl->colorspace != ISL_COLORSPACE_YUV &&
       fmtl->uniform_channel_type != ISL_SNORM &&
       fmtl->uniform_channel_type != ISL_UFLOAT &&
       fmtl->uniform_channel_type != ISL_SFLOAT &&
       fmtl->uniform_channel_type != ISL_SINT &&
       surf_format != ISL_FORMAT_R16G16B16A16_UNORM /* TODO */ &&
       isl_format_supports_rendering(isl_dev->info, surf_format)) {
      /* On gfx9-12, avoid format re-interpretation in order to support
       * non-zero clear colors when copying. On gfx12, also do this in order
       * to properly interpret the clear color of imported dmabuf surfaces.
       */
      return surf_format;
   } else if (ISL_GFX_VERX10(isl_dev) <= 120 &&
              isl_format_supports_ccs_e(isl_dev->info, surf_format)) {
      /* On gfx9-12.0, choose a copy format that maintains compatibility with
       * CCS_E. Although format reinterpretation doesn't affect compression
       * support while rendering on gfx12.0, the sampler does have reduced
       * support for compression when the bits-per-channel changes.
       */
      return get_ccs_compatible_uint_format(fmtl);
   } else {
      return get_copy_format_for_bpb(isl_dev, fmtl->bpb);
   }
}

void
blorp_surf_convert_to_uncompressed(const struct isl_device *isl_dev,
                                   struct blorp_surface_info *info,
                                   uint32_t *x, uint32_t *y,
                                   uint32_t *width, uint32_t *height)
{
   const struct isl_format_layout *fmtl =
      isl_format_get_layout(info->surf.format);

   assert(fmtl->bw > 1 || fmtl->bh > 1);

   /* This should be the first modification made to the surface */
   assert(info->tile_x_sa == 0 && info->tile_y_sa == 0);

   if (width && height) {
      ASSERTED const uint32_t level_width =
         u_minify(info->surf.logical_level0_px.width, info->view.base_level);
      ASSERTED const uint32_t level_height =
         u_minify(info->surf.logical_level0_px.height, info->view.base_level);
      assert(*width % fmtl->bw == 0 || *x + *width == level_width);
      assert(*height % fmtl->bh == 0 || *y + *height == level_height);
      *width = DIV_ROUND_UP(*width, fmtl->bw);
      *height = DIV_ROUND_UP(*height, fmtl->bh);
   }

   if (x && y) {
      assert(*x % fmtl->bw == 0);
      assert(*y % fmtl->bh == 0);
      *x /= fmtl->bw;
      *y /= fmtl->bh;
   }

   /* We only want one level and slice */
   info->view.levels = 1;
   info->view.array_len = 1;

   if (info->surf.dim == ISL_SURF_DIM_3D) {
      /* Roll the Z offset into the image view */
      info->view.base_array_layer += info->z_offset;
      info->z_offset = 0;
   }

   uint64_t offset_B;
   ASSERTED bool ok =
      isl_surf_get_uncompressed_surf(isl_dev, &info->surf, &info->view,
                                     &info->surf, &info->view, &offset_B,
                                     &info->tile_x_sa, &info->tile_y_sa);
   assert(ok);
   info->addr.offset += offset_B;

   /* BLORP doesn't use the actual intratile offsets.  Instead, it needs the
    * surface to be a bit bigger and we offset the vertices instead. Standard
    * tilings don't need intratile offsets because each subresource is aligned
    * to a bpb-based tile boundary or miptail slot offset.
    */
  if (isl_tiling_is_64(info->surf.tiling) ||
      isl_tiling_is_std_y(info->surf.tiling)) {
      assert(info->tile_x_sa == 0 && info->tile_y_sa == 0);
   } else {
      assert(info->surf.dim == ISL_SURF_DIM_2D);
      assert(info->surf.logical_level0_px.array_len == 1);
      info->surf.logical_level0_px.w += info->tile_x_sa;
      info->surf.logical_level0_px.h += info->tile_y_sa;
      info->surf.phys_level0_sa.w += info->tile_x_sa;
      info->surf.phys_level0_sa.h += info->tile_y_sa;
   }
}

bool
blorp_copy_supports_compute(struct blorp_context *blorp,
                            const struct isl_surf *src_surf,
                            const struct isl_surf *dst_surf,
                            enum isl_aux_usage dst_aux_usage)
{
   return blorp_blit_supports_compute(blorp, src_surf, dst_surf, dst_aux_usage);
}

void
blorp_copy_get_formats(const struct isl_device *isl_dev,
                       const struct isl_surf *src_surf,
                       const struct isl_surf *dst_surf,
                       enum isl_format *src_view_format,
                       enum isl_format *dst_view_format)
{
   const struct isl_format_layout *src_fmtl =
      isl_format_get_layout(src_surf->format);
   const struct isl_format_layout *dst_fmtl =
      isl_format_get_layout(dst_surf->format);

   if (ISL_GFX_VER(isl_dev) >= 8 &&
       isl_surf_usage_is_depth(src_surf->usage)) {
      /* In order to use HiZ, we have to use the real format for the source.
       */
      *src_view_format = src_surf->format;
      *dst_view_format = src_surf->format;
   } else if (ISL_GFX_VER(isl_dev) >= 7 &&
              isl_surf_usage_is_depth(dst_surf->usage)) {
      /* On Gfx7 and higher, we use actual depth writes for blits into depth
       * buffers so we need the real format.
       */
      *src_view_format = dst_surf->format;
      *dst_view_format = dst_surf->format;

      /* Some generations like Gfx9/11 have a CCS_E dependent on the
       * bits-per-channel of the format. If we reinterpret a R32 source image
       * as D24_UNORM we'll read invalid data from the sampler.
       *
       * Instead keep the source as R32_UINT (so it stays bits-per-channel
       * compatible according to the VK_KHR_maintenance8 copy operations
       * compatibility format list) and have the shader do a conversion
       * to a floating point value out of 24bits of data to write into the
       * depth output.
       */
      if (dst_surf->format == ISL_FORMAT_R24_UNORM_X8_TYPELESS &&
          src_surf->format != ISL_FORMAT_R24_UNORM_X8_TYPELESS) {
         *src_view_format = ISL_FORMAT_R32_UINT;
      }
   } else if (isl_surf_usage_is_depth_or_stencil(src_surf->usage) ||
              isl_surf_usage_is_depth_or_stencil(dst_surf->usage)) {
      assert(src_fmtl->bpb == dst_fmtl->bpb);
      *src_view_format =
      *dst_view_format =
         get_copy_format_for_bpb(isl_dev, dst_fmtl->bpb);
   } else {
      *src_view_format =
         blorp_copy_get_color_format(isl_dev, src_surf->format);
      *dst_view_format =
         blorp_copy_get_color_format(isl_dev, dst_surf->format);
   }
}

static int
get_max_format_scale(const struct isl_device *isl_dev,
                     const struct blorp_surface_info *info,
                     uint32_t x, uint32_t width, uint32_t height,
                     bool unpadded)
{
   const bool full_width = u_minify(info->surf.logical_level0_px.width,
                                    info->view.base_level) == width;
   const bool full_height = u_minify(info->surf.logical_level0_px.height,
                                     info->view.base_level) == height;

   if (info->aux_usage != ISL_AUX_USAGE_NONE) {
      /* CCS_D, MCS and HIZ don't support changing the format bpb. FCV_CCS_E
       * could be supported, but it requires more collaboration between BLORP
       * and drivers.
       */
      if (info->aux_usage != ISL_AUX_USAGE_CCS_E)
         return 1;

      /* CCS_E on gfx9-11 requires the surface's bpc not change. */
      if (isl_dev->info->ver <= 11)
         return 1;

      /* On gfx12, CCS_E can survive a change in the format bpb. However, the
       * RenderCompressionFormat must not change.
       */
      if (isl_dev->info->ver == 12) {
         if (info->view.usage & (ISL_SURF_USAGE_RENDER_TARGET_BIT |
                                 ISL_SURF_USAGE_STORAGE_BIT)) {
            /* For some destinations, the clear color can be ignored only if
             * the entire slice is covered.
             */
            if (!full_width || !full_height)
               return 1;
         } else if (info->view.usage & ISL_SURF_USAGE_TEXTURE_BIT) {
            /* For textures, a replicated pixel must have been provided. */
            if (!info->has_replicated_pixel)
               return 1;
         }
      }
   }

   /* We don't support depth/stencil. */
   if (isl_surf_usage_is_depth_or_stencil(info->surf.usage))
      return 1;

   /* We don't support NPOT formats */
   const struct isl_format_layout *surf_fmtl =
      isl_format_get_layout(info->surf.format);
   if (surf_fmtl->bpb % 3 == 0)
      return 1;

   struct isl_tile_info surf_tile_info;
   isl_surf_get_tile_info(&info->surf, &surf_tile_info);
   uint32_t lod1_w = u_minify(info->surf.logical_level0_px.width, 1);
   uint32_t phys_lod1_w = align(lod1_w, info->surf.image_alignment_el.w);

   int max_bpb = 128;
   /* From the Sandybridge PRM, Volume 1, Part 2, page 32:
    *
    *    "NOTE: 128BPE Format Color Buffer ( render target ) MUST be either
    *     TileX or Linear."
    *
    * This is necessary all the way back to 965, but is permitted on Gfx7+.
    */
   if (ISL_GFX_VER(isl_dev) < 7 && info->surf.tiling == ISL_TILING_Y0)
      max_bpb = 64;

   /* Find the format size which satisfies alignment requirements. */
   for (; max_bpb >= surf_fmtl->bpb; max_bpb /= 2) {
      if (info->view.base_level >= 1 &&
          phys_lod1_w * surf_fmtl->bpb % max_bpb)
         continue;

      if (x * surf_fmtl->bpb % max_bpb)
         continue;

      if (info->tile_x_sa * surf_fmtl->bpb % max_bpb)
         continue;

      if (width * surf_fmtl->bpb % max_bpb) {
         /* For buffers/linear surfaces, don't ignore the width. Doing so may
          * lead to accessing buffer memory out of bounds.
          */
         if (info->surf.tiling == ISL_TILING_LINEAR)
            continue;

         /* Partial width copies must be aligned to avoid stomping on
          * neighboring pixels.
          */
         if (!full_width)
            continue;

         /* No need to scale the format if we'd only add more padding. */
         if (width * surf_fmtl->bpb < max_bpb)
            continue;
      }

      if (!(info->view.usage & ISL_SURF_USAGE_TEXTURE_BIT) ||
           (isl_dev->requires_padding && unpadded)) {
         /* All surface types except for padded textures need their row pitch
          * aligned to the pixel block size.
          */
         if (info->surf.row_pitch_B * 8 % max_bpb)
            continue;
      }

      if (info->view.usage & (ISL_SURF_USAGE_RENDER_TARGET_BIT |
                              ISL_SURF_USAGE_STORAGE_BIT)) {
         /* Some destinations require the base address be aligned to the pixel
          * block size.
          */
         if (info->addr.offset * 8 % max_bpb)
            continue;
      }

      struct isl_tile_info tile_info;
      isl_tiling_get_info(info->surf.tiling, info->surf.dim,
                          info->surf.msaa_layout, max_bpb, info->surf.samples,
                          &tile_info);
      assert(surf_tile_info.swiz_count == tile_info.swiz_count);
      if (memcmp(surf_tile_info.swiz, tile_info.swiz, tile_info.swiz_count))
         continue;

      if (info->surf.miptail_start_level < info->view.base_level &&
          surf_tile_info.max_miptail_levels != tile_info.max_miptail_levels)
         continue;

      return max_bpb / surf_fmtl->bpb;
   }

   UNREACHABLE("Invalid loop condition above");
}

static void
format_scale_copy(const struct isl_device *isl_dev,
                  struct blorp_surface_info *info,
                  uint32_t *x, uint32_t *width, int scale)
{
   uint32_t orig_fmt_bpb = isl_format_get_layout(info->surf.format)->bpb;
   info->view.format = get_copy_format_for_bpb(isl_dev, orig_fmt_bpb * scale);

   if (isl_tiling_is_64(info->surf.tiling) ||
       isl_tiling_is_std_y(info->surf.tiling)) {
      blorp_surf_convert_to_single_level_tile(isl_dev, info, true);
   } else {
      blorp_surf_convert_to_single_slice(isl_dev, info);

      assert(info->surf.logical_level0_px.w == info->surf.phys_level0_sa.w);
      info->surf.logical_level0_px.w = info->surf.phys_level0_sa.w =
         DIV_ROUND_UP(info->surf.logical_level0_px.w, scale);
      info->tile_x_sa /= scale;
      info->surf.format = info->view.format;
   }

   *x /= scale;
   *width = DIV_ROUND_UP(*width, scale);
}

void
blorp_copy(struct blorp_batch *batch,
           const struct blorp_surf *src_surf,
           unsigned src_level, unsigned src_layer,
           const struct blorp_surf *dst_surf,
           unsigned dst_level, unsigned dst_layer,
           uint32_t src_x, uint32_t src_y,
           uint32_t dst_x, uint32_t dst_y,
           uint32_t src_width, uint32_t src_height)
{
   const struct isl_device *isl_dev = batch->blorp->isl_dev;
   const struct intel_device_info *devinfo = isl_dev->info;
   struct blorp_params params;

   if (src_width == 0 || src_height == 0)
      return;

   blorp_params_init(&params, batch->blorp);
   params.op = BLORP_OP_COPY;

   const bool compute = batch->flags & BLORP_BATCH_USE_COMPUTE;
   if (compute) {
      assert(blorp_copy_supports_compute(batch->blorp,
                                         src_surf->surf, dst_surf->surf,
                                         dst_surf->aux_usage));
   } else if (batch->flags & BLORP_BATCH_USE_BLITTER) {
      assert(blorp_copy_supports_blitter(batch->blorp,
                                         src_surf->surf, dst_surf->surf,
                                         src_surf->aux_usage,
                                         dst_surf->aux_usage));
   }

   blorp_surface_info_init(batch, &params.src, src_surf, src_level,
                           src_layer, ISL_FORMAT_UNSUPPORTED, false);
   blorp_surface_info_init(batch, &params.dst, dst_surf, dst_level,
                           dst_layer, ISL_FORMAT_UNSUPPORTED, true);

   struct blorp_blit_prog_key key;
   BLORP_KEY_INIT(key, batch->blorp, BLORP_SHADER_TYPE_COPY,
                  (compute ? BLORP_SHADER_PIPELINE_COMPUTE :
                             BLORP_SHADER_PIPELINE_RENDER));
   key.filter = BLORP_FILTER_NONE;
   key.need_src_offset = src_surf->tile_x_sa || src_surf->tile_y_sa;
   key.need_dst_offset = dst_surf->tile_x_sa || dst_surf->tile_y_sa;

   params.shader_type = key.base.shader_type;
   params.shader_pipeline = key.base.shader_pipeline;

   const struct isl_format_layout *src_fmtl =
      isl_format_get_layout(params.src.surf.format);
   const struct isl_format_layout *dst_fmtl =
      isl_format_get_layout(params.dst.surf.format);

   assert(params.src.aux_usage == ISL_AUX_USAGE_NONE ||
          params.src.aux_usage == ISL_AUX_USAGE_HIZ ||
          params.src.aux_usage == ISL_AUX_USAGE_HIZ_CCS_WT ||
          params.src.aux_usage == ISL_AUX_USAGE_ZCS ||
          params.src.aux_usage == ISL_AUX_USAGE_MCS ||
          params.src.aux_usage == ISL_AUX_USAGE_MCS_CCS ||
          params.src.aux_usage == ISL_AUX_USAGE_CCS_E ||
          params.src.aux_usage == ISL_AUX_USAGE_FCV_CCS_E ||
          params.src.aux_usage == ISL_AUX_USAGE_STC_CCS);

   /* The public interface states that the value returned by the format query
    * is valid for losslessly compressed surfaces. Internally, we're free to
    * use it as a starting point for all surfaces.
    */
   blorp_copy_get_formats(isl_dev, &params.src.surf, &params.dst.surf,
                          &params.src.view.format, &params.dst.view.format);

   if (isl_aux_usage_has_fast_clears(params.src.aux_usage) &&
       isl_dev->ss.clear_color_state_size > 0) {
      /* Depending on the format, the sampler may change the location from
       * which it fetches the clear color. This can be a problem in some
       * cases, so make sure that the view format won't change the location.
       */
      ASSERTED enum isl_format src_view_fmt = params.src.view.format;
      ASSERTED enum isl_format src_surf_fmt = params.src.surf.format;
      ASSERTED bool hiz = params.src.aux_usage == ISL_AUX_USAGE_HIZ_CCS_WT;
      assert(isl_get_sampler_clear_field_offset(devinfo, src_view_fmt, hiz) ==
             isl_get_sampler_clear_field_offset(devinfo, src_surf_fmt, hiz));
   }

   if (src_fmtl->bw > 1 || src_fmtl->bh > 1) {
      blorp_surf_convert_to_uncompressed(batch->blorp->isl_dev, &params.src,
                                         &src_x, &src_y,
                                         &src_width, &src_height);
      key.need_src_offset = true;
   }

   if (dst_fmtl->bw > 1 || dst_fmtl->bh > 1) {
      blorp_surf_convert_to_uncompressed(batch->blorp->isl_dev, &params.dst,
                                         &dst_x, &dst_y, NULL, NULL);
      key.need_dst_offset = true;
   }

   /* Once both surfaces are stomped to uncompressed as needed, the
    * destination size is the same as the source size unless we're copying
    * between YUV and color images. We'll remove any differences in the
    * process of using the largest format possible for the copy.
    */
   uint32_t dst_width = src_width;
   uint32_t dst_height = src_height;
   if (isl_format_is_yuv(src_fmtl->format) !=
       isl_format_is_yuv(dst_fmtl->format))
      dst_width = src_width * src_fmtl->bpb / dst_fmtl->bpb;

   int max_fmt_scale_src = get_max_format_scale(isl_dev, &params.src, src_x,
                                                src_width, src_height,
                                                batch->flags & BLORP_BATCH_SRC_UNPADDED);
   int max_fmt_scale_dst = get_max_format_scale(isl_dev, &params.dst, dst_x,
                                                dst_width, dst_height,
                                                false);
   int copy_fmt_bpb = MIN2(src_fmtl->bpb * max_fmt_scale_src,
                           dst_fmtl->bpb * max_fmt_scale_dst);

   if (src_fmtl->bpb < copy_fmt_bpb) {
      format_scale_copy(isl_dev, &params.src, &src_x, &src_width,
                        copy_fmt_bpb / src_fmtl->bpb);
      key.need_src_offset = true;
   }

   if (dst_fmtl->bpb < copy_fmt_bpb) {
      format_scale_copy(isl_dev, &params.dst, &dst_x, &dst_width,
                        copy_fmt_bpb / dst_fmtl->bpb);
      key.need_dst_offset = true;
   }

   assert(src_width == dst_width);

   if (params.src.view.format != params.dst.view.format) {
      enum isl_format src_cast_format = params.src.view.format;
      enum isl_format dst_cast_format = params.dst.view.format;

      /* The BLORP bitcast code gets confused by RGB formats.  Just treat them
       * as RGBA and then everything will be happy.  This is perfectly safe
       * because BLORP likes to treat things as if they have vec4 colors all
       * the time anyway.
       */
      if (isl_format_get_layout(src_cast_format)->bpb % 3 == 0)
         src_cast_format = isl_format_rgb_to_rgba(src_cast_format);
      if (isl_format_get_layout(dst_cast_format)->bpb % 3 == 0)
         dst_cast_format = isl_format_rgb_to_rgba(dst_cast_format);

      if (src_cast_format != dst_cast_format) {
         key.format_bit_cast = true;
         key.src_format = src_cast_format;
         key.dst_format = dst_cast_format;
      }
   }

   if (batch->flags & BLORP_BATCH_USE_BLITTER) {
      if (devinfo->verx10 < 125) {
         blorp_surf_convert_to_single_slice(isl_dev, &params.dst);
         blorp_surf_convert_to_single_slice(isl_dev, &params.src);
      }

      params.x0 = dst_x;
      params.x1 = dst_x + dst_width;
      params.y0 = dst_y;
      params.y1 = dst_y + dst_height;
      params.wm_inputs.blit.coord_transform[0].offset = dst_x - (float)src_x;
      params.wm_inputs.blit.coord_transform[1].offset = dst_y - (float)src_y;
      params.wm_inputs.blit.coord_transform[0].multiplier = 1.0f;
      params.wm_inputs.blit.coord_transform[1].multiplier = 1.0f;

      batch->blorp->exec(batch, &params);
      return;
   }

   struct blt_coords coords = {
      .x = {
         .src0 = src_x,
         .src1 = src_x + src_width,
         .dst0 = dst_x,
         .dst1 = dst_x + dst_width,
         .mirror = false
      },
      .y = {
         .src0 = src_y,
         .src1 = src_y + src_height,
         .dst0 = dst_y,
         .dst1 = dst_y + dst_height,
         .mirror = false
      }
   };

   do_blorp_blit(batch, &params, &key, &coords);
}

void
blorp_buffer_copy(struct blorp_batch *batch,
                  struct blorp_address src,
                  struct blorp_address dst,
                  uint64_t size)
{
   struct isl_surf surf;
   struct blorp_surf src_blorp_surf = {
      .surf = &surf,
      .addr = src,
   };

   struct blorp_surf dst_blorp_surf = {
      .surf = &surf,
      .addr = dst,
   };

   while (size != 0) {
      isl_surf_from_mem(batch->blorp->isl_dev, &surf,
                        src_blorp_surf.addr.offset |
                        dst_blorp_surf.addr.offset, size, ISL_TILING_LINEAR);

      for (int i = 0; i < surf.logical_level0_px.a; i++) {
         blorp_copy(batch,
                    &src_blorp_surf, 0, i,
                    &dst_blorp_surf, 0, i, 0, 0, 0, 0,
                    surf.logical_level0_px.w,
                    surf.logical_level0_px.h);
      }

      size -= surf.size_B;
      src_blorp_surf.addr.offset += surf.size_B;
      dst_blorp_surf.addr.offset += surf.size_B;
   }
}
