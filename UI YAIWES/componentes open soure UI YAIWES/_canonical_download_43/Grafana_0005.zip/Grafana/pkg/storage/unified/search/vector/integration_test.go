package vector

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/grafana/grafana/pkg/setting"
	"github.com/grafana/grafana/pkg/storage/unified/search/vector/filter"
	"github.com/grafana/grafana/pkg/storage/unified/sql/db/dbimpl"
	"github.com/grafana/grafana/pkg/util/testutil"
	"github.com/grafana/grafana/pkg/util/xorm"
)

const testModel = "test-model"
const testResource = "dashboards"

var testSubtree = subtreeName(testResource)

// To run: start the pgvector devenv (localhost:5433) and
//
//	PGVECTOR_TEST_DB="host=localhost port=5433 dbname=grafana_vectors user=grafana password=password sslmode=disable" \
//	  go test -run TestIntegration ./pkg/storage/unified/search/vector/... -v -count=1
func setupIntegrationTest(t *testing.T) (VectorBackend, *xorm.Engine, context.Context) {
	t.Helper()
	testutil.SkipIntegrationTestInShortMode(t)

	connStr := os.Getenv("PGVECTOR_TEST_DB")
	if connStr == "" {
		t.Skip("PGVECTOR_TEST_DB not set, skipping pgvector integration test")
	}

	ctx := context.Background()

	engine, err := xorm.NewEngine("postgres", connStr)
	require.NoError(t, err)
	t.Cleanup(func() {
		if err := engine.Close(); err != nil {
			t.Logf("closing xorm engine: %v", err)
		}
	})

	cfg := setting.NewCfg()
	err = MigrateVectorStore(ctx, engine, cfg)
	require.NoError(t, err)

	database := dbimpl.NewDB(engine.DB().DB, engine.Dialect().DriverName())
	// interval=0 keeps the promoter idle; promotion tests call Promote(ctx) directly.
	backend := NewPgvectorBackend(ctx, database, 1000, 0, false, engine)

	cleanIntegrationState(t, engine)

	return backend, engine, ctx
}

// cleanIntegrationState drops any `integration-test*` partial indexes, clears
// rows, and resets the checkpoint.
func cleanIntegrationState(t *testing.T, engine *xorm.Engine) {
	t.Helper()
	ctx := context.Background()

	indexPrefix := fmt.Sprintf("%s_integration_test", testResource)
	rows, err := engine.DB().QueryContext(ctx, `
		SELECT c.relname FROM pg_class c
		JOIN pg_index i ON i.indexrelid = c.oid
		JOIN pg_class t ON t.oid = i.indrelid
		WHERE t.relname = $1 AND c.relkind = 'i' AND c.relname LIKE $2`,
		testSubtree, indexPrefix+"%")
	require.NoError(t, err)
	var indexes []string
	for rows.Next() {
		var n string
		require.NoError(t, rows.Scan(&n))
		indexes = append(indexes, n)
	}
	_ = rows.Close()

	for _, idx := range indexes {
		_, _ = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP INDEX IF EXISTS %s`, idx))
	}

	_, _ = engine.DB().ExecContext(ctx,
		fmt.Sprintf(`DELETE FROM %s WHERE namespace LIKE 'integration-test%%'`, testSubtree))
	_, _ = engine.DB().ExecContext(ctx,
		`DELETE FROM vector_promoted WHERE namespace LIKE 'integration-test%'`)
	_, _ = engine.DB().ExecContext(ctx,
		`DELETE FROM query_embedding_cache WHERE namespace LIKE 'integration-test%'`)
	_, _ = engine.DB().ExecContext(ctx,
		`DELETE FROM vector_search_rate_buckets WHERE namespace LIKE 'integration-test%'`)
	_, _ = engine.DB().ExecContext(ctx,
		`UPDATE vector_latest_rv SET latest_rv = 0 WHERE id = 1`)
	_, _ = engine.DB().ExecContext(ctx,
		`DELETE FROM vector_backfill_jobs WHERE model = $1`, testModel)
}

func TestIntegrationVectorUpsertAndSearch(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	// Metadata mirrors the dashboard embed extractor's real schema:
	// scalar datasourceUid/language keys (embed/dashboard/extractor.go).
	vectors := []Vector{
		{
			Namespace: "integration-test", Resource: testResource, UID: "dash-1", Title: "CPU Dashboard", Subresource: "panel/1",
			ResourceVersion: 10, Folder: "folder-a",
			Content:   "CPU usage over time for production servers",
			Metadata:  json.RawMessage(`{"datasourceUid":"prom-1","language":"promql"}`),
			Embedding: makeEmbedding(0.9, 0.1), Model: testModel,
		},
		{
			Namespace: "integration-test", Resource: testResource, UID: "dash-1", Title: "CPU Dashboard", Subresource: "panel/2",
			ResourceVersion: 10, Folder: "folder-a",
			Content:   "Memory usage alerts dashboard",
			Metadata:  json.RawMessage(`{"datasourceUid":"prom-1","language":"promql"}`),
			Embedding: makeEmbedding(0.1, 0.9), Model: testModel,
		},
		{
			Namespace: "integration-test", Resource: testResource, UID: "dash-2", Title: "Logs Dashboard", Subresource: "panel/1",
			ResourceVersion: 20, Folder: "folder-b",
			Content:   "Log volume by service",
			Metadata:  json.RawMessage(`{"datasourceUid":"loki-1","language":"logql"}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		},
	}

	require.NoError(t, backend.Upsert(ctx, vectors))

	results, err := backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.85, 0.15), 10)
	require.NoError(t, err)
	require.GreaterOrEqual(t, len(results), 3)
	assert.Equal(t, "dash-1", results[0].UID)
	assert.Equal(t, "CPU Dashboard", results[0].Title)
	assert.Equal(t, "panel/1", results[0].Subresource)

	results, err = backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "uid", Values: []string{"dash-2"}})
	require.NoError(t, err)
	require.Len(t, results, 1)
	assert.Equal(t, "dash-2", results[0].UID)

	results, err = backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "folder", Values: []string{"folder-a"}})
	require.NoError(t, err)
	require.Len(t, results, 2)

	results, err = backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "language", Values: []string{"logql"}})
	require.NoError(t, err)
	require.Len(t, results, 1)
	assert.Equal(t, "dash-2", results[0].UID)
}

// Metadata containment must match regardless of how the writer shaped the
// value: the dashboard embed extractor stores scalars while external
// collections store arrays, and both live in the same column.
func TestIntegrationMetadataFilterShapes(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	vectors := []Vector{
		{
			Namespace: "integration-test-shapes", Resource: testResource, UID: "scalar-dash", Title: "Scalar", Subresource: "panel/1",
			ResourceVersion: 1, Folder: "f",
			Content:   "scalar-shaped metadata like the embed extractor writes",
			Metadata:  json.RawMessage(`{"datasourceUid":"prom-1","language":"promql"}`),
			Embedding: makeEmbedding(0.9, 0.1), Model: testModel,
		},
		{
			Namespace: "integration-test-shapes", Resource: testResource, UID: "array-dash", Title: "Array", Subresource: "chunk/1",
			ResourceVersion: 1, Folder: "f",
			Content:   "array-shaped metadata like external collections write",
			Metadata:  json.RawMessage(`{"datasourceUid":["prom-1","prom-2"],"language":["promql"]}`),
			Embedding: makeEmbedding(0.8, 0.2), Model: testModel,
		},
		{
			Namespace: "integration-test-shapes", Resource: testResource, UID: "other-dash", Title: "Other", Subresource: "panel/1",
			ResourceVersion: 1, Folder: "f",
			Content:   "different datasource entirely",
			Metadata:  json.RawMessage(`{"datasourceUid":"loki-1","language":"logql"}`),
			Embedding: makeEmbedding(0.7, 0.3), Model: testModel,
		},
	}
	require.NoError(t, backend.Upsert(ctx, vectors))

	uids := func(rs []VectorSearchResult) []string {
		out := make([]string, 0, len(rs))
		for _, r := range rs {
			out = append(out, r.UID)
		}
		return out
	}

	// one value matches both storage shapes
	results, err := backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "datasourceUid", Values: []string{"prom-1"}})
	require.NoError(t, err)
	assert.ElementsMatch(t, []string{"scalar-dash", "array-dash"}, uids(results))

	// scalar-only match
	results, err = backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "language", Values: []string{"logql"}})
	require.NoError(t, err)
	assert.ElementsMatch(t, []string{"other-dash"}, uids(results))

	// array element beyond the first still matches
	results, err = backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "datasourceUid", Values: []string{"prom-2"}})
	require.NoError(t, err)
	assert.ElementsMatch(t, []string{"array-dash"}, uids(results))

	// multiple values are IN semantics (any-of), across shapes
	results, err = backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "datasourceUid", Values: []string{"prom-1", "loki-1"}})
	require.NoError(t, err)
	assert.ElementsMatch(t, []string{"scalar-dash", "array-dash", "other-dash"}, uids(results))

	// two filters AND together
	results, err = backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "datasourceUid", Values: []string{"prom-1"}},
		SearchFilter{Field: "language", Values: []string{"promql"}})
	require.NoError(t, err)
	assert.ElementsMatch(t, []string{"scalar-dash", "array-dash"}, uids(results))

	// empty-values filter is skipped, not rendered as invalid SQL
	results, err = backend.Search(ctx, "integration-test-shapes", testModel, testResource, makeEmbedding(0.5, 0.5), 10,
		SearchFilter{Field: "datasourceUid", Values: []string{}})
	require.NoError(t, err)
	assert.Len(t, results, 3)
}

func TestIntegrationVectorDeleteSubresources(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	err := backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "dash", Title: "Dash", Subresource: "panel/1",
			ResourceVersion: 10, Content: "panel one", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
		{Namespace: "integration-test", Resource: testResource, UID: "dash", Title: "Dash", Subresource: "panel/2",
			ResourceVersion: 10, Content: "panel two", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
		{Namespace: "integration-test", Resource: testResource, UID: "dash", Title: "Dash", Subresource: "panel/3",
			ResourceVersion: 10, Content: "panel three", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
	})
	require.NoError(t, err)

	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash")
	require.NoError(t, err)
	require.Len(t, stored, 3)

	current := map[string]string{"panel/1": "panel one"}
	var toDelete []string
	for sub := range stored {
		if _, ok := current[sub]; !ok {
			toDelete = append(toDelete, sub)
		}
	}
	require.ElementsMatch(t, []string{"panel/2", "panel/3"}, toDelete)

	err = backend.DeleteSubresources(ctx, "integration-test", testModel, testResource, "dash", toDelete)
	require.NoError(t, err)

	results, err := backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.5, 0.5), 10)
	require.NoError(t, err)
	require.Len(t, results, 1)
	assert.Equal(t, "panel/1", results[0].Subresource)

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash"}})
	require.NoError(t, err)
}

// TestIntegrationDeleteNamespace verifies a tenant wipe removes every row for a
// namespace across embeddings, query cache, rate buckets, and vector_promoted,
// while leaving other namespaces untouched.
func TestIntegrationDeleteNamespace(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	const nsA = "integration-test-a"
	const nsB = "integration-test-b"

	cache := backend.(QueryEmbeddingCache)
	limiter := backend.(RateLimiter)

	seed := func(ns string) {
		require.NoError(t, backend.Upsert(ctx, []Vector{
			{Namespace: ns, Resource: testResource, UID: "dash", Title: "Dash", Subresource: "panel/1",
				ResourceVersion: 10, Content: "content", Metadata: json.RawMessage(`{}`),
				Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
		}))
		require.NoError(t, cache.Put(ctx, ns, testModel, fmt.Sprintf("%064d", 1), makeEmbedding(0.5, 0.5)))
		_, _, err := limiter.Allow(ctx, ns, time.Minute, 100)
		require.NoError(t, err)
		_, err = engine.DB().ExecContext(ctx,
			`INSERT INTO vector_promoted (namespace, resource) VALUES ($1, $2)`, ns, testResource)
		require.NoError(t, err)
	}
	seed(nsA)
	seed(nsB)

	deleted, err := backend.DeleteNamespace(ctx, nsA)
	require.NoError(t, err)
	assert.Equal(t, int64(1), deleted, "one embedding row removed for nsA")

	// nsA gone from every table.
	existsA, err := backend.Exists(ctx, nsA, testModel, testResource, "dash")
	require.NoError(t, err)
	assert.False(t, existsA, "nsA embeddings should be gone")

	countA, err := cache.Count(ctx, nsA)
	require.NoError(t, err)
	assert.Equal(t, int64(0), countA, "nsA query cache should be gone")

	assert.Equal(t, 0, rawCount(t, engine, `SELECT count(*) FROM vector_search_rate_buckets WHERE namespace = $1`, nsA))
	assert.Equal(t, 0, rawCount(t, engine, `SELECT count(*) FROM vector_promoted WHERE namespace = $1`, nsA))

	// nsB untouched.
	existsB, err := backend.Exists(ctx, nsB, testModel, testResource, "dash")
	require.NoError(t, err)
	assert.True(t, existsB, "nsB embeddings should survive")

	countB, err := cache.Count(ctx, nsB)
	require.NoError(t, err)
	assert.Equal(t, int64(1), countB, "nsB query cache should survive")

	assert.Equal(t, 1, rawCount(t, engine, `SELECT count(*) FROM vector_search_rate_buckets WHERE namespace = $1`, nsB))
	assert.Equal(t, 1, rawCount(t, engine, `SELECT count(*) FROM vector_promoted WHERE namespace = $1`, nsB))
}

func rawCount(t *testing.T, engine *xorm.Engine, query string, args ...any) int {
	t.Helper()
	var n int
	require.NoError(t, engine.DB().QueryRowContext(context.Background(), query, args...).Scan(&n))
	return n
}

// TestIntegrationVectorUpsertReplaceSubresources pins the atomic
// "replace the stored subresource set for this UID" contract the
// reconciler depends on: subresources not present in the new write get
// deleted, present ones get rewritten, and nothing about other UIDs or
// the rest of the namespace changes.
func TestIntegrationVectorUpsertReplaceSubresources(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, sub, content string) Vector {
		return Vector{
			Namespace: "integration-test", Resource: testResource, UID: uid, Title: uid,
			Subresource: sub, ResourceVersion: 10, Content: content, Folder: "folder-a",
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		}
	}

	// Seed dash-a with three panels and dash-b with two; dash-b is the
	// "untouched neighbor" used to assert isolation.
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("dash-a", "panel/1", "a-1"),
		mk("dash-a", "panel/2", "a-2"),
		mk("dash-a", "panel/3", "a-3"),
		mk("dash-b", "panel/1", "b-1"),
		mk("dash-b", "panel/2", "b-2"),
	}))

	// Replace dash-a with just panel/1 (rewritten) and panel/4 (new).
	// panel/2 and panel/3 must be deleted in the same transaction.
	// desired = the full surviving set; changed = the rows to write.
	err := backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "dash-a", []Vector{
		mk("dash-a", "panel/1", "a-1 updated"),
		mk("dash-a", "panel/4", "a-4 new"),
	}, nil, []string{"panel/1", "panel/4"})
	require.NoError(t, err)

	stored, folder, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash-a")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{
		"panel/1": "a-1 updated",
		"panel/4": "a-4 new",
	}, stored, "stale subresources removed; new set is the exact replacement")
	assert.Equal(t, "folder-a", folder, "stored folder is returned alongside content")

	// dash-b must be untouched.
	storedB, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash-b")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{
		"panel/1": "b-1",
		"panel/2": "b-2",
	}, storedB, "neighbor UID is isolated from the replace")

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash-a"}})
	require.NoError(t, err)
	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash-b"}})
	require.NoError(t, err)
}

// changed ⊊ desired: only `changed` rows are rewritten, panels in
// `desired` but not `changed` are kept, and nothing is deleted.
func TestIntegrationVectorUpsertReplaceSubresources_PartialUpdate(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, sub, content string) Vector {
		return Vector{
			Namespace: "integration-test", Resource: testResource, UID: uid, Title: uid,
			Subresource: sub, ResourceVersion: 1, Content: content,
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		}
	}

	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("dash", "panel/1", "p1"),
		mk("dash", "panel/2", "p2"),
		mk("dash", "panel/3", "p3"),
	}))

	require.NoError(t, backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "dash",
		[]Vector{
			mk("dash", "panel/2", "p2 v2"), // changed
			mk("dash", "panel/9", "p9"),    // new
		},
		nil,
		[]string{"panel/1", "panel/2", "panel/3", "panel/9"},
	))

	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{
		"panel/1": "p1",    // untouched (kept via desired, not in changed)
		"panel/2": "p2 v2", // rewritten
		"panel/3": "p3",    // untouched
		"panel/9": "p9",    // new
	}, stored)

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash"}})
	require.NoError(t, err)
}

// Empty `changed`: a panel is dropped from `desired` and deleted, with nothing to upsert.
func TestIntegrationVectorUpsertReplaceSubresources_DeleteOnlyNoChange(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, sub, content string) Vector {
		return Vector{
			Namespace: "integration-test", Resource: testResource, UID: uid, Title: uid,
			Subresource: sub, ResourceVersion: 1, Content: content,
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		}
	}

	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("dash", "panel/1", "p1"),
		mk("dash", "panel/2", "p2"),
	}))

	// No changed vectors; desired drops panel/2.
	require.NoError(t, backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "dash",
		nil, nil, []string{"panel/1"}))

	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{"panel/1": "p1"}, stored)

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash"}})
	require.NoError(t, err)
}

// TestIntegrationVectorUpsertReplaceSubresources_EmptyInput is the
// no-op early-return path. Existing rows stay put.
func TestIntegrationVectorUpsertReplaceSubresources_EmptyInput(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	require.NoError(t, backend.Upsert(ctx, []Vector{{
		Namespace: "integration-test", Resource: testResource, UID: "dash", Title: "Dash",
		Subresource: "panel/1", ResourceVersion: 1, Content: "untouched",
		Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
	}}))

	require.NoError(t, backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "dash", nil, nil, nil))

	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{"panel/1": "untouched"}, stored)

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash"}})
	require.NoError(t, err)
}

// TestIntegrationVectorUpsertReplaceSubresources_AtomicOnValidationError
// pins the all-or-nothing contract: when a vector in the batch fails
// validation, no rows in the batch are persisted and no stale rows
// are deleted. The reconciler depends on this so a half-applied
// dashboard never appears in search.
func TestIntegrationVectorUpsertReplaceSubresources_AtomicOnValidationError(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, sub, content string) Vector {
		return Vector{
			Namespace: "integration-test", Resource: testResource, UID: uid, Title: uid,
			Subresource: sub, ResourceVersion: 1, Content: content,
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		}
	}

	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("dash", "panel/1", "v1"),
		mk("dash", "panel/2", "v1"),
	}))

	// Second vector has empty Title — Validate() rejects it.
	bad := mk("dash", "panel/2", "v2-bad")
	bad.Title = ""
	err := backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "dash", []Vector{
		mk("dash", "panel/1", "v2"),
		bad,
	}, nil, []string{"panel/1", "panel/2"})
	require.Error(t, err)

	// State is unchanged: panel/1 still has v1 content, panel/2 still present.
	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{"panel/1": "v1", "panel/2": "v1"}, stored,
		"failed batch leaves no half-applied state")

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"dash"}})
	require.NoError(t, err)
}

func TestIntegrationVectorExists(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	exists, err := backend.Exists(ctx, "integration-test", testModel, testResource, "exists-dash")
	require.NoError(t, err)
	assert.False(t, exists, "no rows yet, Exists should be false")

	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "exists-dash", Title: "T",
			Subresource: "panel/1", ResourceVersion: 1, Content: "x",
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
	}))

	exists, err = backend.Exists(ctx, "integration-test", testModel, testResource, "exists-dash")
	require.NoError(t, err)
	assert.True(t, exists, "after upsert Exists should be true")

	exists, err = backend.Exists(ctx, "integration-test", testModel, testResource, "nonexistent-dash")
	require.NoError(t, err)
	assert.False(t, exists)

	exists, err = backend.Exists(ctx, "integration-test", "different-model", testResource, "exists-dash")
	require.NoError(t, err)
	assert.False(t, exists, "different model should be treated as not-exists")
}

func TestIntegrationVectorCountStoredEmbeddings(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	// Counts are global, and cleanIntegrationState only wipes the
	// integration-test namespaces, so assert on the delta.
	countFor := func(t *testing.T, model string) int64 {
		t.Helper()
		counts, err := backend.CountStoredEmbeddings(ctx)
		require.NoError(t, err)
		for _, c := range counts {
			if c.Resource == testResource && c.Model == model {
				return c.Count
			}
		}
		return 0
	}

	before := countFor(t, testModel)
	beforeOther := countFor(t, "other-model")

	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "count-dash", Title: "T",
			Subresource: "panel/1", ResourceVersion: 1, Content: "x",
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
		{Namespace: "integration-test", Resource: testResource, UID: "count-dash", Title: "T",
			Subresource: "panel/2", ResourceVersion: 1, Content: "y",
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel},
		{Namespace: "integration-test", Resource: testResource, UID: "count-dash", Title: "T",
			Subresource: "panel/1", ResourceVersion: 1, Content: "z",
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: "other-model"},
	}))

	assert.Equal(t, before+2, countFor(t, testModel))
	assert.Equal(t, beforeOther+1, countFor(t, "other-model"), "rows must be grouped per model")

	_, _, err := backend.DeleteRows(ctx, "integration-test", testModel, testResource,
		DeleteSelector{UIDs: []string{"count-dash"}})
	require.NoError(t, err)
	assert.Equal(t, before, countFor(t, testModel))
	assert.Equal(t, beforeOther+1, countFor(t, "other-model"))
}

// TestIntegrationVectorContentVersion pins the MIN-across-rows contract:
// an absent uid reports exists=false, mixed content_version rows report the
// oldest (MIN), and both Upsert and UpsertReplaceSubresources persist the
// version so a later read reflects it.
func TestIntegrationVectorContentVersion(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	version, exists, err := backend.ContentVersion(ctx, "integration-test", testModel, testResource, "cv-dash")
	require.NoError(t, err)
	assert.False(t, exists, "no rows yet")
	assert.Equal(t, 0, version)

	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "cv-dash", Title: "T",
			Subresource: "panel/1", Content: "p1", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 2},
		{Namespace: "integration-test", Resource: testResource, UID: "cv-dash", Title: "T",
			Subresource: "panel/2", Content: "p2", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 5},
	}))

	version, exists, err = backend.ContentVersion(ctx, "integration-test", testModel, testResource, "cv-dash")
	require.NoError(t, err)
	assert.True(t, exists)
	assert.Equal(t, 2, version, "MIN across the uid's mixed-version rows")

	// UpsertReplaceSubresources round-trips content_version too: panel/1
	// bumps to 9, panel/2 is left untouched (still 5, in desired but not
	// changed) — the new MIN reflects the surviving older row.
	require.NoError(t, backend.UpsertReplaceSubresources(ctx, "integration-test", testModel, testResource, "cv-dash",
		[]Vector{
			{Namespace: "integration-test", Resource: testResource, UID: "cv-dash", Title: "T",
				Subresource: "panel/1", Content: "p1 v2", Metadata: json.RawMessage(`{}`),
				Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 9},
		}, nil, []string{"panel/1", "panel/2"}))

	version, exists, err = backend.ContentVersion(ctx, "integration-test", testModel, testResource, "cv-dash")
	require.NoError(t, err)
	assert.True(t, exists)
	assert.Equal(t, 5, version, "panel/1 now 9, panel/2 unchanged at 5, so MIN is 5")

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"cv-dash"}})
	require.NoError(t, err)
}

// TestIntegrationVectorUpdateContentVersion pins the round-trip contract:
// UpdateContentVersion stamps every subresource row of a uid, regardless of
// their prior (possibly mixed) content_version, and ContentVersion reflects
// the new MIN afterward.
func TestIntegrationVectorUpdateContentVersion(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "uv-dash", Title: "T",
			Subresource: "panel/1", Content: "p1", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 1},
		{Namespace: "integration-test", Resource: testResource, UID: "uv-dash", Title: "T",
			Subresource: "panel/2", Content: "p2", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 2},
	}))

	version, exists, err := backend.ContentVersion(ctx, "integration-test", testModel, testResource, "uv-dash")
	require.NoError(t, err)
	require.True(t, exists)
	assert.Equal(t, 1, version, "MIN across the mixed-version rows before the touch")

	require.NoError(t, backend.UpdateContentVersion(ctx, "integration-test", testModel, testResource, "uv-dash", 5))

	version, exists, err = backend.ContentVersion(ctx, "integration-test", testModel, testResource, "uv-dash")
	require.NoError(t, err)
	require.True(t, exists)
	assert.Equal(t, 5, version, "every row (both panel/1 and panel/2) stamped to the new version")

	// Content itself is untouched — this is a version-only stamp, not a re-embed.
	stored, _, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "uv-dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{"panel/1": "p1", "panel/2": "p2"}, stored)

	_, _, err = backend.DeleteRows(ctx, "integration-test", testModel, testResource, DeleteSelector{UIDs: []string{"uv-dash"}})
	require.NoError(t, err)
}

func TestIntegrationVectorGetLatestRV(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	rv, err := backend.GetLatestRV(ctx)
	require.NoError(t, err)
	assert.Equal(t, int64(0), rv)

	require.NoError(t, backend.SetLatestRV(ctx, 42))
	rv, err = backend.GetLatestRV(ctx)
	require.NoError(t, err)
	assert.Equal(t, int64(42), rv)

	// Monotonic: lower rv is ignored.
	require.NoError(t, backend.SetLatestRV(ctx, 10))
	rv, err = backend.GetLatestRV(ctx)
	require.NoError(t, err)
	assert.Equal(t, int64(42), rv)

	// Higher rv advances.
	require.NoError(t, backend.SetLatestRV(ctx, 100))
	rv, err = backend.GetLatestRV(ctx)
	require.NoError(t, err)
	assert.Equal(t, int64(100), rv)
}

func TestIntegrationVectorCreateBackfillJob(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	require.NoError(t, backend.CreateBackfillJob(ctx, testModel, testResource, 100, 1))

	// Second insert for the same (model, resource) is a no-op (ON CONFLICT
	// DO NOTHING): the original row is preserved, not overwritten with 200.
	require.NoError(t, backend.CreateBackfillJob(ctx, testModel, testResource, 200, 1))

	jobs, err := backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Len(t, jobs, 1, "exactly one job exists after the conflicting insert")
	assert.Equal(t, int64(100), jobs[0].StoppingRV, "original stopping_rv preserved")
}

func TestIntegrationVectorReopenStaleBackfillJobs(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	require.NoError(t, backend.CreateBackfillJob(ctx, testModel, testResource, 100, 1))
	jobs, err := backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Len(t, jobs, 1)
	require.NoError(t, backend.CompleteBackfillJob(ctx, jobs[0].ID))

	// Completed job is invisible to the lister until a version bump reopens it.
	jobs, err = backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Empty(t, jobs)

	// Same content_version: no-op, job stays completed.
	reopened, err := backend.ReopenStaleBackfillJobs(ctx, testModel, testResource, 1, 999)
	require.NoError(t, err)
	assert.False(t, reopened, "same content_version must not reopen")
	jobs, err = backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Empty(t, jobs)

	// Version bump: reopens, resets the cursor/error, advances stopping_rv.
	reopened, err = backend.ReopenStaleBackfillJobs(ctx, testModel, testResource, 2, 999)
	require.NoError(t, err)
	assert.True(t, reopened)
	jobs, err = backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Len(t, jobs, 1)
	assert.False(t, jobs[0].IsComplete)
	assert.Equal(t, int64(999), jobs[0].StoppingRV)
	assert.Empty(t, jobs[0].LastSeenKey)
	assert.Empty(t, jobs[0].LastError)
}

func TestIntegrationVectorReopenStaleBackfillJobs_CoversCatchAllJob(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	// A ''-catch-all job must also be reopened by a builder-scoped call.
	// Seeded with raw SQL: catch-all rows are operator-created by design —
	// CreateBackfillJob validates resource as non-empty.
	_, err := engine.Exec(
		`INSERT INTO vector_backfill_jobs (model, resource, stopping_rv, is_complete, content_version)
		 VALUES ($1, '', 100, TRUE, 1)`, testModel)
	require.NoError(t, err)

	reopened, err := backend.ReopenStaleBackfillJobs(ctx, testModel, testResource, 2, 999)
	require.NoError(t, err)
	assert.True(t, reopened, "the ''-catch-all job must be reopened by a resource-scoped call")

	jobs, err := backend.ListIncompleteBackfillJobs(ctx, testModel)
	require.NoError(t, err)
	require.Len(t, jobs, 1)
	assert.Equal(t, "", jobs[0].Resource)
}

func TestIntegrationVectorReconcilerLock(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	release, acquired, err := backend.TryAcquireReconcilerLock(ctx)
	require.NoError(t, err)
	require.True(t, acquired)
	defer release()

	// Second acquire on the same backend (different connection) must be denied.
	_, acquired2, err := backend.TryAcquireReconcilerLock(ctx)
	require.NoError(t, err)
	require.False(t, acquired2)
}

func TestIntegrationPromoterPromotesLargeTenant(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	const ns = "integration-test-big"
	const threshold = 50
	const nRows = threshold + 10

	vectors := make([]Vector, 0, nRows)
	for i := 0; i < nRows; i++ {
		vectors = append(vectors, Vector{
			Namespace: ns, Resource: testResource, UID: "dash", Title: "Dash", Subresource: fmt.Sprintf("panel/%d", i),
			ResourceVersion: int64(i + 1), Content: fmt.Sprintf("content %d", i),
			Metadata: json.RawMessage(`{}`), Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
		})
	}
	require.NoError(t, backend.Upsert(ctx, vectors))

	idxName := partialHNSWName(testResource, ns)
	require.False(t, indexExists(t, engine, idxName))
	require.Equal(t, nRows, countRowsIn(t, engine, testSubtree, ns))

	database := dbimpl.NewDB(engine.DB().DB, engine.Dialect().DriverName())
	promoter := NewPromoter(database, threshold, 0)
	require.NoError(t, promoter.Promote(ctx))

	require.True(t, indexExists(t, engine, idxName))
	require.Equal(t, nRows, countRowsIn(t, engine, testSubtree, ns))

	results, err := backend.Search(ctx, ns, testModel, testResource, makeEmbedding(0.5, 0.5), 5)
	require.NoError(t, err)
	assert.Len(t, results, 5)
}

func TestIntegrationPromoterSkipsSmallTenant(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	const ns = "integration-test-small"
	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: ns, Resource: testResource, UID: "dash", Title: "Dash", Subresource: "panel/1",
			ResourceVersion: 1, Content: "only row", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.1, 0.1), Model: testModel},
	}))

	database := dbimpl.NewDB(engine.DB().DB, engine.Dialect().DriverName())
	promoter := NewPromoter(database, 100, 0)
	require.NoError(t, promoter.Promote(ctx))

	idxName := partialHNSWName(testResource, ns)
	require.False(t, indexExists(t, engine, idxName),
		"small tenant should not be promoted")
}

func indexExists(t *testing.T, engine *xorm.Engine, idxName string) bool {
	t.Helper()
	var exists bool
	err := engine.DB().QueryRowContext(context.Background(), `
		SELECT EXISTS (
			SELECT 1 FROM pg_class c
			JOIN pg_index i ON i.indexrelid = c.oid
			WHERE c.relname = $1 AND c.relkind = 'i' AND i.indisvalid
		)`, idxName).Scan(&exists)
	require.NoError(t, err)
	return exists
}

func countRowsIn(t *testing.T, engine *xorm.Engine, table, ns string) int {
	t.Helper()
	var n int
	require.NoError(t, engine.DB().QueryRowContext(context.Background(),
		fmt.Sprintf(`SELECT COUNT(*) FROM %s WHERE namespace = $1`, table), ns).Scan(&n))
	return n
}

// makeEmbedding builds a 1024-dim halfvec with the first two values set.
func makeEmbedding(a, b float32) []float32 {
	e := make([]float32, 1024)
	e[0] = a
	e[1] = b
	return e
}

func TestEnsureResourcePartition_RejectsUnsafeResource(t *testing.T) {
	b := &pgvectorBackend{}
	for _, res := range []string{"", "Dashboards", "dash-boards", "a.b", "drop;table", "with space"} {
		require.Error(t, b.EnsureResourcePartition(context.Background(), res),
			"resource %q must be rejected", res)
	}
}

func TestIntegrationVectorEnsureResourcePartition(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	pg := backend.(*pgvectorBackend)

	const res = "testpartition"
	leaf := subtreeName(res)
	idx := leaf + "_metadata_idx"
	drop := func() { _, _ = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP TABLE IF EXISTS %s`, leaf)) }
	drop()
	t.Cleanup(drop)

	// Absent before creation.
	ready, err := pg.resourcePartitionReady(ctx, leaf, idx, "")
	require.NoError(t, err)
	require.False(t, ready)

	// Create it: partition + metadata index both present.
	require.NoError(t, backend.EnsureResourcePartition(ctx, res))
	ready, err = pg.resourcePartitionReady(ctx, leaf, idx, "")
	require.NoError(t, err)
	assert.True(t, ready, "leaf attached as partition and metadata index present")

	// Heals a missing index: drop it, retry must recreate it.
	_, err = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP INDEX IF EXISTS %s`, idx))
	require.NoError(t, err)
	require.NoError(t, backend.EnsureResourcePartition(ctx, res))
	ready, err = pg.resourcePartitionReady(ctx, leaf, idx, "")
	require.NoError(t, err)
	assert.True(t, ready, "missing index recreated on retry")

	// Idempotent: a second call (fast path) is a no-op, no error.
	require.NoError(t, backend.EnsureResourcePartition(ctx, res))

	// Internal partitions never get the ts index.
	var hasFTS bool
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT EXISTS (SELECT 1 FROM pg_class WHERE relname = $1 AND relkind = 'i')`,
		leaf+"_ts_idx").Scan(&hasFTS))
	assert.False(t, hasFTS, "internal partitions must not get a ts index")
}

func TestIntegrationVectorEnsureResourcePartitionExternal(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	pg := backend.(*pgvectorBackend)

	const res = "testpartition_external"
	leaf := subtreeName(res)
	idx := leaf + "_metadata_idx"
	ftsIdx := leaf + "_ts_idx"
	drop := func() { _, _ = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP TABLE IF EXISTS %s`, leaf)) }
	drop()
	t.Cleanup(drop)

	// External partitions get partition + metadata index + ts index.
	require.NoError(t, backend.EnsureResourcePartition(ctx, res))
	ready, err := pg.resourcePartitionReady(ctx, leaf, idx, ftsIdx)
	require.NoError(t, err)
	assert.True(t, ready, "external partition with metadata and ts indexes")

	// Retro-fits partitions created before the ts index existed.
	_, err = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP INDEX IF EXISTS %s`, ftsIdx))
	require.NoError(t, err)
	ready, err = pg.resourcePartitionReady(ctx, leaf, idx, ftsIdx)
	require.NoError(t, err)
	require.False(t, ready, "missing ts index must not report ready")
	require.NoError(t, backend.EnsureResourcePartition(ctx, res))
	ready, err = pg.resourcePartitionReady(ctx, leaf, idx, ftsIdx)
	require.NoError(t, err)
	assert.True(t, ready, "missing ts index recreated on retry")
}

func TestIntegrationEnsureCollectionRejectsReservedSuffix(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	// Internal *_external keys would be misclassified as external.
	_, err := backend.EnsureCollection(ctx, "reserved.test.grafana.app", "foo_external", false)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "reserved partition key")

	_, err = backend.EnsureCollection(ctx, "reserved.test.grafana.app", "foo-external", false)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "reserved partition key")
}

func TestIntegrationVectorLexicalSearch(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	pg := backend.(*pgvectorBackend)

	const ns = "integration-test"
	// Provision via the real write-path flow (catalog row + partition + FTS index).
	coll, err := backend.EnsureCollection(ctx, "lexint.test.grafana.app", "lexint", true)
	require.NoError(t, err)
	extRes := coll.PartitionKey
	require.Equal(t, "lexint_external", extRes)
	leaf := subtreeName(extRes)
	drop := func() {
		_, _ = engine.DB().ExecContext(ctx, fmt.Sprintf(`DROP TABLE IF EXISTS %s`, leaf))
		_, _ = engine.DB().ExecContext(ctx, `DELETE FROM embedding_collections WHERE partition_key = $1`, extRes)
	}
	t.Cleanup(drop)

	row := func(uid, sub, content string, meta string) Vector {
		return Vector{
			Namespace: ns, Resource: extRes, UID: uid, Title: "Title " + uid,
			Subresource: sub, Content: content, Metadata: json.RawMessage(meta),
			Embedding: makeEmbedding(0.1, 0.2), Model: testModel,
		}
	}
	// The same content under another model must not duplicate hits.
	other := row("r1", "chunk/0", "High CPU usage on mimir ingester", `{"folderUid":"f1"}`)
	other.Model = "other-model"
	require.NoError(t, backend.Upsert(ctx, []Vector{
		row("r1", "chunk/0", "High CPU usage on mimir ingester", `{"folderUid":"f1","kind":"alert_rule"}`),
		row("r1", "chunk/1", "runbook: restart mimir ingester pods, check CPU throttling", `{"folderUid":"f1","kind":"alert_rule"}`),
		row("r2", "chunk/0", "Postgres disk usage high on primary", `{"folderUid":"f2","kind":"alert_rule","labels":["team=db","env=prod"]}`),
		row("r3", "chunk/0", "staging mimir latency above threshold", `{"folderUid":"f1","kind":"alert_rule"}`),
		other,
	}))

	search := func(q string, filters ...SearchFilter) []LexicalHit {
		t.Helper()
		hits, err := pg.LexicalSearch(ctx, LexicalQuery{
			Namespace: ns, Model: testModel, Resource: extRes,
			Query: q, Limit: 10, Filters: filters,
		})
		require.NoError(t, err)
		return hits
	}
	uids := func(hits []LexicalHit) []string {
		out := make([]string, len(hits))
		for i, h := range hits {
			out[i] = h.UID
		}
		return out
	}

	t.Run("plain words AND, per-uid dedup across chunks and models", func(t *testing.T) {
		hits := search("mimir CPU")
		require.Equal(t, []string{"r1"}, uids(hits))
		assert.Equal(t, "Title r1", hits[0].Title)
		assert.NotEmpty(t, hits[0].Content)
		assert.Greater(t, hits[0].Score, 0.0)
	})

	t.Run("best matching chunk wins", func(t *testing.T) {
		hits := search("runbook throttling")
		require.Equal(t, []string{"r1"}, uids(hits))
		assert.Equal(t, "chunk/1", hits[0].Subresource)
	})

	t.Run("quoted phrase", func(t *testing.T) {
		assert.Equal(t, []string{"r2"}, uids(search(`"disk usage"`)))
		assert.Empty(t, search(`"usage disk"`))
	})

	t.Run("negation", func(t *testing.T) {
		assert.Equal(t, []string{"r1"}, uids(search("mimir -staging")))
	})

	t.Run("or", func(t *testing.T) {
		assert.ElementsMatch(t, []string{"r2", "r3"}, uids(search("postgres OR staging")))
	})

	t.Run("stopword-only query matches nothing without error", func(t *testing.T) {
		assert.Empty(t, search("the of and"))
	})

	t.Run("negation-only query matches nothing", func(t *testing.T) {
		// Pure negation would match nearly every row at rank 0.
		assert.Empty(t, search("-staging"))
		assert.Empty(t, search("the -staging"))
	})

	t.Run("or-negation keeps positive matches", func(t *testing.T) {
		// 'cpu' | !'stage' isn't indexable, but the cpu docs must still hit.
		assert.Equal(t, []string{"r1"}, uids(search("CPU OR -staging")))
	})

	t.Run("rows without metadata are searchable", func(t *testing.T) {
		// Metadata is optional on external writes; a NULL must not fail the
		// row scan on either leg.
		noMeta := row("r5", "chunk/0", "windows kubelet flapping", "")
		noMeta.Metadata = nil
		require.NoError(t, backend.Upsert(ctx, []Vector{noMeta}))
		hits := search("kubelet")
		require.Equal(t, []string{"r5"}, uids(hits))
		assert.Nil(t, hits[0].Metadata)

		semHits, err := pg.Search(ctx, ns, testModel, extRes, makeEmbedding(0.1, 0.2), 10,
			SearchFilter{Field: "uid", Values: []string{"r5"}})
		require.NoError(t, err)
		require.Len(t, semHits, 1)
	})

	t.Run("legacy rows without ts are invisible", func(t *testing.T) {
		// Rows written before the ts column exist with ts NULL; they don't
		// match until rewritten by an upsert.
		emb := "[" + strings.TrimSuffix(strings.Repeat("0,", 1024), ",") + "]"
		_, err := engine.DB().ExecContext(ctx, fmt.Sprintf(
			`INSERT INTO %s (resource, namespace, model, uid, title, subresource, content, embedding)
			 VALUES ($1, $2, $3, $4, $5, $6, $7, '%s'::halfvec)`, leaf, emb),
			extRes, ns, testModel, "legacy", "t", "", "mimir legacy row")
		require.NoError(t, err)
		for _, h := range search("mimir") {
			assert.NotEqual(t, "legacy", h.UID)
		}
	})

	t.Run("uid filter", func(t *testing.T) {
		assert.Empty(t, search("mimir", SearchFilter{Field: "uid", Values: []string{"r2"}}))
		assert.Equal(t, []string{"r1"}, uids(search("mimir CPU", SearchFilter{Field: "uid", Values: []string{"r1"}})))
	})

	t.Run("metadata containment filters, scalar and array", func(t *testing.T) {
		assert.ElementsMatch(t, []string{"r1", "r3"},
			uids(search("mimir OR staging", SearchFilter{Field: "folderUid", Values: []string{"f1"}})))
		assert.Equal(t, []string{"r2"},
			uids(search("postgres", SearchFilter{Field: "labels", Values: []string{"team=db"}})))
		assert.Empty(t, search("postgres", SearchFilter{Field: "labels", Values: []string{"team=infra"}}))
	})

	t.Run("model scoping", func(t *testing.T) {
		hits, err := pg.LexicalSearch(ctx, LexicalQuery{
			Namespace: ns, Model: "third-model", Resource: extRes,
			Query: "mimir", Limit: 10,
		})
		require.NoError(t, err)
		assert.Empty(t, hits)
	})

	t.Run("limit truncates", func(t *testing.T) {
		hits, err := pg.LexicalSearch(ctx, LexicalQuery{
			Namespace: ns, Model: testModel, Resource: extRes,
			Query: "mimir OR postgres OR staging", Limit: 1, Filters: nil,
		})
		require.NoError(t, err)
		assert.Len(t, hits, 1)
	})
}

// TestIntegrationVectorTimestamps pins the created_at/updated_at contract:
// created_at is stamped once on insert and preserved across re-embeds, while
// updated_at advances on every upsert of the same row.
func TestIntegrationVectorTimestamps(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	v := Vector{
		Namespace: "integration-test", Resource: testResource, UID: "dash-ts", Title: "Dash",
		Subresource: "panel/1", ResourceVersion: 10, Folder: "folder-a",
		Content: "original content", Metadata: json.RawMessage(`{}`),
		Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{v}))

	created1, updated1 := readEmbeddingTimestamps(t, engine, v.Namespace, v.Model, v.UID, v.Subresource)
	require.False(t, created1.IsZero(), "created_at must be stamped on insert")
	// Both columns default to the same transaction timestamp on insert.
	require.Equal(t, created1, updated1)

	// CURRENT_TIMESTAMP has microsecond resolution and is fixed per
	// transaction, so a short sleep guarantees a strictly greater updated_at
	// on the next upsert without flakiness.
	time.Sleep(10 * time.Millisecond)

	v.Content = "changed content"
	v.Embedding = makeEmbedding(0.6, 0.4)
	require.NoError(t, backend.Upsert(ctx, []Vector{v}))

	created2, updated2 := readEmbeddingTimestamps(t, engine, v.Namespace, v.Model, v.UID, v.Subresource)
	require.Equal(t, created1, created2, "created_at must not change on re-embed")
	require.True(t, updated2.After(updated1), "updated_at must advance on re-embed")

	_, _, err := backend.DeleteRows(ctx, v.Namespace, testModel, testResource, DeleteSelector{UIDs: []string{v.UID}})
	require.NoError(t, err)
}

func readEmbeddingTimestamps(t *testing.T, engine *xorm.Engine, namespace, model, uid, subresource string) (createdAt, updatedAt time.Time) {
	t.Helper()
	row := engine.DB().QueryRowContext(context.Background(),
		`SELECT created_at, updated_at FROM embeddings
			WHERE namespace = $1 AND model = $2 AND uid = $3 AND subresource = $4`,
		namespace, model, uid, subresource)
	require.NoError(t, row.Scan(&createdAt, &updatedAt))
	return createdAt, updatedAt
}

func TestIntegrationVectorCollectionCatalog(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	// The migration seeds the dashboards row.
	c, found, err := backend.ResolveCollection(ctx, "dashboard.grafana.app", "dashboards")
	require.NoError(t, err)
	require.True(t, found)
	assert.Equal(t, "dashboards", c.PartitionKey)
	assert.False(t, c.IsExternal)

	// Unknown pair: not found, no error.
	_, found, err = backend.ResolveCollection(ctx, "nope.grafana.app", "nope")
	require.NoError(t, err)
	assert.False(t, found)

	// Insert an external collection whose resource name is not a valid SQL
	// identifier — the catalog decouples resource names from partition keys.
	_, err = engine.DB().ExecContext(ctx, `
		INSERT INTO embedding_collections (group_name, resource, partition_key, is_external)
		VALUES ('ext.example.com', 'my-things', 'my_things', true)
		ON CONFLICT DO NOTHING`)
	require.NoError(t, err)
	t.Cleanup(func() {
		_, _ = engine.DB().ExecContext(context.Background(),
			`DELETE FROM embedding_collections WHERE group_name = 'ext.example.com'`)
	})

	c, found, err = backend.ResolveCollection(ctx, "ext.example.com", "my-things")
	require.NoError(t, err)
	require.True(t, found)
	assert.Equal(t, "my_things", c.PartitionKey)
	assert.True(t, c.IsExternal)

	// validateResource rides the catalog: operations on an unprovisioned
	// partition key are rejected before touching the embeddings table.
	_, err = backend.Search(ctx, "ns", testModel, "not-provisioned", make([]float32, 3), 5)
	require.Error(t, err)
	require.Contains(t, err.Error(), "unsupported resource")
}

func TestIntegrationVectorMetadataOnlyRefresh(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	orig := Vector{
		Namespace: "ns-meta", Resource: testResource, UID: "meta-uid",
		Title: "Before", Subresource: "chunk/1", Content: "hello", Folder: "fold-old",
		Metadata: json.RawMessage(`{"embeddedAt":1}`), Embedding: makeEmbedding(0.1, 0.1), Model: testModel,
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{orig}))
	// (test lives in package vector, so Vector/VectorMeta are unqualified)

	// metadataOnly rewrite: title/folder/metadata change, embedding and content stay.
	err := backend.UpsertReplaceSubresources(ctx, "ns-meta", testModel, testResource, "meta-uid",
		nil,
		[]VectorMeta{{Subresource: "chunk/1", Title: "After", Folder: "fold-new", Metadata: json.RawMessage(`{"embeddedAt":2}`)}},
		[]string{"chunk/1"})
	require.NoError(t, err)

	content, _, err := backend.GetSubresourceContent(ctx, "ns-meta", testModel, testResource, "meta-uid")
	require.NoError(t, err)
	require.Equal(t, map[string]string{"chunk/1": "hello"}, content, "content untouched")

	// Row-level check: title/folder/metadata updated, embedding unchanged.
	rows, err := backend.Search(ctx, "ns-meta", testModel, testResource, makeEmbedding(0.1, 0.1), 5)
	require.NoError(t, err)
	require.Len(t, rows, 1)
	require.Equal(t, "After", rows[0].Title)
	require.Equal(t, "fold-new", rows[0].Folder, "folder moves land without re-embed")
	require.JSONEq(t, `{"embeddedAt":2}`, string(rows[0].Metadata))
}

func TestIntegrationVectorDeleteRows(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, sub string) Vector {
		return Vector{
			Namespace: "ns-del", Resource: testResource, UID: uid, Title: "T",
			Subresource: sub, Content: "c", Embedding: makeEmbedding(0.2, 0.2), Model: testModel,
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("u1", ""), mk("u1", "chunk/1"), mk("u2", ""), mk("u3", ""),
	}))

	// UIDs selector: whole entities including subresources.
	n, more, err := backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{UIDs: []string{"u1", "u2"}})
	require.NoError(t, err)
	require.False(t, more)
	require.EqualValues(t, 3, n)

	// All selector with tiny page to exercise hasMore.
	require.NoError(t, backend.Upsert(ctx, []Vector{mk("u4", ""), mk("u5", "")}))
	n, more, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{All: true, Limit: 2})
	require.NoError(t, err)
	require.EqualValues(t, 2, n)
	require.True(t, more) // u3 remains
	n, more, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{All: true, Limit: 2})
	require.NoError(t, err)
	require.EqualValues(t, 1, n)
	require.False(t, more)

	// Exact-boundary page: collection holds exactly `limit` rows, so the
	// full page is also the last one — has_more must be false.
	require.NoError(t, backend.Upsert(ctx, []Vector{mk("u6", ""), mk("u7", "")}))
	n, more, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{All: true, Limit: 2})
	require.NoError(t, err)
	require.EqualValues(t, 2, n)
	require.False(t, more)

	// Selector validation.
	_, _, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{})
	require.Error(t, err)
	_, _, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{UIDs: []string{"x"}, All: true})
	require.Error(t, err)

	// AllModels spans embedding models; model-scoped deletes leave other
	// models' rows (orphans from a model change) behind.
	oldModel := mk("u8", "")
	oldModel.Model = "old-model"
	require.NoError(t, backend.Upsert(ctx, []Vector{mk("u8", ""), oldModel}))
	n, _, err = backend.DeleteRows(ctx, "ns-del", testModel, testResource, DeleteSelector{UIDs: []string{"u8"}})
	require.NoError(t, err)
	require.EqualValues(t, 1, n)
	n, more, err = backend.DeleteRows(ctx, "ns-del", "", testResource, DeleteSelector{UIDs: []string{"u8"}, AllModels: true})
	require.NoError(t, err)
	require.False(t, more)
	require.EqualValues(t, 1, n)

	require.NoError(t, backend.Upsert(ctx, []Vector{mk("u9", ""), func() Vector { v := mk("u9", ""); v.Model = "old-model"; return v }()}))
	n, more, err = backend.DeleteRows(ctx, "ns-del", "", testResource, DeleteSelector{All: true, AllModels: true, Limit: 2})
	require.NoError(t, err)
	require.EqualValues(t, 2, n)
	require.False(t, more)
}

func TestIntegrationEnsureCollection(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	t.Cleanup(func() {
		_, _ = engine.DB().ExecContext(context.Background(),
			`DELETE FROM embedding_collections WHERE group_name = 'prov.example.com'`)
		_, _ = engine.DB().ExecContext(context.Background(), `DROP TABLE IF EXISTS embeddings_prov_things_external`)
	})

	// First call provisions: catalog row + partition + GIN index.
	c, err := backend.EnsureCollection(ctx, "prov.example.com", "prov-things", true)
	require.NoError(t, err)
	require.Equal(t, "prov_things_external", c.PartitionKey)
	require.True(t, c.IsExternal)

	var ready bool
	require.NoError(t, engine.DB().QueryRowContext(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM pg_inherits i
			JOIN pg_class c ON c.oid = i.inhrelid
			JOIN pg_class p ON p.oid = i.inhparent
			WHERE p.relname = 'embeddings' AND c.relname = 'embeddings_prov_things_external'
		) AND EXISTS (
			SELECT 1 FROM pg_class WHERE relname = 'embeddings_prov_things_external_metadata_idx' AND relkind = 'i'
		)`).Scan(&ready))
	require.True(t, ready, "partition leaf + GIN index exist")

	// Idempotent.
	c2, err := backend.EnsureCollection(ctx, "prov.example.com", "prov-things", true)
	require.NoError(t, err)
	require.Equal(t, c, c2)

	// Writes to the new collection work end-to-end.
	require.NoError(t, backend.Upsert(ctx, []Vector{{
		Namespace: "ns-prov", Resource: c.PartitionKey, UID: "u1", Title: "T",
		Content: "c", Embedding: makeEmbedding(0.3, 0.3), Model: testModel,
	}}))

	// Over-long resource names are rejected before any DB write.
	_, err = backend.EnsureCollection(ctx, "prov.example.com", strings.Repeat("x", 60), true)
	require.Error(t, err)
	require.Contains(t, err.Error(), "too long")

	// Concurrent provisioning converges on one row.
	var wg sync.WaitGroup
	errs := make([]error, 4)
	for i := range errs {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			_, errs[i] = backend.EnsureCollection(ctx, "prov.example.com", "prov-race", true)
		}(i)
	}
	wg.Wait()
	for _, e := range errs {
		require.NoError(t, e)
	}
	var n int
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT count(*) FROM embedding_collections WHERE group_name = 'prov.example.com' AND resource = 'prov-race'`).Scan(&n))
	require.Equal(t, 1, n)
	t.Cleanup(func() {
		_, _ = engine.DB().ExecContext(context.Background(), `DROP TABLE IF EXISTS embeddings_prov_race_external`)
	})
}

// TestIntegrationEnsureCollection_FoundPathEnsuresPartition pins the fix for
// the wedged-collection bug: a catalog row can exist (e.g. the INSERT half of
// a prior provision committed) while its partition DDL never ran (transient
// failure, or a bounced replica racing the retry). Before the fix, the found
// path returned early and the collection stayed permanently unwritable
// ("no partition of relation embeddings found for row"). EnsureCollection
// must create the missing leaf on every call, not just first provision.
func TestIntegrationEnsureCollection_FoundPathEnsuresPartition(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	const group, resource, key = "prov.example.com", "prov-wedged", "prov_wedged_external"
	leaf := "embeddings_" + key
	t.Cleanup(func() {
		_, _ = engine.DB().ExecContext(context.Background(),
			`DELETE FROM embedding_collections WHERE group_name = $1`, group)
		_, _ = engine.DB().ExecContext(context.Background(), fmt.Sprintf(`DROP TABLE IF EXISTS %s`, leaf))
	})

	// Simulate the wedge: catalog row present, partition never created.
	_, err := engine.DB().ExecContext(ctx, `
		INSERT INTO embedding_collections (group_name, resource, partition_key, is_external)
		VALUES ($1, $2, $3, true)`, group, resource, key)
	require.NoError(t, err)

	var existsBefore bool
	require.NoError(t, engine.DB().QueryRowContext(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM pg_inherits i
			JOIN pg_class c ON c.oid = i.inhrelid
			JOIN pg_class p ON p.oid = i.inhparent
			WHERE p.relname = 'embeddings' AND c.relname = $1
		)`, leaf).Scan(&existsBefore))
	require.False(t, existsBefore, "partition must not exist yet")

	// The found path must still provision the partition leaf.
	c, err := backend.EnsureCollection(ctx, group, resource, true)
	require.NoError(t, err)
	require.Equal(t, key, c.PartitionKey)

	var existsAfter bool
	require.NoError(t, engine.DB().QueryRowContext(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM pg_inherits i
			JOIN pg_class c ON c.oid = i.inhrelid
			JOIN pg_class p ON p.oid = i.inhparent
			WHERE p.relname = 'embeddings' AND c.relname = $1
		)`, leaf).Scan(&existsAfter))
	require.True(t, existsAfter, "found path must create the missing partition leaf")

	// Collection is now actually writable, not permanently wedged.
	require.NoError(t, backend.Upsert(ctx, []Vector{{
		Namespace: "ns-wedged", Resource: c.PartitionKey, UID: "u1", Title: "T",
		Content: "c", Embedding: makeEmbedding(0.4, 0.4), Model: testModel,
	}}))
}

// TestIntegrationEnsureCollection_IsExternalMismatch guards against a
// fat-fingered vector_allowed_external_collections entry: an operator who
// accidentally lists an internal (group, resource) pair must not have
// EnsureCollection silently hand back that internal collection for external
// writes to land in.
func TestIntegrationEnsureCollection_IsExternalMismatch(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	// The migration seeds dashboard.grafana.app/dashboards as internal
	// (is_external=false). Calling EnsureCollection with isExternal=true
	// must reject it rather than returning the internal collection.
	_, err := backend.EnsureCollection(ctx, "dashboard.grafana.app", "dashboards", true)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "is internal, not writable through the external API")
}

func TestIntegrationWithEntityLock(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	var order []string
	var mu sync.Mutex
	record := func(s string) { mu.Lock(); order = append(order, s); mu.Unlock() }

	firstInside := make(chan struct{})
	release := make(chan struct{})
	done := make(chan struct{})

	go func() {
		_ = backend.WithEntityLock(ctx, "ns-lock", testResource, "u-lock", func(context.Context) error {
			record("first-in")
			close(firstInside)
			<-release
			record("first-out")
			return nil
		})
		close(done)
	}()

	<-firstInside
	second := make(chan struct{})
	go func() {
		_ = backend.WithEntityLock(ctx, "ns-lock", testResource, "u-lock", func(context.Context) error {
			record("second-in")
			return nil
		})
		close(second)
	}()

	// Second must not enter while first holds the lock.
	select {
	case <-second:
		t.Fatal("second acquired lock while first held it")
	case <-time.After(300 * time.Millisecond):
	}

	close(release)
	<-done
	<-second
	require.Equal(t, []string{"first-in", "first-out", "second-in"}, order)

	// Different entity does not contend.
	err := backend.WithEntityLock(ctx, "ns-lock", testResource, "other-uid", func(context.Context) error { return nil })
	require.NoError(t, err)
}

func TestIntegrationEnsureCollection_PartitionKeyConflict(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	t.Cleanup(func() {
		_, _ = engine.DB().ExecContext(context.Background(),
			`DELETE FROM embedding_collections WHERE partition_key = 'clash_things_external'`)
		_, _ = engine.DB().ExecContext(context.Background(), `DROP TABLE IF EXISTS embeddings_clash_things_external`)
	})

	_, err := backend.EnsureCollection(ctx, "one.example.com", "clash-things", true)
	require.NoError(t, err)

	// Sanitize collision within a group: clash_things derives the same key.
	_, err = backend.EnsureCollection(ctx, "one.example.com", "clash_things", true)
	require.ErrorContains(t, err, `partition key "clash_things_external" is already owned by one.example.com/clash-things`)

	// Cross-group collision on the same resource name.
	_, err = backend.EnsureCollection(ctx, "two.example.com", "clash-things", true)
	require.ErrorContains(t, err, `already owned by one.example.com/clash-things`)

	// The owning collection keeps working.
	_, err = backend.EnsureCollection(ctx, "one.example.com", "clash-things", true)
	require.NoError(t, err)
}

// TestIntegrationVectorNullFolder pins that reads tolerate legacy rows whose
// folder column is NULL (written before the column existed): scanning into a
// plain string must not error, and NULL comes back as "".
func TestIntegrationVectorNullFolder(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)

	require.NoError(t, backend.Upsert(ctx, []Vector{
		{Namespace: "integration-test", Resource: testResource, UID: "null-folder-dash", Title: "T",
			Subresource: "panel/1", Content: "legacy content", Metadata: json.RawMessage(`{}`),
			Embedding: makeEmbedding(0.5, 0.5), Model: testModel, ContentVersion: 1},
	}))
	_, err := engine.Exec("UPDATE embeddings SET folder = NULL WHERE uid = 'null-folder-dash'")
	require.NoError(t, err)

	stored, folder, err := backend.GetSubresourceContent(ctx, "integration-test", testModel, testResource, "null-folder-dash")
	require.NoError(t, err)
	assert.Equal(t, map[string]string{"panel/1": "legacy content"}, stored)
	assert.Empty(t, folder)

	results, err := backend.Search(ctx, "integration-test", testModel, testResource, makeEmbedding(0.5, 0.5), 10)
	require.NoError(t, err)
	require.NotEmpty(t, results)
	for _, r := range results {
		if r.UID == "null-folder-dash" {
			assert.Empty(t, r.Folder)
		}
	}
}

func mustFilter(t *testing.T, raw string) *filter.Filter {
	t.Helper()
	f, err := filter.Parse(json.RawMessage(raw))
	require.NoError(t, err)
	require.NotNil(t, f)
	return f
}

func TestIntegrationVectorDeleteByFilter(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)

	mk := func(uid, status string) Vector {
		return Vector{
			Namespace: "ns-flt", Resource: testResource, UID: uid, Title: "T",
			Subresource: "", Content: "c", Embedding: makeEmbedding(0.3, 0.3), Model: testModel,
			Metadata: json.RawMessage(fmt.Sprintf(`{"status":%q}`, status)),
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("u1", "stale"), mk("u2", "stale"), mk("u3", "fresh"),
	}))

	n, more, err := backend.DeleteRows(ctx, "ns-flt", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"status":"stale"}`)})
	require.NoError(t, err)
	require.False(t, more)
	require.EqualValues(t, 2, n)

	// Only the fresh row survives.
	n, _, err = backend.DeleteRows(ctx, "ns-flt", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"status":"fresh"}`)})
	require.NoError(t, err)
	require.EqualValues(t, 1, n)
}

func TestIntegrationVectorUpdateMetadata(t *testing.T) {
	backend, engine, ctx := setupIntegrationTest(t)
	// Isolate so created_at == updated_at holds for freshly-seeded rows.
	_, err := backend.DeleteNamespace(ctx, "ns-upd")
	require.NoError(t, err)

	mk := func(uid, status string) Vector {
		return Vector{
			Namespace: "ns-upd", Resource: testResource, UID: uid, Title: "T",
			Subresource: "", Content: "c", Embedding: makeEmbedding(0.4, 0.4), Model: testModel,
			Metadata: json.RawMessage(fmt.Sprintf(`{"status":%q,"owner":"u-old"}`, status)),
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("u1", "open"), mk("u2", "open"), mk("u3", "closed"),
	}))

	// Merge status, drop owner, only on open rows.
	updated, err := backend.UpdateMetadata(ctx, "ns-upd", testResource,
		mustFilter(t, `{"status":"open"}`),
		json.RawMessage(`{"status":"resolved","note":"done"}`), []string{"owner"})
	require.NoError(t, err)
	require.EqualValues(t, 2, updated)

	var meta string
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT metadata::text FROM embeddings WHERE resource=$1 AND namespace=$2 AND uid=$3`,
		testResource, "ns-upd", "u1").Scan(&meta))
	require.JSONEq(t, `{"status":"resolved","note":"done"}`, meta)

	// The closed row is untouched.
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT metadata::text FROM embeddings WHERE resource=$1 AND namespace=$2 AND uid=$3`,
		testResource, "ns-upd", "u3").Scan(&meta))
	require.JSONEq(t, `{"status":"closed","owner":"u-old"}`, meta)

	// Updated rows bump updated_at; the untouched row keeps created_at == updated_at.
	var bumped, untouched bool
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT updated_at > created_at FROM embeddings WHERE resource=$1 AND namespace=$2 AND uid=$3`,
		testResource, "ns-upd", "u1").Scan(&bumped))
	require.True(t, bumped, "updated_at should advance on metadata update")
	require.NoError(t, engine.DB().QueryRowContext(ctx,
		`SELECT updated_at > created_at FROM embeddings WHERE resource=$1 AND namespace=$2 AND uid=$3`,
		testResource, "ns-upd", "u3").Scan(&untouched))
	require.False(t, untouched, "untouched row keeps its original updated_at")
}

func TestIntegrationVectorFilterEdgeCases(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)
	// Isolate from any rows a prior run left in this namespace.
	_, err := backend.DeleteNamespace(ctx, "ns-edge")
	require.NoError(t, err)

	mk := func(uid string, meta string) Vector {
		return Vector{
			Namespace: "ns-edge", Resource: testResource, UID: uid, Title: "T",
			Content: "c", Embedding: makeEmbedding(0.5, 0.5), Model: testModel,
			Metadata: json.RawMessage(meta),
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("eq", `{"tag":"a"}`),          // scalar equal to "a"
		mk("neq", `{"tag":"c"}`),         // scalar not "a"
		mk("missing", `{"other":"x"}`),   // no tag field
		mk("numstr", `{"score":"high"}`), // nonnumeric score
		mk("num", `{"score":42}`),        // numeric score
	}))

	// $ne is the exact negation of $eq's containment: excludes the equal
	// scalar, includes the unequal scalar and rows missing the field.
	ne, err := backend.UpdateMetadata(ctx, "ns-edge", testResource,
		mustFilter(t, `{"tag":{"$ne":"a"}}`),
		json.RawMessage(`{"nematch":true}`), nil)
	require.NoError(t, err)
	require.EqualValues(t, 4, ne) // neq, missing, numstr, num — not eq

	// $eq matches only the equal scalar.
	n, _, err := backend.DeleteRows(ctx, "ns-edge", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"tag":"a"}`)})
	require.NoError(t, err)
	require.EqualValues(t, 1, n)

	// A range filter over a key some rows store as a nonnumeric string must
	// not abort; the nonnumeric row simply doesn't match.
	n, more, err := backend.DeleteRows(ctx, "ns-edge", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"score":{"$gt":10}}`)})
	require.NoError(t, err)
	require.False(t, more)
	require.EqualValues(t, 1, n) // only num (42); numstr skipped, not an error
}

func TestIntegrationVectorFilterNonStringIn(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)
	_, err := backend.DeleteNamespace(ctx, "ns-nonstr")
	require.NoError(t, err)

	mk := func(uid, meta string) Vector {
		return Vector{
			Namespace: "ns-nonstr", Resource: testResource, UID: uid, Title: "T",
			Content: "c", Embedding: makeEmbedding(0.7, 0.7), Model: testModel,
			Metadata: json.RawMessage(meta),
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("num", `{"score":42}`),
		mk("num2", `{"score":7}`),
		mk("boolt", `{"flag":true}`),
		mk("boolf", `{"flag":false}`),
		mk("arr", `{"tags":["a","b"]}`),
	}))

	// $in with numeric values must not raise a text-vs-numeric type error and
	// must match by JSONB value, not text formatting.
	n, _, err := backend.DeleteRows(ctx, "ns-nonstr", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"score":{"$in":[42,99]}}`)})
	require.NoError(t, err)
	require.EqualValues(t, 1, n) // only score=42

	// $in with a boolean value.
	n, _, err = backend.DeleteRows(ctx, "ns-nonstr", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"flag":{"$in":[true]}}`)})
	require.NoError(t, err)
	require.EqualValues(t, 1, n) // only flag=true

	// $in over a string array field matches by element membership.
	n, _, err = backend.DeleteRows(ctx, "ns-nonstr", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"tags":{"$in":["b"]}}`)})
	require.NoError(t, err)
	require.EqualValues(t, 1, n) // arr contains "b"
}

func TestIntegrationVectorNeMatchesNullMetadata(t *testing.T) {
	backend, _, ctx := setupIntegrationTest(t)
	_, err := backend.DeleteNamespace(ctx, "ns-null")
	require.NoError(t, err)

	mk := func(uid string, meta json.RawMessage) Vector {
		return Vector{
			Namespace: "ns-null", Resource: testResource, UID: uid, Title: "T",
			Content: "c", Embedding: makeEmbedding(0.8, 0.8), Model: testModel,
			Metadata: meta,
		}
	}
	require.NoError(t, backend.Upsert(ctx, []Vector{
		mk("has", json.RawMessage(`{"env":"prod"}`)),
		mk("other", json.RawMessage(`{"env":"dev"}`)),
		mk("none", nil), // stored as SQL NULL
	}))

	// $ne "prod" must match the dev row AND the metadata-less row (Mongo: a
	// missing field is "not equal"), i.e. everything except the prod row.
	n, _, err := backend.DeleteRows(ctx, "ns-null", testModel, testResource,
		DeleteSelector{Filter: mustFilter(t, `{"env":{"$ne":"prod"}}`)})
	require.NoError(t, err)
	require.EqualValues(t, 2, n) // other + none, not has
}
