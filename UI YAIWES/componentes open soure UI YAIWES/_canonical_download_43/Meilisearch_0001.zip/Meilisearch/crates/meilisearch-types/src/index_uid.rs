use std::borrow::Borrow;
use std::error::Error;
use std::fmt;
use std::str::FromStr;

use deserr::Deserr;
use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::error::{Code, ErrorCode};

#[derive(
    Debug, Clone, Deserialize, PartialEq, Eq, Deserr, PartialOrd, Ord, Serialize, ToSchema, Hash,
)]
#[deserr(try_from(String) = IndexUid::try_from -> IndexUidFormatError)]
#[serde(try_from = "String")]
#[schema(value_type = String, example = "movies")]
pub struct IndexUid(String);

// manual impl: don't want to botch the serde try_from
impl routes::RequestBody for IndexUid {}

impl IndexUid {
    pub fn new_unchecked(s: impl AsRef<str>) -> Self {
        Self(s.as_ref().to_string())
    }

    pub fn into_inner(self) -> String {
        self.0
    }

    /// Return a reference over the inner str.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for IndexUid {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.0, f)
    }
}

impl std::ops::Deref for IndexUid {
    type Target = str;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl TryFrom<String> for IndexUid {
    type Error = IndexUidFormatError;

    fn try_from(uid: String) -> Result<Self, Self::Error> {
        if !uid.chars().all(|x| x.is_ascii_alphanumeric() || x == '-' || x == '_')
            || uid.is_empty()
            || uid.len() > 400
        {
            Err(IndexUidFormatError { invalid_uid: uid })
        } else {
            Ok(IndexUid(uid))
        }
    }
}

impl FromStr for IndexUid {
    type Err = IndexUidFormatError;

    fn from_str(uid: &str) -> Result<IndexUid, IndexUidFormatError> {
        uid.to_string().try_into()
    }
}

impl From<IndexUid> for String {
    fn from(uid: IndexUid) -> Self {
        uid.into_inner()
    }
}

impl Borrow<String> for IndexUid {
    fn borrow(&self) -> &String {
        &self.0
    }
}

#[derive(Debug)]
pub struct IndexUidFormatError {
    pub invalid_uid: String,
}

impl fmt::Display for IndexUidFormatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "`{}` is not a valid index uid. Index uid can be an \
            integer or a string containing only alphanumeric \
            characters, hyphens (-) and underscores (_), \
            and can not be more than 512 bytes.",
            self.invalid_uid,
        )
    }
}

impl Error for IndexUidFormatError {}

impl ErrorCode for IndexUidFormatError {
    fn error_code(&self) -> Code {
        Code::InvalidIndexUid
    }
}

#[derive(Clone, Copy)]
pub struct AnyIndex<'a>(&'a str);

impl<'a> AnyIndex<'a> {
    pub fn new(uid: &'a str) -> Self {
        Self(uid)
    }

    pub fn uid(&self) -> &'a str {
        self.0
    }
}

#[derive(Clone, Copy)]
pub struct UserIndex<'a>(&'a str);

pub const RESERVED_UID_PREFIX: &str = ".meili";

impl<'a> UserIndex<'a> {
    pub fn new(uid: &'a str) -> Option<Self> {
        if uid.starts_with(RESERVED_UID_PREFIX) {
            None
        } else {
            Some(Self(uid))
        }
    }

    pub fn uid(&self) -> &'a str {
        self.0
    }
}

#[derive(Clone, Copy)]
pub struct DsrIndex;

impl DsrIndex {
    pub const fn dsr_uid() -> &'static str {
        ".meili_dsr"
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ForeignIndexUid(pub IndexUid);

impl std::borrow::Borrow<str> for ForeignIndexUid {
    fn borrow(&self) -> &str {
        &self.0
    }
}

impl AsRef<str> for ForeignIndexUid {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct SourceFieldName(pub String);

impl AsRef<str> for SourceFieldName {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct SourceIndexUid(pub IndexUid);

impl std::borrow::Borrow<str> for SourceIndexUid {
    fn borrow(&self) -> &str {
        &self.0
    }
}

impl AsRef<str> for SourceIndexUid {
    fn as_ref(&self) -> &str {
        &self.0
    }
}
