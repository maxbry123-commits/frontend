use std::collections::BTreeMap;
use std::sync::atomic::Ordering;

use actix_web::web::Data;
use actix_web::{web, HttpRequest, HttpResponse};
use deserr::actix_web::AwebQueryParameter;
use export::Export;
use index_scheduler::IndexScheduler;
use meilisearch_auth::AuthController;
use meilisearch_types::batch_view::BatchView;
use meilisearch_types::batches::BatchStats;
use meilisearch_types::deserr::query_params::Param;
use meilisearch_types::deserr::DeserrQueryParamError;
use meilisearch_types::error::{Code, ErrorType, ResponseError};
use meilisearch_types::index_uid::IndexUid;
use meilisearch_types::keys::CreateApiKey;
use meilisearch_types::milli::{
    AttributePatterns, FilterFeatures, FilterableAttributesFeatures, FilterableAttributesPatterns,
    FilterableAttributesRule,
};
use meilisearch_types::settings::{
    Checked, FacetingSettings, MinWordSizeTyposSetting, PaginationSettings, Settings, TypoSettings,
    Unchecked,
};
use meilisearch_types::task_view::{DetailsView, TaskView};
use meilisearch_types::tasks::{Kind, Status, Task, TaskId};
use serde::{Deserialize, Serialize};
use time::OffsetDateTime;
use tracing::debug;
use utoipa::ToSchema;

use self::api_key::KeyView;
use self::indexes::documents::BrowseQuery;
use self::indexes::{IndexCreateRequest, IndexStats, UpdateIndexRequest};
use self::logs::{GetLogs, LogMode, UpdateStderrLogs};
use self::open_api_utils::OpenApiAuth;
use self::tasks::AllTasks;
use crate::extractors::authentication::policies::*;
use crate::extractors::authentication::GuardedData;
use crate::milli::progress::{ProgressStepView, ProgressView};
use crate::routes::batches::AllBatches;
use crate::routes::features::RuntimeTogglableFeatures;
use crate::routes::indexes::documents::{DocumentDeletionByFilter, DocumentEditionByFunction};
use crate::routes::indexes::{
    GetIndexStatsParams, IndexView, ListFields, ListFieldsFilter, Size, SizeFormat,
};
use crate::routes::multi_search::SearchResults;
use crate::routes::network::{Network, Remote, Shard};
use crate::routes::swap_indexes::SwapIndexesPayload;
use crate::routes::webhooks::{
    WebhookResults, WebhookSettings, WebhookWithMetadataRedactedAuthorization,
};
use crate::search::{
    FederatedSearch, FederatedSearchResult, Federation, FederationOptions, MergeFacets,
    SearchQueryWithIndex, SearchResultWithIndex, SimilarQuery, SimilarResult,
    INCLUDE_METADATA_HEADER,
};
use crate::search_queue::SearchQueue;

const PAGINATION_DEFAULT_LIMIT: usize = 20;
const PAGINATION_DEFAULT_LIMIT_FN: fn() -> usize = || 20;

mod api_key;
pub mod batches;
pub mod chats;
mod dump;
mod dynamic_search_rules;
mod export;
mod export_analytics;
pub mod features;
pub mod indexes;
mod logs;
mod metrics;
mod multi_search;
mod multi_search_analytics;
pub mod network;
mod open_api_utils;
pub mod render;
mod render_analytics;
mod snapshot;
mod swap_indexes;
pub mod tasks;
#[cfg(test)]
mod tasks_test;
mod webhooks;

#[routes::routes(
    routes(
        "/health" => get(get_health),
        "/version" => get(get_version),
        "/stats" => get(get_stats),
        "/chats" => sub(chats::ChatsApi),
        "/tasks" => sub(tasks::TaskApi),
        "/batches"=>sub(batches::BatchesApi),
        "/indexes" => sub(indexes::IndexesApi),
        // We must stop the search path here because the rest must be configured by each route individually
        "/snapshots"=> sub(snapshot::SnapshotApi),
        "/dumps"=> sub(dump::DumpApi),
        "/keys"=> sub(api_key::ApiKeyApi),
        "/metrics"=> sub(metrics::MetricApi),
        "/logs"=> sub(logs::LogsApi),
        "/multi-search"=> sub(multi_search::MultiSearchApi),
        "/swap-indexes"=> sub(swap_indexes::SwapIndexesApi),
        "/experimental-features"=> sub(features::ExperimentalFeaturesApi),
        "/export"=> sub(export::ExportApi),
        "/network"=> sub(network::NetworkApi),
        "/webhooks"=> sub(webhooks::WebhooksApi),
        "/dynamic-search-rules"=> sub(dynamic_search_rules::DynamicSearchRulesApi),
        "/render-template" => sub(render::RenderApi),
    ),
    tag = "Root",
    tags(
        (name = "Stats", description = "Stats gives extended information and metrics about indexes and the Meilisearch database."),
        (name = "Health", description = "The health check endpoint enables you to periodically test the health of your Meilisearch instance."),
        (name = "Version", description = "Returns the version of the running Meilisearch instance."),
        (name = "Backups", description = "Meilisearch offers two types of backups: snapshots and dumps. Snapshots are mainly intended as a safeguard, while dumps are useful when migrating Meilisearch."),
        (name = "Export", description = "Export documents and settings from this instance to a remote Meilisearch server."),
        (name = "Async task management", description = "Routes for listing and managing batches and tasks (asynchronous operations)."),
    ),
    modifiers(&OpenApiAuth),
    servers((
        url = "http://localhost:7700",
        description = "Local server.",
    )),
    components(schemas(PaginationView<KeyView>, PaginationView<IndexView>, IndexView, DocumentDeletionByFilter, AllBatches, BatchStats, ProgressStepView, ProgressView, BatchView, RuntimeTogglableFeatures, SwapIndexesPayload, DocumentEditionByFunction, MergeFacets, FederationOptions, SearchQueryWithIndex, Federation, FederatedSearch, FederatedSearchResult, SearchResults, SearchResultWithIndex, SimilarQuery, SimilarResult, PaginationView<serde_json::Value>, BrowseQuery, UpdateIndexRequest, IndexUid, IndexCreateRequest, KeyView, Action, CreateApiKey, UpdateStderrLogs, LogMode, GetLogs, IndexStats, Stats, HealthStatus, HealthResponse, VersionResponse, Code, ErrorType, AllTasks, TaskView, Status, DetailsView, ResponseError, Settings<Unchecked>, Settings<Checked>, TypoSettings, MinWordSizeTyposSetting, FacetingSettings, PaginationSettings, SummarizedTaskView, Kind, Network, Remote, Shard, FilterableAttributesRule, FilterableAttributesPatterns, AttributePatterns, FilterableAttributesFeatures, FilterFeatures, Export, WebhookSettings, WebhookResults, WebhookWithMetadataRedactedAuthorization, ListFields, ListFieldsFilter, SizeFormat))
)]
pub struct MeilisearchApi;

/// Parse the `Meili-Include-Metadata` header from an HTTP request.
///
/// Returns `true` if the header is present and set to "true" or "1"
/// (case-insensitive).
/// Returns `false` if the header is not present or has any other value.
pub fn parse_include_metadata_header(req: &HttpRequest) -> bool {
    req.headers()
        .get(INCLUDE_METADATA_HEADER)
        .and_then(|h| h.to_str().ok())
        .map(|v| matches!(v.to_lowercase().as_str(), "true" | "1"))
        .unwrap_or(false)
}

/// A summarized view of a task, returned when a task is enqueued
#[derive(Debug, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "camelCase")]
pub struct SummarizedTaskView {
    /// Unique sequential identifier of the task.
    #[schema(value_type = u32)]
    pub task_uid: TaskId,
    /// Unique identifier of the targeted index. Null for global tasks.
    pub index_uid: Option<String>,
    /// Status of the task. Possible values are `enqueued`, `processing`,
    /// `succeeded`, `failed`, and `canceled`.
    pub status: Status,
    /// Type of operation performed by the task.
    #[serde(rename = "type")]
    pub kind: Kind,
    /// Date and time when the task was enqueued.
    #[serde(
        serialize_with = "time::serde::rfc3339::serialize",
        deserialize_with = "time::serde::rfc3339::deserialize"
    )]
    pub enqueued_at: OffsetDateTime,
    /// Custom metadata attached to this task at creation. Use it to associate
    /// tasks with external systems or add application-specific information.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub custom_metadata: Option<String>,
}

impl From<Task> for SummarizedTaskView {
    fn from(task: Task) -> Self {
        SummarizedTaskView {
            task_uid: task.uid,
            index_uid: task.index_uid().map(|s| s.to_string()),
            status: task.status,
            kind: task.kind.as_kind(),
            enqueued_at: task.enqueued_at,
            custom_metadata: task.custom_metadata,
        }
    }
}

pub struct Pagination {
    pub offset: usize,
    pub limit: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "camelCase")]
#[schema(rename_all = "camelCase")]
pub struct PaginationView<T> {
    /// Items for the current page.
    pub results: Vec<T>,
    /// Number of items skipped.
    pub offset: usize,
    /// Maximum number of items returned.
    pub limit: usize,
    /// Total number of items matching the query.
    pub total: usize,
}

impl Pagination {
    pub fn empty(self) -> PaginationView<()> {
        self.format_with(0, Default::default())
    }

    pub fn try_auto_paginate_sized<T, E>(
        self,
        content: impl IntoIterator<Item = Result<T, E>> + ExactSizeIterator,
    ) -> Result<PaginationView<T>, E>
    where
        T: Serialize,
    {
        let total = content.len();
        let content: Result<Vec<_>, _> =
            content.into_iter().skip(self.offset).take(self.limit).collect();
        let content = content?;
        Ok(self.format_with(total, content))
    }

    /// Given the full data to paginate, returns the selected section.
    pub fn auto_paginate_sized<T>(
        self,
        content: impl IntoIterator<Item = T> + ExactSizeIterator,
    ) -> PaginationView<T>
    where
        T: Serialize,
    {
        let total = content.len();
        let content: Vec<_> = content.into_iter().skip(self.offset).take(self.limit).collect();
        self.format_with(total, content)
    }

    pub fn auto_paginate_counting<T, I>(self, content: I) -> PaginationView<T>
    where
        I: IntoIterator<Item = T>,
        T: Serialize,
    {
        let mut total = 0;
        let mut results = Vec::with_capacity(self.limit);

        for item in content {
            if total >= self.offset && results.len() < self.limit {
                results.push(item);
            }

            total += 1;
        }

        self.format_with(total, results)
    }

    /// Given an iterator and the total number of elements, returns the
    /// selected section.
    pub fn auto_paginate_unsized<T>(
        self,
        total: usize,
        content: impl IntoIterator<Item = T>,
    ) -> PaginationView<T>
    where
        T: Serialize,
    {
        let content: Vec<_> = content.into_iter().skip(self.offset).take(self.limit).collect();
        self.format_with(total, content)
    }

    /// Given the data already paginated + the total number of elements, it
    /// stores
    /// everything in a [PaginationResult].
    pub fn format_with<T>(self, total: usize, results: Vec<T>) -> PaginationView<T>
    where
        T: Serialize,
    {
        PaginationView { results, offset: self.offset, limit: self.limit, total }
    }
}

impl<T> PaginationView<T> {
    pub fn new(offset: usize, limit: usize, total: usize, results: Vec<T>) -> Self {
        Self { offset, limit, results, total }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[allow(clippy::large_enum_variant)]
#[serde(tag = "name")]
pub enum UpdateType {
    ClearAll,
    Customs,
    DocumentsAddition {
        #[serde(skip_serializing_if = "Option::is_none")]
        number: Option<usize>,
    },
    DocumentsPartial {
        #[serde(skip_serializing_if = "Option::is_none")]
        number: Option<usize>,
    },
    DocumentsDeletion {
        #[serde(skip_serializing_if = "Option::is_none")]
        number: Option<usize>,
    },
    Settings {
        settings: Settings<Unchecked>,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProcessedUpdateResult {
    pub update_id: u64,
    #[serde(rename = "type")]
    pub update_type: UpdateType,
    pub duration: f64, // in seconds
    #[serde(with = "time::serde::rfc3339")]
    pub enqueued_at: OffsetDateTime,
    #[serde(with = "time::serde::rfc3339")]
    pub processed_at: OffsetDateTime,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FailedUpdateResult {
    pub update_id: u64,
    #[serde(rename = "type")]
    pub update_type: UpdateType,
    pub error: ResponseError,
    pub duration: f64, // in seconds
    #[serde(with = "time::serde::rfc3339")]
    pub enqueued_at: OffsetDateTime,
    #[serde(with = "time::serde::rfc3339")]
    pub processed_at: OffsetDateTime,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EnqueuedUpdateResult {
    pub update_id: u64,
    #[serde(rename = "type")]
    pub update_type: UpdateType,
    #[serde(with = "time::serde::rfc3339")]
    pub enqueued_at: OffsetDateTime,
    #[serde(skip_serializing_if = "Option::is_none", with = "time::serde::rfc3339::option")]
    pub started_processing_at: Option<OffsetDateTime>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", tag = "status")]
pub enum UpdateStatusResponse {
    Enqueued {
        #[serde(flatten)]
        content: EnqueuedUpdateResult,
    },
    Processing {
        #[serde(flatten)]
        content: EnqueuedUpdateResult,
    },
    Failed {
        #[serde(flatten)]
        content: FailedUpdateResult,
    },
    Processed {
        #[serde(flatten)]
        content: ProcessedUpdateResult,
    },
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct IndexUpdateResponse {
    pub update_id: u64,
}

impl IndexUpdateResponse {
    pub fn with_id(update_id: u64) -> Self {
        Self { update_id }
    }
}

/// Always return a 200 with:
/// ```json
/// {
///     "status": "Meilisearch is running"
/// }
/// ```
pub async fn running() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "status": "Meilisearch is running" }))
}

/// Global statistics for the Meilisearch instance
#[derive(Serialize, Debug, ToSchema)]
#[serde(rename_all = "camelCase")]
pub struct Stats {
    /// Total disk space used by the database in bytes
    pub database_size: Size,
    /// Actual size of the data in the database in bytes
    pub used_database_size: Size,
    /// Date of the last update in RFC 3339 format. Null if no update has been
    /// processed
    #[serde(serialize_with = "time::serde::rfc3339::option::serialize")]
    pub last_update: Option<OffsetDateTime>,
    /// Statistics for each index
    #[schema(value_type = HashMap<String, indexes::IndexStats>)]
    pub indexes: BTreeMap<String, indexes::IndexStats>,
}

/// Get stats of all indexes
///
/// Return statistics for the Meilisearch instance and for each index. Includes database size, last update time, document counts, and indexing status per index.
#[routes::path(
    override_tag = "Stats",
    security(("Bearer" = ["stats.get", "stats.*", "*"])),
    params(GetIndexStatsParams),
    responses(
        (status = 200, description = "The stats of the instance.", body = Stats, content_type = "application/json", example = json!(
            {
                "databaseSize": 567,
                "usedDatabaseSize": 456,
                "lastUpdate": "2019-11-20T09:40:33.711324Z",
                "indexes": {
                    "movies": {
                        "numberOfDocuments": 10,
                        "indexSize": 1572864,
                        "usedIndexSize": 524288,
                        "rawDocumentDbSize": 100,
                        "maxDocumentSize": 16,
                        "avgDocumentSize": 10,
                        "isIndexing": true,
                        "fieldDistribution": {
                            "genre": 10,
                            "author": 9
                        }
                    }
                }
            }
        )),
        (status = 401, description = "The authorization header is missing.", body = ResponseError, content_type = "application/json", example = json!(
            {
                "message": "The Authorization header is missing. It must use the bearer authorization method.",
                "code": "missing_authorization_header",
                "type": "auth",
                "link": "https://docs.meilisearch.com/errors#missing_authorization_header"
            }
        )),
    )
)]
async fn get_stats(
    index_scheduler: GuardedData<ActionPolicy<{ actions::STATS_GET }>, Data<IndexScheduler>>,
    auth_controller: GuardedData<ActionPolicy<{ actions::STATS_GET }>, Data<AuthController>>,
    params: AwebQueryParameter<GetIndexStatsParams, DeserrQueryParamError>,
) -> Result<HttpResponse, ResponseError> {
    let filters = index_scheduler.filters();
    let params = params.into_inner();

    let stats =
        create_all_stats((*index_scheduler).clone(), (*auth_controller).clone(), filters, params)?;

    debug!(returns = ?stats, "Get stats");
    Ok(HttpResponse::Ok().json(stats))
}

pub fn create_all_stats(
    index_scheduler: Data<IndexScheduler>,
    auth_controller: Data<AuthController>,
    filters: &meilisearch_auth::AuthFilter,
    params: GetIndexStatsParams,
) -> Result<Stats, ResponseError> {
    let mut last_task: Option<OffsetDateTime> = None;
    let mut indexes = BTreeMap::new();
    let mut database_size = 0;
    let mut used_database_size = 0;

    let size_format = params.size_format.unwrap_or(SizeFormat::Raw); // default to `raw` for backcompat.
    let Param(show_internal_database_sizes) = params.show_internal_database_sizes;

    for index_uid in index_scheduler.user_index_names()? {
        // Accumulate the size of all indexes, even unauthorized ones, so
        // as to return a database_size representative of the correct database size on disk.
        // See <https://github.com/meilisearch/meilisearch/pull/3541#discussion_r1126747643> for context.
        let stats = index_scheduler.user_index_stats(&index_uid)?;
        database_size += stats.inner_stats.database_size;
        used_database_size += stats.inner_stats.used_database_size;

        if !filters.is_index_authorized(&index_uid) {
            continue;
        }

        last_task = last_task.map_or(Some(stats.inner_stats.updated_at), |last| {
            Some(last.max(stats.inner_stats.updated_at))
        });
        indexes.insert(
            index_uid.to_string(),
            IndexStats::from_db_index_stats(stats, size_format, show_internal_database_sizes),
        );
    }

    database_size += index_scheduler.size()?;
    used_database_size += index_scheduler.used_size()?;
    database_size += auth_controller.size()?;
    used_database_size += auth_controller.used_size()?;

    let database_size = Size::new(database_size, size_format);
    let used_database_size = Size::new(used_database_size, size_format);

    let stats = Stats { database_size, used_database_size, last_update: last_task, indexes };
    Ok(stats)
}

#[derive(Serialize, ToSchema)]
#[serde(rename_all = "camelCase")]
struct VersionResponse {
    /// The commit used to compile this build of Meilisearch.
    commit_sha: String,
    /// The date of this build.
    commit_date: String,
    /// The version of Meilisearch.
    pkg_version: String,
}

/// Get version
///
/// Return the current Meilisearch version, including the commit SHA and build date.
#[routes::path(
    override_tag = "Version",
    security(("Bearer" = ["version", "*"])),
    responses(
        (status = 200, description = "Instance is healthy.", body = VersionResponse, content_type = "application/json", example = json!(
            {
                "commitSha": "b46889b5f0f2f8b91438a08a358ba8f05fc09fc1",
                "commitDate": "2021-07-08",
                "pkgVersion": "0.23.0"
            }
        )),
        (status = 401, description = "The authorization header is missing.", body = ResponseError, content_type = "application/json", example = json!(
            {
                "message": "The Authorization header is missing. It must use the bearer authorization method.",
                "code": "missing_authorization_header",
                "type": "auth",
                "link": "https://docs.meilisearch.com/errors#missing_authorization_header"
            }
        )),
    )
)]
async fn get_version(
    _index_scheduler: GuardedData<ActionPolicy<{ actions::VERSION }>, Data<IndexScheduler>>,
) -> HttpResponse {
    let build_info = build_info::BuildInfo::from_build();

    HttpResponse::Ok().json(VersionResponse {
        commit_sha: build_info.commit_sha1.unwrap_or("unknown").to_string(),
        commit_date: build_info
            .commit_timestamp
            .and_then(|commit_timestamp| {
                commit_timestamp
                    .format(&time::format_description::well_known::Iso8601::DEFAULT)
                    .ok()
            })
            .unwrap_or("unknown".into()),
        pkg_version: env!("CARGO_PKG_VERSION").to_string(),
    })
}

#[derive(Default, Serialize, ToSchema)]
#[serde(rename_all = "camelCase")]
struct HealthResponse {
    /// The status of the instance.
    status: HealthStatus,
}

#[derive(Default, Serialize, ToSchema)]
#[serde(rename_all = "camelCase")]
enum HealthStatus {
    #[default]
    Available,
    MustRestart,
}

/// Get health
///
/// The health check endpoint enables you to periodically test the health of your Meilisearch instance. Returns a simple status indicating that the server is available.
///
/// The engine will return `available` status with a `200` status code when the instance is healthy.
/// It will return `mustRestart` status with a `500` status code if the instance requires a restart.
/// This restart is required after a compaction of the task queue for example.
#[routes::path(
    responses(
        (status = 200, description = "Instance is healthy.", body = HealthResponse, content_type = "application/json", example = json!(
            {
                "status": "available"
            }
        )),
    ),
    override_tag = "Health",
    security()
)]
pub async fn get_health(
    index_scheduler: Data<IndexScheduler>,
    auth_controller: Data<AuthController>,
    search_queue: Data<SearchQueue>,
) -> Result<HttpResponse, ResponseError> {
    if tasks::compact::COMPACTION_SUCCESSFUL.load(Ordering::Relaxed) {
        return Ok(HttpResponse::InternalServerError()
            .json(HealthResponse { status: HealthStatus::MustRestart }));
    }

    search_queue.health().unwrap();
    index_scheduler.health().unwrap();
    auth_controller.health().unwrap();

    Ok(HttpResponse::Ok().json(HealthResponse::default()))
}
