use std::sync::Arc;

use actix_http::StatusCode;
use meili_snap::{json_string, snapshot};
use wiremock::matchers::{method, path, AnyMatcher};
use wiremock::{Mock, MockServer, Request, ResponseTemplate};

use crate::common::{Server, Value, SCORE_DOCUMENTS};
use crate::json;

#[actix_rt::test]
async fn error_feature() {
    let server = Server::new().await;

    let (response, code) = server
        .multi_search(json!({
            "federation": {},
            "queries": [
            {
                "indexUid": "test",
                "federationOptions": {
                    "remote": "toto"
                }
            }
        ]}))
        .await;
    snapshot!(code, @"400 Bad Request");
    snapshot!(json_string!(response), @r###"
    {
      "message": "Inside `.queries[0]`: Performing a remote federated search requires enabling the `network` experimental feature. See https://github.com/orgs/meilisearch/discussions/805",
      "code": "feature_not_enabled",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#feature_not_enabled"
    }
    "###);

    let (response, code) = server
        .multi_search(json!({
            "federation": {},
            "queries": [
            {
                "indexUid": "test",
                "federationOptions": {
                    "queryPosition": 42,
                }
            }
        ]}))
        .await;
    snapshot!(code, @"400 Bad Request");
    snapshot!(json_string!(response), @r###"
    {
      "message": "Inside `.queries[0]`: Using `federationOptions.queryPosition` requires enabling the `network` experimental feature. See https://github.com/orgs/meilisearch/discussions/805",
      "code": "feature_not_enabled",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#feature_not_enabled"
    }
    "###);
}

#[actix_rt::test]
async fn error_params() {
    let server = Server::new().await;

    let (response, code) = server
        .multi_search(json!({
            "federation": {},
            "queries": [
            {
                "indexUid": "test",
                "federationOptions": {
                    "remote": 42
                }
            }
        ]}))
        .await;
    snapshot!(code, @"400 Bad Request");
    snapshot!(json_string!(response), @r###"
    {
      "message": "Invalid value type at `.queries[0].federationOptions.remote`: expected a string, but found a positive integer: `42`",
      "code": "invalid_multi_search_remote",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#invalid_multi_search_remote"
    }
    "###);

    let (response, code) = server
        .multi_search(json!({
            "federation": {},
            "queries": [
            {
                "indexUid": "test",
                "federationOptions": {
                    "queryPosition": "toto",
                }
            }
        ]}))
        .await;
    snapshot!(code, @"400 Bad Request");
    snapshot!(json_string!(response), @r###"
    {
      "message": "Invalid value type at `.queries[0].federationOptions.queryPosition`: expected a positive integer, but found a string: `\"toto\"`",
      "code": "invalid_multi_search_query_position",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#invalid_multi_search_query_position"
    }
    "###);
}

#[actix_rt::test]
async fn remote_sharding() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms2.set_network(json!({"self": "ms2"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms2",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index2.add_documents(json!(documents[3..5]), None).await;
    ms2.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
            "url": rms2.url()
        }
    }});

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms2.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, _status_code) = ms2.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_sharding_federated_pattern_facets() {
    use crate::common::NESTED_DOCUMENTS;

    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms2.set_network(json!({"self": "ms2"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms2",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
            "ms0": {
                "url": rms0.url()
            },
            "ms1": {
                "url": rms1.url()
            },
            "ms2": {
                "url": rms2.url()
            }
        },
        "shards": {
            // Full replication
            "shard1": { "remotes": ["ms0", "ms1", "ms2"] }
        }
    });

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");
    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // list indexes
    let index0 = ms0.index("test");

    // update settings
    let (task, code) = index0
        .update_settings_filterable_attributes(json!([{
            "attributePatterns": ["doggos.*"],
            "features": {
                "facetSearch": true,
                "filter": { "equality": true, "comparison": true }
            }
        }]))
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    // add documents
    let documents = NESTED_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let (task, code) = index0.add_documents(json!(documents), None).await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    // Wait for all the tasks
    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // perform multi-search
    let request = json!({
        "q": null,
        "facets": ["doggos.name", "doggos.age"],
        "useNetwork": true
    });

    let (response, code) = index0.search_post(request).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": 852,
          "father": "jean",
          "mother": "michelle",
          "doggos": [
            {
              "name": "bobby",
              "age": 2
            },
            {
              "name": "buddy",
              "age": 4
            }
          ],
          "cattos": "pésti",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 654,
          "father": "pierre",
          "mother": "sabine",
          "doggos": [
            {
              "name": "gros bill",
              "age": 8
            }
          ],
          "cattos": [
            "simba",
            "pestiféré"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 750,
          "father": "romain",
          "mother": "michelle",
          "cattos": [
            "enigma"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 951,
          "father": "jean-baptiste",
          "mother": "sophie",
          "doggos": [
            {
              "name": "turbo",
              "age": 5
            },
            {
              "name": "fast",
              "age": 6
            }
          ],
          "cattos": [
            "moumoute",
            "gomez"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 4,
      "facetDistribution": {
        "doggos.age": {
          "2": 1,
          "4": 1,
          "5": 1,
          "6": 1,
          "8": 1
        },
        "doggos.name": {
          "bobby": 1,
          "buddy": 1,
          "fast": 1,
          "gros bill": 1,
          "turbo": 1
        }
      },
      "facetStats": {
        "doggos.age": {
          "min": 2.0,
          "max": 8.0
        }
      },
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // update settings
    let (task, code) = index0
        .update_settings_filterable_attributes(json!([{
            "attributePatterns": ["doggos.name", "doggos.age"],
            "features": {
                "facetSearch": true,
                "filter": { "equality": true, "comparison": true }
            }
        }]))
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    // perform multi-search
    let request = json!({
        "q": null,
        "facets": ["doggos.*"],
        "useNetwork": true
    });

    let (response, code) = index0.search_post(request).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": 852,
          "father": "jean",
          "mother": "michelle",
          "doggos": [
            {
              "name": "bobby",
              "age": 2
            },
            {
              "name": "buddy",
              "age": 4
            }
          ],
          "cattos": "pésti",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 654,
          "father": "pierre",
          "mother": "sabine",
          "doggos": [
            {
              "name": "gros bill",
              "age": 8
            }
          ],
          "cattos": [
            "simba",
            "pestiféré"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 750,
          "father": "romain",
          "mother": "michelle",
          "cattos": [
            "enigma"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        },
        {
          "id": 951,
          "father": "jean-baptiste",
          "mother": "sophie",
          "doggos": [
            {
              "name": "turbo",
              "age": 5
            },
            {
              "name": "fast",
              "age": 6
            }
          ],
          "cattos": [
            "moumoute",
            "gomez"
          ],
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms0"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 4,
      "facetDistribution": {
        "doggos.age": {
          "2": 1,
          "4": 1,
          "5": 1,
          "6": 1,
          "8": 1
        },
        "doggos.name": {
          "bobby": 1,
          "buddy": 1,
          "fast": 1,
          "gros bill": 1,
          "turbo": 1
        }
      },
      "facetStats": {
        "doggos.age": {
          "min": 2.0,
          "max": 8.0
        }
      },
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn remote_sharding_auto_search() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms2.set_network(json!({"self": "ms2"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms2",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index2.add_documents(json!(documents[3..5]), None).await;
    ms2.wait_task(task.uid()).await.succeeded();

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
            "url": rms2.url()
        }
    }});

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms2.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform search with network
    let query = "badman returns";
    let request = json!(
    {
        "q": query,
        "useNetwork": true,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    let (response, code) = index1.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    let (response, code) = index2.search_post(request).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms2"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    let request = json!(
    {
        "q": query,
        "useNetwork": true,
        "showPerformanceDetails": true,
    });
    let (response, code) = index2.search_post(request).await;
    snapshot!(code, @"200 OK");
    assert!(response["performanceDetails"].is_object());
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_dsrs() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) =
        ms0.set_features(json!({"network": true, "dynamicSearchRules": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) =
        ms1.set_features(json!({"network": true, "dynamicSearchRules": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) =
        ms2.set_features(json!({"network": true, "dynamicSearchRules": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // dsr created on leader will be propagated after sharding
    let (task, code) = ms0
        .create_dynamic_search_rule(
            "propagated-to-all-remotes",
            json!({
                "active": true,
                "actions": [
                    {
                        "selector": { "id": "remote" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    // dsr created on follower will be deleted after sharding
    let (task, code) = ms1
        .create_dynamic_search_rule(
            "deleted-after-sharding",
            json!({
                "active": true,
                "actions": [
                    {
                        "selector": { "id": "remote" },
                        "action": { "type": "pin", "position": 2 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          },
        },
        "shards": {
          "ms0": {
            "remotes": ["ms0"]
          },
          "ms1": {
            "remotes": ["ms1"]
          },
          "ms2": {
            "remotes": ["ms2"]
          }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (value, code) = ms0.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 1
    }
    "###);

    let (value, code) = ms1.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 1
    }
    "###);

    let (value, code) = ms2.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 1
    }
    "###);

    let (task, code) = ms0
        .create_dynamic_search_rule(
            "propagated-too",
            json!({
                "active": true,
                "actions": [
                    {
                        "selector": { "id": "remote" },
                        "action": { "type": "pin", "position": 1 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (value, code) = ms0.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-too",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 1
              }
            }
          ]
        },
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 2
    }
    "###);

    let (value, code) = ms1.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-too",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 1
              }
            }
          ]
        },
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 2
    }
    "###);

    let (value, code) = ms2.list_dynamic_search_rules().await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(value, {".results[].lastUpdatedAt" => "[updatedAt]"}), @r###"
    {
      "results": [
        {
          "uid": "propagated-too",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 1
              }
            }
          ]
        },
        {
          "uid": "propagated-to-all-remotes",
          "lastUpdatedAt": "[updatedAt]",
          "active": true,
          "conditions": {},
          "actions": [
            {
              "selector": {
                "id": "remote"
              },
              "action": {
                "type": "pin",
                "position": 0
              }
            }
          ]
        }
      ],
      "offset": 0,
      "limit": 20,
      "total": 2
    }
    "###);
}

#[actix_rt::test]
async fn remote_search_filters_out_pinned_documents_excluded_by_filters() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["dynamicSearchRules"], json!(true));

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0.update_settings_filterable_attributes(json!(["kind"])).await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1.update_settings_filterable_attributes(json!(["kind"])).await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = index0
        .add_documents(
            json!([
                { "id": "local-non-match", "title": "Spider-Man", "kind": "keep" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "remote-keep", "title": "Batman Returns", "kind": "keep" },
                { "id": "remote-filtered", "title": "The Matrix", "kind": "drop" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pin-filtered-remote",
            json!({
                "active": true,
                "conditions": {
                    "query": {
                        "words": "returns"
                    }
                },
                "actions": [
                    {
                        "selector": { "id": "remote-filtered" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "Batman Returns",
            "filter": "kind = keep",
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": "remote-keep",
          "title": "Batman Returns",
          "kind": "keep",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        }
      ],
      "query": "Batman Returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 1,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn remote_search_keeps_remote_pins() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["dynamicSearchRules"]), @"true");

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0
        .add_documents(
            json!([
                { "id": "local", "title": "Batman Returns" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "remote", "title": "Batman" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pin-remote",
            json!({
                "active": true,
                "actions": [
                    {
                        "selector": { "id": "remote" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "batman returns",
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["hits"]));
}

#[actix_rt::test]
async fn remote_search_pagination_counts_pins_that_miss_query() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["dynamicSearchRules"], json!(true));

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0
        .add_documents(
            json!([
                { "id": "local-non-match", "title": "Spider-Man" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "remote-organic", "title": "Batman Returns" },
                { "id": "remote-pinned", "title": "The Matrix" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pin-remote-query-miss",
            json!({
                "active": true,
                "conditions": {
                  "query": {
                    "words": "returns"
                  }
                },
                "actions": [
                    {
                        "selector": { "id": "remote-pinned" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "Batman Returns",
            "page": 2,
            "hitsPerPage": 1,
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": "remote-organic",
          "title": "Batman Returns",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        }
      ],
      "query": "Batman Returns",
      "processingTimeMs": "[time]",
      "hitsPerPage": 1,
      "page": 2,
      "totalPages": 2,
      "totalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn remote_search_pumps_pins_when_organic_results_run_out() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["dynamicSearchRules"], json!(true));

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0
        .add_documents(json!([{ "id": "local-non-match", "title": "Spider-Man" }]), None)
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "organic-1", "title": "Batman Returns" },
                { "id": "late-pin-1", "title": "The Matrix" },
                { "id": "organic-2", "title": "Batman Forever" },
                { "id": "late-pin-2", "title": "Superman" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pump-remote-pins",
            json!({
                "active": true,
                "conditions": {
                  "query": {
                    "words": "batman"
                  }
                },
                "actions": [
                    {
                        "selector": { "id": "late-pin-1" },
                        "action": { "type": "pin", "position": 10 }
                    },
                    {
                        "selector": { "id": "late-pin-2" },
                        "action": { "type": "pin", "position": 20 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "Batman",
            "limit": 10,
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".**.weightedRankingScore" => "[score]" }), @r###"
    {
      "hits": [
        {
          "id": "organic-1",
          "title": "Batman Returns",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        },
        {
          "id": "organic-2",
          "title": "Batman Forever",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        },
        {
          "id": "late-pin-1",
          "title": "The Matrix",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        },
        {
          "id": "late-pin-2",
          "title": "Superman",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        }
      ],
      "query": "Batman",
      "processingTimeMs": "[time]",
      "limit": 10,
      "offset": 0,
      "estimatedTotalHits": 4,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "Batman",
            "offset": 2,
            "limit": 2,
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".**.weightedRankingScore" => "[score]" }), @r###"
    {
      "hits": [
        {
          "id": "late-pin-1",
          "title": "The Matrix",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        },
        {
          "id": "late-pin-2",
          "title": "Superman",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": "[score]",
            "remote": "ms1"
          }
        }
      ],
      "query": "Batman",
      "processingTimeMs": "[time]",
      "limit": 2,
      "offset": 2,
      "estimatedTotalHits": 4,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
#[ignore = "distinct/pinning semantics to revisit"]
async fn remote_search_distinct_deduplicates_pinned_documents() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["dynamicSearchRules"]), @"true");

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0.update_settings_filterable_attributes(json!(["series"])).await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1.update_settings_filterable_attributes(json!(["series"])).await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = index0
        .add_documents(
            json!([
                { "id": "local-duplicate", "title": "Batman Returns", "series": "batman" },
                { "id": "local-unique", "title": "Batman Forever", "series": "forever" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "remote-pinned", "title": "The Matrix", "series": "batman" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pin-remote-duplicate",
            json!({
                "active": true,
                "actions": [
                    {
                        "selector": { "id": "remote-pinned" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "batman",
            "distinct": "series",
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": "remote-pinned",
          "title": "The Matrix",
          "series": "batman",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 1.0,
            "extra_document": {},
            "remote": "ms1"
          }
        },
        {
          "id": "local-unique",
          "title": "Batman Forever",
          "series": "forever",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.9848484848484848,
            "remote": "ms0"
          }
        }
      ],
      "query": "batman",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn remote_search_facet_distribution_counts_pins_that_miss_query() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["network"], json!(true));
    let (response, code) = ms1.set_features(json!({"dynamicSearchRules": true})).await;
    assert_eq!(code, StatusCode::OK, "{response}");
    assert_eq!(response["dynamicSearchRules"], json!(true));

    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, code) = index0.update_settings_filterable_attributes(json!(["color"])).await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1.update_settings_filterable_attributes(json!(["color"])).await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = index0
        .add_documents(
            json!([
                { "id": "local-non-match", "title": "Spider-Man", "color": "green" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, code) = index1
        .add_documents(
            json!([
                { "id": "remote-organic", "title": "Batman Returns", "color": "red" },
                { "id": "remote-pinned", "title": "The Matrix", "color": "blue" }
            ]),
            None,
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let (task, code) = ms1
        .create_dynamic_search_rule(
            "pin-remote-for-facets",
            json!({
                "active": true,
                "conditions": {
                  "query": {
                    "words": "returns"
                  }
                },
                "actions": [
                    {
                        "selector": { "id": "remote-pinned" },
                        "action": { "type": "pin", "position": 0 }
                    }
                ]
            }),
        )
        .await;
    snapshot!(code, @"202 Accepted");
    ms1.wait_task(task.uid()).await.succeeded();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        }
    }});

    let (_response, code) = ms0.set_network(network.clone()).await;
    snapshot!(code, @"200 OK");
    let (_response, code) = ms1.set_network(network).await;
    snapshot!(code, @"200 OK");

    let (response, code) = ms0
        .index("test")
        .search_post(json!({
            "q": "Batman Returns",
            "facets": ["color"],
            "useNetwork": true
        }))
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "id": "remote-pinned",
          "title": "The Matrix",
          "color": "blue",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        },
        {
          "id": "remote-organic",
          "title": "Batman Returns",
          "color": "red",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        }
      ],
      "query": "Batman Returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "facetDistribution": {
        "color": {
          "blue": 1,
          "red": 1
        }
      },
      "facetStats": {},
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn remote_sharding_federated_auto_search() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
  {
    "self": "ms0",
    "remotes": {},
    "shards": {},
    "leader": null,
    "version": "[version]"
  }
  "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
  {
    "self": "ms1",
    "remotes": {},
    "shards": {},
    "leader": null,
    "version": "[version]"
  }
  "###);
    let (response, code) = ms2.set_network(json!({"self": "ms2"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
  {
    "self": "ms2",
    "remotes": {},
    "shards": {},
    "leader": null,
    "version": "[version]"
  }
  "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index2.add_documents(json!(documents[3..5]), None).await;
    ms2.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
            "url": rms2.url()
        }
    }});

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms2.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query_1 = "badman";
    let query_2 = "returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query_1,
                "indexUid": "test",
                "useNetwork": true,
            },
            {
                "q": query_2,
                "indexUid": "test",
                "useNetwork": true,
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
  {
    "hits": [
      {
        "title": "Badman",
        "id": "E",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 1.0,
          "remote": "ms2"
        }
      },
      {
        "title": "Batman Returns",
        "id": "C",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.9242424242424242,
          "remote": "ms1"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 1",
        "id": "A",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 2",
        "id": "B",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman",
        "id": "D",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 0.4621212121212121,
          "remote": "ms2"
        }
      }
    ],
    "processingTimeMs": "[time]",
    "limit": 20,
    "offset": 0,
    "estimatedTotalHits": 5,
    "requestUid": "[uuid]",
    "remoteErrors": {}
  }
  "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
  {
    "hits": [
      {
        "title": "Badman",
        "id": "E",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 1.0,
          "remote": "ms2"
        }
      },
      {
        "title": "Batman Returns",
        "id": "C",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.9242424242424242,
          "remote": "ms1"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 1",
        "id": "A",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 2",
        "id": "B",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman",
        "id": "D",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 0.4621212121212121,
          "remote": "ms2"
        }
      }
    ],
    "processingTimeMs": "[time]",
    "limit": 20,
    "offset": 0,
    "estimatedTotalHits": 5,
    "requestUid": "[uuid]",
    "remoteErrors": {}
  }
  "###);
    let (response, _status_code) = ms2.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
  {
    "hits": [
      {
        "title": "Badman",
        "id": "E",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 1.0,
          "remote": "ms2"
        }
      },
      {
        "title": "Batman Returns",
        "id": "C",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.9242424242424242,
          "remote": "ms1"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 1",
        "id": "A",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman the dark knight returns: Part 2",
        "id": "B",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 1,
          "weightedRankingScore": 0.8787878787878788,
          "remote": "ms0"
        }
      },
      {
        "title": "Batman",
        "id": "D",
        "_federation": {
          "indexUid": "test",
          "queriesPosition": 0,
          "weightedRankingScore": 0.4621212121212121,
          "remote": "ms2"
        }
      }
    ],
    "processingTimeMs": "[time]",
    "limit": 20,
    "offset": 0,
    "estimatedTotalHits": 5,
    "requestUid": "[uuid]",
    "remoteErrors": {}
  }
  "###);
}

#[actix_rt::test]
async fn remote_sharding_retrieve_vectors() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms2.set_network(json!({"self": "ms2"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms2",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // setup embedders

    let mock_server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/"))
        .respond_with(move |req: &Request| {
            println!("Received request: {:?}", req);
            let text = req.body_json::<String>().unwrap().to_lowercase();
            let patterns = [
                ("batman", [1.0, 0.0, 0.0]),
                ("dark", [0.0, 0.1, 0.0]),
                ("knight", [0.1, 0.1, 0.0]),
                ("returns", [0.0, 0.0, 0.2]),
                ("part", [0.05, 0.1, 0.0]),
                ("1", [0.3, 0.05, 0.0]),
                ("2", [0.2, 0.05, 0.0]),
            ];
            let mut embedding = vec![0.; 3];
            for (pattern, vector) in patterns {
                if text.contains(pattern) {
                    for (i, v) in vector.iter().enumerate() {
                        embedding[i] += v;
                    }
                }
            }
            ResponseTemplate::new(200).set_body_json(json!({ "data": embedding }))
        })
        .mount(&mock_server)
        .await;
    let url = mock_server.uri();

    for (server, index) in [(&ms0, &index0), (&ms1, &index1), (&ms2, &index2)] {
        let (response, code) = index
            .update_settings(json!({
                "embedders": {
                    "rest": {
                        "source": "rest",
                        "url": url,
                        "dimensions": 3,
                        "request": "{{text}}",
                        "response": { "data": "{{embedding}}" },
                        "documentTemplate": "{{doc.name}}",
                    },
                },
            }))
            .await;
        snapshot!(code, @"202 Accepted");
        server.wait_task(response.uid()).await.succeeded();
    }

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
            "url": rms2.url()
        }
    }});

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms2.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // multi vector search: one query per remote

    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": "batman",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "dark knight",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "returns",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [],
      "queryVectors": {
        "0": [
          1.0,
          0.0,
          0.0
        ],
        "1": [
          0.1,
          0.2,
          0.0
        ],
        "2": [
          0.0,
          0.0,
          0.2
        ]
      },
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 0,
      "requestUid": "[uuid]",
      "remoteErrors": {},
      "semanticHitCount": 0
    }
    "###);

    // multi vector search: two local queries, one remote

    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": "batman",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "dark knight",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "returns",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [],
      "queryVectors": {
        "0": [
          1.0,
          0.0,
          0.0
        ],
        "1": [
          0.1,
          0.2,
          0.0
        ],
        "2": [
          0.0,
          0.0,
          0.2
        ]
      },
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 0,
      "requestUid": "[uuid]",
      "remoteErrors": {},
      "semanticHitCount": 0
    }
    "###);

    // multi vector search: two queries on the same remote

    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": "batman",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "dark knight",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "returns",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [],
      "queryVectors": {
        "0": [
          1.0,
          0.0,
          0.0
        ],
        "1": [
          0.1,
          0.2,
          0.0
        ],
        "2": [
          0.0,
          0.0,
          0.2
        ]
      },
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 0,
      "requestUid": "[uuid]",
      "remoteErrors": {},
      "semanticHitCount": 0
    }
    "###);

    // multi search: two vector, one keyword

    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": "batman",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "dark knight",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 0.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "returns",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [],
      "queryVectors": {
        "0": [
          1.0,
          0.0,
          0.0
        ],
        "2": [
          0.0,
          0.0,
          0.2
        ]
      },
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 0,
      "requestUid": "[uuid]",
      "remoteErrors": {},
      "semanticHitCount": 0
    }
    "###);

    // multi vector search: no local queries, all remote

    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": "batman",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "dark knight",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "returns",
                "indexUid": "test",
                "hybrid": {
                    "semanticRatio": 1.0,
                    "embedder": "rest"
                },
                "retrieveVectors": true,
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [],
      "queryVectors": {
        "0": [
          1.0,
          0.0,
          0.0
        ],
        "1": [
          0.1,
          0.2,
          0.0
        ],
        "2": [
          0.0,
          0.0,
          0.2
        ]
      },
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 0,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn error_unregistered_remote() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r###"
    {
      "message": "Inside `.queries[2]`: Invalid `.federation_options.remote`: remote `ms2` is not registered",
      "code": "invalid_multi_search_remote",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#invalid_multi_search_remote"
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r###"
    {
      "message": "Inside `.queries[2]`: Invalid `.federation_options.remote`: remote `ms2` is not registered",
      "code": "invalid_multi_search_remote",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#invalid_multi_search_remote"
    }
    "###);
}

#[actix_rt::test]
async fn error_no_weighted_score() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::with_params(
        ms1.clone(),
        LocalMeiliParams { gobble_headers: true, ..Default::default() },
    )
    .await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote hit does not contain `._federation.weightedScoreValues`\n  - hint: check that the remote instance is a Meilisearch instance running the same version",
          "code": "remote_bad_response",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_bad_response"
        }
      }
    }
    "###);
}

#[actix_rt::test]
async fn error_bad_response() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::with_params(
        ms1.clone(),
        LocalMeiliParams {
            override_response_body: Some("<html>Returning an HTML page</html>".into()),
            ..Default::default()
        },
    )
    .await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "could not parse response from the remote host as a federated search response:\n  - response from remote: <html>Returning an HTML page</html>\n  - hint: check that the remote instance is a Meilisearch instance running the same version",
          "code": "remote_bad_response",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_bad_response"
        }
      }
    }
    "###);
}

#[actix_rt::test]
async fn error_bad_request() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "nottest",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote host responded with code 400:\n  - response from remote: {\"message\":\"Inside `.queries[1]`: Index `nottest` not found.\",\"code\":\"index_not_found\",\"type\":\"invalid_request\",\"link\":\"https://docs.meilisearch.com/errors#index_not_found\"}\n  - hint: check that the remote instance has the correct index configuration for that request\n  - hint: check that the `network` experimental feature is enabled on the remote instance",
          "code": "remote_bad_request",
          "type": "invalid_request",
          "link": "https://docs.meilisearch.com/errors#remote_bad_request"
        }
      }
    }
    "###);
}

#[actix_rt::test]
async fn error_bad_request_facets_by_index() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test0");
    let index1 = ms1.index("test1");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {
          "facetsByIndex": {
            "test0": []
          }
        },
        "queries": [
            {
                "q": query,
                "indexUid": "test0",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test1",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test0",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test0",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "facetsByIndex": {
        "test0": {
          "distribution": {},
          "stats": {}
        }
      },
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote host responded with code 400:\n  - response from remote: {\"message\":\"Inside `.federation.facetsByIndex.test0`: Index `test0` not found.\\n - Note: index `test0` is not used in queries\",\"code\":\"index_not_found\",\"type\":\"invalid_request\",\"link\":\"https://docs.meilisearch.com/errors#index_not_found\"}\n  - hint: check that the remote instance has the correct index configuration for that request\n  - hint: check that the `network` experimental feature is enabled on the remote instance",
          "code": "remote_bad_request",
          "type": "invalid_request",
          "link": "https://docs.meilisearch.com/errors#remote_bad_request"
        }
      }
    }
    "###);
}

#[actix_rt::test]
async fn error_bad_request_facets_by_index_facet() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, _status_code) = index0.update_settings_filterable_attributes(json!(["id"])).await;
    ms0.wait_task(task.uid()).await.succeeded();

    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {
          "facetsByIndex": {
            "test": ["id"]
          }
        },
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "facetsByIndex": {
        "test": {
          "distribution": {
            "id": {
              "A": 1,
              "B": 1
            }
          },
          "stats": {}
        }
      },
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote host responded with code 400:\n  - response from remote: {\"message\":\"Inside `.queries[1]`: Inside `.federation.facetsByIndex.test`: Invalid facet distribution: Pattern `id` is not filterable. This index does not have configured filterable attributes.\",\"code\":\"invalid_search_facets\",\"type\":\"invalid_request\",\"link\":\"https://docs.meilisearch.com/errors#invalid_search_facets\"}\n  - hint: check that the remote instance has the correct index configuration for that request\n  - hint: check that the `network` experimental feature is enabled on the remote instance",
          "code": "remote_bad_request",
          "type": "invalid_request",
          "link": "https://docs.meilisearch.com/errors#remote_bad_request"
        }
      }
    }
    "###);
}

#[actix_rt::test]
#[ignore]
async fn error_remote_does_not_answer() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "sharding": false
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "sharding": false
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
          "url": "https://thiswebsitedoesnotexist.example"
        }
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "remoteErrors": {
        "ms2": {
          "message": "error sending request",
          "code": "remote_could_not_send_request",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_could_not_send_request"
        }
      }
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r#"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "remoteErrors": {
        "ms2": {
          "message": "error sending request",
          "code": "remote_could_not_send_request",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_could_not_send_request"
        }
      }
    }
    "#);
}

#[ignore = "routes are overridden in remote URLs"]
#[actix_rt::test]
async fn error_remote_404() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": format!("{}/this-route-does-not-exists/", rms1.url())
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote host responded with code 404:\n  - response from remote: null\n  - hint: check that the remote instance has the correct index configuration for that request\n  - hint: check that the `network` experimental feature is enabled on the remote instance",
          "code": "remote_bad_request",
          "type": "invalid_request",
          "link": "https://docs.meilisearch.com/errors#remote_bad_request"
        }
      }
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn error_remote_sharding_auth() {
    let ms0 = Server::new().await;
    let mut ms1 = Server::new_auth().await;
    ms1.use_api_key("MASTER_KEY");

    let (search_api_key_not_enough_indexes, code) = ms1
        .add_api_key(json!({
          "actions": ["search"],
          "indexes": ["nottest"],
          "expiresAt": serde_json::Value::Null
        }))
        .await;
    meili_snap::snapshot!(code, @"201 Created");
    let search_api_key_not_enough_indexes = search_api_key_not_enough_indexes["key"].clone();

    let (api_key_not_search, code) = ms1
        .add_api_key(json!({
          "actions": ["documents.*"],
          "indexes": ["*"],
          "expiresAt": serde_json::Value::Null
        }))
        .await;
    meili_snap::snapshot!(code, @"201 Created");
    let api_key_not_search = api_key_not_search["key"].clone();

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    ms1.clear_api_key();

    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1-nottest": {
            "url": rms1.url(),
            "searchApiKey": search_api_key_not_enough_indexes
        },
        "ms1-notsearch": {
          "url": rms1.url(),
          "searchApiKey": api_key_not_search
        }
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1-nottest"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1-notsearch"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1-notsearch": {
          "message": "could not authenticate against the remote host\n  - hint: check that the remote instance was registered with a valid API key having the `search` action",
          "code": "remote_invalid_api_key",
          "type": "auth",
          "link": "https://docs.meilisearch.com/errors#remote_invalid_api_key"
        },
        "ms1-nottest": {
          "message": "could not authenticate against the remote host\n  - hint: check that the remote instance was registered with a valid API key having the `search` action",
          "code": "remote_invalid_api_key",
          "type": "auth",
          "link": "https://docs.meilisearch.com/errors#remote_invalid_api_key"
        }
      }
    }
    "###);
}

#[actix_rt::test]
async fn remote_sharding_auth() {
    let ms0 = Server::new().await;
    let mut ms1 = Server::new_auth().await;
    ms1.use_api_key("MASTER_KEY");

    let (search_api_key, code) = ms1
        .add_api_key(json!({
          "actions": ["search"],
          "indexes": ["*"],
          "expiresAt": serde_json::Value::Null
        }))
        .await;
    meili_snap::snapshot!(code, @"201 Created");
    let search_api_key = search_api_key["key"].clone();

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    ms1.clear_api_key();
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url(),
            "searchApiKey": "MASTER_KEY"
        },
        "ms1-alias": {
          "url": rms1.url(),
          "searchApiKey": search_api_key
        }
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1-alias"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1-alias"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 4,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn error_remote_500() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::with_params(
        ms1.clone(),
        LocalMeiliParams { fails: FailurePolicy::Always, ..Default::default() },
    )
    .await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            }
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {
        "ms1": {
          "message": "remote host responded with code 500:\n  - response from remote: {\"error\":\"provoked error\",\"code\":\"test_error\",\"link\":\"https://docs.meilisearch.com/errors#test_error\"}",
          "code": "remote_remote_error",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_remote_error"
        }
      }
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    // the response if full because we queried the instance that works
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
async fn error_remote_500_once() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "shards": {},
      "leader": null,
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::with_params(
        ms1.clone(),
        LocalMeiliParams { fails: FailurePolicy::Once, ..Default::default() },
    )
    .await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            }
        ]
    });

    // Meilisearch is tolerant to a single failure
    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[actix_rt::test]
#[ignore]
async fn error_remote_timeout() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // set self

    let (response, code) = ms0.set_network(json!({"self": "ms0"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms0",
      "remotes": {},
      "sharding": false
    }
    "###);
    let (response, code) = ms1.set_network(json!({"self": "ms1"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]"}), @r###"
    {
      "self": "ms1",
      "remotes": {},
      "sharding": false
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let (task, _status_code) = index0.add_documents(json!(documents[0..2]), None).await;
    ms0.wait_task(task.uid()).await.succeeded();
    let (task, _status_code) = index1.add_documents(json!(documents[2..3]), None).await;
    ms1.wait_task(task.uid()).await.succeeded();

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::with_params(
        ms1.clone(),
        LocalMeiliParams { delay: Some(std::time::Duration::from_secs(31)), ..Default::default() },
    )
    .await;

    // set network
    let network = json!({"remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
    }});

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (_response, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");
    let (_response, status_code) = ms1.set_network(network.clone()).await;
    snapshot!(status_code, @"200 OK");

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            }
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "remoteErrors": {
        "ms1": {
          "message": "remote host did not answer before the deadline",
          "code": "remote_timeout",
          "type": "system",
          "link": "https://docs.meilisearch.com/errors#remote_timeout"
        }
      }
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "remoteErrors": {}
    }
    "###);
}

// test: try all the flattened structs in queries

// working facet tests with and without merge

#[derive(Default)]
pub enum FailurePolicy {
    #[default]
    Never,
    Once,
    Always,
}

/// Parameters to change the behavior of the [`LocalMeili`] server.
#[derive(Default)]
pub struct LocalMeiliParams {
    /// delay the response by the specified duration
    pub delay: Option<std::time::Duration>,
    pub fails: FailurePolicy,
    /// replace the reponse body with the provided String
    pub override_response_body: Option<String>,
    pub gobble_headers: bool,
}

/// A server that exploits [`MockServer`] to provide an URL for testing network and the network.
pub struct LocalMeili {
    mock_server: &'static MockServer,
}

impl LocalMeili {
    pub async fn new(server: Arc<Server>) -> Self {
        Self::with_params(server, Default::default()).await
    }

    pub async fn with_params(server: Arc<Server>, params: LocalMeiliParams) -> Self {
        let mock_server = Box::leak(Box::new(MockServer::start().await));

        // tokio won't let us execute asynchronous code from a sync function inside of an async test,
        // so instead we spawn another thread that will call the service on a brand new tokio runtime
        // and communicate via channels...
        let (request_sender, request_receiver) = crossbeam_channel::bounded::<wiremock::Request>(0);
        let (response_sender, response_receiver) =
            crossbeam_channel::bounded::<(Value, StatusCode)>(0);
        std::thread::spawn(move || {
            let rt = tokio::runtime::Builder::new_current_thread().build().unwrap();
            while let Ok(req) = request_receiver.recv() {
                let headers: Vec<(&str, &str)> = if params.gobble_headers {
                    vec![("Content-Type", "application/json")]
                } else {
                    req.headers
                        .iter()
                        .map(|(name, value)| (name.as_str(), value.to_str().unwrap()))
                        .collect()
                };
                let (value, code) = rt.block_on(async {
                    match req.method.as_str() {
                        "POST" => {
                            server.service.post_raw(&req.url, req.body, headers.clone()).await
                        }
                        "PUT" => server.service.put_raw(&req.url, req.body, headers.clone()).await,
                        "PATCH" => server.service.patch_raw(&req.url, req.body, headers).await,
                        "GET" => server.service.get(&req.url).await,
                        "DELETE" => server.service.delete(&req.url, headers).await,
                        _ => unimplemented!(),
                    }
                });
                if response_sender.send((value, code)).is_err() {
                    break;
                }
            }
            println!("exiting mock thread")
        });

        let failed_already = std::sync::atomic::AtomicBool::new(false);

        Mock::given(AnyMatcher)
            .respond_with(move |req: &wiremock::Request| {
                if let Some(delay) = params.delay {
                    std::thread::sleep(delay);
                }
                match params.fails {
                    FailurePolicy::Never => {}
                    FailurePolicy::Once => {
                        let failed_already =
                            failed_already.fetch_or(true, std::sync::atomic::Ordering::AcqRel);
                        if !failed_already {
                            return fail(params.override_response_body.as_deref());
                        }
                    }
                    FailurePolicy::Always => return fail(params.override_response_body.as_deref()),
                }
                request_sender.send(req.clone()).unwrap();
                let (value, code) = response_receiver.recv().unwrap();
                let response = ResponseTemplate::new(code.as_u16());
                if let Some(override_response_body) = params.override_response_body.as_deref() {
                    response.set_body_string(override_response_body)
                } else {
                    response.set_body_json(value)
                }
            })
            .mount(mock_server)
            .await;
        Self { mock_server }
    }

    pub fn url(&self) -> String {
        self.mock_server.uri()
    }
}

fn fail(override_response_body: Option<&str>) -> ResponseTemplate {
    let response = ResponseTemplate::new(500);
    if let Some(override_response_body) = override_response_body {
        response.set_body_string(override_response_body)
    } else {
        response.set_body_json(json!({"error": "provoked error", "code": "test_error", "link": "https://docs.meilisearch.com/errors#test_error"}))
    }
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          },
        },
        "shards": {
          "ms0": {
            "remotes": ["ms0"]
          },
          "ms1": {
            "remotes": ["ms1"]
          },
          "ms2": {
            "remotes": ["ms2"]
          }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let _index1 = ms1.index("test");
    let _index2 = ms2.index("test");

    let (task, _status_code) = index0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // perform multi-search
    let query = "badman returns";
    let request = json!({
        "federation": {},
        "queries": [
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": query,
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, _status_code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, _status_code) = ms2.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_distinct() {
    use crate::common::DOCUMENTS;

    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    {
        let index0 = ms0.index("test");
        let (value, _) =
            index0.update_settings_filterable_attributes(json!(["color", "title"])).await;
        ms0.wait_task(value.uid()).await.succeeded();
    }

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          },
        },
        "shards": {
          "ms0": {
            "remotes": ["ms0"]
          },
          "ms1": {
            "remotes": ["ms1"]
          },
          "ms2": {
            "remotes": ["ms2"]
          }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // add documents
    let documents = DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let _index1 = ms1.index("test");
    let _index2 = ms2.index("test");

    let (task, _status_code) = index0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // no distinct
    let request = json!({
        "federation": {
          "facetsByIndex": {
            "test":["title", "color"],
          },
          "mergeFacets": {}
        },
        "queries": [
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Escape Room",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        },
        {
          "title": "Gläss",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        },
        {
          "title": "Shazam!",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 1.0,
            "remote": "ms2"
          }
        },
        {
          "title": "Captain Marvel",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 1.0,
            "remote": "ms2"
          }
        },
        {
          "title": "How to Train Your Dragon: The Hidden World",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 1.0,
            "remote": "ms2"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "facetDistribution": {
        "color": {
          "blue": 3,
          "green": 2,
          "red": 3,
          "yellow": 2
        },
        "title": {
          "Captain Marvel": 1,
          "Escape Room": 1,
          "Gläss": 1,
          "How to Train Your Dragon: The Hidden World": 1,
          "Shazam!": 1
        }
      },
      "facetStats": {},
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // with distinct
    let request = json!({
        "federation": {
          "distinct": "color",
          "facetsByIndex": {
            "test":["title", "color"],
          },
          "mergeFacets": {}
        },
        "queries": [
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms0"
                }
            },
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms1"
                }
            },
            {
                "q": "",
                "attributesToRetrieve": ["title"],
                "indexUid": "test",
                "federationOptions": {
                    "remote": "ms2"
                }
            },
        ]
    });

    let (response, _status_code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Escape Room",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        },
        {
          "title": "Shazam!",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 2,
            "weightedRankingScore": 1.0,
            "remote": "ms2"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "facetDistribution": {
        "color": {
          "blue": 1,
          "green": 1,
          "red": 1,
          "yellow": 1
        },
        "title": {
          "Escape Room": 1,
          "Shazam!": 1
        }
      },
      "facetStats": {},
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // useNetwork
    let request = json!(
    {
        "q": "",
        "useNetwork": true,
        "facets": ["title", "color"],
        "attributesToRetrieve": ["title"],
        "distinct": "color"
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Escape Room",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms1"
          }
        },
        {
          "title": "Shazam!",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "ms2"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "facetDistribution": {
        "color": {
          "blue": 1,
          "green": 1,
          "red": 1,
          "yellow": 1
        },
        "title": {
          "Escape Room": 1,
          "Shazam!": 1
        }
      },
      "facetStats": {},
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_auto_search() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          }
        },
        "shards": {
            "ms0": {
              "remotes": ["ms0"]
            },
            "ms1": {
              "remotes": ["ms1"]
            },
            "ms2": {
              "remotes": ["ms2"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");

    let (task, _status_code) = index0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // perform search with network
    let query = "badman returns";
    let request = json!(
    {
        "q": query,
        "useNetwork": true,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index1.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index2.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // perform search with implicit network
    let query = "badman returns";
    let request = json!(
    {
        "q": query,
        // default to useNetwork: true in sharding context
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "ms1"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "ms2"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "ms0"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // perform search with explicitly disabled network
    let query = "badman returns";
    let request = json!(
    {
        "q": query,
        "useNetwork": false,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman",
          "id": "D"
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 1,
      "requestUid": "[uuid]"
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_federated_auto_search() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          }
        },
        "shards": {
            "s0": {
              "remotes": ["ms0", "ms1"]
            },
            "s1": {
              "remotes": ["ms1", "ms2"]
            },
            "s2": {
              "remotes": ["ms2", "ms0"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "s0": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "s1": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "s2": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "s0": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "s1": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "s2": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "s0": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "s1": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "s2": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let index2 = ms2.index("test");

    let (task, _status_code) = index0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // perform search with network
    let query = "badman returns";
    let request = json!(
    {
        "q": query,
        "useNetwork": true,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "[remote]"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index1.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "[remote]"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index2.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.8317901234567902,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.7028218694885362,
            "remote": "[remote]"
          }
        },
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.5,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.23106060606060605,
            "remote": "[remote]"
          }
        }
      ],
      "query": "badman returns",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    // perform search with network
    let query_1 = "badman";
    let query_2 = "returns";
    let request = json!(
    {
        "federation": {},
        "queries": [
          {
              "q": query_1,
              "indexUid": "test",
              "useNetwork": true,
          },
          {
              "q": query_2,
              "indexUid": "test",
              "useNetwork": true,
          },
        ]
    });

    let (response, code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.9242424242424242,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.4621212121212121,
            "remote": "[remote]"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.9242424242424242,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.4621212121212121,
            "remote": "[remote]"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = ms2.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]"  }), @r###"
    {
      "hits": [
        {
          "title": "Badman",
          "id": "E",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman Returns",
          "id": "C",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.9242424242424242,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 1",
          "id": "A",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman the dark knight returns: Part 2",
          "id": "B",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 1,
            "weightedRankingScore": 0.8787878787878788,
            "remote": "[remote]"
          }
        },
        {
          "title": "Batman",
          "id": "D",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 0.4621212121212121,
            "remote": "[remote]"
          }
        }
      ],
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 5,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_auto_search_apostrophe_catastrophe() {
    use crate::common::C_EST_FRANÇAIS_DOCUMENTS;

    let ms0 = Server::new().await;
    let ms1 = Server::new().await;

    // enable feature
    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          }
        },
        "shards": {
            "ms0": {
              "remotes": ["ms0"]
            },
            "ms1": {
              "remotes": ["ms1"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = C_EST_FRANÇAIS_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");

    let (task, _status_code) = index0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();

    let (task, _status_code) = index0
        .update_settings(json!({
          "filterableAttributes": ["facette"]
        }))
        .await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();

    // perform search with network
    let request = json!(
    {
        "filter": "facette = \"L'école\"",
        "useNetwork": true,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]"  }), @r###"
    {
      "hits": [
        {
          "id": "D",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "E",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "A",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index1.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "id": "A",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "D",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "E",
          "facette": "L'école",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 3,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);

    // perform search with network
    let request = json!(
    {
        "filter": "facette = '\"Lécole'",
        "useNetwork": true,
    });

    let (response, code) = index0.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "id": "G",
          "facette": "\"Lécole",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "F",
          "facette": "\"Lécole",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) = index1.search_post(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]", ".hits.*._federation.remote" => "[remote]" }), @r###"
    {
      "hits": [
        {
          "id": "F",
          "facette": "\"Lécole",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        },
        {
          "id": "G",
          "facette": "\"Lécole",
          "_federation": {
            "indexUid": "test",
            "queriesPosition": 0,
            "weightedRankingScore": 1.0,
            "remote": "[remote]"
          }
        }
      ],
      "query": "",
      "processingTimeMs": "[time]",
      "limit": 20,
      "offset": 0,
      "estimatedTotalHits": 2,
      "requestUid": "[uuid]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(not(feature = "enterprise"))]
#[actix_rt::test]
async fn sharding_not_enterprise() {
    let ms0 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    let (response, code) = ms0.set_network(json!({"self": "ms0", "leader": "ms0"})).await;
    snapshot!(code, @"451 Unavailable For Legal Reasons");
    snapshot!(json_string!(response), @r###"
    {
      "message": "Meilisearch Enterprise Edition is required to set `network.leader`",
      "code": "requires_enterprise_edition",
      "type": "invalid_request",
      "link": "https://docs.meilisearch.com/errors#requires_enterprise_edition"
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_with_custom_metadata() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!({
      "self": "ms0",
      "leader": "ms0",
      "remotes": {
        "ms0": {
            "url": rms0.url()
        },
        "ms1": {
            "url": rms1.url()
        },
        "ms2": {
            "url": rms2.url()
        }
      },
      "shards": {
          "ms0": {
            "remotes": ["ms0"]
          },
          "ms1": {
            "remotes": ["ms1"]
          },
          "ms2": {
            "remotes": ["ms2"]
          }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = SCORE_DOCUMENTS.clone();
    let documents = documents.as_array().unwrap();
    let index0 = ms0.index("test");
    let _index1 = ms1.index("test");
    let _index2 = ms2.index("test");

    let (task, _status_code) = index0
        .add_documents_with_custom_metadata(
            json!(documents),
            None,
            Some("remote_auto_sharding_with_custom_metadata"),
        )
        .await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    let t = ms0.wait_task(t0).await.succeeded();

    snapshot!(t, @r###"
    {
      "uid": "[uid]",
      "batchUid": "[batch_uid]",
      "indexUid": "test",
      "status": "succeeded",
      "type": "documentAdditionOrUpdate",
      "canceledBy": null,
      "details": {
        "receivedDocuments": 5,
        "indexedDocuments": 1
      },
      "error": null,
      "duration": "[duration]",
      "enqueuedAt": "[date]",
      "startedAt": "[date]",
      "finishedAt": "[date]",
      "network": {
        "remote_tasks": {
          "ms1": {
            "taskUid": 1,
            "error": null
          },
          "ms2": {
            "taskUid": 1,
            "error": null
          }
        },
        "network_version": "[version]"
      },
      "customMetadata": "remote_auto_sharding_with_custom_metadata"
    }
    "###);

    let t = ms1.wait_task(t1).await.succeeded();
    snapshot!(t, @r###"
    {
      "uid": "[uid]",
      "batchUid": "[batch_uid]",
      "indexUid": "test",
      "status": "succeeded",
      "type": "documentAdditionOrUpdate",
      "canceledBy": null,
      "details": {
        "receivedDocuments": 5,
        "indexedDocuments": 2
      },
      "error": null,
      "duration": "[duration]",
      "enqueuedAt": "[date]",
      "startedAt": "[date]",
      "finishedAt": "[date]",
      "network": {
        "origin": {
          "remoteName": "ms0",
          "taskUid": 1,
          "networkVersion": "[version]"
        }
      },
      "customMetadata": "remote_auto_sharding_with_custom_metadata"
    }
    "###);

    let t = ms2.wait_task(t2).await.succeeded();
    snapshot!(t, @r###"
    {
      "uid": "[uid]",
      "batchUid": "[batch_uid]",
      "indexUid": "test",
      "status": "succeeded",
      "type": "documentAdditionOrUpdate",
      "canceledBy": null,
      "details": {
        "receivedDocuments": 5,
        "indexedDocuments": 2
      },
      "error": null,
      "duration": "[duration]",
      "enqueuedAt": "[date]",
      "startedAt": "[date]",
      "finishedAt": "[date]",
      "network": {
        "origin": {
          "remoteName": "ms0",
          "taskUid": 1,
          "networkVersion": "[version]"
        }
      },
      "customMetadata": "remote_auto_sharding_with_custom_metadata"
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_auto_facet_search() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          }
        },
        "shards": {
            "a": {
              "remotes": ["ms0", "ms1"]
            },
            "b": {
              "remotes": ["ms1", "ms2"]
            },
            "c": {
              "remotes": ["ms2", "ms0"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = json!([
      {
        "id": 1,
        "title": "Carol",
        "genres": [
          "Romance",
          "Drama"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "MacOS",
          "Linux",
          "Windows"
        ]
      },
      {
        "id": 2,
        "title": "Wonder Woman",
        "genres": [
          "Action",
          "Adventure"
        ],
        "color": [
          "green"
        ],
        "platforms": [
          "MacOS"
        ]
      },
      {
        "id": 3,
        "title": "Life of Pi",
        "genres": [
          "Adventure",
          "Drama"
        ],
        "color": [
          "blue"
        ],
        "platforms": [
          "Windows"
        ]
      },
      {
        "id": 4,
        "title": "Mad Max: Fury Road",
        "genres": [
          "Adventure",
          "Science Fiction"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "MacOS",
          "Linux"
        ]
      },
      {
        "id": 5,
        "title": "Moana",
        "genres": [
          "Fantasy",
          "Action"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "Windows"
        ]
      },
      {
        "id": 6,
        "title": "Philadelphia",
        "genres": [
          "Drama"
        ],
        "color": [
          "blue"
        ],
        "platforms": [
          "MacOS",
          "Linux",
          "Windows"
        ]
      }
    ]);
    let index0 = ms0.index("test");
    let _index1 = ms1.index("test");
    let _index2 = ms2.index("test");

    let (task, code) = index0.add_documents(documents, None).await;
    snapshot!(code, @"202 Accepted");
    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (task, _status_code) =
        index0.update_settings_filterable_attributes(json!(["genres", "color", "platforms"])).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, code) = index0.facet_search(json!({"facetName": "platforms"})).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "facetHits": [
        {
          "value": "Linux",
          "count": 3
        },
        {
          "value": "MacOS",
          "count": 4
        },
        {
          "value": "Windows",
          "count": 4
        }
      ],
      "facetQuery": null,
      "processingTimeMs": "[time]",
      "remoteErrors": {}
    }
    "###);
    let (response, code) =
        index0.facet_search(json!({"facetName": "platforms", "useNetwork": false})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "facetHits": [
        {
          "value": "Linux",
          "count": 2
        },
        {
          "value": "MacOS",
          "count": 3
        },
        {
          "value": "Windows",
          "count": 4
        }
      ],
      "facetQuery": null,
      "processingTimeMs": "[time]"
    }
    "###);

    let (response, code) =
        index0.facet_search(json!({"facetName": "genres", "facetQuery": "A"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "facetHits": [
        {
          "value": "Action",
          "count": 2
        },
        {
          "value": "Adventure",
          "count": 3
        }
      ],
      "facetQuery": "A",
      "processingTimeMs": "[time]",
      "remoteErrors": {}
    }
    "###);

    let (response, code) =
        index0.facet_search(json!({"facetName": "genres", "facetQuery": "A", "filter": "platforms = Linux OR genres = Drama"})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "facetHits": [
        {
          "value": "Adventure",
          "count": 2
        }
      ],
      "facetQuery": "A",
      "processingTimeMs": "[time]",
      "remoteErrors": {}
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_auto_documents_fetch() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          }
        },
        "shards": {
            "a": {
              "remotes": ["ms0", "ms1"]
            },
            "b": {
              "remotes": ["ms1", "ms2"]
            },
            "c": {
              "remotes": ["ms2", "ms0"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "a": {
          "remotes": [
            "ms0",
            "ms1"
          ]
        },
        "b": {
          "remotes": [
            "ms1",
            "ms2"
          ]
        },
        "c": {
          "remotes": [
            "ms0",
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = json!([
      {
        "id": 1,
        "title": "Carol",
        "genres": [
          "Romance",
          "Drama"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "MacOS",
          "Linux",
          "Windows"
        ],
        "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
        }
      },
      {
        "id": 2,
        "title": "Wonder Woman",
        "genres": [
          "Action",
          "Adventure"
        ],
        "color": [
          "green"
        ],
        "platforms": [
          "MacOS"
        ],
        "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
        }
      },
      {
        "id": 3,
        "title": "Life of Pi",
        "genres": [
          "Adventure",
          "Drama"
        ],
        "color": [
          "blue"
        ],
        "platforms": [
          "Windows"
        ],
        "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
        }
      },
      {
        "id": 4,
        "title": "Mad Max: Fury Road",
        "genres": [
          "Adventure",
          "Science Fiction"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "MacOS",
          "Linux"
        ],
        "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
        }
      },
      {
        "id": 5,
        "title": "Moana",
        "genres": [
          "Fantasy",
          "Action"
        ],
        "color": [
          "red"
        ],
        "platforms": [
          "Windows"
        ]
      },
      {
        "id": 6,
        "title": "Philadelphia",
        "genres": [
          "Drama"
        ],
        "color": [
          "blue"
        ],
        "platforms": [
          "MacOS",
          "Linux",
          "Windows"
        ]
      }
    ]);
    let index0 = ms0.index("test");
    let index1 = ms1.index("test");
    let _index2 = ms2.index("test");

    let (task, code) = index0.add_documents(documents, None).await;
    snapshot!(code, @"202 Accepted");
    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (_task, _status_code) = index0
        .update_settings_sortable_attributes(json!(["genres", "color", "platforms", "_geo"]))
        .await;
    let (task, _status_code) = index0
        .update_settings_filterable_attributes(json!(["genres", "color", "platforms", "_geo"]))
        .await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    println!("platforms:asc");
    let (response, code) =
        index0.fetch_documents(json!({"offset": 0, "limit": 5, "sort": ["platforms:asc"]})).await;

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 1,
          "title": "Carol",
          "genres": [
            "Romance",
            "Drama"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ],
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 6,
          "title": "Philadelphia",
          "genres": [
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ]
        },
        {
          "id": 4,
          "title": "Mad Max: Fury Road",
          "genres": [
            "Adventure",
            "Science Fiction"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux"
          ],
          "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
          }
        },
        {
          "id": 2,
          "title": "Wonder Woman",
          "genres": [
            "Action",
            "Adventure"
          ],
          "color": [
            "green"
          ],
          "platforms": [
            "MacOS"
          ],
          "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
          }
        },
        {
          "id": 3,
          "title": "Life of Pi",
          "genres": [
            "Adventure",
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "Windows"
          ],
          "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
          }
        }
      ],
      "offset": 0,
      "limit": 5,
      "total": 6
    }
    "###);
    snapshot!(code, @"200 OK");

    println!("platforms:asc, useNetwork: false");
    let (response, code) = index0
        .fetch_documents(
            json!({"offset": 0, "limit": 5, "sort": ["platforms:asc"], "useNetwork": false}),
        )
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 1,
          "title": "Carol",
          "genres": [
            "Romance",
            "Drama"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ],
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 6,
          "title": "Philadelphia",
          "genres": [
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ]
        },
        {
          "id": 2,
          "title": "Wonder Woman",
          "genres": [
            "Action",
            "Adventure"
          ],
          "color": [
            "green"
          ],
          "platforms": [
            "MacOS"
          ],
          "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
          }
        },
        {
          "id": 3,
          "title": "Life of Pi",
          "genres": [
            "Adventure",
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "Windows"
          ],
          "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
          }
        },
        {
          "id": 5,
          "title": "Moana",
          "genres": [
            "Fantasy",
            "Action"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "Windows"
          ]
        }
      ],
      "offset": 0,
      "limit": 5,
      "total": 5
    }
    "###);

    println!("genres:asc, filter: platforms = Linux");
    let (response, code) = index0
        .fetch_documents(
            json!({"offset": 0, "limit": 5, "sort": ["genres:asc"], "filter": "platforms = Linux"}),
        )
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 4,
          "title": "Mad Max: Fury Road",
          "genres": [
            "Adventure",
            "Science Fiction"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux"
          ],
          "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
          }
        },
        {
          "id": 1,
          "title": "Carol",
          "genres": [
            "Romance",
            "Drama"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ],
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 6,
          "title": "Philadelphia",
          "genres": [
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ]
        }
      ],
      "offset": 0,
      "limit": 5,
      "total": 3
    }
    "###);

    println!("_geoPoint(48.8561446,2.2978204):asc");
    let (response, code) = index0
        .fetch_documents(
            json!({"offset": 0, "limit": 5, "sort": ["_geoPoint(48.8561446,2.2978204):asc"]}),
        )
        .await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 1,
          "title": "Carol",
          "genres": [
            "Romance",
            "Drama"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ],
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 4,
          "title": "Mad Max: Fury Road",
          "genres": [
            "Adventure",
            "Science Fiction"
          ],
          "color": [
            "red"
          ],
          "platforms": [
            "MacOS",
            "Linux"
          ],
          "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
          }
        },
        {
          "id": 6,
          "title": "Philadelphia",
          "genres": [
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "MacOS",
            "Linux",
            "Windows"
          ]
        },
        {
          "id": 2,
          "title": "Wonder Woman",
          "genres": [
            "Action",
            "Adventure"
          ],
          "color": [
            "green"
          ],
          "platforms": [
            "MacOS"
          ],
          "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
          }
        },
        {
          "id": 3,
          "title": "Life of Pi",
          "genres": [
            "Adventure",
            "Drama"
          ],
          "color": [
            "blue"
          ],
          "platforms": [
            "Windows"
          ],
          "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
          }
        }
      ],
      "offset": 0,
      "limit": 5,
      "total": 6
    }
    "###);

    println!("attributes to retrieve");
    let (response, code) = index0
        .fetch_documents(json!({"offset": 0, "limit": 5, "fields": ["id", "title", "_geo"]}))
        .await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 1,
          "title": "Carol",
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 6,
          "title": "Philadelphia"
        },
        {
          "id": 4,
          "title": "Mad Max: Fury Road",
          "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
          }
        },
        {
          "id": 2,
          "title": "Wonder Woman",
          "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
          }
        },
        {
          "id": 3,
          "title": "Life of Pi",
          "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
          }
        }
      ],
      "offset": 0,
      "limit": 5,
      "total": 6
    }
    "###);

    println!("list documents using GET /indexes/:uid/documents");
    let (response, code) = index0
        .get_all_documents(crate::common::GetAllDocumentsOptions {
            limit: Some(100),
            fields: Some(vec!["id", "title", "_geo"]),
            ..Default::default()
        })
        .await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "results": [
        {
          "id": 1,
          "title": "Carol",
          "_geo": {
            "lat": 34.0522,
            "lng": -118.2437
          }
        },
        {
          "id": 6,
          "title": "Philadelphia"
        },
        {
          "id": 4,
          "title": "Mad Max: Fury Road",
          "_geo": {
            "lat": 61.4777599,
            "lng": 23.1967508
          }
        },
        {
          "id": 2,
          "title": "Wonder Woman",
          "_geo": {
            "lat": "45.4777599",
            "lng": "9.1967508"
          }
        },
        {
          "id": 3,
          "title": "Life of Pi",
          "_geo": {
            "lat": 42.4777599,
            "lng": 12.1967508
          }
        },
        {
          "id": 5,
          "title": "Moana"
        }
      ],
      "offset": 0,
      "limit": 100,
      "total": 6
    }
    "###);

    println!("GET one document using GET /indexes/:uid/documents/:document_id");
    let (response, code) = index0.get_document(1, None).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "id": 1,
      "title": "Carol",
      "genres": [
        "Romance",
        "Drama"
      ],
      "color": [
        "red"
      ],
      "platforms": [
        "MacOS",
        "Linux",
        "Windows"
      ],
      "_geo": {
        "lat": 34.0522,
        "lng": -118.2437
      }
    }
    "###);

    let (response, code) = index1.get_document(1, None).await;
    snapshot!(code, @"200 OK");

    snapshot!(json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" }), @r###"
    {
      "id": 1,
      "title": "Carol",
      "genres": [
        "Romance",
        "Drama"
      ],
      "color": [
        "red"
      ],
      "platforms": [
        "MacOS",
        "Linux",
        "Windows"
      ],
      "_geo": {
        "lat": 34.0522,
        "lng": -118.2437
      }
    }
    "###);
}

#[cfg(feature = "enterprise")]
#[actix_rt::test]
async fn remote_auto_sharding_auto_search_documents_join() {
    let ms0 = Server::new().await;
    let ms1 = Server::new().await;
    let ms2 = Server::new().await;

    // enable feature

    let (response, code) = ms0.set_features(json!({"network": true, "foreignKeys": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    snapshot!(json_string!(response["foreignKeys"]), @"true");
    let (response, code) = ms1.set_features(json!({"network": true, "foreignKeys": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    snapshot!(json_string!(response["foreignKeys"]), @"true");
    let (response, code) = ms2.set_features(json!({"network": true, "foreignKeys": true})).await;
    snapshot!(code, @"200 OK");
    snapshot!(json_string!(response["network"]), @"true");
    snapshot!(json_string!(response["foreignKeys"]), @"true");

    // wrap servers
    let ms0 = Arc::new(ms0);
    let ms1 = Arc::new(ms1);
    let ms2 = Arc::new(ms2);

    let rms0 = LocalMeili::new(ms0.clone()).await;
    let rms1 = LocalMeili::new(ms1.clone()).await;
    let rms2 = LocalMeili::new(ms2.clone()).await;

    // set network
    let network = json!(
      {
        "self": "ms0",
        "leader": "ms0",
        "remotes": {
          "ms0": {
              "url": rms0.url()
          },
          "ms1": {
              "url": rms1.url()
          },
          "ms2": {
              "url": rms2.url()
          }
        },
        "shards": {
            "ms0": {
              "remotes": ["ms0"]
            },
            "ms1": {
              "remotes": ["ms1"]
            },
            "ms2": {
              "remotes": ["ms2"]
            }
        }
      }
    );

    println!("{}", serde_json::to_string_pretty(&network).unwrap());

    let (task, status_code) = ms0.set_network(network.clone()).await;
    snapshot!(status_code, @"202 Accepted");

    let t0 = task.uid();
    let (t, _) = ms0.get_task(t0).await;

    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    let (response, status_code) = ms0.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms0",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms1.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms1",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    let (response, status_code) = ms2.get_network().await;
    snapshot!(status_code, @"200 OK");
    snapshot!(json_string!(response, {".version" => "[version]", ".remotes.*.url" => "[url]"}), @r###"
    {
      "self": "ms2",
      "remotes": {
        "ms0": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms1": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        },
        "ms2": {
          "url": "[url]",
          "searchApiKey": null,
          "writeApiKey": null,
          "status": "available"
        }
      },
      "shards": {
        "ms0": {
          "remotes": [
            "ms0"
          ]
        },
        "ms1": {
          "remotes": [
            "ms1"
          ]
        },
        "ms2": {
          "remotes": [
            "ms2"
          ]
        }
      },
      "leader": "ms0",
      "version": "[version]"
    }
    "###);

    // add documents
    let documents = crate::search::document_join::authors_documents_with_author_profile();
    let documents = documents.as_array().unwrap();
    let authors0 = ms0.index("authors");
    let _authors1 = ms1.index("authors");
    let _authors2 = ms2.index("authors");

    let (_task, _code) = authors0
        .update_settings(json!({ "filterableAttributes": ["id", "birthday", "popularity"] }))
        .await;

    let (_task, _status_code) = authors0.add_documents(json!(documents), None).await;

    let documents = crate::search::document_join::books_documents_with_genres();
    let documents = documents.as_array().unwrap();
    let books0 = ms0.index("books");
    let _books1 = ms1.index("books");
    let _books2 = ms2.index("books");

    let (_task, _code) = books0
        .update_settings(json!({
            "foreignKeys": [
                { "foreignIndexUid": "authors", "fieldName": "author"},
                { "foreignIndexUid": "authors", "fieldName": "related_authors"}
            ],
            "filterableAttributes": ["id", "genres", "author", "related_authors"]
        }))
        .await;

    let (task, _status_code) = books0.add_documents(json!(documents), None).await;

    let t0 = task.uid();
    let (t, _) = ms0.get_task(task.uid()).await;
    let t1 = t["network"]["remote_tasks"]["ms1"]["taskUid"].as_u64().unwrap();
    let t2 = t["network"]["remote_tasks"]["ms2"]["taskUid"].as_u64().unwrap();

    ms0.wait_task(t0).await.succeeded();
    ms1.wait_task(t1).await.succeeded();
    ms2.wait_task(t2).await.succeeded();

    // perform search with network
    let request = json!({
        "federation": {},
        "queries": [
            {
                "indexUid": "books",
                "q": "",
                "filter": "genres = action AND _foreign(author, birthday STARTS WITH \"1958-\" AND popularity >= 3.5)",
                "attributesToRetrieve": ["title", "author", "related_authors", "genres"]
            },
            {
                "indexUid": "books",
                "q": "",
                "filter": "genres = classic AND (_foreign(author, birthday STARTS WITH \"198\") OR _foreign(related_authors, birthday STARTS WITH \"198\"))",
                "attributesToRetrieve": ["title", "author", "related_authors", "genres"]
            }
        ]
    });

    let (response, code) = ms0.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(
        json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" })
    );

    let (response, code) = ms1.multi_search(request.clone()).await;
    snapshot!(code, @"200 OK");
    snapshot!(
        json_string!(response, { ".processingTimeMs" => "[time]", ".requestUid" => "[uuid]" })
    );
}
