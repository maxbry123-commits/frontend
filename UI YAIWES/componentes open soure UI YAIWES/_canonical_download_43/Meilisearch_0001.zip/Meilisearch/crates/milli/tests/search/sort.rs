use big_s::S;
use milli::progress::Progress;
use milli::Criterion::{Attribute, Exactness, Proximity, Typo, Words};
use milli::{AscDesc, Error, Member, Search, TermsMatchingStrategy, UserError};

use crate::search::{self, EXTERNAL_DOCUMENTS_IDS};

#[test]
fn sort_ranking_rule_missing() {
    let criteria = vec![Words, Typo, Proximity, Attribute, Exactness];
    // sortables: `tag` and `asc_desc_rank`
    let index = search::setup_search_index_with_criteria(&criteria);
    let rtxn = index.read_txn().unwrap();
    let fields_ids_map = index.fields_ids_map(&rtxn).unwrap();

    let progress = Progress::default();
    let mut search = Search::new(
        &rtxn,
        &index,
        &fields_ids_map,
        "index_uid",
        time::OffsetDateTime::now_utc(),
        &progress,
    );
    search.query(search::TEST_QUERY);
    search.limit(EXTERNAL_DOCUMENTS_IDS.len());

    search.terms_matching_strategy(TermsMatchingStrategy::default());
    search.sort_criteria(vec![AscDesc::Asc(Member::Field(S("tag")))]);

    let result = search.execute();
    assert!(matches!(result, Err(Error::UserError(UserError::SortRankingRuleMissing))));
}
