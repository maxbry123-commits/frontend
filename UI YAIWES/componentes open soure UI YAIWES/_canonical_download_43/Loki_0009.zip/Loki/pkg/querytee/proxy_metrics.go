package querytee

import (
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

const (
	comparisonMatch    = "match"
	comparisonMismatch = "mismatch"
	comparisonFailed   = "fail"
	comparisonSkipped  = "skipped"

	unknownIssuer = "unknown"
	canaryIssuer  = "loki-canary"
)

type ProxyMetrics struct {
	requestsTotal          *prometheus.CounterVec
	requestDuration        *prometheus.HistogramVec
	responsesTotal         *prometheus.CounterVec
	responsesComparedTotal *prometheus.CounterVec
	missingMetrics         *prometheus.HistogramVec

	// Sampling metrics
	queriesSampled    *prometheus.CounterVec
	samplingDecisions *prometheus.CounterVec

	// Race metrics
	raceWins        *prometheus.CounterVec
	raceModeEnabled prometheus.Gauge
}

func NewProxyMetrics(registerer prometheus.Registerer) *ProxyMetrics {
	m := &ProxyMetrics{
		requestsTotal: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "requests_total",
			Help:      "Total number of HTTP requests received by query-tee.",
		}, []string{"method", "route"}),
		requestDuration: promauto.With(registerer).NewHistogramVec(prometheus.HistogramOpts{
			Namespace:                       "loki_querytee",
			Name:                            "request_duration_seconds",
			Help:                            "Time (in seconds) spent serving HTTP requests.",
			NativeHistogramBucketFactor:     1.1,
			NativeHistogramMaxBucketNumber:  100,
			NativeHistogramMinResetDuration: time.Hour,
		}, []string{"backend", "backend_alias", "method", "route", "status_code", "issuer"}),
		responsesTotal: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "responses_total",
			Help:      "Total number of responses sent back to the client by the selected backend.",
		}, []string{"backend", "backend_alias", "method", "route", "issuer"}),
		responsesComparedTotal: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "responses_compared_total",
			Help:      "Total number of responses compared per route and backend name by result.",
		}, []string{"backend", "backend_alias", "route", "result", "issuer", "tenant"}),
		missingMetrics: promauto.With(registerer).NewHistogramVec(prometheus.HistogramOpts{
			Namespace:                       "loki_querytee",
			Name:                            "missing_metrics_series",
			Help:                            "Number of missing metrics (series) in a vector response.",
			NativeHistogramBucketFactor:     1.1,
			NativeHistogramMaxBucketNumber:  100,
			NativeHistogramMinResetDuration: time.Hour,
		}, []string{"backend", "backend_alias", "route", "status_code", "issuer"}),

		queriesSampled: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "queries_sampled_total",
			Help:      "Total number of queries that were sampled and sent to Kafka.",
		}, []string{"tenant", "route"}),

		samplingDecisions: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "sampling_decisions_total",
			Help:      "Total number of sampling decisions made.",
		}, []string{"tenant", "route", "decision"}),

		raceWins: promauto.With(registerer).NewCounterVec(prometheus.CounterOpts{
			Namespace: "loki_querytee",
			Name:      "race_wins_total",
			Help:      "Total number of times each backend won the race (when racing is enabled).",
		}, []string{"backend", "backend_alias", "route", "issuer"}),

		raceModeEnabled: promauto.With(registerer).NewGauge(prometheus.GaugeOpts{
			Namespace: "loki_querytee",
			Name:      "race_mode_enabled",
			Help:      "Set to 1 if race mode is enabled for this querytee instance, 0 otherwise.",
		}),
	}

	return m
}
