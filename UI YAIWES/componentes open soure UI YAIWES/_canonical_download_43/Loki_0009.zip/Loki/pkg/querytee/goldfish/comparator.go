package goldfish

import (
	"net/http"
	"time"

	logger "github.com/go-kit/log"
	"github.com/go-kit/log/level"

	"github.com/grafana/loki/v3/pkg/goldfish"
	"github.com/grafana/loki/v3/pkg/loghttp"
	"github.com/grafana/loki/v3/pkg/querytee/comparator"
)

const mismatchCauseMissingResponse = "missing_response"

// CompareResponses compares performance statistics and hashes from QuerySample
func CompareResponses(sample *goldfish.QuerySample, cellAResp, cellBResp *ResponseData, performanceTolerance float64, respComparator comparator.ResponsesComparator, logger logger.Logger) goldfish.ComparisonResult {
	result := goldfish.ComparisonResult{
		CorrelationID:     sample.CorrelationID,
		DifferenceDetails: make(map[string]any),
		PerformanceMetrics: goldfish.PerformanceMetrics{
			CellAQueryTime:  time.Duration(sample.CellAStats.ExecTimeMs) * time.Millisecond,
			CellBQueryTime:  time.Duration(sample.CellBStats.ExecTimeMs) * time.Millisecond,
			CellABytesTotal: sample.CellAResponseSize,
			CellBBytesTotal: sample.CellBResponseSize,
		},
		ComparedAt: time.Now(),
	}

	// Calculate ratios
	if sample.CellAStats.ExecTimeMs > 0 {
		result.PerformanceMetrics.QueryTimeRatio = float64(sample.CellBStats.ExecTimeMs) / float64(sample.CellAStats.ExecTimeMs)
	}
	if sample.CellAResponseSize > 0 {
		result.PerformanceMetrics.BytesRatio = float64(sample.CellBResponseSize) / float64(sample.CellAResponseSize)
	}

	// Compare responses using clear matching rules
	switch {
	case sample.CellAStatusCode != sample.CellBStatusCode:
		// Different status codes always indicate a mismatch
		result.ComparisonStatus = goldfish.ComparisonStatusMismatch
		result.MismatchCause = comparator.CauseStatusMismatch
		result.DifferenceDetails["status_code"] = map[string]any{
			"cell_a": sample.CellAStatusCode,
			"cell_b": sample.CellBStatusCode,
		}
		return result

	case sample.CellAStatusCode == sample.CellBStatusCode && sample.CellAStatusCode != http.StatusOK:
		// Same non-200 status codes indicate matching error behavior
		// Both services are failing in the same way (e.g., both returning 404 for not found)
		result.ComparisonStatus = goldfish.ComparisonStatusMatch
		return result

	case sample.CellAResponseHash != sample.CellBResponseHash:
		// Both returned 200 but with different content

		result.DifferenceDetails["content_hash"] = map[string]any{
			"cell_a": sample.CellAResponseHash,
			"cell_b": sample.CellBResponseHash,
		}

		result.ComparisonStatus = goldfish.ComparisonStatusMismatch

		// compare metric query responses with tolerance if comparator is provided
		if respComparator != nil {
			if cellAResp == nil || cellBResp == nil {
				_ = level.Warn(logger).Log(
					"msg", "unable to perform tolerance comparison due to missing responses",
					"correlation_id", sample.CorrelationID,
				)
				result.MismatchCause = mismatchCauseMissingResponse
			} else {
				// Compare the query responses to try to detect the cause of the mismatch.
				// While comparing query responses, the comparator might treat responses as a match in the following scenarios:
				// 1. While comparing sample query responses, the comparator allows drifts in floating-point values for samples up to the configured tolerance.
				// Sample values with drift upto the allowed tolerance are treated as a match.
				// 2. While comparing streams' responses from a logs query, log entries with the exact same timestamp but different content,
				// appearing in different orders across different cells, would be treated as a match.
				summary, err := respComparator.Compare(cellAResp.Body, cellBResp.Body, sample.SampledAt)
				if err != nil {
					if summary != nil && summary.MismatchCause != "" {
						result.MismatchCause = summary.MismatchCause
					}
					level.Error(logger).Log("msg", "response comparison failed", "err", err)
				} else if cellAResp.ResultType == loghttp.ResultTypeStream {
					result.ComparisonStatus = goldfish.ComparisonStatusMatch
				} else {
					result.MatchWithinTolerance = true
					result.ComparisonStatus = goldfish.ComparisonStatusMatchWithinTolerance
				}
			}
		}

		// compare performance statistics if its a match within tolerance.
		if !result.MatchWithinTolerance {
			return result
		}
	default:
		// Both returned 200 with identical content
		result.ComparisonStatus = goldfish.ComparisonStatusMatch
	}

	// Still compare performance statistics for analysis, but don't change match status
	compareQueryStats(sample.CellAStats, sample.CellBStats, &result, performanceTolerance)

	return result
}

// compareQueryStats compares performance statistics between two queries
func compareQueryStats(statsA, statsB goldfish.QueryStats, result *goldfish.ComparisonResult, tolerance float64) {

	// Compare execution times (record variance for analysis)
	if statsA.ExecTimeMs > 0 && statsB.ExecTimeMs > 0 {
		ratio := float64(statsB.ExecTimeMs) / float64(statsA.ExecTimeMs)
		if ratio > (1+tolerance) || ratio < (1-tolerance) {
			result.DifferenceDetails["exec_time_variance"] = map[string]any{
				"cell_a_ms": statsA.ExecTimeMs,
				"cell_b_ms": statsB.ExecTimeMs,
				"ratio":     ratio,
			}
		}
	}

	// Compare bytes processed (should be exactly the same for same query)
	if statsA.BytesProcessed != statsB.BytesProcessed {
		result.DifferenceDetails["bytes_processed"] = map[string]any{
			"cell_a": statsA.BytesProcessed,
			"cell_b": statsB.BytesProcessed,
		}
	}

	// Compare lines processed (should be exactly the same for same query)
	if statsA.LinesProcessed != statsB.LinesProcessed {
		result.DifferenceDetails["lines_processed"] = map[string]any{
			"cell_a": statsA.LinesProcessed,
			"cell_b": statsB.LinesProcessed,
		}
	}

	// Compare total entries returned (should be exactly the same for same query)
	if statsA.TotalEntriesReturned != statsB.TotalEntriesReturned {
		result.DifferenceDetails["entries_returned"] = map[string]any{
			"cell_a": statsA.TotalEntriesReturned,
			"cell_b": statsB.TotalEntriesReturned,
		}
	}
}
