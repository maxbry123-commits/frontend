package index

import (
	"context"
	"errors"
	"fmt"
	"io"
	"sync"
	"time"

	"github.com/go-kit/log"
	"github.com/go-kit/log/level"
	"github.com/grafana/dskit/backoff"
	"github.com/grafana/dskit/services"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/thanos-io/objstore"
	"github.com/twmb/franz-go/pkg/kgo"

	"github.com/grafana/loki/v3/pkg/dataobj"
	"github.com/grafana/loki/v3/pkg/dataobj/index/indexobj"
	"github.com/grafana/loki/v3/pkg/dataobj/metastore"
	"github.com/grafana/loki/v3/pkg/dataobj/metastore/multitenancy"
	"github.com/grafana/loki/v3/pkg/kafka"
	"github.com/grafana/loki/v3/pkg/kafka/client"
	"github.com/grafana/loki/v3/pkg/scratch"
)

var (
	ErrPartitionRevoked  = errors.New("partition revoked")
	ErrIndexerNotRunning = errors.New("indexer service is not running")
)

type triggerType string

const (
	triggerTypeAppend  triggerType = "append"
	triggerTypeMaxIdle triggerType = "max-idle"
	triggerTypeMaxAge  triggerType = "max-age"
)

func (tt triggerType) String() string {
	switch tt {
	case triggerTypeAppend:
		return "append"
	case triggerTypeMaxIdle:
		return "max-idle"
	case triggerTypeMaxAge:
		return "max-age"
	default:
		return "unknown"
	}
}

type bufferedEvent struct {
	event  metastore.ObjectWrittenEvent
	record *kgo.Record
}

type partitionState struct {
	events       []bufferedEvent
	lastActivity time.Time
	isProcessing bool
}

type downloadedObject struct {
	event       metastore.ObjectWrittenEvent
	objectBytes *[]byte
	err         error
}

const (
	defaultIndexConsumerGroup = "index-builder"
)

// An interface for the methods needed from a calculator. Useful for testing.
type calculator interface {
	Calculate(context.Context, log.Logger, *dataobj.Object, string) error
	Flush() (*dataobj.Object, io.Closer, []multitenancy.TimeRange, error)
	// Reset discards any pending state without flushing. Used to clean up after
	// a failed or cancelled build so the next request starts clean; a
	// successful Flush already consumes all state.
	Reset()
	IsFull() bool
}

// An interface for the methods needed from a kafka client. Useful for testing.
type kafkaClient interface {
	PollRecords(context.Context, int) kgo.Fetches
	CommitRecords(context.Context, ...*kgo.Record) error
	Close()
}

type Builder struct {
	services.Service

	cfg  Config
	mCfg metastore.Config

	// Kafka client and topic/partition info
	client kafkaClient

	// Indexer handles all index building
	indexer indexer

	// Partition management only
	partitionStates map[int32]*partitionState
	flushTicker     *time.Ticker

	// Only kafka commit functionality
	metrics *builderMetrics

	// Control and coordination
	wg                 sync.WaitGroup
	logger             log.Logger
	partitionsMutex    sync.Mutex
	activeCalculations map[int32]context.CancelCauseFunc
}

func NewIndexBuilder(
	cfg Config,
	mCfg metastore.Config,
	kafkaCfg kafka.Config,
	logger log.Logger,
	instanceID string,
	bucket objstore.Bucket,
	scratchStore scratch.Store,
	reg prometheus.Registerer,
) (*Builder, error) {
	builderReg := prometheus.WrapRegistererWith(prometheus.Labels{
		"topic":     kafkaCfg.Topic,
		"component": "index_builder",
	}, reg)

	builderMetrics := newBuilderMetrics()
	if err := builderMetrics.register(builderReg); err != nil {
		return nil, fmt.Errorf("failed to register metrics for index builder: %w", err)
	}

	indexerMetrics := newIndexerMetrics()
	if err := indexerMetrics.register(builderReg); err != nil {
		return nil, fmt.Errorf("failed to register indexer metrics: %w", err)
	}

	// Create index building dependencies
	builder, err := indexobj.NewBuilder(cfg.BuilderBaseConfig, scratchStore)
	if err != nil {
		return nil, fmt.Errorf("failed to create index builder: %w", err)
	}
	calculator := NewCalculator(builder)

	indexStorageBucket := objstore.NewPrefixedBucket(bucket, mCfg.IndexStoragePrefix)

	if err := builder.RegisterMetrics(builderReg); err != nil {
		return nil, fmt.Errorf("failed to register metrics for index builder: %w", err)
	}

	if err := calculator.RegisterMetrics(builderReg); err != nil {
		return nil, fmt.Errorf("failed to register metrics for calculator: %w", err)
	}

	s := &Builder{
		cfg:                cfg,
		mCfg:               mCfg,
		logger:             logger,
		metrics:            builderMetrics,
		partitionStates:    make(map[int32]*partitionState),
		activeCalculations: make(map[int32]context.CancelCauseFunc),
	}

	// Create self-contained indexer
	s.indexer = newSerialIndexer(
		calculator,
		bucket,
		indexStorageBucket,
		builderMetrics,
		indexerMetrics,
		logger,
		indexerConfig{QueueSize: 64},
	)

	consumerGroup := defaultIndexConsumerGroup
	if kafkaCfg.ConsumerGroup != "" {
		consumerGroup = kafkaCfg.ConsumerGroup
	}

	kafkaCfg.AutoCreateTopicEnabled = true
	eventConsumerClient, err := client.NewReaderClient(
		"index_builder",
		kafkaCfg,
		logger,
		reg,
		kgo.ConsumeTopics(kafkaCfg.Topic),
		kgo.InstanceID(instanceID),
		kgo.SessionTimeout(3*time.Minute),
		kgo.ConsumerGroup(consumerGroup),
		// Offer both cooperative-sticky and round-robin during migration from eager
		// rebalancing (KIP-429). A follow-up change removes RoundRobin once every
		// index-builder member advertises cooperative-sticky.
		kgo.Balancers(kgo.CooperativeStickyBalancer(), kgo.RoundRobinBalancer()),
		kgo.RebalanceTimeout(5*time.Minute),
		kgo.DisableAutoCommit(),
		kgo.OnPartitionsAssigned(s.handlePartitionsAssigned),
		kgo.OnPartitionsRevoked(s.handlePartitionsRevoked),
		kgo.OnPartitionsLost(s.handlePartitionsLost),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create kafka consumer client: %w", err)
	}
	s.client = eventConsumerClient

	s.Service = services.NewBasicService(s.starting, s.running, s.stopping)

	return s, nil
}

func (p *Builder) handlePartitionsAssigned(_ context.Context, _ *kgo.Client, topics map[string][]int32) {
	p.partitionsMutex.Lock()
	defer p.partitionsMutex.Unlock()

	for _, partitions := range topics {
		for _, partition := range partitions {
			p.partitionStates[partition] = &partitionState{
				events:       make([]bufferedEvent, 0),
				lastActivity: time.Now(),
				isProcessing: false,
			}
		}
	}
}

// This is not thread-safe
func (p *Builder) handlePartitionsRevoked(_ context.Context, _ *kgo.Client, topics map[string][]int32) {
	p.partitionsMutex.Lock()
	defer p.partitionsMutex.Unlock()

	for _, partitions := range topics {
		for _, partition := range partitions {
			// Delete partition metrics to prevent cardinality growth
			p.metrics.deletePartitionMetrics(partition)

			delete(p.partitionStates, partition)

			// Cancel any active calculations
			if cancel, exists := p.activeCalculations[partition]; exists {
				cancel(ErrPartitionRevoked)
				delete(p.activeCalculations, partition)
			}
		}
	}
}

func (p *Builder) handlePartitionsLost(ctx context.Context, client *kgo.Client, topics map[string][]int32) {
	p.handlePartitionsRevoked(ctx, client, topics)
}

func (p *Builder) starting(ctx context.Context) error {
	// Start indexer service first
	if err := services.StartAndAwaitRunning(ctx, p.indexer); err != nil {
		return fmt.Errorf("failed to start indexer service: %w", err)
	}

	// Start flush worker if configured
	if p.cfg.FlushInterval > 0 {
		p.flushTicker = time.NewTicker(p.cfg.FlushInterval)
		p.wg.Go(func() {
			defer p.flushTicker.Stop()

			for {
				select {
				case <-p.flushTicker.C:
					p.checkAndFlushPartitions(ctx)
				case <-ctx.Done():
					return
				}
			}
		})
	}

	level.Info(p.logger).Log("msg", "started index builder service")
	return nil
}

func (p *Builder) running(ctx context.Context) error {
	// Main Kafka processing loop
	for {
		select {
		case <-ctx.Done():
			// Do not return ctx.Err(): a non-nil RunningFn error marks the
			// dskit service Failed, which Loki surfaces as "failed services"
			// on normal shutdown.
			return nil
		default:
		}

		fetches := p.client.PollRecords(ctx, -1)
		if err := fetches.Err0(); err != nil {
			if errors.Is(err, kgo.ErrClientClosed) || errors.Is(err, context.Canceled) {
				return nil
			}
			// Some other error occurred. We will check it in
			// [processFetchTopicPartition] instead.
		}
		if fetches.Empty() {
			continue
		}
		fetches.EachPartition(func(fetch kgo.FetchTopicPartition) {
			if err := fetch.Err; err != nil {
				level.Error(p.logger).Log("msg", "failed to fetch records for topic partition", "topic", fetch.Topic, "partition", fetch.Partition, "err", err.Error())
				return
			}
			for _, record := range fetch.Records {
				p.processRecord(ctx, record)
			}
		})
	}
}

func (p *Builder) stopping(failureCase error) error {
	// Stop accepting new timed flushes first, then drain in-flight flush
	// workers while the indexer is still Running so they can finish or abort
	// cleanly instead of racing Stopping.
	if p.flushTicker != nil {
		p.flushTicker.Stop()
	}

	p.partitionsMutex.Lock()
	for partition, cancel := range p.activeCalculations {
		cancel(nil)
		delete(p.activeCalculations, partition)
	}
	p.partitionsMutex.Unlock()

	p.wg.Wait()

	ctx := context.TODO()
	if err := services.StopAndAwaitTerminated(ctx, p.indexer); err != nil {
		level.Error(p.logger).Log("msg", "failed to stop indexer", "err", err)
	}

	p.client.Close()
	return failureCase
}

// processRecord processes a single record. It is not safe for concurrent use.
func (p *Builder) processRecord(ctx context.Context, record *kgo.Record) {
	calculationCtx, eventsToIndex := p.appendRecord(ctx, record)
	if len(eventsToIndex) == 0 {
		return
	}
	p.buildAndCommitIndex(calculationCtx, eventsToIndex, record.Partition, triggerTypeAppend)
}

// Appends a record and returns a slice of buffered events to index. The slice will be empty if no indexing is required.
func (p *Builder) appendRecord(ctx context.Context, record *kgo.Record) (context.Context, []bufferedEvent) {
	event := &metastore.ObjectWrittenEvent{}
	if err := event.Unmarshal(record.Value); err != nil {
		level.Error(p.logger).Log("msg", "failed to unmarshal metastore event", "err", err)
		return nil, nil
	}

	bufferedEvt := &bufferedEvent{
		event:  *event,
		record: record,
	}

	return p.bufferAndTryProcess(ctx, record.Partition, bufferedEvt, triggerTypeAppend)
}

func (p *Builder) cleanupPartition(partition int32) {
	p.partitionsMutex.Lock()
	defer p.partitionsMutex.Unlock()

	// Cancel active calculation for this partition
	if cancel, exists := p.activeCalculations[partition]; exists {
		cancel(nil)
		delete(p.activeCalculations, partition)
	}

	if state, ok := p.partitionStates[partition]; ok {
		// Clear processed events and reset processing flag
		state.isProcessing = false
		state.lastActivity = time.Now()
	}
}

func (p *Builder) markEventsCompleted(partition int32, eventsProcessed int) {
	p.partitionsMutex.Lock()
	defer p.partitionsMutex.Unlock()

	state, ok := p.partitionStates[partition]
	if !ok {
		return
	}
	state.events = state.events[eventsProcessed:]
}

// Check for partitions that either haven't received new events for MaxIdleTime
// or have buffered events older than MaxAge.
// Flush those partitions.
func (p *Builder) checkAndFlushPartitions(ctx context.Context) {
	p.partitionsMutex.Lock()
	partitionsToFlush := make(map[int32]triggerType)
	for partition, state := range p.partitionStates {
		// Don't flush anything that's currently processing
		if state.isProcessing {
			continue
		}

		// Flush partitions which haven't received new events for MaxIdleTime
		if time.Since(state.lastActivity) >= p.cfg.MaxIdleTime {
			partitionsToFlush[partition] = triggerTypeMaxIdle
			continue
		}

		// Flush partitions with events older than MaxAge
		recordTime := time.Now()
		if len(state.events) > 0 {
			earliestWriteTime, err := time.Parse(time.RFC3339, state.events[0].event.WriteTime)
			if err != nil {
				level.Warn(p.logger).Log("msg", "failed to parse write time", "err", err)
			} else {
				if time.Since(earliestWriteTime) >= p.cfg.MaxAge {
					partitionsToFlush[partition] = triggerTypeMaxAge
					continue
				}
				recordTime = earliestWriteTime
			}
		}

		// If we don't choose to flush a partition, set processing delay based on the
		// earliest event time in the buffer (or current time if there are no events).
		// This is to avoid leaving partitions with no recent activity with high processing delay metrics.
		p.metrics.setProcessingDelay(partition, recordTime)
	}
	p.partitionsMutex.Unlock()

	for partition, triggerType := range partitionsToFlush {
		p.flushPartition(ctx, partition, triggerType)
	}
}

func (p *Builder) flushPartition(ctx context.Context, partition int32, triggerType triggerType) {
	calculationCtx, eventsToFlush := p.bufferAndTryProcess(ctx, partition, nil, triggerType)
	if len(eventsToFlush) == 0 {
		return
	}

	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		level.Info(p.logger).Log("msg", "flushing partition",
			"partition", partition, "events", len(eventsToFlush), "trigger", triggerType)

		p.buildAndCommitIndex(calculationCtx, eventsToFlush, partition, triggerType)
	}()
}

func (p *Builder) buildAndCommitIndex(ctx context.Context, events []bufferedEvent, partition int32, triggerType triggerType) {
	defer p.cleanupPartition(partition)

	// Submit to indexer service and wait for completion
	records, err := p.indexer.submitBuild(ctx, events, partition, triggerType)
	if err != nil {
		if isExpectedBuildAbort(ctx, err) {
			level.Debug(p.logger).Log("msg", "index build aborted", "partition", partition, "err", err, "trigger", triggerType)
			return
		}
		level.Error(p.logger).Log("msg", "failed to build index", "partition", partition, "err", err, "trigger", triggerType)
		return
	}

	// Commit the records
	if err := p.commitRecords(ctx, records); err != nil {
		if isExpectedBuildAbort(ctx, err) {
			level.Debug(p.logger).Log("msg", "index commit aborted", "partition", partition, "err", err, "trigger", triggerType)
			return
		}
		level.Error(p.logger).Log("msg", "failed to commit records", "partition", partition, "err", err, "trigger", triggerType)
		return
	}

	p.markEventsCompleted(partition, len(records))
}

// isExpectedBuildAbort reports whether err is an expected abort from partition
// revocation or service shutdown, not a real build failure.
func isExpectedBuildAbort(ctx context.Context, err error) bool {
	return errors.Is(context.Cause(ctx), ErrPartitionRevoked) ||
		errors.Is(err, context.Canceled) ||
		errors.Is(err, ErrIndexerNotRunning)
}

// bufferAndTryProcess is the unified method that handles both buffering and processing decisions
func (p *Builder) bufferAndTryProcess(ctx context.Context, partition int32, newEvent *bufferedEvent, trigger triggerType) (context.Context, []bufferedEvent) {
	p.partitionsMutex.Lock()
	defer p.partitionsMutex.Unlock()

	state, exists := p.partitionStates[partition]
	if !exists {
		return nil, nil
	}

	// Add new event to buffer if provided (normal processing case)
	if newEvent != nil {
		state.events = append(state.events, *newEvent)
		state.lastActivity = time.Now()
		level.Debug(p.logger).Log("msg", "buffered new event for partition", "count", len(state.events), "partition", partition, "trigger", trigger)
	}

	// Check if we can start processing
	if state.isProcessing || len(state.events) == 0 {
		return nil, nil
	}

	// Check trigger-specific requirements
	if trigger == triggerTypeAppend && len(state.events) < p.cfg.EventsPerIndex {
		return nil, nil
	}

	// Atomically mark as processing and extract events
	state.isProcessing = true
	eventsToProcess := make([]bufferedEvent, len(state.events))
	copy(eventsToProcess, state.events)

	// Set up cancellation context with proper coordination
	calculationCtx, cancel := context.WithCancelCause(ctx)
	p.activeCalculations[partition] = cancel

	level.Debug(p.logger).Log("msg", "started processing partition",
		"partition", partition, "events", len(eventsToProcess), "trigger", trigger)

	return calculationCtx, eventsToProcess
}

func (p *Builder) commitRecords(ctx context.Context, records []*kgo.Record) error {
	if len(records) == 0 {
		return nil
	}

	backoff := backoff.New(ctx, backoff.Config{
		MinBackoff: 100 * time.Millisecond,
		MaxBackoff: 10 * time.Second,
		MaxRetries: 20,
	})

	var lastErr error
	backoff.Reset()
	for backoff.Ongoing() {
		p.metrics.incCommitsTotal()
		err := p.client.CommitRecords(ctx, records...)
		if err == nil {
			return nil
		}
		level.Error(p.logger).Log("msg", "failed to commit records", "err", err, "count", len(records))
		p.metrics.incCommitFailures()
		lastErr = err
		backoff.Wait()
	}
	return lastErr
}
