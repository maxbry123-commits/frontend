package postings

import (
	"time"

	"github.com/grafana/loki/v3/pkg/memory"
)

// labelPostingKey is the unique key for a label posting aggregation entry.
type labelPostingKey struct {
	objectPath   string
	sectionIndex int64
	columnName   string
	labelValue   string
}

// labelPostingEntry holds the aggregated state for a single label posting.
type labelPostingEntry struct {
	ObjectPath       string
	ShardBuckets     int64
	SectionIndex     int64
	ColumnName       string
	LabelValue       string
	bitmap           memory.Bitmap
	MinTimestamp     int64
	MaxTimestamp     int64
	UncompressedSize int64
	MinShardBucket   uint32
	MaxShardBucket   uint32
}

// BitmapBytes returns the raw bytes of the bitmap trimmed to the logical size
// (ceil(Len()/8) bytes). Offset is always 0 for bitmaps built with Resize/Set.
func (e *labelPostingEntry) BitmapBytes() []byte {
	data, _ := e.bitmap.Bytes()
	n := (e.bitmap.Len() + 7) / 8
	if n > len(data) {
		n = len(data)
	}
	return data[:n]
}

// labelAggregator aggregates label posting observations incrementally.
// It is NOT goroutine-safe; callers must synchronize if needed.
type labelAggregator struct {
	entries       map[labelPostingKey]*labelPostingEntry
	estimatedSize int
	minTimestamp  time.Time
	maxTimestamp  time.Time
}

// newLabelAggregator creates a new labelAggregator.
func newLabelAggregator() *labelAggregator {
	return &labelAggregator{
		entries: make(map[labelPostingKey]*labelPostingEntry),
	}
}

// Observe records a single observation of a label posting.
func (a *labelAggregator) Observe(obs LabelObservation) {
	key := labelPostingKey{
		objectPath:   obs.ObjectPath,
		sectionIndex: obs.SectionIndex,
		columnName:   obs.ColumnName,
		labelValue:   obs.LabelValue,
	}

	tsNano := obs.Timestamp.UnixNano()

	ts := obs.Timestamp.UTC()
	if a.minTimestamp.IsZero() || ts.Before(a.minTimestamp) {
		a.minTimestamp = ts
	}
	if a.maxTimestamp.IsZero() || ts.After(a.maxTimestamp) {
		a.maxTimestamp = ts
	}

	entry, ok := a.entries[key]
	if !ok {
		entry = &labelPostingEntry{
			ObjectPath:     obs.ObjectPath,
			ShardBuckets:   obs.ShardBuckets,
			SectionIndex:   obs.SectionIndex,
			ColumnName:     obs.ColumnName,
			LabelValue:     obs.LabelValue,
			bitmap:         memory.NewBitmap(nil, 0),
			MinTimestamp:   tsNano,
			MaxTimestamp:   tsNano,
			MinShardBucket: obs.ShardBucket,
			MaxShardBucket: obs.ShardBucket,
		}
		a.entries[key] = entry

		// Track size for new entry: 5 int64 fields + 2 uint32 fields encoded as int64 + string sizes
		a.estimatedSize += 7*8 + len(obs.ObjectPath) + len(obs.ColumnName) + len(obs.LabelValue)
	}

	// Grow bitmap if needed and set the bit for this stream ID.
	if int(obs.StreamID) >= entry.bitmap.Len() {
		prevLen := entry.bitmap.Len()
		entry.bitmap.Resize(int(obs.StreamID) + 1)
		// Track bitmap growth in estimated size.
		newBytes := (entry.bitmap.Len() + 7) / 8
		oldBytes := (prevLen + 7) / 8
		a.estimatedSize += newBytes - oldBytes
	}
	entry.bitmap.Set(int(obs.StreamID), true)

	if tsNano < entry.MinTimestamp {
		entry.MinTimestamp = tsNano
	}
	if tsNano > entry.MaxTimestamp {
		entry.MaxTimestamp = tsNano
	}
	if obs.ShardBucket < entry.MinShardBucket {
		entry.MinShardBucket = obs.ShardBucket
	}
	if obs.ShardBucket > entry.MaxShardBucket {
		entry.MaxShardBucket = obs.ShardBucket
	}
	entry.UncompressedSize += obs.UncompressedSize
}

// Entries returns all aggregated entries converted to public type. Bitmap
// normalization (padding to equal length) is NOT done here.
func (a *labelAggregator) Entries() []LabelEntry {
	if len(a.entries) == 0 {
		return nil
	}

	result := make([]LabelEntry, 0, len(a.entries))
	for _, entry := range a.entries {
		result = append(result, LabelEntry{
			ObjectPath:       entry.ObjectPath,
			ShardBuckets:     entry.ShardBuckets,
			SectionIndex:     entry.SectionIndex,
			ColumnName:       entry.ColumnName,
			LabelValue:       entry.LabelValue,
			StreamIDBitmap:   entry.BitmapBytes(),
			MinTimestamp:     entry.MinTimestamp,
			MaxTimestamp:     entry.MaxTimestamp,
			UncompressedSize: entry.UncompressedSize,
			MinShardBucket:   entry.MinShardBucket,
			MaxShardBucket:   entry.MaxShardBucket,
		})
	}
	return result
}

// EstimatedSize returns an O(1) estimate of the encoded size of all
// accumulated observations in bytes.
func (a *labelAggregator) EstimatedSize() int {
	return a.estimatedSize
}

// TimeRange returns the minimum and maximum observation timestamp seen by the
// aggregator. It returns zero time.Time values when nothing has been observed.
func (a *labelAggregator) TimeRange() (time.Time, time.Time) {
	return a.minTimestamp, a.maxTimestamp
}

// Reset clears all accumulated state.
func (a *labelAggregator) Reset() {
	a.entries = make(map[labelPostingKey]*labelPostingEntry)
	a.estimatedSize = 0
	a.minTimestamp = time.Time{}
	a.maxTimestamp = time.Time{}
}
