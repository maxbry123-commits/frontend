/*
 * Copyright (C) 2020,2026 Collabora Ltd.
 * Copyright (C) 2022 Alyssa Rosenzweig
 * Copyright (C) 2025 Arm Ltd.
 * SPDX-License-Identifier: MIT
 */

#include "compiler/glsl_types.h"
#include "compiler/nir/nir_builder.h"
#include "panfrost/compiler/pan_compiler.h"
#include "panfrost/compiler/pan_nir.h"
#include "util/perf/cpu_trace.h"

#include "panfrost/model/pan_model.h"
#include "valhall/valhall.h"
#include "bi_debug.h"
#include "bifrost_compile.h"
#include "bifrost_nir.h"
#include "compiler.h"
#include "../kraid/kraid.h"

static bool
bi_use_kraid(nir_shader *nir, uint64_t gpu_id)
{
   return pan_use_kraid(pan_arch(gpu_id), nir->info.stage,
                        nir->info.internal);
}

/*
 * Some operations are only available as 32-bit instructions. 64-bit floats are
 * unsupported and ints are lowered with nir_lower_int64.  Certain 8-bit and
 * 16-bit instructions, however, are lowered here.
 */
struct lower_bit_size_opts {
   bool use_kraid;
   uint64_t gpu_id;
};
static unsigned
bi_lower_bit_size(const nir_instr *instr, void *data)
{
   const struct lower_bit_size_opts *opts = data;
   switch (instr->type) {
   case nir_instr_type_alu: {
      nir_alu_instr *alu = nir_instr_as_alu(instr);
      switch (alu->op) {
      case nir_op_fexp2:
      case nir_op_flog2:
      case nir_op_fpow:
         // Kraid can handle 16-bit fexp/flog/fpow on v12+
         if (opts->use_kraid && pan_arch(opts->gpu_id) >= 12)
            return 0;
         FALLTHROUGH;
      case nir_op_fsin:
      case nir_op_fcos:
      case nir_op_bit_count:
      case nir_op_bitfield_reverse:
         return (nir_src_bit_size(alu->src[0].src) == 32) ? 0 : 32;
      case nir_op_fround_even:
      case nir_op_fceil:
      case nir_op_ffloor:
      case nir_op_ffract:
      case nir_op_ftrunc:
      case nir_op_frexp_sig:
      case nir_op_frexp_exp:
         /* On v11+, FROUND.v2s16 is gone */
         if (pan_arch(opts->gpu_id) < 11)
            return 0;
         return (nir_src_bit_size(alu->src[0].src) == 32) ? 0 : 32;
      case nir_op_iadd:
      case nir_op_isub:
      case nir_op_iadd_sat:
      case nir_op_uadd_sat:
      case nir_op_isub_sat:
      case nir_op_usub_sat:
      case nir_op_ineg:
      case nir_op_iabs:
         /* On v11+, IABS.v4s8, IADD.v4s8 and ISUB.v4s8 are gone */
         if (pan_arch(opts->gpu_id) < 11)
            return 0;

         return (nir_src_bit_size(alu->src[0].src) == 8) ? 16 : 0;
      default:
         return 0;
      }
   }

   case nir_instr_type_intrinsic: {
      nir_intrinsic_instr *intr = nir_instr_as_intrinsic(instr);

      switch (intr->intrinsic) {
      case nir_intrinsic_ballot:
      case nir_intrinsic_ballot_relaxed:
         /* We only support ballot on 32-bit types. */
         return (nir_src_bit_size(intr->src[0]) == 32) ? 0 : 32;
      case nir_intrinsic_read_invocation:
         /* CLPER only supports 32-bit types. */
         return (intr->def.bit_size < 32) ? 32 : 0;
      default:
         return 0;
      }
   }

   default:
      return 0;
   }
}

/* Although Bifrost generally supports packed 16-bit vec2 and 8-bit vec4,
 * transcendentals are an exception. Also shifts because of lane size mismatch
 * (8-bit in Bifrost, 32-bit in NIR TODO - workaround!). Some conversions need
 * to be scalarized due to type size. */

static uint8_t
bi_vectorize_filter(const nir_instr *instr, const void *data)
{
   uint64_t gpu_id = *((uint64_t *)data);

   if (instr->type == nir_instr_type_phi) {
      unsigned bit_size = nir_instr_as_phi(instr)->def.bit_size;
      if (bit_size == 8)
         return 4;
      if (bit_size == 16)
         return 2;
      return 1;
   }

   /* Do not vectorize all non-ALU instruction */
   if (instr->type != nir_instr_type_alu)
      return 0;

   const nir_alu_instr *alu = nir_instr_as_alu(instr);

   switch (alu->op) {
   case nir_op_ball_fequal2:
   case nir_op_ball_fequal3:
   case nir_op_ball_fequal4:
   case nir_op_ball_fequal5:
   case nir_op_ball_fequal8:
   case nir_op_ball_fequal16:
   case nir_op_bany_fnequal2:
   case nir_op_bany_fnequal3:
   case nir_op_bany_fnequal4:
   case nir_op_bany_fnequal5:
   case nir_op_bany_fnequal8:
   case nir_op_bany_fnequal16:
   case nir_op_ball_iequal2:
   case nir_op_ball_iequal3:
   case nir_op_ball_iequal4:
   case nir_op_ball_iequal5:
   case nir_op_ball_iequal8:
   case nir_op_ball_iequal16:
   case nir_op_bany_inequal2:
   case nir_op_bany_inequal3:
   case nir_op_bany_inequal4:
   case nir_op_bany_inequal5:
   case nir_op_bany_inequal8:
   case nir_op_bany_inequal16:
      return 1;
   case nir_op_pack_uvec2_to_uint:
   case nir_op_pack_uvec4_to_uint:
      return 0;
   case nir_op_fexp2:
   case nir_op_flog2:
   case nir_op_fpow:
   case nir_op_frcp:
   case nir_op_frsq:
   case nir_op_ishl:
   case nir_op_ishr:
   case nir_op_ushr:
   case nir_op_extract_u16:
   case nir_op_extract_i16:
   case nir_op_insert_u16:
      return 1;
   case nir_op_f2f16:
   case nir_op_f2f16_rtz:
   case nir_op_f2f16_rtne:
   case nir_op_u2f16:
   case nir_op_i2f16:
      /* On v10 and earlier we can take 2 32-bit floats as srcs, while on v11+
       * we lost all packed F16 conversions.
       */
      return (pan_arch(gpu_id) >= 11) ? 1 : 2;
   /* On v11+, we lost packed 16-bit frexp_*  */
   case nir_op_frexp_sig:
   case nir_op_frexp_exp:
      if (pan_arch(gpu_id) >= 11)
         return 1;

      break;
   default:
      break;
   }

   const uint8_t bit_size =
      MAX2(alu->def.bit_size, nir_src_bit_size(alu->src[0].src));

   if (bit_size == 1)
      return 0;
   else
      return MAX2(1, 32 / bit_size);
}

static bool
mem_vectorize_cb(unsigned align_mul, unsigned align_offset, unsigned bit_size,
                 unsigned num_components, int64_t hole_size,
                 nir_intrinsic_instr *low, nir_intrinsic_instr *high,
                 void *data)
{
   uint64_t gpu_id = *(uint64_t *)data;

   if (hole_size > 0)
      return false;

   /* We have a hard limit of at most 4 components */
   if (num_components > 4)
      return false;

   const unsigned bytes = num_components * (bit_size / 8);
   const unsigned max_bytes = 128u / 8u; /* LOAD.i128 */

   if (bytes > max_bytes)
      return false;

   /* Valhall+ (v9+) supports unaligned load/store, so we don't need the
    * combined access to be naturally aligned.
    */
   if (pan_arch(gpu_id) >= 9)
      return true;

   const unsigned combined_align = nir_combined_align(align_mul, align_offset);
   return bytes <= combined_align;
}

static void
bi_optimize_loop(nir_shader *nir, uint64_t gpu_id, bool allow_copies)
{
   bool progress;

   do {
      progress = false;

      NIR_PASS(progress, nir, nir_split_array_vars, nir_var_function_temp);
      NIR_PASS(progress, nir, nir_shrink_vec_array_vars, nir_var_function_temp);
      NIR_PASS(progress, nir, nir_opt_deref);

      NIR_PASS(progress, nir, nir_lower_vars_to_ssa);
      NIR_PASS(progress, nir, nir_lower_wrmasks);

      if (allow_copies) {
         /* Only run this pass in the first call to bi_optimize_loop. Later
          * calls assume that we've lowered away any copy_deref instructions
          * and we don't want to introduce any more.
          */
         NIR_PASS(progress, nir, nir_opt_find_array_copies);
      }

      NIR_PASS(progress, nir, nir_opt_copy_prop_vars);
      NIR_PASS(progress, nir, nir_opt_dead_write_vars);
      NIR_PASS(progress, nir, nir_opt_combine_stores, nir_var_all);

      NIR_PASS(progress, nir, nir_lower_alu_width, bi_vectorize_filter, &gpu_id);
      NIR_PASS(progress, nir, nir_opt_vectorize, bi_vectorize_filter, &gpu_id);
      NIR_PASS(progress, nir, nir_opt_copy_prop);
      NIR_PASS(progress, nir, nir_opt_dce);
      NIR_PASS(progress, nir, nir_opt_cse);

      nir_opt_peephole_select_options peephole_select_options = {
         .limit = 64,
         .expensive_alu_ok = true,
      };
      NIR_PASS(progress, nir, nir_opt_peephole_select,
               &peephole_select_options);
      NIR_PASS(progress, nir, nir_opt_idiv_const, 8);
      NIR_PASS(progress, nir, nir_opt_algebraic);
      NIR_PASS(progress, nir, nir_opt_constant_folding);

      NIR_PASS(progress, nir, nir_opt_dead_cf);

      bool loop_progress = false;
      NIR_PASS(loop_progress, nir, nir_opt_loop);
      progress |= loop_progress;

      if (loop_progress) {
         /* If nir_opt_loop makes progress, then we need to clean things up
          * if we want any hope of nir_opt_if or nir_opt_loop_unroll to make
          * progress.
          */
         NIR_PASS(progress, nir, nir_opt_copy_prop);
         NIR_PASS(progress, nir, nir_opt_dce);
      }

      /* XXX: On Bifrost (G52), this cause a failure on
       * "dEQP-VK.graphicsfuzz.spv-composite-phi" and is related to an unknown
       * scheduling issue */
      if (pan_arch(gpu_id) >= 9)
         NIR_PASS(
            progress, nir, nir_opt_if,
            nir_opt_if_optimize_phi_true_false | nir_opt_if_avoid_64bit_phis);

      NIR_PASS(progress, nir, nir_opt_phi_to_bool);
      NIR_PASS(progress, nir, nir_opt_loop_unroll);
      NIR_PASS(progress, nir, nir_opt_remove_phis);
      NIR_PASS(progress, nir, nir_opt_undef);
   } while (progress);

   NIR_PASS(_, nir, nir_lower_undef_to_zero, NULL);

   NIR_PASS(_, nir, nir_remove_dead_variables, nir_var_function_temp, NULL);
}

static void
bi_optimize_late(nir_shader *nir, uint64_t gpu_id,
                const struct pan_shader_info *info)
{
   NIR_PASS(_, nir, nir_opt_shrink_stores, false /* shrink_image_store */);
   bi_optimize_loop(nir, gpu_id, false /* allow_copies */);

   NIR_PASS(_, nir, nir_opt_shrink_vectors, false);

   NIR_PASS(_, nir, pan_nir_fuse_io_cvt, gpu_id, &info->varyings.formats);

   /* nir_lower_pack can generate split operations, execute algebraic again to
    * handle them */
   bool algebraic_progress = true;
   while (algebraic_progress) {
      algebraic_progress = false;
      NIR_PASS(algebraic_progress, nir, nir_opt_algebraic);
   }

   /* This is only needed because we support iadd64 but not isub64.
    * nir_opt_algebraic lowers isub64 into iadd64 + ineg64 and since ineg64 is
    * not supported either we lower that too.
    * TODO: wire up isub64 and ineg64, then remove this
    */
   NIR_PASS(_, nir, nir_lower_int64);

   /* Algebraic can materialize instructions with a bit_size that we need to lower */
   NIR_PASS(_, nir, nir_lower_bit_size, bi_lower_bit_size,
            &(struct lower_bit_size_opts) {
               .use_kraid = bi_use_kraid(nir, gpu_id),
               .gpu_id = gpu_id,
            });

   /* We need to cleanup after each iteration of late algebraic
    * optimizations, since otherwise NIR can produce weird edge cases
    * (like fneg of a constant) which we don't handle */
   bool late_algebraic = true;
   while (late_algebraic) {
      late_algebraic = false;
      NIR_PASS(late_algebraic, nir, nir_opt_algebraic_late);
      NIR_PASS(_, nir, nir_lower_alu_width, bi_vectorize_filter, &gpu_id);
      NIR_PASS(_, nir, nir_opt_constant_folding);
      NIR_PASS(_, nir, nir_opt_copy_prop);
      NIR_PASS(_, nir, nir_opt_dce);
      NIR_PASS(_, nir, nir_opt_cse);
   }

   /* This opt currently helps on Bifrost but not Valhall */
   if (pan_arch(gpu_id) < 9)
      NIR_PASS(_, nir, bifrost_nir_opt_boolean_bitwise);

   /* Hoist loop-invariant code out of loops */
   NIR_PASS(_, nir, nir_opt_gcm, false /* value_number */);
   NIR_PASS(_, nir, nir_opt_dce);

   NIR_PASS(_, nir, pan_nir_lower_bool_to_bitsize);
   NIR_PASS(_, nir, nir_lower_alu_width, bi_vectorize_filter, &gpu_id);
   NIR_PASS(_, nir, nir_opt_vectorize, bi_vectorize_filter, &gpu_id);

   /* Prepass to simplify instruction selection */
   bool late_algebraic_progress = true;
   while (late_algebraic_progress) {
      late_algebraic_progress = false;
      NIR_PASS(late_algebraic_progress, nir, bifrost_nir_lower_algebraic_late,
               pan_arch(gpu_id), bi_use_kraid(nir, gpu_id));
      late_algebraic |= late_algebraic_progress;
   }

   while (late_algebraic) {
      late_algebraic = false;
      NIR_PASS(late_algebraic, nir, nir_opt_algebraic_late);
      NIR_PASS(_, nir, nir_lower_alu_width, bi_vectorize_filter, &gpu_id);
      NIR_PASS(_, nir, nir_opt_constant_folding);
      NIR_PASS(_, nir, nir_opt_copy_prop);
      NIR_PASS(_, nir, nir_opt_dce);
      NIR_PASS(_, nir, nir_opt_cse);
   }

   /* Backend scheduler is purely local, so do some global optimizations
    * to reduce register pressure. */
   NIR_PASS(_, nir, nir_opt_sink, nir_move_all);
   NIR_PASS(_, nir, nir_opt_move, nir_move_all);

   /* We might lower attribute, varying, and image indirects. Use the
    * gathered info to skip the extra analysis in the happy path. */
   bool any_indirects =
      nir->info.inputs_read_indirectly || nir->info.outputs_read_indirectly ||
      nir->info.outputs_written_indirectly ||
      nir->info.patch_inputs_read_indirectly ||
      nir->info.patch_outputs_read_indirectly ||
      nir->info.patch_outputs_written_indirectly || nir->info.images_used[0];

   if (any_indirects) {
      nir_divergence_analysis(nir);
      NIR_PASS(_, nir, bi_lower_divergent_indirects,
               pan_subgroup_size(pan_arch(gpu_id)));
   }
}

void
bifrost_preprocess_nir(nir_shader *nir, uint64_t gpu_id)
{
   MESA_TRACE_FUNC();

   NIR_PASS(_, nir, nir_split_var_copies);

   /* The DISCARD instruction just flags the thread as discarded, but the
    * actual termination only happens when all threads in the quad are
    * discarded, or when an instruction with a .discard flow is
    * encountered (Valhall) or when a clause with a .terminate_discarded_thread
    * is reached (Bifrost).
    * We could do without nir_lower_terminate_to_demote(), but this allows
    * for extra dead-code elimination when code sections are detected as
    * being unused after a termination is crossed.
    */
   if (nir->info.stage == MESA_SHADER_FRAGMENT) {
      NIR_PASS(_, nir, nir_lower_terminate_to_demote);
   } else if (nir->info.stage == MESA_SHADER_VERTEX) {
      if (pan_arch(gpu_id) <= 7)
         NIR_PASS(_, nir, pan_nir_lower_vertex_id);
   }

   /* Ensure that halt are translated to returns and get rid of them */
   NIR_PASS(_, nir, nir_lower_halt_to_return);
   NIR_PASS(_, nir, nir_lower_returns);

   /* Get rid of any global vars before we lower to scratch. */
   NIR_PASS(_, nir, nir_lower_global_vars_to_local);

   bi_optimize_loop(nir, gpu_id, true /* allow_copies */);

   NIR_PASS(_, nir, nir_lower_var_copies);
}

static bool
bi_lower_subgroups(nir_builder *b, nir_intrinsic_instr *intr, void *data)
{
   uint64_t gpu_id = *(uint64_t *)data;
   unsigned int arch = pan_arch(gpu_id);

   b->cursor = nir_before_instr(&intr->instr);

   nir_def *val = NULL;
   switch (intr->intrinsic) {
   case nir_intrinsic_vote_any:
      val = nir_ine_imm(b, nir_ballot(b, 1, 32, intr->src[0].ssa), 0);
      break;

   case nir_intrinsic_vote_all:
      val = nir_ieq_imm(b, nir_ballot(b, 1, 32, nir_inot(b, intr->src[0].ssa)), 0);
      break;

   case nir_intrinsic_load_subgroup_id: {
      nir_def *local_id = nir_load_local_invocation_id(b);
      nir_def *local_size = nir_load_workgroup_size(b);
      /* local_id.x + local_size.x * (local_id.y + local_size.y * local_id.z) */
      nir_def *flat_local_id =
         nir_iadd(b,
            nir_channel(b, local_id, 0),
            nir_imul(b,
               nir_channel(b, local_size, 0),
               nir_iadd(b,
                  nir_channel(b, local_id, 1),
                  nir_imul(b,
                     nir_channel(b, local_size, 1),
                     nir_channel(b, local_id, 2)))));
      /*
       * nir_udiv_imm with a power of two divisor, which pan_subgroup_size is,
       * will construct a right shift instead of an udiv.
       */
      val = nir_udiv_imm(b, flat_local_id, pan_subgroup_size(arch));
      break;
   }

   case nir_intrinsic_load_subgroup_size:
      val = nir_imm_int(b, pan_subgroup_size(arch));
      break;

   case nir_intrinsic_load_num_subgroups: {
      uint32_t subgroup_size = pan_subgroup_size(arch);
      assert(!b->shader->info.workgroup_size_variable);
      uint32_t workgroup_size =
         b->shader->info.workgroup_size[0] *
         b->shader->info.workgroup_size[1] *
         b->shader->info.workgroup_size[2];
      uint32_t num_subgroups = DIV_ROUND_UP(workgroup_size, subgroup_size);
      val = nir_imm_int(b, num_subgroups);
      break;
   }

   default:
      return false;
   }

   nir_def_rewrite_uses(&intr->def, val);
   return true;
}

/* Workgroups may be merged if the structure of the workgroup is not software
 * visible. This is true if neither shared memory nor BARRIER instructions nor
 * subgroups are used. The hardware may be able to optimize compute shaders
 * that set this flag.
 *
 * From the vulkan spec version 1.4.317 section 9.25.8:
 *
 *    "For shaders that have defined workgroups, each invocation in a subgroup
 *     must be in the same local workgroup."
 */
bool
valhall_can_merge_workgroups(nir_shader *nir)
{
   if (nir->info.shared_size != 0)
      return false;

   nir_foreach_function_impl(impl, nir) {
      nir_foreach_block(block, impl) {
         nir_foreach_instr(instr, block) {
            if (instr->type != nir_instr_type_intrinsic)
               continue;

            /* We only emit BARRIER instructions for workgroup execution
             * barriers. For subgroup execution barriers, the only consequence
             * of merging workgroups is that the scope may be larger, which is
             * allowed. */
            nir_intrinsic_instr *intrin = nir_instr_as_intrinsic(instr);
            if (intrin->intrinsic == nir_intrinsic_barrier &&
                nir_intrinsic_execution_scope(intrin) == SCOPE_WORKGROUP)
               return false;

            /* This is in nir->info.uses_wide_subgroups, but we don't want to
             * force an extra nir_gather_shader_info call. */
            if (nir_intrinsic_has_semantic(intrin, NIR_INTRINSIC_SUBGROUP))
               return false;

            /* load_subgroup_invocation allows observing merged workgroups
             * because the first thread in the workgroup may have a nonzero
             * subgroup invocation and so on. We don't have to care about
             * load_subgroup_id, because we implement it by dividing the local
             * invocation id, so it doesn't care what the actual subgroup
             * layout is in hw.
             *
             * Note that these intrinsics do not have NIR_INTRINSIC_SUBGROUP
             * because they do not perform any communication with other
             * subgroup threads. */
            if (intrin->intrinsic == nir_intrinsic_load_subgroup_invocation)
               return false;
         }
      }
   }

   return true;
}

static bool
bi_lower_load_output(nir_builder *b, nir_intrinsic_instr *intr,
                     UNUSED void *data)
{
   if (intr->intrinsic != nir_intrinsic_load_output)
      return false;

   unsigned loc = nir_intrinsic_io_semantics(intr).location;
   assert(loc >= FRAG_RESULT_DATA0);
   unsigned rt = loc - FRAG_RESULT_DATA0;

   b->cursor = nir_before_instr(&intr->instr);

   nir_def *conversion = nir_load_rt_conversion_pan(
      b, .base = rt, .src_type = nir_intrinsic_dest_type(intr));

   nir_def *lowered = nir_load_tile_pan(
      b, intr->def.num_components, intr->def.bit_size,
      pan_nir_tile_location_sample(b, loc, nir_imm_int(b, 0)),
      pan_nir_tile_default_coverage(b),
      conversion, .dest_type = nir_intrinsic_dest_type(intr),
      .io_semantics = nir_intrinsic_io_semantics(intr));

   nir_def_rewrite_uses(&intr->def, lowered);
   return true;
}

static bool
bifrost_nir_lower_load_output(nir_shader *nir)
{
   assert(nir->info.stage == MESA_SHADER_FRAGMENT);

   return nir_shader_intrinsics_pass(
      nir, bi_lower_load_output,
      nir_metadata_control_flow, NULL);
}

static bool
bytes_can_straddle_boundary(unsigned bytes, unsigned align_mul,
                            unsigned align_off, unsigned boundary)
{
   /* addr = k*align_mul + align_off */
   assert(IS_POT(align_mul));
   assert(align_off < align_mul);
   assert(IS_POT(boundary));

   if (align_mul >= boundary)
      return (align_off % boundary) + bytes > boundary;
   else
      return align_off + bytes > align_mul;
}

static nir_mem_access_size_align
size_align_for_bytes(uint8_t bytes, uint8_t bit_size,
                     uint32_t align_mul, uint32_t align_off)
{
   /* Grab the largest power of two which divides bytes */
   assert(bytes != 0);
   uint8_t bytes_max_bit_size = 8 << (ffs(bytes) - 1);

   /* Clamp the bit size if needed */
   bit_size = MIN3(bit_size, bytes_max_bit_size, 64);

   return (nir_mem_access_size_align) {
      .num_components = (bytes * 8) / bit_size,
      .bit_size = bit_size,
      .align = nir_combined_align(align_mul, align_off),
      .shift = nir_mem_access_shift_method_scalar,
   };
}

static nir_mem_access_size_align
scratch_access_size_align_v9(uint8_t bytes, uint8_t bit_size,
                             uint32_t align_mul, uint32_t align_off)
{
   /* On v9-v10, we must never straddle the 16-byte boundary. */
   while (bytes_can_straddle_boundary(bytes, align_mul, align_off, 16))
      bytes--;

   return size_align_for_bytes(bytes, bit_size, align_mul, align_off);
}

static nir_mem_access_size_align
scratch_access_size_align_v11(uint8_t bytes, uint8_t bit_size,
                              uint32_t align_mul, uint32_t align_off,
                              bool is_store)
{
   assert(align_off < align_mul);

   /* v11+ has complex rules based on how many bytes are accessed, check if the
    * access is legal, otherwise reduce the amount of bytes accessed.
    */
   for (; bytes > 1; bytes--) {
      switch (bytes) {
      case 2:
         /* Must not straddle 4 bytes boundaries */
         if (bytes_can_straddle_boundary(bytes, align_mul, align_off, 4))
            continue;

         return size_align_for_bytes(1, bit_size, align_mul, align_off);

      case 3:
         /* No restrictions for store */
         if (is_store)
            return size_align_for_bytes(3, 8, align_mul, align_off);

         /* We can do 3-byte loads as long as they're aligned to 4 bytes.
          * If align_off == 1, nir_lower_mem_access_bit_sizes() will upgrade
          * to an aligned 4-byte load and shift the result.
          */
         if (align_mul >= 4 && align_off <= 1)
            return size_align_for_bytes(3, 8, 4, 0);

         /* Otherwise, we have to split the load */
         continue;

      case 4:
      case 8:
      case 16:
         /* Must be 4-byte aligned */
         if (nir_combined_align(align_mul, align_off) < 4)
            continue;

         return size_align_for_bytes(bytes, bit_size, align_mul, align_off);

      case 6:
         if (is_store) {
            /* Stores must not straddle 4 bytes boundaries. */
            if (bytes_can_straddle_boundary(bytes, align_mul, align_off, 4))
               continue;

            return size_align_for_bytes(6, bit_size, align_mul, align_off);
         } else {
            /* Loads must be aligned to 4 bytes. */
            if (nir_combined_align(align_mul, align_off) < 4)
               continue;

            return size_align_for_bytes(6, bit_size, 4, 0);
         }

      default: /* 5, 7, 9-15 */
         /* All other sizes have to fall back to a smaller load */
         continue;
      }
   }

   /* 1-byte accesses are always unrestricted */
   assert(bytes == 1);
   return size_align_for_bytes(1, 8, align_mul, align_off);
}

static nir_mem_access_size_align
mem_access_size_align_cb(nir_intrinsic_op intrin, uint8_t bytes,
                         uint8_t bit_size, uint32_t align_mul,
                         uint32_t align_offset, bool offset_is_const,
                         enum gl_access_qualifier access, const void *cb_data)
{
   uint64_t gpu_id = *(uint64_t *)cb_data;
   uint32_t align = nir_combined_align(align_mul, align_offset);
   assert(util_is_power_of_two_nonzero(align));

   bool is_scratch = intrin == nir_intrinsic_load_scratch ||
                     intrin == nir_intrinsic_store_scratch;

   /* No more than 16 bytes at a time. */
   bytes = MIN2(bytes, 16);

   /* TLS memory requires special alignment, handle it separately */
   if (pan_arch(gpu_id) >= 9 && is_scratch) {
      bool is_store = intrin == nir_intrinsic_store_scratch;

      if (pan_arch(gpu_id) >= 11)
         return scratch_access_size_align_v11(bytes, bit_size, align_mul,
                                                align_offset, is_store);
      else
         return scratch_access_size_align_v9(bytes, bit_size, align_mul,
                                             align_offset);
   }

   /* All loads must be aligned up to the next power of two of their byte
    * size. If we have insufficient alignment, split into smaller loads.
    *
    * Valhall+ (v9+) supports unaligned global/shared accesses, so we don't
    * split them for alignment there.
    */
   unsigned required_align = util_next_power_of_two(bytes);
   if (pan_arch(gpu_id) >= 9) {
      required_align = MIN2(align, required_align);
   } else if (align < required_align) {
      bytes = align;
      required_align = bytes;
   }

   /* If the number of bytes is a multiple of 4, use 32-bit loads. Else if it's
    * a multiple of 2, use 16-bit loads. Else use 8-bit loads.
    *
    * But if we're only aligned to 1 byte, use 8-bit loads. If we're only
    * aligned to 2 bytes, use 16-bit loads, unless we needed 8-bit loads due to
    * the size.
    */
   if ((bytes & 1) || (align == 1))
      bit_size = 8;
   else if ((bytes & 2) || (align == 2))
      bit_size = 16;
   else if (bit_size >= 32)
      bit_size = 32;

   unsigned num_comps = MIN2(bytes / (bit_size / 8), 4);

   /* Push constants require 32-bit loads. */
   if (intrin == nir_intrinsic_load_push_constant) {
      /* We need to read also the "padding" sitting between the 4-byte boundary
       * and the data we require, for align_mul >= 4 that is align_offset
       * directly, otherwise we need to find the worst possible aligned address
       */
      unsigned pad = align_mul >= 4 ? (align_offset % 4) :
                                      (align_offset + 4 - align_mul);
      num_comps = DIV_ROUND_UP(pad + bytes, 4);
      bit_size = MAX2(bit_size, 32);
      required_align = 4;
   }

   return (nir_mem_access_size_align){
      .num_components = num_comps,
      .bit_size = bit_size,
      .align = required_align,
      .shift = nir_mem_access_shift_method_scalar,
   };
}

static bool
nir_shader_has_local_variables(const nir_shader *nir)
{
   nir_foreach_function(func, nir) {
      if (func->impl && !exec_list_is_empty(&func->impl->locals))
         return true;
   }

   return false;
}

static bool pan_nir_lower_buf_image_access(nir_shader *nir, unsigned arch);
static bool bi_should_idvs(nir_shader *nir, const struct pan_compile_inputs *inputs);
static bool bifrost_nir_lower_vs_atomics(nir_shader *nir);

void
bifrost_postprocess_nir(nir_shader *nir,
                        const struct pan_compile_inputs *inputs,
                        struct pan_shader_info *info)
{
   MESA_TRACE_FUNC();

   const uint64_t gpu_id = inputs->gpu_id;
   const unsigned gpu_arch = pan_arch(gpu_id);

   if (gpu_arch >= 9)
      NIR_PASS(_, nir, pan_nir_lower_image_64bit);

   NIR_PASS(_, nir, nir_lower_image_atomics_to_global, NULL, NULL);

   /* on Bifrost, lower MSAA load/stores to 3D load/stores */
   if (gpu_arch < 9)
      NIR_PASS(_, nir, pan_nir_lower_image_ms);

   NIR_PASS(_, nir, pan_nir_lower_buf_image_access, gpu_arch);

   /* We assume that UBO and SSBO were lowered, let's move things around. */
   NIR_PASS(_, nir, nir_opt_sink, nir_move_all);
   NIR_PASS(_, nir, nir_opt_move, nir_move_all);

   if (nir->info.stage == MESA_SHADER_FRAGMENT) {
      NIR_PASS(_, nir, nir_lower_is_helper_invocation);
      NIR_PASS(_, nir, pan_nir_lower_helper_invocation);
      NIR_PASS(_, nir, pan_nir_lower_sample_pos);
      NIR_PASS(_, nir, nir_lower_frag_coord_to_pixel_coord);
      NIR_PASS(_, nir, pan_nir_lower_var_special_pan);

      NIR_PASS(_, nir, nir_lower_mediump_io, nir_var_shader_out, 0, false);

      NIR_PASS(_, nir, bifrost_nir_lower_load_output);

      /* Collect format varyings */
      pan_varying_collect_formats(&info->varyings.formats, nir, inputs->gpu_id);

      NIR_PASS(_, nir, pan_nir_resize_varying_io, &info->varyings.formats,
               inputs->varying_layout ?: &info->varyings.formats);
      NIR_PASS(_, nir, nir_lower_io_to_scalar, nir_var_shader_in, NULL, NULL);
      NIR_PASS(_, nir, nir_opt_vectorize_io, nir_var_shader_in, false);

      if (!inputs->is_blend)
         NIR_PASS(_, nir, pan_nir_lower_fs_inputs, inputs->gpu_id,
                  inputs->varying_layout, info);

      /* Blit shaders may not need to run ATEST, since ATEST is not needed if
       * early-z is forced, alpha-to-coverage is disabled, and there are no
       * writes to the coverage mask. The latter two are satisfied for all
       * blit shaders, so we just care about early-z, which blit shaders force
       * iff they do not write depth or stencil
       */
      const bool emit_zs =
         nir->info.outputs_written & (BITFIELD_BIT(FRAG_RESULT_DEPTH) |
                                      BITFIELD_BIT(FRAG_RESULT_STENCIL));
      const bool skip_atest = inputs->is_blit && !emit_zs;
      NIR_PASS(_, nir, pan_nir_lower_fs_outputs, skip_atest,
               inputs->fragcolor_nr_cbufs);
   } else if (nir->info.stage == MESA_SHADER_VERTEX) {
      NIR_PASS(_, nir, nir_lower_viewport_transform);
      NIR_PASS(_, nir, nir_lower_point_size, 1.0, 0.0);

      /* Copy varying format & Layout */
      assert(inputs->varying_layout);
      memcpy(&info->varyings.formats, inputs->varying_layout,
             sizeof(*inputs->varying_layout));

      NIR_PASS(_, nir, pan_nir_resize_varying_io, &info->varyings.formats,
               &info->varyings.formats);

      info->vs.idvs = bi_should_idvs(nir, inputs);

      if (info->vs.idvs && nir->info.writes_memory)
         NIR_PASS(_, nir, bifrost_nir_lower_vs_atomics);

      /* Needs to run after lower_vs_atomics as it inserts operations between
       * ssbo_atomic and store_output */
      NIR_PASS(_, nir, pan_nir_lower_noperspective_vs);
      NIR_PASS(_, nir, pan_nir_lower_vs_inputs, inputs->gpu_id);
      NIR_PASS(_, nir, pan_nir_lower_vs_outputs, inputs->gpu_id,
               inputs->varying_layout, info->vs.idvs,
               &info->vs.needs_extended_fifo);
   }

   NIR_PASS(_, nir, pan_nir_lower_tex, gpu_id);
   NIR_PASS(_, nir, pan_nir_lower_image, gpu_id);

   /* Remove useless movs left behind from lower_io_to_scalar/vectorize_io */
   NIR_PASS(_, nir, nir_opt_copy_prop);

   /* Why aren't we vectorizing nir_var_shader_temp?
    * Basically, the current RA doesn't know rematerialization and is still
    * learning spills, if we vectorize temp stores it might create long-lived
    * COLLECTs that make the RA fall off the bicycle and create very scary spills.
    * (spills that are just other temp STORE/LOADs).
    *
    * Really hope that a Metroid boss hears my prayer and saves the day soon!
    * test case: dEQP-VK.subgroups.ballot_broadcast.compute.subgroupbroadcast_u8vec3
    * TODO: Fix RA and re-enable temp vectorization.
    */
   nir_load_store_vectorize_options vectorize_opts = {
      .modes = nir_var_mem_global |
               nir_var_mem_shared |
               nir_var_mem_ubo /* | nir_var_mem_temp */,
      .callback = mem_vectorize_cb,
      .cb_data = (void *)&gpu_id,
      .robust_modes = inputs->robust_modes,
   };

   /* Only allow vectorization of SSBOs when no robustness2 is configured */
   if (!(inputs->robust_modes & nir_var_mem_ssbo))
      vectorize_opts.modes |= nir_var_mem_ssbo;

   NIR_PASS(_, nir, nir_opt_load_store_vectorize, &vectorize_opts);

   /* Our OpenCL compiler (src/panfrost/clc/pan_compile.c) has a very weird and
    * suboptimal optimization pipeline that results in a lot of unoptimized
    * memcpys and sparse scratch space.  That code is still being used for
    * panlib, so we try to re-optimize it here.
    * TODO: If you want to remove this pass, first optimize clc libpan on v9
    *       until it doesn't emit kilobytes of scratch access.
    */
   NIR_PASS(_, nir, nir_lower_scratch_to_var);

   if (nir_shader_has_local_variables(nir)) {
      /* Lower indirect access on small arrays to if/else trees.  After
       * vars_to_ssa and copy propagation, these will often end up as just a
       * handful of MUX instructions instead of memory access.  The threshold
       * of 8 array elements is chosen fairly arbitrarily.
       */
      NIR_PASS(_, nir, nir_lower_indirect_derefs_to_if_else_trees,
               nir_var_function_temp, 8);

      /* Turn the deref loads/stores we just made direct into SSA values */
      NIR_PASS(_, nir, nir_opt_constant_folding);
      NIR_PASS(_, nir, nir_lower_vars_to_ssa);
      NIR_PASS(_, nir, nir_opt_dce);

      /* Get rid of any dead function_temp variables so they don't get
       * assigned scratch space by vars_to_explicit_types().
       */
      NIR_PASS(_, nir, nir_remove_dead_variables, nir_var_function_temp, NULL);

      /* This can create illegal memory accesses for TLS (Ex: struct with
       * four uint32_t + memcpy).  Let nir_lower_mem_access_bit_sizes split it.
       * bandwith is more important than instruction count.
       */
      NIR_PASS(_, nir, nir_lower_vars_to_explicit_types, nir_var_function_temp,
               glsl_get_natural_size_align_bytes);

      nir_address_format scratch_addr_format =
         nir_get_ptr_bitsize(nir) == 64 ? nir_address_format_32bit_offset_as_64bit
                                        : nir_address_format_32bit_offset;

      NIR_PASS(_, nir, nir_lower_explicit_io, nir_var_function_temp,
               scratch_addr_format);
   }

   nir_lower_mem_access_bit_sizes_options mem_size_options = {
      .modes = nir_var_mem_ubo | nir_var_mem_push_const | nir_var_mem_ssbo |
               nir_var_mem_constant | nir_var_mem_task_payload |
               nir_var_shader_temp | nir_var_function_temp |
               nir_var_mem_global | nir_var_mem_shared,
      .callback = mem_access_size_align_cb,
      .cb_data = (void *) &gpu_id,
   };
   NIR_PASS(_, nir, nir_lower_mem_access_bit_sizes, &mem_size_options);

   /* The divergent scratch lowering must come after mem access bit lowering */
   nir_divergence_analysis(nir);
   NIR_PASS(_, nir, pan_nir_lower_divergent_scratch, gpu_arch);

   if (bi_use_kraid(nir, gpu_id))
      NIR_PASS(_, nir, pan_nir_lower_mem_to_global);

   nir_lower_ssbo_options ssbo_opts = {
      .native_loads = gpu_arch >= 9,
      .native_offset = gpu_arch >= 9,
   };
   NIR_PASS(_, nir, nir_lower_ssbo, &ssbo_opts);

   /*
    * Lower subgroups ops before lowering int64: nir_lower_int64 doesn't know
    * how to lower imul reductions and scans.
    *
    * TODO: we can implement certain operations (notably reductions, scans,
    * certain shuffles, etc) more efficiently than nir_lower_subgroups. Moreover
    * we can implement reductions and scans on f16vec2 values without splitting
    * to scalar first.
    */
   const nir_lower_subgroups_options lower_subgroup_opts = {
      .subgroup_size = pan_subgroup_size(gpu_arch),
      .ballot_bit_size = 32,
      .ballot_components = 1,
      .lower_to_scalar = true,
      .lower_vote_feq = true,
      .lower_vote_ieq = true,
      .lower_vote_bool_eq = true,
      .lower_first_invocation_to_ballot = true,
      .lower_read_first_invocation = true,
      .lower_subgroup_masks = true,
      .lower_relative_shuffle = true,
      .lower_shuffle = true,
      .lower_quad = true,
      .lower_quad_broadcast_dynamic = true,
      .lower_quad_vote = true,
      .lower_elect = true,
      .lower_rotate_to_shuffle = true,
      .lower_rotate_clustered_to_shuffle = true,
      .lower_inverse_ballot = true,
      .lower_reduce = true,
      .lower_boolean_reduce = true,
      .lower_boolean_shuffle = true,
   };
   bool lower_subgroups_progress = false;
   NIR_PASS(lower_subgroups_progress, nir, nir_lower_subgroups,
            &lower_subgroup_opts);
   /* lower_subgroups creates vars, clean them up before lower_64bit_phis */
   if (lower_subgroups_progress)
      NIR_PASS(_, nir, nir_lower_vars_to_ssa);

   NIR_PASS(_, nir, nir_shader_intrinsics_pass, bi_lower_subgroups,
            nir_metadata_control_flow, (void *) &gpu_id);

   /* Lower constant idiv before we lower 64-bit integers */
   NIR_PASS(_, nir, nir_opt_idiv_const, 8);

   /* Lower 64-bit integers */
   NIR_PASS(_, nir, nir_lower_64bit_phis);
   NIR_PASS(_, nir, nir_lower_int64);

   const nir_lower_idiv_options lower_idiv_opts = {
      .allow_fp16 = true,
   };
   NIR_PASS(_, nir, nir_lower_idiv, &lower_idiv_opts);

   NIR_PASS(_, nir, nir_lower_flrp, 16 | 32 | 64, false /* always_precise */);
   NIR_PASS(_, nir, nir_lower_alu); /* Lower [iu]mul_high */

   /* Lower bit sizes and vector widths */
   NIR_PASS(_, nir, nir_lower_bit_size, bi_lower_bit_size,
            &(struct lower_bit_size_opts) {
               .use_kraid = bi_use_kraid(nir, gpu_id),
               .gpu_id = gpu_id,
            });
   NIR_PASS(_, nir, nir_lower_alu_width, bi_vectorize_filter, &gpu_id);
   NIR_PASS(_, nir, nir_lower_load_const_to_scalar);
   NIR_PASS(_, nir, nir_lower_phis_to_scalar, bi_vectorize_filter, &gpu_id);

   bi_optimize_loop(nir, gpu_id, false /* allow_copies */);
}

static bool
lower_buf_image_access(nir_builder *b, nir_intrinsic_instr *intr, void *data)
{
   switch (intr->intrinsic) {
   case nir_intrinsic_image_texel_address:
   case nir_intrinsic_image_load:
   case nir_intrinsic_image_store:
      break;
   default:
      return false;
   }
   enum glsl_sampler_dim dim = nir_intrinsic_image_dim(intr);
   if (dim != GLSL_SAMPLER_DIM_BUF)
      return false;

   unsigned *arch = data;
   b->cursor = nir_before_instr(&intr->instr);

   nir_def *res_handle = intr->src[0].ssa;
   nir_def *buf_index = nir_channel(b, intr->src[1].ssa, 0);
   nir_def *texel_addr, *icd;
   if (*arch >= 9) {
      texel_addr = nir_lea_buf_pan(b, res_handle, buf_index);
      icd = pan_nir_load_va_buf_cvt(b, res_handle);
   } else {
      nir_def *attr = nir_lea_attr_pan(b, res_handle, buf_index,
                                       nir_imm_int(b, 0),
                                       .src_type = 32,
                                       .desc_set = BI_TABLE_ATTRIBUTE_1);
      texel_addr = nir_channels(b, attr, BITFIELD_MASK(2));
      icd = nir_channel(b, attr, 2);
   }
   texel_addr = nir_pack_64_2x32(b, texel_addr);

   switch (intr->intrinsic) {
   case nir_intrinsic_image_texel_address:
      nir_def_replace(&intr->def, texel_addr);
      break;
   case nir_intrinsic_image_load: {
      nir_def *loaded_mem = nir_load_global_cvt_pan(
         b, intr->def.num_components, intr->def.bit_size, texel_addr, icd,
         .dest_type = nir_intrinsic_dest_type(intr));
      nir_def_replace(&intr->def, loaded_mem);
      break;
   }
   case nir_intrinsic_image_store: {
      /* Due to SPIR-V limitations, the source type is not fully reliable: it
       * reports uint32 even for write_imagei. This causes an incorrect
       * u32->s32->u32 roundtrip which incurs an unwanted clamping. Use auto32
       * instead, which will match per the OpenCL spec. Of course this does
       * not work for 16-bit stores, but those are not available in OpenCL.
       */
      ASSERTED nir_alu_type T = nir_intrinsic_src_type(intr);
      assert(nir_alu_type_get_type_size(T) == 32);

      nir_def *value = intr->src[3].ssa;
      nir_store_global_cvt_pan(b, value, texel_addr, icd, .src_type = 32);
      nir_instr_remove(&intr->instr);
      break;
   }
   default:
      UNREACHABLE("Unexpected intrinsic");
   }

   return true;
}

static bool
pan_nir_lower_buf_image_access(nir_shader *shader, unsigned arch)
{
   return nir_shader_intrinsics_pass(shader, lower_buf_image_access,
                                     nir_metadata_control_flow, &arch);
}

/* Decide if Index-Driven Vertex Shading should be used for a given shader */
static bool
bi_should_idvs(nir_shader *nir, const struct pan_compile_inputs *inputs)
{
   /* Opt-out */
   if (inputs->no_idvs || bifrost_debug & BIFROST_DBG_NOIDVS)
      return false;

   /* IDVS splits up vertex shaders, not defined on other shader stages */
   if (nir->info.stage != MESA_SHADER_VERTEX)
      return false;

   /* Bifrost cannot write gl_PointSize during IDVS */
   if ((pan_arch(inputs->gpu_id) < 9) &&
       nir->info.outputs_written & VARYING_BIT_PSIZ)
      return false;

   /* Otherwise, IDVS is usually better */
   return true;
}

/* Atomics and memory write on the vertex stage have implementation-defined
 * behaviors on how many invocations will happen. However for some reasons,
 * atomic counters on GL/GLES specs are quite ambigous here and even have tests
 * counting how many invocations have been made on VS.... This pass detects
 * atomics that result in a direct store output of one specific IDVS stage
 * and ensure it's only executed for said stage.
 *
 * This allows
 * "dEQP-GLES31.functional.shaders.opaque_type_indexing.atomic_counter.*" to
 * pass under ANGLE.
 * TODO: We should fix the tests and fix ANGLE too since VS atomics are not yet
 *       enabled for panvk (even though they should be).  This pass is only here
 *       to pass a couple tests and breaks if any operation is inserted between
 *       the atomic operation and the varying store.
 */

static bool
bifrost_nir_lower_vs_atomics_impl(nir_builder *b, nir_intrinsic_instr *intr,
                                  UNUSED void *data)
{
   if (intr->intrinsic != nir_intrinsic_global_atomic &&
       intr->intrinsic != nir_intrinsic_ssbo_atomic)
      return false;

   unsigned output_mask = 0;
   nir_foreach_use(use, &intr->def) {
      nir_instr *parent = nir_src_use_instr(use);
      if (parent->type != nir_instr_type_intrinsic)
         continue;

      nir_intrinsic_instr *parent_intr = nir_instr_as_intrinsic(parent);
      if (parent_intr->intrinsic != nir_intrinsic_store_output &&
          parent_intr->intrinsic != nir_intrinsic_store_per_view_output)
         continue;

      nir_io_semantics sem = nir_intrinsic_io_semantics(parent_intr);
      output_mask |= BITFIELD_BIT(va_shader_output_from_loc(sem.location));
   }

   /* In case they are not written to any outputs, we default to only output in
    * the position stage */
   if (output_mask == 0)
      output_mask |= VA_SHADER_OUTPUT_POSITION_BIT;

   /* In case they are not written to both IDVS stages, we just do not try
    * lowering it */
   if (((output_mask & VA_SHADER_OUTPUT_VARY_BIT) &&
        (output_mask & (VA_SHADER_OUTPUT_POSITION_BIT |
                        VA_SHADER_OUTPUT_ATTRIB_BIT))))
      return false;

   /* In case we know we have only outputs to a certain type, we can make the
    * atomic exclusive to this */
   b->cursor = nir_before_instr(&intr->instr);
   nir_def *res = nir_undef(b, intr->def.num_components, intr->def.bit_size);

   nir_def *shader_output = nir_load_shader_output_pan(b);
   nir_push_if(b, nir_i2b(b, nir_iand_imm(b, shader_output, output_mask)));
   nir_instr *new_instr = nir_instr_clone(b->shader, &intr->instr);
   nir_intrinsic_instr *new_intr = nir_instr_as_intrinsic(new_instr);
   nir_builder_instr_insert(b, new_instr);
   nir_pop_if(b, NULL);

   res = nir_if_phi(b, &new_intr->def, res);
   nir_def_replace(&intr->def, res);

   return true;
}

static bool
bifrost_nir_lower_vs_atomics(nir_shader *shader)
{
   assert(shader->info.stage == MESA_SHADER_VERTEX);
   return nir_shader_intrinsics_pass(shader, bifrost_nir_lower_vs_atomics_impl,
                                     nir_metadata_none, NULL);
}

/* This creates the inital rough shape of a unified IDVS shader:
 *
 * %0 = @load_shader_output_pan
 * if %0 & VA_SHADER_OUTPUT_POSITON_BIT {
 *    <substituted copy of input impl>
 * }
 * if %0 & VA_SHADER_OUTPUT_ATTRIB_BIT {
 *    <substituted copy of input impl>
 * }
 * if %0 & VA_SHADER_OUTPUT_VARY_BIT {
 *    <substituted copy of input impl>
 * }
 *
 * It needs to be followed by other passes for cleaning up.
 */
static bool
bifrost_make_unified_idvs_shader(nir_shader *nir)
{
   nir_function_impl *impl = nir_shader_get_entrypoint(nir);

   nir_cf_list old_blocks;
   nir_cf_extract(&old_blocks, nir_before_impl(impl), nir_after_impl(impl));

   /* Make a new main block. */
   nir_cf_node_insert_begin(&impl->body, &nir_block_create(impl)->cf_node);

   nir_builder builder = nir_builder_create(impl);
   nir_builder *b = &builder;
   b->cursor = nir_before_impl(impl);
   nir_def *shader_output = nir_load_shader_output_pan(b);

   nir_block *out_blocks[VA_SHADER_OUTPUT_COUNT] = {NULL};

   for (enum va_shader_output out = 0; out < VA_SHADER_OUTPUT_COUNT; ++out) {
      nir_def *cond =
         nir_i2b(b, nir_iand_imm(b, shader_output, BITFIELD_BIT(out)));
      nir_if *nif = nir_push_if(b, cond);
      nir_cf_list_clone_and_reinsert(&old_blocks, &nif->cf_node, b->cursor,
                                     NULL);
      nir_pop_if(b, NULL);

      out_blocks[out] = nir_if_first_then_block(nif);
   }

   /* After messing around with the CFG, reindex blocks. */
   nir_index_blocks(impl);

   /* This is more or less what nir_inline_sysval does, except that it uses a
    * different constant depending on which of the out_blocks the intrinsic
    * instruction is in.
    */
   for (enum va_shader_output out = 0; out < VA_SHADER_OUTPUT_COUNT; ++out) {
      nir_block *out_block = out_blocks[out];
      assert(out_block);

      nir_foreach_block_in_cf_node_safe(block, &out_block->cf_node) {
         nir_foreach_instr_safe(instr, block) {
            if (instr->type != nir_instr_type_intrinsic)
               continue;

            nir_intrinsic_instr *intr = nir_instr_as_intrinsic(instr);
            if (intr->intrinsic != nir_intrinsic_load_shader_output_pan)
               continue;

            b->cursor = nir_before_instr(&intr->instr);
            nir_def_replace(&intr->def, nir_imm_intN_t(b, BITFIELD_BIT(out),
                                                       intr->def.bit_size));
         }
      }
   }

   nir_progress(true, impl, nir_metadata_none);

   return true;
}

static void
bifrost_handle_unified_idvs_shader(nir_shader *nir)
{
   NIR_PASS(_, nir, bifrost_make_unified_idvs_shader);

   /* Clean up from specializing inside the previous pass. */
   bool progress = true;
   while (progress) {
      progress = false;
      NIR_PASS(progress, nir, nir_opt_constant_folding);
      NIR_PASS(progress, nir, nir_opt_dce);
      NIR_PASS(progress, nir, nir_opt_dead_cf);
      NIR_PASS(progress, nir, nir_opt_cse);
   }

   /* Hoist common values before the predicated blocks. */
   NIR_PASS(_, nir, nir_opt_gcm, true);
}

static const char *
idvs_variant_suffix(enum bi_idvs_mode idvs)
{
   switch (idvs) {
   case BI_IDVS_VARYING:
      return "_var";
   case BI_IDVS_POSITION:
      return "_pos";
   case BI_IDVS_ALL:
      return "_all";
   case BI_IDVS_NONE:
      return "";
   default:
      return "invalid";
   }
}

static void
bifrost_dump_shader(nir_shader *nir, struct util_dynarray *binary,
                    enum bi_idvs_mode idvs, uint32_t offset, uint32_t size)
{
   const char *dump_dir = os_get_option_secure("BIFROST_MESA_DUMP_DIR");
   if (dump_dir == NULL)
      return;

   bool has_src_blake3 = false;
   for (uint32_t i = 0; i < BLAKE3_OUT_LEN && !has_src_blake3; ++i)
      has_src_blake3 |= nir->info.source_blake3[i] != 0;

   /* Only shaders with a unique source identifier can be dumped. */
   if (!has_src_blake3) {
      fprintf(
         stderr,
         "Warning: Skip dump of shader %s (stage=%s) without source hash\n",
         nir->info.name ?: "<unnamed>",
         _mesa_shader_stage_to_abbrev(nir->info.stage));
      return;
   }

   const char *id = NULL;
   char blake3_str[BLAKE3_HEX_LEN] = {0};
   _mesa_blake3_format(blake3_str, nir->info.source_blake3);
   id = &blake3_str[0];

   char path[PATH_MAX + 1] = {0};
   snprintf(path, sizeof(path), "%s/%s.%s%s.bin", dump_dir, id,
            _mesa_shader_stage_to_file_ext(nir->info.stage),
            idvs_variant_suffix(idvs));

   FILE *dump_stream = fopen(path, "w");

   unsigned written = 0;
   if (dump_stream) {
      char* ptr = ((char*)binary->data) + offset;
      written = fwrite(ptr, sizeof(char), size, dump_stream);
   }

   if (written == size) {
      fprintf(stderr, "PAN: Dumped shader %s to %s\n",
              nir->info.name ?: "<unnamed>", path);
   } else {
      fprintf(stderr, "PAN: Failed to dump %s to %s\n",
              nir->info.name ?: "<unnamed>", path);
   }

   if (dump_stream)
      fclose(dump_stream);
}

void
bifrost_compile_shader_nir(nir_shader *nir,
                           const struct pan_compile_inputs *inputs,
                           struct util_dynarray *binary,
                           struct pan_shader_info *info)
{
   MESA_TRACE_FUNC();

   bifrost_init_debug_options();

   /* Apply special transformation to IDVS_ALL shaders before late
    * optimization loop. */
   if (nir->info.stage == MESA_SHADER_VERTEX && info->vs.idvs &&
       (pan_arch(inputs->gpu_id) >= 12)) {
      bifrost_handle_unified_idvs_shader(nir);
   }

   bi_optimize_late(nir, inputs->gpu_id, info);

   /* Lower constants to scalar but then immediately fold so we get minimum-
    * width vectors instead of scalars
    */
   NIR_PASS(_, nir, nir_lower_load_const_to_scalar);
   NIR_PASS(_, nir, nir_opt_constant_folding);
   uint64_t gpu_id = inputs->gpu_id;
   NIR_PASS(_, nir, nir_lower_phis_to_scalar, bi_vectorize_filter, &gpu_id);
   NIR_PASS(_, nir, nir_opt_copy_prop);
   NIR_PASS(_, nir, nir_opt_dce);

   info->tls_size = nir->scratch_size;
   info->stage = nir->info.stage;
   info->fau.max = PAN_MAX_PUSH;
   info->fau.reserved = inputs->fau.reserved;
   info->fau.count = inputs->fau.reserved;

   if (bi_use_kraid(nir, gpu_id)) {
      if (inputs->fau.pushable_ubos) {
         /* We can't push if there's a driver-reserved range */
         assert(inputs->fau.reserved == 0);
         NIR_PASS(_, nir, pan_nir_opt_push_ubo, inputs->fau.pushable_ubos,
                  &info->fau, &info->ubo_mask);
      }
#ifdef WITH_PANFROST_RUST
      kraid_compile_nir(nir, inputs, binary, info);
#endif
   } else if (nir->info.stage == MESA_SHADER_VERTEX && info->vs.idvs) {
      /* On 5th Gen, IDVS is only in one binary */
      if (pan_arch(inputs->gpu_id) >= 12)
         bi_compile_variant(nir, inputs, binary, info, BI_IDVS_ALL);
      else {
         bi_compile_variant(nir, inputs, binary, info, BI_IDVS_POSITION);
         bi_compile_variant(nir, inputs, binary, info, BI_IDVS_VARYING);
      }
   } else {
      bi_compile_variant(nir, inputs, binary, info, BI_IDVS_NONE);
   }

   /* Based on the provided info, dump the binary/-ies. */
   if (info->stage == MESA_SHADER_VERTEX && info->vs.idvs) {
      enum bi_idvs_mode mode =
         pan_arch(inputs->gpu_id) >= 12 ? BI_IDVS_ALL : BI_IDVS_POSITION;
      uint32_t size_prim = info->vs.secondary_offset ?: binary->size;
      bifrost_dump_shader(nir, binary, mode, 0, size_prim);
      if (info->vs.secondary_enable && mode != BI_IDVS_ALL) {
         uint32_t offs = info->vs.secondary_offset;
         uint32_t size_sec = binary->size - offs;
         bifrost_dump_shader(nir, binary, BI_IDVS_VARYING, offs, size_sec);
      }
   } else {
      bifrost_dump_shader(nir, binary, BI_IDVS_NONE, 0, binary->size);
   }

   info->ubo_mask &= (1 << nir->info.num_ubos) - 1;
}
