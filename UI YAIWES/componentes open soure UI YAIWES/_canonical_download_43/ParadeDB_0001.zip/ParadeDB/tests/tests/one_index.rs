// Copyright (c) 2023-2026 ParadeDB, Inc.
//
// This file is part of ParadeDB - Postgres for Search and Analytics
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

use rstest::*;
use sqlx::PgConnection;
use tests::fixtures::*;

#[rstest]
fn only_one_index_allowed(mut conn: PgConnection) {
    r#"
    CALL paradedb.create_paradedb_test_table(
      schema_name => 'public',
      table_name => 'mock_items'
    )
    "#
    .execute(&mut conn);

    r#"
    CREATE INDEX index_one ON public.mock_items
    USING paradedb (id, description)
    WITH (key_field = 'id');
    "#
    .execute(&mut conn);

    let result = r#"
    CREATE INDEX index_two ON public.mock_items
    USING paradedb (id, description)
    WITH (key_field = 'id');
    "#
    .execute_result(&mut conn);

    match result {
        Ok(_) => panic!("created a second index"),
        Err(e) => {
            let msg = format!("{e}");
            assert!(
                msg.contains("a relation may only have one ParadeDB index"),
                "{msg}"
            );
        }
    }
}
