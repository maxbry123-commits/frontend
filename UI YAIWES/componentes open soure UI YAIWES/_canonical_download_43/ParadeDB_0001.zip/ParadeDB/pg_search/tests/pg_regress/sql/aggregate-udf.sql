CREATE EXTENSION IF NOT EXISTS pg_search;
DROP TABLE IF EXISTS pr2625;
CREATE TABLE pr2625 (
    id serial8,
    k text,
    v float8
);
CREATE INDEX idxpr2625 ON pr2625 USING paradedb (id, k, v) WITH (key_field = 'id', target_segment_count = 8, layer_sizes = '1gb, 10gb');

--
-- test with 1 segment
--
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;

SET parallel_leader_participation = true;
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'transaction');
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'raw');
SET parallel_leader_participation = false;
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'transaction');


--
-- test with multiple segments
--
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;
INSERT INTO pr2625(k, v) SELECT paradedb.random_words(1), x::float8 from generate_series(1, 1000) x;

SET parallel_leader_participation = true;
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'transaction');
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'raw');
SET parallel_leader_participation = false;
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'transaction');


--
-- this one will execute serially in the current backend
--
SET parallel_leader_participation = false;
SET max_parallel_workers = 0;
SELECT * FROM paradedb.aggregate(index=>'idxpr2625', query=>paradedb.all(), agg=>'{"average": { "avg": { "field": "v" }}}', visibility=>'transaction');

RESET parallel_leader_participation;
RESET max_parallel_workers;
