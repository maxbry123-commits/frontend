CREATE EXTENSION IF NOT EXISTS pg_search;

SET paradedb.enable_aggregate_custom_scan TO on;

DROP TABLE IF EXISTS tbl_inet;
CREATE TABLE tbl_inet (ip inet);
CREATE INDEX idx_inet ON tbl_inet USING paradedb (ip) WITH (key_field = 'ip');
INSERT INTO tbl_inet (ip) VALUES ('192.168.0.1');
SELECT count(*) FROM tbl_inet WHERE ip @@@ '192.168.0.1';
EXPLAIN (FORMAT TEXT, COSTS OFF, TIMING OFF, VERBOSE)
SELECT count(*) FROM tbl_inet WHERE ip @@@ '192.168.0.1';

RESET paradedb.enable_aggregate_custom_scan;
