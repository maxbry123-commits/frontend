import type { SponsorTier } from '@voidzero-dev/vitepress-theme/src/types/sponsors'

export const sponsors: SponsorTier[] = [
  {
    tier: 'Special',
    size: 'big',
    items: [
      {
        name: 'Vercel',
        url: 'https://vercel.com',
        img: '/vercel.svg',
      },
      {
        name: 'Chromatic',
        url: 'https://www.chromatic.com/?utm_source=vitest&utm_medium=sponsorship&utm_campaign=vitestSponsorship',
        img: '/chromatic.svg',
      },
      {
        name: 'Zammad',
        url: 'https://zammad.com',
        img: '/zammad.svg',
      },
    ],
  },
  {
    tier: 'Platinum Sponsors',
    size: 'big',
    items: [
      {
        name: 'Bolt',
        url: 'https://bolt.new',
        img: '/bolt.svg',
      },
      {
        name: 'Latitude',
        url: 'https://latitude.so/',
        img: '/latitude.svg',
      },
    ],
  },
  {
    tier: 'Gold',
    size: 'medium',
    items: [
      {
        name: 'vital',
        url: 'https://vital.io/',
        img: '/vital.svg',
      },
      {
        name: 'Mailmeteor',
        url: 'https://mailmeteor.com/',
        img: '/mailmeteor.svg',
      },
      {
        name: 'Liminity',
        url: 'https://www.liminity.se/',
        img: '/liminity.svg',
      },
      {
        name: 'Kraken Tech',
        url: 'https://kraken.tech/',
        img: '/kraken.svg',
      },
      {
        name: 'Aerius Ventilation',
        url: 'https://aerius.se/',
        img: '/aerius.png',
      },
      {
        name: 'TestMu AI',
        url: 'https://www.testmuai.com/?utm_medium=sponsor&utm_source=vitest-dev',
        img: '/testmuai.svg',
      },
    ],
  },
]
