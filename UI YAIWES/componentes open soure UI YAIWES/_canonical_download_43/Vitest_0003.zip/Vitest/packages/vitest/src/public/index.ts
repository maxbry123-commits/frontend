import type { SerializedConfig } from '../runtime/config'
import type { SerializedTestSpecification } from '../runtime/types/utils'
import type {
  ModuleDefinitionDiagnostic,
  ModuleDefinitionDurationsDiagnostic,
  ModuleDefinitionLocation,
  SourceModuleDiagnostic,
  SourceModuleLocations,
  UntrackedModuleDefinitionDiagnostic,
} from '../types/module-locations'
import '../types/global'

// eslint-disable-next-line ts/no-namespace
export declare namespace Experimental {
  export {
    ModuleDefinitionDiagnostic,
    ModuleDefinitionDurationsDiagnostic,
    ModuleDefinitionLocation,
    SourceModuleDiagnostic,
    SourceModuleLocations,
    UntrackedModuleDefinitionDiagnostic,
  }
}

export type {
  ExternalResult,
  TransformResultWithSource,
  WebSocketEvents,
  WebSocketHandlers,
  WebSocketRPC,
} from '../api/types'
export { assert, chai, createExpect, expect, should } from '../integrations/chai'
export { inject } from '../integrations/inject'
export { Snapshots } from '../integrations/snapshot/chai'

export { vi, vitest } from '../integrations/vi'
export type { VitestUtils } from '../integrations/vi'
export type {
  Bench,
  BenchCompareOptions,
  BenchFn,
  BenchFnOptions,
  BenchFromSource,
  BenchmarkGroup,
  BenchmarkProvider,
  BenchOptions,
  BenchRegistration,
  BenchRegistrationInput,
  BenchResult,
  BenchRunOptions,
  BenchStorage,
} from '../runtime/benchmark'

export type {
  RuntimeConfig,
  SerializedConfig,
  SerializedCoverageConfig,
  SerializedRootConfig,
} from '../runtime/config'

/** @deprecated use `SerializedConfig` instead */
export type TestRunnerConfig = SerializedConfig

export { VitestEvaluatedModules as EvaluatedModules } from '../runtime/moduleRunner/evaluatedModules'

export { recordArtifact } from '../runtime/runner/artifact'
export {
  afterAll,
  afterEach,
  aroundAll,
  aroundEach,
  beforeAll,
  beforeEach,
  onTestFailed,
  onTestFinished,
} from '../runtime/runner/hooks'
export {
  describe,
  it,
  suite,
  test,
} from '../runtime/runner/suite'
export type {
  BaselineData,
  BrowserTraceArtifact,
  FailureScreenshotArtifact,
  ImportDuration,
  OnTestFailedHandler,
  OnTestFinishedHandler,
  RunMode,
  Task as RunnerTask,
  TaskBase as RunnerTaskBase,
  TaskEventPack as RunnerTaskEventPack,
  TaskResult as RunnerTaskResult,
  TaskResultPack as RunnerTaskResultPack,
  Test as RunnerTestCase,
  File as RunnerTestFile,
  Suite as RunnerTestSuite,
  SuiteAPI,
  SuiteCollector,
  SuiteFactory,
  SuiteOptions,
  TaskCustomOptions,
  TaskMeta,
  TaskState,
  TestAnnotation,
  TestAnnotationArtifact,
  TestAnnotationLocation,
  TestAPI,
  TestArtifact,
  TestArtifactBase,
  TestArtifactLocation,
  TestArtifactRegistry,
  TestAttachment,
  TestBenchmark,
  TestBenchmarkTask,
  TestContext,
  TestFunction,
  TestOptions,
  TestTagDefinition,
  TestTags,
  TestTryOptions,

  VisualRegressionArtifact,
} from '../runtime/runner/types'

export type { CancelReason, VitestRunner as VitestTestRunner } from '../runtime/runner/types'
export { TestRunner } from '../runtime/runners/test'
export { assertType } from '../typecheck/assertType'

export type { AssertType } from '../typecheck/assertType'
export { expectTypeOf } from '../typecheck/expectTypeOf'

export type { ExpectTypeOf } from '../typecheck/expectTypeOf'

export type { BrowserTesterOptions } from '../types/browser'

export type {
  AfterSuiteRunMeta,
  LabelColor,
  ModuleGraphData,
  ParsedStack,
  ProvidedContext,
  TestError,
  UserConsoleLog,
} from '../types/general'
export type {
  RunnerRPC,
  RuntimeRPC,
} from '../types/rpc'
export type { BrowserUI } from '../types/ui'
export type {
  ContextRPC,
  ContextTestEnvironment,
  TestExecutionMethod,
  WorkerGlobalState,
} from '../types/worker'

export type {
  Assertion,
  AsymmetricMatchersContaining,
  AsyncExpectationResult as AsyncMatcherResult,
  DeeplyAllowMatchers,
  ExpectStatic,
  JestAssertion,
  RawMatcherFn as Matcher,
  ExpectationResult as MatcherResult,
  Matchers,
  MatchersObject,
  MatcherState,
  SyncExpectationResult as SyncMatcherResult,
} from '@vitest/expect'

export type {
  DomainMatchResult,
  DomainSnapshotAdapter,
  SnapshotData,
  SnapshotMatchOptions,
  SnapshotResult,
  SnapshotSerializer,
  SnapshotStateOptions,
  SnapshotSummary,
  SnapshotUpdateState,
  UncheckedSnapshot,
} from '@vitest/snapshot'

export type {
  Mock,
  MockContext,
  Mocked,
  MockedClass,
  MockedFunction,
  MockedObject,
  MockInstance,
  MockResult,
  MockResultIncomplete,
  MockResultReturn,
  MockResultThrow,
  MockSettledResult,
  MockSettledResultFulfilled,
  MockSettledResultIncomplete,
  MockSettledResultRejected,
} from '@vitest/spy'

export type { SerializedError } from '@vitest/utils'
export type { SerializedTestSpecification }
export type { DiffOptions } from '@vitest/utils/diff'
