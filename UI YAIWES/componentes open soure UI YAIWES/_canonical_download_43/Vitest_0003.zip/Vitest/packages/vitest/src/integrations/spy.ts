export * from '@vitest/spy'
