export {
  startCoverageInsideWorker,
  stopCoverageInsideWorker,
  takeCoverageInsideWorker,
} from '../integrations/coverage'
export { collectTests, startTests } from '../runtime/runner/run'
export type { FileSpecification } from '../runtime/runner/types'
export {
  loadDiffConfig,
  loadSnapshotSerializers,
  setupCommonEnv,
  setupEnv,
} from '../runtime/setup-common'
export * as SpyModule from '@vitest/spy'
export type { ParsedStack, StringifyOptions } from '@vitest/utils'
export {
  format,
  inspect,
  stringify,
} from '@vitest/utils/display'
export { processError } from '@vitest/utils/error'
export { getType } from '@vitest/utils/helpers'
export {
  DecodedMap,
  getOriginalPosition,
} from '@vitest/utils/source-map'
export { getSafeTimers, setSafeTimers } from '@vitest/utils/timers'

export interface FsOptions {
  encoding?: BufferEncoding
  flag?: string | number
}

export interface BrowserCommands {
  readFile: (
    path: string,
    options?: BufferEncoding | FsOptions,
  ) => Promise<string>
  writeFile: (
    path: string,
    content: string,
    options?: BufferEncoding | (FsOptions & { mode?: number | string }),
  ) => Promise<void>
  removeFile: (path: string) => Promise<void>
}

export interface CDPSession {
  // methods are defined by the provider type augmentation
}

export type BrowserTraceEntryKind = 'action' | 'expect' | 'mark' | 'lifecycle'

export interface MarkOptions {
  /**
   * Optional stack string used to resolve marker location.
   * Useful for wrapper libraries that need to forward the end-user callsite.
   */
  stack?: string

  /**
   * Optional marker kind that's used to categorize the marker in the trace viewer.
   * @default 'mark'
   */
  kind?: BrowserTraceEntryKind
}

/**
 * @internal
 */
export const __INTERNAL: {
  _asLocator: (lang: 'javascript', selector: string) => string
  _createLocator: (selector: string) => any
  _extendedMethods: Set<string>
} = {
  _extendedMethods: new Set(),
} as any
