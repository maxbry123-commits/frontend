import antfu, { GLOB_SRC } from '@antfu/eslint-config'

export default antfu(
  {
    vue: true,
    // Disable tests rules because we need to test with various setup
    test: false,
    // This replaces the old `.gitignore`
    ignores: [
      '**/coverage',
      '**/*.snap',
      '**/bench.json',
      '**/fixtures',
      '**/assets/**',
      '**/*.d.ts',
      '**/*.timestamp-*',
      '**/test-results',
      'test/unit/src/self',
      'test/unit/test/mocking/already-hoisted.test.ts',
      'test/cache/cache/.vitest-base/results.json',
      'test/unit/src/wasm/wasm-bindgen-no-cyclic',
      'test/workspaces/results.json',
      'test/workspaces-browser/results.json',
      'test/reporters/fixtures/with-syntax-error.test.js',
      'test/network-imports/public/slash@3.0.0.js',
      'test/coverage-test/src/transpiled.js',
      'test/coverage-test/src/original.ts',
      'test/e2e/deps/error/*',
      'test/e2e/deps/malformed-source-map/*.js',
      'examples/**/mockServiceWorker.js',
      'examples/sveltekit/.svelte-kit',
      'packages/browser/**/esm-client-injector.js',
      // contains technically invalid code to display pretty diff
      'docs/guide/snapshot.md',
      // uses invalid js example
      'docs/api/advanced/import-example.md',
      'docs/guide/examples/*.md',
    ],
  },
  {
    rules: {
      // prefer global Buffer to not initialize the whole module
      'node/prefer-global/buffer': 'off',
      'node/prefer-global/process': 'off',
      'no-empty-pattern': 'off',
      'antfu/indent-binary-ops': 'off',
      'unused-imports/no-unused-imports': 'error',
      'pnpm/json-enforce-catalog': 'off',
      'style/member-delimiter-style': [
        'error',
        {
          multiline: { delimiter: 'none' },
          singleline: { delimiter: 'semi' },
        },
      ],
      // let TypeScript handle this
      'no-undef': 'off',
      'ts/no-invalid-this': 'off',
      'eslint-comments/no-unlimited-disable': 'off',
      'curly': ['error', 'all'],

      // TODO: migrate and turn it back on
      'ts/ban-types': 'off',
      'ts/no-unsafe-function-type': 'off',

      'markdown/fenced-code-language': 'off',

      'no-restricted-imports': [
        'error',
        {
          paths: ['path'],
        },
      ],

      'import/no-named-as-default': 'off',
      // Has dangerous false positives
      'e18e/prefer-array-fill': 'off',
      // Doesn't actually matter, JS engines cache them
      // Also has dangerous false positives (reports /g/)
      'e18e/prefer-static-regex': 'off',
    },
  },
  {
    files: [`packages/*/*.{js,mjs,d.ts}`],
    rules: {
      'antfu/no-import-dist': 'off',
    },
  },
  {
    files: [`packages/${GLOB_SRC}`],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: ['vitest', 'path', 'vitest/node'],
        },
      ],
    },
  },
  {
    // these files define vitest as peer dependency
    files: [`packages/{coverage-*,ui,browser,web-worker,browser-*}/${GLOB_SRC}`],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: ['path'],
        },
      ],
    },
  },
  {
    files: [
      `docs/${GLOB_SRC}`,
      `**/*.md`,
      `**/*.md/${GLOB_SRC}`,
    ],
    rules: {
      // it uses parser which is not compatible with vitepress
      'markdown/no-missing-link-fragments': 'off',
      'prefer-arrow-callback': 'off',
      'perfectionist/sort-imports': 'off',
      'style/max-statements-per-line': 'off',
      'import/newline-after-import': 'off',
      'import/first': 'off',
      'unused-imports/no-unused-imports': 'off',
      'ts/method-signature-style': 'off',
      'no-self-compare': 'off',
      'import/no-mutable-exports': 'off',
      'no-throw-literal': 'off',
      'import/no-duplicates': 'off',
    },
  },
  {
    files: [
      `docs/${GLOB_SRC}`,
      `packages/web-worker/${GLOB_SRC}`,
      `test/unit/${GLOB_SRC}`,
    ],
    rules: {
      'no-restricted-globals': 'off',
    },
  },
  {
    files: [
      `test/${GLOB_SRC}`,
    ],
    rules: {
      'antfu/no-top-level-await': 'off',
      'unicorn/consistent-function-scoping': 'off',
    },
  },
  {
    files: [`packages/browser/src/client/orchestrator.ts`],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: ['vitest/internal/browser', 'vitest/node'],
        },
      ],
    },
  },
  // ivya should be loaded only once in "ivya chunk" (see browser rollup config)
  {
    files: [`packages/browser/${GLOB_SRC}`],
    ignores: [
      // aria snapshots
      `packages/browser/src/vendor-types.ts`,
      `packages/browser/src/client/tester/aria.ts`,
      // primary use case - creates the engine
      `packages/browser/src/client/tester/locators.ts`,
      // uses utils from ivya to reuse locator syntax
      `packages/browser/src/client/tester/expect/${GLOB_SRC}`,
      // used as a type
      `packages/browser/src/client/utils.ts`,
    ],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: ['ivya', 'ivya/utils', 'ivya/aria'],
        },
      ],
    },
  },
)
