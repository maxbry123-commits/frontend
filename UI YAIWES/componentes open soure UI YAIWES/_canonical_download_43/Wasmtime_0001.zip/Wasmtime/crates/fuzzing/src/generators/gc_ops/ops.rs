//! Operations for the `gc` operations.

use crate::generators::gc_ops::types::StackType;
use crate::generators::gc_ops::{
    limits::GcOpsLimits,
    types::{CompositeType, RecGroupId, StructField, TypeId, Types},
};
use mutatis::Generate;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use wasm_encoder::{
    CodeSection, ConstExpr, EntityType, ExportKind, ExportSection, Function, FunctionSection,
    GlobalSection, ImportSection, Instruction, Module, RefType, TableSection, TableType,
    TypeSection, ValType,
};

/// Pick a same-kind concrete type index for `raw`, or `None` when there are no
/// types of that kind (so the caller drops the op).
fn pick_type_index(indices: &[u32], raw: u32) -> Option<u32> {
    if indices.is_empty() {
        None
    } else {
        Some(indices[usize::try_from(raw).unwrap() % indices.len()])
    }
}

/// Returns the element field if the indexed type is an array
fn array_element<'a>(
    types: &'a Types,
    encoding_order: &[TypeId],
    type_index: u32,
) -> Option<&'a StructField> {
    encoding_order
        .get(usize::try_from(type_index).unwrap())
        .and_then(|tid| types.type_defs.get(tid))
        .and_then(|def| match &def.composite_type {
            CompositeType::Array(at) => Some(&at.element),
            CompositeType::Struct(_) => None,
        })
}

/// The base offsets and indices for various Wasm entities within
/// their index spaces in the the encoded Wasm binary.
#[derive(Clone, Copy)]
struct WasmEncodingBases {
    struct_type_base: u32,
    typed_first_func_index: u32,
    struct_local_idx: u32,
    eq_local_idx: u32,
    i31_local_idx: u32,
    array_local_idx: u32,
    typed_local_base: u32,
    typed_local2_base: u32,
    struct_global_idx: u32,
    eq_global_idx: u32,
    i31_global_idx: u32,
    array_global_idx: u32,
    typed_global_base: u32,
    struct_table_idx: u32,
    eq_table_idx: u32,
    i31_table_idx: u32,
    array_table_idx: u32,
    typed_table_base: u32,
    array_length: u32,
}

/// A description of a Wasm module that makes a series of `externref` table
/// operations.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct GcOps {
    pub(crate) limits: GcOpsLimits,
    pub(crate) ops: Vec<GcOp>,
    pub(crate) types: Types,
}

impl GcOps {
    /// Serialize this module into a Wasm binary.
    ///
    /// The module requires several function imports. See this function's
    /// implementation for their exact types.
    ///
    /// The single export of the module is a function "run" that takes
    /// `self.num_params` parameters of type `externref`.
    ///
    /// The "run" function does not terminate; you should run it with limited
    /// fuel. It also is not guaranteed to avoid traps: it may access
    /// out-of-bounds of the table.
    pub fn to_wasm_binary(&mut self) -> Vec<u8> {
        let mut encoding_order_grouped = Vec::with_capacity(self.types.rec_groups.len());
        self.fixup(&mut encoding_order_grouped);

        let mut module = Module::new();

        // Encode the types for all functions that we are using.
        let mut types = TypeSection::new();

        // 0: "gc"
        types.ty().function(
            vec![],
            // Return a bunch of stuff from `gc` so that we exercise GCing when
            // there is return pointer space allocated on the stack. This is
            // especially important because the x64 backend currently
            // dynamically adjusts the stack pointer for each call that uses
            // return pointers rather than statically allocating space in the
            // stack frame.
            vec![ValType::EXTERNREF, ValType::EXTERNREF, ValType::EXTERNREF],
        );

        // 1: "run"
        let mut params: Vec<ValType> =
            Vec::with_capacity(usize::try_from(self.limits.num_params).unwrap());
        for _i in 0..self.limits.num_params {
            params.push(ValType::EXTERNREF);
        }
        let params_len = u32::try_from(params.len()).unwrap();
        let results = vec![];
        types.ty().function(params, results);

        // 2: `take_refs`
        types.ty().function(
            vec![ValType::EXTERNREF, ValType::EXTERNREF, ValType::EXTERNREF],
            vec![],
        );

        // 3: `make_refs`
        types.ty().function(
            vec![],
            vec![ValType::EXTERNREF, ValType::EXTERNREF, ValType::EXTERNREF],
        );

        // 4: `take_struct`
        types.ty().function(
            vec![ValType::Ref(RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Struct,
                },
            })],
            vec![],
        );

        // 5: `take_eq`
        types.ty().function(
            vec![ValType::Ref(RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Eq,
                },
            })],
            vec![],
        );

        // 6: `take_i31`
        //
        // Takes a `(ref null i31)` along with the guest's inline `i31.get_s`
        // and `i31.get_u` results, so the host can re-derive them and assert
        // that its view of the i31 matches the Wasm instructions'.
        let take_i31_type_idx = types.len();
        types.ty().function(
            vec![ValType::Ref(RefType::I31REF), ValType::I32, ValType::I32],
            vec![],
        );

        // 7: `take_array`
        let take_array_type_idx = types.len();
        types.ty().function(
            vec![ValType::Ref(RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Array,
                },
            })],
            vec![],
        );

        let struct_type_base: u32 = types.len();

        // Build the type-id-to-wasm-index map from the pre-computed
        // encoding order (rec groups in topo order, members sorted by
        // supertype-first within each group).
        let mut type_ids_to_index: BTreeMap<TypeId, u32> = BTreeMap::new();
        let mut next_idx = struct_type_base;
        for (_, members) in &encoding_order_grouped {
            for &tid in members {
                type_ids_to_index.insert(tid, next_idx);
                next_idx += 1;
            }
        }

        // Flat encoding order (dense index -> TypeId), used below for naming the
        // typed host imports and, later, for field lookups during encoding.
        let encoding_order: Vec<TypeId> = encoding_order_grouped
            .iter()
            .flat_map(|(_, members)| members.iter().copied())
            .collect();

        let encode_ty_id = |ty_id: &TypeId| -> wasm_encoder::SubType {
            let def = &self.types.type_defs[ty_id];
            let inner = match &def.composite_type {
                CompositeType::Struct(st) => {
                    let fields: Box<[wasm_encoder::FieldType]> = st
                        .fields
                        .iter()
                        .map(|f| wasm_encoder::FieldType {
                            element_type: f.field_type.to_storage_type(&type_ids_to_index),
                            mutable: f.mutable,
                        })
                        .collect();
                    wasm_encoder::CompositeInnerType::Struct(wasm_encoder::StructType { fields })
                }
                CompositeType::Array(at) => {
                    let element = wasm_encoder::FieldType {
                        element_type: at.element.field_type.to_storage_type(&type_ids_to_index),
                        mutable: at.element.mutable,
                    };
                    wasm_encoder::CompositeInnerType::Array(wasm_encoder::ArrayType(element))
                }
            };
            wasm_encoder::SubType {
                is_final: def.is_final,
                supertype_idx: def.supertype.map(|st| type_ids_to_index[&st]),
                composite_type: wasm_encoder::CompositeType {
                    inner,
                    shared: false,
                    describes: None,
                    descriptor: None,
                },
            }
        };

        let mut concrete_count = 0;

        // Emit rec groups in the pre-computed order.
        for (_, group_members) in &encoding_order_grouped {
            let members: Vec<wasm_encoder::SubType> =
                group_members.iter().map(encode_ty_id).collect();
            types.ty().rec(members);
            concrete_count += u32::try_from(group_members.len()).unwrap();
        }

        let typed_fn_type_base: u32 = struct_type_base + concrete_count;

        for i in 0..concrete_count {
            let concrete = struct_type_base + i;
            types.ty().function(
                vec![ValType::Ref(RefType {
                    nullable: true,
                    heap_type: wasm_encoder::HeapType::Concrete(concrete),
                })],
                vec![],
            );
        }

        // Import the GC function.
        let mut imports = ImportSection::new();
        imports.import("", "gc", EntityType::Function(0));
        imports.import("", "take_refs", EntityType::Function(2));
        imports.import("", "make_refs", EntityType::Function(3));
        imports.import("", "take_struct", EntityType::Function(4));
        imports.import("", "take_eq", EntityType::Function(5));
        imports.import("", "take_i31", EntityType::Function(take_i31_type_idx));
        imports.import("", "take_array", EntityType::Function(take_array_type_idx));

        // For each of our concrete struct/array types, define a function
        // import that takes an argument of that concrete type. The import name
        // records the kind so the host can define it appropriately.
        let typed_first_func_index: u32 = imports.len();

        for i in 0..concrete_count {
            let ty_idx = typed_fn_type_base + i;
            let wasm_idx = struct_type_base + i;
            let is_array = encoding_order
                .get(usize::try_from(i).unwrap())
                .and_then(|tid| self.types.type_defs.get(tid))
                .map(|def| def.composite_type.is_array())
                .unwrap_or(false);
            let name = if is_array {
                format!("take_array_{wasm_idx}")
            } else {
                format!("take_struct_{wasm_idx}")
            };
            imports.import("", &name, EntityType::Function(ty_idx));
        }

        // Define our table.
        let mut tables = TableSection::new();
        tables.table(TableType {
            element_type: RefType::EXTERNREF,
            minimum: u64::from(self.limits.table_size),
            maximum: None,
            table64: false,
            shared: false,
        });

        let struct_table_idx = tables.len();
        tables.table(TableType {
            element_type: RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Struct,
                },
            },
            minimum: u64::from(self.limits.table_size),
            maximum: None,
            table64: false,
            shared: false,
        });

        let eq_table_idx = tables.len();
        tables.table(TableType {
            element_type: RefType::EQREF,
            minimum: u64::from(self.limits.table_size),
            maximum: None,
            table64: false,
            shared: false,
        });

        let i31_table_idx = tables.len();
        tables.table(TableType {
            element_type: RefType::I31REF,
            minimum: u64::from(self.limits.table_size),
            maximum: None,
            table64: false,
            shared: false,
        });

        let array_table_idx = tables.len();
        tables.table(TableType {
            element_type: RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Array,
                },
            },
            minimum: u64::from(self.limits.table_size),
            maximum: None,
            table64: false,
            shared: false,
        });

        let typed_table_base = tables.len();
        for i in 0..concrete_count {
            let concrete = struct_type_base + i;
            tables.table(TableType {
                element_type: RefType {
                    nullable: true,
                    heap_type: wasm_encoder::HeapType::Concrete(concrete),
                },
                minimum: u64::from(self.limits.table_size),
                maximum: None,
                table64: false,
                shared: false,
            });
        }

        // Define our globals.
        let mut globals = GlobalSection::new();
        for _ in 0..self.limits.num_globals {
            globals.global(
                wasm_encoder::GlobalType {
                    val_type: wasm_encoder::ValType::EXTERNREF,
                    mutable: true,
                    shared: false,
                },
                &ConstExpr::ref_null(wasm_encoder::HeapType::EXTERN),
            );
        }

        // Add exactly one (ref.null struct) global.
        let struct_global_idx = globals.len();
        globals.global(
            wasm_encoder::GlobalType {
                val_type: ValType::Ref(RefType {
                    nullable: true,
                    heap_type: wasm_encoder::HeapType::Abstract {
                        shared: false,
                        ty: wasm_encoder::AbstractHeapType::Struct,
                    },
                }),
                mutable: true,
                shared: false,
            },
            &ConstExpr::ref_null(wasm_encoder::HeapType::Abstract {
                shared: false,
                ty: wasm_encoder::AbstractHeapType::Struct,
            }),
        );

        // Add exactly one (ref.null eq) global.
        let eq_global_idx = globals.len();
        globals.global(
            wasm_encoder::GlobalType {
                val_type: ValType::Ref(RefType::EQREF),
                mutable: true,
                shared: false,
            },
            &ConstExpr::ref_null(wasm_encoder::HeapType::Abstract {
                shared: false,
                ty: wasm_encoder::AbstractHeapType::Eq,
            }),
        );

        // Add exactly one (ref.null i31) global.
        let i31_global_idx = globals.len();
        globals.global(
            wasm_encoder::GlobalType {
                val_type: ValType::Ref(RefType::I31REF),
                mutable: true,
                shared: false,
            },
            &ConstExpr::ref_null(wasm_encoder::HeapType::I31),
        );

        // Add exactly one (ref.null array) global.
        let array_global_idx = globals.len();
        globals.global(
            wasm_encoder::GlobalType {
                val_type: ValType::Ref(RefType {
                    nullable: true,
                    heap_type: wasm_encoder::HeapType::Abstract {
                        shared: false,
                        ty: wasm_encoder::AbstractHeapType::Array,
                    },
                }),
                mutable: true,
                shared: false,
            },
            &ConstExpr::ref_null(wasm_encoder::HeapType::Abstract {
                shared: false,
                ty: wasm_encoder::AbstractHeapType::Array,
            }),
        );

        // Add one typed (ref <type>) global per struct/array type.
        let typed_global_base = globals.len();
        for i in 0..concrete_count {
            let concrete = struct_type_base + i;
            globals.global(
                wasm_encoder::GlobalType {
                    val_type: ValType::Ref(RefType {
                        nullable: true,
                        heap_type: wasm_encoder::HeapType::Concrete(concrete),
                    }),
                    mutable: true,
                    shared: false,
                },
                &ConstExpr::ref_null(wasm_encoder::HeapType::Concrete(concrete)),
            );
        }

        // Define the "run" function export.
        let mut functions = FunctionSection::new();
        let mut exports = ExportSection::new();

        let run_defined_idx = functions.len();
        functions.function(1);
        let run_func_index = imports.len() + run_defined_idx;
        exports.export("run", ExportKind::Func, run_func_index);

        // Give ourselves one scratch local that we can use in various `GcOp`
        // implementations.
        let mut local_decls: Vec<(u32, ValType)> = vec![(1, ValType::EXTERNREF)];

        let scratch_local = params_len;
        let struct_local_idx = scratch_local + 1;
        local_decls.push((
            1,
            ValType::Ref(RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Struct,
                },
            }),
        ));

        let eq_local_idx = struct_local_idx + 1;
        local_decls.push((1, ValType::Ref(RefType::EQREF)));

        let i31_local_idx = eq_local_idx + 1;
        local_decls.push((1, ValType::Ref(RefType::I31REF)));

        let array_local_idx = i31_local_idx + 1;
        local_decls.push((
            1,
            ValType::Ref(RefType {
                nullable: true,
                heap_type: wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Array,
                },
            }),
        ));

        let typed_local_base: u32 = array_local_idx + 1;
        let typed_local2_base: u32 = typed_local_base + concrete_count;
        for _ in 0..2 {
            for i in 0..concrete_count {
                let concrete = struct_type_base + i;
                local_decls.push((
                    1,
                    ValType::Ref(RefType {
                        nullable: true,
                        heap_type: wasm_encoder::HeapType::Concrete(concrete),
                    }),
                ));
            }
        }

        let storage_bases = WasmEncodingBases {
            struct_type_base,
            typed_first_func_index,
            struct_local_idx,
            eq_local_idx,
            i31_local_idx,
            array_local_idx,
            typed_local_base,
            typed_local2_base,
            struct_global_idx,
            eq_global_idx,
            i31_global_idx,
            array_global_idx,
            typed_global_base,
            struct_table_idx,
            eq_table_idx,
            i31_table_idx,
            array_table_idx,
            typed_table_base,
            array_length: self.limits.array_length,
        };

        let mut func = Function::new(local_decls);
        func.instruction(&Instruction::Loop(wasm_encoder::BlockType::Empty));
        for op in &self.ops {
            op.encode(
                &mut func,
                scratch_local,
                storage_bases,
                &self.types,
                &encoding_order,
                &type_ids_to_index,
            );
        }
        func.instruction(&Instruction::Br(0));
        func.instruction(&Instruction::End);
        func.instruction(&Instruction::End);

        let mut code = CodeSection::new();
        code.function(&func);

        module
            .section(&types)
            .section(&imports)
            .section(&functions)
            .section(&tables)
            .section(&globals)
            .section(&exports)
            .section(&code);

        module.finish()
    }

    /// Fixes this test case such that it becomes valid.
    ///
    /// This is necessary because a random mutation (e.g. removing an op in the
    /// middle of our sequence) might have made it so that subsequent ops won't
    /// have their expected operand types on the Wasm stack
    /// anymore. Furthermore, because we serialize and deserialize test cases,
    /// and libFuzzer will occasionally mutate those serialized bytes directly,
    /// rather than use one of our custom mutations, we have no guarantee that
    /// pre-mutation test cases are even valid! Therefore, we always call this
    /// method before translating this "AST"-style representation into a raw
    /// Wasm binary.
    pub fn fixup(&mut self, encoding_order_grouped: &mut Vec<(RecGroupId, Vec<TypeId>)>) {
        self.limits.fixup();
        self.types.fixup(&self.limits, encoding_order_grouped);
        let encoding_order: Vec<TypeId> = encoding_order_grouped
            .iter()
            .flat_map(|(_, members)| members.iter().copied())
            .collect();

        let mut new_ops = Vec::with_capacity(self.ops.len());
        let mut stack: Vec<StackType> = Vec::new();
        let num_types = u32::try_from(self.types.type_defs.len()).unwrap();

        // Concrete encoding indices split by kind, so typed ops can be remapped
        // onto a same-kind type (struct ops never point at an array, etc.).
        let mut struct_type_indices = Vec::new();
        let mut array_type_indices = Vec::new();
        for (i, tid) in encoding_order.iter().enumerate() {
            let i = u32::try_from(i).unwrap();
            match self.types.type_defs.get(tid) {
                Some(def) if def.composite_type.is_array() => array_type_indices.push(i),
                Some(_) => struct_type_indices.push(i),
                None => {}
            }
        }

        let mut operand_types = Vec::new();
        for op in &self.ops {
            let Some(op) = op.fixup(
                &self.limits,
                num_types,
                &struct_type_indices,
                &array_type_indices,
            ) else {
                continue;
            };
            let op = StackType::fixup_cast(op, &self.types, &encoding_order);

            debug_assert!(operand_types.is_empty());
            op.operand_types(&mut operand_types);
            for ty in operand_types.drain(..) {
                StackType::fixup(
                    ty,
                    &mut stack,
                    &mut new_ops,
                    num_types,
                    &self.types,
                    &encoding_order,
                );
            }

            // Finally, emit the op itself (updates stack abstractly)
            let mut result_types = Vec::new();
            StackType::emit(op, &mut stack, &mut new_ops, num_types, &mut result_types);
        }

        // Drop any remaining values on the operand stack.
        for _ in 0..stack.len() {
            new_ops.push(GcOp::Drop);
        }

        log::trace!("ops after fixup: {new_ops:#?}");
        self.ops = new_ops;
    }

    /// Attempts to remove the last opcode from the sequence.
    ///
    /// Returns `true` if an opcode was successfully removed, or `false` if the
    /// list was already empty.
    pub fn pop(&mut self) -> bool {
        self.ops.pop().is_some()
    }
}

macro_rules! for_each_gc_op {
    ( $mac:ident ) => {
        $mac! {
            #[operands([])]
            #[results([ExternRef, ExternRef, ExternRef])]
            Gc,

            #[operands([])]
            #[results([ExternRef, ExternRef, ExternRef])]
            MakeRefs,

            #[operands([Some(ExternRef), Some(ExternRef), Some(ExternRef)])]
            #[results([])]
            TakeRefs,

            #[operands([])]
            #[results([ExternRef])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            TableGet { elem_index: u32 },

            #[operands([Some(ExternRef)])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            TableSet { elem_index: u32 },

            #[operands([])]
            #[results([ExternRef])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                global_index = global_index.checked_rem(limits.num_globals)?;
            })]
            GlobalGet { global_index:  u32 },

            #[operands([Some(ExternRef)])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                global_index = global_index.checked_rem(limits.num_globals)?;
            })]
            GlobalSet { global_index: u32 },

            #[operands([])]
            #[results([ExternRef])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                local_index = local_index.checked_rem(limits.num_params)?;
            })]
            LocalGet { local_index: u32 },

            #[operands([Some(ExternRef)])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                local_index = local_index.checked_rem(limits.num_params)?;
            })]
            LocalSet { local_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            StructNew { type_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            StructNewDefault { type_index: u32 },

            #[operands([Some(Struct(None))])]
            #[results([])]
            TakeStructCall,

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TakeTypedStructCall { type_index: u32 },

            #[operands([Some(Struct(None))])]
            #[results([])]
            StructLocalSet,

            #[operands([])]
            #[results([Struct(None)])]
            StructLocalGet,

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructLocalSet { type_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructLocalGet { type_index: u32 },

            #[operands([Some(Struct(None))])]
            #[results([])]
            StructGlobalSet,

            #[operands([])]
            #[results([Struct(None)])]
            StructGlobalGet,

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructGlobalSet { type_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructGlobalGet { type_index: u32 },

            #[operands([Some(Struct(None))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            StructTableSet { elem_index: u32 },

            #[operands([])]
            #[results([Struct(None)])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            StructTableGet { elem_index: u32 },

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructTableSet { elem_index: u32, type_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructTableGet { elem_index: u32, type_index: u32 },

            #[operands([None])]
            #[results([])]
            Drop,

            #[operands([])]
            #[results([ExternRef])]
            NullExtern,

            #[operands([])]
            #[results([Struct(None)])]
            NullStruct,

            #[operands([])]
            #[results([Eq])]
            NullEq,

            #[operands([Some(Eq)])]
            #[results([])]
            TakeEqCall,

            #[operands([Some(Eq)])]
            #[results([])]
            EqLocalSet,

            #[operands([])]
            #[results([Eq])]
            EqLocalGet,

            #[operands([Some(Eq)])]
            #[results([])]
            EqGlobalSet,

            #[operands([])]
            #[results([Eq])]
            EqGlobalGet,

            #[operands([Some(Eq)])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            EqTableSet { elem_index: u32 },

            #[operands([])]
            #[results([Eq])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            EqTableGet { elem_index: u32 },

            #[operands([])]
            #[results([Struct(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            NullTypedStruct { type_index: u32 },

            #[operands([Some(Struct(Some(sub_type_index)))])]
            #[results([Struct(Some(super_type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                sub_type_index = pick_type_index(struct_type_indices, sub_type_index)?;
                super_type_index = pick_type_index(struct_type_indices, super_type_index)?;
            })]
            RefCastUpward { sub_type_index: u32, super_type_index: u32 },

            #[operands([Some(Struct(Some(super_type_index)))])]
            #[results([Struct(Some(sub_type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                sub_type_index = pick_type_index(struct_type_indices, sub_type_index)?;
                super_type_index = pick_type_index(struct_type_indices, super_type_index)?;
            })]
            RefCastDownward { sub_type_index: u32, super_type_index: u32 },

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            StructGet { type_index: u32, field_index: u32 },

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            StructGetU { type_index: u32, field_index: u32 },

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            StructSet { type_index: u32, field_index: u32 },

            #[operands([])]
            #[results([I31])]
            NullI31,

            #[operands([])]
            #[results([I31])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Any `i32` is a valid operand to `ref.i31` (it wraps to 31
                // bits), so no clamping is needed.
            })]
            RefI31 { value: u32 },

            #[operands([Some(I31)])]
            #[results([])]
            I31LocalSet,

            #[operands([])]
            #[results([I31])]
            I31LocalGet,

            #[operands([Some(I31)])]
            #[results([])]
            I31GlobalSet,

            #[operands([])]
            #[results([I31])]
            I31GlobalGet,

            #[operands([Some(I31)])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            I31TableSet { elem_index: u32 },

            #[operands([])]
            #[results([I31])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            I31TableGet { elem_index: u32 },

            #[operands([Some(I31)])]
            #[results([])]
            TakeI31Call,

            #[operands([Some(I31)])]
            #[results([])]
            I31GetS,

            #[operands([Some(I31)])]
            #[results([])]
            I31GetU,

            #[operands([Some(Struct(None))])]
            #[results([Eq])]
            StructRefAsEq,

            #[operands([Some(Struct(Some(type_index)))])]
            #[results([Eq])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(struct_type_indices, type_index)?;
            })]
            TypedStructRefAsEq { type_index: u32 },

            #[operands([Some(I31)])]
            #[results([Eq])]
            I31RefAsEq,

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayNewDefault { type_index: u32 },

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayNew { type_index: u32 },

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                n = n % (limits.array_length + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayNewFixed { type_index: u32, n: u32 },

            #[operands([])]
            #[results([Array(None)])]
            NullArray,

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            NullTypedArray { type_index: u32 },

            #[operands([Some(Array(None))])]
            #[results([])]
            TakeArrayCall,

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TakeTypedArrayCall { type_index: u32 },

            #[operands([Some(Array(None))])]
            #[results([])]
            ArrayLocalSet,

            #[operands([])]
            #[results([Array(None)])]
            ArrayLocalGet,

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayLocalSet { type_index: u32 },

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayLocalGet { type_index: u32 },

            #[operands([Some(Array(None))])]
            #[results([])]
            ArrayGlobalSet,

            #[operands([])]
            #[results([Array(None)])]
            ArrayGlobalGet,

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayGlobalSet { type_index: u32 },

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayGlobalGet { type_index: u32 },

            #[operands([Some(Array(None))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            ArrayTableSet { elem_index: u32 },

            #[operands([])]
            #[results([Array(None)])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
            })]
            ArrayTableGet { elem_index: u32 },

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayTableSet { elem_index: u32, type_index: u32 },

            #[operands([])]
            #[results([Array(Some(type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Add one to make sure that out-of-bounds table accesses are
                // possible, but still rare.
                elem_index = elem_index % (limits.table_size + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayTableGet { elem_index: u32, type_index: u32 },

            #[operands([Some(Array(Some(sub_type_index)))])]
            #[results([Array(Some(super_type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                sub_type_index = pick_type_index(array_type_indices, sub_type_index)?;
                super_type_index = pick_type_index(array_type_indices, super_type_index)?;
            })]
            ArrayRefCastUpward { sub_type_index: u32, super_type_index: u32 },

            #[operands([Some(Array(Some(super_type_index)))])]
            #[results([Array(Some(sub_type_index))])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                sub_type_index = pick_type_index(array_type_indices, sub_type_index)?;
                super_type_index = pick_type_index(array_type_indices, super_type_index)?;
            })]
            ArrayRefCastDownward { sub_type_index: u32, super_type_index: u32 },

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                // Keep most indices in-bounds: an array is exactly `array_length`
                // long, so `% (array_length + 1)` is out-of-bounds only for one
                // index value, making OOB traps possible but rare.
                index = index % (limits.array_length + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayGet { type_index: u32, index: u32 },

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                index = index % (limits.array_length + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayGetU { type_index: u32, index: u32 },

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                index = index % (limits.array_length + 1);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArraySet { type_index: u32, index: u32 },

            #[operands([Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                offset = offset % (limits.array_length + 1);
                len = len % (limits.array_length - offset + 2);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayFill { type_index: u32, offset: u32, len: u32 },

            #[operands([Some(Array(Some(type_index))), Some(Array(Some(type_index)))])]
            #[results([])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                dst_offset = dst_offset % (limits.array_length + 1);
                src_offset = src_offset % (limits.array_length + 1);
                len = len % (limits.array_length - dst_offset.max(src_offset) + 2);
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            ArrayCopy { type_index: u32, dst_offset: u32, src_offset: u32, len: u32 },

            #[operands([Some(Array(None))])]
            #[results([])]
            ArrayLen,

            #[operands([Some(Array(None))])]
            #[results([Eq])]
            ArrayRefAsEq,

            #[operands([Some(Array(Some(type_index)))])]
            #[results([Eq])]
            #[fixup(|limits, num_types, struct_type_indices, array_type_indices| {
                type_index = pick_type_index(array_type_indices, type_index)?;
            })]
            TypedArrayRefAsEq { type_index: u32 },
        }
    };
}

macro_rules! define_gc_op_variants {
    (
        $(
            $( #[$attr:meta] )*
            $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
        )*
    ) => {
        /// The operations that can be performed by the `gc` function.
        #[derive(
            Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize, mutatis::Mutate,
        )]
        #[mutatis(default_mutate = false)]
        #[allow(missing_docs, reason = "self-describing")]
        pub enum GcOp {
            $(
                $op $( { $( #[mutatis(default_mutate)] $field : $field_ty ),* } )? ,
            )*
        }
    };
}
for_each_gc_op!(define_gc_op_variants);

macro_rules! define_op_names {
    (
        $(
            $( #[$attr:meta] )*
            $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
        )*
    ) => {
        #[cfg(test)]
        pub(crate) const OP_NAMES: &[&str] = &[
            $(stringify!($op)),*
        ];
    }
}
for_each_gc_op!(define_op_names);

impl GcOp {
    #[cfg(test)]
    pub(crate) fn name(&self) -> &'static str {
        macro_rules! define_gc_op_name {
            (
                $(
                    $( #[$attr:meta] )*
                    $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
                )*
            ) => {
                match self {
                    $(
                        Self::$op $( { $($field: _),* } )? => stringify!($op),
                    )*
                }
            };
        }
        for_each_gc_op!(define_gc_op_name)
    }

    pub(crate) fn operand_types(&self, out: &mut Vec<Option<StackType>>) {
        macro_rules! define_gc_op_operand_types {
            (
                $(
                    #[operands($operands:expr)]
                    $( #[$attr:meta] )*
                    $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
                )*
            ) => {{
                use StackType::*;
                match self {
                    $(
                        Self::$op $( { $($field),* } )? => {
                            $(
                                $(
                                    #[allow(unused, reason = "macro code")]
                                    let $field = *$field;
                                )*
                            )?
                            let operands: [Option<StackType>; _] = $operands;
                            out.extend(operands);
                        }
                    )*
                }
            }};
        }
        for_each_gc_op!(define_gc_op_operand_types)
    }

    pub(crate) fn result_types(&self, out: &mut Vec<StackType>) {
        macro_rules! define_gc_op_result_types {
            (
                $(
                    #[operands($operands:expr)]
                    #[results($results:expr)]
                    $( #[$attr:meta] )*
                    $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
                )*
            ) => {{
                use StackType::*;
                match self {
                    $(
                        Self::$op $( { $($field),* } )? => {
                            $(
                                $(
                                    #[allow(unused, reason = "macro code")]
                                    let $field = *$field;
                                )*
                            )?
                            let results: [StackType; _] = $results;
                            out.extend(results);
                        }
                    )*
                }
            }};
        }
        for_each_gc_op!(define_gc_op_result_types)
    }

    /// Fix up an op's immediates. `struct_type_indices` / `array_type_indices`
    /// are the concrete encoding indices of each kind; a typed op remaps its
    /// type index into the matching set so struct ops never point at an array
    /// (or vice versa), and drops itself if no type of that kind exists.
    pub(crate) fn fixup(
        &self,
        limits: &GcOpsLimits,
        num_types: u32,
        struct_type_indices: &[u32],
        array_type_indices: &[u32],
    ) -> Option<Self> {
        macro_rules! define_gc_op_fixup {
            (
                $(
                    #[operands($operands:expr)]
                    #[results($results:expr)]
                    $( #[fixup(|$limits:ident, $num_types:ident, $structs:ident, $arrays:ident| $fixup:expr)] )?
                    $op:ident $( { $( $field:ident : $field_ty:ty ),* } )? ,
                )*
            ) => {{
                let _ = (limits, num_types, struct_type_indices, array_type_indices);
                match self {
                    $(
                        Self::$op $( { $($field),* } )? => {
                            $(
                                $(
                                    #[allow(unused_mut, unused_assignments, reason = "macro code")]
                                    let mut $field = *$field;
                                )*
                                #[allow(unused_variables, reason = "macro code")]
                                let $limits = limits;
                                #[allow(unused_variables, reason = "macro code")]
                                let $num_types = num_types;
                                #[allow(unused_variables, reason = "macro code")]
                                let $structs = struct_type_indices;
                                #[allow(unused_variables, reason = "macro code")]
                                let $arrays = array_type_indices;
                                $fixup;
                            )?
                            Some(Self::$op $( { $( $field ),* } )? )
                        }
                    )*
                }
            }};
        }
        for_each_gc_op!(define_gc_op_fixup)
    }

    fn encode(
        &self,
        func: &mut Function,
        scratch_local: u32,
        encoding_bases: WasmEncodingBases,
        types: &Types,
        encoding_order: &[TypeId],
        type_ids_to_index: &BTreeMap<TypeId, u32>,
    ) {
        let gc_func_idx = 0;
        let take_refs_func_idx = 1;
        let make_refs_func_idx = 2;
        let take_structref_idx = 3;
        let take_eqref_idx = 4;
        let take_i31_idx = 5;
        let take_arrayref_idx = 6;

        match *self {
            Self::Gc => {
                func.instruction(&Instruction::Call(gc_func_idx));
            }
            Self::MakeRefs => {
                func.instruction(&Instruction::Call(make_refs_func_idx));
            }
            Self::TakeRefs => {
                func.instruction(&Instruction::Call(take_refs_func_idx));
            }
            Self::TableGet { elem_index: x } => {
                func.instruction(&Instruction::I32Const(x.cast_signed()));
                func.instruction(&Instruction::TableGet(0));
            }
            Self::TableSet { elem_index: x } => {
                func.instruction(&Instruction::LocalSet(scratch_local));
                func.instruction(&Instruction::I32Const(x.cast_signed()));
                func.instruction(&Instruction::LocalGet(scratch_local));
                func.instruction(&Instruction::TableSet(0));
            }
            Self::GlobalGet { global_index: x } => {
                func.instruction(&Instruction::GlobalGet(x));
            }
            Self::GlobalSet { global_index: x } => {
                func.instruction(&Instruction::GlobalSet(x));
            }
            Self::LocalGet { local_index: x } => {
                func.instruction(&Instruction::LocalGet(x));
            }
            Self::LocalSet { local_index: x } => {
                func.instruction(&Instruction::LocalSet(x));
            }
            Self::Drop => {
                func.instruction(&Instruction::Drop);
            }
            Self::NullExtern => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::EXTERN));
            }
            Self::NullStruct => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Struct,
                }));
            }
            Self::NullEq => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Eq,
                }));
            }
            Self::TakeEqCall => {
                func.instruction(&Instruction::Call(take_eqref_idx));
            }
            Self::EqLocalGet => {
                func.instruction(&Instruction::LocalGet(encoding_bases.eq_local_idx));
            }
            Self::EqLocalSet => {
                func.instruction(&Instruction::LocalSet(encoding_bases.eq_local_idx));
            }
            Self::EqGlobalGet => {
                func.instruction(&Instruction::GlobalGet(encoding_bases.eq_global_idx));
            }
            Self::EqGlobalSet => {
                func.instruction(&Instruction::GlobalSet(encoding_bases.eq_global_idx));
            }
            Self::EqTableGet { elem_index } => {
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::TableGet(encoding_bases.eq_table_idx));
            }
            Self::EqTableSet { elem_index } => {
                // Use eq_local_idx (eqref) to temporarily store the value before table.set.
                func.instruction(&Instruction::LocalSet(encoding_bases.eq_local_idx));
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::LocalGet(encoding_bases.eq_local_idx));
                func.instruction(&Instruction::TableSet(encoding_bases.eq_table_idx));
            }
            // `NullTypedStruct` / `NullTypedArray` both produce a typed null; the
            // concrete type index already resolves to the right kind.
            Self::NullTypedStruct { type_index } | Self::NullTypedArray { type_index } => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::Concrete(
                    encoding_bases.struct_type_base + type_index,
                )));
            }
            Self::StructNew { type_index: x } => {
                if let Some(tid) = encoding_order.get(usize::try_from(x).unwrap()) {
                    if let Some(CompositeType::Struct(st)) =
                        types.type_defs.get(tid).map(|def| &def.composite_type)
                    {
                        for field in &st.fields {
                            field.field_type.emit_default_const(func, type_ids_to_index);
                        }
                    }
                }
                func.instruction(&Instruction::StructNew(encoding_bases.struct_type_base + x));
            }
            Self::StructNewDefault { type_index: x } => {
                func.instruction(&Instruction::StructNewDefault(
                    encoding_bases.struct_type_base + x,
                ));
            }
            Self::ArrayNewDefault { type_index: x } => {
                // Create a default-initialized array of a fixed length so most
                // subsequent indexed accesses are in-bounds.
                func.instruction(&Instruction::I32Const(
                    encoding_bases.array_length.cast_signed(),
                ));
                func.instruction(&Instruction::ArrayNewDefault(
                    encoding_bases.struct_type_base + x,
                ));
            }
            Self::ArrayNew { type_index: x } => {
                if let Some(element) = array_element(types, encoding_order, x) {
                    element
                        .field_type
                        .emit_default_const(func, type_ids_to_index);
                }
                func.instruction(&Instruction::I32Const(
                    encoding_bases.array_length.cast_signed(),
                ));
                func.instruction(&Instruction::ArrayNew(encoding_bases.struct_type_base + x));
            }
            Self::ArrayNewFixed { type_index: x, n } => {
                if let Some(element) = array_element(types, encoding_order, x) {
                    for _ in 0..n {
                        element
                            .field_type
                            .emit_default_const(func, type_ids_to_index);
                    }
                }
                func.instruction(&Instruction::ArrayNewFixed {
                    array_type_index: encoding_bases.struct_type_base + x,
                    array_size: n,
                });
            }
            Self::TakeStructCall => {
                func.instruction(&Instruction::Call(take_structref_idx));
            }
            // Typed struct/array calls and storage share identical encodings
            // (they index the same kind-agnostic typed func/local/global/table
            // slots); only their abstract stack type differs.
            Self::TakeTypedStructCall { type_index: x }
            | Self::TakeTypedArrayCall { type_index: x } => {
                let f = encoding_bases.typed_first_func_index + x;
                func.instruction(&Instruction::Call(f));
            }
            Self::StructLocalGet => {
                func.instruction(&Instruction::LocalGet(encoding_bases.struct_local_idx));
            }
            Self::TypedStructLocalGet { type_index: x }
            | Self::TypedArrayLocalGet { type_index: x } => {
                func.instruction(&Instruction::LocalGet(encoding_bases.typed_local_base + x));
            }
            Self::StructLocalSet => {
                func.instruction(&Instruction::LocalSet(encoding_bases.struct_local_idx));
            }
            Self::TypedStructLocalSet { type_index: x }
            | Self::TypedArrayLocalSet { type_index: x } => {
                func.instruction(&Instruction::LocalSet(encoding_bases.typed_local_base + x));
            }
            Self::StructGlobalGet => {
                func.instruction(&Instruction::GlobalGet(encoding_bases.struct_global_idx));
            }
            Self::TypedStructGlobalGet { type_index: x }
            | Self::TypedArrayGlobalGet { type_index: x } => {
                func.instruction(&Instruction::GlobalGet(
                    encoding_bases.typed_global_base + x,
                ));
            }
            Self::StructGlobalSet => {
                func.instruction(&Instruction::GlobalSet(encoding_bases.struct_global_idx));
            }
            Self::TypedStructGlobalSet { type_index: x }
            | Self::TypedArrayGlobalSet { type_index: x } => {
                func.instruction(&Instruction::GlobalSet(
                    encoding_bases.typed_global_base + x,
                ));
            }
            Self::StructTableGet { elem_index } => {
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::TableGet(encoding_bases.struct_table_idx));
            }
            Self::TypedStructTableGet {
                elem_index,
                type_index,
            }
            | Self::TypedArrayTableGet {
                elem_index,
                type_index,
            } => {
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::TableGet(
                    encoding_bases.typed_table_base + type_index,
                ));
            }
            Self::StructTableSet { elem_index } => {
                // Use struct_local_idx (anyref) to temporarily store the value before table.set
                func.instruction(&Instruction::LocalSet(encoding_bases.struct_local_idx));
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::LocalGet(encoding_bases.struct_local_idx));
                func.instruction(&Instruction::TableSet(encoding_bases.struct_table_idx));
            }
            Self::TypedStructTableSet {
                elem_index,
                type_index,
            }
            | Self::TypedArrayTableSet {
                elem_index,
                type_index,
            } => {
                func.instruction(&Instruction::LocalSet(
                    encoding_bases.typed_local_base + type_index,
                ));
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::LocalGet(
                    encoding_bases.typed_local_base + type_index,
                ));
                func.instruction(&Instruction::TableSet(
                    encoding_bases.typed_table_base + type_index,
                ));
            }
            Self::RefCastUpward {
                sub_type_index: _,
                super_type_index,
            }
            | Self::ArrayRefCastUpward {
                sub_type_index: _,
                super_type_index,
            } => {
                // The value on the stack is already the subtype, so this
                // cast always succeeds.
                let heap_type = wasm_encoder::HeapType::Concrete(
                    encoding_bases.struct_type_base + super_type_index,
                );
                func.instruction(&Instruction::RefCastNullable(heap_type));
            }
            Self::RefCastDownward {
                sub_type_index,
                super_type_index,
            }
            | Self::ArrayRefCastDownward {
                sub_type_index,
                super_type_index,
            } => {
                // Fallible downcast that never traps:
                //
                //   local.tee $my_temp
                //   ;; Test if the downcast will succeed.
                //   ref.test ...
                //   if (result (ref null $my_sub))
                //     ;; The downcast will succeed, do a downcast-or-trap
                //     ;; operation which we know will not trap.
                //     local.get $my_temp
                //     ref.cast ...
                //   else
                //     ;; The downcast would fail, so just create a null
                //     ;; reference instead.
                //     ref.null ...
                //   end
                let sub_wasm_type = encoding_bases.struct_type_base + sub_type_index;
                let sub_heap_type = wasm_encoder::HeapType::Concrete(sub_wasm_type);
                let temp_local = encoding_bases.typed_local_base + super_type_index;

                // Tee the supertype value into a temp local (saves and
                // leaves the value on the stack for ref.test).
                func.instruction(&Instruction::LocalTee(temp_local));

                // Test if the downcast will succeed.
                func.instruction(&Instruction::RefTestNullable(sub_heap_type));

                // if (result (ref null $sub_type))
                func.instruction(&Instruction::If(wasm_encoder::BlockType::Result(
                    ValType::Ref(RefType {
                        nullable: true,
                        heap_type: sub_heap_type,
                    }),
                )));

                // The downcast will succeed; do the cast.
                func.instruction(&Instruction::LocalGet(temp_local));
                func.instruction(&Instruction::RefCastNullable(sub_heap_type));

                func.instruction(&Instruction::Else);

                // The downcast would fail; produce null instead.
                func.instruction(&Instruction::RefNull(sub_heap_type));

                func.instruction(&Instruction::End);
            }
            Self::StructGet {
                type_index,
                field_index,
            }
            | Self::StructGetU {
                type_index,
                field_index,
            } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let fields = encoding_order
                    .get(usize::try_from(type_index).unwrap())
                    .and_then(|tid| types.type_defs.get(tid))
                    .and_then(|def| match &def.composite_type {
                        CompositeType::Struct(st) => Some(&st.fields[..]),
                        CompositeType::Array(_) => None,
                    });

                match fields {
                    Some(fields) if !fields.is_empty() => {
                        let typed_local = encoding_bases.typed_local_base + type_index;
                        // Guard against null: save ref, check, skip if null.
                        func.instruction(&Instruction::LocalTee(typed_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                        func.instruction(&Instruction::Else);
                        func.instruction(&Instruction::LocalGet(typed_local));
                        let idx = field_index % u32::try_from(fields.len()).unwrap();
                        if fields[usize::try_from(idx).unwrap()].field_type.is_packed() {
                            if matches!(self, Self::StructGetU { .. }) {
                                func.instruction(&Instruction::StructGetU {
                                    struct_type_index: wasm_type,
                                    field_index: idx,
                                });
                            } else {
                                func.instruction(&Instruction::StructGetS {
                                    struct_type_index: wasm_type,
                                    field_index: idx,
                                });
                            }
                        } else {
                            func.instruction(&Instruction::StructGet {
                                struct_type_index: wasm_type,
                                field_index: idx,
                            });
                        }
                        // Drop the result — field values are not tracked
                        // on the abstract stack.
                        func.instruction(&Instruction::Drop);
                        func.instruction(&Instruction::End);
                    }
                    _ => {
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::StructSet {
                type_index,
                field_index,
            } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let fields = encoding_order
                    .get(usize::try_from(type_index).unwrap())
                    .and_then(|tid| types.type_defs.get(tid))
                    .and_then(|def| match &def.composite_type {
                        CompositeType::Struct(st) => Some(&st.fields[..]),
                        CompositeType::Array(_) => None,
                    });

                match fields {
                    Some(fields) if !fields.is_empty() => {
                        let len = fields.len();
                        let start = (usize::try_from(field_index).unwrap()) % len;
                        let mutable_field = (0..len)
                            .map(|offset| (start + offset) % len)
                            .find(|&i| fields[i].mutable);

                        match mutable_field {
                            Some(idx) => {
                                let typed_local = encoding_bases.typed_local_base + type_index;

                                // Wasm stack: [struct_ref]
                                func.instruction(&Instruction::LocalTee(typed_local));
                                func.instruction(&Instruction::RefIsNull);
                                func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                                func.instruction(&Instruction::Else);
                                func.instruction(&Instruction::LocalGet(typed_local));
                                fields[idx]
                                    .field_type
                                    .emit_default_const(func, type_ids_to_index);
                                let idx = u32::try_from(idx).unwrap();
                                func.instruction(&Instruction::StructSet {
                                    struct_type_index: wasm_type,
                                    field_index: idx,
                                });
                                func.instruction(&Instruction::End);
                            }
                            None => {
                                func.instruction(&Instruction::Drop);
                            }
                        }
                    }
                    _ => {
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::NullI31 => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::I31));
            }
            Self::RefI31 { value } => {
                func.instruction(&Instruction::I32Const(value.cast_signed()));
                func.instruction(&Instruction::RefI31);
            }
            Self::I31LocalGet => {
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
            }
            Self::I31LocalSet => {
                func.instruction(&Instruction::LocalSet(encoding_bases.i31_local_idx));
            }
            Self::I31GlobalGet => {
                func.instruction(&Instruction::GlobalGet(encoding_bases.i31_global_idx));
            }
            Self::I31GlobalSet => {
                func.instruction(&Instruction::GlobalSet(encoding_bases.i31_global_idx));
            }
            Self::I31TableGet { elem_index } => {
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::TableGet(encoding_bases.i31_table_idx));
            }
            Self::I31TableSet { elem_index } => {
                // Use i31_local_idx (i31ref) to temporarily store the value before table.set.
                func.instruction(&Instruction::LocalSet(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::TableSet(encoding_bases.i31_table_idx));
            }
            Self::StructRefAsEq
            | Self::TypedStructRefAsEq { .. }
            | Self::ArrayRefAsEq
            | Self::TypedArrayRefAsEq { .. }
            | Self::I31RefAsEq => {
                // Upcasting to `eqref` is implicit in Wasm subtyping: `struct`,
                // `array`, and `i31` are all subtypes of `eq`, so the value
                // already on the stack is a valid `eqref` and no instruction is
                // required. Only the abstract stack type changes (via
                // `result_types`).
            }
            Self::I31GetS | Self::I31GetU => {
                // `i31.get_s`/`i31.get_u` trap on a null reference, so guard
                // against null: save the ref, test it, and only perform the
                // get when non-null. The i32 result is not tracked on the
                // abstract stack, so drop it.
                func.instruction(&Instruction::LocalTee(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::RefIsNull);
                func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                func.instruction(&Instruction::Else);
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
                if matches!(self, Self::I31GetS) {
                    func.instruction(&Instruction::I31GetS);
                } else {
                    func.instruction(&Instruction::I31GetU);
                }
                func.instruction(&Instruction::Drop);
                func.instruction(&Instruction::End);
            }
            Self::TakeI31Call => {
                // Differential check: pass the i31ref plus the guest's inline
                // `i31.get_s` and `i31.get_u` results to the host, which
                // re-derives them and asserts they match. The get instructions
                // trap on null, so guard against it.
                func.instruction(&Instruction::LocalTee(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::RefIsNull);
                func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                // Null branch: `take_i31(null, 0, 0)`.
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::I31));
                func.instruction(&Instruction::I32Const(0));
                func.instruction(&Instruction::I32Const(0));
                func.instruction(&Instruction::Call(take_i31_idx));
                func.instruction(&Instruction::Else);
                // Non-null branch: `take_i31(ref, i31.get_s, i31.get_u)`.
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::I31GetS);
                func.instruction(&Instruction::LocalGet(encoding_bases.i31_local_idx));
                func.instruction(&Instruction::I31GetU);
                func.instruction(&Instruction::Call(take_i31_idx));
                func.instruction(&Instruction::End);
            }
            Self::NullArray => {
                func.instruction(&Instruction::RefNull(wasm_encoder::HeapType::Abstract {
                    shared: false,
                    ty: wasm_encoder::AbstractHeapType::Array,
                }));
            }
            Self::TakeArrayCall => {
                func.instruction(&Instruction::Call(take_arrayref_idx));
            }
            Self::ArrayLocalGet => {
                func.instruction(&Instruction::LocalGet(encoding_bases.array_local_idx));
            }
            Self::ArrayLocalSet => {
                func.instruction(&Instruction::LocalSet(encoding_bases.array_local_idx));
            }
            Self::ArrayGlobalGet => {
                func.instruction(&Instruction::GlobalGet(encoding_bases.array_global_idx));
            }
            Self::ArrayGlobalSet => {
                func.instruction(&Instruction::GlobalSet(encoding_bases.array_global_idx));
            }
            Self::ArrayTableGet { elem_index } => {
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::TableGet(encoding_bases.array_table_idx));
            }
            Self::ArrayTableSet { elem_index } => {
                // Use array_local_idx (arrayref) to temporarily store the value before table.set.
                func.instruction(&Instruction::LocalSet(encoding_bases.array_local_idx));
                func.instruction(&Instruction::I32Const(elem_index.cast_signed()));
                func.instruction(&Instruction::LocalGet(encoding_bases.array_local_idx));
                func.instruction(&Instruction::TableSet(encoding_bases.array_table_idx));
            }
            Self::ArrayGet { type_index, index } | Self::ArrayGetU { type_index, index } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let typed_local = encoding_bases.typed_local_base + type_index;
                let element = encoding_order
                    .get(usize::try_from(type_index).unwrap())
                    .and_then(|tid| types.type_defs.get(tid))
                    .and_then(|def| match &def.composite_type {
                        CompositeType::Array(at) => Some(&at.element),
                        CompositeType::Struct(_) => None,
                    });

                match element {
                    Some(element) => {
                        // Null-guard: array.get traps on null, so skip if null.
                        // The index is kept mostly in-bounds by fixup.
                        func.instruction(&Instruction::LocalTee(typed_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                        func.instruction(&Instruction::Else);
                        func.instruction(&Instruction::LocalGet(typed_local));
                        func.instruction(&Instruction::I32Const(index.cast_signed()));
                        if element.field_type.is_packed() {
                            if matches!(self, Self::ArrayGetU { .. }) {
                                func.instruction(&Instruction::ArrayGetU(wasm_type));
                            } else {
                                func.instruction(&Instruction::ArrayGetS(wasm_type));
                            }
                        } else {
                            func.instruction(&Instruction::ArrayGet(wasm_type));
                        }
                        // The element value is not tracked on the abstract stack.
                        func.instruction(&Instruction::Drop);
                        func.instruction(&Instruction::End);
                    }
                    None => {
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::ArraySet { type_index, index } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let typed_local = encoding_bases.typed_local_base + type_index;
                let element = encoding_order
                    .get(usize::try_from(type_index).unwrap())
                    .and_then(|tid| types.type_defs.get(tid))
                    .and_then(|def| match &def.composite_type {
                        CompositeType::Array(at) => Some(at.element.clone()),
                        CompositeType::Struct(_) => None,
                    });

                match element {
                    Some(element) if element.mutable => {
                        // Null-guard: array.set traps on null, so skip if null.
                        func.instruction(&Instruction::LocalTee(typed_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                        func.instruction(&Instruction::Else);
                        func.instruction(&Instruction::LocalGet(typed_local));
                        func.instruction(&Instruction::I32Const(index.cast_signed()));
                        element
                            .field_type
                            .emit_default_const(func, type_ids_to_index);
                        func.instruction(&Instruction::ArraySet(wasm_type));
                        func.instruction(&Instruction::End);
                    }
                    // Immutable element or non-array: just drop the operand.
                    _ => {
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::ArrayFill {
                type_index,
                offset,
                len,
            } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let typed_local = encoding_bases.typed_local_base + type_index;
                match array_element(types, encoding_order, type_index) {
                    Some(element) if element.mutable => {
                        func.instruction(&Instruction::LocalTee(typed_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                        func.instruction(&Instruction::Else);
                        func.instruction(&Instruction::LocalGet(typed_local));
                        func.instruction(&Instruction::I32Const(offset.cast_signed()));
                        element
                            .field_type
                            .emit_default_const(func, type_ids_to_index);
                        func.instruction(&Instruction::I32Const(len.cast_signed()));
                        func.instruction(&Instruction::ArrayFill(wasm_type));
                        func.instruction(&Instruction::End);
                    }
                    _ => {
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::ArrayCopy {
                type_index,
                dst_offset,
                src_offset,
                len,
            } => {
                let wasm_type = encoding_bases.struct_type_base + type_index;
                let dst_local = encoding_bases.typed_local_base + type_index;
                let src_local = encoding_bases.typed_local2_base + type_index;
                match array_element(types, encoding_order, type_index) {
                    Some(element) if element.mutable => {
                        func.instruction(&Instruction::LocalSet(src_local));
                        func.instruction(&Instruction::LocalSet(dst_local));
                        func.instruction(&Instruction::LocalGet(dst_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::LocalGet(src_local));
                        func.instruction(&Instruction::RefIsNull);
                        func.instruction(&Instruction::I32Or);
                        func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                        func.instruction(&Instruction::Else);
                        func.instruction(&Instruction::LocalGet(dst_local));
                        func.instruction(&Instruction::I32Const(dst_offset.cast_signed()));
                        func.instruction(&Instruction::LocalGet(src_local));
                        func.instruction(&Instruction::I32Const(src_offset.cast_signed()));
                        func.instruction(&Instruction::I32Const(len.cast_signed()));
                        func.instruction(&Instruction::ArrayCopy {
                            array_type_index_dst: wasm_type,
                            array_type_index_src: wasm_type,
                        });
                        func.instruction(&Instruction::End);
                    }
                    _ => {
                        func.instruction(&Instruction::Drop);
                        func.instruction(&Instruction::Drop);
                    }
                }
            }
            Self::ArrayLen => {
                // array.len traps on null, so guard; the length is not tracked.
                func.instruction(&Instruction::LocalTee(encoding_bases.array_local_idx));
                func.instruction(&Instruction::RefIsNull);
                func.instruction(&Instruction::If(wasm_encoder::BlockType::Empty));
                func.instruction(&Instruction::Else);
                func.instruction(&Instruction::LocalGet(encoding_bases.array_local_idx));
                func.instruction(&Instruction::ArrayLen);
                func.instruction(&Instruction::Drop);
                func.instruction(&Instruction::End);
            }
        }
    }
}
