# Copyright New York University and the in-toto contributors
# SPDX-License-Identifier: Apache-2.0

"""
<Program Name>
  common_args.py

<Author>
  Lukas Puehringer <lukas.puehringer@nyu.edu>

<Started>
  Mar 09, 2018

<Copyright>
  See LICENSE for licensing information.

<Purpose>
  Provides a collection of constants that can be used as `*args` or `**kwargs`
  to argparse.ArgumentParser.add_argument() for cli tools with common
  command line arguments.

  Example Usage:

  ```
  form in_toto.common_args import EXCLUDE_ARGS, EXCLUDE_KWARGS
  parser = argparse.ArgumentParser()
  parser.add_argument(*EXCLUDE_KWARGS, **EXCLUDE_KWARGS)
  ```

"""

import sys

from in_toto.settings import LINK_CMD_EXEC_TIMEOUT

EXCLUDE_ARGS = ["--exclude"]
EXCLUDE_KWARGS = {
    "dest": "exclude_patterns",
    "required": False,
    "metavar": "<pattern>",
    "nargs": "+",
    "help": (
        "path patterns to match paths that should not be recorded as"
        " 'materials' or 'products'. Passed patterns override patterns"
        " defined in environment variables or config files. See Config docs"
        " for details."
    ),
}

BASE_PATH_ARGS = ["--base-path"]
BASE_PATH_KWARGS = {
    "dest": "base_path",
    "required": False,
    "metavar": "<path>",
    "help": (
        "base path for relative paths passed via '--materials' and"
        " '--products'. It is used to locate and record artifacts, and is"
        " not included in the resulting link metadata. Default is the"
        " current working directory."
    ),
}

LSTRIP_PATHS_ARGS = ["--lstrip-paths"]
LSTRIP_PATHS_KWARGS = {
    "dest": "lstrip_paths",
    "required": False,
    "nargs": "+",
    "metavar": "<path>",
    "help": (
        "path prefixes used to left-strip artifact paths before storing"
        " them to the resulting link metadata. If multiple prefixes are"
        " specified, only a single prefix can match the path of any"
        " artifact and that is then left-stripped. All prefixes are checked"
        " to ensure none of them are a left substring of another."
    ),
}

KEY_PASSWORD_ARGS = ["-P", "--password"]
KEY_PASSWORD_KWARGS = {
    "nargs": "?",
    "const": True,
    "metavar": "<password>",
    "help": (
        "password for encrypted key specified with '--signing-key'. Passing '-P'"
        " without <password> opens a prompt. If no password is passed, or"
        " entered on the prompt, the key is treated as unencrypted. (Do "
        " not confuse with '-p/--products'!)"
    ),
}
OPTS_TITLE = "Optional Arguments" if sys.version_info < (3, 10) else "Options"


def parse_password_and_prompt_args(args):
    """Parse -P/--password optional arg (nargs=?, const=True)."""
    # --P was provided without argument (True)
    if args.password is True:
        password = None
        prompt = True
    # --P was not provided (None), or provided with argument (<password>)
    else:
        password = args.password
        prompt = False

    return password, prompt


GPG_ARGS = ["-g", "--gpg"]
GPG_KWARGS = {
    "nargs": "?",
    "const": True,
    "metavar": "<id>",
    "help": (
        "GPG keyid to sign the resulting link metadata.  When '--gpg' is"
        " passed without the keyid, the default GPG key is used. The keyid"
        " prefix is used as an infix for the link metadata filename, i.e."
        " '<name>.<keyid prefix>.link'. Passing one of '--signing-key' or '--gpg'"
        " is required."
    ),
}

GPG_HOME_ARGS = ["--gpg-home"]
GPG_HOME_KWARGS = {
    "dest": "gpg_home",
    "type": str,
    "metavar": "<path>",
    "help": (
        "path to a GPG home directory used to load a GPG key identified"
        " by '--gpg'. If '--gpg-home' is not passed, the default GPG home"
        " directory is used."
    ),
}

SIGNING_KEY_ARGS = ["--signing-key"]
SIGNING_KEY_KWARGS = {
    "type": str,
    "metavar": "<path>",
    "dest": "signing_key",
    "help": (
        "signing key in a standard PKCS8/PEM format. Supported keytypes are"
        " rsa, ed25519, ecdsa (nistp256). Use '--password [<password>]' to pass"
        " a decryption password or toggle a prompt, if the key is encrypted."
    ),
}

VERBOSE_ARGS = ["-v", "--verbose"]
VERBOSE_KWARGS = {
    "dest": "verbose",
    "action": "store_true",
    "help": "show more output",
}

QUIET_ARGS = ["-q", "--quiet"]
QUIET_KWARGS = {
    "dest": "quiet",
    "action": "store_true",
    "help": "suppress all output",
}

METADATA_DIRECTORY_ARGS = ["-d", "--metadata-directory"]
METADATA_DIRECTORY_KWARGS = {
    "required": False,
    "type": str,
    "metavar": "<directory>",
    "help": (
        "path to a directory to dump metadata. If '--metadata-directory'"
        " is not passed, the current working directory is used."
    ),
}

DSSE_ARGS = ["--use-dsse"]
DSSE_KWARGS = {
    "dest": "use_dsse",
    "default": False,
    "action": "store_true",
    "help": ("generate metadata using dsse (experimental)."),
}

RUN_TIMEOUT_ARGS = ["--run-timeout"]
RUN_TIMEOUT_KWARGS = {
    "type": int,
    "dest": "run_timeout",
    "default": LINK_CMD_EXEC_TIMEOUT,
    "help": (
        "integer that represents the max timeout in seconds for the "
        "   in-toto-run command."
        f"   Default is '{LINK_CMD_EXEC_TIMEOUT}' seconds."
    ),
}


def title_case_action_groups(parser):
    """Capitalize the first character of all words in the title of each action
    group of the passed parser.

    This is useful for consistency when using the sphinx argparse extension,
    which title-cases default action groups only.

    """
    for action_group in parser._action_groups:  # noqa: SLF001
        action_group.title = action_group.title.title()


def sort_action_groups(parser, title_order=None):
    """Sort action groups of passed parser by their titles according to the
    passed (or a default) order.

    """
    if title_order is None:
        title_order = [
            "Required Named Arguments",
            "Positional Arguments",
            OPTS_TITLE,
        ]

    action_group_dict = {}
    for action_group in parser._action_groups:  # noqa: SLF001
        action_group_dict[action_group.title] = action_group

    ordered_action_groups = [action_group_dict[title] for title in title_order]

    parser._action_groups = (  # noqa: SLF001
        ordered_action_groups
    )
