[**@lancedb/lancedb**](../README.md) • **Docs**

***

[@lancedb/lancedb](../globals.md) / OpenTableOptions

# Interface: OpenTableOptions

## Properties

### branch?

```ts
optional branch: string;
```

Open the table scoped to this branch instead of the default branch.

Reads and writes on the returned table operate in the branch's context.

***

### ~~indexCacheSize?~~

```ts
optional indexCacheSize: number;
```

Set the size of the index cache, specified as a number of entries

#### Deprecated

Use session-level cache configuration instead.
Create a Session with custom cache sizes and pass it to the connect() function.

The exact meaning of an "entry" will depend on the type of index:
- IVF: there is one entry for each IVF partition
- BTREE: there is one entry for the entire index

This cache applies to the entire opened table, across all indices.
Setting this value higher will increase performance on larger datasets
at the expense of more RAM

***

### storageOptions?

```ts
optional storageOptions: Record<string, string>;
```

Configuration for object storage.

Options already set on the connection will be inherited by the table,
but can be overridden here.

The available options are described at https://docs.lancedb.com/storage/

***

### version?

```ts
optional version: number;
```

Open the table pinned to this version, producing a read-only view.

Composes with [OpenTableOptions.branch](OpenTableOptions.md#branch): when both are set, opens
that branch at the version; otherwise opens `main` at the version. Call
`checkoutLatest` to return to a writable state.
