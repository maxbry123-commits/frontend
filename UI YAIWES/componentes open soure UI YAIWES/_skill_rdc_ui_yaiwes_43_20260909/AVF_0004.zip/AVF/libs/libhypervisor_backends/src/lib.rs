// Copyright 2023, The Android Open Source Project
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! This library provides wrappers around various hypervisor backends.

#![no_std]

extern crate alloc;

mod error;
mod hypervisor;
mod mem;

pub use error::{Error, Result};
pub use hypervisor::{
    get_device_assigner, get_granule_size, get_mem_sharer, get_mmio_guard,
    DeviceAssigningHypervisor, KvmError,
};
