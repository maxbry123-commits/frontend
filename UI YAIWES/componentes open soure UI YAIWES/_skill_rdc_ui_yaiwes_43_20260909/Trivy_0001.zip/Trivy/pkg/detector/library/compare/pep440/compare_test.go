package pep440_test

import (
	"testing"

	"github.com/stretchr/testify/assert"

	dbTypes "github.com/aquasecurity/trivy-db/pkg/types"
	"github.com/aquasecurity/trivy/pkg/detector/library/compare/pep440"
)

func TestPep440Comparer_IsVulnerable(t *testing.T) {
	type args struct {
		currentVersion string
		advisory       dbTypes.Advisory
	}
	tests := []struct {
		name           string
		allowLocalSpec bool
		args           args
		want           bool
	}{
		{
			name: "happy path",
			args: args{
				currentVersion: "1.0.0",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"<=1.0"},
					PatchedVersions:    []string{">=1.1"},
				},
			},
			want: true,
		},
		{
			name: "no patch",
			args: args{
				currentVersion: "1.2.3",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"<=99.999.99999"},
					PatchedVersions:    []string{"<0.0.0"},
				},
			},
			want: true,
		},
		{
			name: "no patch with wildcard",
			args: args{
				currentVersion: "1.2.3",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"*"},
					PatchedVersions:    nil,
				},
			},
			want: true,
		},
		{
			name: "pre-release",
			args: args{
				currentVersion: "1.2.3a1",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"<=1.2.2"},
					PatchedVersions:    []string{">=1.2.2"},
				},
			},
			want: false,
		},
		{
			name: "multiple constraints",
			args: args{
				currentVersion: "2.0.0",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{">=1.7.0 <1.7.16", ">=1.8.0 <1.8.8", ">=2.0.0 <2.0.8", ">=3.0.0b1 <3.0.0b7"},
					PatchedVersions:    []string{">=3.0.0b7", ">=2.0.8 <3.0.0b1", ">=1.8.8 <2.0.0", ">=1.7.16 <1.8.0"},
				},
			},
			want: true,
		},
		{
			name: "exact versions",
			args: args{
				currentVersion: "2.1.0.post1",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"2.1.0.post1", "2.0.0"},
					PatchedVersions:    []string{">=2.1.1"},
				},
			},
			want: true,
		},
		{
			name: "invalid version",
			args: args{
				currentVersion: "1.2..4",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"<1.0.0"},
				},
			},
			want: false,
		},
		{
			name: "invalid constraint",
			args: args{
				currentVersion: "1.2.4",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"!1.0.0"},
				},
			},
			want: false,
		},
		{
			// Without AllowLocalSpecifier, the local segment is stripped from the candidate version,
			// so "4.2.8+sp1" matches "== 4.2.8" and is incorrectly treated as vulnerable.
			name:           "without AllowLocalSpecifier: local segment ignored, version matches base constraint",
			allowLocalSpec: false,
			args: args{
				currentVersion: "4.2.8+sp1",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{"== 4.2.8"},
					PatchedVersions:    []string{"== 4.2.9"},
				},
			},
			want: true,
		},
		{
			// With AllowLocalSpecifier, the local segment is compared strictly,
			// so "4.2.8+sp999" does not fall in ">= sp1, < sp999" and is correctly not vulnerable.
			name:           "with AllowLocalSpecifier: patched version not vulnerable",
			allowLocalSpec: true,
			args: args{
				currentVersion: "4.2.8+sp999",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{">= 4.2.8+sp1, < 4.2.8+sp999"},
					PatchedVersions:    []string{"4.2.8+sp999"},
				},
			},
			want: false,
		},
		{
			name:           "with AllowLocalSpecifier: vulnerable version matched by local range",
			allowLocalSpec: true,
			args: args{
				currentVersion: "4.2.8+sp1",
				advisory: dbTypes.Advisory{
					VulnerableVersions: []string{">= 4.2.8+sp1, < 4.2.8+sp999"},
					PatchedVersions:    []string{"4.2.8+sp999"},
				},
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var c pep440.Comparer
			if tt.allowLocalSpec {
				c = pep440.NewComparer(pep440.AllowLocalSpecifier())
			}
			got := c.IsVulnerable(tt.args.currentVersion, tt.args.advisory)
			assert.Equal(t, tt.want, got)
		})
	}
}
