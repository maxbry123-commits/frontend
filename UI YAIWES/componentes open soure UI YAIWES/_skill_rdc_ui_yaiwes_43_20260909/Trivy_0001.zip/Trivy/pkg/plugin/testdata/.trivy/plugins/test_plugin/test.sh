#!/bin/sh

echo "foo"