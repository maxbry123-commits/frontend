# Reporting

## DefectDojo (Community)
DefectDojo can parse Trivy JSON reports. The parser supports deduplication and auto-close features.

👉 Get it at: <https://github.com/DefectDojo/django-DefectDojo>

## SecObserve (Community)
SecObserve can parse Trivy results as CycloneDX reports and provides an unified overview of vulnerabilities from different sources. Vulnerabilities can be evaluated with manual and rule based assessments.

👉 Get it at: <https://github.com/SecObserve/SecObserve>

## Scan2html (Community)
A Trivy plugin that scans and outputs the results to an interactive html file.

👉 Get it at: <https://github.com/fatihtokus/scan2html>

## SonarQube (Community)
A Trivy plugin that converts JSON report to SonarQube [generic issues format](https://docs.sonarqube.org/9.6/analyzing-source-code/importing-external-issues/generic-issue-import-format/).

👉 Get it at: <https://github.com/umax/trivy-plugin-sonarqube>

## Trivy-Streamlit (Community)
Trivy-Streamlit is a Streamlit application that allows you to quickly parse the results from a Trivy JSON report.

👉 Get it at: <https://github.com/mfreeman451/trivy-streamlit>

## Trivy-Vulnerability-Explorer (Community)

This project is a web application that allows to load a Trivy report in json format and displays the vulnerabilities of a single target in an interactive data table.

👉 Get it at: <https://github.com/dbsystel/trivy-vulnerability-explorer>

## plopsec.com (Community)

This project is a web application designed to help you visualize Trivy image scan reports. It enriches the data with additional exploitability metrics from EPSS, Metasploit, and Exploit-DB, updated daily.

👉 Get it at: <https://plopsec.com> | <https://github.com/pl0psec/plopsec.com>
