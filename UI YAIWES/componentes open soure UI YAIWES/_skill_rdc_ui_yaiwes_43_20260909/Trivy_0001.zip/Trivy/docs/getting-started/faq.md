## FAQ

### How to pronounce the name "Trivy"?

`tri` is pronounced like **tri**gger, `vy` is pronounced like en**vy**.

### Does Trivy support X?

Check out the [Scanning coverage page](../guide/coverage/index.md).

### Is there a paid version of Trivy?

If you liked Trivy, you will love Aqua which builds on top of Trivy to provide even more enhanced capabilities for a complete security management offering.  
You can find a high level comparison table specific to Trivy users [here](../commercial/compare.md).  
In addition check out the <https://aquasec.com> website for more information about our products and services.
If you'd like to contact Aqua or request a demo, please use this form: <https://www.aquasec.com/demo>

### How to generate multiple reports?
See [here](../guide/configuration/reporting.md#converting).

### How to run Trivy under air-gapped environment?
See [here](../guide/advanced/air-gap.md).

### Why `trivy fs` and `trivy repo` does not scan JAR files for vulnerabilities?
See [here](../guide/target/repository.md#rationale).
