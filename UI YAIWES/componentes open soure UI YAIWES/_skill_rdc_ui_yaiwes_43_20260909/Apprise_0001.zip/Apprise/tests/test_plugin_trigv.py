# BSD 2-Clause License
#
# Apprise - Push Notification Library.
# Copyright (c) 2026, Chris Caron <lead2gold@gmail.com>
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

import logging
from unittest import mock

from helpers import AppriseURLTester
import pytest
import requests

import apprise
from apprise.plugins.trigv import NotifyTrigv

logging.disable(logging.CRITICAL)

VALID_API_KEY = "trgv_a1b2c3d4_0123456789abcdef0123456789abcdef"

apprise_url_tests = (
    (
        "trigvs://",
        {
            "instance": TypeError,
        },
    ),
    (
        "trigv://",
        {
            "instance": TypeError,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/general",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/deploys",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigv://{VALID_API_KEY}@trigv-platform.test/general",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigv://{VALID_API_KEY}@trigv-platform.test:8080/general",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/alerts/ops",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/?to=alerts,ops",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/?url=https://example.com",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/?urgency=time_sensitive",
        {
            "instance": NotifyTrigv,
        },
    ),
    (
        "trigvs://not-a-valid-key",
        {
            "instance": TypeError,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}/bad.channel/",
        {
            "instance": TypeError,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}",
        {
            "instance": NotifyTrigv,
            "response": False,
            "requests_response_code": requests.codes.unauthorized,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}",
        {
            "instance": NotifyTrigv,
            "response": False,
            "requests_response_code": requests.codes.unprocessable_entity,
        },
    ),
    (
        f"trigvs://{VALID_API_KEY}",
        {
            "instance": NotifyTrigv,
            "test_requests_exceptions": True,
        },
    ),
)


def test_plugin_trigv_urls():
    """NotifyTrigv() Apprise URLs."""

    AppriseURLTester(tests=apprise_url_tests).run_all()


@mock.patch("requests.post")
def test_plugin_trigv_general(mock_post):
    """NotifyTrigv() General Checks."""

    response = mock.Mock()
    response.content = b'{"event":{"public_id":"evt_test","status":"queued"}}'
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = apprise.Apprise.instantiate(f"trigvs://{VALID_API_KEY}/alerts")
    assert isinstance(obj, NotifyTrigv)
    assert obj.targets == ["alerts"]
    assert len(obj) == 1

    assert (
        obj.notify(
            body="Backup failed",
            title="Cron",
            notify_type=apprise.NotifyType.FAILURE,
        )
        is True
    )

    assert mock_post.call_count == 1
    assert mock_post.call_args_list[0][0][0] == (
        "https://api.trigv.com/api/v1/events"
    )

    headers = mock_post.call_args_list[0][1]["headers"]
    assert headers["Authorization"] == f"Bearer {VALID_API_KEY}"
    assert headers["Content-Type"] == "application/json"

    import json

    payload = json.loads(mock_post.call_args_list[0][1]["data"])
    assert payload["channel"] == "alerts"
    assert payload["title"] == "Cron"
    assert payload["description"] == "Backup failed"
    assert payload["level"] == "error"
    assert payload["delivery_urgency"] == "time_sensitive"


@mock.patch("requests.post")
def test_plugin_trigv_local_host(mock_post):
    """NotifyTrigv() custom hostname for local development."""

    response = mock.Mock()
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = apprise.Apprise.instantiate(
        f"trigv://{VALID_API_KEY}@trigv-platform.test/general"
    )
    assert isinstance(obj, NotifyTrigv)

    assert obj.notify(body="Hello", title="Test") is True
    assert (
        mock_post.call_args_list[0][0][0]
        == "http://trigv-platform.test/api/v1/events"
    )


@mock.patch("requests.post")
def test_plugin_trigv_custom_port(mock_post):
    """NotifyTrigv() custom hostname with an explicit port."""

    response = mock.Mock()
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = apprise.Apprise.instantiate(
        f"trigvs://{VALID_API_KEY}@trigv-platform.test:8443/general"
    )
    assert isinstance(obj, NotifyTrigv)
    assert obj.port == 8443

    assert obj.notify(body="Hello", title="Test") is True
    assert (
        mock_post.call_args_list[0][0][0]
        == "https://trigv-platform.test:8443/api/v1/events"
    )


@mock.patch("requests.post")
def test_plugin_trigv_multiple_channels(mock_post):
    """NotifyTrigv() notifies every channel specified."""

    response = mock.Mock()
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = NotifyTrigv(api_key=VALID_API_KEY, targets=["alerts", "ops"])
    assert obj.targets == ["alerts", "ops"]
    assert len(obj) == 2

    assert obj.send(body="test", title="title") is True
    assert mock_post.call_count == 2

    import json

    channels_notified = {
        json.loads(call[1]["data"])["channel"]
        for call in mock_post.call_args_list
    }
    assert channels_notified == {"alerts", "ops"}


@mock.patch("requests.post")
def test_plugin_trigv_multiple_channels_partial_failure(mock_post):
    """NotifyTrigv() still tries every channel if one of them fails."""

    ok_response = mock.Mock()
    ok_response.status_code = requests.codes.accepted

    error_response = mock.Mock()
    error_response.status_code = requests.codes.internal_server_error
    error_response.content = b""

    mock_post.side_effect = [error_response, ok_response]

    obj = NotifyTrigv(api_key=VALID_API_KEY, targets=["alerts", "ops"])
    assert obj.send(body="test", title="title") is False
    assert mock_post.call_count == 2


@mock.patch("requests.post")
def test_plugin_trigv_multiple_channels_request_exception(mock_post):
    """NotifyTrigv() marks a failure when one channel raises."""

    ok_response = mock.Mock()
    ok_response.status_code = requests.codes.accepted

    mock_post.side_effect = [
        requests.RequestException(),
        ok_response,
    ]

    obj = NotifyTrigv(api_key=VALID_API_KEY, targets=["alerts", "ops"])
    assert obj.send(body="test", title="title") is False
    assert mock_post.call_count == 2


@mock.patch("requests.post")
def test_plugin_trigv_duplicate_success(mock_post):
    """NotifyTrigv() treats HTTP 200 idempotent duplicate as success."""

    response = mock.Mock()
    response.status_code = requests.codes.ok
    mock_post.return_value = response

    obj = NotifyTrigv(api_key=VALID_API_KEY)
    assert obj.send(body="test", title="title") is True


@mock.patch("requests.post")
def test_plugin_trigv_optional_payload_and_priority(mock_post):
    """NotifyTrigv() includes optional fields and maps numeric priority."""

    response = mock.Mock()
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = NotifyTrigv(
        api_key=VALID_API_KEY,
        image_url="https://example.com/image.png",
        event_type="backup.failed",
        priority=1,
    )
    assert obj.send(body="", title="") is True

    import json

    payload = json.loads(mock_post.call_args_list[0][1]["data"])
    assert payload["title"] == obj.app_desc
    assert payload["description"] == obj.app_desc
    assert payload["image_url"] == "https://example.com/image.png"
    assert payload["event_type"] == "backup.failed"
    assert payload["delivery_urgency"] == "time_sensitive"


@mock.patch("requests.post")
def test_plugin_trigv_empty_body_and_invalid_priority(mock_post):
    """NotifyTrigv() omits an empty body and ignores invalid priority."""

    response = mock.Mock()
    response.status_code = requests.codes.accepted
    mock_post.return_value = response

    obj = NotifyTrigv(api_key=VALID_API_KEY, priority="invalid")
    assert obj.send(body="", title="Title", notify_type="unknown") is True

    import json

    payload = json.loads(mock_post.call_args_list[0][1]["data"])
    assert "description" not in payload
    assert payload["level"] == "info"
    assert payload["delivery_urgency"] == "standard"


def test_plugin_trigv_invalid_urgency():
    """NotifyTrigv() rejects unknown urgency."""

    with pytest.raises(TypeError):
        NotifyTrigv(api_key=VALID_API_KEY, urgency="critical")


def test_plugin_trigv_to_alias():
    """NotifyTrigv() parses ?to= into additional targets."""

    parsed = NotifyTrigv.parse_url(
        f"trigvs://{VALID_API_KEY}/alerts/?to=ops,escalation"
    )
    obj = NotifyTrigv(**parsed)
    # parse_list() de-duplicates and sorts every target it is given
    assert obj.targets == ["alerts", "escalation", "ops"]


@mock.patch("requests.post")
def test_plugin_trigv_url_roundtrip(mock_post):
    """NotifyTrigv() url() round-trips optional query parameters."""

    mock_post.return_value = mock.Mock()
    mock_post.return_value.status_code = requests.codes.accepted

    obj = NotifyTrigv(
        api_key=VALID_API_KEY,
        targets="deploys",
        supplemental_url="https://example.com/run/1",
        image_url="https://example.com/image.png",
        urgency="time_sensitive",
        event_type="deploy.completed",
        priority=2,
    )

    generated = obj.url()
    assert "deploys" in generated
    assert "url=" in generated
    assert "image_url=" in generated
    assert "urgency=time_sensitive" in generated
    assert "event_type=deploy.completed" in generated
    assert "priority=2" in generated

    parsed = NotifyTrigv.parse_url(generated)
    obj2 = NotifyTrigv(**parsed)
    assert obj2.targets == ["deploys"]
    assert obj2.supplemental_url == "https://example.com/run/1"
    assert obj2.image_url == "https://example.com/image.png"
    assert obj2.urgency == "time_sensitive"
    assert obj2.event_type == "deploy.completed"
    assert obj2.priority == 2
