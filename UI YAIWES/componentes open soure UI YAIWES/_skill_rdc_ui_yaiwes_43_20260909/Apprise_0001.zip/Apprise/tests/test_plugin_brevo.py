# BSD 2-Clause License
#
# Apprise - Push Notification Library.
# Copyright (c) 2026, Chris Caron <lead2gold@gmail.com>
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

# Disable logging for a cleaner testing output
import logging
import os
from unittest import mock

from helpers import AppriseURLTester
import pytest
import requests

from apprise import Apprise, AppriseAttachment, NotifyType
from apprise.plugins.brevo import NotifyBrevo

logging.disable(logging.CRITICAL)

# Attachment Directory
TEST_VAR_DIR = os.path.join(os.path.dirname(__file__), "var")

# a test UUID we can use
UUID4 = "8b799edf-6f98-4d3a-9be7-2862fb4e5752"

# Our Testing URLs
apprise_url_tests = (
    (
        "brevo://",
        {
            "instance": None,
        },
    ),
    (
        "brevo://:@/",
        {
            "instance": None,
        },
    ),
    (
        "brevo://abcd",
        {
            # Just an broken email (no api key or email)
            "instance": None,
        },
    ),
    (
        "brevo://abcd@host",
        {
            # Just an Email specified, no API Key
            "instance": None,
        },
    ),
    (
        "brevo://invalid-api-key+*-d:user@example.com",
        {
            # An invalid API Key
            "instance": TypeError,
        },
    ),
    (
        ("brevo://abcd:user@example.com/newuser@example.com?reply=%20!"),
        {
            # An invalid Reply-To address
            "instance": TypeError,
        },
    ),
    (
        "brevo://abcd:user@example.com?format=text",
        {
            # No To/Target Address(es) specified; so we sub in the same From
            # address
            "instance": NotifyBrevo,
        },
    ),
    (
        (
            "brevo://abcd:user@example.com/newuser@example.com"
            "?reply=user@example.ca"
        ),
        {
            # A good email
            "instance": NotifyBrevo,
            "force_debug": True,
        },
    ),
    (
        "brevo://abcd:user@example.com/bademailaddress",
        {
            # won't be able to send email
            "instance": NotifyBrevo,
            "notify_response": False,
        },
    ),
    (
        (
            "brevo://abcd:user@example.com/newuser@example.com"
            "?bcc=l2g@nuxref.com"
        ),
        {
            # A good email with Blind Carbon Copy
            "instance": NotifyBrevo,
        },
    ),
    (
        (
            "brevo://abcd:user@example.com/newuser@example.com"
            "?cc=l2g@nuxref.com"
        ),
        {
            # A good email with Carbon Copy
            "instance": NotifyBrevo,
        },
    ),
    (
        (
            "brevo://abcd:user@example.com/newuser@example.com"
            "?to=l2g@nuxref.com"
        ),
        {
            # A good email with Carbon Copy
            "instance": NotifyBrevo,
        },
    ),
    (
        "brevo://abcd:user@example.ca/newuser@example.ca",
        {
            "instance": NotifyBrevo,
            # force a failure
            "response": False,
            "requests_response_code": requests.codes.internal_server_error,
        },
    ),
    (
        "brevo://abcd:user@example.uk/newuser@example.uk",
        {
            "instance": NotifyBrevo,
            # throw a bizzare code forcing us to fail to look it up
            "response": False,
            "requests_response_code": 999,
        },
    ),
    (
        "brevo://abcd:user@example.au/newuser@example.au",
        {
            "instance": NotifyBrevo,
            # Throws a series of i/o exceptions with this flag
            # is set and tests that we gracfully handle them
            "test_requests_exceptions": True,
        },
    ),
)


def test_plugin_brevo_urls():
    """NotifyBrevo() Apprise URLs."""

    # Run our general tests
    AppriseURLTester(tests=apprise_url_tests).run_all()


@mock.patch("requests.get")
@mock.patch("requests.post")
def test_plugin_brevo_edge_cases(mock_post, mock_get):
    """NotifyBrevo() Edge Cases."""

    # no apikey
    with pytest.raises(TypeError):
        NotifyBrevo(apikey=None, from_email="user@example.com")

    # invalid from email
    with pytest.raises(TypeError):
        NotifyBrevo(apikey="abcd", from_email="!invalid")

    # no email
    with pytest.raises(TypeError):
        NotifyBrevo(apikey="abcd", from_email=None)

    # Invalid To email address
    NotifyBrevo(
        apikey="abcd", from_email="user@example.com", targets="!invalid"
    )

    # Test invalid bcc/cc entries mixed with good ones
    assert isinstance(
        NotifyBrevo(
            apikey="abcd",
            from_email="l2g@example.com",
            bcc=("abc@def.com", "!invalid"),
            cc=("abc@test.org", "!invalid"),
        ),
        NotifyBrevo,
    )


@mock.patch("requests.post")
def test_plugin_brevo_attachments(mock_post):
    """NotifyBrevo() Attachments."""

    request = mock.Mock()
    request.status_code = requests.codes.ok

    # Prepare Mock
    mock_post.return_value = request

    path = os.path.join(TEST_VAR_DIR, "apprise-test.gif")
    attach = AppriseAttachment(path)
    obj = Apprise.instantiate("brevo://abcd:user@example.com")
    assert isinstance(obj, NotifyBrevo)
    assert (
        obj.notify(
            body="body",
            title="title",
            notify_type=NotifyType.INFO,
            attach=attach,
        )
        is True
    )

    mock_post.reset_mock()

    # Try again in a use case where we can't access the file
    with mock.patch("os.path.isfile", return_value=False):
        assert (
            obj.notify(
                body="body",
                title="title",
                notify_type=NotifyType.INFO,
                attach=attach,
            )
            is False
        )

    # Try again in a use case where we can't access the file
    with mock.patch("builtins.open", side_effect=OSError):
        assert (
            obj.notify(
                body="body",
                title="title",
                notify_type=NotifyType.INFO,
                attach=attach,
            )
            is False
        )
