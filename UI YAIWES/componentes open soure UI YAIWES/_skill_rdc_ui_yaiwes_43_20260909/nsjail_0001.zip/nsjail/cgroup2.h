/*

   nsjail - cgroup2 namespacing
   -----------------------------------------

   Copyright 2014 Google Inc. All Rights Reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

*/

#ifndef NS_CGROUP2_H
#define NS_CGROUP2_H

#include <stdbool.h>
#include <stddef.h>

#include "nsjail.h"

namespace cgroup2 {

bool initNsFromParent(nsj_t* nsj, pid_t pid);
bool initNs(void);
bool initUser(nsj_t* nsj);
void finishFromParent(nsj_t* nsj, pid_t pid);
bool setup(nsj_t* nsj);
bool detectCgroupv2(nsj_t* nsj);

}  // namespace cgroup2

#endif /* _CGROUP2_H */
