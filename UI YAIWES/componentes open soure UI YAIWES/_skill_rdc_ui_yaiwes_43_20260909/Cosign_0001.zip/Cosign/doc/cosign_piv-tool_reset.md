## cosign piv-tool reset

Reset the hardware token completely

```
cosign piv-tool reset [flags]
```

### Examples

```
  cosign piv-tool reset
```

### Options

```
  -h, --help   help for reset
```

### Options inherited from parent commands

```
  -f, --no-input             skip warnings and confirmations
      --output-file string   log output to a file
  -t, --timeout duration     timeout for commands (default 3m0s)
  -d, --verbose              log debug output
```

### SEE ALSO

* [cosign piv-tool](cosign_piv-tool.md)	 - Provides utilities for managing a hardware token

