## cosign pkcs11-tool list-keys-uris

List URIs of all keys in a PKCS11 token

```
cosign pkcs11-tool list-keys-uris [flags]
```

### Examples

```
  # list key URIs in a specific PKCS11 token slot
  cosign pkcs11-tool list-keys-uris --module-path /usr/lib/libp11kit.so --slot-id 0
```

### Options

```
  -h, --help                 help for list-keys-uris
      --module-path string   absolute path to the PKCS11 module
      --pin string           pin of the PKCS11 slot, uses environment variable COSIGN_PKCS11_PIN if empty
      --slot-id uint         id of the PKCS11 slot, uses 0 if empty
```

### Options inherited from parent commands

```
  -f, --no-input             skip warnings and confirmations
      --output-file string   log output to a file
  -t, --timeout duration     timeout for commands (default 3m0s)
  -d, --verbose              log debug output
```

### SEE ALSO

* [cosign pkcs11-tool](cosign_pkcs11-tool.md)	 - Provides utilities for retrieving information from a PKCS11 token.

