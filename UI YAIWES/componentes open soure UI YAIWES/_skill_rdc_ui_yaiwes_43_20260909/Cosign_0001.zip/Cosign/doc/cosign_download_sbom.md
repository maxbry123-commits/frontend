## cosign download sbom

DEPRECATED: Download SBOMs from the supplied container image

### Synopsis

Download SBOMs from the supplied container image

WARNING: SBOM attachments are deprecated and support will be removed in a Cosign release soon after 2024-02-22 (see https://github.com/sigstore/cosign/issues/2755). Instead, please use SBOM attestations.

```
cosign download sbom [flags]
```

### Examples

```
  cosign download sbom <image uri>
```

### Options

```
      --allow-http-registry           whether to allow using HTTP protocol while connecting to registries. Don't use this for anything but testing
      --allow-insecure-registry       whether to allow insecure connections to registries (e.g., with expired or self-signed TLS certificates). Don't use this for anything but testing
  -h, --help                          help for sbom
      --k8s-keychain                  whether to use the kubernetes keychain instead of the default keychain (supports workload identity).
      --platform string               download SBOM for a specific platform image
      --registry-cacert string        path to the X.509 CA certificate file in PEM format to be used for the connection to the registry
      --registry-client-cert string   path to the X.509 certificate file in PEM format to be used for the connection to the registry
      --registry-client-key string    path to the X.509 private key file in PEM format to be used, together with the 'registry-client-cert' value, for the connection to the registry
      --registry-password string      registry basic auth password
      --registry-server-name string   SAN name to use as the 'ServerName' tls.Config field to verify the mTLS connection to the registry
      --registry-token string         registry bearer auth token
      --registry-username string      registry basic auth username
```

### Options inherited from parent commands

```
      --output-file string   log output to a file
  -t, --timeout duration     timeout for commands (default 3m0s)
  -d, --verbose              log debug output
```

### SEE ALSO

* [cosign download](cosign_download.md)	 - Provides utilities for downloading artifacts and attached artifacts in a registry

