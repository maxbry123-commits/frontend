// Copyright 2022 The Sigstore Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cosign

import (
	"crypto"
	"errors"
	"hash"
	"io"
	"io/fs"
	"os"
)

const (
	DefaultMaxWorkers int = 10
)

func FileExists(filename string) (bool, error) {
	info, err := os.Stat(filename)
	if errors.Is(err, fs.ErrNotExist) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return !info.IsDir(), nil
}

// HashReader hashes while it reads.
type HashReader struct {
	r  io.Reader
	h  hash.Hash
	ch crypto.Hash
}

func NewHashReader(r io.Reader, ch crypto.Hash) HashReader {
	if ch == 0 {
		return HashReader{
			r:  r,
			h:  nil,
			ch: ch,
		}
	}
	h := ch.New()
	return HashReader{
		r:  io.TeeReader(r, h),
		h:  h,
		ch: ch,
	}
}

// Read implements io.Reader.
func (h *HashReader) Read(p []byte) (n int, err error) { return h.r.Read(p) }

// Sum implements hash.Hash.
func (h *HashReader) Sum(p []byte) []byte {
	if h.h == nil {
		return nil
	}
	return h.h.Sum(p)
}

// Reset implements hash.Hash.
func (h *HashReader) Reset() {
	if h.h == nil {
		return
	}
	h.h.Reset()
}

// Size implements hash.Hash.
func (h *HashReader) Size() int {
	if h.h == nil {
		return 0
	}
	return h.h.Size()
}

// BlockSize implements hash.Hash.
func (h *HashReader) BlockSize() int {
	if h.h == nil {
		return 0
	}
	return h.h.BlockSize()
}

// Write implements hash.Hash
func (h *HashReader) Write(p []byte) (int, error) { return 0, errors.New("not implemented") } //nolint: revive

// HashFunc implements cosign.NamedHash
func (h *HashReader) HashFunc() crypto.Hash { return h.ch }
