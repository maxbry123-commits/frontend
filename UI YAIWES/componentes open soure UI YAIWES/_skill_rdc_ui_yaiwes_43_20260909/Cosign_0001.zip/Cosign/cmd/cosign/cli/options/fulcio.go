//
// Copyright 2021 The Sigstore Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package options

import (
	"github.com/spf13/cobra"
)

const DefaultFulcioURL = "https://fulcio.sigstore.dev"

// FulcioOptions is the wrapper for Fulcio related options.
type FulcioOptions struct {
	URL                      string
	AuthFlow                 string
	IdentityToken            string
	InsecureSkipFulcioVerify bool // Deprecated: SCT verification is no longer performed during signing/attestation.
}

var _ Interface = (*FulcioOptions)(nil)

// AddFlags implements Interface
func (o *FulcioOptions) AddFlags(cmd *cobra.Command) {
	// TODO: change this back to api.SigstorePublicServerURL after the v1 migration is complete.
	cmd.Flags().StringVar(&o.URL, "fulcio-url", DefaultFulcioURL,
		"address of sigstore PKI server")
	_ = cmd.Flags().MarkDeprecated("fulcio-url", "please use a signing config to specify a fulcio url; see `cosign signing-config --help`")

	cmd.Flags().StringVar(&o.IdentityToken, "identity-token", "",
		"identity token to use for certificate from fulcio. the token or a path to a file containing the token is accepted.")
	// _ = cmd.MarkFlagFilename("identity-token") // no typical extensions

	cmd.Flags().StringVar(&o.AuthFlow, "fulcio-auth-flow", "",
		"fulcio interactive oauth2 flow to use for certificate from fulcio. Defaults to determining the flow based on the runtime environment. (options) normal|device|token|client_credentials")

	cmd.Flags().BoolVar(&o.InsecureSkipFulcioVerify, "insecure-skip-verify", false,
		"skip verifying fulcio published to the SCT (this should only be used for testing).")
	_ = cmd.Flags().MarkDeprecated("insecure-skip-verify", "SCT verification is no longer performed during signing/attestation.")
}
