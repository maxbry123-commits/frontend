//
// Copyright 2024 The Sigstore Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cli

import (
	"context"

	"github.com/sigstore/cosign/v3/cmd/cosign/cli/bundle"
	"github.com/sigstore/cosign/v3/cmd/cosign/cli/options"
	"github.com/spf13/cobra"
)

func Bundle() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "bundle",
		Short: "Interact with a Sigstore protobuf bundle",
		Long:  "Tools for interacting with a Sigstore protobuf bundle",
	}

	cmd.AddCommand(bundleCreate())
	cmd.AddCommand(bundleUpgrade())
	cmd.AddCommand(bundleInspect())

	return cmd
}

func bundleCreate() *cobra.Command {
	o := &options.BundleCreateOptions{}

	cmd := &cobra.Command{
		Use:   "create",
		Short: "Create a Sigstore protobuf bundle",
		Long:  "Create a Sigstore protobuf bundle by supplying signed material",
		Example: `  # create a bundle from a signature and certificate
  cosign bundle create --artifact <path> --signature <sig> --certificate <cert> --out bundle.sigstore.json

  # create a bundle from an attestation
  cosign bundle create --artifact <path> --attestation <att> --out bundle.sigstore.json`,
		RunE: func(cmd *cobra.Command, _ []string) error {
			bundleCreateCmd := &bundle.CreateCmd{
				Artifact:             o.Artifact,
				AttestationPath:      o.AttestationPath,
				BundlePath:           o.BundlePath,
				CertificatePath:      o.CertificatePath,
				IgnoreTlog:           o.IgnoreTlog,
				KeyRef:               o.KeyRef,
				Out:                  o.Out,
				RekorURL:             o.RekorURL,
				RFC3161TimestampPath: o.RFC3161TimestampPath,
				SignaturePath:        o.SignaturePath,
				Sk:                   o.Sk,
				Slot:                 o.Slot,
			}

			ctx, cancel := context.WithTimeout(cmd.Context(), ro.Timeout)
			defer cancel()

			return bundleCreateCmd.Exec(ctx)
		},
	}

	o.AddFlags(cmd)
	return cmd
}

func bundleUpgrade() *cobra.Command {
	o := &options.BundleUpgradeOptions{}

	cmd := &cobra.Command{
		Use:   "upgrade <bundle>",
		Short: "Upgrade a Sigstore protobuf bundle",
		Long:  "Upgrade a Sigstore Protobuf bundle to the latest version. This command only supports standardized bundles.",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			bundleUpgradeCmd := &bundle.UpgradeCmd{
				Out:      o.Out,
				RekorURL: o.RekorURL,
			}

			ctx, cancel := context.WithTimeout(cmd.Context(), ro.Timeout)
			defer cancel()

			return bundleUpgradeCmd.Exec(ctx, args[0])
		},
	}

	o.AddFlags(cmd)
	return cmd
}

func bundleInspect() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "inspect BUNDLE",
		Short: "Inspect a Sigstore protobuf bundle",
		Args:  cobra.ExactArgs(1),
		RunE: func(_ *cobra.Command, args []string) error {
			bundleInspectCmd := &bundle.InspectCmd{
				BundlePath: args[0],
			}

			return bundleInspectCmd.Exec()
		},
	}

	return cmd
}
