//
// Copyright 2021 The Sigstore Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cli

import (
	"flag"

	"github.com/sigstore/cosign/v3/cmd/cosign/cli/options"
	"github.com/sigstore/cosign/v3/cmd/cosign/cli/triangulate"
	"github.com/spf13/cobra"
)

func Triangulate() *cobra.Command {
	o := &options.TriangulateOptions{}

	cmd := &cobra.Command{
		Deprecated:       "triangulate will be removed in v4.0.0 (see https://github.com/sigstore/cosign/issues/4696). Instead, please use `oras discover` or `cosign tree` to show referring artifacts",
		Use:              "triangulate",
		Short:            "Outputs the located cosign image reference. This is the location where cosign stores the specified artifact type",
		Example:          "  cosign triangulate <IMAGE>",
		PersistentPreRun: options.BindViper,
		RunE: func(cmd *cobra.Command, args []string) error {
			if len(args) != 1 {
				return flag.ErrHelp
			}
			return triangulate.MungeCmd(cmd.Context(), o.Registry, args[0], o.Type)
		},
	}

	o.AddFlags(cmd)
	return cmd
}
