// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package timestamp

import (
	"math"
	"time"
)

// FromTime returns a new millisecond timestamp from a time.
func FromTime(t time.Time) int64 {
	return t.UnixMilli()
}

// Time returns a new time.Time object from a millisecond timestamp, in UTC.
func Time(ts int64) time.Time {
	return time.UnixMilli(ts).UTC()
}

// FromFloatSeconds returns a millisecond timestamp from float seconds.
func FromFloatSeconds(ts float64) int64 {
	return int64(math.Round(ts * 1000))
}
