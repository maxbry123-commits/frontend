#include <gtest/gtest.h>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <collection_manager.h>
#include "collection.h"

class CollectionFilteringTest : public ::testing::Test {
protected:
    std::string state_dir_path = "/tmp/typesense_test/collection_filtering";
    Store *store;
    CollectionManager & collectionManager = CollectionManager::get_instance();
    std::atomic<bool> quit = false;

    std::vector<std::string> query_fields;
    std::vector<sort_by> sort_fields;

    void setupCollection() {
        LOG(INFO) << "Truncating and creating: " << state_dir_path;
        system(("rm -rf "+state_dir_path+" && mkdir -p "+state_dir_path).c_str());

        store = new Store(state_dir_path);
        collectionManager.init(store, 1.0, "auth_key", quit);
        collectionManager.load(8, 1000);
    }

    virtual void SetUp() {
        setupCollection();
    }

    virtual void TearDown() {
        collectionManager.dispose();
        delete store;
    }
};

TEST_F(CollectionFilteringTest, FilterOnTextFields) {
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {
            field("name", field_types::STRING, false),
            field("age", field_types::INT32, false),
            field("years", field_types::INT32_ARRAY, false),
            field("tags", field_types::STRING_ARRAY, true)
    };

    std::vector<sort_by> sort_fields = { sort_by("age", "DESC") };

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if(coll_array_fields == nullptr) {
        coll_array_fields = collectionManager.create_collection("coll_array_fields", 4, fields, "age").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_array_fields->add(json_line);
    }

    infile.close();

    query_fields = {"name"};
    std::vector<std::string> facets;
    nlohmann::json results = coll_array_fields->search("Jeremy", query_fields, "tags: gold", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    std::vector<std::string> ids = {"4", "0", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "tags : fine PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "tags : foobarbaz", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // using just ":", filtering should return documents that contain ALL tokens in the filter expression
    results = coll_array_fields->search("Jeremy", query_fields, "tags : PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    // no documents contain "white"
    results = coll_array_fields->search("Jeremy", query_fields, "tags : WHITE", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // no documents contain both "white" and "platinum", so
    results = coll_array_fields->search("Jeremy", query_fields, "tags : WHITE PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // with exact match operator (:=) partial matches are not allowed
    results = coll_array_fields->search("Jeremy", query_fields, "tags:= PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "tags : bronze", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"4", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // search with a list of tags, also testing extra padding of space
    results = coll_array_fields->search("Jeremy", query_fields, "tags: [bronze,   silver]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"3", "4", "0", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // need to be exact matches
    results = coll_array_fields->search("Jeremy", query_fields, "tags: bronze", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    // when comparators are used, they should be ignored
    results = coll_array_fields->search("Jeremy", query_fields, "tags:<bronze", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "tags:<=BRONZE", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "tags:>BRONZE", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    // bad filter value (empty)
    auto res_op = coll_array_fields->search("Jeremy", query_fields, "tags:=", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `tags`: Filter value cannot be empty.", res_op.error());

    collectionManager.drop_collection("coll_array_fields");

    auto schema_json =
            R"({
                "name": "title",
                "fields": [
                    {"name": "title", "type": "string"},
                    {"name": "titles", "type": "string[]"}
                ]
            })"_json;

    std::vector<nlohmann::json> documents = {
            R"({
                "title": "foo bar baz",
                "titles": []
            })"_json,
            R"({
                "title": "foo bar baz",
                "titles": ["foo bar baz"]
            })"_json,
            R"({
                "title": "foo bar baz",
                "titles": ["bar foo baz", "foo bar baz"]
            })"_json,
            R"({
                "title": "bar foo baz",
                "titles": ["bar foo baz"]
            })"_json,
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "title"},
            {"q", "foo"},
            {"query_by", "title"},
            {"filter_by", "title:= foo bar baz"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());
    ASSERT_EQ(3, res_obj["hits"].size());
    ASSERT_EQ("2", res_obj["hits"][0]["document"].at("id"));
    ASSERT_EQ("1", res_obj["hits"][1]["document"].at("id"));
    ASSERT_EQ("0", res_obj["hits"][2]["document"].at("id"));

    req_params = {
            {"collection", "title"},
            {"q", "foo"},
            {"query_by", "titles"},
            {"filter_by", "titles:= foo bar baz"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("2", res_obj["hits"][0]["document"].at("id"));
    ASSERT_EQ("1", res_obj["hits"][1]["document"].at("id"));
}

TEST_F(CollectionFilteringTest, FilterByExactPhraseMatch) {
    Collection *coll;
    std::vector<field> fields = {
            field("text", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_phrase", 1, fields, "").get();

    coll->add(R"({"id": "1", "text": "Lewis Hamilton has won multiple Formula One World Championships."})");
    coll->add(R"({"id": "2", "text": "The scientist created a new formula, and this was just one of many groundbreaking discoveries in the lab."})");
    coll->add(R"({"id": "3", "text": "Formula One is a popular sport."})");

    auto results = coll->search("*", {"text"}, "text:\"Formula One\"", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_EQ("3", results["hits"][0]["document"]["id"].get<std::string>());
    ASSERT_EQ("1", results["hits"][1]["document"]["id"].get<std::string>());
}

TEST_F(CollectionFilteringTest, FilterByNegatedExactPhraseMatch) {
    Collection *coll;
    std::vector<field> fields = {
            field("text", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_negated_phrase", 1, fields, "").get();

    coll->add(R"({"id": "1", "text": "this is a test"})");
    coll->add(R"({"id": "2", "text": "this is not a test"})");
    coll->add(R"({"id": "3", "text": "another test case"})");

    auto results = coll->search("*", {"text"}, "text:!=\"this is a test\"", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    std::set<std::string> expected_ids = {"2", "3"};
    std::set<std::string> actual_ids;
    for(const auto& hit : results["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, FilterByExactPhraseMatchInArray) {
    Collection *coll;
    std::vector<field> fields = {
            field("tags", field_types::STRING_ARRAY, true)
    };
    coll = collectionManager.create_collection("coll_phrase_array", 1, fields, "").get();

    coll->add(R"({"id": "1", "tags": ["new york", "travel"]})");
    coll->add(R"({"id": "2", "tags": ["new", "york", "travel"]})");
    coll->add(R"({"id": "3", "tags": ["paris", "travel"]})");
    coll->add(R"({"id": "4", "tags": ["new york", "paris"]})");

    auto results = coll->search("*", {"tags"}, "tags:[\"new york\", paris]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["found"].get<size_t>());

    std::set<std::string> expected_ids = {"1", "3", "4"};
    std::set<std::string> actual_ids;
    for(const auto& hit : results["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, FilterByNegatedExactPhraseMatchInArray) {
    Collection *coll;
    std::vector<field> fields = {
            field("tags", field_types::STRING_ARRAY, true)
    };
    coll = collectionManager.create_collection("coll_phrase_array_negated", 1, fields, "").get();

    coll->add(R"({"id": "1", "tags": ["new york", "travel"]})");
    coll->add(R"({"id": "2", "tags": ["new", "york", "travel"]})");
    coll->add(R"({"id": "3", "tags": ["paris", "travel"]})");
    coll->add(R"({"id": "4", "tags": ["new york", "paris"]})");

    auto results = coll->search("*", {"tags"}, "tags:!=[\"new york\", paris]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());

    std::set<std::string> expected_ids = {"2"};
    std::set<std::string> actual_ids;
    for(const auto& hit : results["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, LazyEvaluationOfFilterBy) {
    Collection *coll;
    std::vector<field> fields = {
            field("field", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_lazy", 1, fields, "").get();

    coll->add(R"({"id": "1", "field": "foo"})");
    coll->add(R"({"id": "2", "field": "foo bar baz"})");
    coll->add(R"({"id": "3", "field": "foo bar"})");
    coll->add(R"({"id": "4", "field": "bar"})");
    coll->add(R"({"id": "5", "field": "foo bar baz"})");
    coll->add(R"({"id": "6", "field": "baz"})");
    coll->add(R"({"id": "7", "field": "foo baz bar"})");
    coll->add(R"({"id": "8", "field": "foo bar baz"})");

    std::map<std::string, std::string> req_params = {
            {"collection", "coll_lazy"},
            {"q", "foo"},
            {"query_by", "field"},
            {"filter_by", "field:\"foo bar baz\""},
            {"enable_lazy_filter", "true"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());

    std::set<std::string> expected_ids = {"2", "5", "8"};
    std::set<std::string> actual_ids;
    for(const auto& hit : res_obj["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, LazyEvaluationOfFilterByNegated) {
    Collection *coll;
    std::vector<field> fields = {
            field("field", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_lazy_negated", 1, fields, "").get();

    coll->add(R"({"id": "1", "field": "foo"})");
    coll->add(R"({"id": "2", "field": "foo bar baz"})");
    coll->add(R"({"id": "3", "field": "foo bar"})");
    coll->add(R"({"id": "4", "field": "bar"})");
    coll->add(R"({"id": "5", "field": "foo bar baz"})");
    coll->add(R"({"id": "6", "field": "baz"})");
    coll->add(R"({"id": "7", "field": "foo baz bar"})");
    coll->add(R"({"id": "8", "field": "foo bar baz"})");

    std::map<std::string, std::string> req_params = {
            {"collection", "coll_lazy_negated"},
            {"q", "foo"},
            {"query_by", "field"},
            {"filter_by", "field:!=\"foo bar baz\""},
            {"enable_lazy_filter", "true"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());

    std::set<std::string> expected_ids = {"1", "3", "7"};
    std::set<std::string> actual_ids;
    for(const auto& hit : res_obj["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, LazyEvaluationOfFilterByInArray) {
    Collection *coll;
    std::vector<field> fields = {
            field("field", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_lazy", 1, fields, "").get();

    coll->add(R"({"id": "1", "field": "foo"})");
    coll->add(R"({"id": "2", "field": "foo bar baz"})");
    coll->add(R"({"id": "3", "field": "foo bar"})");
    coll->add(R"({"id": "4", "field": "bar"})");
    coll->add(R"({"id": "5", "field": "foo bar baz"})");
    coll->add(R"({"id": "6", "field": "baz"})");
    coll->add(R"({"id": "7", "field": "foo baz bar"})");
    coll->add(R"({"id": "8", "field": "foo bar baz"})");

    std::map<std::string, std::string> req_params = {
            {"collection", "coll_lazy"},
            {"q", "foo"},
            {"query_by", "field"},
            {"filter_by", "field:[foo, bar, baz, \"foo bar baz\"]"},
            {"enable_lazy_filter", "true"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, res_obj["found"].get<size_t>());

    std::set<std::string> expected_ids = {"1", "2", "5", "8"};
    std::set<std::string> actual_ids;
    for(const auto& hit : res_obj["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, LazyEvaluationOfFilterByInArrayNegated) {
    Collection *coll;
    std::vector<field> fields = {
            field("field", field_types::STRING, false)
    };
    coll = collectionManager.create_collection("coll_lazy_array_negated", 1, fields, "").get();

    coll->add(R"({"id": "1", "field": "foo"})");
    coll->add(R"({"id": "2", "field": "foo bar baz"})");
    coll->add(R"({"id": "3", "field": "foo bar"})");
    coll->add(R"({"id": "4", "field": "bar"})");
    coll->add(R"({"id": "5", "field": "foo bar baz"})");
    coll->add(R"({"id": "6", "field": "baz"})");
    coll->add(R"({"id": "7", "field": "foo baz bar"})");
    coll->add(R"({"id": "8", "field": "foo bar baz"})");

    std::map<std::string, std::string> req_params = {
            {"collection", "coll_lazy_array_negated"},
            {"q", "foo"},
            {"query_by", "field"},
            {"filter_by", "field:!=[foo, bar, baz, \"foo bar baz\"]"},
            {"enable_lazy_filter", "true"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());

    std::set<std::string> expected_ids = {"3", "7"};
    std::set<std::string> actual_ids;
    for(const auto& hit : res_obj["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);
}

TEST_F(CollectionFilteringTest, FacetFieldStringFiltering) {
    Collection *coll_str;

    std::ifstream infile(std::string(ROOT_DIR)+"test/multi_field_documents.jsonl");
    std::vector<field> fields = {
            field("title", field_types::STRING, false),
            field("starring", field_types::STRING, true),
            field("cast", field_types::STRING_ARRAY, false),
            field("points", field_types::INT32, false)
    };

    std::vector<sort_by> sort_fields = { sort_by("points", "DESC") };

    coll_str = collectionManager.get_collection("coll_str").get();
    if(coll_str == nullptr) {
        coll_str = collectionManager.create_collection("coll_str", 1, fields, "points").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        nlohmann::json document = nlohmann::json::parse(json_line);
        coll_str->add(document.dump());
    }

    infile.close();

    query_fields = {"title"};
    std::vector<std::string> facets;

    // exact filter on string field must fail when single token is used
    facets.clear();
    facets.emplace_back("starring");
    auto results = coll_str->search("*", query_fields, "starring:= samuel", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
    ASSERT_EQ(0, results["found"].get<size_t>());

    // multiple tokens but with a typo on one of them
    results = coll_str->search("*", query_fields, "starring:= ssamuel l. Jackson", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
    ASSERT_EQ(0, results["found"].get<size_t>());

    // same should succeed when verbatim filter is made
    results = coll_str->search("*", query_fields, "starring:= samuel l. Jackson", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ(2, results["found"].get<size_t>());

    // with backticks
    results = coll_str->search("*", query_fields, "starring:= `samuel l. Jackson`", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ(2, results["found"].get<size_t>());

    // contains filter with a single token should work as well
    results = coll_str->search("*", query_fields, "starring: jackson", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll_str->search("*", query_fields, "starring: samuel", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ(2, results["found"].get<size_t>());

    // contains when only 1 token so should not match
    results = coll_str->search("*", query_fields, "starring: samuel johnson", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll_str");
}

TEST_F(CollectionFilteringTest, FacetFieldStringArrayFiltering) {
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {field("name", field_types::STRING, false),
                                 field("name_facet", field_types::STRING, true),
                                 field("age", field_types::INT32, true),
                                 field("years", field_types::INT32_ARRAY, true),
                                 field("rating", field_types::FLOAT, true),
                                 field("timestamps", field_types::INT64_ARRAY, true),
                                 field("tags", field_types::STRING_ARRAY, true)};

    std::vector<sort_by> sort_fields = { sort_by("age", "DESC") };

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if(coll_array_fields == nullptr) {
        coll_array_fields = collectionManager.create_collection("coll_array_fields", 1, fields, "age").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        nlohmann::json document = nlohmann::json::parse(json_line);
        document["name_facet"] = document["name"];
        const std::string & patched_json_line = document.dump();
        coll_array_fields->add(patched_json_line);
    }

    infile.close();

    query_fields = {"name"};
    std::vector<std::string> facets = {"tags"};

    // facet with filter on string array field must fail when exact token is used
    facets.clear();
    facets.push_back("tags");
    auto results = coll_array_fields->search("Jeremy", query_fields, "tags:= PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
    ASSERT_EQ(0, results["found"].get<size_t>());

    results = coll_array_fields->search("Jeremy", query_fields, "tags:= FINE", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "tags:= FFINE PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // partial token filter should be made without "=" operator
    results = coll_array_fields->search("Jeremy", query_fields, "tags: PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ(1, results["found"].get<size_t>());

    results = coll_array_fields->search("Jeremy", query_fields, "tags: FINE", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ(1, results["found"].get<size_t>());

    // to make tokens match facet value exactly, use "=" operator
    results = coll_array_fields->search("Jeremy", query_fields, "tags:= FINE PLATINUM", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ(1, results["found"].get<size_t>());

    // allow exact filter on non-faceted field
    results = coll_array_fields->search("Jeremy", query_fields, "name:= Jeremy Howard", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());
    ASSERT_EQ(5, results["found"].get<size_t>());

    // multi match exact query (OR condition)
    results = coll_array_fields->search("Jeremy", query_fields, "tags:= [Gold, bronze]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());
    ASSERT_EQ(3, results["found"].get<size_t>());

    results = coll_array_fields->search("Jeremy", query_fields, "tags:= [Gold, bronze, fine PLATINUM]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());
    ASSERT_EQ(4, results["found"].get<size_t>());

    // single array multi match
    results = coll_array_fields->search("Jeremy", query_fields, "tags:= [fine PLATINUM]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ(1, results["found"].get<size_t>());

    collectionManager.drop_collection("coll_array_fields");
}

TEST_F(CollectionFilteringTest, FilterOnTextFieldWithColon) {
    Collection *coll1;

    std::vector<field> fields = {field("url", field_types::STRING, true),
                                 field("points", field_types::INT32, false)};

    std::vector<sort_by> sort_fields = { sort_by("points", "DESC") };

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 4, fields, "points").get();
    }

    nlohmann::json doc1;
    doc1["id"] = "1";
    doc1["url"] = "https://example.com/1";
    doc1["points"] = 1;

    coll1->add(doc1.dump());

    query_fields = {"url"};
    std::vector<std::string> facets;

    auto res = coll1->search("*", query_fields, "url:= https://example.com/1", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, res["hits"].size());
    ASSERT_STREQ("1", res["hits"][0]["document"]["id"].get<std::string>().c_str());

    res = coll1->search("*", query_fields, "url: https://example.com/1", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, res["hits"].size());
    ASSERT_STREQ("1", res["hits"][0]["document"]["id"].get<std::string>().c_str());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, HandleBadlyFormedFilterQuery) {
    // should not crash when filter query is malformed!
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {field("name", field_types::STRING, false), field("age", field_types::INT32, false),
                                 field("years", field_types::INT32_ARRAY, false),
                                 field("timestamps", field_types::INT64_ARRAY, false),
                                 field("tags", field_types::STRING_ARRAY, true)};

    std::vector<sort_by> sort_fields = { sort_by("age", "DESC") };

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if(coll_array_fields == nullptr) {
        coll_array_fields = collectionManager.create_collection("coll_array_fields", 4, fields, "age").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_array_fields->add(json_line);
    }

    infile.close();

    query_fields = {"name"};
    std::vector<std::string> facets;

    // when filter field does not exist in the schema
    nlohmann::json results = coll_array_fields->search("Jeremy", query_fields, "tagzz: gold", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // compound filter expression containing an unknown field
    results = coll_array_fields->search("Jeremy", query_fields,
               "(age:>0 ||  timestamps:> 0) || tagzz: gold", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // unbalanced paranthesis
    results = coll_array_fields->search("Jeremy", query_fields,
                                        "(age:>0 ||  timestamps:> 0) || ", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // searching using a string for a numeric field
    results = coll_array_fields->search("Jeremy", query_fields, "age: abcdef", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // searching using a string for a numeric array field
    results = coll_array_fields->search("Jeremy", query_fields, "timestamps: abcdef", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // malformed k:v syntax
    results = coll_array_fields->search("Jeremy", query_fields, "timestamps abcdef", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // just spaces - must be treated as empty filter
    results = coll_array_fields->search("Jeremy", query_fields, "  ", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    // wrapping number with quotes
    results = coll_array_fields->search("Jeremy", query_fields, "age: '21'", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // empty value for a numerical filter field
    auto res_op = coll_array_fields->search("Jeremy", query_fields, "age:", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `age`: Numerical field has an invalid comparator.", res_op.error());

    // empty value for string filter field
    res_op = coll_array_fields->search("Jeremy", query_fields, "tags:", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `tags`: Filter value cannot be empty.", res_op.error());

    res_op = coll_array_fields->search("Jeremy", query_fields, "tags:= ", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `tags`: Filter value cannot be empty.", res_op.error());

    collectionManager.drop_collection("coll_array_fields");
}

TEST_F(CollectionFilteringTest, FilterAndQueryFieldRestrictions) {
    Collection *coll_mul_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/multi_field_documents.jsonl");
    std::vector<field> fields = {
        field("title", field_types::STRING, false),
        field("starring", field_types::STRING, false),
        field("cast", field_types::STRING_ARRAY, true),
        field("points", field_types::INT32, false)
    };

    coll_mul_fields = collectionManager.get_collection("coll_mul_fields").get();
    if(coll_mul_fields == nullptr) {
        coll_mul_fields = collectionManager.create_collection("coll_mul_fields", 4, fields, "points").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_mul_fields->add(json_line);
    }

    infile.close();

    std::vector<std::string> facets;

    // query shall be allowed on faceted text fields as well
    query_fields = {"cast"};
    Option<nlohmann::json> result_op =
            coll_mul_fields->search("anton", query_fields, "", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_TRUE(result_op.ok());

    nlohmann::json results = result_op.get();
    ASSERT_EQ(1, results["hits"].size());
    std::string solo_id = results["hits"].at(0)["document"]["id"];
    ASSERT_STREQ("14", solo_id.c_str());

    // filtering on string field should be possible
    query_fields = {"title"};
    result_op = coll_mul_fields->search("captain", query_fields, "starring: Samuel L. Jackson", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(true, result_op.ok());
    results = result_op.get();
    ASSERT_EQ(1, results["hits"].size());
    solo_id = results["hits"].at(0)["document"]["id"];
    ASSERT_STREQ("6", solo_id.c_str());

    // filtering on facet field should be possible (supports partial word search but without typo tolerance)
    query_fields = {"title"};
    result_op = coll_mul_fields->search("*", query_fields, "cast: chris", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(true, result_op.ok());
    results = result_op.get();
    ASSERT_EQ(4, results["hits"].size());

    // bad query string
    result_op = coll_mul_fields->search("captain", query_fields, "BLAH", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_STREQ("Could not parse the filter query.", result_op.error().c_str());

    // missing field
    result_op = coll_mul_fields->search("captain", query_fields, "age: 100", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_STREQ("Could not find a filter field named `age` in the schema.", result_op.error().c_str());

    // bad filter value type
    result_op = coll_mul_fields->search("captain", query_fields, "points: \"100\"", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_STREQ("Error with filter field `points`: Numerical field has an invalid comparator.", result_op.error().c_str());

    result_op = coll_mul_fields->search("captain", query_fields, "points:<= foo", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_FALSE(result_op.ok());
    ASSERT_EQ("Error with filter field `points`: Not an int32.", result_op.error());

    // bad filter value type - equaling float on an integer field
    result_op = coll_mul_fields->search("captain", query_fields, "points: 100.34", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_STREQ("Error with filter field `points`: Not an int32.", result_op.error().c_str());

    // bad filter value type - less than float on an integer field
    result_op = coll_mul_fields->search("captain", query_fields, "points: <100.0", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_STREQ("Error with filter field `points`: Not an int32.", result_op.error().c_str());

    // when an int32 field is queried with a 64-bit number
    result_op = coll_mul_fields->search("captain", query_fields, "points: <2230070399", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());
    ASSERT_EQ("Error with filter field `points`: `2230070399` exceeds the range of an int32.", result_op.error());

    result_op = coll_mul_fields->search("captain", query_fields, "points:<= 9223372036854775808", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_FALSE(result_op.ok());
    ASSERT_EQ("Error with filter field `points`: `9223372036854775808` exceeds the range of an int32.", result_op.error());

    // using a string filter value against an integer field
    result_op = coll_mul_fields->search("captain", query_fields, "points: <sdsdfsdf", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());

    // large negative number
    result_op = coll_mul_fields->search("captain", query_fields, "points: >-3230070399", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(false, result_op.ok());

    // but should allow small negative number
    result_op = coll_mul_fields->search("captain", query_fields, "points: >-3230", facets, sort_fields, {0}, 10, 1,
                                        FREQUENCY, {false});
    ASSERT_EQ(true, result_op.ok());

    collectionManager.drop_collection("coll_mul_fields");
}

TEST_F(CollectionFilteringTest, FilterOnNumericFields) {
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {
            field("name", field_types::STRING, false),
            field("rating", field_types::FLOAT, false),
            field("age", field_types::INT32, false),
            field("years", field_types::INT32_ARRAY, false),
            field("timestamps", field_types::INT64_ARRAY, false),
            field("tags", field_types::STRING_ARRAY, true)
    };

    std::vector<sort_by> sort_fields = { sort_by("age", "DESC") };

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if(coll_array_fields == nullptr) {
        // ensure that default_sorting_field is a non-array numerical field
        auto coll_op = collectionManager.create_collection("coll_array_fields", 4, fields, "years");
        ASSERT_EQ(false, coll_op.ok());
        ASSERT_STREQ("Default sorting field `years` is not a sortable type.", coll_op.error().c_str());

        // let's try again properly
        coll_op = collectionManager.create_collection("coll_array_fields", 4, fields, "age");
        coll_array_fields = coll_op.get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_array_fields->add(json_line);
    }

    infile.close();

    // Plain search with no filters - results should be sorted by rank fields
    query_fields = {"name"};
    std::vector<std::string> facets;
    nlohmann::json results = coll_array_fields->search("Jeremy", query_fields, "", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    std::vector<std::string> ids = {"3", "1", "4", "0", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // Searching on an int32 field
    results = coll_array_fields->search("Jeremy", query_fields, "age:>24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"3", "1", "4"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "age:>=24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "age:24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    // alternative `:=` syntax
    results = coll_array_fields->search("Jeremy", query_fields, "age:=24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "age:= 24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    // Searching a number against an int32 array field
    results = coll_array_fields->search("Jeremy", query_fields, "years:>2002", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"1", "0", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "years:<1989", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    ids = {"3"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // not equals
    results = coll_array_fields->search("Jeremy", query_fields, "age:!= 24", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"3", "1", "4", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "age:!= 0", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    ids = {"3", "1", "4", "0", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // multiple filters
    results = coll_array_fields->search("Jeremy", query_fields, "years:<2005 && years:>1987", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    ids = {"4"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // multiple search values (works like SQL's IN operator) against a single int field
    results = coll_array_fields->search("Jeremy", query_fields, "age:[21, 24, 63]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"3", "0", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // alternative `:=` syntax
    results = coll_array_fields->search("Jeremy", query_fields, "age:= [21, 24, 63]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    // individual comparators can still be applied.
    results = coll_array_fields->search("Jeremy", query_fields, "age: [!=21, >30]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"3", "1", "4", "0"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // negate multiple search values (works like SQL's NOT IN) against a single int field
    results = coll_array_fields->search("Jeremy", query_fields, "age:!= [21, 24, 63]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"1", "4"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // individual comparators can still be applied.
    results = coll_array_fields->search("Jeremy", query_fields, "age: != [<30, >60]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"1", "4"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // multiple search values against an int32 array field - also use extra padding between symbols
    results = coll_array_fields->search("Jeremy", query_fields, "years : [ 2015, 1985 , 1999]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"3", "1", "4", "0"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // searching on an int64 array field - also ensure that padded space causes no issues
    results = coll_array_fields->search("Jeremy", query_fields, "timestamps : > 475205222", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"1", "4", "0", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // range based filter
    results = coll_array_fields->search("Jeremy", query_fields, "age: 21..32", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"4", "0", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "age: 0 .. 100", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    results = coll_array_fields->search("Jeremy", query_fields, "age: [21..24, 40..65]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"3", "1", "0", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "rating: 7.812 .. 9.999", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"1", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_array_fields->search("Jeremy", query_fields, "rating: [7.812 .. 9.999, 1.05 .. 1.09]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    // when filters don't match any record, no results should be returned
    results = coll_array_fields->search("Jeremy", query_fields, "timestamps:>1591091288061", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    testing_not_equals_bug = true;
    results = coll_array_fields->search("Jeremy", query_fields, "age:!= [21, 24, 63, 44, 32]", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll_array_fields");

    auto schema_json =
            R"({
                "name": "Products",
                "fields": [
                    {"name": "quantity", "type": "int32", "range_index": true}
                ]
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "quantity": 20
            })"_json,
            R"({
                "quantity": 45
            })"_json
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "Products"},
            {"q", "*"},
            {"filter_by", "quantity: !=[20, 45]"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"]);
}

TEST_F(CollectionFilteringTest, FilterOnFloatFields) {
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {
            field("name", field_types::STRING, false),
            field("age", field_types::INT32, false),
            field("top_3", field_types::FLOAT_ARRAY, false),
            field("rating", field_types::FLOAT, false)
    };
    std::vector<sort_by> sort_fields_desc = { sort_by("rating", "DESC") };
    std::vector<sort_by> sort_fields_asc = { sort_by("rating", "ASC") };

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if(coll_array_fields == nullptr) {
        coll_array_fields = collectionManager.create_collection("coll_array_fields", 4, fields, "age").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        auto add_op = coll_array_fields->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }

    infile.close();

    // Plain search with no filters - results should be sorted by rating field DESC
    query_fields = {"name"};
    std::vector<std::string> facets;
    nlohmann::json results = coll_array_fields->search("Jeremy", query_fields, "", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    std::vector<std::string> ids = {"1", "2", "4", "0", "3"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // Plain search with no filters - results should be sorted by rating field ASC
    results = coll_array_fields->search("Jeremy", query_fields, "", facets, sort_fields_asc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    ids = {"3", "0", "4", "2", "1"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str()); //?
    }

    results = coll_array_fields->search("Jeremy", query_fields, "rating:!=0", facets, sort_fields_asc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"0", "4", "2", "1"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str()); //?
    }

    // Searching on a float field, sorted desc by rating
    results = coll_array_fields->search("Jeremy", query_fields, "rating:>0.0", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"1", "2", "4", "0"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // Searching a float against an float array field
    results = coll_array_fields->search("Jeremy", query_fields, "top_3:>7.8", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"1", "2"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // multiple filters
    results = coll_array_fields->search("Jeremy", query_fields, "top_3:>7.8 && rating:>7.9", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    ids = {"1"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // multiple search values (works like SQL's IN operator) against a single float field
    results = coll_array_fields->search("Jeremy", query_fields, "rating:[1.09, 7.812]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"2", "0"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // negate multiple search values (works like SQL's NOT IN operator) against a single float field
    results = coll_array_fields->search("Jeremy", query_fields, "rating:!= [1.09, 7.812]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"1", "4", "3"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // individual comparators can still be applied.
    results = coll_array_fields->search("Jeremy", query_fields, "rating: != [<5.4, >9]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"2", "4"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_array_fields->search("Jeremy", query_fields, "rating: [!= 1]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    ids = {"1", "2", "4", "0", "3"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // multiple search values against a float array field - also use extra padding between symbols
    results = coll_array_fields->search("Jeremy", query_fields, "top_3 : [ 5.431, 0.001 , 7.812, 11.992]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"2", "4", "0"};
    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // when filters don't match any record, no results should be returned
    auto results_op = coll_array_fields->search("Jeremy", query_fields, "rating:<-2.78", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_TRUE(results_op.ok());
    results = results_op.get();
    ASSERT_EQ(0, results["hits"].size());

    // rank tokens by default sorting field
    results_op = coll_array_fields->search("j", query_fields, "", facets, sort_fields_desc, {0}, 10, 1, MAX_SCORE, {true});
    ASSERT_TRUE(results_op.ok());
    results = results_op.get();
    ASSERT_EQ(5, results["hits"].size());

    ids = {"1", "2", "4", "0", "3"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    testing_not_equals_bug = true;
    results = coll_array_fields->search("Jeremy", query_fields, "rating:!= [1.09, 7.812, 9.999, 0.0, 5.5]", facets, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll_array_fields");

    auto schema_json =
            R"({
                "name": "Products",
                "fields": [
                    {"name": "price", "type": "float", "range_index": true}
                ]
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "price": 9.99
            })"_json,
            R"({
                "price": 15.80
            })"_json
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "Products"},
            {"q", "*"},
            {"filter_by", "price: !=[15.8, 9.99]"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"]);
}

TEST_F(CollectionFilteringTest, FilterOnNegativeNumericalFields) {
    Collection *coll1;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("int32_field", field_types::INT32, false),
                                 field("int64_field", field_types::INT64, false),
                                 field("float_field", field_types::FLOAT, false)};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "int32_field").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"Title 1", "-100", "5000000", "-10.45124"},
        {"Title 2", "100", "-1000000", "0.45124"},
        {"Title 3", "-200", "3000000", "-0.45124"},
        {"Title 4", "150", "10000000", "1.45124"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = std::to_string(i);
        doc["title"] = records[i][0];
        doc["int32_field"] = std::stoi(records[i][1]);
        doc["int64_field"] = std::stoll(records[i][2]);
        doc["float_field"] = std::stof(records[i][3]);

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    auto results = coll1->search("*", {}, "int32_field:<0", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());
    ASSERT_EQ("2", results["hits"][1]["document"]["id"].get<std::string>());

    results = coll1->search("*", {}, "int64_field:<0", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {}, "float_field:<0", {}, {sort_by("float_field", "desc")}, {0}, 10, 1, FREQUENCY,
                            {true}, 10).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());
    ASSERT_EQ("0", results["hits"][1]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, ComparatorsOnMultiValuedNumericalField) {
    Collection *coll_array_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::vector<field> fields = {
            field("name", field_types::STRING, false),
            field("age", field_types::INT32, false),
            field("top_3", field_types::FLOAT_ARRAY, false),
            field("rating", field_types::FLOAT, false)
    };

    std::vector<sort_by> sort_fields_desc = {sort_by("rating", "DESC")};

    coll_array_fields = collectionManager.get_collection("coll_array_fields").get();
    if (coll_array_fields == nullptr) {
        coll_array_fields = collectionManager.create_collection("coll_array_fields", 4, fields, "age").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        auto add_op = coll_array_fields->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }

    infile.close();

    query_fields = {"name"};
    std::vector<std::string> facets;
    nlohmann::json results = coll_array_fields->search("Jeremy", query_fields, "age: [24, >32]",
            facets, sort_fields_desc, {0}, 10, 1,FREQUENCY, {false}).get();

    ASSERT_EQ(3, results["hits"].size());

    std::vector<std::string> ids = {"1", "0", "3"};

    for (size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // with <= and >=

    results = coll_array_fields->search("Jeremy", query_fields, "age: [<=24, >=44]",
                                        facets, sort_fields_desc, {0}, 10, 1,FREQUENCY, {false}).get();

    ASSERT_EQ(4, results["hits"].size());

    ids = {"1", "2", "0", "3"};

    for (size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    collectionManager.drop_collection("coll_array_fields");
}

TEST_F(CollectionFilteringTest, FilteringWithPrefixSearch) {
    Collection *coll1;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("points", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "points").get();
    }

    std::vector<std::vector<std::string>> records = {
            {"elephant"}, {"emerald"}, {"effective"}, {"esther"}, {"eagle"},
            {"empty"}, {"elite"}, {"example"}, {"elated"}, {"end"},
            {"ear"}, {"eager"}, {"earmark"}, {"envelop"}, {"excess"},
            {"ember"}, {"earth"}, {"envoy"}, {"emerge"}, {"emigrant"},
            {"envision"}, {"envy"}, {"envisage"}, {"executive"}, {"end"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = std::to_string(i);
        doc["title"] = records[i][0];
        doc["points"] = i;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    // pick a location close to only the Sacre Coeur
    auto res_op = coll1->search("e",
                                {"title"}, "points: 23",
                                {}, {}, {0}, 10, 1, FREQUENCY, {true});

    auto results = res_op.get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());

    ASSERT_STREQ("23", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, NumericalFilteringWithAnd) {
    Collection *coll1;

    std::vector<field> fields = {field("company_name", field_types::STRING, false),
                                 field("num_employees", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "num_employees").get();
    }

    std::vector<std::vector<std::string>> records = {
            {"123", "Company 1", "50"},
            {"125", "Company 2", "150"},
            {"127", "Company 3", "250"},
            {"129", "Stark Industries 4", "500"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = records[i][0];
        doc["company_name"] = records[i][1];
        doc["num_employees"] = std::stoi(records[i][2]);

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    std::vector<sort_by> sort_fields = { sort_by("num_employees", "ASC") };

    auto results = coll1->search("*",
                                {}, "num_employees:>=100 && num_employees:<=300",
                                {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_EQ(2, results["hits"].size());

    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][1]["document"]["id"].get<std::string>().c_str());

    // when filter number is well below all values
    results = coll1->search("*",
                                 {}, "num_employees:>=100 && num_employees:<=10",
                                 {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    // check boundaries
    results = coll1->search("*",
                            {}, "num_employees:>=150 && num_employees:<=250",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][1]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*",
                            {}, "num_employees:>150 && num_employees:<250",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());


    results = coll1->search("*",
                            {}, "num_employees:>50 && num_employees:<250",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    // extreme boundaries

    results = coll1->search("*",
                            {}, "num_employees:>50 && num_employees:<=500",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("129", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*",
                            {}, "num_employees:>=50 && num_employees:<500",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("125", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    // no match
    results = coll1->search("*",
                            {}, "num_employees:>3000 && num_employees:<10",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, FilteringViaDocumentIds) {
    Collection *coll1;

    std::vector<field> fields = {field("company_name", field_types::STRING, false),
                                 field("num_employees", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "num_employees").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"123", "Company 1", "50"},
        {"125", "Company 2", "150"},
        {"127", "Company 3", "250"},
        {"129", "Stark Industries 4", "500"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = records[i][0];
        doc["company_name"] = records[i][1];
        doc["num_employees"] = std::stoi(records[i][2]);

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    std::vector<sort_by> sort_fields = { sort_by("num_employees", "ASC") };

    auto results = coll1->search("*",
                                 {}, "id: 123",
                                 {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*",
                            {}, "id: != 123",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_EQ(3, results["hits"].size());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("129", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    // single ID with backtick

    results = coll1->search("*",
                            {}, "id: `123`",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    // single ID with condition
    results = coll1->search("*",
                            {}, "id: 125 && num_employees: 150",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    // multiple IDs
    results = coll1->search("*",
                            {}, "id: [123, 125, 127, 129] && num_employees: <300",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_EQ(3, results["hits"].size());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("125", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    // multiple IDs with exact equals operator with IDs not being ordered
    results = coll1->search("*",
                            {}, "id:= [129, 123, 127, 125] && num_employees: <300",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_EQ(3, results["hits"].size());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("125", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    // multiple IDs with exact equals operator and backticks
    results = coll1->search("*",
                            {}, "id:= [`123`, `125`, `127`, `129`] && num_employees: <300",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_EQ(3, results["hits"].size());
    ASSERT_STREQ("123", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("125", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*",
                           {}, "id:!= [123,125] && num_employees: <300",
                           {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_STREQ("127", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*",
                           {}, "id:![123,125] && num_employees: <300",
                           {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_STREQ("127", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    // empty id list not allowed
    auto res_op = coll1->search("*", {}, "id:=", {}, sort_fields, {0}, 10, 1, FREQUENCY, {true});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `id`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {}, "id:= ", {}, sort_fields, {0}, 10, 1, FREQUENCY, {true});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `id`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {}, "id: ", {}, sort_fields, {0}, 10, 1, FREQUENCY, {true});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `id`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {}, "id: ``", {}, sort_fields, {0}, 10, 1, FREQUENCY, {true});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `id`: Filter value cannot be empty.", res_op.error());

    // when no IDs exist
    results = coll1->search("*",
                            {}, "id: [1000] && num_employees: <300",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    results = coll1->search("*",
                            {}, "id: 1000",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    // match all IDs
    results = coll1->search("*",
                            {}, "id: *",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());

    results = coll1->search("*",
                            {}, "id:= [*]",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());

    // match no IDs
    results = coll1->search("*",
                            {}, "id: != *",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    results = coll1->search("*",
                            {}, "id: != [*]",
                            {}, sort_fields, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, NumericalFilteringWithArray) {
    Collection *coll1;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("prices", field_types::INT32_ARRAY, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if (coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"1", "T Shirt 1", "1", "2", "3"},
        {"2", "T Shirt 2", "1", "2", "3"},
        {"3", "T Shirt 3", "1", "2", "3"},
        {"4", "T Shirt 4", "1", "1", "1"},
    };

    for (size_t i = 0; i < records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = records[i][0];
        doc["title"] = records[i][1];

        std::vector<int32_t> prices;
        for(size_t j = 2; j <= 4; j++) {
            prices.push_back(std::stoi(records[i][j]));
        }

        doc["prices"] = prices;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    // check equals on a repeating price
    auto results = coll1->search("*",
                                 {}, "prices:1",
                                 {}, {}, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());
    ASSERT_EQ(4, results["hits"].size());

    // check ranges

    results = coll1->search("*",
                            {}, "prices:>=1",
                            {}, {}, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());
    ASSERT_EQ(4, results["hits"].size());

    results = coll1->search("*",
                            {}, "prices:>=2",
                            {}, {}, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(3, results["found"].get<size_t>());
    ASSERT_EQ(3, results["hits"].size());

    results = coll1->search("*",
                            {}, "prices:<4",
                            {}, {}, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());
    ASSERT_EQ(4, results["hits"].size());

    results = coll1->search("*",
                            {}, "prices:<=2",
                            {}, {}, {0}, 10, 1, FREQUENCY, {true}).get();

    ASSERT_EQ(4, results["found"].get<size_t>());
    ASSERT_EQ(4, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, NegationOperatorBasics) {
    Collection *coll1;

    std::vector<field> fields = {
            field("title", field_types::STRING, false),
            field("artist", field_types::STRING, false),
            field("points", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 2, fields, "points").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"Taylor Swift Karaoke: reputation", "Taylor Swift"},
        {"Beat it", "Michael Jackson"},
        {"Style", "Taylor Swift"},
        {"Thriller", "Michael Joseph Jackson"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = std::to_string(i);
        doc["title"] = records[i][0];
        doc["artist"] = records[i][1];
        doc["points"] = i;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    auto results = coll1->search("*", {"artist"}, "artist:!=Michael Jackson", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();

    ASSERT_EQ(3, results["found"].get<size_t>());

    ASSERT_STREQ("3", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("2", results["hits"][1]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("0", results["hits"][2]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"artist"}, "artist:!= Michael Jackson && points: >0", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_STREQ("3", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("2", results["hits"][1]["document"]["id"].get<std::string>().c_str());

    // negation operation on multiple values

    results = coll1->search("*", {"artist"}, "artist:!= [Michael Jackson, Taylor Swift]", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("3", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    // when no such value exists: should return all results
    results = coll1->search("*", {"artist"}, "artist:!=Foobar", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(4, results["found"].get<size_t>());

    results = coll1->search("*", {"artist"}, "artist:! Jackson", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(2, results["found"]);
    ASSERT_EQ("2", results["hits"][0]["document"]["id"]);
    ASSERT_EQ("0", results["hits"][1]["document"]["id"]);

    results = coll1->search("*", {"artist"}, "artist:![Swift, Jack]", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(2, results["found"]);
    ASSERT_EQ("3", results["hits"][0]["document"]["id"]);
    ASSERT_EQ("1", results["hits"][1]["document"]["id"]);

    results = coll1->search("*", {"artist"}, "artist:![Swift, Jackson]", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(0, results["found"]);

    results = coll1->search("*", {"artist"}, "artist:!=[]", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10).get();
    ASSERT_EQ(4, results["found"]);

    // empty value (bad filtering)
    auto res_op = coll1->search("*", {"artist"}, "artist:!=", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10);
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `artist`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {"artist"}, "artist:!= ", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10);
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `artist`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {"artist"}, "artist:!=``", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10);
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `artist`: Filter value cannot be empty.", res_op.error());

    res_op = coll1->search("*", {"artist"}, "artist:!=[`foo`, ``]", {}, {}, {0}, 10, 1, FREQUENCY, {true}, 10);
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `artist`: Filter value cannot be empty.", res_op.error());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, FilterStringsWithComma) {
    Collection *coll1;

    std::vector<field> fields = {field("place", field_types::STRING, true),
                                 field("state", field_types::STRING, false),
                                 field("points", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "points").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"St. John's Cathedral, Denver, Colorado", "Colorado"},
        {"Crater Lake National Park, Oregon", "Oregon"},
        {"St. Patrick's Cathedral, Manhattan", "New York"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = std::to_string(i);
        doc["place"] = records[i][0];
        doc["state"] = records[i][1];
        doc["points"] = i;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    auto results = coll1->search("*", {"place"}, "place:= St. John's Cathedral, Denver, Colorado", {}, {}, {0}, 10, 1,
                                 FREQUENCY, {true}, 10).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("0", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"place"}, "place:= `St. John's Cathedral, Denver, Colorado`", {}, {}, {0}, 10, 1,
                            FREQUENCY, {true}, 10).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("0", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"place"}, "place:= [`St. John's Cathedral, Denver, Colorado`]", {}, {}, {0}, 10, 1,
                            FREQUENCY, {true}, 10).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("0", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"place"}, "place:= [`St. John's Cathedral, Denver, Colorado`, `St. Patrick's Cathedral, Manhattan`]", {}, {}, {0}, 10, 1,
                            FREQUENCY, {true}, 10).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_STREQ("2", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("0", results["hits"][1]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"place"}, "place: [`Cathedral, Denver, Colorado`]", {}, {}, {0}, 10, 1,
                            FREQUENCY, {true}, 10).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_STREQ("0", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    results = coll1->search("*", {"place"}, "place: []", {}, {}, {0}, 10, 1,
                            FREQUENCY, {true}, 10).get();

    ASSERT_EQ(0, results["found"].get<size_t>());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, NumericalRangeFilter) {
    std::vector<field> fields = {field("company", field_types::STRING, true),
                                 field("num_employees", field_types::INT32, false),};

    Collection* coll1 = collectionManager.create_collection("coll1", 1, fields, "num_employees").get();

    std::vector<std::vector<std::string>> records = {
        {"123", "Company 1", "50"},
        {"125", "Company 2", "150"},
        {"127", "Company 3", "250"},
        {"129", "Stark Industries 4", "500"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = records[i][0];
        doc["company"] = records[i][1];
        doc["num_employees"] = std::stoi(records[i][2]);

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    std::vector<sort_by> sort_fields = { sort_by("num_employees", "ASC") };

    auto results = coll1->search("*", {}, "num_employees:>=100 && num_employees:<=300", {}, sort_fields, {0}, 10, 1,
                                 FREQUENCY, {true}, 10).get();

    ASSERT_EQ(2, results["found"].get<size_t>());
    ASSERT_STREQ("125", results["hits"][0]["document"]["id"].get<std::string>().c_str());
    ASSERT_STREQ("127", results["hits"][1]["document"]["id"].get<std::string>().c_str());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, RangeFilterOnTimestamp) {
    std::vector<field> fields = {field("ts", field_types::INT64, false)};

    Collection* coll1 = collectionManager.create_collection(
            "coll1", 1, fields, "", 0, "", {}, {"."}
    ).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["ts"] = 1646092800000;

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["ts"] = 1648771199000;

    nlohmann::json doc3;
    doc3["id"] = "2";
    doc3["ts"] = 1647111199000;

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());
    ASSERT_TRUE(coll1->add(doc3.dump()).ok());

    auto results = coll1->search("*", {},"ts:[1646092800000..1648771199000]", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();

    ASSERT_EQ(3, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, QueryBoolFields) {
    Collection *coll_bool;

    std::ifstream infile(std::string(ROOT_DIR)+"test/bool_documents.jsonl");
    std::vector<field> fields = {
            field("popular", field_types::BOOL, false),
            field("title", field_types::STRING, false),
            field("rating", field_types::FLOAT, false),
            field("bool_array", field_types::BOOL_ARRAY, false),
    };

    std::vector<sort_by> sort_fields = { sort_by("popular", "DESC"), sort_by("rating", "DESC") };

    coll_bool = collectionManager.get_collection("coll_bool").get();
    if(coll_bool == nullptr) {
        coll_bool = collectionManager.create_collection("coll_bool", 1, fields, "rating").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_bool->add(json_line);
    }

    infile.close();

    // Plain search with no filters - results should be sorted correctly
    query_fields = {"title"};
    std::vector<std::string> facets;
    nlohmann::json results = coll_bool->search("the", query_fields, "", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    std::vector<std::string> ids = {"1", "3", "4", "9", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // Searching on a bool field
    results = coll_bool->search("the", query_fields, "popular:true", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"1", "3", "4"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll_bool->search("*", query_fields, "popular:true", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(7, results["hits"].size());

    ids = {"1", "0", "3", "5", "6", "7", "4"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    // alternative `:=` syntax
    results = coll_bool->search("the", query_fields, "popular:=true", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    results = coll_bool->search("the", query_fields, "popular:false", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    results = coll_bool->search("the", query_fields, "popular:= false", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"9", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // searching against a bool array field

    // should be able to filter with an array of boolean values
    Option<nlohmann::json> res_op = coll_bool->search("the", query_fields, "bool_array:[true, false]", facets,
                                                      sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_TRUE(res_op.ok());
    results = res_op.get();

    ASSERT_EQ(5, results["hits"].size());

    results = coll_bool->search("the", query_fields, "bool_array: true", facets, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());
    ids = {"1", "4", "9", "2"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // should be able to search using array with a single element boolean value

    results = coll_bool->search("the", query_fields, "bool_array:[true]", facets,
                                 sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();

    ASSERT_EQ(4, results["hits"].size());

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    // not equals on bool field

    results = coll_bool->search("the", query_fields, "popular:!= true", facets,
                             sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();

    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ("9", results["hits"][0]["document"]["id"].get<std::string>());
    ASSERT_EQ("2", results["hits"][1]["document"]["id"].get<std::string>());

    // not equals on bool array field
    results = coll_bool->search("the", query_fields, "bool_array:!= [true]", facets,
                                sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();

    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("3", results["hits"][0]["document"]["id"].get<std::string>());

    // empty filter value
    res_op = coll_bool->search("the", query_fields, "bool_array:=", facets,
                                    sort_fields, {0}, 10, 1, FREQUENCY, {false});

    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ("Error with filter field `bool_array`: Filter value cannot be empty.", res_op.error());

    testing_not_equals_bug = true;
    results = coll_bool->search("the", query_fields, "popular: !=[true, false]", facets,
                                sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();

    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll_bool");
}

TEST_F(CollectionFilteringTest, FilteringWithTokenSeparators) {
    std::vector<field> fields = {field("code", field_types::STRING, true)};

    Collection* coll1 = collectionManager.create_collection(
        "coll1", 1, fields, "", 0, "", {}, {"."}
    ).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["code"] = "7318.15";

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());

    auto results = coll1->search("*", {},"code:=7318.15", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();

    ASSERT_EQ(1, results["hits"].size());

    results = coll1->search("*", {},"code:=`7318.15`", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();

    ASSERT_EQ(1, results["hits"].size());

    collectionManager.drop_collection("coll1");

    Collection* coll2 = collectionManager.create_collection(
            "coll2", 1, fields, "", 0, "", {"."}, {}
    ).get();

    doc1["id"] = "0";
    doc1["code"] = "7318.15";

    ASSERT_TRUE(coll2->add(doc1.dump()).ok());

    results = coll2->search("*", {},"code:=7318.15", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();

    ASSERT_EQ(1, results["hits"].size());

    collectionManager.drop_collection("coll2");
}

TEST_F(CollectionFilteringTest, ExactFilteringSingleQueryTerm) {
    std::vector<field> fields = {field("name", field_types::STRING, false),
                                 field("tags", field_types::STRING_ARRAY, false)};

    Collection* coll1 = collectionManager.create_collection(
        "coll1", 1, fields, "", 0, "", {}, {"."}
    ).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["name"] = "AT&T GoPhone";
    doc1["tags"] = {"AT&T GoPhone"};

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["name"] = "AT&T";
    doc2["tags"] = {"AT&T"};

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());

    auto results = coll1->search("*", {},"name:=AT&T", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {},"tags:=AT&T", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    nlohmann::json doc3;
    doc3["id"] = "2";
    doc3["name"] = "Phone";
    doc3["tags"] = {"Samsung Phone", "Phone"};

    ASSERT_TRUE(coll1->add(doc3.dump()).ok());

    results = coll1->search("*", {},"tags:=Phone", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, ExactFilteringRepeatingTokensSingularField) {
    std::vector<field> fields = {field("name", field_types::STRING, false)};

    Collection* coll1 = collectionManager.create_collection(
        "coll1", 1, fields, "", 0, "", {}, {"."}
    ).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["name"] = "Cardiology - Interventional Cardiology";

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["name"] = "Cardiology - Interventional";

    nlohmann::json doc3;
    doc3["id"] = "2";
    doc3["name"] = "Cardiology - Interventional Cardiology Department";

    nlohmann::json doc4;
    doc4["id"] = "3";
    doc4["name"] = "Interventional Cardiology - Interventional Cardiology";

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());
    ASSERT_TRUE(coll1->add(doc3.dump()).ok());
    ASSERT_TRUE(coll1->add(doc4.dump()).ok());

    auto results = coll1->search("*", {},"name:=Cardiology - Interventional Cardiology", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {},"name:=Cardiology - Interventional", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {},"name:=Interventional Cardiology", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll1->search("*", {},"name:=Cardiology", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, ExactFilteringRepeatingTokensArrayField) {
    std::vector<field> fields = {field("name", field_types::STRING_ARRAY, false)};

    Collection* coll1 = collectionManager.create_collection(
        "coll1", 1, fields, "", 0, "", {}, {"."}
    ).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["name"] = {"Cardiology - Interventional Cardiology"};

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["name"] = {"Cardiology - Interventional"};

    nlohmann::json doc3;
    doc3["id"] = "2";
    doc3["name"] = {"Cardiology - Interventional Cardiology Department"};

    nlohmann::json doc4;
    doc4["id"] = "3";
    doc4["name"] = {"Interventional Cardiology - Interventional Cardiology"};

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());
    ASSERT_TRUE(coll1->add(doc3.dump()).ok());
    ASSERT_TRUE(coll1->add(doc4.dump()).ok());

    auto results = coll1->search("*", {},"name:=Cardiology - Interventional Cardiology", {}, {}, {0}, 10,
                                 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {},"name:=Cardiology - Interventional", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll1->search("*", {},"name:=Interventional Cardiology", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll1->search("*", {},"name:=Cardiology", {}, {}, {0}, 10,
                            1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, ExcludeMultipleTokens) {
    Collection *coll1;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("points", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "points").get();
    }

    std::vector<std::vector<std::string>> records = {
        {"alpha"},
        {"TXBT0eiYnFhkJHqz02Wv0PWN5hp1"},
        {"3u7RtEn5S9fcnizoUojWUwW23Yf2"},
        {"HpPALvzDDVc3zMmlAAUySwp8Ir33"},
        {"9oF2qhYI8sdBa2xJSerfmntpvBr2"},
        {"5fAnLlld5obG4vhhNIbIeoHe1uB2"},
        {"4OlIYKbzwIUoAOYy6dfDzCREezg1"},
        {"4JK1BvoqCuTeMwEZorlKj8hnSl02"},
        {"3tQBmRH0AQPEWyoKcDNYJyIxQQe2"},
        {"3Mvl5HZgNwQkHykAqL77oMfo8DW2"},
        {"3Ipnw5JATpYFyCcdUKTBhCicjoH3"},
        {"2rizUF2ntNSUVpaXwPdHmSBB6C63"},
        {"2kMHFOUQhAQK9cQbFNoXGpcAFVD2"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;
        doc["id"] = std::to_string(i);
        doc["title"] = records[i][0];
        doc["points"] = i;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    auto results = coll1->search(
            "-TXBT0eiYnFhkJHqz02Wv0PWN5hp1 -3u7RtEn5S9fcnizoUojWUwW23Yf2 -HpPALvzDDVc3zMmlAAUySwp8Ir33 "
            "-9oF2qhYI8sdBa2xJSerfmntpvBr2 -5fAnLlld5obG4vhhNIbIeoHe1uB2 -4OlIYKbzwIUoAOYy6dfDzCREezg1 "
            "-4JK1BvoqCuTeMwEZorlKj8hnSl02 -3tQBmRH0AQPEWyoKcDNYJyIxQQe2 -3Mvl5HZgNwQkHykAqL77oMfo8DW2 "
            "-3Ipnw5JATpYFyCcdUKTBhCicjoH3 -2rizUF2ntNSUVpaXwPdHmSBB6C63 -2kMHFOUQhAQK9cQbFNoXGpcAFVD2",
            {"title"}, "",
            {}, {}, {0}, 10, 1, FREQUENCY).get();

    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ(1, results["hits"].size());

    ASSERT_STREQ("0", results["hits"][0]["document"]["id"].get<std::string>().c_str());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, FilteringAfterUpsertOnArrayWithTokenSeparators) {
    std::vector<field> fields = {field("name", field_types::STRING, false),
                                 field("tags", field_types::STRING_ARRAY, false),
                                 field("tag", field_types::STRING, false)};

    Collection* coll1 = collectionManager.create_collection("coll1", 1, fields, "", 0, "", {}, {"-"}).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["name"] = "david";
    doc1["tags"] = {"alpha-beta-gamma", "foo-bar-baz"};
    doc1["tag"] = "foo-bar-baz";

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["name"] = "david";
    doc2["tags"] = {"alpha-gamma-beta", "bar-foo-baz"};
    doc2["tag"] = "alpha-beta";

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());

    auto results = coll1->search("david", {"name"},"tags:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    // upsert with "foo-bar-baz" removed
    doc1["tags"] = {"alpha-beta-gamma"};
    coll1->add(doc1.dump(), UPSERT);

    results = coll1->search("david", {"name"},"tags:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll1->search("david", {"name"},"tags:=[bar-foo-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    // repeat for singular string field: upsert with "foo-bar-baz" removed
    doc1["tag"] = "alpha-beta-gamma";
    coll1->add(doc1.dump(), UPSERT);

    results = coll1->search("david", {"name"},"tag:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, FilteringAfterUpsertOnArrayWithSymbolsToIndex) {
    std::vector<field> fields = {field("name", field_types::STRING, false),
                                 field("tags", field_types::STRING_ARRAY, false),
                                 field("tag", field_types::STRING, false)};

    auto coll1 = collectionManager.create_collection("coll1", 1, fields, "", 0, "", {"-"}, {}).get();

    nlohmann::json doc1;
    doc1["id"] = "0";
    doc1["name"] = "david";
    doc1["tags"] = {"alpha-beta-gamma", "foo-bar-baz"};
    doc1["tag"] = "foo-bar-baz";

    nlohmann::json doc2;
    doc2["id"] = "1";
    doc2["name"] = "david";
    doc2["tags"] = {"alpha-gamma-beta", "bar-foo-baz"};
    doc2["tag"] = "alpha-beta";

    ASSERT_TRUE(coll1->add(doc1.dump()).ok());
    ASSERT_TRUE(coll1->add(doc2.dump()).ok());

    auto results = coll1->search("david", {"name"},"tags:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    // upsert with "foo-bar-baz" removed
    doc1["tags"] = {"alpha-beta-gamma"};
    coll1->add(doc1.dump(), UPSERT);

    results = coll1->search("david", {"name"},"tags:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll1->search("david", {"name"},"tags:=[bar-foo-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    // repeat for singular string field: upsert with "foo-bar-baz" removed
    doc1["tag"] = "alpha-beta-gamma";
    coll1->add(doc1.dump(), UPSERT);

    results = coll1->search("david", {"name"},"tag:=[foo-bar-baz]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, ComplexFilterQuery) {
    nlohmann::json schema_json =
            R"({
                "name": "ComplexFilterQueryCollection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "age", "type": "int32"},
                    {"name": "years", "type": "int32[]"},
                    {"name": "rating", "type": "float"},
                    {"name": "tags", "type": "string[]"}
                ]
            })"_json;

    auto op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::string json_line;
    while (std::getline(infile, json_line)) {
        auto add_op = coll->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }
    infile.close();

    std::vector<sort_by> sort_fields_desc = {sort_by("rating", "DESC")};
    nlohmann::json results = coll->search("Jeremy", {"name"}, "(rating:>=0 && years:>2000) && age:>50",
                                          {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    results = coll->search("*", {"name"}, "(age:>50 && rating:>5) || years:<2000",
                                          {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    results = coll->search("Jeremy", {"name"}, "(age:>50 || rating:>5) && years:<2000",
                                          {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    std::vector<std::string> ids = {"4", "3"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll->search("Jeremy", {"name"}, "(age:<50 && rating:10) || (years:>2000 && rating:<5)",
                                          {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    ids = {"0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    results = coll->search("Jeremy", {"name"}, "years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))",
                           {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    ids = {"2"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    std::string extreme_filter = "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5))) ||"
                                 "(years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5)))";

    auto search_op = coll->search("Jeremy", {"name"}, extreme_filter,
                                  {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_TRUE(search_op.ok());
    ASSERT_EQ(1, search_op.get()["hits"].size());

    extreme_filter += "|| (years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5)))";
    search_op = coll->search("Jeremy", {"name"}, extreme_filter,
                             {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("`filter_by` has too many operations. Maximum allowed: 100. Use `--filter-by-max-ops` command line "
              "argument to customize this value.", search_op.error());

    collectionManager.dispose();
    delete store;

    store = new Store(state_dir_path);
    collectionManager.init(store, 1.0, "auth_key", quit, 109); // Re-initialize with 109 filter operations allowed.
    auto load_op = collectionManager.load(8, 1000);

    if(!load_op.ok()) {
        LOG(ERROR) << load_op.error();
    }
    ASSERT_TRUE(load_op.ok());

    auto coll2 = collectionManager.get_collection_unsafe("ComplexFilterQueryCollection");
    search_op = coll2->search("Jeremy", {"name"}, extreme_filter,
                                  {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_TRUE(search_op.ok());
    ASSERT_EQ(1, search_op.get()["hits"].size());

    extreme_filter += "|| (years:>2000 && ((age:<30 && rating:>5) || (age:>50 && rating:<5)))";
    search_op = coll2->search("Jeremy", {"name"}, extreme_filter,
                             {}, sort_fields_desc, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("`filter_by` has too many operations. Maximum allowed: 109. Use `--filter-by-max-ops` command line "
              "argument to customize this value.", search_op.error());

    collectionManager.drop_collection("ComplexFilterQueryCollection");
}

TEST_F(CollectionFilteringTest, PrefixSearchWithFilter) {
    std::ifstream infile(std::string(ROOT_DIR)+"test/documents.jsonl");
    std::vector<field> search_fields = {
            field("title", field_types::STRING, false),
            field("points", field_types::INT32, false)
    };

    query_fields = {"title"};
    sort_fields = { sort_by(sort_field_const::text_match, "DESC"), sort_by("points", "DESC") };

    auto collection = collectionManager.create_collection("collection", 4, search_fields, "points").get();

    std::string json_line;

    // dummy record for record id 0: to make the test record IDs to match with line numbers
    json_line = "{\"points\":10,\"title\":\"z\"}";
    collection->add(json_line);

    while (std::getline(infile, json_line)) {
        collection->add(json_line);
    }

    infile.close();

    std::vector<std::string> facets;
    auto results = collection->search("what ex", query_fields, "points: >10", facets, sort_fields, {0}, 10, 1, MAX_SCORE, {true}, 10,
                                 spp::sparse_hash_set<std::string>(),
                                 spp::sparse_hash_set<std::string>(), 10, "", 30, 5,
                                 "", 10).get();
    ASSERT_EQ(7, results["hits"].size());
    std::vector<std::string> ids = {"6", "12", "19", "22", "13", "8", "15"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_STREQ(id.c_str(), result_id.c_str());
    }

    collectionManager.drop_collection("collection");
}

TEST_F(CollectionFilteringTest, LargeFilterToken) {
    nlohmann::json json =
            R"({
                "name": "LargeFilterTokenCollection",
                "fields": [
                    {"name": "uri", "type": "string"}
                ],
                "symbols_to_index": [
                    "/",
                    "-"
                ]
            })"_json;

    auto op = collectionManager.create_collection(json);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    json.clear();
    std::string token = "rade/aols/insolvenzrecht/persoenliche-risiken-fuer-organe-von-kapitalgesellschaften-gmbh-"
                        "geschaeftsfuehrer-ag-vorstand";
    json["uri"] = token;
    auto add_op = coll->add(json.dump());
    ASSERT_TRUE(add_op.ok());

    auto results = coll->search("*", query_fields, "", {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    results = coll->search("*", query_fields, "uri:" + token, {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    token.erase(100); // Max token length that's indexed is 100, we'll still get a match.
    results = coll->search("*", query_fields, "uri:" + token, {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());

    token.erase(99);
    results = coll->search("*", query_fields, "uri:" + token, {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
}

TEST_F(CollectionFilteringTest, NonIndexedFiltering) {
    nlohmann::json json =
            R"({
                "name": "NonIndexedCollection",
                "fields": [
                    {"name": "uri", "type": "string"},
                    {"name": "non_index", "type": "string", "index": false, "optional": true}
                ]
            })"_json;

    auto op = collectionManager.create_collection(json);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    json.clear();
    json = R"({
                "uri": "token",
                "non_index": "foo"
            })"_json;
    auto add_op = coll->add(json.dump());
    ASSERT_TRUE(add_op.ok());

    auto search_op = coll->search("*", {}, "", {}, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_EQ(1, search_op.get()["hits"].size());

    search_op = coll->search("*", {}, "non_index:= bar", {}, sort_fields, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Cannot filter on non-indexed field `non_index`.", search_op.error());
}

TEST_F(CollectionFilteringTest, ComputeFilterResult) {
    Collection *coll1;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("points", field_types::INT32, false),};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "points").get();
    }

    for(size_t i=0; i<50; i++) {
        nlohmann::json doc;

        doc["title"] = i < 10 ? "foo" : "bar";
        doc["points"] = i;

        ASSERT_TRUE(coll1->add(doc.dump()).ok());
    }

    auto res_op = coll1->search("*", {}, "title: foo",
                                {}, {}, {0}, 10, 1, FREQUENCY, {true});

    auto results = res_op.get();

    ASSERT_EQ(10, results["found"]);

    res_op = coll1->search("*", {}, "title: bar && points:>=10",
                                {}, {}, {0}, 10, 1, FREQUENCY, {true});

    results = res_op.get();

    ASSERT_EQ(40, results["found"]);

    collectionManager.drop_collection("coll1");
}

TEST_F(CollectionFilteringTest, PrefixFilterOnTextFields) {
    Collection *coll_mul_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/multi_field_documents.jsonl");
    std::vector<field> fields = {
            field("title", field_types::STRING, false),
            field("starring", field_types::STRING, false),
            field("cast", field_types::STRING_ARRAY, true),
            field("points", field_types::INT32, false)
    };

    coll_mul_fields = collectionManager.get_collection("coll_mul_fields").get();
    if(coll_mul_fields == nullptr) {
        coll_mul_fields = collectionManager.create_collection("coll_mul_fields", 4, fields, "points").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_mul_fields->add(json_line);
    }

    infile.close();

    nlohmann::json results = coll_mul_fields->search("*", {}, "cast: Chris", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    std::vector<std::string> ids = {"6", "8", "1", "7"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_mul_fields->search("*", {}, "cast: Ch*", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(4, results["hits"].size());

    ids = {"6", "8", "1", "7"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_mul_fields->search("*", {}, "cast: M*", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"3", "2", "16"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_mul_fields->search("*", {}, "cast: Chris P*", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());

    ids = {"1", "7"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_mul_fields->search("*", {}, "cast: [Martin, Chris P*]", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());

    ids = {"2", "1", "7"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    results = coll_mul_fields->search("*", {}, "cast: [M*, Chris P*]", {}, {}, {0},
                                                     10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(5, results["hits"].size());

    ids = {"3", "2", "16", "1", "7"};

    for(size_t i = 0; i < results["hits"].size(); i++) {
        nlohmann::json result = results["hits"].at(i);
        std::string result_id = result["document"]["id"];
        std::string id = ids.at(i);
        ASSERT_EQ(id, result_id);
    }

    auto schema_json =
            R"({
                "name": "Names",
                "fields": [
                    {"name": "name", "type": "string", "optional": true},
                    {"name": "names", "type": "string[]", "optional": true}
                ]
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "name": "Steve Jobs"
            })"_json,
            R"({
                "name": "Adam Stator"
            })"_json,
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "Names"},
            {"q", "*"},
            {"query_by", "name"},
            {"filter_by", "name:= S*"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"].get<size_t>());
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("Steve Jobs", res_obj["hits"][0]["document"].at("name"));

    req_params = {
            {"collection", "Names"},
            {"q", "*"},
            {"query_by", "name"},
            {"filter_by", "name: S*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Adam Stator", res_obj["hits"][0]["document"].at("name"));
    ASSERT_EQ("Steve Jobs", res_obj["hits"][1]["document"].at("name"));

    documents = {
            R"({
                "name": "Steve Reiley"
            })"_json,
            R"({
                "name": "Storm"
            })"_json,
            R"({
                "name": "Steve Rogers"
            })"_json,
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "name"},
            {"filter_by", "name:= St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, res_obj["found"].get<size_t>());
    ASSERT_EQ(4, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"].at("name"));
    ASSERT_EQ("Storm", res_obj["hits"][1]["document"].at("name"));
    ASSERT_EQ("Steve Reiley", res_obj["hits"][2]["document"].at("name"));
    ASSERT_EQ("Steve Jobs", res_obj["hits"][3]["document"].at("name"));

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "name"},
            {"filter_by", "name: St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(5, res_obj["found"].get<size_t>());
    ASSERT_EQ(5, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"].at("name"));
    ASSERT_EQ("Storm", res_obj["hits"][1]["document"].at("name"));
    ASSERT_EQ("Steve Reiley", res_obj["hits"][2]["document"].at("name"));
    ASSERT_EQ("Adam Stator", res_obj["hits"][3]["document"].at("name"));
    ASSERT_EQ("Steve Jobs", res_obj["hits"][4]["document"].at("name"));

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "name"},
            {"filter_by", "name:= Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"].at("name"));
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"].at("name"));

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "name"},
            {"filter_by", "name: Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"].at("name"));
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"].at("name"));

    documents = {
            R"({
                "names": []
            })"_json,
            R"({
                "names": ["Steve Jobs"]
            })"_json,
            R"({
                "names": ["Adam Stator"]
            })"_json
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names:= St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"].get<size_t>());
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("Steve Jobs", res_obj["hits"][0]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names: St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Adam Stator", res_obj["hits"][0]["document"]["names"][0]);
    ASSERT_EQ("Steve Jobs", res_obj["hits"][1]["document"]["names"][0]);

    documents = {
            R"({
                "names": ["Steve Reiley"]
            })"_json,
            R"({
                "names": ["Storm"]
            })"_json,
            R"({
                "names": ["Adam", "Steve Rogers"]
            })"_json,
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names:= St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, res_obj["found"].get<size_t>());
    ASSERT_EQ(4, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Storm", res_obj["hits"][1]["document"]["names"][0]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][2]["document"]["names"][0]);
    ASSERT_EQ("Steve Jobs", res_obj["hits"][3]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names: St*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(5, res_obj["found"].get<size_t>());
    ASSERT_EQ(5, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Storm", res_obj["hits"][1]["document"]["names"][0]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][2]["document"]["names"][0]);
    ASSERT_EQ("Adam Stator", res_obj["hits"][3]["document"]["names"][0]);
    ASSERT_EQ("Steve Jobs", res_obj["hits"][4]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names:= Steve*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());
    ASSERT_EQ(3, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"]["names"][0]);
    ASSERT_EQ("Steve Jobs", res_obj["hits"][2]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names: Steve*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());
    ASSERT_EQ(3, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"]["names"][0]);
    ASSERT_EQ("Steve Jobs", res_obj["hits"][2]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names:= Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names: Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, res_obj["found"].get<size_t>());
    ASSERT_EQ(2, res_obj["hits"].size());
    ASSERT_EQ("Steve Rogers", res_obj["hits"][0]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][1]["document"]["names"][0]);

    documents = {
            R"({
                "names": ["Steve Runner foo"]
            })"_json,
            R"({
                "names": ["foo Steve Runner"]
            })"_json,
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names:= Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, res_obj["found"].get<size_t>());
    ASSERT_EQ(3, res_obj["hits"].size());
    ASSERT_EQ("Steve Runner foo", res_obj["hits"][0]["document"]["names"][0]);
    ASSERT_EQ("Steve Rogers", res_obj["hits"][1]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][2]["document"]["names"][0]);

    req_params = {
            {"collection", "Names"},
            {"q", "s"},
            {"query_by", "names"},
            {"filter_by", "names: Steve R*"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, res_obj["found"].get<size_t>());
    ASSERT_EQ(4, res_obj["hits"].size());
    ASSERT_EQ("foo Steve Runner", res_obj["hits"][0]["document"]["names"][0]);
    ASSERT_EQ("Steve Runner foo", res_obj["hits"][1]["document"]["names"][0]);
    ASSERT_EQ("Steve Rogers", res_obj["hits"][2]["document"]["names"][1]);
    ASSERT_EQ("Steve Reiley", res_obj["hits"][3]["document"]["names"][0]);
}

TEST_F(CollectionFilteringTest, InfixFilterOnTextFields) {
    // Create collection with infix: true on string fields
    auto schema_json =
            R"({
                "name": "InfixFilterColl",
                "fields": [
                    {"name": "title", "type": "string", "infix": true},
                    {"name": "cast", "type": "string[]", "infix": true},
                    {"name": "name_no_infix", "type": "string"},
                    {"name": "points", "type": "int32"}
                ],
                "default_sorting_field": "points"
            })"_json;

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    auto coll = collection_create_op.get();

    std::vector<nlohmann::json> documents = {
        R"({"title": "Captain America", "cast": ["Chris Evans", "Scarlett Johansson"], "name_no_infix": "foo", "points": 78})"_json,
        R"({"title": "Anchorman", "cast": ["Chris Parnell", "Josh Lawson"], "name_no_infix": "bar", "points": 63})"_json,
        R"({"title": "There Will Be Blood", "cast": ["Martin Stringer", "Jacob Stringer"], "name_no_infix": "baz", "points": 81})"_json,
        R"({"title": "Good Will Hunting", "cast": ["Matt Damon", "Ben Affleck"], "name_no_infix": "qux", "points": 83})"_json,
        R"({"title": "Percy Jackson", "cast": ["Logan Lerman", "Alexandra Daddario"], "name_no_infix": "quux", "points": 59})"_json,
        R"({"title": "Quantum Quest", "cast": ["Chris Pine"], "name_no_infix": "corge", "points": 52})"_json,
    };

    for (auto const& json : documents) {
        auto add_op = coll->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    // Test 1: Basic single-token infix on array field - *ris* should match "Chris" (Evans, Parnell, Pine)
    auto results = coll->search("*", {}, "cast: *ris*", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["hits"].size());
    std::set<std::string> result_ids;
    for (size_t i = 0; i < results["hits"].size(); i++) {
        result_ids.insert(results["hits"][i]["document"]["id"].get<std::string>());
    }
    ASSERT_TRUE(result_ids.count("0"));
    ASSERT_TRUE(result_ids.count("1"));
    ASSERT_TRUE(result_ids.count("5"));

    // Test 2: Infix on string field - *pta* should match "Captain America"
    results = coll->search("*", {}, "title: *pta*", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("Captain America", results["hits"][0]["document"]["title"]);

    // Test 3: Infix with no matches
    results = coll->search("*", {}, "cast: *zzz*", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());

    // Test 4: OR of infix values - [*ris*, *art*] matches Chris* and Martin
    results = coll->search("*", {}, "cast: [*ris*, *art*]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    result_ids.clear();
    for (size_t i = 0; i < results["hits"].size(); i++) {
        result_ids.insert(results["hits"][i]["document"]["id"].get<std::string>());
    }
    ASSERT_TRUE(result_ids.count("0"));
    ASSERT_TRUE(result_ids.count("1"));
    ASSERT_TRUE(result_ids.count("2"));
    ASSERT_TRUE(result_ids.count("5"));

    // Test 5: Error when field lacks infix: true
    auto res_op = coll->search("*", {}, "name_no_infix: *foo*", {}, {}, {0}, 10, 1, FREQUENCY, {false});
    ASSERT_FALSE(res_op.ok());
    ASSERT_EQ(400, res_op.code());
    ASSERT_EQ("Error with filter field `name_no_infix`: Infix filtering requires the field to have "
              "`infix: true` in the schema.", res_op.error());

    // Test 6: Mixed infix + exact in OR - [*ris*, Martin]
    results = coll->search("*", {}, "cast: [*ris*, Martin]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    result_ids.clear();
    for (size_t i = 0; i < results["hits"].size(); i++) {
        result_ids.insert(results["hits"][i]["document"]["id"].get<std::string>());
    }
    ASSERT_TRUE(result_ids.count("0"));
    ASSERT_TRUE(result_ids.count("1"));
    ASSERT_TRUE(result_ids.count("2"));
    ASSERT_TRUE(result_ids.count("5"));

    // Test 7: Mixed infix + prefix in OR - [*ris*, Ma*]
    results = coll->search("*", {}, "cast: [*ris*, Ma*]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    result_ids.clear();
    for (size_t i = 0; i < results["hits"].size(); i++) {
        result_ids.insert(results["hits"][i]["document"]["id"].get<std::string>());
    }
    ASSERT_TRUE(result_ids.count("0"));
    ASSERT_TRUE(result_ids.count("1"));
    ASSERT_TRUE(result_ids.count("2"));
    ASSERT_TRUE(result_ids.count("3"));
    ASSERT_TRUE(result_ids.count("5"));

    // Test 8: Infix combined with AND on another field
    results = coll->search("*", {}, "cast: *ris* && points: >60", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    result_ids.clear();
    for (size_t i = 0; i < results["hits"].size(); i++) {
        result_ids.insert(results["hits"][i]["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_TRUE(result_ids.count("0"));
    ASSERT_TRUE(result_ids.count("1"));

    // Test 9: Infix on title (non-array string field) - *unt* matches "Good Will Hunting"
    results = coll->search("*", {}, "title: *unt*", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("Good Will Hunting", results["hits"][0]["document"]["title"]);

    // Test 10: enable_lazy_filter=true + OR of infix values, cast:[*an*,*in*] with q:"will".
    {
        std::map<std::string, std::string> req_params = {
            {"collection", "InfixFilterColl"},
            {"q", "will"},
            {"query_by", "title"},
            {"filter_by", "cast: [*an*, *in*]"},
            {"enable_lazy_filter", "true"}
        };
        nlohmann::json embedded_params;
        std::string json_res;
        auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
        ASSERT_TRUE(search_op.ok());
        auto res_obj = nlohmann::json::parse(json_res);
        ASSERT_EQ(1, res_obj["found"].get<size_t>());
        ASSERT_EQ("2", res_obj["hits"][0]["document"]["id"].get<std::string>());
    }

    // Test 11: enable_lazy_filter=true + negated OR of infix values, cast:![*an*,*in*] with q:"will".
    // NOT({0,2,4,5}) = {1,3}. "will" in title: {2,3}. Result = {3}.
    {
        std::map<std::string, std::string> req_params = {
            {"collection", "InfixFilterColl"},
            {"q", "will"},
            {"query_by", "title"},
            {"filter_by", "cast: ! [*an*, *in*]"},
            {"enable_lazy_filter", "true"}
        };
        nlohmann::json embedded_params;
        std::string json_res;
        auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
        ASSERT_TRUE(search_op.ok());
        auto res_obj = nlohmann::json::parse(json_res);
        ASSERT_EQ(1, res_obj["found"].get<size_t>());
        ASSERT_EQ("3", res_obj["hits"][0]["document"]["id"].get<std::string>());
    }

    // Test 12: Exact-match operator (:=) with infix-style value — cast:= *in*.
    // No exact matches to "in" in our cast so should return 0
    results = coll->search("*", {}, "cast:= *in*", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
}

TEST_F(CollectionFilteringTest, ExactFilterOnLongField) {
    nlohmann::json schema = R"({
         "name": "companies",
         "fields": [
           {"name": "keywords", "type": "string[]"}
         ]
       })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());

    auto coll = op.get();

    nlohmann::json doc1;
    doc1["id"] = "0";

    std::string arr_value;

    // when value exceeds 128 tokens, we will fail gracefully
    for(size_t i = 0; i < 130; i++) {
        arr_value += "foo" + std::to_string(i) + " ";
    }
    doc1["keywords"] = {arr_value};

    ASSERT_TRUE(coll->add(doc1.dump()).ok());

    auto results = coll->search("*", {}, "keywords:=" + arr_value, {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["hits"].size());
}

TEST_F(CollectionFilteringTest, FilterOnStemmedField) {
    nlohmann::json schema = R"({
         "name": "companies",
         "fields": [
           {"name": "keywords", "type": "string[]", "facet": true, "stem": true }
         ]
       })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());

    auto coll = op.get();

    std::vector<nlohmann::json> documents = {
            R"({
                "id": "124",
                "keywords": ["Running Shoes"]
            })"_json,
            R"({
                "id": "125",
                "keywords": ["Baking"]
            })"_json
    };
    for (auto const &json: documents) {
        auto add_op = coll->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    auto results = coll->search("*", {}, "keywords:=Baking", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("125", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "keywords:=Running Shoes", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("124", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "keywords:=run Shoes", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("124", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "keywords:=run Shoe", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("124", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "keywords:shoe", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("124", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "keywords:[shoe, baking]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["hits"].size());
    ASSERT_EQ("125", results["hits"][0]["document"]["id"].get<std::string>());
    ASSERT_EQ("124", results["hits"][1]["document"]["id"].get<std::string>());

}

TEST_F(CollectionFilteringTest, MaxFilterByCandidates) {
    Collection *coll1;
    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("points", field_types::INT32, false)};

    coll1 = collectionManager.get_collection("coll1").get();
    if(coll1 == nullptr) {
        coll1 = collectionManager.create_collection("coll1", 1, fields, "points").get();
    }

    for(size_t i = 0; i < 20; i++) {
        nlohmann::json doc;
        doc["title"] = "Independent" + std::to_string(i);
        doc["points"] = i;
        coll1->add(doc.dump());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "coll1"},
            {"q", "*"},
            {"filter_by", "title:independent*"},
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, res_obj["found"].get<size_t>());
    ASSERT_EQ(4, res_obj["hits"].size());
    ASSERT_EQ("Independent19", res_obj["hits"][0]["document"]["title"]);
    ASSERT_EQ("Independent18", res_obj["hits"][1]["document"]["title"]);
    ASSERT_EQ("Independent17", res_obj["hits"][2]["document"]["title"]);
    ASSERT_EQ("Independent16", res_obj["hits"][3]["document"]["title"]);

    req_params = {
            {"collection", "coll1"},
            {"q", "*"},
            {"filter_by", "title:independent*"},
            {"max_filter_by_candidates", "0"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"].get<size_t>());
    ASSERT_EQ(0, res_obj["hits"].size());

    req_params = {
            {"collection", "coll1"},
            {"q", "*"},
            {"filter_by", "title:independent*"},
            {"max_filter_by_candidates", "1"}
    };

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"].get<size_t>());
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("Independent19", res_obj["hits"][0]["document"]["title"]);
}

TEST_F(CollectionFilteringTest, FilterOnObjectFields) {
    auto schema_json =
            R"({
                "name": "Products",
                "fields": [
                    {"name": "product_id", "type": "string"},
                    {"name": "product_name", "type": "string", "infix": true},
                    {"name": "product_description", "type": "string"},
                    {"name": "embedding", "type":"float[]", "embed":{"from": ["product_description"], "model_config": {"model_name": "ts/e5-small"}}},
                    {"name": "rating", "type": "int32"},
                    {"name": "stocks", "type": "object"},
                    {"name": "stocks.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "product_id": "product_a",
                "product_name": "shampoo",
                "product_description": "Our new moisturizing shampoo is perfect for those with dry or damaged hair.",
                "rating": "2",
                "stocks": {
                    "26": {
                        "rec": true
                    }
                }
            })"_json,
            R"({
                "product_id": "product_b",
                "product_name": "soap",
                "product_description": "Introducing our all-natural, organic soap bar made with essential oils and botanical ingredients.",
                "rating": "4",
                "stocks": {
                    "26": {
                        "rec": false
                    }
                }
            })"_json,
            R"({
                "product_id": "product_c",
                "product_name": "comb",
                "product_description": "Experience the natural elegance and gentle care of our handcrafted wooden combs – because your hair deserves the best.",
                "rating": "3",
                "stocks": {}
            })"_json
    };

    EmbedderManager::set_model_dir("/tmp/typesense_test/models");

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection", "Products"},
            {"q", "*"},
            {"filter_by", "stocks.26.rec:true"},
            {"include_fields", "product_id, product_name, stocks"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"].get<size_t>());
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("product_a", res_obj["hits"][0]["document"]["product_id"]);
    ASSERT_EQ(1, res_obj["hits"][0]["document"].count("stocks"));
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"].size());
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"].count("26"));
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"]["26"].size());
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"]["26"].count("rec"));
    ASSERT_TRUE(res_obj["hits"][0]["document"]["stocks"]["26"]["rec"]);

    req_params = {
            {"collection", "Products"},
            {"q", "*"},
            {"filter_by", "stocks.26.rec:false"},
            {"include_fields", "product_id, product_name, stocks"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"].get<size_t>());
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("product_b", res_obj["hits"][0]["document"]["product_id"]);
    ASSERT_EQ(1, res_obj["hits"][0]["document"].count("stocks"));
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"].size());
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"].count("26"));
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"]["26"].size());
    ASSERT_EQ(1, res_obj["hits"][0]["document"]["stocks"]["26"].count("rec"));
    ASSERT_FALSE(res_obj["hits"][0]["document"]["stocks"]["26"]["rec"]);
}

TEST_F(CollectionFilteringTest, IgnoreFieldValidation) {
    Collection *coll_mul_fields;

    std::ifstream infile(std::string(ROOT_DIR)+"test/multi_field_documents.jsonl");
    std::vector<field> fields = {
            field("title", field_types::STRING, false),
            field("starring", field_types::STRING, false),
            field("cast", field_types::STRING_ARRAY, true),
            field("points", field_types::INT32, false)
    };

    coll_mul_fields = collectionManager.get_collection("coll_mul_fields").get();
    if(coll_mul_fields == nullptr) {
        coll_mul_fields = collectionManager.create_collection("coll_mul_fields", 4, fields, "points").get();
    }

    std::string json_line;

    while (std::getline(infile, json_line)) {
        coll_mul_fields->add(json_line);
    }

    infile.close();
    nlohmann::json embedded_params;
    std::string json_res;
    long now_ts = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

    std::map<std::string, std::string> req_params = {
            {"collection", "coll_mul_fields"},
            {"q", "*"},
            {"filter_by", "age: 100"}
    };
    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not find a filter field named `age` in the schema.", search_op.error());

    req_params = {
            {"collection", "coll_mul_fields"},
            {"q", "*"},
            {"filter_by", "age: 100"},
            {"validate_field_names", "false"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"]);

    req_params = {
            {"collection", "coll_mul_fields"},
            {"q", "the"},
            {"query_by", "title"},
            {"filter_by", "age: 100"},
            {"enable_lazy_filter", "true"},
            {"validate_field_names", "false"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"]);

    req_params = {
            {"collection", "coll_mul_fields"},
            {"q", "*"},
            {"filter_by", "age: 100 && points: 75"},
            {"validate_field_names", "false"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(0, res_obj["found"]);

    req_params = {
            {"collection", "coll_mul_fields"},
            {"q", "*"},
            {"filter_by", "age: 100 || points: 75"},
            {"validate_field_names", "false"}
    };
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, res_obj["found"]);
    ASSERT_EQ(1, res_obj["hits"].size());
    ASSERT_EQ("8", res_obj["hits"][0]["document"].at("id"));
}

TEST_F(CollectionFilteringTest, NestedObjectFieldsFiltering) {
    auto schema_json =
            R"({
                "name": "menu",
                "fields": [
                    {"name": "name", "type": "string", "infix": true},
                    {"name": "ingredients", "type": "object[]"},
                    {"name": "ingredients.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "name": "Pasta",
                "ingredients": [{"name": "Che,ese", "concentration": 40}, {"name" : "spinach", "concentration": 10},
                                {"name": "jalepeno", "concentration": 20}]
            })"_json,
            R"({
                "name": "Pizza",
                "ingredients": [{"name": "chee.se", "concentration": 30}, {"name": "pizza sauce", "concentration": 30},
                                {"name": "olives", "concentration": 30}]
            })"_json,
            R"({
                "name": "Lasagna",
                "ingredients": [{"name": "Cheese", "concentration": 60}, {"name": "jalepeno", "concentration": 20},
                                {"name": "olives", "concentration": 20}]
            })"_json,
            R"({
                "name": "Popcorn",
                "ingredients": [{"name": "chee.se", "concentration": 30}]
            })"_json,
            R"({
                "name": "Pizza Rolls",
                "ingredients": [{"name": "chee/se", "concentration": 60}, {"name": "pizza sauce", "concentration": 5},
                                {"name" : "corn", "concentration": 40}]
            })"_json
    };


    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "name: p* && ingredients.{name : cheese && concentration :<50}"},
            {"include_fields", "name, ingredients"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto result = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, result["found"].get<size_t>());
    ASSERT_EQ(3, result["hits"].size());
    ASSERT_EQ("Popcorn", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][1]["document"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][2]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : olives && concentration :<50} && name : l*"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, result["found"].get<size_t>());
    ASSERT_EQ(1, result["hits"].size());
    ASSERT_EQ("Lasagna", result["hits"][0]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "p*"},
            {"query_by",       "name"},
            {"filter_by",      "ingredients.{name : cheese && concentration :<50}"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, result["found"].get<size_t>());
    ASSERT_EQ(3, result["hits"].size());
    ASSERT_EQ("Popcorn", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][1]["document"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][2]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : [jalepeno, olives] && concentration :<30}"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, result["found"].get<size_t>());
    ASSERT_EQ(2, result["hits"].size());
    ASSERT_EQ("Lasagna", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][1]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : [jalepeno, olives] && concentration :[10..20]}"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, result["found"].get<size_t>());
    ASSERT_EQ(2, result["hits"].size());
    ASSERT_EQ("Lasagna", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][1]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : cheese && concentration :[10..30, >=60]}"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(4, result["found"].get<size_t>());
    ASSERT_EQ(4, result["hits"].size());
    ASSERT_EQ("Pizza Rolls", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Popcorn", result["hits"][1]["document"]["name"]);
    ASSERT_EQ("Lasagna", result["hits"][2]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][3]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "a"},
            {"query_by",       "name"},
            {"infix",          "always"},
            {"filter_by",      "ingredients.{name : cheese && concentration :<50} && name: p*"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, result["found"].get<size_t>());
    ASSERT_EQ(2, result["hits"].size());
    ASSERT_EQ("Pizza", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][1]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "a"},
            {"query_by",       "name"},
            {"infix",          "always"},
            {"filter_by",      "ingredients.{name : olives && concentration :<50} || ingredients.{name : cheese && concentration :>50}"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, result["found"].get<size_t>());
    ASSERT_EQ(3, result["hits"].size());
    ASSERT_EQ("Pizza Rolls", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Lasagna", result["hits"][1]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][2]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "a"},
            {"query_by",       "name"},
            {"infix",          "always"},
            {"filter_by",      "ingredients.{(name : olives && concentration :<50) || (name : cheese && concentration :>50)}"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(3, result["found"].get<size_t>());
    ASSERT_EQ(3, result["hits"].size());
    ASSERT_EQ("Pizza Rolls", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Lasagna", result["hits"][1]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][2]["document"]["name"]);

    //validation tests
    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : cheese && }"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not parse the filter query: unbalanced `&&` operands.", search_op.error());

    //missing } at end
    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : cheese && concentration:30"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not parse the object filter: unbalanced curly braces.", search_op.error());

    //typo in nested field name
    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : cheese && concentrations:30}"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not find a filter field named `ingredients.concentrations` in the schema.", search_op.error());

    //invalid nested field
    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients.{name : cheese && concentration:30 && cost:<100}"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not find a filter field named `ingredients.cost` in the schema.", search_op.error());

    //missing . after {
    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "ingredients{name : cheese && concentration:30}"},
            {"enable_lazy_filter", "true"},
            {"include_fields", "name, ingredients"}
    };
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    json_res.clear();
    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Could not find a filter field named `ingredients{name` in the schema.", search_op.error());
}

TEST_F(CollectionFilteringTest, NestedObjectFieldsFilteringMultiple) {
    auto schema_json =
            R"({
                "name": "menu",
                "fields": [
                    {"name": "name", "type": "string", "infix": true},
                    {"name": "ingredients", "type": "object[]"},
                    {"name": "ingredients.*", "type": "auto", "optional": true},
                    {"name": "country", "type": "object[]"},
                    {"name": "country.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;

    std::vector<nlohmann::json> documents = {
            R"({
                "name": "Pasta",
                "ingredients": [{"name": "cheese", "concentration": 40}, {"name" : "spinach", "concentration": 10},
                                {"name": "jalepeno", "concentration": 20}],
                "country": [{"name": "Italy", "consumption": 60}, {"name": "India", "consumption": 20},
                            {"name": "England", "consumption": 45}]
            })"_json,
            R"({
                "name": "Pizza",
                "ingredients": [{"name": "cheese", "concentration": 30}, {"name": "pizza sauce", "concentration": 30},
                                {"name": "olives", "concentration": 30}],
                "country": [{"name": "Italy", "consumption": 80}, {"name": "India", "consumption": 50},
                            {"name": "England", "consumption": 75}]
            })"_json,
            R"({
                "name": "Lasagna",
                "ingredients": [{"name": "cheese", "concentration": 60}, {"name": "jalepeno", "concentration": 20},
                                {"name": "olives", "concentration": 20}],
                "country": [{"name": "Italy", "consumption": 44}, {"name": "India", "consumption": 12},
                            {"name": "England", "consumption": 55}]
            })"_json,
            R"({
                "name": "Popcorn",
                "ingredients": [{"name": "cheese", "concentration": 30}],
                "country": [{"name": "Italy", "consumption": 20}, {"name": "India", "consumption": 70},
                            {"name": "England", "consumption": 35}]
            })"_json,
            R"({
                "name": "Pizza Rolls",
                "ingredients": [{"name": "cheese", "concentration": 60}, {"name": "pizza sauce", "concentration": 5},
                                {"name" : "corn", "concentration": 40}],
                "country": [{"name": "Italy", "consumption": 10}, {"name": "India", "consumption": 50},
                            {"name": "England", "consumption": 15}]
            })"_json
    };


    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "country.{name : India && consumption :>20} && ingredients.{name : cheese && concentration :<50}"},
            {"include_fields", "name, ingredients, country"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto result = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, result["found"].get<size_t>());
    ASSERT_EQ(2, result["hits"].size());
    ASSERT_EQ("Popcorn", result["hits"][0]["document"]["name"]);
    ASSERT_EQ("Pizza", result["hits"][1]["document"]["name"]);

    req_params = {
            {"collection",     "menu"},
            {"q",              "*"},
            {"filter_by",      "country.{name : I* && consumption :>20} && name: l* && ingredients.{name : olives && concentration :20}"},
            {"include_fields", "name, ingredients, country"}
    };
    json_res.clear();
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, result["found"].get<size_t>());
    ASSERT_EQ(1, result["hits"].size());
    ASSERT_EQ("Lasagna", result["hits"][0]["document"]["name"]);
}

TEST_F(CollectionFilteringTest, FilterOnFieldWithSymbolsToIndex) {
    // Test filtering with field-level symbols_to_index configuration

    nlohmann::json schema = R"({
        "name": "symbols_test",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "root", "type": "string", "symbols_to_index": ["~"]}
        ]
    })"_json;

    auto collection_create_op = collectionManager.create_collection(schema);
    ASSERT_TRUE(collection_create_op.ok());
    Collection* coll = collection_create_op.get();

    nlohmann::json doc1 = R"({
        "title": "Document one",
        "root": "~~"
    })"_json;

    nlohmann::json doc2 = R"({
        "title": "Document two",
        "root": "somethingElse"
    })"_json;

    ASSERT_TRUE(coll->add(doc1.dump()).ok());
    ASSERT_TRUE(coll->add(doc2.dump()).ok());

    auto results = coll->search("*", {"title"}, "root:=~~", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();

    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("Document one", results["hits"][0]["document"]["title"].get<std::string>());
    ASSERT_EQ("~~", results["hits"][0]["document"]["root"].get<std::string>());

    results = coll->search("*", {"title"}, "root:=somethingElse", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["hits"].size());
    ASSERT_EQ("Document two", results["hits"][0]["document"]["title"].get<std::string>());

    collectionManager.drop_collection("symbols_test");
}

TEST_F(CollectionFilteringTest, DeepNestedObjectFieldsFiltering) {
    auto schema_json =
            R"({
                "name": "menu_nested",
                "fields": [
                    {"name": "main", "type": "object"},
                    {"name": "main.name", "type": "string", "infix": true},
                    {"name": "main.ingredients", "type": "object[]"},
                    {"name": "main.ingredients.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;

    std::vector<nlohmann::json> documents = {
            R"({"main": {
                            "name": "Pasta",
                            "ingredients": [{"name": "cheese", "concentration": 40, "vegan_available": true}, {"name" : "spinach", "concentration": 10},
                                            {"name": "jalepeno", "concentration": 20}]
                }
            })"_json,
            R"({"main": {
                            "name": "Pizza",
                            "ingredients": [{"name": "cheese", "concentration": 30, "vegan_available": false}, {"name": "pizza sauce", "concentration": 30},
                                            {"name": "olives", "concentration": 30}]
                }
            })"_json,
            R"({"main": {
                            "name": "Lasagna",
                            "ingredients": [{"name": "cheese", "concentration": 60, "vegan_available": true}, {"name": "jalepeno", "concentration": 20},
                                            {"name": "olives", "concentration": 20}]
                }
            })"_json
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection",     "menu_nested"},
            {"q",              "*"},
            {"filter_by",      "main.name: p* && main.ingredients.{name : cheese && concentration :<50 && vegan_available:true}"},
            {"include_fields", "main.name, main.ingredients"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto result = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, result["found"].get<size_t>());
    ASSERT_EQ(1, result["hits"].size());
    ASSERT_EQ("Pasta", result["hits"][0]["document"]["main"]["name"]);

    //deep nested field
    schema_json =
            R"({
                "name": "menu_nested_deep",
                "fields": [
                    {"name": "root", "type": "object"},
                    {"name": "root.main", "type": "object"},
                    {"name": "root.main.name", "type": "string", "infix": true},
                    {"name": "root.main.ingredients", "type": "object[]"},
                    {"name": "root.main.ingredients.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;

    documents = {
            R"({"root" : {
                            "main": {
                                        "name": "Pasta",
                                        "ingredients": [{"name": "cheese", "concentration": 40}, {"name" : "spinach", "concentration": 10},
                                                        {"name": "jalepeno", "concentration": 20}]
                            }
                }
            })"_json,
            R"({"root": {
                            "main": {
                                        "name": "Pizza",
                                        "ingredients": [{"name": "cheese", "concentration": 30}, {"name": "pizza sauce", "concentration": 30},
                                                        {"name": "olives", "concentration": 30}]
                            }
                }
            })"_json,
            R"({"root": {
                            "main": {
                                        "name": "Lasagna",
                                        "ingredients": [{"name": "cheese", "concentration": 60}, {"name": "jalepeno", "concentration": 20},
                                                        {"name": "olives", "concentration": 20}]
                            }
                }
            })"_json
    };

    collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    req_params = {
            {"collection",     "menu_nested_deep"},
            {"q",              "*"},
            {"filter_by",      "root.main.name: p* && root.main.ingredients.{name : cheese && concentration :<50}"},
            {"include_fields", "root.main.name, root.main.ingredients"}
    };
    json_res.clear();
    now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    result = nlohmann::json::parse(json_res);
    ASSERT_EQ(2, result["found"].get<size_t>());
    ASSERT_EQ(2, result["hits"].size());
    ASSERT_EQ("Pizza", result["hits"][0]["document"]["root"]["main"]["name"]);
    ASSERT_EQ("Pasta", result["hits"][1]["document"]["root"]["main"]["name"]);
}

TEST_F(CollectionFilteringTest, DeepNestedFieldsInsideObjectFilter) {
    auto schema_json =
            R"({
                "name": "show_nested",
                "fields": [
                    {"name": "title", "type": "string"},
                    {"name": "performances", "type": "object[]"},
                    {"name": "performances.startDate.localTimeHour", "type": "int32[]"},
                    {"name": "performances.pricing.minPrice", "type": "int64[]"}
                ],
                "enable_nested_fields": true
            })"_json;

    std::vector<nlohmann::json> documents = {
            R"({
                "title": "Same Object Match",
                "performances": [
                    {"startDate": {"localTimeHour": 19}, "pricing": {"minPrice": 4500}},
                    {"startDate": {"localTimeHour": 18}, "pricing": {"minPrice": 9000}}
                ]
            })"_json,
            R"({
                "title": "Split Object Match",
                "performances": [
                    {"startDate": {"localTimeHour": 19}, "pricing": {"minPrice": 9000}},
                    {"startDate": {"localTimeHour": 18}, "pricing": {"minPrice": 4500}}
                ]
            })"_json,
            R"({
                "title": "No Match",
                "performances": [
                    {"startDate": {"localTimeHour": 20}, "pricing": {"minPrice": 9000}}
                ]
            })"_json
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    std::map<std::string, std::string> req_params = {
            {"collection",     "show_nested"},
            {"q",              "*"},
            {"filter_by",      "performances.{startDate.localTimeHour:19 && pricing.minPrice:<5000}"},
            {"include_fields", "title, performances"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());
    auto result = nlohmann::json::parse(json_res);
    ASSERT_EQ(1, result["found"].get<size_t>());
    ASSERT_EQ(1, result["hits"].size());
    ASSERT_EQ("Same Object Match", result["hits"][0]["document"]["title"]);
}

TEST_F(CollectionFilteringTest, ArrayFieldInsideObjectFilter) {
    auto schema_json =
            R"({
                "name": "inventory_nested_offers",
                "fields": [
                    {"name": "title", "type": "string"},
                    {"name": "offers", "type": "object[]"},
                    {"name": "offers.quantities", "type": "int32[]", "range_index": true},
                    {"name": "offers.markers", "type": "string[]"},
                    {"name": "offers.enabled", "type": "bool[]"},
                    {"name": "offers.score", "type": "float[]"},
                    {"name": "offers.minCost", "type": "int32[]", "range_index": true},
                    {"name": "offers.maxCost", "type": "int32[]", "range_index": true}
                ],
                "enable_nested_fields": true
            })"_json;

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());

    std::vector<nlohmann::json> documents = {
            R"({
                "title": "Same Offer Numeric Match",
                "offers": [
                    {"quantities": [1, 3], "markers": ["standard"], "enabled": [false], "score": [2.0], "minCost": 7000, "maxCost": 4500},
                    {"quantities": [1], "markers": ["backup"], "enabled": [false], "score": [5.0], "minCost": 9000, "maxCost": 12000}
                ]
            })"_json,
            R"({
                "title": "Split Offer Numeric Match",
                "offers": [
                    {"quantities": [2, 3], "markers": ["standard"], "enabled": [false], "score": [1.0], "minCost": 9000, "maxCost": 12000},
                    {"quantities": [1], "markers": ["backup"], "enabled": [false], "score": [5.0], "minCost": 7000, "maxCost": 4500}
                ]
            })"_json,
            R"({
                "title": "String Marker Match",
                "offers": [
                    {"quantities": [1], "markers": ["priority", "manual"], "enabled": [true, false], "score": [1.25], "minCost": 7200, "maxCost": 5000}
                ]
            })"_json,
            R"({
                "title": "Split Marker Match",
                "offers": [
                    {"quantities": [1], "markers": ["priority"], "enabled": [true], "score": [1.0], "minCost": 9000, "maxCost": 10000},
                    {"quantities": [1], "markers": ["standard"], "enabled": [false], "score": [5.0], "minCost": 7200, "maxCost": 5000}
                ]
            })"_json,
            R"({
                "title": "Range Quantity Match",
                "offers": [
                    {"quantities": [4], "markers": ["standard"], "enabled": [false], "score": [1.75], "minCost": 7300, "maxCost": 5000}
                ]
            })"_json,
            R"({
                "title": "No Match",
                "offers": [
                    {"quantities": [1], "markers": ["standard"], "enabled": [false], "score": [5.0], "minCost": 9000, "maxCost": 12000}
                ]
            })"_json
    };

    for (auto const& json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }

    const auto search_titles = [&](const std::string& filter_by) {
        std::map<std::string, std::string> req_params = {
                {"collection",     "inventory_nested_offers"},
                {"q",              "*"},
                {"filter_by",      filter_by},
                {"include_fields", "title, offers"}
        };
        nlohmann::json embedded_params;
        std::string json_res;
        auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();

        auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
        EXPECT_TRUE(search_op.ok()) << search_op.error();

        std::vector<std::string> titles;
        if (search_op.ok()) {
            auto result = nlohmann::json::parse(json_res);
            for (const auto& hit: result["hits"]) {
                titles.push_back(hit["document"]["title"].get<std::string>());
            }
        }
        std::sort(titles.begin(), titles.end());
        return titles;
    };

    ASSERT_EQ(std::vector<std::string>({"Same Offer Numeric Match"}),
              search_titles("offers.{quantities:>=3 && minCost:<=7100 && maxCost:>=4000}"));
    ASSERT_EQ(std::vector<std::string>({"String Marker Match"}),
              search_titles("offers.{markers:=priority && minCost:<=7500}"));
    ASSERT_EQ(std::vector<std::string>({"String Marker Match"}),
              search_titles("offers.{enabled:true && minCost:<=7500}"));
    ASSERT_EQ(std::vector<std::string>({"String Marker Match"}),
              search_titles("offers.{score:<1.5 && minCost:<=7500}"));
    ASSERT_EQ(std::vector<std::string>({"Range Quantity Match"}),
              search_titles("offers.{quantities:[3..4] && minCost:<=7400 && maxCost:>=4900}"));
    ASSERT_EQ(std::vector<std::string>({"Range Quantity Match", "Split Marker Match", "String Marker Match"}),
              search_titles("offers.{quantities:!=3 && minCost:<=7400}"));
    ASSERT_EQ(std::vector<std::string>({"No Match", "Range Quantity Match", "Same Offer Numeric Match",
                                        "Split Offer Numeric Match"}),
              search_titles("offers.{markers:!=priority}"));
    ASSERT_EQ(std::vector<std::string>({"No Match", "Split Marker Match", "String Marker Match"}),
              search_titles("offers.{quantities:![3..4]}"));
}

TEST_F(CollectionFilteringTest, MissingFilterSchemaValidation) {
    // track_missing_values on non-optional field should fail
    auto schema = R"({
        "name": "bad_coll",
        "fields": [
            {"name": "title", "type": "string", "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_FALSE(op.ok());
    ASSERT_EQ("The `track_missing_values` property can only be set on optional fields.", op.error());

    schema = R"({
        "name": "bad_coll_not_indexed",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "index": false, "track_missing_values": true}
        ]
    })"_json;

    op = collectionManager.create_collection(schema);
    ASSERT_FALSE(op.ok());
    ASSERT_EQ("The `track_missing_values` property can only be set on indexed optional fields.", op.error());

    // track_missing_values on optional field should succeed and appear in summary
    schema = R"({
        "name": "good_coll",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());

    auto coll = op.get();
    auto summary = coll->get_summary_json();
    bool found = false;
    for (auto& f : summary["fields"]) {
        if (f["name"] == "color") {
            LOG(INFO) << "Field summary: " << f.dump();
            ASSERT_TRUE(f["track_missing_values"].get<bool>());
            found = true;
        }
    }
    ASSERT_TRUE(found);

    collectionManager.drop_collection("good_coll");
}

TEST_F(CollectionFilteringTest, MissingFilterBasic) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "Pants", "color": "blue", "points": 30})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "3", "title": "Scarf", "points": 40})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "4", "title": "Shoes", "color": "green", "points": 50})"_json.dump()).ok());

    // !_missing: docs with color
    auto results = coll->search("*", {}, "color: !_missing",
                                {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(3, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"4", "2", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // _missing: docs without color
    results = coll->search("*", {}, "color: _missing",
                           {}, sort_fields, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"3", "1"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterWithoutTrackMissingValues) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());

    auto search_op = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0});
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Missing filter can only be applied to optional fields with `track_missing_values` enabled in the schema.", search_op.error());

    search_op = coll->search("*", {}, "color: _missing", {}, sort_fields, {0});
    ASSERT_FALSE(search_op.ok());
    ASSERT_EQ("Missing filter can only be applied to optional fields with `track_missing_values` enabled in the schema.", search_op.error());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterDoesNotHijackStringValuesContainingMissing) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "pre_missing_post", "color": "red"})"_json.dump()).ok());

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    auto filter_op = filter::parse_filter_query("title: _missing", coll->get_schema(), store, doc_id_prefix,
                                                filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_EQ("Missing filter can only be applied to optional fields with `track_missing_values` enabled in the schema.",
              filter_op.error());

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("color: _missing", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    ASSERT_EQ(MISSING, filter_tree_root->filter_exp.comparators[0]);
    ASSERT_FALSE(filter_tree_root->filter_exp.apply_not_equals);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("title: pre_missing_post", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    ASSERT_NE(MISSING, filter_tree_root->filter_exp.comparators[0]);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query(R"(title: `_missing`)", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    ASSERT_NE(MISSING, filter_tree_root->filter_exp.comparators[0]);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("title:=_missing", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    ASSERT_NE(MISSING, filter_tree_root->filter_exp.comparators[0]);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("title: _missing value", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    ASSERT_NE(MISSING, filter_tree_root->filter_exp.comparators[0]);
    delete filter_tree_root;

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterCombinedWithOtherFilters) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "Pants", "color": "blue", "points": 30})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "3", "title": "Scarf", "points": 5})"_json.dump()).ok());

    // AND with numeric
    auto results = coll->search("*", {}, "color: !_missing && points: >15",
                                {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "color: _missing && points: >10",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    // OR
    results = coll->search("*", {}, "color: !_missing || points: >15",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(3, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"2", "1", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // text search + exists
    results = coll->search("s", {"title"}, "color: !_missing",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterMultipleOptionalFields) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "size", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "color": "red", "size": "M", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B", "color": "blue", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "size": "L", "points": 30})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "3", "title": "D", "points": 40})"_json.dump()).ok());

    // both exist
    auto results = coll->search("*", {}, "color: !_missing && size: !_missing",
                                {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    // color exists, size missing
    results = coll->search("*", {}, "color: !_missing && size: _missing",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    // both missing
    results = coll->search("*", {}, "color: _missing && size: _missing",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("3", results["hits"][0]["document"]["id"].get<std::string>());

    // either exists (OR)
    results = coll->search("*", {}, "color: !_missing || size: !_missing",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(3, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"2", "1", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterNumericAndBoolFields) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "rating", "type": "float", "optional": true, "track_missing_values": true},
            {"name": "stock", "type": "int32", "optional": true, "track_missing_values": true},
            {"name": "in_stock", "type": "bool", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "rating": 4.5, "stock": 100, "in_stock": true, "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B", "rating": 3.2, "in_stock": false, "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "stock": 50, "points": 30})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "3", "title": "D", "points": 40})"_json.dump()).ok());

    // float exists
    auto results = coll->search("*", {}, "rating: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"1", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // float not exists
    results = coll->search("*", {}, "rating: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"3", "2"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // int exists
    results = coll->search("*", {}, "stock: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"2", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // bool exists: docs 0 and 1 (both true and false count)
    results = coll->search("*", {}, "in_stock: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"1", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // bool not exists
    results = coll->search("*", {}, "in_stock: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"3", "2"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    // cross-field: rating exists AND stock missing
    results = coll->search("*", {}, "rating: !_missing && stock: _missing",
                           {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterAfterDeletion) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "Pants", "color": "blue", "points": 30})"_json.dump()).ok());

    auto results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    // delete doc with color
    coll->remove("0");
    results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    // delete doc without color
    coll->remove("1");
    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(0, results["found"].get<size_t>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterAfterUpdate) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "points": 20})"_json.dump()).ok());

    auto results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    // upsert doc 1 with color
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "color": "green", "points": 20})"_json.dump(), UPSERT).ok());
    results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(0, results["found"].get<size_t>());

    // upsert doc 2 without color
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "Pants", "points": 30})"_json.dump(), UPSERT).ok());
    results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterMixedBatchUpdatePreservesUnchangedFieldState) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "Shirt", "color": "red", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "Hat", "color": "blue", "points": 20})"_json.dump()).ok());

    std::vector<std::string> updates = {
        R"({"id": "0", "points": 15})",
        R"({"id": "1", "color": "green"})"
    };
    nlohmann::json update_doc;
    auto import_response = coll->add_many(updates, update_doc, UPDATE);
    ASSERT_TRUE(import_response["success"].get<bool>());
    ASSERT_EQ(2, import_response["num_imported"].get<int>());

    auto results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(0, results["found"].get<size_t>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterOnArrayFields) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "tags", "type": "string[]", "optional": true, "track_missing_values": true},
            {"name": "scores", "type": "int32[]", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "tags": ["sport", "outdoor"], "scores": [10, 20], "points": 1})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B", "tags": ["indoor"], "points": 2})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "points": 3})"_json.dump()).ok());

    auto results = coll->search("*", {}, "tags: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "scores: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "scores: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterRegexDynamicFields) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "extra_.*", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    // Index docs before and after concrete regex-matched fields are materialized.
    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B", "extra_size": "L", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "extra_color": "green", "points": 30})"_json.dump()).ok());

    auto results = coll->search("*", {}, "extra_color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"1", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    results = coll->search("*", {}, "extra_color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "extra_size: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    expected_ids = {"2", "0"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    results = coll->search("*", {}, "extra_size: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("1", results["hits"][0]["document"]["id"].get<std::string>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterFallbackField) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": ".*", "type": "string*", "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "color": "red"})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B"})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "size": "L"})"_json.dump()).ok());

    auto results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("0", results["hits"][0]["document"]["id"].get<std::string>());

    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    std::vector<std::string> expected_ids = {"2", "1"};
    for (size_t i = 0; i < results["hits"].size(); i++) {
        ASSERT_EQ(expected_ids[i], results["hits"][i]["document"]["id"].get<std::string>());
    }

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterSchemaAlter) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    ASSERT_TRUE(coll->add(R"({"id": "0", "title": "A", "points": 10})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "1", "title": "B", "points": 20})"_json.dump()).ok());
    ASSERT_TRUE(coll->add(R"({"id": "2", "title": "C", "color": "green", "points": 30})"_json.dump()).ok());

    // add optional field with track_missing_values
    auto alter_payload = R"({
        "fields": [
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true}
        ]
    })"_json;
    ASSERT_TRUE(coll->alter(alter_payload).ok());

    // docs 0 and 1 should be missing; doc 2 had color and gets re-indexed during alter
    auto results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());
    results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("2", results["hits"][0]["document"]["id"].get<std::string>());

    // add new doc with color
    ASSERT_TRUE(coll->add(R"({"id": "3", "title": "D", "color": "red", "points": 40})"_json.dump()).ok());
    results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    // drop the field
    alter_payload = R"({"fields": [{"name": "color", "drop": true}]})"_json;
    ASSERT_TRUE(coll->alter(alter_payload).ok());

    // filter on dropped field should fail
    auto search_op = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0});
    ASSERT_FALSE(search_op.ok());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterLargerDataset) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true},
            {"name": "points", "type": "int32"}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    for (int i = 0; i < 100; i++) {
        nlohmann::json doc;
        doc["id"] = std::to_string(i);
        doc["title"] = "Product " + std::to_string(i);
        doc["points"] = i;
        if (i % 2 == 0) {
            doc["color"] = "color_" + std::to_string(i);
        }
        ASSERT_TRUE(coll->add(doc.dump()).ok());
    }

    auto results = coll->search("*", {}, "color: !_missing", {}, sort_fields, {0}, 200).get();
    ASSERT_EQ(50, results["found"].get<size_t>());

    results = coll->search("*", {}, "color: _missing", {}, sort_fields, {0}, 200).get();
    ASSERT_EQ(50, results["found"].get<size_t>());

    results = coll->search("*", {}, "color: !_missing && points: >=50", {}, sort_fields, {0}, 200).get();
    ASSERT_EQ(25, results["found"].get<size_t>());

    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterLazyEvaluation) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    std::set<int> has_color = {0, 1, 5};
    for (int i = 0; i < 6; i++) {
        nlohmann::json doc;
        doc["id"] = std::to_string(i);
        doc["title"] = "Product " + std::to_string(i);
        if (has_color.count(i)) {
            doc["color"] = "color_" + std::to_string(i);
        }
        ASSERT_TRUE(coll->add(doc.dump()).ok());
    }

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;
    auto const enable_lazy_evaluation = true;
    auto const disable_lazy_evaluation = false;

    Option<bool> filter_op = filter::parse_filter_query("color: !_missing", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_missing = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                               enable_lazy_evaluation);
    ASSERT_TRUE(iter_missing.init_status().ok());
    ASSERT_FALSE(iter_missing._get_is_filter_result_initialized());

    // !_missing (complement): docs with color = {0, 1, 5}
    // is_valid sets seq_id = id+1 for the probed doc; next() keeps that value for complement iterators.
    // is_valid(0)=1, next()→1; is_valid(1)=1, next()→2; is_valid(2)=0; is_valid(3)=0; is_valid(4)=0;
    // is_valid(5)=1, next()→invalid
    std::vector<uint32_t> validate_ids = {0, 1, 2, 3, 4, 5, 6};
    std::vector<uint32_t> seq_ids = {1, 2, 3, 4, 5, 6, 6};
    std::vector<int> expected = {1, 1, 0, 0, 0, 1, -1};

    iter_missing.reset();
    ASSERT_EQ(filter_result_iterator_t::valid, iter_missing.validity);

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_missing.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_missing.next();
        }
        ASSERT_EQ(seq_ids[i], iter_missing.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_missing.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_missing_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             disable_lazy_evaluation);
        ASSERT_TRUE(iter_missing_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_missing_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5, 6};
        seq_ids = {1, 5, 5, 5, 5, 5, 5};
        expected = {1, 1, 0, 0, 0, 1, -1};

        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i] == -1 ? filter_result_iterator_t::invalid : filter_result_iterator_t::valid,
                      iter_missing_non_lazy.validity);
            ASSERT_EQ(expected[i], iter_missing_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_missing_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_missing_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_missing_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    // _missing (direct): docs missing color = {2, 3, 4}
    filter_op = filter::parse_filter_query("color: _missing", coll->get_schema(), store, doc_id_prefix,
                                          filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_missing = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                    enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_missing.init_status().ok());
    ASSERT_FALSE(iter_not_missing._get_is_filter_result_initialized());

    // is_valid(0)=0; is_valid(1)=0; is_valid(2)=1, next()→3; is_valid(3)=1, next()→4;
    // is_valid(4)=1, next()→invalid
    validate_ids = {0, 1, 2, 3, 4, 5, 6};
    seq_ids = {2, 2, 3, 4, 4, 4, 4};
    expected = {0, 0, 1, 1, 1, -1, -1};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i] == -1 ? filter_result_iterator_t::invalid : filter_result_iterator_t::valid,
                  iter_not_missing.validity);
        ASSERT_EQ(expected[i], iter_not_missing.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_missing.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_missing.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_missing.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_not_missing_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 disable_lazy_evaluation);
        ASSERT_TRUE(iter_not_missing_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_not_missing_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5, 6};
        seq_ids = {2, 2, 3, 4, 4, 4, 4};
        expected = {0, 0, 1, 1, 1, -1, -1};

        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i] == -1 ? filter_result_iterator_t::invalid : filter_result_iterator_t::valid,
                      iter_not_missing_non_lazy.validity);
            ASSERT_EQ(expected[i], iter_not_missing_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_not_missing_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_not_missing_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_missing_non_lazy.validity);
    }

    delete filter_tree_root;
    collectionManager.drop_collection("products");
}

TEST_F(CollectionFilteringTest, MissingFilterLazyEvaluationSearchHits) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    std::set<std::string> expected_ids;
    for (int i = 0; i < 30; i++) {
        nlohmann::json doc;
        doc["id"] = std::to_string(i);
        doc["title"] = "Product " + std::to_string(i);
        if (i < 25) {
            doc["color"] = "color_" + std::to_string(i);
            expected_ids.insert(std::to_string(i));
        }
        ASSERT_TRUE(coll->add(doc.dump()).ok());
    }

    std::map<std::string, std::string> req_params = {
        {"collection", "products"},
        {"q", "*"},
        {"query_by", "title"},
        {"filter_by", "color: !_missing"},
        {"enable_lazy_filter", "true"},
        {"per_page", "30"}
    };
    nlohmann::json embedded_params;
    std::string json_res;
    auto now_ts = std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    auto search_op = collectionManager.do_search(req_params, embedded_params, json_res, now_ts);
    ASSERT_TRUE(search_op.ok());

    auto res_obj = nlohmann::json::parse(json_res);
    ASSERT_EQ(25, res_obj["found"].get<size_t>());
    ASSERT_EQ(25, res_obj["hits"].size());

    std::set<std::string> actual_ids;
    for (const auto& hit : res_obj["hits"]) {
        actual_ids.insert(hit["document"]["id"].get<std::string>());
    }
    ASSERT_EQ(expected_ids, actual_ids);

    collectionManager.drop_collection("products");
}
