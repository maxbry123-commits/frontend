#include <gtest/gtest.h>
#include <string>
#include <vector>
#include <set>
#include <fstream>
#include <collection_manager.h>
#include <filter.h>
#include <posting.h>
#include <chrono>
#include "collection.h"

class FilterTest : public ::testing::Test {
protected:
    Store *store;
    CollectionManager & collectionManager = CollectionManager::get_instance();
    std::atomic<bool> quit = false;

    std::vector<std::string> query_fields;
    std::vector<sort_by> sort_fields;

    void setupCollection() {
        std::string state_dir_path = "/tmp/typesense_test/collection_join";
        LOG(INFO) << "Truncating and creating: " << state_dir_path;
        system(("rm -rf "+state_dir_path+" && mkdir -p "+state_dir_path).c_str());

        store = new Store(state_dir_path);
        collectionManager.init(store, 1.0, "auth_key", quit);
        collectionManager.load(8, 1000);
    }

    virtual void SetUp() {
        setupCollection();
    }

    virtual void TearDown() {
        collectionManager.dispose();
        delete store;
    }
};

TEST_F(FilterTest, FilterTreeIterator) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "age", "type": "int32"},
                    {"name": "years", "type": "int32[]"},
                    {"name": "rating", "type": "float"},
                    {"name": "tags", "type": "string[]"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::string json_line;
    while (std::getline(infile, json_line)) {
        auto add_op = coll->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }
    infile.close();

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    auto const enable_lazy_evaluation = true;
    auto iter_null_filter_tree_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                               enable_lazy_evaluation);

    ASSERT_TRUE(iter_null_filter_tree_test.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_null_filter_tree_test.validity);

    Option<bool> filter_op = filter::parse_filter_query("name: foo", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_no_match_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);

    ASSERT_TRUE(iter_no_match_test.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_no_match_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: [`ALPHA1]X`,`ALPHA2]X`,`ALPHA3]X`]", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_no_match_multi_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);

    ASSERT_TRUE(iter_no_match_multi_test.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_no_match_multi_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: Jeremy", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_contains_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(iter_contains_test.init_status().ok());

    for (uint32_t i = 0; i < 5; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_contains_test.validity);
        ASSERT_EQ(i, iter_contains_test.seq_id);
        iter_contains_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: [Jeremy, Howard, Richard]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_contains_multi_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_contains_multi_test.init_status().ok());

    for (uint32_t i = 0; i < 5; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_contains_multi_test.validity);
        ASSERT_EQ(i, iter_contains_multi_test.seq_id);
        iter_contains_multi_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_multi_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name:= Jeremy Howard", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_exact_match_1_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_exact_match_1_test.init_status().ok());

    for (uint32_t i = 0; i < 5; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_exact_match_1_test.validity);
        ASSERT_EQ(i, iter_exact_match_1_test.seq_id);
        iter_exact_match_1_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_match_1_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags:= PLATINUM", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_exact_match_2_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_exact_match_2_test.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_match_2_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags:= [gold, silver]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_exact_match_multi_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                enable_lazy_evaluation);
    ASSERT_TRUE(iter_exact_match_multi_test.init_status().ok());

    std::vector<int> expected = {0, 2, 3, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_exact_match_multi_test.validity);
        ASSERT_EQ(i, iter_exact_match_multi_test.seq_id);
        iter_exact_match_multi_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_match_multi_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags:!= gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                         enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_test.init_status().ok());

    expected = {1, 3};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test.validity);
        ASSERT_EQ(i, iter_not_equals_test.seq_id);
        iter_not_equals_test.next();
    }

    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: James || tags: bronze", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto doc =
            R"({
                "name": "James Rowdy",
                "age": 36,
                "years": [2005, 2022],
                "rating": 6.03,
                "tags": ["copper"]
            })"_json;
    auto add_op = coll->add(doc.dump());
    ASSERT_TRUE(add_op.ok());

    auto iter_or_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                 enable_lazy_evaluation);
    ASSERT_TRUE(iter_or_test.init_status().ok());

    expected = {2, 4, 5};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_or_test.validity);
        ASSERT_EQ(i, iter_or_test.seq_id);
        iter_or_test.next();
    }

    ASSERT_EQ(filter_result_iterator_t::invalid, iter_or_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: James || (tags: gold && tags: silver)", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_complex_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_complex_filter_test.init_status().ok());

    ASSERT_EQ(filter_result_iterator_t::valid, iter_complex_filter_test.validity);
    ASSERT_EQ(0, iter_complex_filter_test.is_valid(3));
    ASSERT_EQ(4, iter_complex_filter_test.seq_id);

    expected = {4, 5};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_complex_filter_test.validity);
        ASSERT_EQ(i, iter_complex_filter_test.seq_id);
        iter_complex_filter_test.next();
    }

    ASSERT_EQ(filter_result_iterator_t::invalid, iter_complex_filter_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: James || (tags: gold && tags: [silver, bronze])", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_validate_ids_test1 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_validate_ids_test1.init_status().ok());

    std::vector<int> validate_ids = {0, 1, 2, 3, 4, 5, 6};
    std::vector<int> seq_ids = {0, 2, 2, 4, 4, 5, 5};
    expected = {1, 0, 1, 0, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_validate_ids_test1.is_valid(validate_ids[i]));
        ASSERT_EQ(seq_ids[i], iter_validate_ids_test1.seq_id);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: platinum || name: James", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_validate_ids_test2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_validate_ids_test2.init_status().ok());

    validate_ids = {0, 1, 2, 3, 4, 5, 6}, seq_ids = {1, 1, 5, 5, 5, 5, 5};
    expected = {0, 1, 0, 0, 0, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_validate_ids_test2.is_valid(validate_ids[i]));
        ASSERT_EQ(seq_ids[i], iter_validate_ids_test2.seq_id);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: gold && rating: < 6", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_validate_ids_test3 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_validate_ids_test3.init_status().ok());
    ASSERT_FALSE(iter_validate_ids_test3._get_is_filter_result_initialized());

    iter_validate_ids_test3.compute_iterators();
    ASSERT_TRUE(iter_validate_ids_test3._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6}, seq_ids = {0, 4, 4, 4, 4, 4, 4};
    expected = {1, 0, 0, 0, 1, -1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_validate_ids_test3.is_valid(validate_ids[i]));
        ASSERT_EQ(seq_ids[i], iter_validate_ids_test3.seq_id);
    }

    // Lazy evaluation.
    iter_validate_ids_test3 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(iter_validate_ids_test3.init_status().ok());
    ASSERT_FALSE(iter_validate_ids_test3._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6}, seq_ids = {0, 3, 3, 4, 4, 4, 4};
    expected = {1, 0, 0, 0, 1, -1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_validate_ids_test3.is_valid(validate_ids[i]));
        ASSERT_EQ(seq_ids[i], iter_validate_ids_test3.seq_id);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_compact_plist_contains_atleast_one_test1 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                                  filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_compact_plist_contains_atleast_one_test1.init_status().ok());

    std::vector<uint32_t> ids = {1, 3, 5};
    std::vector<uint32_t> offset_index = {0, 3, 6};
    std::vector<uint32_t> offsets = {0, 3, 4, 0, 3, 4, 0, 3, 4};

    compact_posting_list_t* c_list1 = compact_posting_list_t::create(3, &ids[0], &offset_index[0], 9, &offsets[0]);
    ASSERT_FALSE(iter_compact_plist_contains_atleast_one_test1.contains_atleast_one(SET_COMPACT_POSTING(c_list1)));
    free(c_list1);

    auto iter_compact_plist_contains_atleast_one_test2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                                  filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_compact_plist_contains_atleast_one_test2.init_status().ok());

    ids = {1, 3, 4};
    offset_index = {0, 3, 6};
    offsets = {0, 3, 4, 0, 3, 4, 0, 3, 4};

    compact_posting_list_t* c_list2 = compact_posting_list_t::create(3, &ids[0], &offset_index[0], 9, &offsets[0]);
    ASSERT_TRUE(iter_compact_plist_contains_atleast_one_test2.contains_atleast_one(SET_COMPACT_POSTING(c_list2)));
    free(c_list2);

    auto iter_plist_contains_atleast_one_test1 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_plist_contains_atleast_one_test1.init_status().ok());

    posting_list_t p_list1(2);
    ids = {1, 3};
    for (const auto &i: ids) {
        p_list1.upsert(i, {1, 2, 3});
    }

    ASSERT_FALSE(iter_plist_contains_atleast_one_test1.contains_atleast_one(&p_list1));

    auto iter_plist_contains_atleast_one_test2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root);
    ASSERT_TRUE(iter_plist_contains_atleast_one_test2.init_status().ok());

    posting_list_t p_list2(2);
    ids = {1, 3, 4};
    for (const auto &i: ids) {
        p_list1.upsert(i, {1, 2, 3});
    }

    ASSERT_TRUE(iter_plist_contains_atleast_one_test2.contains_atleast_one(&p_list1));

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags:= [gold, silver]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_reset_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                    enable_lazy_evaluation);
    ASSERT_TRUE(iter_reset_test.init_status().ok());

    expected = {0, 2, 3, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_reset_test.validity);
        ASSERT_EQ(i, iter_reset_test.seq_id);
        iter_reset_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_reset_test.validity);

    iter_reset_test.reset();

    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_reset_test.validity);
        ASSERT_EQ(i, iter_reset_test.seq_id);
        iter_reset_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_reset_test.validity);

    auto iter_move_assignment_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                              enable_lazy_evaluation);

    iter_reset_test.reset();
    iter_move_assignment_test = std::move(iter_reset_test);

    expected = {0, 2, 3, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_move_assignment_test.validity);
        ASSERT_EQ(i, iter_move_assignment_test.seq_id);
        iter_move_assignment_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_move_assignment_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: gold", coll->get_schema(), store, doc_id_prefix,
                                                filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_to_array_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(iter_to_array_test.init_status().ok());

    uint32_t* filter_ids = nullptr;
    uint32_t filter_ids_length;

    iter_to_array_test.compute_iterators();
    filter_ids_length = iter_to_array_test.to_filter_id_array(filter_ids);
    ASSERT_EQ(3, filter_ids_length);

    expected = {0, 2, 4};
    for (uint32_t i = 0; i < filter_ids_length; i++) {
        ASSERT_EQ(expected[i], filter_ids[i]);
    }

    delete[] filter_ids;

    auto iter_and_scalar_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                         enable_lazy_evaluation);
    ASSERT_TRUE(iter_and_scalar_test.init_status().ok());

    uint32_t a_ids[6] = {0, 1, 3, 4, 5, 6};
    uint32_t* and_result = nullptr;
    uint32_t and_result_length;
    and_result_length = iter_and_scalar_test.and_scalar(a_ids, 6, and_result);
    ASSERT_EQ(2, and_result_length);

    expected = {0, 4};
    for (uint32_t i = 0; i < and_result_length; i++) {
        ASSERT_EQ(expected[i], and_result[i]);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_and_scalar_test.validity);

    delete[] and_result;
    delete filter_tree_root;

    doc = R"({
            "name": "James Rowdy",
            "age": 36,
            "years": [2005, 2022],
            "rating": 6.03,
            "tags": ["FINE PLATINUM"]
        })"_json;
    add_op = coll->add(doc.dump());
    ASSERT_TRUE(add_op.ok());

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: bronze", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);

    auto iter_add_phrase_ids_test = new filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);
    std::unique_ptr<filter_result_iterator_t> filter_iter_guard(iter_add_phrase_ids_test);
    ASSERT_TRUE(iter_add_phrase_ids_test->init_status().ok());

    auto phrase_ids = new uint32_t[4];
    for (uint32_t i = 0; i < 4; i++) {
        phrase_ids[i] = i * 2;
    }
    filter_result_iterator_t::add_phrase_ids(iter_add_phrase_ids_test, phrase_ids, 4);
    filter_iter_guard.release();
    filter_iter_guard.reset(iter_add_phrase_ids_test);

    ASSERT_EQ(filter_result_iterator_t::valid, iter_add_phrase_ids_test->validity);
    ASSERT_EQ(2, iter_add_phrase_ids_test->seq_id);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: [gold]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_multi_value_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_multi_value_test.init_status().ok());
    ASSERT_FALSE(iter_string_multi_value_test._get_is_filter_result_initialized());

    expected = {0, 2, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_multi_value_test.validity);
        ASSERT_EQ(i, iter_string_multi_value_test.seq_id);
        iter_string_multi_value_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_multi_value_test.validity);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags:= bronze", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_equals_test.init_status().ok());
    ASSERT_TRUE(iter_string_equals_test._get_is_filter_result_initialized());

    expected = {2, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_equals_test.validity);
        ASSERT_EQ(i, iter_string_equals_test.seq_id);
        iter_string_equals_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_equals_test.validity);

    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_equals_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                              enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_equals_test_2.init_status().ok());
    ASSERT_FALSE(iter_string_equals_test_2._get_is_filter_result_initialized());

    expected = {0, 2, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_equals_test_2.validity);
        ASSERT_EQ(i, iter_string_equals_test_2.seq_id);
        iter_string_equals_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_equals_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != [gold, silver]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    auto iter_string_not_equals_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                  enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_not_equals_test_2.init_status().ok());
    ASSERT_TRUE(iter_string_not_equals_test_2._get_is_filter_result_initialized());

    expected = {1, 5, 6};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_not_equals_test_2.validity);
        ASSERT_EQ(i, iter_string_not_equals_test_2.seq_id);
        iter_string_not_equals_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_not_equals_test_2.validity);

    coll->remove("0");
    coll->remove("2");

    doc = R"({
            "name": "James Rowdy",
            "age": 16,
            "years": [2022],
            "rating": 2.03,
            "tags": ["FINE PLATINUM"]
        })"_json;
    add_op = coll->add(doc.dump());
    ASSERT_TRUE(add_op.ok());

    delete filter_tree_root;

    Collection *bool_coll;

    std::vector<field> fields = {field("title", field_types::STRING, false),
                                 field("in_stock", field_types::BOOL, false),
                                 field("points", field_types::INT32, false),};

    bool_coll = collectionManager.get_collection("bool_coll").get();
    if(bool_coll == nullptr) {
        bool_coll = collectionManager.create_collection("bool_coll", 1, fields, "points").get();
    }

    for(size_t i=0; i<10; i++) {
        nlohmann::json bool_doc;

        bool_doc["title"] = "title_" + std::to_string(i);
        bool_doc["in_stock"] = (i < 5 || i % 2) ? "true" : "false";
        bool_doc["points"] = i;

        ASSERT_TRUE(bool_coll->add(bool_doc.dump()).ok());
    }

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("in_stock: false", bool_coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_boolean_test = filter_result_iterator_t(bool_coll->get_name(), bool_coll->_get_index(), filter_tree_root,
                                                      enable_lazy_evaluation);
    ASSERT_TRUE(iter_boolean_test.init_status().ok());
    ASSERT_TRUE(iter_boolean_test._get_is_filter_result_initialized());
    ASSERT_EQ(2, iter_boolean_test.approx_filter_ids_length);

    expected = {6, 8};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_boolean_test.validity);
        ASSERT_EQ(i, iter_boolean_test.seq_id);
        iter_boolean_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_boolean_test.validity);
    delete filter_tree_root;

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("in_stock: true", bool_coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_boolean_test_2 = filter_result_iterator_t(bool_coll->get_name(), bool_coll->_get_index(), filter_tree_root,
                                                        enable_lazy_evaluation);
    ASSERT_TRUE(iter_boolean_test_2.init_status().ok());
    ASSERT_FALSE(iter_boolean_test_2._get_is_filter_result_initialized());
    ASSERT_EQ(8, iter_boolean_test_2.approx_filter_ids_length);

    expected = {0, 1, 2, 3, 4, 5, 7, 9};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_boolean_test_2.validity);
        ASSERT_EQ(i, iter_boolean_test_2.seq_id);
        iter_boolean_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_boolean_test_2.validity);

    iter_boolean_test_2.reset();

    expected = {0, 1, 2, 3, 4, 5, 7, 9};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_boolean_test_2.validity);
        ASSERT_EQ(i, iter_boolean_test_2.seq_id);
        iter_boolean_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_boolean_test_2.validity);

    iter_boolean_test_2.reset();
    ASSERT_EQ(0, iter_boolean_test_2.is_valid(6));
    ASSERT_EQ(filter_result_iterator_t::valid, iter_boolean_test_2.validity);
    ASSERT_EQ(7, iter_boolean_test_2.seq_id);

    ASSERT_EQ(0, iter_boolean_test_2.is_valid(8));
    ASSERT_EQ(filter_result_iterator_t::valid, iter_boolean_test_2.validity);
    ASSERT_EQ(9, iter_boolean_test_2.seq_id);

    ASSERT_EQ(-1, iter_boolean_test_2.is_valid(10));
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_boolean_test_2.validity);
    delete filter_tree_root;

    doc = R"({
            "name": "James rock",
            "age": 20,
            "years": [],
            "rating": 4.51,
            "tags": ["gallium", "Gadolinium"]
        })"_json;
    add_op = coll->add(doc.dump());
    ASSERT_TRUE(add_op.ok());

    search_stop_us = UINT64_MAX; // `Index::fuzzy_search_fields` checks for timeout.
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: g*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_prefix_value_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                  enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_prefix_value_test.init_status().ok());
    ASSERT_FALSE(iter_string_prefix_value_test._get_is_filter_result_initialized());
    ASSERT_EQ(3, iter_string_prefix_value_test.approx_filter_ids_length); // document 0 and 2 have been deleted.

    expected = {4, 8};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_prefix_value_test.validity);
        ASSERT_EQ(i, iter_string_prefix_value_test.seq_id);
        iter_string_prefix_value_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_prefix_value_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != g*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_prefix_value_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                    enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_prefix_value_test_2.init_status().ok());
    ASSERT_FALSE(iter_string_prefix_value_test_2._get_is_filter_result_initialized());
    ASSERT_EQ(4, iter_string_prefix_value_test_2.approx_filter_ids_length); // 7 total docs, 3 approx count for equals.

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    seq_ids = {1, 2, 3, 4, 5, 6, 7, 8, 9, 9};
    expected = {1, 1, 1, 1, 0, 1, 1, 1, 0, -1};
    std::vector<uint32_t > equals_match_seq_ids = {4, 4, 4, 4, 4, 8, 8, 8, 8, 8};
    std::vector<bool> equals_iterator_valid = {true, true, true, true, true, true, true, true, true, true};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_prefix_value_test_2.validity);
        ASSERT_EQ(expected[i], iter_string_prefix_value_test_2.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_string_prefix_value_test_2._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_string_prefix_value_test_2._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_string_prefix_value_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_string_prefix_value_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_prefix_value_test_2.validity);

    delete filter_tree_root;
}

TEST_F(FilterTest, MissingFilterLazyEvaluationComputeIterators) {
    auto schema = R"({
        "name": "products",
        "fields": [
            {"name": "title", "type": "string"},
            {"name": "color", "type": "string", "optional": true, "track_missing_values": true}
        ]
    })"_json;

    auto op = collectionManager.create_collection(schema);
    ASSERT_TRUE(op.ok());
    auto coll = op.get();

    std::set<int> has_color = {0, 1, 5};
    for (int i = 0; i < 6; i++) {
        nlohmann::json doc;
        doc["id"] = std::to_string(i);
        doc["title"] = "Product " + std::to_string(i);
        if (has_color.count(i)) {
            doc["color"] = "color_" + std::to_string(i);
        }
        ASSERT_TRUE(coll->add(doc.dump()).ok());
    }

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("color: !_missing", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_missing = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root, true);
    ASSERT_TRUE(iter_missing.init_status().ok());
    ASSERT_FALSE(iter_missing._get_is_filter_result_initialized());

    uint32_t* filter_ids = nullptr;
    iter_missing.compute_iterators();

    const uint32_t filter_ids_length = iter_missing.to_filter_id_array(filter_ids);
    ASSERT_EQ(3, filter_ids_length);

    std::vector<uint32_t> expected = {0, 1, 5};
    for (uint32_t i = 0; i < filter_ids_length; i++) {
        ASSERT_EQ(expected[i], filter_ids[i]);
    }

    delete[] filter_ids;
    delete filter_tree_root;
    collectionManager.drop_collection("products");
}

TEST_F(FilterTest, FilterTreeIteratorTimeout) {
    auto count = 20;
    auto filter_ids = new uint32_t[count];
    for (auto i = 0; i < count; i++) {
        filter_ids[i] = i;
    }
    auto filter_iterator = new filter_result_iterator_t(filter_ids, count, DEFAULT_FILTER_BY_CANDIDATES,
                                                        std::chrono::duration_cast<std::chrono::microseconds>(
                                                        std::chrono::system_clock::now().time_since_epoch()).count(),
                                                        10000000); // Timeout after 10 seconds
    std::unique_ptr<filter_result_iterator_t> filter_iter_guard(filter_iterator);

    ASSERT_EQ(filter_result_iterator_t::valid, filter_iterator->validity);
    std::this_thread::sleep_for(std::chrono::seconds(5));

    for (auto i = 0; i < 20; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, filter_iterator->validity);
        filter_iterator->next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, filter_iterator->validity); // End of iterator reached.

    filter_iterator->reset();
    ASSERT_EQ(filter_result_iterator_t::valid, filter_iterator->validity);
    std::this_thread::sleep_for(std::chrono::seconds(5));

    for (auto i = 0; i < 9; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, filter_iterator->validity);
        filter_iterator->next();
    }
    ASSERT_EQ(filter_result_iterator_t::timed_out, filter_iterator->validity);

    filter_iterator->reset();
    ASSERT_EQ(filter_result_iterator_t::timed_out, filter_iterator->validity); // Resetting won't help with timeout.

    uint32_t excluded_result_index = 0;
    auto result = new filter_result_t();
    filter_iterator->get_n_ids(count, excluded_result_index, nullptr, 0, result);

    ASSERT_EQ(0, result->count); // Shouldn't return results
    delete result;

    filter_iterator->reset(true);
    result = new filter_result_t();
    filter_iterator->get_n_ids(count, excluded_result_index, nullptr, 0, result, true);

    ASSERT_EQ(count, result->count); // With `curation_timeout` true, we should get result.
    delete result;
}

TEST_F(FilterTest, FilterTreeInitialization) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "age", "type": "int32"},
                    {"name": "years", "type": "int32[]"},
                    {"name": "rating", "type": "float"},
                    {"name": "tags", "type": "string[]"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::string json_line;
    while (std::getline(infile, json_line)) {
        auto add_op = coll->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }
    infile.close();

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("age: 0 && (rating: >0 && years: 2016)", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto const enable_lazy_evaluation = true;
    auto iter_left_subtree_0_matches = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                enable_lazy_evaluation);

    ASSERT_TRUE(iter_left_subtree_0_matches.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_left_subtree_0_matches.validity);
    ASSERT_EQ(0, iter_left_subtree_0_matches.approx_filter_ids_length);
    ASSERT_TRUE(iter_left_subtree_0_matches._get_is_filter_result_initialized());
    ASSERT_EQ(nullptr, iter_left_subtree_0_matches._get_left_it());
    ASSERT_EQ(nullptr, iter_left_subtree_0_matches._get_right_it());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("(rating: >0 && years: 2016) && age: 0", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_right_subtree_0_matches = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);

    ASSERT_TRUE(iter_right_subtree_0_matches.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_right_subtree_0_matches.validity);
    ASSERT_EQ(0, iter_right_subtree_0_matches.approx_filter_ids_length);
    ASSERT_TRUE(iter_right_subtree_0_matches._get_is_filter_result_initialized());
    ASSERT_EQ(nullptr, iter_right_subtree_0_matches._get_left_it());
    ASSERT_EQ(nullptr, iter_right_subtree_0_matches._get_right_it());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("(age: 0 && rating: >0) || (age: 0 && rating: >0)", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_inner_subtree_0_matches = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);

    ASSERT_TRUE(iter_inner_subtree_0_matches.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_inner_subtree_0_matches.validity);
    ASSERT_EQ(0, iter_inner_subtree_0_matches.approx_filter_ids_length);
    ASSERT_FALSE(iter_inner_subtree_0_matches._get_is_filter_result_initialized());
    ASSERT_NE(nullptr, iter_inner_subtree_0_matches._get_left_it());
    ASSERT_NE(nullptr, iter_inner_subtree_0_matches._get_right_it());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    auto add_op = coll->add(
            R"({"name": "Jeremy Howard", "top_3": [0, 0.0, 0.0], "rating": 0.0,"age": 63, "years": [1981, 1985],
                 "timestamps": [348974822, 475205222], "tags": ["silver"]})");
    ASSERT_TRUE(add_op.ok());
    std::string dirty_values = "DROP";
    auto alter_op = coll->update_matching_filter("id: 0", R"({"tags": ["gold"]})", dirty_values);
    ASSERT_TRUE(alter_op.ok());

    filter_op = filter::parse_filter_query("years:!= 2016 && tags: != silver", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_0_matches = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                   filter_tree_root, enable_lazy_evaluation);

    ASSERT_TRUE(iter_0_matches.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::valid, iter_0_matches.validity);
    ASSERT_FALSE(iter_0_matches._get_is_filter_result_initialized());
    ASSERT_EQ(3, iter_0_matches.approx_filter_ids_length);

    iter_0_matches.compute_iterators();
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_0_matches.validity);
    ASSERT_TRUE(iter_0_matches._get_is_filter_result_initialized());
    ASSERT_EQ(0, iter_0_matches.approx_filter_ids_length);

    delete filter_tree_root;
    filter_tree_root = nullptr;
}

TEST_F(FilterTest, NotEqualsStringFilter) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "tags", "type": "string[]"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::string json_line;
    while (std::getline(infile, json_line)) {
        auto add_op = coll->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }
    infile.close();

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("tags:!= gold", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto const enable_lazy_evaluation = true;
    auto computed_not_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(computed_not_equals_test.init_status().ok());
    ASSERT_TRUE(computed_not_equals_test._get_is_filter_result_initialized());

    std::vector<int> expected = {1, 3};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_not_equals_test.validity);
        ASSERT_EQ(i, computed_not_equals_test.seq_id);
        computed_not_equals_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_not_equals_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != fine platinum", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_not_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_not_equals_test.init_status().ok());
    ASSERT_FALSE(iter_string_not_equals_test._get_is_filter_result_initialized());

    std::vector<uint32_t> validate_ids = {0, 1, 2, 3, 4, 5};
    std::vector<uint32_t> seq_ids = {1, 2, 3, 4, 5, 5};
    std::vector<uint32_t> equals_match_seq_ids = {1, 1, 1, 1, 1, 1};
    std::vector<bool> equals_iterator_valid = {true, true, false, false, false, false};
    expected = {1, 0, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_not_equals_test.validity);
        ASSERT_EQ(expected[i], iter_string_not_equals_test.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_string_not_equals_test._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_string_not_equals_test._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_string_not_equals_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_string_not_equals_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_not_equals_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != [gold, silver]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    auto iter_string_array_not_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                      enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_array_not_equals_test.init_status().ok());
    ASSERT_FALSE(iter_string_array_not_equals_test._get_is_filter_result_initialized());
    ASSERT_EQ(5, iter_string_array_not_equals_test.approx_filter_ids_length);

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {0, 1, 0, 0, 0, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_array_not_equals_test.validity);
        ASSERT_EQ(expected[i], iter_string_array_not_equals_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_string_array_not_equals_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_string_array_not_equals_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_array_not_equals_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    auto docs = {
            R"({
                "name": "James Rowdy",
                "tags": ["copper"]
            })"_json,
            R"({
                "name": "James Rowdy",
                "tags": ["copper"]
            })"_json,
            R"({
                "name": "James Rowdy",
                "tags": ["gold"]
            })"_json
    };

    for (auto const& doc: docs) {
        auto add_op = coll->add(doc.dump());
        ASSERT_TRUE(add_op.ok());
    }

    filter_op = filter::parse_filter_query("tags: != gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_string_not_equals_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                  enable_lazy_evaluation);
    ASSERT_TRUE(iter_string_not_equals_test_2.init_status().ok());
    ASSERT_FALSE(iter_string_not_equals_test_2._get_is_filter_result_initialized());

    validate_ids = {1, 2, 3, 4, 5, 6, 7, 8};
    seq_ids = {2, 3, 4, 5, 6, 7, 8, 8};
    expected = {1, 0, 1, 0, 1, 1, 0, -1};
    equals_match_seq_ids = {2, 2, 4, 4, 7, 7, 7, 7};
    equals_iterator_valid = {true, true, true, true, true, true, true, true};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_not_equals_test_2.validity);
        ASSERT_EQ(expected[i], iter_string_not_equals_test_2.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_string_not_equals_test_2._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_string_not_equals_test_2._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_string_not_equals_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_string_not_equals_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_not_equals_test_2.validity);

    iter_string_not_equals_test_2.reset();
    validate_ids = {2, 5, 7, 8};
    seq_ids = {3, 6, 8, 8};
    expected = {0, 1, 0, -1};
    equals_match_seq_ids = {2, 7, 7, 7};
    equals_iterator_valid = {true, true, true, true};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_string_not_equals_test_2.validity);
        ASSERT_EQ(expected[i], iter_string_not_equals_test_2.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_string_not_equals_test_2._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_string_not_equals_test_2._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_string_not_equals_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_string_not_equals_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_string_not_equals_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("name: James || tags: != bronze", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_or_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                            filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_or_test.init_status().ok());
    ASSERT_FALSE(iter_not_equals_or_test._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    seq_ids = {1, 2, 3, 4, 5, 6, 7, 8, 8};
    expected = {1, 1, 0, 1, 0, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_or_test.validity);
        ASSERT_EQ(expected[i], iter_not_equals_or_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_or_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_or_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_or_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != silver || tags: != gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_or_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                               filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_or_test_2.init_status().ok());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    seq_ids = {1, 2, 3, 4, 5, 6, 7, 8, 8};
    expected = {0, 1, 1, 1, 0, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_or_test_2.validity);
        ASSERT_EQ(expected[i], iter_not_equals_or_test_2.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_or_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_or_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_or_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: James && tags: != gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_and_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                             filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_and_test.init_status().ok());
    ASSERT_FALSE(iter_not_equals_and_test._get_is_filter_result_initialized());

    iter_not_equals_and_test.compute_iterators();
    ASSERT_TRUE(iter_not_equals_and_test._get_is_filter_result_initialized());

    validate_ids = {4, 5, 6, 7};
    seq_ids = {5, 6, 6, 6};
    expected = {0, 1, 1, -1};

    ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_and_test.validity);
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_not_equals_and_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_and_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_and_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_and_test.validity);

    // Lazy evaluation.
    iter_not_equals_and_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                        filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_and_test.init_status().ok());
    ASSERT_FALSE(iter_not_equals_and_test._get_is_filter_result_initialized());

    validate_ids = {5, 6, 7, 8};
    seq_ids = {6, 7, 8, 8};
    expected = {1, 1, 0, -1};

    ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_and_test.validity);
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_not_equals_and_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_and_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_and_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_and_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("tags: != silver && tags: != gold", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_and_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_and_test_2.init_status().ok());
    ASSERT_FALSE(iter_not_equals_and_test_2._get_is_filter_result_initialized());

    iter_not_equals_and_test_2.compute_iterators();
    ASSERT_TRUE(iter_not_equals_and_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    seq_ids = {1, 5, 5, 5, 5, 6, 6, 6, 6};
    expected = {0, 1, 0, 0, 0, 1, 1, -1, -1};

    ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_and_test_2.validity);
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_not_equals_and_test_2.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_and_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_and_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_and_test_2.validity);

    // Lazy evaluation.
    iter_not_equals_and_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                          filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_and_test_2.init_status().ok());
    ASSERT_FALSE(iter_not_equals_and_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    seq_ids = {1, 2, 3, 4, 5, 6, 7, 8, 8};
    expected = {0, 1, 0, 0, 0, 1, 1, 0, -1};

    ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_and_test_2.validity);
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(expected[i], iter_not_equals_and_test_2.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_and_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_and_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_and_test_2.validity);

    delete filter_tree_root;
}

TEST_F(FilterTest, NumericFilterIterator) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "rating", "type": "float"},
                    {"name": "age", "type": "int32"},
                    {"name": "years", "type": "int32[]"},
                    {"name": "timestamps", "type": "int64[]"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    std::ifstream infile(std::string(ROOT_DIR)+"test/numeric_array_documents.jsonl");
    std::string json_line;
    while (std::getline(infile, json_line)) {
        auto add_op = coll->add(json_line);
        ASSERT_TRUE(add_op.ok());
    }
    infile.close();

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("age: > 32", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto const enable_lazy_evaluation = true;
    auto const disable_lazy_evaluation = false;
    auto computed_greater_than_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                               enable_lazy_evaluation);
    ASSERT_TRUE(computed_greater_than_test.init_status().ok());
    ASSERT_TRUE(computed_greater_than_test._get_is_filter_result_initialized());

    std::vector<int> expected = {1, 3};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_greater_than_test.validity);
        ASSERT_EQ(i, computed_greater_than_test.seq_id);
        computed_greater_than_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_greater_than_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: >= 32", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_greater_than_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_greater_than_test.init_status().ok());
    ASSERT_FALSE(iter_greater_than_test._get_is_filter_result_initialized());

    std::vector<uint32_t> validate_ids = {0, 1, 2, 3, 4, 5};
    std::vector<uint32_t> seq_ids = {1, 3, 3, 4, 4, 4};
    expected = {0, 1, 0, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_greater_than_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test.validity);
        }
        ASSERT_EQ(expected[i], iter_greater_than_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_greater_than_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_greater_than_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test.validity);

    iter_greater_than_test.reset();
    validate_ids = {0, 1, 3, 5};
    seq_ids = {1, 3, 4, 4};
    expected = {0, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_greater_than_test.validity);
        ASSERT_EQ(expected[i], iter_greater_than_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_greater_than_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_greater_than_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_greater_than_test_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                        filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_greater_than_test_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_greater_than_test_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {0, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_greater_than_test_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_greater_than_test_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_greater_than_test_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_greater_than_test_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: != 21", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                         enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_test.init_status().ok());
    ASSERT_FALSE(iter_not_equals_test._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 1, 0, 1, 1, -1};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test.validity);
        ASSERT_EQ(expected[i], iter_not_equals_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_not_equals_test_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                      filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_not_equals_test_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_not_equals_test_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {1, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_not_equals_test_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_not_equals_test_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_not_equals_test_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: != [21]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_test_2.init_status().ok());
    ASSERT_FALSE(iter_not_equals_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 1, 0, 1, 1, -1};
    std::vector<bool> equals_iterator_valid = {true, true, true, false, false, false};
    std::vector<uint32_t> equals_match_seq_ids = {2, 2, 2, 2, 2, 2};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_2.validity);
        ASSERT_EQ(expected[i], iter_not_equals_test_2.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_not_equals_test_2._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_not_equals_test_2._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_not_equals_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_2.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_not_equals_test_2_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                        filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_not_equals_test_2_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_not_equals_test_2_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {1, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_2_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_not_equals_test_2_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_not_equals_test_2_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_not_equals_test_2_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_2_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: [<=21, >32]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 3, 3, 3};
    expected = {0, 1, 1, 1, -1, -1};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 4) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter.validity);
        }
        ASSERT_EQ(expected[i], iter_multivalue_filter.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_multivalue_filter.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                        filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 2, 3, 3, 3, 3};
        expected = {0, 1, 1, 1, -1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: != [<24, >44]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter_2.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 1, 0, 0, 1, -1};
    equals_iterator_valid = {true, true, true, true, false, false};
    equals_match_seq_ids = {2, 2, 2, 3, 3, 3};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_2.validity);
        ASSERT_EQ(expected[i], iter_multivalue_filter_2.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_multivalue_filter_2._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_multivalue_filter_2._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_multivalue_filter_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_2.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_2_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_2_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_2_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 4, 4, 4, 4, 4};
        expected = {1, 1, 0, 0, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_2_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_2_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_2_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_2_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_2_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("age: [21..32, >44]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter_3 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter_3.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter_3._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {2, 2, 3, 4, 4, 4};
    expected = {1, 0, 1, 1, 1, -1};
    equals_iterator_valid = {true, true, true, true, true, false};
    equals_match_seq_ids = {0, 2, 2, 3, 4, 4};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_3.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_3.validity);
        }
        ASSERT_EQ(expected[i], iter_multivalue_filter_3.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_multivalue_filter_3._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_multivalue_filter_3._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_multivalue_filter_3.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter_3.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_3.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_3_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_3_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_3_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {2, 2, 3, 4, 4, 4};
        expected = {1, 0, 1, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_3_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_3_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_3_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_3_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_3_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: <5", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto computed_greater_than_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);
    ASSERT_TRUE(computed_greater_than_test_2.init_status().ok());
    ASSERT_TRUE(computed_greater_than_test_2._get_is_filter_result_initialized());

    expected = {0, 3};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_greater_than_test_2.validity);
        ASSERT_EQ(i, computed_greater_than_test_2.seq_id);
        computed_greater_than_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_greater_than_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: >5", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_greater_than_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_greater_than_test_2.init_status().ok());
    ASSERT_FALSE(iter_greater_than_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 4, 4, 4, 4};
    expected = {0, 1, 1, 0, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_greater_than_test_2.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test_2.validity);
        }
        ASSERT_EQ(expected[i], iter_greater_than_test_2.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_greater_than_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_greater_than_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test_2.validity);

    iter_greater_than_test_2.reset();
    validate_ids = {0, 1, 4, 5};
    seq_ids = {1, 2, 4, 4};
    expected = {0, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 3) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_greater_than_test_2.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test_2.validity);
        }
        ASSERT_EQ(expected[i], iter_greater_than_test_2.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_greater_than_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_greater_than_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_greater_than_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: != 7.812", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_test_3 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_test_3.init_status().ok());
    ASSERT_FALSE(iter_not_equals_test_3._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 1, 0, 1, 1, -1};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_3.validity);
        ASSERT_EQ(expected[i], iter_not_equals_test_3.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_not_equals_test_3.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_test_3.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_3.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_not_equals_test_3_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                        filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_not_equals_test_3_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_not_equals_test_3_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {1, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_3_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_not_equals_test_3_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_not_equals_test_3_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_not_equals_test_3_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_3_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: != [7.812]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_not_equals_test_4 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_not_equals_test_4.init_status().ok());
    ASSERT_FALSE(iter_not_equals_test_4._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 1, 0, 1, 1, -1};
    equals_iterator_valid = {true, true, true, false, false, false};
    equals_match_seq_ids = {2, 2, 2, 2, 2, 2};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_4.validity);
        ASSERT_EQ(expected[i], iter_not_equals_test_4.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_not_equals_test_4._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_not_equals_test_4._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_not_equals_test_4.next();
        }
        ASSERT_EQ(seq_ids[i], iter_not_equals_test_4.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_4.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_not_equals_test_4_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                        filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_not_equals_test_4_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_not_equals_test_4_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {1, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_not_equals_test_4_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_not_equals_test_4_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_not_equals_test_4_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_not_equals_test_4_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_not_equals_test_4_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: [< 1, >6]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter_4 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter_4.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter_4._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 3, 3, 3};
    expected = {0, 1, 1, 1, -1, -1};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 4) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_4.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_4.validity);
        }
        ASSERT_EQ(expected[i], iter_multivalue_filter_4.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            iter_multivalue_filter_4.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter_4.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_4.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_4_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_4_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_4_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 2, 3, 3, 3, 3};
        expected = {0, 1, 1, 1, -1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_4_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_4_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_4_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_4_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_4_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: != [<1, >8]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter_5 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter_5.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter_5._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 5, 5};
    expected = {1, 0, 1, 0, 1, -1};
    equals_iterator_valid = {true, true, true, true, false, false};
    equals_match_seq_ids = {1, 1, 3, 3, 3, 3};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_5.validity);
        ASSERT_EQ(expected[i], iter_multivalue_filter_5.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_multivalue_filter_5._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_multivalue_filter_5._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_multivalue_filter_5.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter_5.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_5.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_5_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_5_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_5_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {2, 2, 4, 4, 4, 4};
        expected = {1, 0, 1, 0, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_5_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_5_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_5_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_5_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_5_non_lazy.validity);
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("rating: [0..6, >8]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_multivalue_filter_6 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_multivalue_filter_6.init_status().ok());
    ASSERT_FALSE(iter_multivalue_filter_6._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 3, 3, 4, 4, 4};
    expected = {1, 1, 0, 1, 1, -1};
    equals_iterator_valid = {true, true, true, true, true, false};
    equals_match_seq_ids = {0, 1, 3, 3, 4, 4};

    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_6.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_6.validity);
        }
        ASSERT_EQ(expected[i], iter_multivalue_filter_6.is_valid(validate_ids[i]));

        ASSERT_EQ(equals_iterator_valid[i], iter_multivalue_filter_6._get_is_equals_iterator_valid());
        ASSERT_EQ(equals_match_seq_ids[i], iter_multivalue_filter_6._get_equals_iterator_id());

        if (expected[i] == 1) {
            iter_multivalue_filter_6.next();
        }
        ASSERT_EQ(seq_ids[i], iter_multivalue_filter_6.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_6.validity);

    // With enable_lazy_evaluation = false, filter result should be initialized.
    {
        auto iter_multivalue_filter_6_non_lazy = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                                          filter_tree_root, disable_lazy_evaluation);
        ASSERT_TRUE(iter_multivalue_filter_6_non_lazy.init_status().ok());
        ASSERT_TRUE(iter_multivalue_filter_6_non_lazy._get_is_filter_result_initialized());

        validate_ids = {0, 1, 2, 3, 4, 5};
        seq_ids = {1, 3, 3, 4, 4, 4};
        expected = {1, 1, 0, 1, 1, -1};

        ASSERT_EQ(filter_result_iterator_t::valid, iter_multivalue_filter_6_non_lazy.validity);
        for (uint32_t i = 0; i < validate_ids.size(); i++) {
            ASSERT_EQ(expected[i], iter_multivalue_filter_6_non_lazy.is_valid(validate_ids[i]));

            if (expected[i] == 1) {
                iter_multivalue_filter_6_non_lazy.next();
            }
            ASSERT_EQ(seq_ids[i], iter_multivalue_filter_6_non_lazy.seq_id);
        }
        ASSERT_EQ(filter_result_iterator_t::invalid, iter_multivalue_filter_6_non_lazy.validity);
    }

    delete filter_tree_root;
}

TEST_F(FilterTest, StandaloneExclamationFilterSyntax) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "age", "type": "int32"},
                    {"name": "rating", "type": "float"},
                    {"name": "is_active", "type": "bool"},
                    {"name": "tags", "type": "string[]"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    nlohmann::json doc1;
    doc1["name"] = "Alice";
    doc1["age"] = 25;
    doc1["rating"] = 4.5;
    doc1["is_active"] = true;
    doc1["tags"] = {"active", "premium"};
    auto add_op = coll->add(doc1.dump());
    ASSERT_TRUE(add_op.ok());

    nlohmann::json doc2;
    doc2["name"] = "Bob";
    doc2["age"] = 30;
    doc2["rating"] = 3.8;
    doc2["is_active"] = false;
    doc2["tags"] = {"inactive"};
    add_op = coll->add(doc2.dump());
    ASSERT_TRUE(add_op.ok());

    nlohmann::json doc3;
    doc3["name"] = "Charlie";
    doc3["age"] = 25;
    doc3["rating"] = 4.2;
    doc3["is_active"] = true;
    doc3["tags"] = {"active"};
    add_op = coll->add(doc3.dump());
    ASSERT_TRUE(add_op.ok());

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("age:![25]", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto results = coll->search("*", {}, "age:![25]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("age:![25, 30]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    results = coll->search("*", {}, "age:![25, 30]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["found"].get<size_t>());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("rating:![4.5]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    results = coll->search("*", {}, "rating:![4.5]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("is_active:![true]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    results = coll->search("*", {}, "is_active:![true]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("is_active:![true, false]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    results = coll->search("*", {}, "is_active:![true, false]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(0, results["found"].get<size_t>());

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("age:!=[25]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto results_traditional = coll->search("*", {}, "age:!=[25]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    auto results_new = coll->search("*", {}, "age:![25]", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    
    ASSERT_EQ(results_traditional["found"].get<size_t>(), results_new["found"].get<size_t>());
    ASSERT_EQ(results_traditional["hits"][0]["document"]["name"].get<std::string>(),
              results_new["hits"][0]["document"]["name"].get<std::string>());

    delete filter_tree_root;
    collectionManager.drop_collection("Collection");
}

TEST_F(FilterTest, StandaloneExclamationFilterValidation) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "age", "type": "int32"},
                    {"name": "rating", "type": "float"},
                    {"name": "is_active", "type": "bool"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();
    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    auto filter_op = filter::parse_filter_query("age:!", coll->get_schema(), store, doc_id_prefix,
                                                filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Filter value cannot be empty after '!' operator") != std::string::npos);

    filter_op = filter::parse_filter_query("rating:!", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Filter value cannot be empty after '!' operator") != std::string::npos);

    filter_op = filter::parse_filter_query("is_active:!", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Filter value cannot be empty after '!' operator") != std::string::npos);

    filter_op = filter::parse_filter_query("age:!   ", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Filter value cannot be empty after '!' operator") != std::string::npos);

    filter_op = filter::parse_filter_query("age:!=", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Not an int32") != std::string::npos);

    filter_op = filter::parse_filter_query("rating:!=", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Not a float") != std::string::npos);

    filter_op = filter::parse_filter_query("is_active:!=", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_FALSE(filter_op.ok());
    ASSERT_TRUE(filter_op.error().find("Filter value cannot be empty") != std::string::npos);

    collectionManager.drop_collection("Collection");
}

TEST_F(FilterTest, StandaloneExclamationSingleValues) {
    nlohmann::json schema =
            R"({
                "name": "Collection",
                "fields": [
                    {"name": "name", "type": "string"},
                    {"name": "age", "type": "int32"},
                    {"name": "rating", "type": "float"},
                    {"name": "is_active", "type": "bool"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    nlohmann::json doc1;
    doc1["name"] = "Alice";
    doc1["age"] = 25;
    doc1["rating"] = 4.5;
    doc1["is_active"] = true;
    auto add_op = coll->add(doc1.dump());
    ASSERT_TRUE(add_op.ok());

    nlohmann::json doc2;
    doc2["name"] = "Bob";
    doc2["age"] = 30;
    doc2["rating"] = 3.8;
    doc2["is_active"] = false;
    add_op = coll->add(doc2.dump());
    ASSERT_TRUE(add_op.ok());

    nlohmann::json doc3;
    doc3["name"] = "Charlie";
    doc3["age"] = 25;
    doc3["rating"] = 4.2;
    doc3["is_active"] = true;
    add_op = coll->add(doc3.dump());
    ASSERT_TRUE(add_op.ok());

    auto results = coll->search("*", {}, "age:25", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "age:!25", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    results = coll->search("*", {}, "rating:4.5", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Alice", results["hits"][0]["document"]["name"].get<std::string>());

    results = coll->search("*", {}, "rating:!4.5", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "is_active:true", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "is_active:!true", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    auto results_traditional = coll->search("*", {}, "age:!=25", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    auto results_new = coll->search("*", {}, "age:!25", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    
    ASSERT_EQ(results_traditional["found"].get<size_t>(), results_new["found"].get<size_t>());
    ASSERT_EQ(results_traditional["hits"][0]["document"]["name"].get<std::string>(),
              results_new["hits"][0]["document"]["name"].get<std::string>());

    results = coll->search("*", {}, "age:!=25", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    results = coll->search("*", {}, "rating:!=4.5", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(2, results["found"].get<size_t>());

    results = coll->search("*", {}, "is_active:!=true", {}, {}, {0}, 10, 1, FREQUENCY, {false}).get();
    ASSERT_EQ(1, results["found"].get<size_t>());
    ASSERT_EQ("Bob", results["hits"][0]["document"]["name"].get<std::string>());

    collectionManager.drop_collection("Collection");
}

TEST_F(FilterTest, PrefixStringFilter) {
    auto schema_json =
            R"({
                "name": "Names",
                "fields": [
                    {"name": "name", "type": "string"}
                ]
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({
                "name": "Steve Jobs"
            })"_json,
            R"({
                "name": "Adam Stator"
            })"_json,
    };

    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    Collection* coll = collection_create_op.get();
    for (auto const &json: documents) {
        auto add_op = coll->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    search_stop_us = UINT64_MAX; // `Index::fuzzy_search_fields` checks for timeout.
    Option<bool> filter_op = filter::parse_filter_query("name:= S*", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto const enable_lazy_evaluation = true;
    auto computed_exact_prefix_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                               enable_lazy_evaluation);
    ASSERT_TRUE(computed_exact_prefix_test.init_status().ok());
    ASSERT_TRUE(computed_exact_prefix_test._get_is_filter_result_initialized());

    std::vector<int> expected = {0};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_exact_prefix_test.validity);
        ASSERT_EQ(i, computed_exact_prefix_test.seq_id);
        computed_exact_prefix_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_exact_prefix_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: S*", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto computed_contains_prefix_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                  enable_lazy_evaluation);
    ASSERT_TRUE(computed_contains_prefix_test.init_status().ok());
    ASSERT_TRUE(computed_contains_prefix_test._get_is_filter_result_initialized());

    expected = {0, 1};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_contains_prefix_test.validity);
        ASSERT_EQ(i, computed_contains_prefix_test.seq_id);
        computed_contains_prefix_test.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_contains_prefix_test.validity);

    delete filter_tree_root;

    documents = {
            R"({
                "name": "Steve Reiley"
            })"_json,
            R"({
                "name": "Storm"
            })"_json,
            R"({
                "name": "Steve Rogers"
            })"_json,
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name:= S*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_exact_prefix_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(iter_exact_prefix_test.init_status().ok());
    ASSERT_FALSE(iter_exact_prefix_test._get_is_filter_result_initialized());

    std::vector<uint32_t> validate_ids = {0, 1, 2, 3, 4, 5};
    std::vector<uint32_t> seq_ids = {2, 2, 3, 4, 4, 4};
    std::vector<uint32_t> equals_match_seq_ids = {0, 2, 2, 3, 4, 4};
    std::vector<bool> equals_iterator_valid = {true, true, true, true, true, false};
    expected = {1, 0, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_exact_prefix_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_prefix_test.validity);
        }
        ASSERT_EQ(expected[i], iter_exact_prefix_test.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_exact_prefix_test._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_exact_prefix_test._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_exact_prefix_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_exact_prefix_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_prefix_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: S*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_contains_prefix_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                              enable_lazy_evaluation);
    ASSERT_TRUE(iter_contains_prefix_test.init_status().ok());
    ASSERT_FALSE(iter_contains_prefix_test._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5};
    seq_ids = {1, 2, 3, 4, 4, 4};
    equals_match_seq_ids = {0, 1, 2, 3, 4, 4};
    equals_iterator_valid = {true, true, true, true, true, false};
    expected = {1, 1, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_contains_prefix_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_prefix_test.validity);
        }
        ASSERT_EQ(expected[i], iter_contains_prefix_test.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_contains_prefix_test._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_contains_prefix_test._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_contains_prefix_test.next();
        }
        ASSERT_EQ(seq_ids[i], iter_contains_prefix_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_prefix_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name:= Steve R*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto computed_exact_prefix_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                 enable_lazy_evaluation);
    ASSERT_TRUE(computed_exact_prefix_test_2.init_status().ok());
    ASSERT_TRUE(computed_exact_prefix_test_2._get_is_filter_result_initialized());

    expected = {2, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_exact_prefix_test_2.validity);
        ASSERT_EQ(i, computed_exact_prefix_test_2.seq_id);
        computed_exact_prefix_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_exact_prefix_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: Steve R*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto computed_contains_prefix_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                    enable_lazy_evaluation);
    ASSERT_TRUE(computed_contains_prefix_test_2.init_status().ok());
    ASSERT_TRUE(computed_contains_prefix_test_2._get_is_filter_result_initialized());

    expected = {2, 4};
    for (auto const& i : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, computed_contains_prefix_test_2.validity);
        ASSERT_EQ(i, computed_contains_prefix_test_2.seq_id);
        computed_contains_prefix_test_2.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, computed_contains_prefix_test_2.validity);

    delete filter_tree_root;

    documents = {
            R"({
                "name": "Steve Runner foo"
            })"_json,
            R"({
                "name": "foo Steve Runner"
            })"_json,
    };

    for (auto const &json: documents) {
        auto add_op = collection_create_op.get()->add(json.dump());
        ASSERT_TRUE(add_op.ok());
    }

    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name:= Steve R*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_exact_prefix_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                             enable_lazy_evaluation);
    ASSERT_TRUE(iter_exact_prefix_test_2.init_status().ok());
    ASSERT_FALSE(iter_exact_prefix_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7};
    seq_ids = {2, 2, 4, 4, 5, 5, 5, 5};
    equals_match_seq_ids = {2, 2, 2, 4, 4, 5, 5, 5};
    equals_iterator_valid = {true, true, true, true, true, true, false, false};
    expected = {0, 0, 1, 0, 1, 1, -1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 6) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_exact_prefix_test_2.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_prefix_test_2.validity);
        }
        ASSERT_EQ(expected[i], iter_exact_prefix_test_2.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_exact_prefix_test_2._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_exact_prefix_test_2._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_exact_prefix_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_exact_prefix_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_exact_prefix_test_2.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("name: Steve R*", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_contains_prefix_test_2 = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                                enable_lazy_evaluation);
    ASSERT_TRUE(iter_contains_prefix_test_2.init_status().ok());
    ASSERT_FALSE(iter_contains_prefix_test_2._get_is_filter_result_initialized());

    validate_ids = {0, 1, 2, 3, 4, 5, 6, 7};
    seq_ids = {2, 2, 4, 4, 5, 6, 6, 6};
    equals_match_seq_ids = {2, 2, 2, 4, 4, 5, 6, 6};
    equals_iterator_valid = {true, true, true, true, true, true, true, false};
    expected = {0, 0, 1, 0, 1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 7) {
            ASSERT_EQ(filter_result_iterator_t::valid, iter_contains_prefix_test_2.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_prefix_test_2.validity);
        }
        ASSERT_EQ(expected[i], iter_contains_prefix_test_2.is_valid(validate_ids[i]));
        ASSERT_EQ(equals_match_seq_ids[i], iter_contains_prefix_test_2._get_equals_iterator_id());
        ASSERT_EQ(equals_iterator_valid[i], iter_contains_prefix_test_2._get_is_equals_iterator_valid());

        if (expected[i] == 1) {
            iter_contains_prefix_test_2.next();
        }
        ASSERT_EQ(seq_ids[i], iter_contains_prefix_test_2.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_contains_prefix_test_2.validity);

    delete filter_tree_root;
}

TEST_F(FilterTest, IdFilterIterator) {
    Collection *coll;

    std::vector<field> fields = {field("company_name", field_types::STRING, false),
                                 field("num_employees", field_types::INT32, false),};

    coll = collectionManager.get_collection("coll1").get();
    if(coll == nullptr) {
        coll = collectionManager.create_collection("coll1", 1, fields, "num_employees").get();
    }

    std::vector<std::vector<std::string>> records = {
            {"123", "Company 1", "50"},
            {"125", "Company 2", "150"},
            {"127", "Company 3", "250"},
            {"129", "Stark Industries 4", "500"},
    };

    for(size_t i=0; i<records.size(); i++) {
        nlohmann::json doc;

        doc["id"] = records[i][0];
        doc["company_name"] = records[i][1];
        doc["num_employees"] = std::stoi(records[i][2]);

        ASSERT_TRUE(coll->add(doc.dump()).ok());
    }

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;

    Option<bool> filter_op = filter::parse_filter_query("id: *", coll->get_schema(), store, doc_id_prefix,
                                                        filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto const enable_lazy_evaluation = true;
    auto all_ids_match_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(all_ids_match_test.init_status().ok());
    ASSERT_FALSE(all_ids_match_test._get_is_filter_result_initialized());
    ASSERT_EQ(4, all_ids_match_test.approx_filter_ids_length);

    std::vector<uint32_t> validate_ids = {0, 1, 3, 4};
    std::vector<uint32_t> seq_ids = {1, 2, 3, 3};
    std::vector<int> expected = {1, 1, 1, -1};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 3) {
            ASSERT_EQ(filter_result_iterator_t::valid, all_ids_match_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, all_ids_match_test.validity);
        }
        ASSERT_EQ(expected[i], all_ids_match_test.is_valid(validate_ids[i]));

        if (expected[i] == 1) {
            all_ids_match_test.next();
        }
        ASSERT_EQ(seq_ids[i], all_ids_match_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, all_ids_match_test.validity);

    all_ids_match_test.reset();
    ASSERT_EQ(filter_result_iterator_t::valid, all_ids_match_test.validity);
    ASSERT_EQ(0, all_ids_match_test.seq_id);
    ASSERT_EQ(1, all_ids_match_test.is_valid(2));

    all_ids_match_test.compute_iterators();
    seq_ids = {0, 1, 2, 3};
    for (auto const& seq_id : seq_ids) {
        ASSERT_EQ(filter_result_iterator_t::valid, all_ids_match_test.validity);
        ASSERT_EQ(1, all_ids_match_test.is_valid(seq_id));
    }

    delete filter_tree_root;
    filter_tree_root = nullptr;
    filter_op = filter::parse_filter_query("id: != [foo, *, bar]", coll->get_schema(), store, doc_id_prefix,
                                           filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto no_ids_match_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                      enable_lazy_evaluation);
    ASSERT_TRUE(no_ids_match_test.init_status().ok());
    ASSERT_TRUE(no_ids_match_test._get_is_filter_result_initialized());
    ASSERT_EQ(0, no_ids_match_test.approx_filter_ids_length);
    ASSERT_EQ(filter_result_iterator_t::invalid, no_ids_match_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;
}

TEST_F(FilterTest, ObjectFitlterIterator) {
    auto schema_json =
            R"({
                "name": "menu",
                "fields": [
                    {"name": "name", "type": "string", "infix": true},
                    {"name": "ingredients", "type": "object[]"},
                    {"name": "ingredients.*", "type": "auto", "optional": true}
                ],
                "enable_nested_fields": true
            })"_json;
    std::vector<nlohmann::json> documents = {
            R"({ "name": "Pasta", "ingredients": [{"name": "cheese", "concentration": 40},
                                                {"name": "spinach", "concentration": 100},
                                                {"name": "jalepeno", "concentration": 20}]
        })"_json,
            R"({ "name": "Lasagna", "ingredients": [{"name": "cheese", "concentration": 60},
                                                {"name": "jalepeno", "concentration": 20},
                                                {"name": "olives", "concentration": 20}]
        })"_json,
            R"({ "name": "Pizza", "ingredients": [{"name": "cheese", "concentration": 30},
                                                {"name": "pizza sauce", "concentration": 30},
                                                {"name": "olives", "concentration": 30}]
        })"_json,
            R"({ "name": "Popcorn", "ingredients": [{"name": "cheese", "concentration": 30}]
        })"_json,
            R"({"name": "Pizza Rolls", "ingredients": [{"name": "cheese", "concentration": 60},
                                                {"name": "pizza sauce", "concentration": 5},
                                                {"name" : "corn", "concentration": 40}]
        })"_json
    };
    auto collection_create_op = collectionManager.create_collection(schema_json);
    ASSERT_TRUE(collection_create_op.ok());
    auto coll = collection_create_op.get();
    for (auto const& json: documents) {
        auto add_op = coll->add(json.dump());
        if (!add_op.ok()) {
            LOG(INFO) << add_op.error();
        }
        ASSERT_TRUE(add_op.ok());
    }
    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" + Collection::DOC_ID_PREFIX + "_";
    filter_node_t* filter_tree_root = nullptr;
    Option<bool> filter_op = filter::parse_filter_query("ingredients.{name : cheese && concentration : >50}",
                                                        coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    auto const enable_lazy_evaluation = true;
    auto root_object_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(root_object_filter_test.init_status().ok());
    ASSERT_FALSE(root_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(3, root_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(1, root_object_filter_test.seq_id);

    std::vector<uint32_t> validate_ids = {0, 1, 2, 3, 4, 5};    // Equivalent to `take_id()` call.
    std::vector<int> expected = {0, 1, 0, 0, 1, -1};            // The result of `is_valid()` call.
    std::vector<uint32_t> seq_ids = {1, 4, 4, 4, 4, 4};         // The id filter_result_iterator is at after `take_id()` call.
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, root_object_filter_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);
        }

        ASSERT_EQ(expected[i], root_object_filter_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            root_object_filter_test.next();
        }
        ASSERT_EQ(seq_ids[i], root_object_filter_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);

    root_object_filter_test.reset();
    ASSERT_EQ(filter_result_iterator_t::valid, root_object_filter_test.validity);
    ASSERT_EQ(0, root_object_filter_test.is_valid(0));
    ASSERT_EQ(1, root_object_filter_test.is_valid(1));
    ASSERT_EQ(-1, root_object_filter_test.is_valid(10));
    ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);

    root_object_filter_test.compute_iterators();
    ASSERT_TRUE(root_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(2, root_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(1, root_object_filter_test.seq_id);

    uint32_t excluded_result_index = 0;
    auto result = new filter_result_t();
    root_object_filter_test.get_n_ids(2, excluded_result_index, nullptr, 0, result);
    ASSERT_EQ(2, result->count);
    ASSERT_EQ(1, result->docs[0]);
    ASSERT_EQ(4, result->docs[1]);
    delete result;

    delete filter_tree_root;
    filter_op = filter::parse_filter_query("ingredients.{name : cheese && concentration : [25..45]}",
                                                        coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    root_object_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                            enable_lazy_evaluation);
    ASSERT_TRUE(root_object_filter_test.init_status().ok());
    ASSERT_FALSE(root_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(4, root_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(0, root_object_filter_test.seq_id);

    validate_ids = {0, 1, 2, 3, 4, 5};    // Equivalent to `take_id()` call.
    expected = {1, 0, 1, 1, -1, -1};      // The result of `is_valid()` call.
    seq_ids = {2, 2, 3, 4, 4, 4};         // The id filter_result_iterator is at after `take_id()` call.
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 4) {
            ASSERT_EQ(filter_result_iterator_t::valid, root_object_filter_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);
        }

        ASSERT_EQ(expected[i], root_object_filter_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            root_object_filter_test.next();
        }
        ASSERT_EQ(seq_ids[i], root_object_filter_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("ingredients.{name : cheese && concentration : >50} || "
                                           "ingredients.{name : cheese && concentration : [25..45]}",
                                           coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    auto or_object_filters_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(or_object_filters_test.init_status().ok());
    ASSERT_FALSE(or_object_filters_test._get_is_filter_result_initialized());
    ASSERT_EQ(7, or_object_filters_test.approx_filter_ids_length);
    ASSERT_EQ(0, or_object_filters_test.seq_id);

    validate_ids = {0, 1, 2, 3, 4, 5};
    expected = {1, 1, 1, 1, 1, -1};
    seq_ids = {1, 2, 3, 4, 4, 4};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, or_object_filters_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, or_object_filters_test.validity);
        }

        ASSERT_EQ(expected[i], or_object_filters_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            or_object_filters_test.next();
        }
        ASSERT_EQ(seq_ids[i], or_object_filters_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("ingredients.{ (name: spinach && concentration: >50) || "
                                                            "(name: jalepeno && concentration: [25..45]) ||"
                                                            "(name: pizza sauce && concentration: <30) }",
                                           coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());
    auto or_object_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(or_object_filter_test.init_status().ok());
    ASSERT_FALSE(or_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(3, or_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(0, or_object_filter_test.seq_id);

    validate_ids = {0, 1, 2, 3, 4, 5};
    expected = {1, 0, 0, 0, 1, -1};
    seq_ids = {4, 4, 4, 4, 4, 4};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, or_object_filter_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, or_object_filter_test.validity);
        }

        ASSERT_EQ(expected[i], or_object_filter_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            or_object_filter_test.next();
        }
        ASSERT_EQ(seq_ids[i], or_object_filter_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, root_object_filter_test.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    filter_op = filter::parse_filter_query("name: p* && ingredients.{name : cheese && concentration : [25..45]}",
                                           coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    search_stop_us = UINT64_MAX; // `Index::fuzzy_search_fields` checks for timeout.
    auto and_object_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                       enable_lazy_evaluation);
    ASSERT_TRUE(and_object_filter_test.init_status().ok());
    ASSERT_FALSE(and_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(4, and_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(0, and_object_filter_test.seq_id);

    validate_ids = {0, 1, 2, 3, 4, 5};
    expected = {1, 0, 1, 1, -1, -1};
    seq_ids = {2, 2, 3, 3, 3, 3};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 4) {
            ASSERT_EQ(filter_result_iterator_t::valid, and_object_filter_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, and_object_filter_test.validity);
        }

        ASSERT_EQ(expected[i], and_object_filter_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            and_object_filter_test.next();
        }
        ASSERT_EQ(seq_ids[i], and_object_filter_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, and_object_filter_test.validity);

    delete filter_tree_root;

    filter_op = filter::parse_filter_query("ingredients.{name: != spinach && concentration: >50}",
                                           coll->get_schema(), store, doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto not_object_filter_test = filter_result_iterator_t(coll->get_name(), coll->_get_index(), filter_tree_root,
                                                           enable_lazy_evaluation);
    ASSERT_TRUE(not_object_filter_test.init_status().ok());
    ASSERT_FALSE(not_object_filter_test._get_is_filter_result_initialized());
    ASSERT_EQ(3, not_object_filter_test.approx_filter_ids_length);
    ASSERT_EQ(1, not_object_filter_test.seq_id);

    validate_ids = {0, 1, 2, 3, 4, 5};
    expected = {0, 1, 0, 0, 1, -1};
    seq_ids = {1, 4, 4, 4, 4, 4};
    for (uint32_t i = 0; i < validate_ids.size(); i++) {
        if (i < 5) {
            ASSERT_EQ(filter_result_iterator_t::valid, not_object_filter_test.validity);
        } else {
            ASSERT_EQ(filter_result_iterator_t::invalid, not_object_filter_test.validity);
        }

        ASSERT_EQ(expected[i], not_object_filter_test.is_valid(validate_ids[i]));
        if (expected[i] == 1) { // We call `next()` in `take_id()` when there is a match.
            not_object_filter_test.next();
        }
        ASSERT_EQ(seq_ids[i], not_object_filter_test.seq_id);
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, not_object_filter_test.validity);

    delete filter_tree_root;
}

TEST_F(FilterTest, FilterReferences) {
    const size_t max_candidates = DEFAULT_FILTER_BY_CANDIDATES;
    const uint64_t search_begin_us = 0;
    const uint64_t search_stop_us = UINT64_MAX;
    auto filter_root = std::make_unique<filter_node_t>();
    auto left_refs = new std::map<std::string, reference_filter_result_t>[4]{
                            {{"foo", reference_filter_result_t(1, new uint32_t[1]{101})}},
                            {{"bar", reference_filter_result_t(1, new uint32_t[1]{102})}},
                            {{"foo", reference_filter_result_t(1, new uint32_t[1]{104})}},
                            {{"bar", reference_filter_result_t(1, new uint32_t[1]{105})}}};
    auto right_refs = new std::map<std::string, reference_filter_result_t>[4]{
                            {{"bar", reference_filter_result_t(1, new uint32_t[1]{100})}},
                            {{"foo", reference_filter_result_t(1, new uint32_t[1]{101})}},
                            {{"bar", reference_filter_result_t(1, new uint32_t[1]{103})}},
                            {{"bar", reference_filter_result_t(1, new uint32_t[1]{106})}}};
    auto fit = std::make_unique<filter_result_iterator_t>(
                                            AND,
                                            new filter_result_iterator_t(new uint32_t[4]{1, 2, 4, 6}, 4,
                                                                         max_candidates, search_begin_us, search_stop_us,
                                                                         left_refs),
                                            new filter_result_iterator_t(new uint32_t[4]{0, 1, 4, 6}, 4,
                                                                         max_candidates, search_begin_us, search_stop_us,
                                                                         right_refs),
                                            filter_root, new filter_node_t());

    std::vector<uint32_t> expected = {1, 4};
    std::vector<std::vector<std::string>> collection_names = {{"foo"}, {"foo", "bar"}};
    std::vector<std::vector<uint32_t>> ref_ids = {{101}, {104, 103}};
    for (size_t i = 0; i < 2; i++) {
        ASSERT_EQ(filter_result_iterator_t::valid, fit->validity);
        const auto& id = expected[i];
        ASSERT_EQ(id, fit->seq_id);

        for (size_t j = 0; j < collection_names[i].size(); j++) {
            const auto& name = collection_names[i][j];
            ASSERT_EQ(1, fit->reference.count(name));
            ASSERT_EQ(1, fit->reference[name].count);

            const auto& ref_id = ref_ids[i][j];
            ASSERT_EQ(ref_id, fit->reference[name].docs[0]);
        }

        fit->next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, fit->validity);
}

TEST_F(FilterTest, InfixLazyEvaluation) {
    // Collection with infix: true on cast (string[]) and points (int32).
    // Documents match the same schema used in CollectionFilteringTest.InfixFilterOnTextFields.
    nlohmann::json schema =
            R"({
                "name": "InfixLazyColl",
                "fields": [
                    {"name": "cast",   "type": "string[]", "infix": true},
                    {"name": "points", "type": "int32"}
                ]
            })"_json;

    Collection* coll = collectionManager.create_collection(schema).get();

    // seq_id 0: cast contains "chris" and "evans"
    // seq_id 1: cast contains "chris" and "parnell"
    // seq_id 2: cast contains "martin" and "stringer"
    // seq_id 3: cast contains "matt" and "damon"
    // seq_id 4: cast contains "logan" and "lerman"
    // seq_id 5: cast contains "chris" and "pine"
    std::vector<std::string> docs = {
        R"({"cast": ["Chris Evans", "Scarlett Johansson"], "points": 78})",
        R"({"cast": ["Chris Parnell", "Josh Lawson"],      "points": 63})",
        R"({"cast": ["Martin Stringer", "Jacob Stringer"], "points": 81})",
        R"({"cast": ["Matt Damon", "Ben Affleck"],         "points": 83})",
        R"({"cast": ["Logan Lerman", "Alexandra Daddario"],"points": 59})",
        R"({"cast": ["Chris Pine"],                        "points": 52})",
    };

    for (auto const& d : docs) {
        auto add_op = coll->add(d);
        ASSERT_TRUE(add_op.ok());
    }

    const std::string doc_id_prefix = std::to_string(coll->get_collection_id()) + "_" +
                                       Collection::DOC_ID_PREFIX + "_";
    auto const enable_lazy_evaluation = true;
    filter_node_t* filter_tree_root = nullptr;

    // Test 1: Basic infix *ris* — "chris" matches docs 0, 1, 5.
    // approx_filter_ids_length = 3 (docs in "chris" posting list).
    // In TEST_BUILD string_filter_ids_threshold = 3, so 3 < 3 is false → lazy path.
    auto filter_op = filter::parse_filter_query("cast: *ris*", coll->get_schema(), store,
                                                doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_infix_basic = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                     filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_infix_basic.init_status().ok());

    std::vector<uint32_t> expected = {0, 1, 5};
    for (auto const& id : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_infix_basic.validity);
        ASSERT_EQ(id, iter_infix_basic.seq_id);
        iter_infix_basic.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_infix_basic.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    // Test 2: No-match infix — iterator immediately invalid.
    filter_op = filter::parse_filter_query("cast: *zzz*", coll->get_schema(), store,
                                           doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_infix_no_match = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                        filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_infix_no_match.init_status().ok());
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_infix_no_match.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    // Test 3: OR of two infix values — [*ris*, *art*].
    // *ris*: "chris" → docs {0, 1, 5}
    // *art*: "martin" → docs {2}
    // approx_filter_ids_length = 3 + 1 = 4 > threshold=3 → lazy.
    filter_op = filter::parse_filter_query("cast: [*ris*, *art*]", coll->get_schema(), store,
                                           doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_infix_or = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                  filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_infix_or.init_status().ok());

    expected = {0, 1, 2, 5};
    for (auto const& id : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_infix_or.validity);
        ASSERT_EQ(id, iter_infix_or.seq_id);
        iter_infix_or.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_infix_or.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    // Test 4: Infix AND numeric — cast:*ris* && points:>60.
    // *ris*: docs {0, 1, 5}; points>60: docs {0, 1, 2, 3} → intersection = {0, 1}.
    filter_op = filter::parse_filter_query("cast: *ris* && points: >60", coll->get_schema(), store,
                                           doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_infix_and_numeric = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                           filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_infix_and_numeric.init_status().ok());

    expected = {0, 1};
    for (auto const& id : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_infix_and_numeric.validity);
        ASSERT_EQ(id, iter_infix_and_numeric.seq_id);
        iter_infix_and_numeric.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_infix_and_numeric.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    // Test 5: AND of two single-token infix conditions — cast:*ris* && cast:*in*.
    // *ris*: docs {0, 1, 5} (via "chris"); *in*: docs {2, 5} (via "martin"/"stringer" and "pine").
    // Intersection = {5}.
    filter_op = filter::parse_filter_query("cast: *ris* && cast: *in*", coll->get_schema(), store,
                                           doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());

    auto iter_two_infix_and = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                       filter_tree_root, enable_lazy_evaluation);
    ASSERT_TRUE(iter_two_infix_and.init_status().ok());

    expected = {5};
    for (auto const& id : expected) {
        ASSERT_EQ(filter_result_iterator_t::valid, iter_two_infix_and.validity);
        ASSERT_EQ(id, iter_two_infix_and.seq_id);
        iter_two_infix_and.next();
    }
    ASSERT_EQ(filter_result_iterator_t::invalid, iter_two_infix_and.validity);

    delete filter_tree_root;
    filter_tree_root = nullptr;

    // Test 6: Multi-token infix must return 400 — *ris pin* tokenizes to ["ris", "pin"].
    // The infix index stores individual word tokens only; substring search across word
    // boundaries is structurally impossible. Users should write cast:*ris* && cast:*pin* instead.
    filter_op = filter::parse_filter_query("cast: *ris pin*", coll->get_schema(), store,
                                           doc_id_prefix, filter_tree_root);
    ASSERT_TRUE(filter_op.ok());  // parse succeeds — parser stores raw value, unaware of token count

    auto iter_multi_token = filter_result_iterator_t(coll->get_name(), coll->_get_index(),
                                                     filter_tree_root, enable_lazy_evaluation);
    ASSERT_FALSE(iter_multi_token.init_status().ok());
    ASSERT_EQ(400, iter_multi_token.init_status().code());
    ASSERT_EQ("Error with filter field `cast`: Infix filter value must be a single token. "
              "To match multiple substrings use separate conditions, "
              "e.g. `field:*foo* && field:*bar*`.", iter_multi_token.init_status().error());

    delete filter_tree_root;
    filter_tree_root = nullptr;
}
