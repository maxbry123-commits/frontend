#include "image_embedder.h"
#include "text_embedder_remote.h"

CLIPImageEmbedder::CLIPImageEmbedder(const std::shared_ptr<Ort::Session>& session, const std::shared_ptr<Ort::Env>& env, const std::string& model_path, const std::string& processor_filename) : image_processor_(model_path, processor_filename), session_(session), env_(env) {
}

embedding_res_t CLIPImageEmbedder::embed(const std::string& encoded_image) {
    std::unique_lock<std::mutex> lock(mutex_);
    // process image
    auto processed_image_op = image_processor_.process_image(encoded_image);
    lock.unlock();
    if (!processed_image_op.ok()) {
        nlohmann::json error_json;
        error_json["error"] = processed_image_op.error();
        return embedding_res_t(processed_image_op.code(), error_json);
    }

    auto processed_image = processed_image_op.get();

    // create input tensors
    std::vector<int64_t> input_shape = {1, 3, 224, 224};
    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

    std::vector<const char*> input_names;
    std::vector<Ort::Value> input_tensors;

    // Check if model requires input_ids (e.g. SigLIP has input_ids + pixel_values, no attention_mask)
    std::vector<int64_t> dummy_input_ids = {0};
    std::vector<int64_t> dummy_input_ids_shape = {1, 1};
    bool has_input_ids = false;
    auto input_count = session_->GetInputCount();
    for(size_t i = 0; i < input_count; i++) {
        auto name = session_->GetInputNameAllocated(i, Ort::AllocatorWithDefaultOptions());
        if(std::strcmp(name.get(), "input_ids") == 0) {
            has_input_ids = true;
            break;
        }
    }

    if(has_input_ids) {
        input_names.push_back("input_ids");
        input_tensors.push_back(Ort::Value::CreateTensor<int64_t>(memory_info, dummy_input_ids.data(), dummy_input_ids.size(), dummy_input_ids_shape.data(), dummy_input_ids_shape.size()));
    }

    input_names.push_back("pixel_values");
    input_tensors.push_back(Ort::Value::CreateTensor<float>(memory_info, (float*) processed_image.data(), processed_image.size(), input_shape.data(), input_shape.size()));

    // create output tensor
    std::vector<const char*> output_names = {"image_embeds"};

    // run inference
    lock.lock();
    auto output_tensors = session_->Run(Ort::RunOptions{nullptr}, input_names.data(), input_tensors.data(), input_tensors.size(), output_names.data(), output_names.size());
    lock.unlock();

    // get output tensor
    auto output_tensor = output_tensors.front().GetTensorMutableData<float>();
    auto shape = output_tensors.front().GetTensorTypeAndShapeInfo().GetShape();

    if (shape.size() != 2) {
        return embedding_res_t(400, "Invalid shape of output tensor");
    }

    std::vector<float> output_vector;

    for (int i = 0; i < shape[1]; i++) {
        output_vector.push_back(output_tensor[i]);
    }

    return embedding_res_t(std::move(output_vector));
}


std::vector<embedding_res_t> CLIPImageEmbedder::embed_documents(const std::vector<std::string>& inputs) {
    std::vector<processed_image_t> processed_images;
    std::unordered_map<int, embedding_res_t> results;

    int i = 0;
    for (const auto& input : inputs) {
        std::unique_lock<std::mutex> lock(mutex_);
        auto processed_image_op = image_processor_.process_image(input);
        lock.unlock();

        if (!processed_image_op.ok()) {
            nlohmann::json error_json;
            error_json["error"] = processed_image_op.error();
            results[i] = embedding_res_t(processed_image_op.code(), error_json);
            i++;
            continue;
        }

        processed_images.push_back(processed_image_op.get());
        i++;
    }


    // no valid images
    if (processed_images.empty()) {
        std::vector<embedding_res_t> result_vector(inputs.size());
        for (int i = 0; i < inputs.size(); i++) {
            result_vector[i] = results[i];
        }

        return result_vector;
    }

    // create input tensor
    std::vector<int64_t> input_shape = {static_cast<int64_t>(processed_images.size()), 3, 224, 224};
    std::vector<const char*> input_names;
    std::vector<int64_t> dummy_input_ids_shape = {1,1};
    std::vector<int64_t> dummy_input_ids = {0};
    std::vector<int64_t> dummy_attention_mask_shape = {1,1};
    std::vector<int64_t> dummy_attention_mask = {1};
    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

    // convert 2D vector to 1D vector
    std::vector<float> input_vector;
    for (auto& image : processed_images) {
        input_vector.reserve(input_vector.size() + image.size());
        std::move(image.begin(), image.end(), std::back_inserter(input_vector));
        image.clear();
    }

    // Build inputs dynamically based on what the model expects
    bool has_attention_mask = false;
    auto input_count = session_->GetInputCount();
    for(size_t idx = 0; idx < input_count; idx++) {
        auto name = session_->GetInputNameAllocated(idx, Ort::AllocatorWithDefaultOptions());
        if(std::strcmp(name.get(), "attention_mask") == 0) {
            has_attention_mask = true;
            break;
        }
    }

    std::vector<Ort::Value> input_tensors;
    input_names.push_back("input_ids");
    input_tensors.push_back(Ort::Value::CreateTensor<int64_t>(memory_info, (int64_t*) dummy_input_ids.data(), dummy_input_ids.size(), dummy_input_ids_shape.data(), dummy_input_ids_shape.size()));
    input_names.push_back("pixel_values");
    input_tensors.push_back(Ort::Value::CreateTensor<float>(memory_info, (float*) input_vector.data(), input_vector.size(), input_shape.data(), input_shape.size()));
    if(has_attention_mask) {
        input_names.push_back("attention_mask");
        input_tensors.push_back(Ort::Value::CreateTensor<int64_t>(memory_info, (int64_t*) dummy_attention_mask.data(), dummy_attention_mask.size(), dummy_attention_mask_shape.data(), dummy_attention_mask_shape.size()));
    }


    std::vector<const char*> output_names = {"image_embeds"};


    // run inference
    // LOG(INFO) << "Running image embedder";
    std::unique_lock<std::mutex> lock(mutex_);
    auto output_tensors = session_->Run(Ort::RunOptions{nullptr}, input_names.data(), input_tensors.data(), input_tensors.size(), output_names.data(), output_names.size());
    lock.unlock();

    // get output tensor
    auto output_tensor = output_tensors.front().GetTensorMutableData<float>();
    auto shape = output_tensors.front().GetTensorTypeAndShapeInfo().GetShape();

    if (shape.size() != 2) {
        return std::vector<embedding_res_t>(inputs.size(), embedding_res_t(400, "Invalid shape of output tensor"));
    }

    std::vector<embedding_res_t> output(inputs.size());
    i = 0;
    for (int j = 0; j < shape[0]; j++) {
        while (results.find(i) != results.end()) {
            output[i] = results[i];
            i++;
        }
        std::vector<float> output_vector;
        for (int k = 0; k < shape[1]; k++) {
            output_vector.push_back(output_tensor[j * shape[1] + k]);
        }
        output[i] = embedding_res_t(std::move(output_vector));
        i++;
    }

    return output;
}