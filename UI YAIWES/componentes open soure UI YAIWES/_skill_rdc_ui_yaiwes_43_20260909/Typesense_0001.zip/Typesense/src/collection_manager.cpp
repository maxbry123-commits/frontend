#include <string>
#include <vector>
#include <queue>
#include <set>
#include <json.hpp>
#include <app_metrics.h>
#include <analytics_manager.h>
#include "collection_manager.h"
#include "analytics_manager.h"
#include "batched_indexer.h"
#include "logger.h"
#include "magic_enum.hpp"
#include "stopwords_manager.h"
#include "conversation_model.h"
#include "field.h"
#include "core_api_utils.h"
#include "synonym_index_manager.h"
#include "curation_index_manager.h"
#include "natural_language_search_model_manager.h"

constexpr const size_t CollectionManager::DEFAULT_NUM_MEMORY_SHARDS;

#ifdef TEST_BUILD
std::function<Option<bool>()> collection_manager_before_async_reference_backfill_apply = nullptr;
#endif

struct staged_async_reference_backfill_t {
    std::shared_ptr<Collection> referenced_coll;
    std::shared_ptr<Collection> referencing_coll;
    std::string referencing_collection_name;
    Collection::async_reference_backfill_update_map_t updates;
};

Option<bool> stage_async_reference_helper_backfill(
        std::shared_ptr<Collection> referenced_coll,
        std::shared_ptr<Collection> referencing_coll,
        const std::string& referenced_field_name,
        const std::string& referencing_field_name,
        std::vector<staged_async_reference_backfill_t>& staged_backfills) {
    if (referenced_coll == nullptr || referencing_coll == nullptr) {
        return Option<bool>(true);
    }

    staged_async_reference_backfill_t staged_backfill;
    staged_backfill.referencing_collection_name = referencing_coll->get_name();
    staged_backfill.referenced_coll = std::move(referenced_coll);
    staged_backfill.referencing_coll = std::move(referencing_coll);

    auto stage_op = staged_backfill.referenced_coll->stage_async_reference_helper_backfill(
            referenced_field_name, staged_backfill.referencing_coll.get(), referencing_field_name,
            staged_backfill.updates);
    if (!stage_op.ok()) {
        return stage_op;
    }

    if (!staged_backfill.updates.empty()) {
        staged_backfills.emplace_back(std::move(staged_backfill));
    }

    return Option<bool>(true);
}

Collection::async_reference_backfill_update_map_t reverse_async_reference_helper_backfill(
        const Collection::async_reference_backfill_update_map_t& updates) {
    Collection::async_reference_backfill_update_map_t reversed_updates;
    for (const auto& update_item: updates) {
        const auto& update = update_item.second;
        reversed_updates.emplace(update_item.first, Collection::async_reference_backfill_update_t{
                update.seq_id, update.new_helper_fields, update.old_helper_fields, update.expected_reference_fields});
    }

    return reversed_updates;
}

void rollback_applied_async_reference_helper_backfills(
        const std::vector<staged_async_reference_backfill_t>& staged_backfills,
        const std::vector<size_t>& applied_backfill_indices) {
    for (auto it = applied_backfill_indices.rbegin(); it != applied_backfill_indices.rend(); ++it) {
        const auto& staged_backfill = staged_backfills[*it];
        auto reversed_updates = reverse_async_reference_helper_backfill(staged_backfill.updates);
        auto rollback_op = staged_backfill.referenced_coll->apply_staged_async_reference_updates(
                staged_backfill.referencing_coll.get(), staged_backfill.referencing_collection_name, reversed_updates);
        if (!rollback_op.ok()) {
            LOG(ERROR) << "Failed to rollback async reference helper backfill for collection `"
                       << staged_backfill.referencing_collection_name << "`: " << rollback_op.error();
        }
    }
}

Option<bool> apply_staged_async_reference_helper_backfills(
        std::vector<staged_async_reference_backfill_t>& staged_backfills) {
#ifdef TEST_BUILD
    if (collection_manager_before_async_reference_backfill_apply != nullptr) {
        auto hook_op = collection_manager_before_async_reference_backfill_apply();
        if (!hook_op.ok()) {
            return hook_op;
        }
    }
#endif

    std::vector<size_t> applied_backfill_indices;
    applied_backfill_indices.reserve(staged_backfills.size());

    for (size_t i = 0; i < staged_backfills.size(); i++) {
        auto& staged_backfill = staged_backfills[i];
        auto apply_op = staged_backfill.referenced_coll->apply_staged_async_reference_updates(
                staged_backfill.referencing_coll.get(), staged_backfill.referencing_collection_name,
                staged_backfill.updates);
        if (!apply_op.ok()) {
            rollback_applied_async_reference_helper_backfills(staged_backfills, applied_backfill_indices);
            return apply_op;
        }

        applied_backfill_indices.push_back(i);
    }

    return Option<bool>(true);
}

CollectionManager::CollectionManager() {

}

Option<Collection*> CollectionManager::init_collection(const nlohmann::json & collection_meta,
                                                       const uint32_t collection_next_seq_id,
                                                       Store* store,
                                                       float max_memory_ratio,
                                                       const std::map<std::string, std::map<std::string, reference_info_t>>& referenced_infos) {
    std::string this_collection_name = collection_meta[Collection::COLLECTION_NAME_KEY].get<std::string>();

    bool enable_nested_fields = collection_meta.count(Collection::COLLECTION_ENABLE_NESTED_FIELDS) != 0 ?
                                collection_meta[Collection::COLLECTION_ENABLE_NESTED_FIELDS].get<bool>() :
                                false;
    std::vector<field> fields;
    nlohmann::json fields_map = collection_meta[Collection::COLLECTION_SEARCH_FIELDS_KEY];

    for (nlohmann::json::iterator it = fields_map.begin(); it != fields_map.end(); ++it) {
        nlohmann::json & field_obj = it.value();

        // handle older records indexed before optional field introduction
        if(field_obj.count(fields::optional) == 0) {
            field_obj[fields::optional] = false;
        }

        if(field_obj.count(fields::index) == 0) {
            field_obj[fields::index] = true;
        }

        if(field_obj.count(fields::locale) == 0) {
            field_obj[fields::locale] = "";
        }

        if(field_obj.count(fields::infix) == 0) {
            field_obj[fields::infix] = -1;
        }

        if(field_obj.count(fields::nested) == 0) {
            field_obj[fields::nested] = false;
        }

        if(field_obj.count(fields::nested_array) == 0) {
            field_obj[fields::nested_array] = 0;
        }

        if(field_obj.count(fields::num_dim) == 0) {
            field_obj[fields::num_dim] = 0;
        }

        if (field_obj.count(fields::reference) == 0) {
            field_obj[fields::reference] = "";
        }

        if (field_obj.count(fields::async_reference) == 0) {
            field_obj[fields::async_reference] = false;
        }

        if(field_obj.count(fields::embed) == 0) {
            field_obj[fields::embed] = nlohmann::json::object();
        }

        if(field_obj.count(fields::model_config) == 0) {
            field_obj[fields::model_config] = nlohmann::json::object();
        }

        if(field_obj.count(fields::hnsw_params) == 0) {
            field_obj[fields::hnsw_params] = nlohmann::json::object();
            field_obj[fields::hnsw_params]["ef_construction"] = 200;
            field_obj[fields::hnsw_params]["M"] = 16;
        }

        if(field_obj.count(fields::stem) == 0) {
            field_obj[fields::stem] = false;
        }

        if(field_obj.count(fields::stem_dictionary) == 0) {
            field_obj[fields::stem_dictionary] = "";
        }

        if(field_obj.count(fields::range_index) == 0) {
            field_obj[fields::range_index] = false;
        }

        if(field_obj.count(fields::store) == 0) {
            field_obj[fields::store] = true;
        }

        if(field_obj.count(fields::truncate_len) == 0) {
            field_obj[fields::truncate_len] = 100;
        }

        if(field_obj.count(fields::token_separators) == 0) {
            field_obj[fields::token_separators] = nlohmann::json::array();
        }

        if(field_obj.count(fields::symbols_to_index) == 0) {
            field_obj[fields::symbols_to_index] = nlohmann::json::array();
        }

        if (field_obj.count(fields::cascade_delete) == 0) {
            field_obj[fields::cascade_delete] = true;
        }

        if(field_obj.count(fields::track_missing_values) == 0) {
            field_obj[fields::track_missing_values] = false;
        }

        vector_distance_type_t vec_dist_type = vector_distance_type_t::cosine;

        if(field_obj.count(fields::vec_dist) != 0 && field_obj[fields::vec_dist].is_string()) {
            auto val = field_obj[fields::vec_dist].get<std::string>();
            StringUtils::tolowercase(val);
            auto vec_dist_type_op = magic_enum::enum_cast<vector_distance_type_t>(val);
            if(vec_dist_type_op.has_value()) {
                vec_dist_type = vec_dist_type_op.value();
            }
        }

        if(field_obj.count(fields::embed) != 0 && !field_obj[fields::embed].empty()) {
            size_t num_dim = field_obj[fields::num_dim];
            auto& model_config = field_obj[fields::embed][fields::model_config];

            auto res = EmbedderManager::get_instance().validate_and_init_model(model_config, num_dim);
            if(!res.ok()) {
                const std::string& model_name = model_config["model_name"].get<std::string>();
                LOG(ERROR) << "Error initializing model: " << model_name << ", error: " << res.error();
                continue;
            }

            if(field_obj[fields::num_dim] == 0) {
                field_obj[fields::num_dim] = num_dim;
            }

            LOG(INFO) << "Model init done.";
        }

        field f(field_obj[fields::name], field_obj[fields::type], field_obj[fields::facet],
                field_obj[fields::optional], field_obj[fields::index], field_obj[fields::locale],
                -1, field_obj[fields::infix], field_obj[fields::nested], field_obj[fields::nested_array],
                field_obj[fields::num_dim], vec_dist_type, field_obj[fields::reference], field_obj[fields::embed],
                field_obj[fields::range_index], field_obj[fields::store], field_obj[fields::stem], field_obj[fields::stem_dictionary],
                field_obj[fields::hnsw_params], field_obj[fields::async_reference], field_obj[fields::token_separators],
                field_obj[fields::symbols_to_index], field_obj[fields::cascade_delete], field_obj[fields::truncate_len],
                field_obj[fields::track_missing_values]);

        // value of `sort` depends on field type
        if(field_obj.count(fields::sort) == 0) {
            f.sort = f.is_num_sort_field();
        } else {
            f.sort = field_obj[fields::sort];
        }

        fields.push_back(f);
    }

    std::string default_sorting_field = collection_meta[Collection::COLLECTION_DEFAULT_SORTING_FIELD_KEY].get<std::string>();

    uint64_t created_at = collection_meta.find((const char*)Collection::COLLECTION_CREATED) != collection_meta.end() ?
                       collection_meta[Collection::COLLECTION_CREATED].get<uint64_t>() : 0;

    size_t num_memory_shards = collection_meta.count(Collection::COLLECTION_NUM_MEMORY_SHARDS) != 0 ?
                               collection_meta[Collection::COLLECTION_NUM_MEMORY_SHARDS].get<size_t>() :
                               DEFAULT_NUM_MEMORY_SHARDS;

    std::string fallback_field_type = collection_meta.count(Collection::COLLECTION_FALLBACK_FIELD_TYPE) != 0 ?
                              collection_meta[Collection::COLLECTION_FALLBACK_FIELD_TYPE].get<std::string>() :
                              "";

    std::vector<std::string> symbols_to_index;
    std::vector<std::string> token_separators;

    if(collection_meta.count(Collection::COLLECTION_SYMBOLS_TO_INDEX) != 0) {
        symbols_to_index = collection_meta[Collection::COLLECTION_SYMBOLS_TO_INDEX].get<std::vector<std::string>>();
    }

    if(collection_meta.count(Collection::COLLECTION_SEPARATORS) != 0) {
        token_separators = collection_meta[Collection::COLLECTION_SEPARATORS].get<std::vector<std::string>>();
    }

    LOG(INFO) << "Found collection " << this_collection_name << " with " << num_memory_shards << " memory shards.";
    std::shared_ptr<VQModel> model = nullptr;
    if(collection_meta.count(Collection::COLLECTION_VOICE_QUERY_MODEL) != 0) {
        const nlohmann::json& voice_query_model = collection_meta[Collection::COLLECTION_VOICE_QUERY_MODEL];

        if(!voice_query_model.is_object()) {
            LOG(ERROR) << "Parameter `voice_query_model` must be an object.";
        }

        if(voice_query_model.count("model_name") == 0) {
            LOG(ERROR) << "Parameter `voice_query_model.model_name` is missing.";
        }

        if(!voice_query_model["model_name"].is_string() || voice_query_model["model_name"].get<std::string>().empty()) {
            LOG(ERROR) << "Parameter `voice_query_model.model_name` is invalid.";
        }

        std::string model_name = voice_query_model["model_name"].get<std::string>();
        auto model_res = VQModelManager::get_instance().validate_and_init_model(model_name);
        if(!model_res.ok()) {
            LOG(ERROR) << "Error while loading voice query model: " << model_res.error();
        } else {
            model = model_res.get();
        }
    }

    spp::sparse_hash_map<std::string, std::string> referenced_in{};
    spp::sparse_hash_map<std::string, std::set<reference_pair_t>> async_referenced_ins;
    auto ref_info_it = referenced_infos.find(this_collection_name);
    if (ref_info_it != referenced_infos.end()) {
        for (const auto& item: ref_info_it->second) {
            const auto& ref_info = item.second;
            referenced_in.emplace(ref_info.collection, ref_info.field);

            if (ref_info.is_async) {
                async_referenced_ins[ref_info.referenced_field_name].emplace(ref_info.collection, ref_info.field);
            }
        }
    }

    nlohmann::json metadata;

    if(collection_meta.count(Collection::COLLECTION_METADATA) != 0) {
        metadata = collection_meta[Collection::COLLECTION_METADATA];
    }

    std::vector<std::string> synonym_sets;
    std::vector<std::string> curation_sets;
    if (collection_meta.count(Collection::COLLECTION_SYNONYM_SETS) != 0) {
        if (!collection_meta[Collection::COLLECTION_SYNONYM_SETS].is_array()) {
            LOG(ERROR) << "Parameter `synonym_sets` must be an array.";
        } else {
            synonym_sets = collection_meta[Collection::COLLECTION_SYNONYM_SETS].get<std::vector<std::string>>();
        }
    }

    if (collection_meta.count(Collection::COLLECTION_curation_sets) != 0) {
        if (!collection_meta[Collection::COLLECTION_curation_sets].is_array()) {
            LOG(ERROR) << "Parameter `curation_sets` must be an array.";
        } else {
            curation_sets = collection_meta[Collection::COLLECTION_curation_sets].get<std::vector<std::string>>();
        }
    }

    auto collection_op = Collection::new_collection(this_collection_name,
                                                    collection_meta[Collection::COLLECTION_ID_KEY].get<uint32_t>(),
                                                    created_at,
                                                    collection_next_seq_id,
                                                    store,
                                                    fields,
                                                    default_sorting_field,
                                                    max_memory_ratio,
                                                    fallback_field_type,
                                                    symbols_to_index,
                                                    token_separators,
                                                    enable_nested_fields, model,
                                                    referenced_in,
                                                    metadata,
                                                    async_referenced_ins,
                                                    synonym_sets,
                                                    curation_sets, false);
    if (!collection_op.ok()) {
        return collection_op;
    }

    auto collection = collection_op.get();
    for (const auto& ref_field: collection->get_reference_fields()) {
        const auto& ref_info = ref_field.second;
        ref_info_it = referenced_infos.find(ref_info.collection);
        if (ref_info_it == referenced_infos.end()) {
            continue;
        }

        const auto it = ref_info_it->second.find(this_collection_name);
        if (it == ref_info_it->second.end()) {
            continue;
        }
        collection->update_reference_field_with_lock(ref_field.first, it->second.referenced_field);
    }

    return Option<Collection*>(collection);
}

std::shared_ptr<Collection> CollectionManager::add_to_collections(Collection* collection) {
    const std::string& collection_name = collection->get_name();
    const uint32_t collection_id = collection->get_collection_id();
    std::unique_lock lock(mutex);
    auto emplace_result = collections.emplace(collection_name, collection);
    collection_id_names.emplace(collection_id, collection_name);
    return emplace_result.first->second;
}

void CollectionManager::init(Store *store, ThreadPool* thread_pool,
                             const float max_memory_ratio,
                             const std::string & auth_key,
                             std::atomic<bool>& quit,
                             const uint16_t& filter_by_max_operations) {
    std::unique_lock lock(mutex);

    this->store = store;
    this->thread_pool = thread_pool;
    this->bootstrap_auth_key = auth_key;
    this->max_memory_ratio = max_memory_ratio;
    this->quit = &quit;
    this->filter_by_max_ops = filter_by_max_operations;
}

// used only in tests!
void CollectionManager::init(Store *store, const float max_memory_ratio, const std::string & auth_key,
                             std::atomic<bool>& quit,
                             const uint16_t& filter_by_max_operations) {
    ThreadPool* thread_pool = new ThreadPool(8);
    init(store, thread_pool, max_memory_ratio, auth_key, quit, filter_by_max_operations);
    CurationIndexManager::get_instance().init_store(store);
    SynonymIndexManager::get_instance().init_store(store);
}

field get_referenced_field(const std::string& ref_schema, const std::string& ref_field_name) {
    if (ref_field_name == "id") {
        return field("id", field_types::STRING, false);
    }

    const auto& ref_coll_schema = nlohmann::json::parse(ref_schema);
    for (const auto &field: ref_coll_schema["fields"]) {
        auto it = field.find("name");
        if (it == field.end() || it->get<std::string>() != ref_field_name) {
            continue;
        }

        return field::field_from_json(field);
    }

    return field{};
}

bool hydrate_referenced_fields(const std::vector<std::string>& collection_meta_jsons,
                               const spp::sparse_hash_map<std::string, std::string>& collection_symlinks,
                               std::map<std::string, std::map<std::string, reference_info_t>>& referenced_ins) {
    std::map<std::string, std::string> collection_meta_by_name;
    for (const auto& collection_meta_json: collection_meta_jsons) {
        const auto& collection_meta = nlohmann::json::parse(collection_meta_json, nullptr, false);
        if (collection_meta.is_discarded() || !collection_meta.is_object() || !collection_meta.contains("name") ||
            !collection_meta["name"].is_string()) {
            continue;
        }

        collection_meta_by_name[collection_meta["name"].get<std::string>()] = collection_meta_json;
    }

    bool hydrated = false;
    for (auto& referenced_in: referenced_ins) {
        auto referenced_coll_name = referenced_in.first;
        auto symlink_it = collection_symlinks.find(referenced_coll_name);
        if (symlink_it != collection_symlinks.end()) {
            referenced_coll_name = symlink_it->second;
        }

        auto meta_it = collection_meta_by_name.find(referenced_coll_name);
        if (meta_it == collection_meta_by_name.end()) {
            continue;
        }

        for (auto& item: referenced_in.second) {
            auto& ref_info = item.second;
            if (!ref_info.referenced_field.name.empty() || ref_info.referenced_field_name.empty()) {
                continue;
            }

            auto ref_field = get_referenced_field(meta_it->second, ref_info.referenced_field_name);
            if (ref_field.name.empty()) {
                continue;
            }

            ref_info.referenced_field = std::move(ref_field);
            hydrated = true;
        }
    }

    return hydrated;
}

void CollectionManager::_populate_referenced_ins(const std::vector<std::string>& collection_meta_jsons,
                                                 std::map<std::string, std::map<std::string, reference_info_t>>& referenced_ins) {
    std::map<std::string, uint32_t> collection_index;
    for (size_t i = 0; i < collection_meta_jsons.size(); i++) {
        auto const& obj = nlohmann::json::parse(collection_meta_jsons[i]);
        if (obj.is_discarded() || !obj.is_object() || !obj.contains("name") || !obj["name"].is_string() ||
            !obj.contains("fields")) {
            continue;
        }

        auto const& collection_name = obj["name"];
        collection_index[collection_name] = i;

        for (const auto &field: obj["fields"]) {
            if (!field.contains("name") || !field.contains("reference")) {
                continue;
            }

            auto field_name = std::string(field["name"]);
            auto const& reference = field["reference"].get<std::string>();
            std::vector<std::string> split_result;
            StringUtils::split(reference, split_result, ".");
            if (split_result.size() < 2) {
                LOG(ERROR) << "Invalid reference `" << reference << "`.";
                continue;
            }

            auto ref_coll_name = split_result[0];
            auto ref_field_name = reference.substr(ref_coll_name.size() + 1);

            // Resolves alias if used in schema.
            auto actual_ref_coll_it = CollectionManager::get_instance().collection_symlinks.find(ref_coll_name);
            if (actual_ref_coll_it != CollectionManager::get_instance().collection_symlinks.end()) {
                ref_coll_name = actual_ref_coll_it->second;
            }

            struct field ref_field{};
            if (collection_index.count(ref_coll_name) != 0) {
                ref_field = get_referenced_field(collection_meta_jsons.at(collection_index[ref_coll_name]),
                                                 ref_field_name);
            } else {
                size_t ref_index = i;
                for (size_t j = i + 1; j < collection_meta_jsons.size(); j++) {
                    auto const& ref_obj = nlohmann::json::parse(collection_meta_jsons[j]);
                    if (ref_obj.is_discarded() || !ref_obj.is_object() || !ref_obj.contains("name") || !ref_obj["name"].is_string() ||
                        !ref_obj.contains("fields")) {
                        continue;
                    }

                    auto const& ref_collection_name = ref_obj["name"];
                    collection_index[collection_name] = j;
                    if (ref_collection_name == ref_coll_name) {
                        ref_index = j;
                        break;
                    }
                }

                if (ref_index > i) {
                    ref_field = get_referenced_field(collection_meta_jsons.at(ref_index), ref_field_name);
                }
            }

            bool async_ref = false;
            if (field.contains(fields::async_reference) &&
                field[fields::async_reference].is_boolean() && field[fields::async_reference].get<bool>()) {
                async_ref = true;
            }

            bool is_array = false;
            if (field.contains(fields::type) && field[fields::type].is_string()) {
                auto const& type = field[fields::type].get<std::string>();
                is_array = (type.size() > 2 && type[type.size() - 2] == '[' && type[type.size() - 1] == ']');
            }

            auto ref_info = reference_info_t(collection_name, field_name, async_ref, is_array, ref_field_name);
            if (!ref_field.name.empty()) {
                ref_info.referenced_field = std::move(ref_field);
            }

            referenced_ins[ref_coll_name].insert({collection_name, std::move(ref_info)});
        }
    }
}

Option<bool> CollectionManager::load(const size_t collection_batch_size, const size_t document_batch_size) {
    // This function must be idempotent, i.e. when called multiple times, must produce the same state without leaks
    LOG(INFO) << "CollectionManager::load()";

    Option<bool> auth_init_op = auth_manager.init(store, bootstrap_auth_key);
    if(!auth_init_op.ok()) {
        LOG(ERROR) << "Auth manager init failed, error=" << auth_init_op.error();
    }

    std::string next_collection_id_str;
    StoreStatus next_coll_id_status = store->get(NEXT_COLLECTION_ID_KEY, next_collection_id_str);

    if(next_coll_id_status == StoreStatus::ERROR) {
        return Option<bool>(500, "Error while fetching the next collection id from the disk.");
    }

    if(next_coll_id_status == StoreStatus::FOUND) {
        next_collection_id = (uint32_t) stoi(next_collection_id_str);
    } else {
        next_collection_id = 0;
    }

    // load aliases

    std::string symlink_prefix_key = std::string(SYMLINK_PREFIX) + "_";
    std::string upper_bound_key = std::string(SYMLINK_PREFIX) + "`";  // cannot inline this
    rocksdb::Slice upper_bound(upper_bound_key);

    rocksdb::Iterator* iter = store->scan(symlink_prefix_key, &upper_bound);
    while(iter->Valid() && iter->key().starts_with(symlink_prefix_key)) {
        std::vector<std::string> parts;
        StringUtils::split(iter->key().ToString(), parts, symlink_prefix_key);
        LOG(INFO) << "Loading symlink " << parts[0] << " to " << iter->value().ToString();
        collection_symlinks[parts[0]] = iter->value().ToString();
        iter->Next();
    }
    delete iter;

    LOG(INFO) << "Loading upto " << collection_batch_size << " collections in parallel, "
              << document_batch_size << " documents at a time.";

    std::vector<std::string> collection_meta_jsons;
    store->scan_fill(std::string(Collection::COLLECTION_META_PREFIX) + "_",
                     std::string(Collection::COLLECTION_META_PREFIX) + "`",
                     collection_meta_jsons);

    const size_t num_collections = collection_meta_jsons.size();
    LOG(INFO) << "Found " << num_collections << " collection(s) on disk.";

    if (!store->contains(REFERENCED_INS)) {
        _populate_referenced_ins(collection_meta_jsons, referenced_ins);
        persist_referenced_ins();
    } else {
        std::string referenced_ins_str;
        store->get(REFERENCED_INS, referenced_ins_str);
        if (!referenced_ins_str.empty()) {
            const auto& referenced_ins_json = nlohmann::json::parse(referenced_ins_str);
            for (const auto& referenced_coll: referenced_ins_json) {
                auto referenced_coll_it = referenced_coll.find("referenced_coll_name");
                if (referenced_coll_it == referenced_coll.end()) {
                    continue;
                }

                auto referenced_infos_it = referenced_coll.find("referenced_infos");
                if (referenced_infos_it == referenced_coll.end()) {
                    continue;
                }

                for (const auto& ref_info: referenced_infos_it.value()) {
                    referenced_ins[referenced_coll_it.value()].insert({ref_info["collection"], reference_info_t(ref_info)});
                }
            }

            if (hydrate_referenced_fields(collection_meta_jsons, collection_symlinks, referenced_ins)) {
                persist_referenced_ins();
            }
        }
    }

    // load stemming dictionaries
    std::string stemming_dictionary_prefix_key = std::string(StemmerManager::STEMMING_DICTIONARY_PREFIX) + "_";
    std::string stemming_dictionary_upper_bound_key = std::string(StemmerManager::STEMMING_DICTIONARY_PREFIX) + "`";
    rocksdb::Slice stemming_dictionary_upper_bound(stemming_dictionary_upper_bound_key);

    iter = store->scan(stemming_dictionary_prefix_key, &stemming_dictionary_upper_bound);
    while(iter->Valid() && iter->key().starts_with(stemming_dictionary_prefix_key)) {
        std::string stemming_dictionary_name = iter->key().ToString().substr(stemming_dictionary_prefix_key.size());
        nlohmann::json stemming_dictionary_obj = nlohmann::json::parse(iter->value().ToString(), nullptr, false);

        if(!stemming_dictionary_obj.is_discarded() && stemming_dictionary_obj.is_object()) {
            StemmerManager::get_instance().load_stemming_dictioary(stemming_dictionary_obj);
        } else {
            LOG(INFO) << "Invalid object for stemming dictionary " << stemming_dictionary_name;
        }

        iter->Next();
    }
    delete iter;

    // load synonym sets
    SynonymIndexManager::get_instance().load_synonym_indices();

    // load curation sets
    CurationIndexManager::get_instance().load_curation_indices();

    //load NL models
    auto natural_language_search_init = NaturalLanguageSearchModelManager::init(store);
    if(!natural_language_search_init.ok()) {
        LOG(INFO) << "Failed to initialize natural language search model manager: "
                  << natural_language_search_init.error();
    } else {
        LOG(INFO) << "Loaded " << natural_language_search_init.get()
                  << " natural language search model(s).";
    }

    ThreadPool loading_pool(collection_batch_size);

    size_t num_processed = 0;
    std::mutex m_process;
    std::condition_variable cv_process;
    std::string collection_name;

    for(size_t coll_index = 0; coll_index < num_collections; coll_index++) {
        const auto& collection_meta_json = collection_meta_jsons[coll_index];
        nlohmann::json collection_meta = nlohmann::json::parse(collection_meta_json, nullptr, false);
        if(collection_meta.is_discarded()) {
            LOG(ERROR) << "Error while parsing collection meta, json: " << collection_meta_json;
            return Option<bool>(500, "Error while parsing collection meta.");
        }

        collection_name = collection_meta[Collection::COLLECTION_NAME_KEY].get<std::string>();

        auto captured_store = store;
        auto captured_referenced_ins = referenced_ins;
        loading_pool.enqueue([captured_store, num_collections, collection_meta, document_batch_size,
                              &m_process, &cv_process, &num_processed, &next_coll_id_status, quit = quit,
                                     captured_referenced_ins, collection_name]() {

            //auto begin = std::chrono::high_resolution_clock::now();
            Option<bool> res = load_collection(collection_meta, document_batch_size, next_coll_id_status, *quit,
                                               captured_referenced_ins);
            /*long long int timeMillis =
                    std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - begin).count();
            LOG(INFO) << "Time taken for indexing: " << timeMillis << "ms";*/

            if(!res.ok()) {
                LOG(ERROR) << "Error while loading collection. " << res.error();
                LOG(ERROR) << "Typesense is quitting.";
                captured_store->close();
                exit(1);
            }

            std::unique_lock<std::mutex> lock(m_process);
            num_processed++;

            auto& cm = CollectionManager::get_instance();
            cv_process.notify_one();

            size_t progress_modulo = std::max<size_t>(1, (num_collections / 10));  // every 10%
            if(num_processed % progress_modulo == 0) {
                LOG(INFO) << "Loaded " << num_processed << " collection(s) so far";
            }
        });
    }

    // wait for all collections to be loaded
    std::unique_lock<std::mutex> lock_process(m_process);
    cv_process.wait(lock_process, [&](){
        return num_processed == num_collections;
        // return num_processed == 1;
    });

    // load presets

    std::string preset_prefix_key = std::string(PRESET_PREFIX) + "_";
    std::string preset_upper_bound_key = std::string(PRESET_PREFIX) + "`"; // cannot inline this
    rocksdb::Slice preset_upper_bound(preset_upper_bound_key);

    iter = store->scan(preset_prefix_key, &preset_upper_bound);
    while(iter->Valid() && iter->key().starts_with(preset_prefix_key)) {
        std::string preset_name = iter->key().ToString().substr(preset_prefix_key.size());
        nlohmann::json preset_obj = nlohmann::json::parse(iter->value().ToString(), nullptr, false);

        if(!preset_obj.is_discarded() && preset_obj.is_object()) {
            preset_configs[preset_name] = preset_obj;
        } else {
            LOG(INFO) << "Invalid value for preset " << preset_name;
        }

        iter->Next();
    }
    delete iter;

    //load stopwords
    std::string stopword_prefix_key = std::string(StopwordsManager::STOPWORD_PREFIX) + "_";
    std::string stopword_upper_bound_key = std::string(StopwordsManager::STOPWORD_PREFIX) + "`"; // cannot inline this
    rocksdb::Slice stopword_upper_bound(stopword_upper_bound_key);

    iter = store->scan(stopword_prefix_key, &stopword_upper_bound);
    while(iter->Valid() && iter->key().starts_with(stopword_prefix_key)) {
        std::string stopword_name = iter->key().ToString().substr(stopword_prefix_key.size());
        nlohmann::json stopword_obj = nlohmann::json::parse(iter->value().ToString(), nullptr, false);

        if(!stopword_obj.is_discarded() && stopword_obj.is_object()) {
            StopwordsManager::get_instance().upsert_stopword(stopword_name, stopword_obj);
        } else {
            LOG(INFO) << "Invalid object for stopword " << stopword_name;
        }

        iter->Next();
    }
    delete iter;

    // restore new analytics configs
    std::vector<std::string> analytics_config_jsons;
    store->scan_fill(AnalyticsManager::ANALYTICS_RULE_PREFIX,
                     std::string(AnalyticsManager::ANALYTICS_RULE_PREFIX) + "`",
                     analytics_config_jsons);

    LOG(INFO) << "Loaded " << num_collections << " collection(s).";
    LOG(INFO) << "Found " << analytics_config_jsons.size() << " analytics config(s).";
    for(const auto& analytics_config_json: analytics_config_jsons) {
        nlohmann::json analytics_config = nlohmann::json::parse(analytics_config_json);
        AnalyticsManager::get_instance().create_rule(analytics_config, false, false, false);
    }
    LOG(INFO) << "Loaded " << analytics_config_jsons.size() << " analytics config(s).";

    // restore old analytics configs
    std::vector<std::string> old_analytics_config_jsons;
    store->scan_fill(AnalyticsManager::OLD_ANALYTICS_RULE_PREFIX,
                     std::string(AnalyticsManager::OLD_ANALYTICS_RULE_PREFIX) + "`",
                     old_analytics_config_jsons);
    LOG(INFO) << "Found " << old_analytics_config_jsons.size() << " old analytics config(s) on disk.";

    size_t restored_old_analytics_configs = 0;
    for(const auto& old_analytics_config_json: old_analytics_config_jsons) {
        nlohmann::json old_analytics_config = nlohmann::json::parse(old_analytics_config_json);
        auto create_op = AnalyticsManager::get_instance().create_old_rule(old_analytics_config);
        if(!create_op.ok() && create_op.code() != 409) {
            LOG(ERROR) << "Error while creating old analytics config. " << create_op.error();
        }
        restored_old_analytics_configs++;
    }
    LOG(INFO) << "Restored " << restored_old_analytics_configs << " old analytics config(s)." << " from " << old_analytics_config_jsons.size() << " old analytics config(s) on disk.";
    LOG(INFO) << "Removing restored old analytics config(s) from disk.";

    loading_pool.shutdown();

    return Option<bool>(true);
}


void CollectionManager::dispose() {
    std::unique_lock lock(mutex);

    collections.clear();
    collection_symlinks.clear();
    preset_configs.clear();
    referenced_ins.clear();
    store->close();
    collection_id_names.clear();
    SynonymIndexManager::get_instance().dispose();
    CurationIndexManager::get_instance().dispose();
}

bool CollectionManager::auth_key_matches(const string& req_auth_key, const string& action,
                                         const std::vector<collection_key_t>& collection_keys,
                                         std::map<std::string, std::string>& params,
                                         std::vector<nlohmann::json>& embedded_params_vec) const {
    std::shared_lock lock(mutex);

    // check with bootstrap auth key
    if(bootstrap_auth_key == req_auth_key) {
        return true;
    }

    // finally, check managed auth keys
    return auth_manager.authenticate(action, collection_keys, params, embedded_params_vec);
}

struct referenced_in_replay_t {
    std::map<std::string, reference_info_t>* ref_info_map;
    std::set<update_reference_info_t> update_ref_infos;
};

struct deferred_ref_resolution_t {
    std::string symlink_name;
    std::string referenced_collection_name;
    reference_info_t ref_info;
    std::shared_ptr<Collection> referencing_coll;
    std::shared_ptr<Collection> referenced_coll;
    std::set<update_reference_info_t> update_ref_infos;
};

Option<Collection*> CollectionManager::create_collection(const std::string& name,
                                                         const size_t num_memory_shards,
                                                         const std::vector<field> & fields,
                                                         const std::string& default_sorting_field,
                                                         const uint64_t created_at,
                                                         const std::string& fallback_field_type,
                                                         const std::vector<std::string>& symbols_to_index,
                                                         const std::vector<std::string>& token_separators,
                                                         const bool enable_nested_fields, std::shared_ptr<VQModel> model,
                                                         const nlohmann::json& metadata,
                                                         const std::vector<std::string>& synonym_sets,
                                                         const std::vector<std::string>& curation_sets) {
    std::unique_lock lock(mutex);

    if(store->contains(Collection::get_meta_key(name))) {
        return Option<Collection*>(409, std::string("A collection with name `") + name + "` already exists.");
    }

    // validated `fallback_field_type`
    if(!fallback_field_type.empty()) {
        field fallback_field_type_def("temp", fallback_field_type, false);
        if(!fallback_field_type_def.has_valid_type()) {
            return Option<Collection*>(400, std::string("Field `.*` has an invalid type."));
        }
    }

    nlohmann::json fields_json = nlohmann::json::array();;

    Option<bool> fields_json_op = field::fields_to_json_fields(fields, default_sorting_field, fields_json);

    if(!fields_json_op.ok()) {
        return Option<Collection*>(fields_json_op.code(), fields_json_op.error());
    }

    uint32_t new_coll_id = next_collection_id;
    next_collection_id++;

    nlohmann::json collection_meta;
    collection_meta[Collection::COLLECTION_NAME_KEY] = name;
    collection_meta[Collection::COLLECTION_ID_KEY] = new_coll_id;
    collection_meta[Collection::COLLECTION_SEARCH_FIELDS_KEY] = fields_json;
    collection_meta[Collection::COLLECTION_DEFAULT_SORTING_FIELD_KEY] = default_sorting_field;
    collection_meta[Collection::COLLECTION_CREATED] = created_at;
    collection_meta[Collection::COLLECTION_NUM_MEMORY_SHARDS] = num_memory_shards;
    collection_meta[Collection::COLLECTION_FALLBACK_FIELD_TYPE] = fallback_field_type;
    collection_meta[Collection::COLLECTION_SYMBOLS_TO_INDEX] = symbols_to_index;
    collection_meta[Collection::COLLECTION_SEPARATORS] = token_separators;
    collection_meta[Collection::COLLECTION_ENABLE_NESTED_FIELDS] = enable_nested_fields;
    collection_meta[Collection::COLLECTION_SYNONYM_SETS] = synonym_sets;
    collection_meta[Collection::COLLECTION_curation_sets] = curation_sets;

    if(model != nullptr) {
        collection_meta[Collection::COLLECTION_VOICE_QUERY_MODEL] = nlohmann::json::object();
        collection_meta[Collection::COLLECTION_VOICE_QUERY_MODEL]["model_name"] = model->get_model_name();
    }

    if(!metadata.empty()) {
        collection_meta[Collection::COLLECTION_METADATA] = metadata;
    }

    rocksdb::WriteBatch batch;
    batch.Put(Collection::get_next_seq_id_key(name), StringUtils::serialize_uint32_t(0));
    batch.Put(Collection::get_meta_key(name), collection_meta.dump());
    batch.Put(NEXT_COLLECTION_ID_KEY, std::to_string(next_collection_id));
    bool write_ok = store->batch_write(batch);

    if(!write_ok) {
        return Option<Collection*>(500, "Could not write to on-disk storage.");
    }

    lock.unlock();

    auto collection_op = Collection::new_collection(name, new_coll_id, created_at, 0, store, fields,
                                                    default_sorting_field,
                                                    this->max_memory_ratio, fallback_field_type,
                                                    symbols_to_index, token_separators,
                                                    enable_nested_fields, model,
                                                    spp::sparse_hash_map<std::string, std::string>(),
                                                    metadata,
                                                    spp::sparse_hash_map<std::string, std::set<reference_pair_t>>(),
                                                    synonym_sets, curation_sets, true);
    if (!collection_op.ok()) {
        store->remove(Collection::get_next_seq_id_key(name));
        store->remove(Collection::get_meta_key(name));
        return collection_op;
    }

    auto new_collection = collection_op.get();
    auto new_collection_shared = add_to_collections(new_collection);
    lock.lock();

    std::vector<std::map<std::string, reference_info_t>> ref_info_maps;
    auto it = referenced_ins.find(name);
    if (it != referenced_ins.end()) {
        ref_info_maps.push_back(it->second);
    }

    std::vector<std::string> deferred_ref_symlinks;
    for (const auto& symlink: collection_symlinks) {
        if (symlink.second == name && referenced_ins.find(symlink.first) != referenced_ins.end()) {
            deferred_ref_symlinks.push_back(symlink.first);
        }
    }

    // Don't hold cm lock to prevent lock cycle inversion
    lock.unlock();

    auto rollback_new_collection = [&]() {
        auto drop_op = drop_collection(name, true, false);
        if (!drop_op.ok()) {
            LOG(ERROR) << "Failed to rollback collection `" << name << "`: " << drop_op.error();
        }
    };

    for (const auto& symlink_name: deferred_ref_symlinks) {
        auto validate_op = validate_deferred_references_for_symlink(symlink_name, name);
        if (!validate_op.ok()) {
            rollback_new_collection();
            return Option<Collection*>(validate_op.code(), validate_op.error());
        }
    }

    std::vector<referenced_in_replay_t> referenced_in_replay_plan;
    std::vector<deferred_ref_resolution_t> deferred_ref_resolution_plan;
    std::vector<staged_async_reference_backfill_t> staged_backfills;

    for(auto& ref_info_map: ref_info_maps) {
        referenced_in_replay_t replay{&ref_info_map, {}};
        for (auto& ref_info_item: ref_info_map) {
            auto& ref_info = ref_info_item.second;
            auto update_ref_infos = new_collection->validate_referenced_in(ref_info.collection, ref_info.field,
                                                                           ref_info.referenced_field_name,
                                                                           ref_info.referenced_field);
            replay.update_ref_infos.insert(update_ref_infos.begin(), update_ref_infos.end());
        }

        for (auto& update_ref_info: replay.update_ref_infos) {
            auto coll = get_collection_unsafe(update_ref_info.collection);
            if(coll) {
                const auto ref_info_it = ref_info_map.find(update_ref_info.collection);
                if (ref_info_it != ref_info_map.end() && ref_info_it->second.is_async) {
                    auto stage_op = stage_async_reference_helper_backfill(new_collection_shared, coll,
                                                                          update_ref_info.referenced_field.name,
                                                                          update_ref_info.field, staged_backfills);
                    if (!stage_op.ok()) {
                        rollback_new_collection();
                        return Option<Collection*>(stage_op.code(), stage_op.error());
                    }
                }
            }
        }

        referenced_in_replay_plan.emplace_back(std::move(replay));
    }

    for (const auto& symlink_name: deferred_ref_symlinks) {
        std::map<std::string, reference_info_t> deferred_ref_infos;
        {
            std::shared_lock ref_lock(mutex);
            auto ref_infos_it = referenced_ins.find(symlink_name);
            if (ref_infos_it != referenced_ins.end()) {
                deferred_ref_infos = ref_infos_it->second;
            }
        }

        for (const auto& item: deferred_ref_infos) {
            deferred_ref_resolution_t resolution;
            resolution.symlink_name = symlink_name;
            resolution.referenced_collection_name = name;
            resolution.ref_info = item.second;
            resolution.referencing_coll = get_collection(resolution.ref_info.collection);
            resolution.referenced_coll = get_collection(resolution.referenced_collection_name);

            if (resolution.referenced_coll != nullptr) {
                resolution.referenced_collection_name = resolution.referenced_coll->get_name();
                resolution.update_ref_infos = resolution.referenced_coll->validate_referenced_in(
                        resolution.ref_info.collection, resolution.ref_info.field,
                        resolution.ref_info.referenced_field_name, resolution.ref_info.referenced_field);
                if (resolution.update_ref_infos.empty()) {
                    rollback_new_collection();
                    return Option<Collection*>(400, "Referenced field `" + resolution.ref_info.referenced_field_name +
                                                    "` not found in the collection `" +
                                                    resolution.referenced_collection_name + "`.");
                }

                if (resolution.update_ref_infos.begin()->is_mutual_reference) {
                    auto info = is_referenced_in_with_lock(resolution.ref_info.collection,
                                                           resolution.referenced_collection_name);
                    auto referenced_field = info.ok() ? info.get().field : resolution.update_ref_infos.begin()->field;
                    rollback_new_collection();
                    return Option<Collection*>(400, "Collections having reference to each other are not allowed. `" +
                                                    resolution.ref_info.collection + "` collection is referenced by `" +=
                                                    resolution.referenced_collection_name + "` collection's `" +=
                                                    referenced_field + "` field.");
                }
            }

            if (resolution.ref_info.is_async && resolution.referencing_coll != nullptr &&
                resolution.referenced_coll != nullptr) {
                for (const auto& update_ref_info: resolution.update_ref_infos) {
                    auto stage_op = stage_async_reference_helper_backfill(resolution.referenced_coll,
                                                                          resolution.referencing_coll,
                                                                          update_ref_info.referenced_field.name,
                                                                          update_ref_info.field, staged_backfills);
                    if (!stage_op.ok()) {
                        rollback_new_collection();
                        return Option<Collection*>(stage_op.code(), stage_op.error());
                    }
                }
            }

            deferred_ref_resolution_plan.emplace_back(std::move(resolution));
        }
    }

    auto apply_backfills_op = apply_staged_async_reference_helper_backfills(staged_backfills);
    if (!apply_backfills_op.ok()) {
        rollback_new_collection();
        return Option<Collection*>(apply_backfills_op.code(), apply_backfills_op.error());
    }

    for(auto& replay: referenced_in_replay_plan) {
        new_collection->add_referenced_ins(*replay.ref_info_map);
        for (auto& update_ref_info: replay.update_ref_infos) {
            auto coll = get_collection_unsafe(update_ref_info.collection);
            if(coll) {
                coll->update_reference_info_with_lock(update_ref_info.field, new_collection->get_name(),
                                                      update_ref_info.referenced_field);

                // We do not erase from `referenced_ins` here, because if a referenced collection is dropped and
                // created again, the referenced field won't be updated in referencing collection.
            }
        }
    }

    std::set<std::string> resolved_ref_symlinks;
    std::unique_lock u_lock(mutex, std::defer_lock);
    for (const auto& resolution: deferred_ref_resolution_plan) {
        if (resolution.referenced_coll != nullptr) {
            field referenced_field = resolution.ref_info.referenced_field;
            resolution.referenced_coll->add_referenced_in(resolution.ref_info.collection, resolution.ref_info.field,
                                                          resolution.ref_info.is_async,
                                                          resolution.ref_info.referenced_field_name,
                                                          referenced_field);
        }

        u_lock.lock();
        auto it = referenced_ins.find(resolution.referenced_collection_name);
        if (it == referenced_ins.end()) {
            referenced_ins[resolution.referenced_collection_name] = {
                    {resolution.ref_info.collection, resolution.ref_info}};
        } else {
            referenced_ins[resolution.referenced_collection_name].insert({
                    resolution.ref_info.collection, resolution.ref_info});
        }
        resolved_ref_symlinks.insert(resolution.symlink_name);
        u_lock.unlock();

        if (resolution.referencing_coll == nullptr) {
            continue;
        }

        if (resolution.update_ref_infos.empty()) {
            resolution.referencing_coll->update_reference_info_with_lock(resolution.ref_info.field,
                                                                         resolution.referenced_collection_name,
                                                                         field{});
            continue;
        }

        for (const auto& update_ref_info: resolution.update_ref_infos) {
            resolution.referencing_coll->update_reference_info_with_lock(update_ref_info.field,
                                                                         resolution.referenced_collection_name,
                                                                         update_ref_info.referenced_field);
        }
    }

    if (!resolved_ref_symlinks.empty()) {
        u_lock.lock();
        for (const auto& symlink_name: resolved_ref_symlinks) {
            if (name != symlink_name) {
                referenced_ins.erase(symlink_name);
            }
        }
        persist_referenced_ins();
        u_lock.unlock();
    }

    return Option<Collection*>(new_collection);
}

std::shared_ptr<Collection> CollectionManager::get_collection_unsafe(const std::string & collection_name) const {
    if(collections.count(collection_name) != 0) {
        return collections.at(collection_name);
    }

    // a symlink name takes lesser precedence over a real collection name
    if(collection_symlinks.count(collection_name) != 0) {
        const std::string & symlinked_name = collection_symlinks.at(collection_name);
        if(collections.count(symlinked_name) != 0) {
            return collections.at(symlinked_name);
        }
    }

    return nullptr;
}

std::shared_ptr<Collection> CollectionManager::get_collection(const std::string & collection_name) const {
    std::shared_lock lock(mutex);
    return get_collection_unsafe(collection_name);
}

std::shared_ptr<Collection> CollectionManager::get_collection_with_id(uint32_t collection_id) const {
    std::shared_lock lock(mutex);

    if(collection_id_names.count(collection_id) != 0) {
        return get_collection_unsafe(collection_id_names.at(collection_id));
    }

    return nullptr;
}

Option<std::vector<std::shared_ptr<Collection>>> CollectionManager::get_collections(uint32_t limit, uint32_t offset,
                                                                    const std::vector<std::string>& api_key_collections) const {

    std::shared_lock lock(mutex);

    std::vector<std::shared_ptr<Collection>> collection_vec;
    auto collections_it = collections.begin();

    if(offset > 0) {
        if(offset >= collections.size()) {
            return Option<std::vector<std::shared_ptr<Collection>>>(400, "Invalid offset param.");
        }

        std::advance(collections_it, offset);
    }

    auto collections_end = collections.end();

    if(limit > 0 && (offset + limit < collections.size())) {
        collections_end = collections_it;
        std::advance(collections_end, limit);
    }

    for (collections_it; collections_it != collections_end; ++collections_it) {
        if(is_valid_api_key_collection(api_key_collections, collections_it->second)) {
            collection_vec.push_back(collections_it->second);
        }
    }


    if(offset == 0 && limit == 0) { //dont sort for paginated requests
        std::sort(std::begin(collection_vec), std::end(collection_vec),
                  [](std::shared_ptr<Collection> lhs, std::shared_ptr<Collection> rhs) {
                      return lhs->get_collection_id() > rhs->get_collection_id();
                  });
    }

    return Option<std::vector<std::shared_ptr<Collection>>>(collection_vec);
}

std::vector<std::string> CollectionManager::get_collection_names() const {
    std::shared_lock lock(mutex);

    std::vector<std::string> collection_vec;
    for(const auto& kv: collections) {
        collection_vec.push_back(kv.first);
    }

    return collection_vec;
}

Option<nlohmann::json> CollectionManager::drop_collection(const std::string& collection_name,
                                                          const bool remove_from_store,
                                                          const bool compact_store) {
    std::shared_lock s_lock(mutex);
    auto collection = get_collection_unsafe(collection_name);

    if(collection == nullptr) {
        return Option<nlohmann::json>(404, "No collection with name `" + collection_name + "` found.");
    }

    // to handle alias resolution
    const std::string actual_coll_name = collection->get_name();

    nlohmann::json collection_json = collection->get_summary_json();

    if(remove_from_store) {
        const std::string& del_key_prefix = std::to_string(collection->get_collection_id()) + "_";
        const std::string& del_end_prefix = std::to_string(collection->get_collection_id()) + "`";
        store->delete_range(del_key_prefix, del_end_prefix);

        if(compact_store) {
            store->flush();
            store->compact_range(del_key_prefix, del_end_prefix);
        }

        store->remove(Collection::get_next_seq_id_key(actual_coll_name));
        store->remove(Collection::get_meta_key(actual_coll_name));
    }

    s_lock.unlock();

    // Remove the record of other collections being referenced in this collection.
    auto reference_fields = collection->get_reference_fields();
    for (const auto& item: reference_fields) {
        const auto& reference_info = item.second;

        remove_referenced_ins_with_lock(collection_name, reference_info);
    }

    std::unique_lock u_lock(mutex);
    collections.erase(actual_coll_name);
    collection_id_names.erase(collection->get_collection_id());

    const auto& embedding_fields = collection->get_embedding_fields();

    u_lock.unlock();
    for(const auto& embedding_field : embedding_fields) {
        const auto& model_name = embedding_field.embed[fields::model_config][fields::model_name].get<std::string>();
        if (embedding_field.embed.count(fields::personalization_type) == 0) {
            process_embedding_field_delete(model_name);
        }
    }

    return Option<nlohmann::json>(collection_json);
}

uint32_t CollectionManager::get_next_collection_id() const {
    return next_collection_id;
}

std::string CollectionManager::get_symlink_key(const std::string & symlink_name) {
    return std::string(SYMLINK_PREFIX) + "_" + symlink_name;
}

spp::sparse_hash_map<std::string, std::string> CollectionManager::get_symlinks() const {
    std::shared_lock lock(mutex);
    return collection_symlinks;
}

Option<std::string> CollectionManager::resolve_symlink(const std::string & symlink_name) const {
    std::shared_lock lock(mutex);

    if(collection_symlinks.count(symlink_name) != 0) {
        return Option<std::string>(collection_symlinks.at(symlink_name));
    }

    return Option<std::string>(404, "Not found.");
}

Option<bool> CollectionManager::upsert_symlink(const std::string & symlink_name, const std::string & collection_name) {
    std::unique_lock lock(mutex);
    if(collections.count(symlink_name) != 0) {
        return Option<bool>(500, "Name `" + symlink_name + "` conflicts with an existing collection name.");
    }

    lock.unlock();
    auto validate_op = validate_deferred_references_for_symlink(symlink_name, collection_name);
    if (!validate_op.ok()) {
        return validate_op;
    }

    bool had_existing_symlink = false;
    std::string existing_collection_name;

    lock.lock();
    if(collections.count(symlink_name) != 0) {
        return Option<bool>(500, "Name `" + symlink_name + "` conflicts with an existing collection name.");
    }

    auto existing_symlink_it = collection_symlinks.find(symlink_name);
    had_existing_symlink = existing_symlink_it != collection_symlinks.end();
    existing_collection_name = had_existing_symlink ? existing_symlink_it->second : std::string();

    bool inserted = store->insert(get_symlink_key(symlink_name), collection_name);
    if(!inserted) {
        return Option<bool>(500, "Unable to insert into store.");
    }

    collection_symlinks[symlink_name] = collection_name;
    lock.unlock();

    auto resolve_op = resolve_deferred_references_for_symlink(symlink_name, collection_name);
    Option<bool> reference_update_op = resolve_op;
    if (reference_update_op.ok() && had_existing_symlink && existing_collection_name != collection_name) {
        reference_update_op = rebind_references_for_symlink_target_swap(symlink_name, existing_collection_name,
                                                                        collection_name);
    }

    if (!reference_update_op.ok()) {
        lock.lock();
        if (had_existing_symlink) {
            if (!store->insert(get_symlink_key(symlink_name), existing_collection_name)) {
                LOG(ERROR) << "Unable to rollback symlink `" << symlink_name << "` in store.";
            }
            collection_symlinks[symlink_name] = existing_collection_name;
        } else {
            if (!store->remove(get_symlink_key(symlink_name))) {
                LOG(ERROR) << "Unable to rollback symlink `" << symlink_name << "` from store.";
            }
            collection_symlinks.erase(symlink_name);
        }
        lock.unlock();
    }

    return reference_update_op;
}

Option<bool> CollectionManager::validate_deferred_references_for_symlink(const std::string& symlink_name,
                                                                         const std::string& collection_name) const {
    std::map<std::string, reference_info_t> deferred_ref_infos;
    std::shared_ptr<Collection> ref_coll;

    std::shared_lock lock(mutex);
    auto ref_infos_it = referenced_ins.find(symlink_name);
    if (ref_infos_it != referenced_ins.end()) {
        deferred_ref_infos = ref_infos_it->second;
    }
    ref_coll = get_collection_unsafe(collection_name);
    lock.unlock();

    if (deferred_ref_infos.empty() || ref_coll == nullptr) {
        return Option<bool>(true);
    }

    auto referenced_collection_name = ref_coll->get_name();
    auto ref_collection_reference_fields = ref_coll->get_reference_fields();

    for (const auto& item: deferred_ref_infos) {
        const auto& ref_info = item.second;
        for (const auto& ref_field: ref_collection_reference_fields) {
            if (ref_field.second.collection == ref_info.collection) {
                return Option<bool>(400, "Collections having reference to each other are not allowed. `" +
                                         ref_info.collection + "` collection is referenced by `" +
                                         referenced_collection_name + "` collection's `" + ref_field.first +
                                         "` field.");
            }
        }
    }

    return Option<bool>(true);
}

Option<bool> CollectionManager::resolve_deferred_references_for_symlink(const std::string& symlink_name,
                                                                        const std::string& collection_name) {
    std::map<std::string, reference_info_t> deferred_ref_infos;

    std::shared_lock lock(mutex);
    auto ref_infos_it = referenced_ins.find(symlink_name);
    if (ref_infos_it != referenced_ins.end()) {
        deferred_ref_infos = ref_infos_it->second;
    }
    lock.unlock();

    if (deferred_ref_infos.empty()) {
        return Option<bool>(true);
    }

    auto validate_op = validate_deferred_references_for_symlink(symlink_name, collection_name);
    if (!validate_op.ok()) {
        return validate_op;
    }

    struct deferred_ref_resolution_t {
        std::string referenced_collection_name;
        reference_info_t ref_info;
        std::shared_ptr<Collection> referencing_coll;
        std::shared_ptr<Collection> referenced_coll;
        std::set<update_reference_info_t> update_ref_infos;
    };

    std::vector<deferred_ref_resolution_t> resolution_plan;
    resolution_plan.reserve(deferred_ref_infos.size());

    for (const auto& item: deferred_ref_infos) {
        deferred_ref_resolution_t resolution;
        resolution.referenced_collection_name = collection_name;
        resolution.ref_info = item.second;
        resolution.referencing_coll = get_collection(resolution.ref_info.collection);
        resolution.referenced_coll = get_collection(resolution.referenced_collection_name);

        if (resolution.referenced_coll != nullptr) {
            resolution.referenced_collection_name = resolution.referenced_coll->get_name();
            resolution.update_ref_infos = resolution.referenced_coll->validate_referenced_in(
                    resolution.ref_info.collection, resolution.ref_info.field, resolution.ref_info.referenced_field_name,
                    resolution.ref_info.referenced_field);
            if (resolution.update_ref_infos.empty()) {
                return Option<bool>(400, "Referenced field `" + resolution.ref_info.referenced_field_name +
                                         "` not found in the collection `" + resolution.referenced_collection_name + "`.");
            }

            if (resolution.update_ref_infos.begin()->is_mutual_reference) {
                auto info = is_referenced_in_with_lock(resolution.ref_info.collection,
                                                       resolution.referenced_collection_name);
                auto referenced_field = info.ok() ? info.get().field : resolution.update_ref_infos.begin()->field;
                return Option<bool>(400, "Collections having reference to each other are not allowed. `" +
                                         resolution.ref_info.collection + "` collection is referenced by `" +=
                                         resolution.referenced_collection_name + "` collection's `" +=
                                         referenced_field + "` field.");
            }
        }

        resolution_plan.emplace_back(std::move(resolution));
    }

    std::vector<staged_async_reference_backfill_t> staged_backfills;
    for (const auto& resolution: resolution_plan) {
        if (!resolution.ref_info.is_async || resolution.referencing_coll == nullptr ||
            resolution.referenced_coll == nullptr) {
            continue;
        }

        for (const auto& update_ref_info: resolution.update_ref_infos) {
            auto stage_op = stage_async_reference_helper_backfill(resolution.referenced_coll,
                                                                  resolution.referencing_coll,
                                                                  update_ref_info.referenced_field.name,
                                                                  update_ref_info.field, staged_backfills);
            if (!stage_op.ok()) {
                return stage_op;
            }
        }
    }

    auto apply_backfills_op = apply_staged_async_reference_helper_backfills(staged_backfills);
    if (!apply_backfills_op.ok()) {
        return apply_backfills_op;
    }

    std::unique_lock u_lock(mutex, std::defer_lock);
    for (const auto& resolution: resolution_plan) {
        if (resolution.referenced_coll != nullptr) {
            field referenced_field = resolution.ref_info.referenced_field;
            resolution.referenced_coll->add_referenced_in(resolution.ref_info.collection, resolution.ref_info.field,
                                                          resolution.ref_info.is_async,
                                                          resolution.ref_info.referenced_field_name,
                                                          referenced_field);
        }

        u_lock.lock();
        auto it = referenced_ins.find(resolution.referenced_collection_name);
        if (it == referenced_ins.end()) {
            referenced_ins[resolution.referenced_collection_name] = {
                    {resolution.ref_info.collection, resolution.ref_info}};
        } else {
            referenced_ins[resolution.referenced_collection_name].insert({
                    resolution.ref_info.collection, resolution.ref_info});
        }
        persist_referenced_ins();
        u_lock.unlock();

        if (resolution.referencing_coll == nullptr) {
            continue;
        }

        if (resolution.update_ref_infos.empty()) {
            resolution.referencing_coll->update_reference_info_with_lock(resolution.ref_info.field,
                                                                         resolution.referenced_collection_name,
                                                                         field{});
            continue;
        }

        for (const auto& update_ref_info: resolution.update_ref_infos) {
            resolution.referencing_coll->update_reference_info_with_lock(update_ref_info.field,
                                                                         resolution.referenced_collection_name,
                                                                         update_ref_info.referenced_field);
        }
    }

    if (!deferred_ref_infos.empty() && collection_name != symlink_name) {
        u_lock.lock();
        referenced_ins.erase(symlink_name);
        persist_referenced_ins();
        u_lock.unlock();
    }

    return Option<bool>(true);
}

Option<bool> CollectionManager::rebind_references_for_symlink_target_swap(const std::string& symlink_name,
                                                                          const std::string& old_collection_name,
                                                                          const std::string& new_collection_name) {
    std::map<std::string, reference_info_t> old_ref_infos;
    {
        std::shared_lock lock(mutex);
        auto ref_infos_it = referenced_ins.find(old_collection_name);
        if (ref_infos_it != referenced_ins.end()) {
            old_ref_infos = ref_infos_it->second;
        }
    }

    if (old_ref_infos.empty()) {
        return Option<bool>(true);
    }

    struct symlink_ref_rebind_t {
        reference_info_t ref_info;
        std::shared_ptr<Collection> referencing_coll;
        std::set<update_reference_info_t> update_ref_infos;
    };

    std::vector<symlink_ref_rebind_t> rebind_plan;
    rebind_plan.reserve(old_ref_infos.size());

    const auto alias_reference_prefix = symlink_name + ".";
    for (const auto& item: old_ref_infos) {
        const auto& old_ref_info = item.second;
        auto referencing_coll = get_collection(old_ref_info.collection);
        if (referencing_coll == nullptr) {
            continue;
        }

        auto schema = referencing_coll->get_schema();
        auto schema_it = schema.find(old_ref_info.field);
        if (schema_it == schema.end()) {
            continue;
        }

        const auto& original_reference = schema_it.value().reference;
        if (original_reference.rfind(alias_reference_prefix, 0) != 0) {
            continue;
        }

        auto original_referenced_field_name = original_reference.substr(alias_reference_prefix.size());
        if (original_referenced_field_name != old_ref_info.referenced_field_name) {
            continue;
        }

        symlink_ref_rebind_t rebind;
        rebind.ref_info = old_ref_info;
        rebind.referencing_coll = referencing_coll;
        rebind_plan.emplace_back(std::move(rebind));
    }

    if (rebind_plan.empty()) {
        return Option<bool>(true);
    }

    auto old_coll = get_collection(old_collection_name);
    auto new_coll = get_collection(new_collection_name);
    if (new_coll == nullptr) {
        for (const auto& rebind: rebind_plan) {
            if (old_coll != nullptr) {
                old_coll->remove_referenced_in(rebind.ref_info.collection, rebind.ref_info.field,
                                               rebind.ref_info.is_async, rebind.ref_info.referenced_field_name);
            }

            rebind.referencing_coll->update_reference_info_with_lock(rebind.ref_info.field, new_collection_name, field{});
        }

        std::unique_lock lock(mutex);
        for (const auto& rebind: rebind_plan) {
            auto old_ref_infos_it = referenced_ins.find(old_collection_name);
            if (old_ref_infos_it != referenced_ins.end()) {
                old_ref_infos_it->second.erase(rebind.ref_info.collection);
                if (old_ref_infos_it->second.empty()) {
                    referenced_ins.erase(old_ref_infos_it);
                }
            }

            auto deferred_ref_info = rebind.ref_info;
            deferred_ref_info.referenced_field = field{};
            referenced_ins[new_collection_name][deferred_ref_info.collection] = std::move(deferred_ref_info);
        }
        persist_referenced_ins();

        return Option<bool>(true);
    }

    auto resolved_new_collection_name = new_coll->get_name();
    if (old_collection_name == resolved_new_collection_name) {
        return Option<bool>(true);
    }

    for (auto& rebind: rebind_plan) {
        rebind.update_ref_infos = new_coll->validate_referenced_in(rebind.ref_info.collection,
                                                                   rebind.ref_info.field,
                                                                   rebind.ref_info.referenced_field_name,
                                                                   rebind.ref_info.referenced_field);
        if (rebind.update_ref_infos.empty()) {
            return Option<bool>(400, "Referenced field `" + rebind.ref_info.referenced_field_name +
                                     "` not found in the collection `" + resolved_new_collection_name + "`.");
        }

        if (rebind.update_ref_infos.begin()->is_mutual_reference) {
            auto info = is_referenced_in_with_lock(rebind.ref_info.collection, resolved_new_collection_name);
            auto referenced_field = info.ok() ? info.get().field : rebind.update_ref_infos.begin()->field;
            return Option<bool>(400, "Collections having reference to each other are not allowed. `" +
                                     rebind.ref_info.collection + "` collection is referenced by `" +
                                     resolved_new_collection_name + "` collection's `" + referenced_field + "` field.");
        }
    }

    std::vector<const symlink_ref_rebind_t*> applied_rebinds;
    applied_rebinds.reserve(rebind_plan.size());
    std::vector<staged_async_reference_backfill_t> staged_backfills;
    auto rollback_applied_rebinds = [&]() {
        for (auto it = applied_rebinds.rbegin(); it != applied_rebinds.rend(); ++it) {
            const auto& rebind = **it;

            new_coll->remove_referenced_in(rebind.ref_info.collection, rebind.ref_info.field,
                                           rebind.ref_info.is_async, rebind.ref_info.referenced_field_name);

            if (old_coll != nullptr) {
                field referenced_field = rebind.ref_info.referenced_field;
                old_coll->add_referenced_in(rebind.ref_info.collection, rebind.ref_info.field,
                                            rebind.ref_info.is_async, rebind.ref_info.referenced_field_name,
                                            referenced_field);
            }

            for (const auto& update_ref_info: rebind.update_ref_infos) {
                rebind.referencing_coll->update_reference_info_with_lock(update_ref_info.field,
                                                                         old_collection_name,
                                                                         rebind.ref_info.referenced_field);
            }
        }
    };

    for (const auto& rebind: rebind_plan) {
        if (old_coll != nullptr) {
            old_coll->remove_referenced_in(rebind.ref_info.collection, rebind.ref_info.field,
                                           rebind.ref_info.is_async, rebind.ref_info.referenced_field_name);
        }

        field referenced_field = rebind.ref_info.referenced_field;
        new_coll->add_referenced_in(rebind.ref_info.collection, rebind.ref_info.field, rebind.ref_info.is_async,
                                    rebind.ref_info.referenced_field_name, referenced_field);
        applied_rebinds.emplace_back(&rebind);

        for (const auto& update_ref_info: rebind.update_ref_infos) {
            rebind.referencing_coll->update_reference_info_with_lock(update_ref_info.field,
                                                                     resolved_new_collection_name,
                                                                     update_ref_info.referenced_field);
        }
    }

    for (const auto& rebind: rebind_plan) {
        if (!rebind.ref_info.is_async) {
            continue;
        }

        for (const auto& update_ref_info: rebind.update_ref_infos) {
            auto stage_op = stage_async_reference_helper_backfill(new_coll, rebind.referencing_coll,
                                                                  update_ref_info.referenced_field.name,
                                                                  update_ref_info.field, staged_backfills);
            if (!stage_op.ok()) {
                rollback_applied_rebinds();
                return stage_op;
            }
        }
    }

    auto apply_backfills_op = apply_staged_async_reference_helper_backfills(staged_backfills);
    if (!apply_backfills_op.ok()) {
        rollback_applied_rebinds();
        return apply_backfills_op;
    }

    std::unique_lock lock(mutex);
    for (const auto& rebind: rebind_plan) {
        auto old_ref_infos_it = referenced_ins.find(old_collection_name);
        if (old_ref_infos_it != referenced_ins.end()) {
            old_ref_infos_it->second.erase(rebind.ref_info.collection);
            if (old_ref_infos_it->second.empty()) {
                referenced_ins.erase(old_ref_infos_it);
            }
        }

        referenced_ins[resolved_new_collection_name][rebind.ref_info.collection] = rebind.ref_info;
    }
    persist_referenced_ins();

    return Option<bool>(true);
}

Option<bool> CollectionManager::delete_symlink(const std::string & symlink_name) {
    std::unique_lock lock(mutex);

    bool removed = store->remove(get_symlink_key(symlink_name));
    if(!removed) {
        return Option<bool>(500, "Unable to delete from store.");
    }

    collection_symlinks.erase(symlink_name);
    return Option<bool>(true);
}

Store* CollectionManager::get_store() {
    return store;
}

AuthManager& CollectionManager::getAuthManager() {
    return auth_manager;
}

/// Parses the optional trailing parameters of a multi-eval clause, i.e. everything between the
/// closing `]` and the closing `)` of `_eval([...], <params>)`.
static bool parse_multi_eval_params(const std::string& params_str, sort_by::eval_mode_t& eval_mode) {
    auto params_substr = params_str;
    StringUtils::trim(params_substr);
    if (params_substr.empty()) {
        return true;
    }

    // The span starts right after `]`, so a parameter list opens with the separating comma.
    if (params_substr[0] != ',') {
        return false;
    }
    params_substr = params_substr.substr(1);

    std::vector<std::string> params;
    StringUtils::split(params_substr, params, ",");
    if (params.empty()) {
        return false;
    }

    for (const auto& param: params) {
        // `split` trims each token, so `mode:sum` and `mode: sum` both arrive here the same way.
        std::vector<std::string> param_parts;
        StringUtils::split(param, param_parts, ":");
        if (param_parts.size() != 2 || param_parts[0] != sort_field_const::eval_mode) {
            return false;
        }

        if (param_parts[1] == sort_field_const::eval_mode_sum) {
            eval_mode = sort_by::eval_mode_t::sum_matches;
        } else if (param_parts[1] == sort_field_const::eval_mode_first_match) {
            eval_mode = sort_by::eval_mode_t::first_match;
        } else {
            return false;
        }
    }

    return true;
}

bool parse_multi_eval(const std::string& sort_by_str, uint32_t& index, std::vector<sort_by>& sort_fields) {
    // FORMAT:
    // _eval([ (<expr_1>): <score_1>, (<expr_2>): <score_2> ]):<order>
    // _eval([ (<expr_1>): <score_1>, (<expr_2>): <score_2> ], mode: sum):<order>

    std::vector<std::string> eval_expressions;
    std::vector<std::int64_t> scores;
    while (true) {
        if (index >= sort_by_str.size()) {
            return false;
        } else if (sort_by_str[index] == ']') {
            break;
        }

        auto open_paren_pos = sort_by_str.find('(', index);
        if (open_paren_pos == std::string::npos) {
            return false;
        }
        index = open_paren_pos;
        std::string eval_expr = "(";
        int paren_count = 1;
        bool in_backtick = false;
        while (++index < sort_by_str.size() && paren_count > 0) {
            if (sort_by_str[index] == '`') {
                in_backtick = !in_backtick;
            } else if (!in_backtick && sort_by_str[index] == '(') {
                paren_count++;
            } else if (!in_backtick && sort_by_str[index] == ')') {
                paren_count--;
            }
            eval_expr += sort_by_str[index];
        }

        // Removing outer parenthesis.
        eval_expr = eval_expr.substr(1, eval_expr.size() - 2);
        if (paren_count != 0 || index >= sort_by_str.size()) {
            return false;
        }

        while (sort_by_str[index] != ':' && ++index < sort_by_str.size());
        if (index >= sort_by_str.size()) {
            return false;
        }

        std::string score;
        while (++index < sort_by_str.size() && !(sort_by_str[index] == ',' || sort_by_str[index] == ']')) {
            score += sort_by_str[index];
        }
        StringUtils::trim(score);
        if (!StringUtils::is_int64_t(score)) {
            return false;
        }

        eval_expressions.emplace_back(eval_expr);
        scores.emplace_back(std::stoll(score));
    }

    // `index` is at the closing `]`, so everything up to the closing `)` of `_eval(` is the optional
    // parameter list. It has to be consumed before the scan below, which stops at the first `:`.
    // With a parameter present that first colon belongs to `mode: sum`, not to the order.
    auto const close_paren_pos = sort_by_str.find(')', index);
    if (close_paren_pos == std::string::npos) {
        return false;
    }

    sort_by::eval_mode_t eval_mode = sort_by::eval_mode_t::first_match;
    if (!parse_multi_eval_params(sort_by_str.substr(index + 1, close_paren_pos - index - 1), eval_mode)) {
        return false;
    }
    index = close_paren_pos;

    while (++index < sort_by_str.size() && sort_by_str[index] != ':');
    if (index >= sort_by_str.size()) {
        return false;
    }

    std::string order_str;
    while (++index < sort_by_str.size() && sort_by_str[index] != ',') {
        order_str += sort_by_str[index];
    }
    StringUtils::trim(order_str);
    StringUtils::toupper(order_str);

    sort_fields.emplace_back(eval_expressions, scores, order_str, eval_mode);
    return true;
}

/// Splits a trailing parameter list off the single-expression form, `_eval((<expr>), mode: sum)`.
///
/// The array form is delimited by `]`, so everything after it is unambiguously a parameter. The
/// single-expression form has no such delimiter and a filter value may legally hold a top level
/// comma, as `title:Hello, World` does. Parameters are therefore only recognised when the
/// expression is wrapped in its own parentheses, which lets a plain parenthesis count find where it
/// ends. `_eval(brand:nike, mode: sum)` stays a filter, exactly as it parses today.
///
/// Returns false only when the parameter list is present but unusable.
static bool split_trailing_eval_params(std::string& eval_expr, sort_by::eval_mode_t& eval_mode) {
    auto expr = eval_expr;
    StringUtils::trim(expr);
    if (expr.empty() || expr[0] != '(') {
        return true;
    }

    int paren_count = 0;
    bool in_backtick = false;
    size_t expr_end = std::string::npos;

    for (size_t i = 0; i < expr.size(); i++) {
        const char c = expr[i];
        if (c == '`') {
            in_backtick = !in_backtick;
        } else if (in_backtick) {
            continue;
        } else if (c == '(') {
            paren_count++;
        } else if (c == ')' && --paren_count == 0) {
            expr_end = i;
            break;
        }
    }

    if (expr_end == std::string::npos) {
        return true;
    }

    // A parameter list is introduced by a comma. Anything else following the group belongs to the
    // filter, as in `(a:1) && (b:2)`, and the expression is left exactly as it was.
    auto trailing = expr.substr(expr_end + 1);
    StringUtils::trim(trailing);
    if (trailing.empty() || trailing[0] != ',') {
        return true;
    }

    if (!parse_multi_eval_params(trailing, eval_mode)) {
        return false;
    }

    // Drop the wrapping parentheses along with the parameter list.
    eval_expr = expr.substr(1, expr_end - 1);
    StringUtils::trim(eval_expr);
    return true;
}

bool parse_eval(const std::string& sort_by_str, uint32_t& index, std::vector<sort_by>& sort_fields) {
    // FORMAT:
    // _eval(<expr>):<order>
    // _eval((<expr>), mode: sum):<order>
    std::string eval_expr = "(";
    int paren_count = 1;
    bool in_backtick = false;
    while (++index < sort_by_str.size() && paren_count > 0) {
        if (sort_by_str[index] == '`') {
            in_backtick = !in_backtick;
        } else if (!in_backtick && sort_by_str[index] == '(') {
            paren_count++;
        } else if (!in_backtick && sort_by_str[index] == ')') {
            paren_count--;
        }
        eval_expr += sort_by_str[index];
    }

    // Removing outer parenthesis.
    eval_expr = eval_expr.substr(1, eval_expr.size() - 2);

    if (paren_count != 0 || index >= sort_by_str.size()) {
        return false;
    }

    sort_by::eval_mode_t eval_mode = sort_by::eval_mode_t::first_match;
    if (!split_trailing_eval_params(eval_expr, eval_mode)) {
        return false;
    }

    while (sort_by_str[index] != ':' && ++index < sort_by_str.size());
    if (index >= sort_by_str.size()) {
        return false;
    }

    std::string order_str;
    while (++index < sort_by_str.size() && sort_by_str[index] != ',') {
        order_str += sort_by_str[index];
    }
    StringUtils::trim(order_str);
    StringUtils::toupper(order_str);

    std::vector<std::string> eval_expressions = {eval_expr};
    std::vector<int64_t> scores = {1};
    sort_fields.emplace_back(eval_expressions, scores, order_str, eval_mode);

    return true;
}

bool parse_nested_join_sort_by_str(const std::string& sort_by_str, uint32_t& index, const std::string& parent_coll_name,
                                   std::vector<sort_by>& sort_fields) {
    if (sort_by_str[index] != '$') {
        return false;
    }

    std::string sort_field_expr;
    char prev_non_space_char = '`';

    auto open_paren_pos = sort_by_str.find('(', index);
    if (open_paren_pos == std::string::npos) {
        return false;
    }

    auto const& collection_name = sort_by_str.substr(index + 1, open_paren_pos - index - 1);
    index = open_paren_pos;
    int paren_count = 1;
    while (++index < sort_by_str.size() && paren_count > 0) {
        if (sort_by_str[index] == '(') {
            paren_count++;
        } else if (sort_by_str[index] == ')' && --paren_count == 0) {
            break;
        }

        if (sort_by_str[index] == '$' && (prev_non_space_char == '`' || prev_non_space_char == ',')) {
            // Nested join sort_by

            // Process the sort fields provided up until now.
            if (!sort_field_expr.empty()) {
                sort_fields.emplace_back("$" + collection_name + "(" + sort_field_expr + ")", "");
                auto& collection_names = sort_fields.back().nested_join_collection_names;
                collection_names.insert(collection_names.begin(), parent_coll_name);
                collection_names.emplace_back(collection_name);

                sort_field_expr.clear();
            }

            auto prev_size = sort_fields.size();
            if (!parse_nested_join_sort_by_str(sort_by_str, index, collection_name, sort_fields)) {
                return false;
            }

            for (; prev_size < sort_fields.size(); prev_size++) {
                auto& collection_names = sort_fields[prev_size].nested_join_collection_names;
                collection_names.insert(collection_names.begin(), parent_coll_name);
            }

            continue;
        }
        sort_field_expr += sort_by_str[index];
        if (sort_by_str[index] != ' ') {
            prev_non_space_char = sort_by_str[index];
        }
    }
    if (paren_count != 0) {
        return false;
    }

    if (!sort_field_expr.empty()) {
        sort_fields.emplace_back("$" + collection_name + "(" + sort_field_expr + ")", "");
        auto& collection_names = sort_fields.back().nested_join_collection_names;
        collection_names.insert(collection_names.begin(), parent_coll_name);
        collection_names.emplace_back(collection_name);
    }

    // Skip the space in between the sort_by expressions.
    while (index + 1 < sort_by_str.size() && (sort_by_str[index + 1] == ' ' || sort_by_str[index + 1] == ',')) {
        index++;
    }

    return true;
}

bool CollectionManager::parse_sort_by_str(std::string sort_by_str, std::vector<sort_by>& sort_fields) {
    std::string sort_field_expr;
    char prev_non_space_char = '`';
    int brace_open_count = 0;

    for(uint32_t i=0; i < sort_by_str.size(); i++) {
        if (sort_field_expr.empty()) {
            if (sort_by_str[i] == '$') {
                // Sort by reference field
                auto open_paren_pos = sort_by_str.find('(', i);
                if (open_paren_pos == std::string::npos) {
                    return false;
                }

                auto const& collection_name = sort_by_str.substr(i + 1, open_paren_pos - i - 1);
                i = open_paren_pos;
                int paren_count = 1;
                while (++i < sort_by_str.size() && paren_count > 0) {
                    if (sort_by_str[i] == '(') {
                        paren_count++;
                    } else if (sort_by_str[i] == ')' && --paren_count == 0) {
                        break;
                    }

                    if (sort_by_str[i] == '$' && (prev_non_space_char == '`' || prev_non_space_char == ',')) {
                        // Nested join sort_by

                        // Process the sort fields provided up until now. Doing this step to maintain the order of sort_by
                        // as specified. Eg, `$Customers(product_price:DESC, $foo(bar:asc))` should result into
                        // {`$Customers(product_price:DESC)`, `$Customers($foo(bar:asc))`} and not the other way around.
                        if (!sort_field_expr.empty()) {
                            sort_fields.emplace_back("$" + collection_name + "(" + sort_field_expr + ")", "");
                            sort_field_expr.clear();
                        }

                        if (!parse_nested_join_sort_by_str(sort_by_str, i, collection_name, sort_fields)) {
                            return false;
                        }

                        continue;
                    }
                    sort_field_expr += sort_by_str[i];
                    if (sort_by_str[i] != ' ') {
                        prev_non_space_char = sort_by_str[i];
                    }
                }
                if (paren_count != 0) {
                    return false;
                }

                if (!sort_field_expr.empty()) {
                    sort_fields.emplace_back("$" + collection_name + "(" + sort_field_expr + ")", "");
                    sort_field_expr.clear();
                }

                // Skip the space in between the sort_by expressions.
                while (i + 1 < sort_by_str.size() && (sort_by_str[i + 1] == ' ' || sort_by_str[i + 1] == ',')) {
                    i++;
                }
                continue;
            } else if (sort_by_str.substr(i, 5) == sort_field_const::eval) {
                // Optional filtering
                auto open_paren_pos = sort_by_str.find('(', i);
                if (open_paren_pos == std::string::npos) {
                    return false;
                }

                i = open_paren_pos;
                while(sort_by_str[++i] == ' ');

                if (sort_by_str[i] == '$' && sort_by_str.find('(', i) != std::string::npos) {
                    // Reference expression inside `_eval()`
                    return false;
                }

                auto result = sort_by_str[i] == '[' ? parse_multi_eval(sort_by_str, i, sort_fields) :
                                                        parse_eval(sort_by_str, --i, sort_fields);
                if (!result) {
                    return false;
                }

                // Skip the space in between the sort_by expressions.
                while (i + 1 < sort_by_str.size() && sort_by_str[i + 1] == ' ') {
                    i++;
                }
                continue;
            }
        }

        if(i == sort_by_str.size()-1 || (sort_by_str[i] == ',' && !isdigit(prev_non_space_char)
            && brace_open_count == 0)) {

            if(i == sort_by_str.size()-1) {
                sort_field_expr += sort_by_str[i];
            }

            int colon_index = sort_field_expr.size()-1;

            while(colon_index >= 0) {
                if(sort_field_expr[colon_index] == ':') {
                    break;
                }

                colon_index--;
            }

            if(colon_index < 0 || colon_index+1 == sort_field_expr.size()) {
                return false;
            }

            std::string order_str = sort_field_expr.substr(colon_index+1, sort_field_expr.size()-colon_index+1);
            StringUtils::trim(order_str);
            StringUtils::toupper(order_str);

            std::string field_name = sort_field_expr.substr(0, colon_index);
            StringUtils::trim(field_name);

            sort_fields.emplace_back(field_name, order_str);
            sort_field_expr = "";

            // Skip the space in between the sort_by expressions.
            while (i + 1 < sort_by_str.size() && sort_by_str[i + 1] == ' ') {
                i++;
            }
        } else {
            if(sort_by_str[i] == '(') {
                brace_open_count++;
            } else if(sort_by_str[i] == ')') {
                brace_open_count--;
            }

            sort_field_expr += sort_by_str[i];
        }

        if(sort_by_str[i] != ' ') {
            prev_non_space_char = sort_by_str[i];
        }
    }

    return true;
}

Option<bool> apply_embedded_params(nlohmann::json& embedded_params, std::map<std::string, std::string>& req_params) {
    const auto auth_collection_it = embedded_params.find(AuthManager::AUTH_RESOLVED_COLLECTION_PARAM);

    // enrich params with values from embedded params
    for(auto& item: embedded_params.items()) {
        if(item.key() == "expires_at" || item.key() == AuthManager::AUTH_RESOLVED_COLLECTION_PARAM) {
            continue;
        }

        // overwrite = true as embedded params have higher priority
        if (!AuthManager::add_item_to_params(req_params, item, true)) {
            return Option<bool>(400, "Error applying search parameters inside Scoped Search API key");
        }
    }

    if(auth_collection_it != embedded_params.end() && auth_collection_it->is_string()) {
        // Auth already resolved the target collection; keep execution pinned to it.
        req_params["collection"] = auth_collection_it->get<std::string>();
    }

    return Option<bool>(true);
}

void enforce_scoped_filter_for_curated_hits(const nlohmann::json& embedded_params,
                                            std::map<std::string, std::string>& req_params) {
    if(embedded_params.count("filter_by") != 0) {
        req_params["filter_curated_hits"] = "true";
    }
}

Option<bool> apply_preset(std::map<std::string, std::string>& req_params) {
    const auto preset_it = req_params.find("preset");

    if(preset_it != req_params.end()) {
        nlohmann::json preset;
        const auto& preset_op = CollectionManager::get_instance().get_preset(preset_it->second, preset);

        // NOTE: we merge only single preset configuration because multi ("searches") preset value replaces
        // the request body directly before we reach this single search request function.
        if(preset_op.ok() && !preset.contains("searches")) {
            if(!preset.is_object()) {
                return Option<bool>(400, "Search preset is not an object.");
            }

            for(const auto& search_item: preset.items()) {
                // overwrite = false since req params will contain embedded params and so has higher priority
                bool populated = AuthManager::add_item_to_params(req_params, search_item, false);
                if(!populated) {
                    return Option<bool>(400, "One or more search parameters are malformed.");
                }
            }
        }
    }

    return Option<bool>(true);
}

Option<bool> get_stopword_set(const std::map<std::string, std::string>& req_params, std::string& stopwords_set) {
    //check if stopword set is supplied
    const auto stopword_it = req_params.find("stopwords");

    if(stopword_it != req_params.end()) {
        stopwords_set = stopword_it->second;

        if(!StopwordsManager::get_instance().stopword_exists(stopwords_set)) {
            return Option<bool>(404, "Could not find the stopword set named `" + stopwords_set + "`.");
        }
    }

    return Option<bool>(true);
}

void update_app_metrics(const uint64_t& timeMillis) {
    AppMetrics::get_instance().increment_count(AppMetrics::SEARCH_LABEL, 1);
    AppMetrics::get_instance().increment_duration(AppMetrics::SEARCH_LABEL, timeMillis);
}

Option<bool> CollectionManager::do_search(std::map<std::string, std::string>& req_params,
                                          nlohmann::json& embedded_params,
                                          std::string& results_json_str,
                                          uint64_t start_ts) {

    auto begin = std::chrono::high_resolution_clock::now();

    // enrich params with values from embedded params
    auto const apply_embedded_params_op = apply_embedded_params(embedded_params, req_params);
    if (!apply_embedded_params_op.ok()) {
        return apply_embedded_params_op;
    }

    auto const apply_preset_op = apply_preset(req_params);
    if (!apply_preset_op.ok()) {
        return apply_preset_op;
    }
    enforce_scoped_filter_for_curated_hits(embedded_params, req_params);

    std::string stopwords_set;
    auto const get_stopwords_op = get_stopword_set(req_params, stopwords_set);
    if (!get_stopwords_op.ok()) {
        return get_stopwords_op;
    }

    CollectionManager & collectionManager = CollectionManager::get_instance();
    const std::string& orig_coll_name = req_params["collection"];
    auto collection = collectionManager.get_collection(orig_coll_name);

    if(collection == nullptr) {
        return Option<bool>(404, "Collection not found");
    }

    collection_search_args_t args;
    auto init_op = collection_search_args_t::init(req_params, collection->get_num_documents(), stopwords_set, start_ts,
                                                  args);
    if (!init_op.ok()) {
        return init_op;
    }

    Option<nlohmann::json> result_op = collection->search(args);

    auto end_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
    auto reqTimeMillis = (end_ts - start_ts) / 1000;

    update_app_metrics(reqTimeMillis);

    if(!result_op.ok()) {
        return Option<bool>(result_op.code(), result_op.error());
    }

    nlohmann::json result = result_op.get();

    if(Config::get_instance().get_enable_search_analytics()) {
        if(args.enable_analytics && result.contains("found")) {
            std::string analytics_query = Tokenizer::normalize_ascii_no_spaces(args.raw_query);
            search_internal_event_t internal_event = {
                SearchAnalytics::LOG_TYPE,
                orig_coll_name,
                analytics_query,
                "",
                req_params["x-typesense-user-id"],
                args.filter_query,
                args.analytics_tag
            };
            if(result["found"].get<size_t>() != 0) {
                const std::string& expanded_query = Tokenizer::normalize_ascii_no_spaces(
                        result["request_params"]["first_q"].get<std::string>());
                internal_event.expanded_q = expanded_query;
                AnalyticsManager::get_instance().add_internal_event(internal_event);
                internal_event.type = SearchAnalytics::POPULAR_QUERIES_TYPE;
                AnalyticsManager::get_instance().add_internal_event(internal_event);
            } else {
                AnalyticsManager::get_instance().add_internal_event(internal_event);
                internal_event.type = SearchAnalytics::NO_HIT_QUERIES_TYPE;
                AnalyticsManager::get_instance().add_internal_event(internal_event);
            }
        }
    }

    if(args.exclude_fields.count("search_time_ms") == 0) {
        auto searchTimeMillis = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::high_resolution_clock::now() - begin).count();
        result["search_time_ms"] = searchTimeMillis;
    }

    if(args.page == 0 && args.offset != 0) {
        result["offset"] = args.offset;
    } else {
        result["page"] = (args.page == 0) ? 1 : args.page;
    }

    results_json_str = result.dump(-1, ' ', false, nlohmann::detail::error_handler_t::ignore);

    //LOG(INFO) << "Time taken: " << timeMillis << "ms";

    return Option<bool>(true);
}

void remove_global_params(nlohmann::json& search_params) {
    const std::vector<std::string> params = {
            "page",
            "per_page",
            "offset",
            "limit",
            "limit_hits"
    };

    for (const auto& param: params) {
        search_params.erase(param);
    }
}

void remove_global_params(std::map<std::string, std::string>& req_params) {
    const std::vector<std::string> params = {
            "page",
            "per_page",
            "offset",
            "limit",
            "limit_hits"
    };

    for (const auto& param: params) {
        req_params.erase(param);
    }
}

Option<bool> CollectionManager::validate_facet_params(const std::vector<collection_search_args_t>& coll_searches,
                                                      const std::vector<std::shared_ptr<Collection>>& collections) {
    struct facet_field_parent {
        std::string facet_signature;
        bool should_return_parent;
    };

    const auto& facet_strategy = coll_searches[0].facet_strategy;
    const auto& simple_facet_query = coll_searches[0].simple_facet_query;
    const auto& facet_min_occurrence_ratio = coll_searches[0].facet_min_occurrence_ratio;
    spp::sparse_hash_map<std::string, facet_field_parent> facet_identity_to_facet_field_map;
    std::string generic_error = " should be uniform across searches for faceting with union search.";
    auto facet_identity = [](const facet& a_facet) {
        return a_facet.field_name + "|ref:" + a_facet.reference_collection_name;
    };
    auto facet_signature = [](const facet& a_facet) {
        std::stringstream ss;
        ss << a_facet.field_name
           << "|ref:" << a_facet.reference_collection_name
           << "|range:" << a_facet.is_range_query
           << "|alpha:" << a_facet.is_sort_by_alpha
           << "|order:" << a_facet.sort_order
           << "|sort:" << a_facet.sort_field
           << "|topk:" << a_facet.is_top_k;

        if(a_facet.is_range_query) {
            for(const auto& kv : a_facet.facet_range_map) {
                ss << "|bucket:" << kv.first << ":" << kv.second.lower_range << ":" << kv.second.range_label;
            }
        }

        return ss.str();
    };

    for(size_t search_index = 0; search_index < coll_searches.size(); search_index++) {
        const auto& args = coll_searches[search_index];
        if(args.facet_fields.empty()) {
            continue;
        }

        if(args.facet_strategy != facet_strategy) {
            return Option<bool>(400, "`facet_strategy`" + generic_error);
        }

        if(args.simple_facet_query != simple_facet_query) {
            return Option<bool>(400, "`facet_query`" + generic_error);
        }

        if(args.facet_min_occurrence_ratio != facet_min_occurrence_ratio) {
            return Option<bool>(400, "`facet_min_occurrence_ratio`" + generic_error);
        }

        auto collection = collections[search_index];
        if(collection == nullptr) {
            return Option<bool>(404, "Collection not found while validating union facet params.");
        }

        auto normalized_facet_return_parent = args.facet_return_parent;
        if(!normalized_facet_return_parent.empty()) {
            auto facet_return_parent_op = collection->process_facet_return_parent(normalized_facet_return_parent);
            if(!facet_return_parent_op.ok()) {
                return facet_return_parent_op;
            }
        }

        for(const auto& field : args.facet_fields) {
            std::vector<facet> parsed_facets;
            auto parse_op = collection->parse_facet_with_lock(field, parsed_facets);
            if(!parse_op.ok()) {
                return parse_op;
            }

            for(const auto& a_facet : parsed_facets) {
                const auto field_identity = facet_identity(a_facet);
                const auto signature = facet_signature(a_facet);
                const auto should_return_parent =
                    normalized_facet_return_parent.size() == 1 && normalized_facet_return_parent[0] == "*" ||
                    std::find(normalized_facet_return_parent.begin(), normalized_facet_return_parent.end(),
                              a_facet.field_name) != normalized_facet_return_parent.end();

                auto it1 = facet_identity_to_facet_field_map.find(field_identity);

                if (it1 != facet_identity_to_facet_field_map.end()) {
                    if(signature != it1->second.facet_signature) {
                        return Option<bool>(400, "facet fields" + generic_error);
                    } else if(it1->second.should_return_parent != should_return_parent) {
                        return Option<bool>(400, "`facet_return_parent`" + generic_error);
                    }
                } else {
                    facet_identity_to_facet_field_map[field_identity] =
                        facet_field_parent{signature, should_return_parent};
                }
            }
        }
    }

    return Option<bool>(true);
}

Option<bool> CollectionManager::do_union(std::map<std::string, std::string>& req_params,
                                         std::vector<nlohmann::json>& embedded_params_vec, nlohmann::json searches,
                                         nlohmann::json& response, uint64_t start_ts, bool remove_duplicates) {
    union_global_params_t union_params(req_params);
    if (!union_params.init_op.ok()) {
        const auto& op = union_params.init_op;
        response["error"] = "Error while initializing global parameters of union: " + op.error();
        response["code"] = op.code();
        return Option<bool>(true);
    }
    remove_global_params(req_params);

    auto const orig_req_params = req_params;
    std::vector<collection_search_args_t> coll_searches;
    std::vector<uint32_t> collection_ids;
    std::vector<std::shared_ptr<Collection>> union_collections;
    auto result_op = Option<bool>(true);
    auto group_by_args_count = 0;

    for(size_t i = 0; i < searches.size(); i++) {
        auto& search_params = searches[i];
        req_params = orig_req_params;

        // Only global pagination params are considered during union.
        remove_global_params(search_params);

        auto validate_op = multi_search_validate_and_add_params(req_params, search_params, false);
        if (!validate_op.ok()) {
            result_op = std::move(validate_op);
            break;
        }

        auto begin = std::chrono::high_resolution_clock::now();

        auto& embedded_params = embedded_params_vec[i];
        // enrich params with values from embedded params
        auto apply_embedded_params_op = apply_embedded_params(embedded_params, req_params);
        if (!apply_embedded_params_op.ok()) {
            result_op = std::move(apply_embedded_params_op);
            break;
        }

        auto apply_preset_op = apply_preset(req_params);
        if (!apply_preset_op.ok()) {
            result_op = std::move(apply_preset_op);
            break;
        }
        enforce_scoped_filter_for_curated_hits(embedded_params, req_params);

        std::string stopwords_set;
        auto get_stopwords_op = get_stopword_set(req_params, stopwords_set);
        if (!get_stopwords_op.ok()) {
            result_op = std::move(get_stopwords_op);
            break;
        }

        CollectionManager& collectionManager = CollectionManager::get_instance();
        const std::string& orig_coll_name = req_params["collection"];
        auto collection = collectionManager.get_collection(orig_coll_name);

        if (collection == nullptr) {
            result_op = Option<bool>(404, "`" + orig_coll_name + "` collection not found.");
            break;
        }

        collection_search_args_t args;
        auto init_op = collection_search_args_t::init(req_params, collection->get_num_documents(), stopwords_set,
                                                      start_ts, args);
        if (!init_op.ok()) {
            result_op = std::move(init_op);
            break;
        }

        if(args.group_limit) {
            group_by_args_count++;
        }

        args.curation_union_global_params(union_params);
        coll_searches.emplace_back(std::move(args));
        collection_ids.emplace_back(collection->get_collection_id());
        union_collections.emplace_back(collection);
    }

    if(result_op.ok() && group_by_args_count > 0 && group_by_args_count != searches.size()) {
        result_op = Option<bool>(400, "Invalid group_by searches count. All searches with union search should be uniform.");
    }

    if (result_op.ok()) {
        result_op = validate_facet_params(coll_searches, union_collections);
    }

    if (!result_op.ok()) {
        response["error"] = result_op.error();
        response["code"] = result_op.code();
        return Option<bool>(true);
    }

    std::vector<long> searchTimeMillis;

    auto union_op = Collection::do_union(collection_ids, coll_searches, searchTimeMillis, union_params, response, remove_duplicates);

    auto end_ts = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
    auto reqTimeMillis = (end_ts - start_ts) / 1000;

    update_app_metrics(reqTimeMillis);

    if (!union_op.ok()) {
        if (union_op.code() == 408) {
            return result_op;
        }

        response["error"] = union_op.error();
        response["code"] = union_op.code();
        return Option<bool>(true);
    }

    return Option<bool>(true);
}

ThreadPool* CollectionManager::get_thread_pool() const {
    return thread_pool;
}

Option<nlohmann::json> CollectionManager::get_collection_summaries(uint32_t limit, uint32_t offset,
                                                                   const std::vector<std::string>& exclude_fields,
                                                                   const std::vector<std::string>& api_key_collections) const {
    std::shared_lock lock(mutex);

    auto collections_op = get_collections(limit, offset, api_key_collections);
    if(!collections_op.ok()) {
        return Option<nlohmann::json>(collections_op.code(), collections_op.error());
    }

    std::vector<std::shared_ptr<Collection>> colls = collections_op.get();

    nlohmann::json json_summaries = nlohmann::json::array();
    auto begin = std::chrono::high_resolution_clock::now();

    for(std::shared_ptr<Collection> collection: colls) {
        nlohmann::json collection_json = collection->get_summary_json();
        for(const auto& exclude_field: exclude_fields) {
            collection_json.erase(exclude_field);
        }

        json_summaries.push_back(collection_json);

        uint64_t timeMillis = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::high_resolution_clock::now() - begin).count();

        if(timeMillis > 30000) {
            return Option<nlohmann::json>(408, "Request Timeout. Please use `offset` and `limit` pagination parameters.");
        }
    }

    return Option<nlohmann::json>(json_summaries);
}

Option<Collection*> CollectionManager::create_collection(nlohmann::json& req_json) {
    const char* NUM_MEMORY_SHARDS = "num_memory_shards";
    const char* SYMBOLS_TO_INDEX = "symbols_to_index";
    const char* TOKEN_SEPARATORS = "token_separators";
    const char* ENABLE_NESTED_FIELDS = "enable_nested_fields";
    const char* DEFAULT_SORTING_FIELD = "default_sorting_field";
    const char* METADATA = "metadata";
    const char* SYNONYM_SETS = "synonym_sets";
    const char* curation_sets = "curation_sets";

    // validate presence of mandatory fields

    if(req_json.count("name") == 0) {
        return Option<Collection*>(400, "Parameter `name` is required.");
    }

    const auto& collection_name = req_json["name"];
    if(!collection_name.is_string() || collection_name.get<std::string>().empty()) {
        return Option<Collection*>(400, "Parameter `name` must be a non-empty string.");
    }

    if(req_json.count(NUM_MEMORY_SHARDS) == 0) {
        req_json[NUM_MEMORY_SHARDS] = CollectionManager::DEFAULT_NUM_MEMORY_SHARDS;
    }

    if(req_json.count(SYMBOLS_TO_INDEX) == 0) {
        req_json[SYMBOLS_TO_INDEX] = std::vector<std::string>();
    }

    if(req_json.count(TOKEN_SEPARATORS) == 0) {
        req_json[TOKEN_SEPARATORS] = std::vector<std::string>();
    }

    if(req_json.count(SYNONYM_SETS) == 0) {
        req_json[SYNONYM_SETS] = nlohmann::json::array();
    }

    if(req_json.count(curation_sets) == 0) {
        req_json[curation_sets] = nlohmann::json::array();
    }

    if(req_json.count(ENABLE_NESTED_FIELDS) == 0) {
        req_json[ENABLE_NESTED_FIELDS] = false;
    }

    if(req_json.count("fields") == 0) {
        return Option<Collection*>(400, "Parameter `fields` is required.");
    }

    if(req_json.count(DEFAULT_SORTING_FIELD) == 0) {
        req_json[DEFAULT_SORTING_FIELD] = "";
    }

    if(!req_json[DEFAULT_SORTING_FIELD].is_string()) {
        return Option<Collection*>(400, std::string("`") + DEFAULT_SORTING_FIELD +
                                        "` should be a string. It should be the name of an int32/float field.");
    }

    if(!req_json[NUM_MEMORY_SHARDS].is_number_unsigned()) {
        return Option<Collection*>(400, std::string("`") + NUM_MEMORY_SHARDS + "` should be a positive integer.");
    }

    if(!req_json[SYMBOLS_TO_INDEX].is_array()) {
        return Option<Collection*>(400, std::string("`") + SYMBOLS_TO_INDEX + "` should be an array of character symbols.");
    }

    if(!req_json[TOKEN_SEPARATORS].is_array()) {
        return Option<Collection*>(400, std::string("`") + TOKEN_SEPARATORS + "` should be an array of character symbols.");
    }

    if(!req_json[ENABLE_NESTED_FIELDS].is_boolean()) {
        return Option<Collection*>(400, std::string("`") + ENABLE_NESTED_FIELDS + "` should be a boolean.");
    }

    if(!req_json[SYNONYM_SETS].is_array()) {
        return Option<Collection*>(400, std::string("`") + SYNONYM_SETS + "` should be an array of synonym sets.");
    }

    if(!req_json[curation_sets].is_array()) {
        return Option<Collection*>(400, std::string("`") + curation_sets + "` should be an array of curation sets.");
    }

    for (const auto& synonym_set_name : req_json[SYNONYM_SETS]) {
        if (!synonym_set_name.is_string() || synonym_set_name.get<std::string>().empty()) {
            return Option<Collection*>(400, std::string("`") + SYNONYM_SETS + "` should be an array of non-empty strings.");
        }
        SynonymIndexManager& synonym_index_manager = SynonymIndexManager::get_instance();
        auto get_op = synonym_index_manager.get_synonym_index(synonym_set_name.get<std::string>());
        if (!get_op.ok()) {
            return Option<Collection*>(404, "Synonym set `" + synonym_set_name.get<std::string>() + "` not found.");
        }
    }

    for (const auto& curation_set_name : req_json[curation_sets]) {
        if (!curation_set_name.is_string() || curation_set_name.get<std::string>().empty()) {
            return Option<Collection*>(400, std::string("`") + curation_sets + "` should be an array of non-empty strings.");
        }
        CurationIndexManager& curation_index_manager = CurationIndexManager::get_instance();
        auto get_op = curation_index_manager.get_curation_index(curation_set_name.get<std::string>());
        if (!get_op.ok()) {
            return Option<Collection*>(404, "Curation set `" + curation_set_name.get<std::string>() + "` not found.");
        }
    }

    for (auto it = req_json[SYMBOLS_TO_INDEX].begin(); it != req_json[SYMBOLS_TO_INDEX].end(); ++it) {
        if(!it->is_string() || it->get<std::string>().size() != 1 ) {
            return Option<Collection*>(400, std::string("`") + SYMBOLS_TO_INDEX + "` should be an array of character symbols.");
        }
    }

    for (auto it = req_json[TOKEN_SEPARATORS].begin(); it != req_json[TOKEN_SEPARATORS].end(); ++it) {
        if(!it->is_string() || it->get<std::string>().size() != 1 ) {
            return Option<Collection*>(400, std::string("`") + TOKEN_SEPARATORS + "` should be an array of character symbols.");
        }
    }

    size_t num_memory_shards = req_json[NUM_MEMORY_SHARDS].get<size_t>();
    if(num_memory_shards == 0) {
        return Option<Collection*>(400, std::string("`") + NUM_MEMORY_SHARDS + "` should be a positive integer.");
    }

    // field specific validation

    if(!req_json["fields"].is_array() || req_json["fields"].empty()) {
        return Option<Collection *>(400, "The `fields` value should be an array of objects containing "
                     "`name`, `type` and optionally, `facet` properties.");
    }

    if(req_json.count(METADATA) != 0) {
        if(!req_json[METADATA].is_object()) {
            return Option<Collection *>(400, "The `metadata` value should be an object.");
        }
    } else {
        req_json[METADATA] = {};
    }

    const std::string& default_sorting_field = req_json[DEFAULT_SORTING_FIELD].get<std::string>();

    if(default_sorting_field == "id") {
        return Option<Collection *>(400, "Invalid `default_sorting_field` value: cannot be `id`.");
    }

    std::string fallback_field_type;
    std::vector<field> fields;
    auto parse_op = field::json_fields_to_fields(req_json[ENABLE_NESTED_FIELDS].get<bool>(),
                                                 req_json["fields"], fallback_field_type, fields, collection_name);

    if(!parse_op.ok()) {
        return Option<Collection*>(parse_op.code(), parse_op.error());
    }

    std::shared_ptr<VQModel> model = nullptr;
    if(req_json.count(Collection::COLLECTION_VOICE_QUERY_MODEL) != 0) {
        const nlohmann::json& voice_query_model = req_json[Collection::COLLECTION_VOICE_QUERY_MODEL];

        if(!voice_query_model.is_object()) {
            return Option<Collection*>(400, "Parameter `voice_query_model` must be an object.");
        }

        if(voice_query_model.count("model_name") == 0) {
            return Option<Collection*>(400, "Parameter `voice_query_model.model_name` is required.");
        }

        if(!voice_query_model["model_name"].is_string() || voice_query_model["model_name"].get<std::string>().empty()) {
            return Option<Collection*>(400, "Parameter `voice_query_model.model_name` must be a non-empty string.");
        }

        const std::string& model_name = voice_query_model["model_name"].get<std::string>();
        auto model_res = VQModelManager::get_instance().validate_and_init_model(model_name);
        if(!model_res.ok()) {
            LOG(ERROR) << "Error while loading voice query model: " << model_res.error();
            return Option<Collection*>(model_res.code(), model_res.error());
        } else {
            model = model_res.get();
        }
    }


    const auto created_at = static_cast<uint64_t>(std::time(nullptr));

    return CollectionManager::get_instance().create_collection(collection_name, num_memory_shards,
                                                                fields, default_sorting_field, created_at,
                                                                fallback_field_type,
                                                                req_json[SYMBOLS_TO_INDEX],
                                                                req_json[TOKEN_SEPARATORS],
                                                                req_json[ENABLE_NESTED_FIELDS],
                                                                model, req_json[METADATA], req_json[SYNONYM_SETS], req_json[curation_sets]);
}

Option<bool> CollectionManager::load_collection(const nlohmann::json &collection_meta,
                                                const size_t batch_size,
                                                const StoreStatus& next_coll_id_status,
                                                const std::atomic<bool>& quit,
                                                const std::map<std::string, std::map<std::string, reference_info_t>>& referenced_infos) {

    auto& cm = CollectionManager::get_instance();

    if(!collection_meta.contains(Collection::COLLECTION_NAME_KEY)) {
        return Option<bool>(500, "No collection name in collection meta: " + collection_meta.dump());
    }

    if(!collection_meta[Collection::COLLECTION_NAME_KEY].is_string()) {
        LOG(ERROR) << collection_meta[Collection::COLLECTION_NAME_KEY];
        LOG(ERROR) << Collection::COLLECTION_NAME_KEY;
        LOG(ERROR) << "";
    }
    const std::string & this_collection_name = collection_meta[Collection::COLLECTION_NAME_KEY].get<std::string>();

    std::string collection_next_seq_id_str;
    StoreStatus next_seq_id_status = cm.store->get(Collection::get_next_seq_id_key(this_collection_name),
                                                collection_next_seq_id_str);

    if(next_seq_id_status == StoreStatus::ERROR) {
        LOG(ERROR) << "Error while fetching next sequence ID for " << this_collection_name;
        return Option<bool>(500, "Error while fetching collection's next sequence ID from the disk for "
                                 "`" + this_collection_name + "`");
    }

    if(next_seq_id_status == StoreStatus::NOT_FOUND && next_coll_id_status == StoreStatus::FOUND) {
        LOG(ERROR) << "collection's next sequence ID is missing";
        return Option<bool>(500, "Next collection id was found, but collection's next sequence ID is missing for "
                                 "`" + this_collection_name + "`");
    }

    uint32_t collection_next_seq_id = next_seq_id_status == StoreStatus::NOT_FOUND ? 0 :
                                      StringUtils::deserialize_uint32_t(collection_next_seq_id_str);

    {
        std::shared_lock lock(cm.mutex);
        std::shared_ptr<Collection> existing_collection = cm.get_collection_unsafe(this_collection_name);

        if(existing_collection != nullptr) {
            // To maintain idempotency, if the collection already exists in-memory, drop it from memory
            LOG(WARNING) << "Dropping duplicate collection " << this_collection_name << " before loading it again.";
            lock.unlock();
            cm.drop_collection(this_collection_name, false);
        }
    }

    auto op = init_collection(collection_meta, collection_next_seq_id, cm.store, 1.0f, referenced_infos);
    if (!op.ok()) {
        return Option<bool>(op.code(), op.error());
    }
    Collection* collection = op.get();

    LOG(INFO) << "Loading collection " << collection->get_name();

    // migrate synonyms if exists
    const std::string& syn_lower_bound_key =
                std::string(SynonymIndex::OLD_COLLECTION_SYNONYM_PREFIX) + "_" + this_collection_name + "_";

    std::string syn_upper_bound_key = std::string(SynonymIndex::OLD_COLLECTION_SYNONYM_PREFIX) + "_" +
                                      this_collection_name + "`";  // cannot inline this
    std::vector<std::string> collection_synonym_jsons;
    cm.store->scan_fill(syn_lower_bound_key, syn_upper_bound_key,
                        collection_synonym_jsons);
    if(!collection_synonym_jsons.empty()) {
        SynonymIndexManager& synonym_index_manager = SynonymIndexManager::get_instance();
        auto get_op = synonym_index_manager.get_synonym_index(this_collection_name + "_synonyms_index");
        if(get_op.ok()) {
            LOG(INFO) << "Synonym index already exists for collection " << this_collection_name
                       << ", skipping migration";
        } else {
          auto synonym_index_op = synonym_index_manager.add_synonym_index(this_collection_name + "_synonyms_index");
          if(!synonym_index_op.ok()) {
              LOG(ERROR) << "Error while creating synonym index for collection " << this_collection_name
                        << ": " << synonym_index_op.error();
              return Option<bool>(synonym_index_op.code(), synonym_index_op.error());
          }
          auto synonym_index = synonym_index_op.get();

          for(const auto & collection_synonym_json: collection_synonym_jsons) {
              nlohmann::json collection_synonym = nlohmann::json::parse(collection_synonym_json);
              synonym_t synonym;
              auto parse_op = synonym_t::parse(collection_synonym, synonym);
              if(!parse_op.ok()) {
                  LOG(ERROR) << "Skipping loading of synonym: " << parse_op.error();
                  continue;
              }
              auto add_op = synonym_index->add_synonym(synonym, true);
              if(!add_op.ok()) {
                  LOG(ERROR) << "Error while adding synonym: " << add_op.error();
              }
          }

          // Add the SynonymIndex to the collection
          collection->set_synonym_sets({this_collection_name + "_synonyms_index"});

          LOG(INFO) << "Migrated synonyms for collection " << this_collection_name;
        }
    }

    // migrate curations if exists
    const std::string& ov_lower_bound_key =
                std::string(CurationIndex::OLD_COLLECTION_OVERRIDE_PREFIX) + "_" + this_collection_name + "_";
    std::string ov_upper_bound_key = std::string(CurationIndex::OLD_COLLECTION_OVERRIDE_PREFIX) + "_" +
                                      this_collection_name + "`";  // cannot inline this
    std::vector<std::string> collection_curation_jsons;
    cm.store->scan_fill(ov_lower_bound_key, ov_upper_bound_key, collection_curation_jsons);
    if(!collection_curation_jsons.empty()) {
        CurationIndexManager& curation_index_manager = CurationIndexManager::get_instance();
        // Create a new CurationIndex for the collection
        auto get_op = curation_index_manager.get_curation_index(this_collection_name + "_curations_index");
        if(get_op.ok()) {
            LOG(INFO) << "Curation index already exists for collection " << this_collection_name
                       << ", skipping migration";
        } else {
          auto curation_index_op = curation_index_manager.add_curation_index(this_collection_name + "_curations_index");
          if(!curation_index_op.ok()) {
              LOG(ERROR) << "Error while creating curation index for collection " << this_collection_name
                        << ": " << curation_index_op.error();
              return Option<bool>(curation_index_op.code(), curation_index_op.error());
          }
          CurationIndex* curation_index = curation_index_op.get();
          for(const auto & collection_curation_json: collection_curation_jsons) {
              nlohmann::json collection_curation = nlohmann::json::parse(collection_curation_json);
              curation_t curation;
              std::string curation_id = collection_curation.value("id", std::string{});
              auto parse_op = curation_t::parse(collection_curation, curation_id, curation);
              if(!parse_op.ok()) {
                  LOG(ERROR) << "Skipping loading of curation: " << parse_op.error();
                  continue;
              }
              auto add_op = curation_index->add_curation(curation, true);
              if(!add_op.ok()) {
                  LOG(ERROR) << "Error while adding curation: " << add_op.error();
              }
          }
          collection->set_curation_sets({this_collection_name + "_curations_index"});
          LOG(INFO) << "Migrated curations for collection " << this_collection_name;
        }
    }

    // Fetch records from the store and re-create memory index
    const std::string seq_id_prefix = collection->get_seq_id_collection_prefix();
    std::string upper_bound_key = collection->get_seq_id_collection_prefix() + "`";  // cannot inline this
    rocksdb::Slice upper_bound(upper_bound_key);

    rocksdb::Iterator* iter = cm.store->scan(seq_id_prefix, &upper_bound);
    std::unique_ptr<rocksdb::Iterator> iter_guard(iter);

    std::vector<index_record> index_records;

    size_t num_found_docs = 0;
    size_t num_valid_docs = 0;
    size_t num_indexed_docs = 0;
    size_t batch_doc_str_size = 0;

    auto begin = std::chrono::high_resolution_clock::now();

    while(iter->Valid() && iter->key().starts_with(seq_id_prefix)) {
        num_found_docs++;
        const uint32_t seq_id = Collection::get_seq_id_from_key(iter->key().ToString());

        nlohmann::json document;
        const std::string& doc_string = iter->value().ToString();

        try {
            document = nlohmann::json::parse(doc_string);
        } catch(const std::exception& e) {
            LOG(ERROR) << "JSON error: " << e.what();
            return Option<bool>(400, "Bad JSON.");
        }

        batch_doc_str_size += doc_string.size();

        if(collection->get_enable_nested_fields()) {
            std::vector<field> flattened_fields;
            field::flatten_doc(document, collection->get_nested_fields(), {}, false, flattened_fields);
        }

        auto dirty_values = DIRTY_VALUES::COERCE_OR_DROP;

        num_valid_docs++;

        index_records.emplace_back(index_record(0, seq_id, document, CREATE, dirty_values));

        // Peek and check for last record right here so that we handle batched indexing correctly
        // Without doing this, the "last batch" would have to be indexed outside the loop.
        iter->Next();
        bool last_record = !(iter->Valid() && iter->key().starts_with(seq_id_prefix));

        // if expected memory usage exceeds 250M, we index the accumulated set without caring about batch size
        bool exceeds_batch_mem_threshold = ((batch_doc_str_size * 7) > (250 * 1014 * 1024));

        // batch must match atleast the number of shards
         if(exceeds_batch_mem_threshold || (num_valid_docs % batch_size == 0) || last_record) {
            size_t num_records = index_records.size();
            std::unordered_set<std::string> dummy;
            size_t num_indexed = collection->batch_index_in_memory(index_records, 200, 60000, 2, false, dummy);
            batch_doc_str_size = 0;

            if(num_indexed != num_records) {
                const std::string& index_error = get_first_index_error(index_records);
                if(!index_error.empty()) {
                    // for now, we will just ignore errors during loading of collection
                    //return Option<bool>(400, index_error);
                }
            }

            index_records.clear();
            num_indexed_docs += num_indexed;
        }

        if(num_found_docs % ((1 << 14)) == 0) {
            // having a cheaper higher layer check to prevent checking clock too often
            auto time_elapsed = std::chrono::duration_cast<std::chrono::seconds>(
                    std::chrono::high_resolution_clock::now() - begin).count();

            if(time_elapsed > 30) {
                begin = std::chrono::high_resolution_clock::now();
                LOG(INFO) << "Loaded " << num_found_docs << " documents from " << collection->get_name() << " so far.";
            }
        }

        if(quit) {
            break;
        }
    }

    cm.add_to_collections(collection);

    LOG(INFO) << "Indexed " << num_indexed_docs << "/" << num_found_docs
              << " documents into collection " << collection->get_name();

    return Option<bool>(true);
}

spp::sparse_hash_map<std::string, nlohmann::json> CollectionManager::get_presets() const {
    std::shared_lock lock(mutex);
    return preset_configs;
}

Option<bool> CollectionManager::get_preset(const string& preset_name, nlohmann::json& preset) const {
    std::shared_lock lock(mutex);

    const auto& it = preset_configs.find(preset_name);
    if(it != preset_configs.end()) {
        preset = it->second;
        return Option<bool>(true);
    }

    return Option<bool>(404, "Not found.");
}

Option<bool> CollectionManager::upsert_preset(const string& preset_name, const nlohmann::json& preset_config) {
    std::unique_lock lock(mutex);

    bool inserted = store->insert(get_preset_key(preset_name), preset_config.dump());
    if(!inserted) {
        return Option<bool>(500, "Unable to insert into store.");
    }

    preset_configs[preset_name] = preset_config;
    return Option<bool>(true);
}

std::string CollectionManager::get_preset_key(const string& preset_name) {
    return std::string(PRESET_PREFIX) + "_" + preset_name;
}

Option<bool> CollectionManager::delete_preset(const string& preset_name) {
    std::unique_lock lock(mutex);

    bool removed = store->remove(get_preset_key(preset_name));
    if(!removed) {
        return Option<bool>(500, "Unable to delete from store.");
    }

    preset_configs.erase(preset_name);
    return Option<bool>(true);
}

Option<Collection*> CollectionManager::clone_collection(const string& existing_name, const nlohmann::json& req_json,
                                                       const bool copy_documents) {
    std::shared_lock lock(mutex);

    if(collections.count(existing_name) == 0) {
        return Option<Collection*>(400, "Collection with name `" + existing_name + "` not found.");
    }

    if(req_json.count("name") == 0 || !req_json["name"].is_string()) {
        return Option<Collection*>(400, "Collection name must be provided.");
    }

    const std::string& new_name = req_json["name"].get<std::string>();

    if(collections.count(new_name) != 0) {
        return Option<Collection*>(400, "Collection with name `" + new_name + "` already exists.");
    }

    std::shared_ptr<Collection> existing_coll = collections[existing_name];

    std::vector<std::string> symbols_to_index;
    std::vector<std::string> token_separators;

    for(auto c: existing_coll->get_symbols_to_index()) {
        symbols_to_index.emplace_back(1, c);
    }

    for(auto c: existing_coll->get_token_separators()) {
        token_separators.emplace_back(1, c);
    }

    lock.unlock();

    auto coll_create_op = create_collection(new_name, DEFAULT_NUM_MEMORY_SHARDS, existing_coll->get_fields(),
                              existing_coll->get_default_sorting_field(), static_cast<uint64_t>(std::time(nullptr)),
                              existing_coll->get_fallback_field_type(), symbols_to_index, token_separators,
                              existing_coll->get_enable_nested_fields(), existing_coll->get_vq_model(),
                              {}, existing_coll->get_synonym_sets(), existing_coll->get_curation_sets());

    lock.lock();

    if(!coll_create_op.ok()) {
        return Option<Collection*>(coll_create_op.code(), coll_create_op.error());
    }

    Collection* new_coll = coll_create_op.get();


    // copy documents if requested
    if(copy_documents) {
        lock.unlock();

        LOG(INFO) << "Copying documents from " << existing_name << " to " << new_name;

        // Fetch records from the store and index them in the new collection using add_many
        const std::string seq_id_prefix = existing_coll->get_seq_id_collection_prefix();
        std::string upper_bound_key = existing_coll->get_seq_id_collection_prefix() + "`";
        rocksdb::Slice upper_bound(upper_bound_key);

        rocksdb::Iterator* iter = store->scan(seq_id_prefix, &upper_bound);
        std::unique_ptr<rocksdb::Iterator> iter_guard(iter);

        std::vector<std::string> json_batch;
        size_t num_found_docs = 0;
        size_t num_indexed_docs = 0;
        size_t batch_doc_str_size = 0;
        const size_t batch_size = 1000;

        auto begin = std::chrono::high_resolution_clock::now();

        while(iter->Valid() && iter->key().starts_with(seq_id_prefix)) {
            num_found_docs++;

            nlohmann::json document;
            const std::string& doc_string = iter->value().ToString();

            try {
                document = nlohmann::json::parse(doc_string);
            } catch(const std::exception& e) {
                LOG(ERROR) << "JSON error during document copy: " << e.what();
                iter->Next();
                continue;
            }

            batch_doc_str_size += doc_string.size();
            json_batch.emplace_back(doc_string);

            // Peek and check for last record
            iter->Next();
            bool last_record = !(iter->Valid() && iter->key().starts_with(seq_id_prefix));

            // Check memory threshold and batch processing
            bool exceeds_batch_mem_threshold = ((batch_doc_str_size * 7) > (250 * 1024 * 1024));

            if(exceeds_batch_mem_threshold || (json_batch.size() >= batch_size) || last_record) {
                // Use add_many which handles both indexing and storage properly
                nlohmann::json dummy_doc;
                auto add_result = new_coll->add_many(json_batch, dummy_doc, CREATE, "", DIRTY_VALUES::COERCE_OR_DROP);

                size_t num_imported = 0;
                if(add_result.contains("num_imported")) {
                    num_imported = add_result["num_imported"].get<size_t>();
                }

                num_indexed_docs += num_imported;
                batch_doc_str_size = 0;
                json_batch.clear();

                // Progress logging
                if(num_found_docs % 10000 == 0 && num_found_docs > 0) {
                    auto time_elapsed = std::chrono::duration_cast<std::chrono::seconds>(
                            std::chrono::high_resolution_clock::now() - begin).count();

                    if(time_elapsed > 30) {
                        begin = std::chrono::high_resolution_clock::now();
                        LOG(INFO) << "Copied " << num_found_docs << " documents so far.";
                    }
                }
            }
        }

        LOG(INFO) << "Successfully copied " << num_indexed_docs << "/" << num_found_docs
                  << " documents from " << existing_name << " to " << new_name;

        lock.lock();
    }

    return Option<Collection*>(new_coll);
}

Option<bool> CollectionManager::add_referenced_ins_with_lock(std::string& referenced_collection_name, reference_info_t&& ref_info,
                                                             std::set<update_reference_info_t>& update_ref_infos,
                                                             bool is_live_request) {
    std::unique_lock lock(mutex);
    return add_referenced_ins(referenced_collection_name, std::move(ref_info), update_ref_infos, is_live_request);
}

Option<bool> CollectionManager::add_referenced_ins(std::string& referenced_collection_name, reference_info_t&& ref_info,
                                                   std::set<update_reference_info_t>& update_ref_infos,
                                                   bool is_live_request) {
    auto ref_coll = get_collection_unsafe(referenced_collection_name);
    std::set<update_reference_info_t> _update_ref_infos{};
    if (ref_coll != nullptr) {
        referenced_collection_name = ref_coll->get_name(); // resolves alias

        // If the collections are created in parallel, we can have a TOCTOU race condition where the referencing collection
        // is yet to call CollectionManager::add_referenced_ins() and the referenced collection checks
        // `CollectionManager::referenced_ins` in `CollectionManager::create_collection` and doesn't find reference. So its
        // `referenced_in` isn't updated. To avoid this scenario we're going to call add_referenced_ins() on referenced collection.
        _update_ref_infos = ref_coll->add_referenced_in(ref_info.collection, ref_info.field, ref_info.is_async,
                                                        ref_info.referenced_field_name, ref_info.referenced_field);
        if (!_update_ref_infos.empty() && _update_ref_infos.begin()->is_mutual_reference) {
            auto info = is_referenced_in(ref_info.collection, referenced_collection_name);
            return Option<bool>(400, "Collections having reference to each other are not allowed. `" + ref_info.collection +
                                     "` collection is referenced by `" += referenced_collection_name + "` collection's `" +=
                                                                                  info.get().field + "` field.");
        }
    }

    update_ref_infos.insert(_update_ref_infos.begin(), _update_ref_infos.end());

    if (!is_live_request) {
        auto it = collection_symlinks.find(referenced_collection_name);
        if (it != collection_symlinks.end()) {
            referenced_collection_name = it->second;
        }
        return Option<bool>(true);
    }

    auto it = referenced_ins.find(referenced_collection_name);
    if (it == referenced_ins.end()) {
        referenced_ins[referenced_collection_name] = {{ref_info.collection, ref_info}};
    } else {
        referenced_ins[referenced_collection_name].insert({ref_info.collection, ref_info});
    }

    persist_referenced_ins();
    return Option<bool>(true);
}

void CollectionManager::remove_referenced_ins_with_lock(const std::string& referencing_coll_name,
                                                        const reference_info_t& ref_info) {
    std::unique_lock lock(mutex);
    if (referencing_coll_name.empty()) {
        return;
    }

    const auto& referenced_coll_name = ref_info.collection;
    auto referenced_it = referenced_ins.find(referenced_coll_name);
    if (referenced_it == referenced_ins.end()) {
        return;
    }
    auto referencing_it = referenced_it->second.find(referencing_coll_name);
    if (referencing_it == referenced_it->second.end()) {
        return;
    }
    const auto referencing_field_name = referencing_it->second.field;
    referenced_it->second.erase(referencing_it);
    if (referenced_it->second.empty()) {
        referenced_ins.erase(referenced_it);
    }
    persist_referenced_ins();

    auto ref_coll = get_collection_unsafe(referenced_coll_name);
    if (ref_coll == nullptr) {
        LOG(ERROR) << "Could not remove referenced in: Referenced collection `" + referenced_coll_name + "` not found.";
        return;
    }
    ref_coll->remove_referenced_in(referencing_coll_name, referencing_field_name, ref_info.is_async,
                                   ref_info.referenced_field.name);
}

std::map<std::string, std::map<std::string, reference_info_t>> CollectionManager::_get_referenced_ins() const {
    std::shared_lock lock(mutex);
    return referenced_ins;
}

void CollectionManager::process_embedding_field_delete(const std::string& model_name) {
    std::shared_lock lock(mutex);
    bool found = false;

    for(const auto& collection: collections) {
        // will be deadlock if we try to acquire lock on collection here
        // caller of this function should have already acquired lock on collection
        const auto& embedding_fields = collection.second->get_embedding_fields_unsafe();

        for(const auto& embedding_field: embedding_fields) {
            if(embedding_field.embed.count(fields::model_config) != 0) {
                const auto& model_config = embedding_field.embed[fields::model_config];
                if(model_config[fields::model_name].get<std::string>() == model_name) {
                    found = true;
                    break;
                }
            }
        }
    }

    if(!found) {
        LOG(INFO) << "Deleting text embedder: " << model_name;
        EmbedderManager::get_instance().delete_text_embedder(model_name);
        EmbedderManager::get_instance().delete_image_embedder(model_name);
    }
}

std::unordered_set<std::string> CollectionManager::get_collection_references(const std::string& coll_name) {
    std::unordered_set<std::string> references;
    auto coll = get_collection(coll_name);
    if(coll == nullptr) {
        return references;
    }

    for (const auto& item: coll->get_reference_fields()) {
        const auto& ref_pair = item.second;
        references.insert(ref_pair.collection);
    }

    return references;
}

std::unordered_set<std::string> CollectionManager::get_nested_referencing_collections(const std::string& coll_name) {
    std::shared_lock lock(mutex);

    auto it = referenced_ins.find(coll_name);
    if (it == referenced_ins.end()) {
        return {};
    }

    std::unordered_set<std::string> referencing_collections;
    std::queue<std::string> pending_collections;

    for (const auto& [ref_coll_name, _] : it->second) {
        if (referencing_collections.insert(ref_coll_name).second) {
            pending_collections.push(ref_coll_name);
        }
    }

    while (!pending_collections.empty()) {
        auto nested_ref_coll = pending_collections.front();
        pending_collections.pop();

        auto nested_it = referenced_ins.find(nested_ref_coll);
        if (nested_it == referenced_ins.end()) {
            continue;
        }

        for (const auto& [nested_ref_coll_name, _] : nested_it->second) {
            if (referencing_collections.insert(nested_ref_coll_name).second) {
                pending_collections.push(nested_ref_coll_name);
            }
        }
    }

    return referencing_collections;
}

bool CollectionManager::is_valid_api_key_collection(const std::vector<std::string>& api_collections,
                                                    std::shared_ptr<Collection> coll) const {
    for(const auto& api_collection : api_collections) {
        if(api_collection == "*") {
            return true;
        }

        const std::regex pattern(api_collection);
        if(std::regex_match(coll->get_name(), pattern)) {
            return true;
        }
    }
    return api_collections.size() > 0 ? false : true;
}

Option<bool> CollectionManager::update_collection_metadata(const std::string& collection, const nlohmann::json& metadata) {
    auto collection_ptr = get_collection(collection);
    if (collection_ptr == nullptr) {
        return Option<bool>(400, "failed to get collection.");
    }

    collection_ptr->update_metadata(metadata);

    std::string collection_meta_str;

    auto collection_metakey = Collection::get_meta_key(collection);
    store->get(collection_metakey, collection_meta_str);

    auto collection_meta_json = nlohmann::json::parse(collection_meta_str);

    collection_meta_json[Collection::COLLECTION_METADATA] = metadata;

    if(store->insert(collection_metakey, collection_meta_json.dump())) {
        return Option<bool>(true);
    }

    return Option<bool>(400, "failed to insert into store.");
}

Option<nlohmann::json> CollectionManager::get_collection_alter_status() const {
    nlohmann::json collection_alter_status = nlohmann::json::array();

    if(collections.empty()) {
        return Option<nlohmann::json>(400, "No collections are added.");
    }

    std::unique_lock lock(mutex);

    for(const auto& kv : collections) {
        auto op = kv.second->get_alter_schema_status();
        if(op.ok()) {
            collection_alter_status.push_back(op.get());
        }
    }

    return Option<nlohmann::json>(collection_alter_status);
}

void CollectionManager::remove_internal_fields(std::map<std::string, std::string>& params) {
    auto it = params.begin();
    while (it != params.end()) {
        if (!it->first.empty() && it->first[0] == '_') {
            it = params.erase(it);
        } else {
            ++it;
        }
    }
}

Option<bool> CollectionManager::update_collection_synonym_sets(const std::string& collection,
                                                               const std::vector<std::string>& synonym_sets,
                                                               bool is_live_req) {
    auto collection_ptr = get_collection(collection);
    if (collection_ptr == nullptr) {
        return Option<bool>(400, "failed to get collection.");
    }

    auto& synonym_index_manager = SynonymIndexManager::get_instance();
    if (is_live_req) {
        for (const auto& synonym_set_name : synonym_sets) {
        auto get_op = synonym_index_manager.get_synonym_index(synonym_set_name);
            if (!get_op.ok()) {
                return Option<bool>(404, "Synonym set `" + synonym_set_name + "` not found.");
            }
        }
    }

    collection_ptr->update_synonym_sets(synonym_sets);

    std::string collection_meta_str;

    auto collection_metakey = Collection::get_meta_key(collection);
    store->get(collection_metakey, collection_meta_str);

    auto collection_meta_json = nlohmann::json::parse(collection_meta_str);

    collection_meta_json[Collection::COLLECTION_SYNONYM_SETS] = synonym_sets;

    if(store->insert(collection_metakey, collection_meta_json.dump())) {
        return Option<bool>(true);
    }

    return Option<bool>(400, "failed to insert into store.");
}

Option<bool> CollectionManager::update_collection_curation_sets(const std::string& collection,
                                                                const std::vector<std::string>& curation_sets,
                                                                bool is_live_req) {
    auto collection_ptr = get_collection(collection);
    if (collection_ptr == nullptr) {
        return Option<bool>(400, "failed to get collection.");
    }

    if (is_live_req) {
        for (const auto& curation_set_name : curation_sets) {
            auto get_op = CurationIndexManager::get_instance().get_curation_index(curation_set_name);
            if (!get_op.ok()) {
                return Option<bool>(404, "Curation set `" + curation_set_name + "` not found.");
            }
        }
    }

    collection_ptr->update_curation_sets(curation_sets);

    std::string collection_meta_str;

    auto collection_metakey = Collection::get_meta_key(collection);
    store->get(collection_metakey, collection_meta_str);

    auto collection_meta_json = nlohmann::json::parse(collection_meta_str);

    collection_meta_json[Collection::COLLECTION_curation_sets] = curation_sets;

    if (store->insert(collection_metakey, collection_meta_json.dump())) {
        return Option<bool>(true);
    }

    return Option<bool>(400, "failed to insert into store.");
}

Option<bool> CollectionManager::get_document_from_store(const std::string collection_name, const uint32_t& seq_id,
                                                        nlohmann::json& document, bool raw_doc) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->get_document_from_store(seq_id, document, raw_doc);
}

Option<uint32_t> CollectionManager::doc_id_to_seq_id(const std::string collection_name, const std::string& doc_id) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<uint32_t>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->doc_id_to_seq_id(doc_id);
}

Option<bool> CollectionManager::get_filter_ids(const std::string collection_name, const std::string& filter_query,
                                               filter_result_t& filter_result,
                                               const bool& should_timeout, const bool& validate_field_names) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->get_filter_ids_with_lock(filter_query, filter_result, should_timeout, validate_field_names);
}

Option<reference_info_t> CollectionManager::is_referenced_in(const std::string& referenced_coll_name,
                                                             const std::string& referring_coll_name) const {
    auto it = referenced_ins.find(referenced_coll_name);
    if (it == referenced_ins.end()) {
        return Option<reference_info_t>(400, "referenced_coll_name: `" + referenced_coll_name + "` not found.");
    }

    auto inner_it = it->second.find(referring_coll_name);
    if (inner_it == it->second.end()) {
        return Option<reference_info_t>(400, "referring_coll_name: `" + referring_coll_name +
                                                "` in referenced_coll_name: `" + referenced_coll_name + "` not found.");
    }

    return Option<reference_info_t>(inner_it->second);
}

Option<reference_info_t> CollectionManager::is_referenced_in_with_lock(const std::string& referenced_coll_name,
                                                                       const std::string& referring_coll_name) const {
    std::shared_lock lock(mutex);
    return is_referenced_in(referenced_coll_name, referring_coll_name);
}

bool CollectionManager::is_referenced_in_any(const std::string& referenced_coll_name) const {
    std::shared_lock lock(mutex);
    const auto it = referenced_ins.find(referenced_coll_name);
    return it != referenced_ins.end();
}

Option<bool> CollectionManager::populate_include_exclude_fields(const std::string& collection_name,
                                                                const std::string& ref_include,
                                                                const std::string& ref_exclude,
                                                                tsl::htrie_set<char>& include_fields_full,
                                                                tsl::htrie_set<char>& exclude_fields_full) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    std::vector<std::string> ref_include_fields_vec, ref_exclude_fields_vec;
    StringUtils::split(ref_include, ref_include_fields_vec, ",");
    StringUtils::split(ref_exclude, ref_exclude_fields_vec, ",");

    spp::sparse_hash_set<std::string> ref_include_fields, ref_exclude_fields;
    ref_include_fields.insert(ref_include_fields_vec.begin(), ref_include_fields_vec.end());
    ref_exclude_fields.insert(ref_exclude_fields_vec.begin(), ref_exclude_fields_vec.end());

    return collection->populate_include_exclude_fields_lk(ref_include_fields,
                                                          ref_exclude_fields,
                                                          include_fields_full,
                                                          exclude_fields_full);
}

Option<bool> CollectionManager::include_related_docs(const std::string& collection_name,
                                                     nlohmann::json& doc, const uint32_t& seq_id,
                                                     const reference_info_t& ref_info,
                                                     const tsl::htrie_set<char>& ref_include_fields_full,
                                                     const tsl::htrie_set<char>& ref_exclude_fields_full,
                                                     const nlohmann::json& original_doc,
                                                     const ref_include_exclude_fields& ref_include_exclude) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->include_related_docs(doc, seq_id, ref_info, ref_include_fields_full, ref_exclude_fields_full,
                                            original_doc, ref_include_exclude);
}

Option<bool> CollectionManager::get_related_ids(const std::string& collection_name,
                                                const std::string& field_name,
                                                const std::vector<uint32_t>& seq_id_vec,
                                                std::vector<uint32_t>& related_ids) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->get_related_ids_with_lock(field_name, seq_id_vec, related_ids);
}

Option<bool> CollectionManager::process_ref_include_fields_sort(const std::string& collection_name,
                                                                const std::string& sort_by_str, size_t limit,
                                                                std::vector<uint32_t>& doc_ids) {
    auto& cm = CollectionManager::get_instance();
    auto collection = cm.get_collection(collection_name);
    if (collection == nullptr) {
        return Option<bool>(400, "Collection `" + collection_name + "` not found.");
    }

    return collection->process_ref_include_fields_sort(sort_by_str, limit, doc_ids);
}

void CollectionManager::lock_nested_referencing_collections_helper(const std::string& coll_name,
                                                                   cascade_remove_node_t* cascade_node,
                                                                   std::set<std::string>& referencing_collections) {
    if (cascade_node == nullptr) {
        return;
    }

    auto it = referenced_ins.find(coll_name);
    if (it == referenced_ins.end()) {
        return;
    }

    for (const auto& [ref_coll_name, ref_info]: it->second) {
        if (!referencing_collections.insert(ref_coll_name).second) {
            continue;
        }

        auto red_coll_it = collections.find(ref_coll_name);
        if (red_coll_it == collections.end()) {
            continue;
        }

        cascade_node->ref_infos.emplace_back(ref_info);
        cascade_node->nested_references.emplace_back(new cascade_remove_node_t({red_coll_it->second,
                                                            std::unique_lock<std::shared_mutex>(red_coll_it->second->get_mutex())}));
        lock_nested_referencing_collections_helper(ref_coll_name, cascade_node->nested_references.back(),
                                                   referencing_collections);
    }
}

void CollectionManager::lock_nested_referencing_collections(const std::string& coll_name,
                                                            cascade_remove_node_t*& cascade_tree) {
    std::shared_lock lock(mutex);

    auto coll_it = collections.find(coll_name);
    if (coll_it == collections.end()) {
        return;
    }

    auto it = referenced_ins.find(coll_name);
    if (it == referenced_ins.end()) {
        return;
    }

    cascade_tree = new cascade_remove_node_t({coll_it->second,
                                              std::unique_lock<std::shared_mutex>(coll_it->second->get_mutex())});

    std::set<std::string> referencing_collections{coll_name};
    lock_nested_referencing_collections_helper(coll_name, cascade_tree, referencing_collections);
}

nlohmann::json CollectionManager::preprocess_union_hits_for_conversation(const nlohmann::json& hits) {
    nlohmann::json result_docs = nlohmann::json::array();
    if(!hits.is_array()) {
        return result_docs;
    }

    std::unordered_map<std::string, nlohmann::json> collection_to_hits;
    for(const auto& hit : hits) {
        if(!hit.is_object() || !hit.contains("document")) {
            continue;
        }

        auto collection_name_it = hit.find("collection");
        if(collection_name_it == hit.end() || !collection_name_it->is_string()) {
            result_docs.push_back(hit["document"]);
            continue;
        }

        collection_to_hits[collection_name_it->get<std::string>()].push_back(hit);
    }

    for(const auto& [collection_name, coll_hits] : collection_to_hits) {
        auto collection = CollectionManager::get_instance().get_collection(collection_name);
        if(collection == nullptr) {
            continue;
        }

        auto group_docs = collection->preprocess_result_docs_for_conversation(coll_hits);
        result_docs.insert(result_docs.end(), group_docs.begin(), group_docs.end());
    }

    return result_docs;
}

void CollectionManager::persist_referenced_ins() {
    auto referenced_ins_json = nlohmann::json::array();
    for (const auto& pair: referenced_ins) {
        nlohmann::json temp_json;
        temp_json["referenced_coll_name"] = pair.first;
        for (const auto& item: pair.second) {
            const auto& ref_info = item.second;
            temp_json["referenced_infos"] += reference_info_t::to_json(ref_info);
        }

        referenced_ins_json += temp_json;
    }

    if (!store->insert(REFERENCED_INS, referenced_ins_json.dump())) {
        LOG(ERROR) << "Could not persist referenced_ins to store.";
    }
}
