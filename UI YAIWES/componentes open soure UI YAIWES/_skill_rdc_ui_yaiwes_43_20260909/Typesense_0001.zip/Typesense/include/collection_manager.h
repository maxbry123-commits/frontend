#pragma once

#include <iostream>
#include <string>
#ifdef TEST_BUILD
#include <functional>
#endif
#include <sparsepp.h>
#include "store.h"
#include "field.h"
#include "collection.h"
#include "auth_manager.h"
#include "threadpool.h"
#include "batched_indexer.h"

const std::string ERROR_could_not_locate_document_in_store = "Could not locate the JSON document for sequence ID: ";

#ifdef TEST_BUILD
extern std::function<Option<bool>()> collection_manager_before_async_reference_backfill_apply;
#endif

// Singleton, for managing meta information of all collections and house keeping
class CollectionManager {
private:
    mutable std::shared_mutex mutex;

    mutable std::shared_mutex noop_coll_mutex;

    Store *store;
    ThreadPool* thread_pool;

    AuthManager auth_manager;

    spp::sparse_hash_map<std::string, std::shared_ptr<Collection>> collections;

    spp::sparse_hash_map<uint32_t, std::string> collection_id_names;

    spp::sparse_hash_map<std::string, std::string> collection_symlinks;

    spp::sparse_hash_map<std::string, nlohmann::json> preset_configs;

    // Auto incrementing ID assigned to each collection
    // Using a ID instead of a collection's name makes renaming possible
    std::atomic<uint32_t> next_collection_id;

    std::string bootstrap_auth_key;

    std::atomic<float> max_memory_ratio;

    std::atomic<bool>* quit;

    // All the references to a particular collection are stored.
    // referenced_coll_name -> referring_coll_name -> reference_info
    std::map<std::string, std::map<std::string, reference_info_t>> referenced_ins;

    CollectionManager();

    ~CollectionManager() = default;

    static std::string get_first_index_error(const std::vector<index_record>& index_records) {
        for(const auto & index_record: index_records) {
            if(!index_record.indexed.ok()) {
                return index_record.indexed.error();
            }
        }

        return "";
    }

    static Option<bool> validate_facet_params(const std::vector<collection_search_args_t>& coll_searches,
                                              const std::vector<std::shared_ptr<Collection>>& collections);

    void persist_referenced_ins();

    Option<bool> validate_deferred_references_for_symlink(const std::string& symlink_name,
                                                          const std::string& collection_name) const;

    Option<bool> resolve_deferred_references_for_symlink(const std::string& symlink_name,
                                                         const std::string& collection_name);

    Option<bool> rebind_references_for_symlink_target_swap(const std::string& symlink_name,
                                                           const std::string& old_collection_name,
                                                           const std::string& new_collection_name);

public:
    static constexpr const size_t DEFAULT_NUM_MEMORY_SHARDS = 4;

    static constexpr const char* NEXT_COLLECTION_ID_KEY = "$CI";
    static constexpr const char* SYMLINK_PREFIX = "$SL";
    static constexpr const char* PRESET_PREFIX = "$PS";
    static constexpr const char* REFERENCED_INS = "$REFERENCED_INS";

    uint16_t filter_by_max_ops;

    static CollectionManager & get_instance() {
        static CollectionManager instance;
        return instance;
    }

    CollectionManager(CollectionManager const&) = delete;
    void operator=(CollectionManager const&) = delete;

    static Option<Collection*> init_collection(const nlohmann::json & collection_meta,
                                               const uint32_t collection_next_seq_id,
                                               Store* store,
                                               float max_memory_ratio,
                                               const std::map<std::string, std::map<std::string, reference_info_t>>& referenced_infos);

    static Option<bool> load_collection(const nlohmann::json& collection_meta,
                                        const size_t batch_size,
                                        const StoreStatus& next_coll_id_status,
                                        const std::atomic<bool>& quit,
                                        const std::map<std::string, std::map<std::string, reference_info_t>>& referenced_infos);

    Option<Collection*> clone_collection(const std::string& existing_name, const nlohmann::json& req_json,
                                         const bool copy_documents = false);

    std::shared_ptr<Collection> add_to_collections(Collection* collection);

    Option<std::vector<std::shared_ptr<Collection>>> get_collections(uint32_t limit = 0, uint32_t offset = 0,
                                                     const std::vector<std::string>& api_key_collections = {}) const;

    std::vector<std::string> get_collection_names() const;

    std::shared_ptr<Collection> get_collection_unsafe(const std::string & collection_name) const;

    // PUBLICLY EXPOSED API

    void init(Store *store, ThreadPool* thread_pool, const float max_memory_ratio,
              const std::string & auth_key, std::atomic<bool>& quit,
              const uint16_t& filter_by_max_operations = Config::FILTER_BY_DEFAULT_OPERATIONS);

    // only for tests!
    void init(Store *store, const float max_memory_ratio, const std::string & auth_key, std::atomic<bool>& exit,
              const uint16_t& filter_by_max_operations = Config::FILTER_BY_DEFAULT_OPERATIONS);

    Option<bool> load(const size_t collection_batch_size, const size_t document_batch_size);

    // frees in-memory data structures when server is shutdown - helps us run a memory leak detector properly
    void dispose();

    bool auth_key_matches(const string& req_auth_key, const string& action,
                          const std::vector<collection_key_t>& collection_keys,
                          std::map<std::string, std::string>& params,
                          std::vector<nlohmann::json>& embedded_params_vec) const;

    static Option<Collection*> create_collection(nlohmann::json& req_json);

    Option<Collection*> create_collection(const std::string& name, const size_t num_memory_shards,
                                          const std::vector<field> & fields,
                                          const std::string & default_sorting_field="",
                                          const uint64_t created_at = static_cast<uint64_t>(std::time(nullptr)),
                                          const std::string& fallback_field_type = "",
                                          const std::vector<std::string>& symbols_to_index = {},
                                          const std::vector<std::string>& token_separators = {},
                                          const bool enable_nested_fields = false, std::shared_ptr<VQModel> model = nullptr,
                                          const nlohmann::json& metadata = {}, const std::vector<std::string>& synonym_sets = {}, const std::vector<std::string>& curation_sets = {});

    std::shared_ptr<Collection> get_collection(const std::string & collection_name) const;

    std::shared_ptr<Collection> get_collection_with_id(uint32_t collection_id) const;

    Option<nlohmann::json> get_collection_summaries(uint32_t limit = 0 , uint32_t offset = 0,
                                                    const std::vector<std::string>& exclude_fields = {},
                                                    const std::vector<std::string>& api_key_collections = {}) const;

    Option<nlohmann::json> drop_collection(const std::string& collection_name,
                                           const bool remove_from_store = true,
                                           const bool compact_store = true);

    uint32_t get_next_collection_id() const;

    static std::string get_symlink_key(const std::string & symlink_name);

    static std::string get_preset_key(const std::string & preset_name);

    Store* get_store();

    ThreadPool* get_thread_pool() const;

    AuthManager& getAuthManager();

    static Option<bool> do_search(std::map<std::string, std::string>& req_params,
                                  nlohmann::json& embedded_params,
                                  std::string& results_json_str,
                                  uint64_t start_ts);

    static Option<bool> do_union(std::map<std::string, std::string>& req_params,
                                 std::vector<nlohmann::json>& embedded_params_vec, nlohmann::json searches,
                                 nlohmann::json& response, uint64_t start_ts, bool remove_duplicates = true);

    static bool parse_sort_by_str(std::string sort_by_str, std::vector<sort_by>& sort_fields);

    // symlinks
    Option<std::string> resolve_symlink(const std::string & symlink_name) const;

    spp::sparse_hash_map<std::string, std::string> get_symlinks() const;

    Option<bool> upsert_symlink(const std::string & symlink_name, const std::string & collection_name);

    Option<bool> delete_symlink(const std::string & symlink_name);

    // presets
    spp::sparse_hash_map<std::string, nlohmann::json> get_presets() const;

    Option<bool> get_preset(const std::string & preset_name, nlohmann::json& preset) const;

    Option<bool> upsert_preset(const std::string & preset_name, const nlohmann::json& preset_config);

    Option<bool> delete_preset(const std::string & preset_name);

    Option<bool> add_referenced_ins_with_lock(std::string& referenced_collection_name, reference_info_t&& ref_info,
                                              std::set<update_reference_info_t>& update_ref_infos,
                                              bool is_live_request = true);

    Option<bool> add_referenced_ins(std::string& referenced_collection_name, reference_info_t&& ref_info,
                                    std::set<update_reference_info_t>& update_ref_infos,
                                    bool is_live_request = true);

    void remove_referenced_ins_with_lock(const std::string& referencing_coll_name, const reference_info_t& ref_info);

    std::map<std::string, std::map<std::string, reference_info_t>> _get_referenced_ins() const;

    void process_embedding_field_delete(const std::string& model_name);

    static void _populate_referenced_ins(const std::vector<std::string>& collection_meta_jsons,
                                         std::map<std::string, std::map<std::string, reference_info_t>>& referenced_ins);

    std::unordered_set<std::string> get_collection_references(const std::string& coll_name);

    std::unordered_set<std::string> get_nested_referencing_collections(const std::string& coll_name);

    bool is_valid_api_key_collection(const std::vector<std::string>& api_key_collections, std::shared_ptr<Collection> coll) const;

    Option<bool> update_collection_metadata(const std::string& collection, const nlohmann::json& metadata);

    Option<bool> update_collection_synonym_sets(const std::string& collection, const std::vector<std::string>& synonym_sets, bool is_live_req = true);

    Option<bool> update_collection_curation_sets(const std::string& collection, const std::vector<std::string>& curation_sets, bool is_live_req = true);

    Option<nlohmann::json> get_collection_alter_status() const;

    static void remove_internal_fields(std::map<std::string, std::string>& params);

    static Option<bool> get_document_from_store(const std::string collection, const uint32_t& seq_id,
                                                nlohmann::json& document, bool raw_doc = false);

    static Option<uint32_t> doc_id_to_seq_id(const std::string collection, const std::string& doc_id);

    static Option<bool> get_filter_ids(const std::string collection, const std::string & filter_query,
                                       filter_result_t& filter_result,
                                       const bool& should_timeout = true, const bool& validate_field_names = true);

    static nlohmann::json preprocess_union_hits_for_conversation(const nlohmann::json& hits);

    bool is_referenced_in_any(const std::string& referenced_coll_name) const;

    Option<reference_info_t> is_referenced_in(const std::string& referenced_coll_name,
                                              const std::string& referring_coll_name) const;

    Option<reference_info_t> is_referenced_in_with_lock(const std::string& referenced_coll_name,
                                                        const std::string& referring_coll_name) const;

    static Option<bool> populate_include_exclude_fields(const std::string& collection_name,
                                                        const std::string& ref_include,
                                                        const std::string& ref_exclude,
                                                        tsl::htrie_set<char>& include_fields_full,
                                                        tsl::htrie_set<char>& exclude_fields_full);

    static Option<bool> include_related_docs(const std::string& collection_name,
                                             nlohmann::json& doc, const uint32_t& seq_id,
                                             const reference_info_t& ref_info,
                                             const tsl::htrie_set<char>& ref_include_fields_full,
                                             const tsl::htrie_set<char>& ref_exclude_fields_full,
                                             const nlohmann::json& original_doc,
                                             const ref_include_exclude_fields& ref_include_exclude);

    static Option<bool> get_related_ids(const std::string& collection_name,
                                        const std::string& field_name,
                                        const std::vector<uint32_t>& seq_id_vec,
                                        std::vector<uint32_t>& related_ids);

    static Option<bool> process_ref_include_fields_sort(const std::string& collection_name,
                                                        const std::string& sort_by_str, size_t limit,
                                                        std::vector<uint32_t>& doc_ids);

    void lock_nested_referencing_collections_helper(const std::string& coll_name,
                                                    cascade_remove_node_t* cascade_node,
                                                    std::set<std::string>& referencing_collections);

    void lock_nested_referencing_collections(const std::string& coll_name,
                                             cascade_remove_node_t*& cascade_tree);
};
