/*
 * Copyright (c) 2017 Etnaviv Project
 * Copyright (C) 2017 Zodiac Inflight Innovations
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Authors:
 *    Wladimir J. van der Laan <laanwj@gmail.com>
 */
#include "etnaviv_blt.h"

#include "etnaviv_emit.h"
#include "etnaviv_clear_blit.h"
#include "etnaviv_context.h"
#include "etnaviv_emit.h"
#include "etnaviv_format.h"
#include "etnaviv_resource.h"
#include "etnaviv_translate.h"

#include "util/format/u_format.h"
#include "util/u_math.h"
#include "pipe/p_defines.h"
#include "pipe/p_state.h"
#include "util/u_blitter.h"
#include "util/u_inlines.h"
#include "util/u_memory.h"
#include "util/u_surface.h"

#include "hw/common_3d.xml.h"
#include "hw/state_blt.xml.h"
#include "hw/common.xml.h"

#include <assert.h>

static const uint32_t blt_conversion_formats[] = {
   BLT_FORMAT_A8R8G8B8,
   BLT_FORMAT_X8R8G8B8,
   BLT_FORMAT_A4R4G4B4,
   BLT_FORMAT_A1R5G5B5,
   BLT_FORMAT_R5G6B5,
   BLT_FORMAT_R8G8,
   BLT_FORMAT_R8,
   BLT_FORMAT_A2R10G10B10,
};

static inline bool
blt_conversion_needs_channel_swap(uint32_t blt_fmt)
{
   /* Not the PE_FORMAT_RB_SWAP property: RB_SWAP formats are stored BGRA and
    * already match the BGRA-named BLT formats (identity), and R8/R8G8 have no
    * R/B pair. A2R10G10B10 is the only whitelist format stored RGBA against a
    * BGRA-named BLT format, so it alone needs the swap.
    */
   return blt_fmt == BLT_FORMAT_A2R10G10B10;
}

struct blt_conv_swizzle {
   uint8_t src_swizzle[4];
   uint8_t dst_swizzle[4];
};

static bool
find_blt_conversion(enum pipe_format src_pipe, enum pipe_format dst_pipe,
                    struct blt_conv_swizzle *swizzle)
{
   /* An integer conversion changes the stored values, a raw copy cannot. */
   if (util_format_is_pure_integer(src_pipe) ||
       util_format_is_pure_integer(dst_pipe))
      return false;

   const uint32_t src_blt = translate_blt_format(src_pipe);
   const uint32_t dst_blt = translate_blt_format(dst_pipe);

   if (src_blt == ETNA_NO_MATCH || dst_blt == ETNA_NO_MATCH)
      return false;

   bool src_found = false, dst_found = false;
   for (unsigned i = 0; i < ARRAY_SIZE(blt_conversion_formats); i++) {
      if (blt_conversion_formats[i] == src_blt) src_found = true;
      if (blt_conversion_formats[i] == dst_blt) dst_found = true;
   }

   if (!src_found || !dst_found)
      return false;

   static const uint8_t ident[] = {0, 1, 2, 3};
   static const uint8_t rb_swap[] = {2, 1, 0, 3};

   memcpy(swizzle->src_swizzle,
          blt_conversion_needs_channel_swap(src_blt) ? rb_swap : ident, 4);
   memcpy(swizzle->dst_swizzle,
          blt_conversion_needs_channel_swap(dst_blt) ? rb_swap : ident, 4);

   return true;
}

/* do_blit_framebuffer(..) only sets non-identity swizzle for channels
 * missing from src - shared channels stay identity.
 */
static inline void
blt_assert_swizzle_compatible(ASSERTED const struct pipe_blit_info *info)
{
   if (!info->swizzle_enable)
      return;

   /* Only channels present in both src and dst must be identity. */
   ASSERTED unsigned n =
      MIN2(util_format_get_nr_components(info->src.format),
           util_format_get_nr_components(info->dst.format));

   assert(info->swizzle[0] == PIPE_SWIZZLE_X);
   assert(n < 2 || info->swizzle[1] == PIPE_SWIZZLE_Y);
   assert(n < 3 || info->swizzle[2] == PIPE_SWIZZLE_Z);
}

static uint32_t
etna_compatible_blt_format(enum pipe_format fmt)
{
   /* YUYV and UYVY are blocksize 4, but 2 bytes per pixel */
   if (fmt == PIPE_FORMAT_YUYV || fmt == PIPE_FORMAT_UYVY)
      return BLT_FORMAT_R8G8;

   switch (util_format_get_blocksize(fmt)) {
   case 1: return BLT_FORMAT_R8;
   case 2: return BLT_FORMAT_R8G8;
   case 4: return BLT_FORMAT_A8R8G8B8;
   case 8: return BLT_FORMAT_A16R16G16B16;
   default: return ETNA_NO_MATCH;
   }
}

static inline uint32_t
blt_compute_stride_bits(const struct blt_imginfo *img)
{
   return VIVS_BLT_DEST_STRIDE_TILING(img->tiling == ETNA_LAYOUT_LINEAR ? 0 : 3) | /* 1/3? */
          VIVS_BLT_DEST_STRIDE_FORMAT(img->format) |
          VIVS_BLT_DEST_STRIDE_STRIDE(img->stride) |
          COND(img->downsample_x, VIVS_BLT_SRC_STRIDE_DOWNSAMPLE_X) |
          COND(img->downsample_y, VIVS_BLT_SRC_STRIDE_DOWNSAMPLE_Y);
}

static inline uint32_t
blt_compute_dest_img_config_bits(const struct blt_imginfo *img)
{
   return BLT_DEST_IMAGE_CONFIG_TS_MODE(img->ts_mode) |
          COND(img->use_ts, BLT_DEST_IMAGE_CONFIG_TS) |
          COND(img->use_ts && img->ts_compress_fmt >= 0, BLT_DEST_IMAGE_CONFIG_COMPRESSION) |
          BLT_DEST_IMAGE_CONFIG_COMPRESSION_FORMAT(img->ts_compress_fmt) |
          BLT_DEST_IMAGE_CONFIG_UNK22 |
          COND(img->srgb, BLT_DEST_IMAGE_CONFIG_SRGB) |
          BLT_DEST_IMAGE_CONFIG_SWIZ_R(img->swizzle[0]) |
          BLT_DEST_IMAGE_CONFIG_SWIZ_G(img->swizzle[1]) |
          BLT_DEST_IMAGE_CONFIG_SWIZ_B(img->swizzle[2]) |
          BLT_DEST_IMAGE_CONFIG_SWIZ_A(img->swizzle[3]) |
          COND(img->tiling == ETNA_LAYOUT_SUPER_TILED, BLT_DEST_IMAGE_CONFIG_TO_SUPER_TILED);
}

static inline uint32_t
blt_compute_src_img_config_bits(const struct blt_imginfo *img)
{
   return BLT_SRC_IMAGE_CONFIG_TS_MODE(img->ts_mode) |
          COND(img->use_ts, BLT_SRC_IMAGE_CONFIG_TS) |
          COND(img->use_ts && img->ts_compress_fmt >= 0, BLT_SRC_IMAGE_CONFIG_COMPRESSION) |
          BLT_SRC_IMAGE_CONFIG_COMPRESSION_FORMAT(img->ts_compress_fmt) |
          COND(img->srgb, BLT_SRC_IMAGE_CONFIG_SRGB) |
          BLT_SRC_IMAGE_CONFIG_SWIZ_R(img->swizzle[0]) |
          BLT_SRC_IMAGE_CONFIG_SWIZ_G(img->swizzle[1]) |
          BLT_SRC_IMAGE_CONFIG_SWIZ_B(img->swizzle[2]) |
          BLT_SRC_IMAGE_CONFIG_SWIZ_A(img->swizzle[3]) |
          COND(img->tiling == ETNA_LAYOUT_SUPER_TILED, BLT_SRC_IMAGE_CONFIG_FROM_SUPER_TILED);
}

static inline uint32_t
blt_compute_swizzle_bits(const struct blt_imginfo *img, bool for_dest)
{
   uint32_t swiz = VIVS_BLT_SWIZZLE_SRC_R(img->swizzle[0]) |
                   VIVS_BLT_SWIZZLE_SRC_G(img->swizzle[1]) |
                   VIVS_BLT_SWIZZLE_SRC_B(img->swizzle[2]) |
                   VIVS_BLT_SWIZZLE_SRC_A(img->swizzle[3]);
   return for_dest ? (swiz << 12) : swiz;
}

/* Clear (part of) an image */
static void
emit_blt_clearimage(struct etna_context *ctx, const struct blt_clear_op *op)
{
   struct etna_cmd_stream *stream = ctx->stream;

   etna_cmd_stream_reserve(stream, 64*2); /* Make sure BLT op doesn't get broken up */
   ETNA_CONTEXT_ATOMIC_EMIT(ctx);

   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000001);
   assert(op->dest.bpp);
   etna_set_state(stream, VIVS_BLT_CONFIG, VIVS_BLT_CONFIG_CLEAR_BPP(op->dest.bpp-1));
   /* NB: blob sets format to 1 in dest/src config for clear, and the swizzle to RRRR.
    * does this matter? It seems to just be ignored. But if we run into issues with BLT
    * behaving stragely, it's something to look at.
    */
   etna_set_state(stream, VIVS_BLT_DEST_STRIDE, blt_compute_stride_bits(&op->dest));
   etna_set_state(stream, VIVS_BLT_DEST_CONFIG,
           blt_compute_dest_img_config_bits(&op->dest) |
           COND(op->dest.bpp == 8, BLT_DEST_IMAGE_CONFIG_64BPP_FORMAT));
   etna_set_state_reloc(stream, VIVS_BLT_DEST_ADDR, &op->dest.addr);
   etna_set_state(stream, VIVS_BLT_SRC_STRIDE, blt_compute_stride_bits(&op->dest));
   etna_set_state(stream, VIVS_BLT_SRC_CONFIG,
           blt_compute_src_img_config_bits(&op->dest) |
           COND(op->dest.bpp == 8, BLT_SRC_IMAGE_CONFIG_64BPP_FORMAT));
   etna_set_state_reloc(stream, VIVS_BLT_SRC_ADDR, &op->dest.addr);
   etna_set_state(stream, VIVS_BLT_DEST_POS, VIVS_BLT_DEST_POS_X(op->rect_x) | VIVS_BLT_DEST_POS_Y(op->rect_y));
   etna_set_state(stream, VIVS_BLT_IMAGE_SIZE, VIVS_BLT_IMAGE_SIZE_WIDTH(op->rect_w) | VIVS_BLT_IMAGE_SIZE_HEIGHT(op->rect_h));
   etna_set_state(stream, VIVS_BLT_CLEAR_COLOR0, op->clear_value[0]);
   etna_set_state(stream, VIVS_BLT_CLEAR_COLOR1, op->clear_value[1]);
   etna_set_state(stream, VIVS_BLT_CLEAR_BITS0, op->clear_bits[0]);
   etna_set_state(stream, VIVS_BLT_CLEAR_BITS1, op->clear_bits[1]);
   if (op->dest.use_ts) {
      etna_set_state_reloc(stream, VIVS_BLT_DEST_TS, &op->dest.ts_addr);
      etna_set_state_reloc(stream, VIVS_BLT_SRC_TS, &op->dest.ts_addr);
      etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE0, op->dest.ts_clear_value[0]);
      etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE1, op->dest.ts_clear_value[1]);
      etna_set_state(stream, VIVS_BLT_SRC_TS_CLEAR_VALUE0, op->dest.ts_clear_value[0]);
      etna_set_state(stream, VIVS_BLT_SRC_TS_CLEAR_VALUE1, op->dest.ts_clear_value[1]);
   }
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_COMMAND, VIVS_BLT_COMMAND_COMMAND_CLEAR_IMAGE);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000000);

   if (DBG_ENABLED(ETNA_DBG_DRAW_STALL))
      etna_stall(stream, SYNC_RECIPIENT_FE, SYNC_RECIPIENT_PE);
}

/* Copy (a subset of) an image to another image. */
static void
emit_blt_copyimage(struct etna_context *ctx, const struct blt_imgcopy_op *op)
{
   struct etna_cmd_stream *stream = ctx->stream;

   etna_cmd_stream_reserve(stream, 64*2); /* Never allow BLT sequences to be broken up */
   ETNA_CONTEXT_ATOMIC_EMIT(ctx);

   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000001);
   etna_set_state(stream, VIVS_BLT_CONFIG,
           VIVS_BLT_CONFIG_SRC_ENDIAN(op->src.endian_mode) |
           VIVS_BLT_CONFIG_DEST_ENDIAN(op->dest.endian_mode) |
           COND(op->downsample_one_sample, VIVS_BLT_CONFIG_DOWNSAMPLE_ONE_SAMPLE));
   etna_set_state(stream, VIVS_BLT_SRC_STRIDE, blt_compute_stride_bits(&op->src));
   etna_set_state(stream, VIVS_BLT_SRC_CONFIG,
           blt_compute_src_img_config_bits(&op->src) |
           COND(op->src.bpp == 8, BLT_SRC_IMAGE_CONFIG_64BPP_FORMAT));
   etna_set_state(stream, VIVS_BLT_SWIZZLE,
           blt_compute_swizzle_bits(&op->src, false) |
           blt_compute_swizzle_bits(&op->dest, true));
   etna_set_state(stream, VIVS_BLT_UNK140A0, 0x00040004);
   etna_set_state(stream, VIVS_BLT_UNK1409C, 0x00400040);
   if (op->src.use_ts) {
      etna_set_state_reloc(stream, VIVS_BLT_SRC_TS, &op->src.ts_addr);
      etna_set_state(stream, VIVS_BLT_SRC_TS_CLEAR_VALUE0, op->src.ts_clear_value[0]);
      etna_set_state(stream, VIVS_BLT_SRC_TS_CLEAR_VALUE1, op->src.ts_clear_value[1]);
   }
   etna_set_state_reloc(stream, VIVS_BLT_SRC_ADDR, &op->src.addr);
   etna_set_state(stream, VIVS_BLT_DEST_STRIDE, blt_compute_stride_bits(&op->dest));
   etna_set_state(stream, VIVS_BLT_DEST_CONFIG,
         blt_compute_dest_img_config_bits(&op->dest) |
         COND(op->flip_y, BLT_DEST_IMAGE_CONFIG_FLIP_Y));
   assert(!op->dest.use_ts); /* Dest TS path doesn't work for copies? */
   if (op->dest.use_ts) {
      etna_set_state_reloc(stream, VIVS_BLT_DEST_TS, &op->dest.ts_addr);
      etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE0, op->dest.ts_clear_value[0]);
      etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE1, op->dest.ts_clear_value[1]);
   }
   etna_set_state_reloc(stream, VIVS_BLT_DEST_ADDR, &op->dest.addr);
   etna_set_state(stream, VIVS_BLT_SRC_POS, VIVS_BLT_DEST_POS_X(op->src_x) | VIVS_BLT_DEST_POS_Y(op->src_y));
   etna_set_state(stream, VIVS_BLT_DEST_POS, VIVS_BLT_DEST_POS_X(op->dest_x) | VIVS_BLT_DEST_POS_Y(op->dest_y));
   etna_set_state(stream, VIVS_BLT_IMAGE_SIZE, VIVS_BLT_IMAGE_SIZE_WIDTH(op->rect_w) | VIVS_BLT_IMAGE_SIZE_HEIGHT(op->rect_h));
   etna_set_state(stream, VIVS_BLT_UNK14058, 0xffffffff);
   etna_set_state(stream, VIVS_BLT_UNK1405C, 0xffffffff);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_COMMAND, VIVS_BLT_COMMAND_COMMAND_COPY_IMAGE);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000000);

   if (DBG_ENABLED(ETNA_DBG_DRAW_STALL))
      etna_stall(stream, SYNC_RECIPIENT_FE, SYNC_RECIPIENT_PE);
}

/* Emit in-place resolve using BLT. */
static void
emit_blt_inplace(struct etna_context *ctx, const struct blt_inplace_op *op)
{
   struct etna_cmd_stream *stream = ctx->stream;

   assert(op->bpp > 0 && util_is_power_of_two_nonzero(op->bpp));
   etna_cmd_stream_reserve(stream, 64*2); /* Never allow BLT sequences to be broken up */
   ETNA_CONTEXT_ATOMIC_EMIT(ctx);

   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000001);
   etna_set_state(stream, VIVS_BLT_CONFIG,
         VIVS_BLT_CONFIG_INPLACE_TS_MODE(op->ts_mode) |
         VIVS_BLT_CONFIG_INPLACE_BOTH |
         (util_logbase2(op->bpp) << VIVS_BLT_CONFIG_INPLACE_BPP__SHIFT));
   etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE0, op->ts_clear_value[0]);
   etna_set_state(stream, VIVS_BLT_DEST_TS_CLEAR_VALUE1, op->ts_clear_value[1]);
   etna_set_state_reloc(stream, VIVS_BLT_DEST_ADDR, &op->addr);
   etna_set_state_reloc(stream, VIVS_BLT_DEST_TS, &op->ts_addr);
   etna_set_state(stream, 0x14068, op->num_tiles);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_COMMAND, 0x00000004);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000000);

   if (DBG_ENABLED(ETNA_DBG_DRAW_STALL))
      etna_stall(stream, SYNC_RECIPIENT_FE, SYNC_RECIPIENT_PE);
}

/* Emit genmipamp using BLT. */
static void
emit_blt_genmipmap(struct etna_context *ctx, const struct blt_genmipmap_op *op)
{
   struct etna_cmd_stream *stream = ctx->stream;

   etna_cmd_stream_reserve(stream, 64*2); /* Never allow BLT sequences to be broken up */
   ETNA_CONTEXT_ATOMIC_EMIT(ctx);

   etna_set_state(stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);
   etna_set_state(stream, VIVS_TS_FLUSH_CACHE, VIVS_TS_FLUSH_CACHE_FLUSH);

   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000001);

   etna_set_state(stream, VIVS_BLT_SRC_STRIDE, blt_compute_stride_bits(&op->src));
   etna_set_state(stream, VIVS_BLT_SRC_CONFIG, blt_compute_src_img_config_bits(&op->src));
   etna_set_state_reloc(stream, VIVS_BLT_SRC_ADDR, &op->src.addr);

   etna_set_state(stream, VIVS_BLT_DEST_CONFIG, blt_compute_dest_img_config_bits(&op->src));
   etna_set_state(stream, VIVS_BLT_DEST_STRIDE, blt_compute_stride_bits(&op->src));

   etna_set_state(stream, VIVS_BLT_IMAGE_SIZE,
           VIVS_BLT_IMAGE_SIZE_HEIGHT(op->height) |
           VIVS_BLT_IMAGE_SIZE_WIDTH(op->width));

   etna_set_state(stream, VIVS_BLT_SWIZZLE,
           blt_compute_swizzle_bits(&op->src, false) |
           blt_compute_swizzle_bits(&op->src, true));

   for (unsigned i = 0; i < op->num_levels; i++) {
      etna_set_state_reloc(stream, VIVS_BLT_MIP_ADDR(i), &op->level[i]);
      etna_set_state(stream, VIVS_BLT_MIP_STRIDE(i), op->stride[i]);
   }

   etna_set_state(stream, VIVS_BLT_MIPMAP_CONFIG,
           VIVS_BLT_MIPMAP_CONFIG_NUM(op->num_levels + 1) |
           VIVS_BLT_MIPMAP_CONFIG_UNK5);
   etna_set_state(stream, VIVS_BLT_CONFIG, 0x0);

   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_COMMAND, VIVS_BLT_COMMAND_COMMAND_GEN_MIPMAPS);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000000);

   if (DBG_ENABLED(ETNA_DBG_DRAW_STALL))
      etna_stall(stream, SYNC_RECIPIENT_FE, SYNC_RECIPIENT_PE);
}

static inline bool
etna_blt_will_fastclear(const struct etna_resource_level *level,
                        const struct pipe_scissor_state *scissor_state,
                        unsigned clear_mask,
                        unsigned full_mask)
{
   if (!scissor_state)
      return clear_mask == full_mask;

   return scissor_state->minx == 0 &&
          scissor_state->miny == 0 &&
          scissor_state->maxx >= level->width &&
          scissor_state->maxy >= level->height &&
          clear_mask == full_mask;
}

static inline uint64_t
etna_calculate_clear_bits(enum pipe_format format, unsigned clear_mask)
{
   const struct util_format_description *desc = util_format_description(format);
   uint64_t clear_bits = 0;

   for (unsigned i = 0; i < desc->nr_channels; i++) {
      if (clear_mask & (1 << desc->swizzle[i])) {
         const uint64_t mask = (1ull << desc->channel[i].size) - 1;
         clear_bits |= mask << desc->channel[i].shift;
      }
   }

   return clear_bits;
}

static void
etna_blit_clear_color_blt(struct pipe_context *pctx, unsigned idx,
                      const union pipe_color_union *color,
                      const struct pipe_scissor_state *scissor_state,
                      unsigned clear_mask)
{
   struct etna_context *ctx = etna_context(pctx);
   struct pipe_surface *dst = &ctx->framebuffer_s.base.cbufs[idx];
   struct etna_resource *dst_res = etna_resource_get_render_compatible(pctx, dst->texture);
   struct etna_resource_level *dst_level = &dst_res->levels[dst->level];
   uint64_t new_clear_value = etna_clear_blit_pack_rgba(dst->format, color, ctx->screen);
   const uint64_t clear_bits = etna_calculate_clear_bits(dst->format, clear_mask);
   bool fast_clear = etna_blt_will_fastclear(dst_level, scissor_state, clear_mask, 0xf);
   bool use_ts = etna_framebuffer_rt_use_ts(ctx, idx);
   int msaa_xscale = 1, msaa_yscale = 1;
   bool is_128bit_format = format_is_128bit(dst->format);

   translate_samples_to_xyscale(dst->texture->nr_samples,
                                &msaa_xscale, &msaa_yscale);

   if (fast_clear)
      dst_level->clear_value = new_clear_value;

   struct blt_clear_op clr = {};
   clr.dest.addr.bo = dst_res->bo;
   clr.dest.addr.offset = dst_level->offset + dst->first_layer * dst_level->layer_stride;
   clr.dest.addr.flags = ETNA_RELOC_WRITE;
   clr.dest.bpp = util_format_get_blocksize(dst_res->internal_format);
   clr.dest.stride = dst_level->stride;
   clr.dest.tiling = dst_res->layout;

   if (use_ts) {
      clr.dest.use_ts = 1;
      clr.dest.ts_addr.bo = dst_res->ts_bo;
      clr.dest.ts_addr.offset = dst_level->ts_offset;
      clr.dest.ts_addr.flags = ETNA_RELOC_WRITE;
      clr.dest.ts_clear_value[0] = dst_level->clear_value;
      clr.dest.ts_clear_value[1] = dst_level->clear_value >> 32;
      clr.dest.ts_mode = dst_level->ts_mode;
      clr.dest.ts_compress_fmt = dst_level->ts_compress_fmt;
   }

   clr.clear_value[0] = new_clear_value;
   clr.clear_value[1] = new_clear_value >> 32;
   clr.clear_bits[0] = clear_bits;
   clr.clear_bits[1] = clear_bits >> 32;

   if (scissor_state) {
      clr.rect_x = scissor_state->minx * msaa_xscale;
      clr.rect_y = scissor_state->miny * msaa_yscale;
      clr.rect_w = (scissor_state->maxx - scissor_state->minx) * msaa_xscale;
      clr.rect_h = (scissor_state->maxy - scissor_state->miny) * msaa_yscale;
   } else {
      clr.rect_x = 0;
      clr.rect_y = 0;
      clr.rect_w = dst_level->width * msaa_xscale;
      clr.rect_h = dst_level->height * msaa_yscale;
   }

   if (is_128bit_format) {
      clr.clear_value[0] = color->ui[0];
      clr.clear_value[1] = color->ui[1];
   }

   emit_blt_clearimage(ctx, &clr);

   if (is_128bit_format) {
      clr.clear_value[0] = color->ui[2];
      clr.clear_value[1] = color->ui[3];
      clr.dest.addr.offset += etna_resource_level_second_plane_offset(dst_level);

      emit_blt_clearimage(ctx, &clr);
   }

   /* This made the TS valid */
   if (use_ts) {
      if (idx == 0) {
         ctx->framebuffer.TS_COLOR_CLEAR_VALUE = dst_level->clear_value;
         ctx->framebuffer.TS_COLOR_CLEAR_VALUE_EXT = dst_level->clear_value >> 32;
      } else {
         ctx->framebuffer.RT_TS_COLOR_CLEAR_VALUE[idx - 1] = dst_level->clear_value;
         ctx->framebuffer.RT_TS_COLOR_CLEAR_VALUE_EXT[idx - 1] = dst_level->clear_value >> 32;
      }

      /* update clear color in SW meta area of the buffer if TS is exported */
      if (unlikely(etna_resource_ext_ts(etna_resource(dst->texture))))
         dst_level->ts_meta->v0.clear_value = dst_level->clear_value;

      etna_resource_level_ts_mark_valid(dst_level);
      etna_resource_level_mark_unflushed(dst_level);
      ctx->dirty |= ETNA_DIRTY_TS | ETNA_DIRTY_DERIVE_TS;
   }

   if (dst->texture->bind & PIPE_BIND_SAMPLER_VIEW)
      ctx->dirty |= ETNA_DIRTY_TEXTURE_CACHES;

   resource_written(ctx, &dst_res->base);
   etna_resource_level_mark_changed(dst_level);
}

static void
etna_blit_clear_zs_blt(struct pipe_context *pctx, struct pipe_surface *dst,
                   unsigned buffers, double depth, unsigned stencil,
                   const struct pipe_scissor_state *scissor_state,
                   unsigned clear_mask)
{
   struct etna_context *ctx = etna_context(pctx);
   struct etna_resource *dst_res = etna_resource_get_render_compatible(pctx, dst->texture);
   struct etna_resource_level *dst_level = &dst_res->levels[dst->level];
   uint32_t new_clear_value = translate_clear_depth_stencil(dst->format, depth, stencil);
   bool fast_clear = etna_blt_will_fastclear(dst_level, scissor_state, clear_mask, 0xff);
   uint32_t new_clear_bits = 0, clear_bits_depth, clear_bits_stencil;
   int msaa_xscale = 1, msaa_yscale = 1;

   translate_samples_to_xyscale(dst->texture->nr_samples,
                                &msaa_xscale, &msaa_yscale);

   /* Get the channels to clear */
   switch (dst->format) {
   case PIPE_FORMAT_Z16_UNORM:
   case PIPE_FORMAT_X8Z24_UNORM:
      clear_bits_depth = 0xffffffff;
      clear_bits_stencil = 0x00000000;
      break;
   case PIPE_FORMAT_S8_UINT_Z24_UNORM:
      clear_bits_depth = 0xffffff00;
      clear_bits_stencil = clear_mask;
      break;
   default:
      clear_bits_depth = clear_bits_stencil = 0xffffffff;
      break;
   }

   if (buffers & PIPE_CLEAR_DEPTH)
      new_clear_bits |= clear_bits_depth;
   if (buffers & PIPE_CLEAR_STENCIL)
      new_clear_bits |= clear_bits_stencil;

   if (new_clear_bits == 0xffffffff && fast_clear)
      dst_level->clear_value = new_clear_value;

   /* TODO unduplicate this */
   struct blt_clear_op clr = {};
   clr.dest.addr.bo = dst_res->bo;
   clr.dest.addr.offset = dst_level->offset + dst->first_layer * dst_level->layer_stride;
   clr.dest.addr.flags = ETNA_RELOC_WRITE;
   clr.dest.bpp = util_format_get_blocksize(dst_res->internal_format);
   clr.dest.stride = dst_level->stride;
   clr.dest.tiling = dst_res->layout;

   if (dst_level->ts_size) {
      clr.dest.use_ts = 1;
      clr.dest.ts_addr.bo = dst_res->ts_bo;
      clr.dest.ts_addr.offset = dst_level->ts_offset;
      clr.dest.ts_addr.flags = ETNA_RELOC_WRITE;
      clr.dest.ts_clear_value[0] = dst_level->clear_value;
      clr.dest.ts_clear_value[1] = dst_level->clear_value;
      clr.dest.ts_mode = dst_level->ts_mode;
      clr.dest.ts_compress_fmt = dst_level->ts_compress_fmt;
   }

   clr.clear_value[0] = new_clear_value;
   clr.clear_value[1] = new_clear_value;
   clr.clear_bits[0] = new_clear_bits;
   clr.clear_bits[1] = new_clear_bits;

   if (scissor_state) {
      clr.rect_x = scissor_state->minx * msaa_xscale;
      clr.rect_y = scissor_state->miny * msaa_yscale;
      clr.rect_w = (scissor_state->maxx - scissor_state->minx) * msaa_xscale;
      clr.rect_h = (scissor_state->maxy - scissor_state->miny) * msaa_yscale;
   } else {
      clr.rect_x = 0;
      clr.rect_y = 0;
      clr.rect_w = dst_level->width * msaa_xscale;
      clr.rect_h = dst_level->height * msaa_yscale;
   }

   emit_blt_clearimage(ctx, &clr);

   /* This made the TS valid */
   if (dst_level->ts_size) {
      ctx->framebuffer.TS_DEPTH_CLEAR_VALUE = dst_level->clear_value;
      etna_resource_level_ts_mark_valid(dst_level);
      etna_resource_level_mark_unflushed(dst_level);
      ctx->dirty |= ETNA_DIRTY_TS | ETNA_DIRTY_DERIVE_TS;
   }

   if (dst->texture->bind & PIPE_BIND_SAMPLER_VIEW)
      ctx->dirty |= ETNA_DIRTY_TEXTURE_CACHES;

   resource_written(ctx, &dst_res->base);
   etna_resource_level_mark_changed(dst_level);
}

static inline unsigned
color_mask_for_buffer(unsigned mask, unsigned buffer)
{
   return ((mask) >> (4 * (buffer))) & 0xf;
}

static void
etna_clear_blt(struct pipe_context *pctx, unsigned buffers,
           uint32_t color_clear_mask, uint8_t stencil_clear_mask,
           const struct pipe_scissor_state *scissor_state,
           const union pipe_color_union *color, double depth, unsigned stencil)
{
   struct etna_context *ctx = etna_context(pctx);

   if (!etna_render_condition_check(pctx))
      return;

   etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);
   etna_set_state(ctx->stream, VIVS_TS_FLUSH_CACHE, VIVS_TS_FLUSH_CACHE_FLUSH);

   if (buffers & PIPE_CLEAR_COLOR) {
      for (int idx = 0; idx < ctx->framebuffer_s.base.nr_cbufs; ++idx) {
         struct pipe_surface *psurf = &ctx->framebuffer_s.base.cbufs[idx];

         if (!psurf->texture)
            continue;

         if (!(buffers & (PIPE_CLEAR_COLOR0 << idx)))
            continue;

         etna_blit_clear_color_blt(pctx, idx, color, scissor_state,
                                   color_mask_for_buffer(color_clear_mask, idx));

         if (!etna_resource(psurf->texture)->explicit_flush)
            etna_context_add_flush_resource(ctx, psurf->texture);
      }
   }

   if ((buffers & PIPE_CLEAR_DEPTHSTENCIL) && ctx->framebuffer_s.base.zsbuf.texture != NULL)
      etna_blit_clear_zs_blt(pctx, &ctx->framebuffer_s.base.zsbuf, buffers, depth, stencil, scissor_state, stencil_clear_mask);

   etna_stall(ctx->stream, SYNC_RECIPIENT_RA, SYNC_RECIPIENT_BLT);

   if ((buffers & PIPE_CLEAR_COLOR) && (buffers & PIPE_CLEAR_DEPTH))
      etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);
   else
      etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000002);
}

static bool
etna_generate_mipmap_blt(struct pipe_context *pctx,
                         struct pipe_resource *prsc,
                         enum pipe_format format,
                         unsigned base_level,
                         unsigned last_level,
                         unsigned first_layer,
                         unsigned last_layer)
{
   struct etna_resource *rsc = etna_resource(prsc);
   struct etna_context *ctx = etna_context(pctx);
   struct etna_resource_level *src_lev = &rsc->levels[base_level];

   if (format != prsc->format)
      return false;

   if (first_layer != last_layer)
      return false;

   uint32_t fmt = translate_blt_format(format);
   if (fmt == ETNA_NO_MATCH) {
      perf_debug_ctx(ctx, "BLT mipmap generation not possible due to unsupported format: %s\n",
                     util_format_short_name(format));
      return false;
   }

   struct blt_genmipmap_op op = {};

   op.num_levels = last_level - base_level;
   op.width = prsc->width0;
   op.height = prsc->height0;
   op.src.addr.bo = rsc->bo;
   op.src.addr.offset = src_lev->offset + (first_layer * src_lev->layer_stride);
   op.src.addr.flags = ETNA_RELOC_READ;
   op.src.stride = src_lev->stride;
   op.src.tiling = rsc->layout;
   op.src.format = fmt;
   op.src.swizzle[0] = 0;
   op.src.swizzle[1] = 1;
   op.src.swizzle[2] = 2;
   op.src.swizzle[3] = 3;

   if (etna_resource_level_ts_valid(src_lev)) {
      assert(first_layer == 0);

      op.src.use_ts = 1;
      op.src.ts_addr.bo = rsc->ts_bo;
      op.src.ts_addr.offset = src_lev->ts_offset;
      op.src.ts_addr.flags = ETNA_RELOC_READ;
      op.src.ts_mode = src_lev->ts_mode;
      op.src.ts_compress_fmt = src_lev->ts_compress_fmt;
   }

   for (unsigned i = 0; i < op.num_levels; i++) {
      struct etna_resource_level *dst_lev = &rsc->levels[i + 1];

      op.level[i].bo = rsc->bo;
      op.level[i].offset = dst_lev->offset + (first_layer * dst_lev->layer_stride);
      op.level[i].flags = ETNA_RELOC_WRITE;
      op.stride[i] = dst_lev->stride;

      etna_resource_level_ts_mark_invalid(dst_lev);
   }

   emit_blt_genmipmap(ctx, &op);

   etna_stall(ctx->stream, SYNC_RECIPIENT_RA, SYNC_RECIPIENT_BLT);

   resource_read(ctx, prsc);
   resource_written(ctx, prsc);

   ctx->dirty |= ETNA_DIRTY_TEXTURE_CACHES;

   return true;
}

static bool
etna_try_blt_blit(struct pipe_context *pctx,
                 const struct pipe_blit_info *blit_info)
{
   struct etna_context *ctx = etna_context(pctx);
   struct etna_resource *src = etna_resource(blit_info->src.resource);
   struct etna_resource *dst = etna_resource(blit_info->dst.resource);
   int src_xscale, src_yscale, dst_xscale, dst_yscale;
   bool downsample_x = false, downsample_y = false;

   /* Ensure that the level is valid */
   assert(blit_info->src.level <= src->base.last_level);
   assert(blit_info->dst.level <= dst->base.last_level);

   if (!translate_samples_to_xyscale(src->base.nr_samples, &src_xscale, &src_yscale))
      return false;
   if (!translate_samples_to_xyscale(dst->base.nr_samples, &dst_xscale, &dst_yscale))
      return false;

   /* BLT does not support upscaling */
   if ((src_xscale < dst_xscale) || (src_yscale < dst_yscale)) {
      DBG("upscaling requested: source %dx%d destination %dx%d",
          src_xscale, src_yscale, dst_xscale, dst_yscale);
      return false;
   }

   if (src_xscale > dst_xscale)
      downsample_x = true;
   if (src_yscale > dst_yscale)
      downsample_y = true;

   /* The width/height are in pixels; they do not change as a result of
    * multi-sampling. So, when blitting from a 4x multisampled surface
    * to a non-multisampled surface, the width and height will be
    * identical. As we do not support scaling, reject different sizes.
    * TODO: could handle 2x downsample here with emit_blt_genmipmaps */
   if (blit_info->dst.box.width != blit_info->src.box.width ||
       blit_info->dst.box.height != abs(blit_info->src.box.height)) { /* allow y flip for glTexImage2D */
      DBG("scaling requested: source %dx%d destination %dx%d",
          blit_info->src.box.width, blit_info->src.box.height,
          blit_info->dst.box.width, blit_info->dst.box.height);
      return false;
   }

   /* No masks - not sure if BLT can copy individual channels */
   unsigned mask = util_format_get_mask(blit_info->dst.format);
   if ((blit_info->mask & mask) != mask) {
      DBG("sub-mask requested: 0x%02x vs format mask 0x%02x", blit_info->mask, mask);
      return false;
   }

   struct blt_conv_swizzle conv_swizzle = { 0 };
   bool has_conversion = false;
   enum pipe_format src_fmt = blit_info->src.format;
   enum pipe_format dst_fmt = blit_info->dst.format;

   if (src_fmt != dst_fmt) {
      has_conversion = find_blt_conversion(src_fmt, dst_fmt, &conv_swizzle);

      if (!has_conversion) {
         DBG("format conversion not supported: %s -> %s",
             util_format_short_name(src_fmt),
             util_format_short_name(dst_fmt));

         return false;
      }

      blt_assert_swizzle_compatible(blit_info);
   }

   src_fmt = translate_format_128bit_to_64bit(src_fmt);
   dst_fmt = translate_format_128bit_to_64bit(dst_fmt);

   /* try to find an exact format match first */
   uint32_t src_format = translate_blt_format(src_fmt);
   uint32_t dst_format = translate_blt_format(dst_fmt);
   /* When not resolving MSAA, but only doing a layout conversion, we can get
    * away with a fallback format of matching size.
    */
   if (src_format == ETNA_NO_MATCH && !downsample_x && !downsample_y)
      src_format = etna_compatible_blt_format(src_fmt);
   if (dst_format == ETNA_NO_MATCH && !downsample_x && !downsample_y)
      dst_format = etna_compatible_blt_format(dst_fmt);
   if (src_format == ETNA_NO_MATCH || dst_format == ETNA_NO_MATCH) {
      DBG("format not supported: %s -> %s",
          util_format_short_name(src_fmt), util_format_short_name(dst_fmt));
      return false;
   }

   if (blit_info->scissor_enable ||
       (blit_info->swizzle_enable && !has_conversion) ||
       blit_info->dst.box.depth != blit_info->src.box.depth ||
       blit_info->dst.box.depth != 1) {
      return false;
   }

   struct etna_resource_level *src_lev = &src->levels[blit_info->src.level];
   struct etna_resource_level *dst_lev = &dst->levels[blit_info->dst.level];

   /* if we asked for in-place resolve, return immediately if ts isn't valid
    * do this check separately because it applies when compression is used, but
    * we can't use inplace resolve path with compression
    */
   if (src == dst) {
      if (memcmp(&blit_info->src, &blit_info->dst, sizeof(blit_info->src)))
         return false;

      if (!etna_resource_level_ts_valid(src_lev)) /* No TS, no worries */
         return true;
   }

   /* Flush destination, as the blit will invalidate any pending TS changes. */
   if (dst != src && etna_resource_level_needs_flush(dst_lev))
      etna_copy_resource(pctx, &dst->base, &dst->base,
                         blit_info->dst.level, blit_info->dst.level,
                         false);

   /* Kick off BLT here */
   if (src == dst && src_lev->ts_compress_fmt < 0) {
      /* Resolve-in-place */
      struct blt_inplace_op op = {};
      size_t tile_size = etna_screen_get_tile_size(ctx->screen, src_lev->ts_mode,
                                                   src->base.nr_samples > 1);

      op.addr.bo = src->bo;
      op.addr.offset = src_lev->offset + blit_info->src.box.z * src_lev->layer_stride;
      op.addr.flags = ETNA_RELOC_READ | ETNA_RELOC_WRITE;
      op.ts_addr.bo = src->ts_bo;
      op.ts_addr.offset = src_lev->ts_offset + blit_info->src.box.z * src_lev->ts_layer_stride;
      op.ts_addr.flags = ETNA_RELOC_READ;
      op.ts_clear_value[0] = src_lev->clear_value;
      op.ts_clear_value[1] = src_lev->clear_value >> 32;
      op.ts_mode = src_lev->ts_mode;
      op.num_tiles = src_lev->layer_stride / tile_size;
      op.bpp = util_format_get_blocksize(src->internal_format);

      etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);
      etna_set_state(ctx->stream, VIVS_TS_FLUSH_CACHE, 0x00000001);
      emit_blt_inplace(ctx, &op);
   } else {
      /* Copy op */
      struct blt_imgcopy_op op = {};
      static const uint8_t ident[] = {0, 1, 2, 3};

      op.src.addr.bo = src->bo;
      op.src.addr.offset = src_lev->offset + blit_info->src.box.z * src_lev->layer_stride;
      op.src.addr.flags = ETNA_RELOC_READ;
      op.src.bpp = util_format_get_blocksize(src->internal_format);

      /* Only convert across the sRGB<->linear boundary. A same-encoding copy is
       * bit-preserving and a decode+encode roundtrip would only lose precision.
       */
      const bool src_is_srgb = util_format_is_srgb(src_fmt);
      const bool dst_is_srgb = util_format_is_srgb(dst_fmt);

      op.src.format = src_format;
      op.src.srgb = src_is_srgb && !dst_is_srgb;
      op.src.stride = src_lev->stride;
      op.src.tiling = src->layout;
      op.src.downsample_x = downsample_x;
      op.src.downsample_y = downsample_y;

      op.downsample_one_sample = (downsample_x || downsample_y) &&
                                 resolve_copies_one_sample(blit_info->dst.format);
      if (has_conversion)
         memcpy(op.src.swizzle, conv_swizzle.src_swizzle, 4);
      else
         memcpy(op.src.swizzle, ident, 4);

      if (etna_resource_level_ts_valid(src_lev)) {
         op.src.use_ts = 1;
         op.src.ts_addr.bo = src->ts_bo;
         op.src.ts_addr.offset = src_lev->ts_offset + blit_info->src.box.z * src_lev->ts_layer_stride;
         op.src.ts_addr.flags = ETNA_RELOC_READ;
         op.src.ts_clear_value[0] = src_lev->clear_value;
         op.src.ts_clear_value[1] = src_lev->clear_value >> 32;
         op.src.ts_mode = src_lev->ts_mode;
         op.src.ts_compress_fmt = src_lev->ts_compress_fmt;
      }

      op.dest.addr.bo = dst->bo;
      op.dest.addr.offset = dst_lev->offset + blit_info->dst.box.z * dst_lev->layer_stride;
      op.dest.addr.flags = ETNA_RELOC_WRITE;
      op.dest.format = dst_format;
      op.dest.srgb = dst_is_srgb && !src_is_srgb;
      op.dest.stride = dst_lev->stride;
      op.dest.tiling = dst->layout;
      if (has_conversion)
         memcpy(op.dest.swizzle, conv_swizzle.dst_swizzle, 4);
      else
         memcpy(op.dest.swizzle, ident, 4);

      /* Apply R<->B swizzle when needed:
       * - Transfer blits (CPU access): swap on the linear side to convert
       *   between GPU-internal BGRA and CPU RGBA byte order.
       * - Shared resource flushes: swap dest to convert PE-internal BGRA
       *   back to the standard RGBA byte order for external consumers. */
      if (ctx->blit_rb_swap) {
         op.dest.swizzle[0] = 2; /* R from B position */
         op.dest.swizzle[2] = 0; /* B from R position */
      } else if (ctx->in_transfer_blit &&
                 translate_pe_format_rb_swap(blit_info->src.format, ctx->screen) &&
                 !src->shared && !dst->shared) {
         bool src_linear = src->layout == ETNA_LAYOUT_LINEAR;
         bool dst_linear = dst->layout == ETNA_LAYOUT_LINEAR;

         if (src_linear != dst_linear) {
            uint8_t *swiz = src_linear ? op.src.swizzle : op.dest.swizzle;
            swiz[0] = 2; /* R from B position */
            swiz[2] = 0; /* B from R position */
         }
      }

      op.dest_x = blit_info->dst.box.x;
      op.dest_y = blit_info->dst.box.y;
      op.src_x = blit_info->src.box.x;
      op.src_y = blit_info->src.box.y;
      op.rect_w = blit_info->dst.box.width;
      op.rect_h = blit_info->dst.box.height;

      assert(op.dest_x < dst_lev->padded_width);
      assert(op.dest_y < dst_lev->padded_height);
      assert((op.dest_x + op.rect_w) <= dst_lev->padded_width);
      assert((op.dest_y + op.rect_h) <= dst_lev->padded_height);

      if (blit_info->src.box.height < 0) { /* flipped? fix up base y */
         op.flip_y = 1;
         op.src_y += blit_info->src.box.height;
      }

      op.src_x *= src_xscale;
      op.src_y *= src_yscale;
      op.rect_w *= src_xscale;
      op.rect_h *= src_yscale;

      assert(op.src_x < src_lev->padded_width);
      assert(op.src_y < src_lev->padded_height);
      assert((op.src_x + op.rect_w) <= src_lev->padded_width);
      assert((op.src_y + op.rect_h) <= src_lev->padded_height);

      etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);
      etna_set_state(ctx->stream, VIVS_TS_FLUSH_CACHE, 0x00000001);
      emit_blt_copyimage(ctx, &op);

      if (format_is_128bit(blit_info->dst.format)) {
         op.src.addr.offset += etna_resource_level_second_plane_offset(src_lev);
         op.dest.addr.offset += etna_resource_level_second_plane_offset(dst_lev);

         emit_blt_copyimage(ctx, &op);
      }
   }

   /* Make FE wait for BLT, in case we want to do something with the image next.
    * This probably shouldn't be here, and depend on what is done with the resource.
    */
   etna_stall(ctx->stream, SYNC_RECIPIENT_FE, SYNC_RECIPIENT_BLT);
   etna_set_state(ctx->stream, VIVS_GL_FLUSH_CACHE, 0x00000c23);

   resource_read(ctx, &src->base);
   resource_written(ctx, &dst->base);

   etna_resource_level_mark_changed(dst_lev);

   /* We don't need to mark the TS as invalid if this was just a flush without
    * compression, as in that case only clear tiles are filled and the tile
    * status still matches the blit target buffer. For compressed formats the
    * tiles are decompressed, so tile status doesn't match anymore.
    */
   if (src != dst || src_lev->ts_compress_fmt >= 0)
      etna_resource_level_ts_mark_invalid(dst_lev);

   ctx->dirty |= ETNA_DIRTY_DERIVE_TS;

   return true;
}

static void
etna_emit_yuv_tiler_state_blt(struct etna_context *ctx, struct etna_yuv_config *config)
{
   struct etna_cmd_stream *stream = ctx->stream;

   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000001);
   etna_set_state(stream, VIVS_BLT_YUV_CONFIG,
                  VIVS_BLT_YUV_CONFIG_SOURCE_FORMAT(config->format) | VIVS_BLT_YUV_CONFIG_ENABLE);
   etna_set_state(stream, VIVS_BLT_YUV_WINDOW_SIZE,
                  VIVS_BLT_YUV_WINDOW_SIZE_HEIGHT(config->height) |
                  VIVS_BLT_YUV_WINDOW_SIZE_WIDTH(config->width));

   etna_yuv_emit_plane(ctx, config->planes[0], ETNA_PENDING_READ, VIVS_BLT_YUV_SRC_YADDR, VIVS_BLT_YUV_SRC_YSTRIDE);
   etna_yuv_emit_plane(ctx, config->planes[1], ETNA_PENDING_READ, VIVS_BLT_YUV_SRC_UADDR, VIVS_BLT_YUV_SRC_USTRIDE);
   etna_yuv_emit_plane(ctx, config->planes[2], ETNA_PENDING_READ, VIVS_BLT_YUV_SRC_VADDR, VIVS_BLT_YUV_SRC_VSTRIDE);
   etna_yuv_emit_plane(ctx, config->dst, ETNA_PENDING_WRITE, VIVS_BLT_YUV_DEST_ADDR, VIVS_BLT_YUV_DEST_STRIDE);

   /* trigger resolve */
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_COMMAND, VIVS_BLT_COMMAND_COMMAND_YUV_TILE);
   etna_set_state(stream, VIVS_BLT_SET_COMMAND, 0x00000003);
   etna_set_state(stream, VIVS_BLT_ENABLE, 0x00000000);

   etna_stall(stream, SYNC_RECIPIENT_RA, SYNC_RECIPIENT_BLT);
}

void
etna_clear_blit_blt_init(struct pipe_context *pctx)
{
   struct etna_context *ctx = etna_context(pctx);

   DBG("etnaviv: Using BLT blit engine");
   pctx->clear = etna_clear_blt;
   pctx->generate_mipmap = etna_generate_mipmap_blt;
   ctx->blit = etna_try_blt_blit;
   ctx->emit_yuv_tiler_state = etna_emit_yuv_tiler_state_blt;
}
