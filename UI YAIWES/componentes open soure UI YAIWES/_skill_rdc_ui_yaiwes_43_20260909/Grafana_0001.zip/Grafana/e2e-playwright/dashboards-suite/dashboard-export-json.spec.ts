import { test, expect } from '@grafana/plugin-e2e';

test.use({
  featureToggles: {
    dashboardNewLayouts: true,
  },
});

test.describe(
  'Export as JSON',
  {
    tag: ['@dashboards'],
  },
  () => {
    test('Export for internal and external use', async ({ gotoDashboardPage, page, selectors }) => {
      const dashboardPage = await gotoDashboardPage({
        uid: 'ZqZnVvFZz',
      });

      // Open the export drawer. Under new layouts the export control lives in the sidebar rail
      // (NewExportButton.Menu.container), not the legacy toolbar split button (arrowMenu).
      const exportButton = dashboardPage.getByGrafanaSelector(
        selectors.pages.Dashboard.DashNav.NewExportButton.Menu.container
      );
      await expect(exportButton).toBeVisible();
      await exportButton.click();
      await dashboardPage
        .getByGrafanaSelector(selectors.pages.Dashboard.DashNav.NewExportButton.Menu.exportAsJson)
        .click();

      await expect(page).toHaveURL(/.*shareView=export.*/);

      // Export as JSON
      await expect(
        dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.container)
      ).toBeVisible();
      await expect(
        dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.exportExternallyToggle)
      ).toBeChecked({
        checked: false,
      });
      const codeEditor = dashboardPage.getByGrafanaSelector(
        selectors.pages.ExportDashboardDrawer.ExportAsJson.codeEditor
      );
      await expect(codeEditor.getByRole('textbox', { name: 'Dashboard definition' })).toBeVisible();

      await expect(
        dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.saveToFileButton)
      ).toBeVisible();
      await expect(
        dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.copyToClipboardButton)
      ).toBeVisible();
      await expect(
        dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.cancelButton)
      ).toBeVisible();

      await dashboardPage
        .getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.copyToClipboardButton)
        .click();
      // TODO failing in CI - fix it
      // let clipboardContent = await page.evaluate(() => navigator.clipboard.readText());
      // expect(clipboardContent).not.toContain('__inputs');

      await dashboardPage
        .getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.exportExternallyToggle)
        .click({ force: true });

      await dashboardPage
        .getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.copyToClipboardButton)
        .click();
      // TODO failing in CI - fix it
      // clipboardContent = await page.evaluate(() => navigator.clipboard.readText());
      // expect(clipboardContent).toContain('__inputs');

      await dashboardPage.getByGrafanaSelector(selectors.pages.ExportDashboardDrawer.ExportAsJson.cancelButton).click();

      await expect(page).not.toHaveURL(/.*shareView=export.*/);
    });
  }
);
