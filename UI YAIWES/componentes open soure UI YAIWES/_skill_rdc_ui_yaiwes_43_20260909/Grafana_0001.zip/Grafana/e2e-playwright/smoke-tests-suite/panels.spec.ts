import { type BootData, type PanelPluginMeta } from '@grafana/data';
import { test, expect } from '@grafana/plugin-e2e';

test.describe(
  'Panels smokescreen',
  {
    tag: ['@acceptance'],
  },
  () => {
    test('Tests each panel type in the panel edit view to ensure no crash', async ({
      gotoDashboardPage,
      selectors,
      page,
    }) => {
      // this test can absolutely take longer than the default 30s timeout
      test.setTimeout(120000);

      // Create new dashboard
      const dashboardPage = await gotoDashboardPage({});

      // Add new panel
      const editPage = await dashboardPage.addPanel();

      // Get panel types from window object
      const panelTypes: PanelPluginMeta[] = await page.evaluate(() => {
        // @grafana/plugin-e2e doesn't export the full bootdata config
        // eslint-disable-next-line @typescript-eslint/consistent-type-assertions
        const win = window as typeof window & { grafanaBootData: BootData };
        return win.grafanaBootData?.settings?.panels ?? {};
      });

      // Loop through every panel type and ensure no crash
      for (const [_, panel] of Object.entries(panelTypes)) {
        if (panel.hideFromList || panel.state === 'deprecated') {
          continue; // Skip hidden and deprecated panels
        }

        try {
          await editPage.setVisualization(panel.name);

          // Verify panel type is selected
          await expect(
            editPage.getByGrafanaSelector(selectors.components.PanelEditor.OptionsPane.header),
            'verify panel editor for the selected panel type is rendered'
          ).toHaveText(panel.name, { timeout: 10000 });

          await expect(page.getByLabel('Panel loading bar'), 'wait for panel to finish rendering').toHaveCount(0, {
            timeout: 10000,
          });

          await expect(
            page.getByText('An unexpected error happened'),
            'ensure no unexpected error occurred'
          ).toBeHidden();
        } catch (error) {
          throw new Error(`Panel '${panel.name}' failed: ${error}`);
        }
      }
    });
  }
);
