export { SecretTextArea } from './SecretTextArea';
