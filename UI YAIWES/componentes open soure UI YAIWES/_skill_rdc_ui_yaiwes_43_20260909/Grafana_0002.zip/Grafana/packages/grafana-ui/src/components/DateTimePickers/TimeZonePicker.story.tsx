import { type Meta, type StoryFn } from '@storybook/react-webpack5';
import { action } from 'storybook/actions';
import { useArgs } from 'storybook/preview-api';

import { TimeZonePicker } from './TimeZonePicker';

const meta: Meta<typeof TimeZonePicker> = {
  title: 'Date time pickers/TimeZonePicker',
  component: TimeZonePicker,
  parameters: {
    controls: {
      exclude: ['inputId', 'onChange', 'onBlur'],
    },
  },
  args: {
    value: 'Europe/Stockholm',
  },
  argTypes: {
    includeInternal: {
      control: {
        type: 'boolean',
      },
    },
  },
};

export const Basic: StoryFn<typeof TimeZonePicker> = (args) => {
  const [, updateArgs] = useArgs();
  return (
    <TimeZonePicker
      {...args}
      onChange={(newValue) => {
        action('on selected')(newValue);
        updateArgs({ value: newValue });
      }}
      onBlur={action('onBlur')}
    />
  );
};

export default meta;
