import { css, cx } from '@emotion/css';

import { type GrafanaTheme2 } from '@grafana/data';

export type DragHandlePosition = 'middle' | 'start' | 'end';

export const getDragStyles = (theme: GrafanaTheme2, handlePosition?: DragHandlePosition) => {
  const position = handlePosition || 'middle';
  const baseColor = theme.colors.emphasize(theme.colors.background.secondary, 0.15);
  const hoverColor = theme.colors.accent.background;
  const clickTargetSize = theme.spacing(1);
  const handlebarThickness = 2;
  const handlebarWidth = theme.spacing(6);
  let verticalOffset = '50%';
  let horizontalOffset = '50%';

  switch (position) {
    case 'start': {
      verticalOffset = '0%';
      horizontalOffset = '0%';
      break;
    }
    case 'end': {
      verticalOffset = '100%';
      horizontalOffset = '100%';
      break;
    }
  }

  const dragHandleBase = css({
    position: 'relative',

    '&:before': {
      content: '""',
      position: 'absolute',
      [theme.transitions.handleMotion('no-preference', 'reduce')]: {
        transition: theme.transitions.create('border-color'),
      },
      zIndex: 1,
    },

    '&:after': {
      background: baseColor,
      content: '""',
      position: 'absolute',
      [theme.transitions.handleMotion('no-preference', 'reduce')]: {
        transition: theme.transitions.create('background'),
      },
      transform: 'translate(-50%, -50%)',
      borderRadius: theme.shape.radius.pill,
      zIndex: 1,
    },

    '&:hover': {
      '&:before': {
        background: hoverColor,
      },

      '&:after': {
        background: theme.colors.accent.main,
      },
    },
  });

  const beforeVertical = {
    width: theme.spacing(0.5),
    height: '100%',
    left: verticalOffset,
    transform: 'translateX(-50%)',
  };

  const beforeHorizontal = {
    height: theme.spacing(0.5),
    borderTop: '1px solid transparent',
    top: horizontalOffset,
    transform: 'translateY(-50%)',
    width: '100%',
  };

  return {
    dragHandleVertical: cx(
      dragHandleBase,
      css({
        cursor: 'col-resize',
        width: clickTargetSize,

        '&:before': beforeVertical,

        '&:after': {
          left: verticalOffset,
          top: '50%',
          height: handlebarWidth,
          width: handlebarThickness,
        },

        '&:hover': {
          '&:after': {
            background: theme.colors.accent.main,
            width: handlebarThickness * 2,
          },
        },
      })
    ),
    dragHandleHorizontal: cx(
      dragHandleBase,
      css({
        height: clickTargetSize,
        cursor: 'row-resize',

        '&:before': beforeHorizontal,

        '&:after': {
          left: '50%',
          top: horizontalOffset,
          height: handlebarThickness,
          width: handlebarWidth,
        },

        '&:hover': {
          '&:after': {
            background: theme.colors.accent.main,
            height: handlebarThickness * 2,
          },
        },
      })
    ),
    dragHandleBaseVertical: cx(
      dragHandleBase,
      css({
        cursor: 'col-resize',
        width: clickTargetSize,

        '&:before': beforeVertical,
      })
    ),
    dragHandleBaseHorizontal: cx(
      dragHandleBase,
      css({
        cursor: 'row-resize',
        height: clickTargetSize,

        '&:before': beforeHorizontal,
      })
    ),
  };
};
