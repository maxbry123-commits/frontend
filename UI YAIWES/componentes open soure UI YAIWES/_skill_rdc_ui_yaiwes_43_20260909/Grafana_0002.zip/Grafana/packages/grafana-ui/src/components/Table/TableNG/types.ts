import { type FC, type SyntheticEvent } from 'react';

import {
  type DataFrame,
  type Field,
  type GrafanaTheme2,
  type KeyValue,
  type TimeRange,
  type FieldConfigSource,
  type ActionModel,
  type FieldType,
  type DataFrameWithValue,
  type SelectableValue,
  type FieldState,
} from '@grafana/data';
import { type CellRendererProps, type Column } from '@grafana/react-data-grid';
import { type MatcherScope, type TableCellHeight } from '@grafana/schema';

import { type TableCellInspectorMode } from '../TableCellInspector';
import { type TableCellOptions } from '../types';

import { type TextAlign } from './styles';
import { type ApplyFilterResult } from './utils';

export const FILTER_FOR_OPERATOR = '=';
export const FILTER_OUT_OPERATOR = '!=';

type AdHocFilterOperator = typeof FILTER_FOR_OPERATOR | typeof FILTER_OUT_OPERATOR;
export type AdHocFilterItem = { key: string; value: string; operator: AdHocFilterOperator };
export type TableFilterActionCallback = (item: AdHocFilterItem) => void;
type TableColumnResizeActionCallback = (fieldDisplayName: string, width: number, fieldScope?: MatcherScope) => void;
type TableSortByActionCallback = (state: TableSortByFieldState[]) => void;
type FooterItem = Array<KeyValue<string>> | string | undefined;

type GetActionsFunction = (frame: DataFrame, field: Field, rowIndex: number) => ActionModel[];

export type GetActionsFunctionLocal = (field: Field, rowIndex: number) => ActionModel[];

export enum FilterOperator {
  CONTAINS = 'Contains',
  EQUALS = '=',
  NOT_EQUALS = '!=',
  GREATER = '>',
  GREATER_OR_EQUAL = '>=',
  LESS = '<',
  LESS_OR_EQUAL = '<=',
  EXPRESSION = 'Expression',
}

export type FilterType = Record<
  string,
  {
    filteredSet: Set<string>;
    displayName: string;
    filtered?: Array<SelectableValue<unknown>>;
    searchFilter?: string;
    operator?: SelectableValue<FilterOperator>;
    parentIndex?: number;
  }
>;

/* ----------------------------- Table specific types ----------------------------- */
export interface TableSummaryRow {
  [columnName: string]: string | number | undefined;
}

export interface TableColumn extends Column<TableRow, TableSummaryRow> {
  field: Field; // Grafana field data/config
  width?: number | string; // Column width
  minWidth?: number; // Min width constraint
}

// Possible values for table cells based on field types
type TableCellValue =
  | string // FieldType.string, FieldType.enum
  | number // FieldType.number
  | boolean // FieldType.boolean
  | Date // FieldType.time
  | DataFrame // For nested data
  | DataFrame[] // For nested frames
  | DataFrameWithValue // For sparklines
  | undefined; // For undefined values

export interface TableRow {
  // Required metadata properties
  __depth: number;
  __index: number;

  // Nested table properties
  data?: DataFrame;
  __expanded?: boolean; // For row expansion state
  __parentIndex?: number; // For nested table parent tracking

  // Generic typing for column values
  [columnName: string]: TableCellValue;
}

export interface TableSortByFieldState {
  displayName: string;
  desc?: boolean;
}

/**
 * Controls how the `sortBy` prop is applied.
 * `initial` will only read from the options on initial render,
 * while `managed` will update the sort order whenever the sortBy array is changed.
 */
export type SortByBehavior = 'initial' | 'managed';

interface BaseTableProps {
  ariaLabel?: string;
  data: DataFrame;
  width: number;
  height: number;
  maxHeight?: number;
  /** Minimal column width specified in pixels */
  columnMinWidth?: number;
  noHeader?: boolean;
  showTypeIcons?: boolean;
  resizable?: boolean;
  sortBy?: TableSortByFieldState[];
  sortByBehavior?: SortByBehavior;
  onColumnResize?: TableColumnResizeActionCallback;
  onSortByChange?: TableSortByActionCallback;
  onCellFilterAdded?: TableFilterActionCallback;
  footerValues?: FooterItem[];
  frozenColumns?: number;
  enablePagination?: boolean;
  /** When pagination is enabled, fixes the number of rows per page instead of deriving it from the panel height. */
  pageSize?: number;
  cellHeight?: TableCellHeight;
  maxRowHeight?: number;
  structureRev?: number;
  transparent?: boolean;
  /* message to show when no rows are present */
  noValue?: string;
  /** used by SparklineCell when provided */
  timeRange?: TimeRange;
  enableSharedCrosshair?: boolean;
  // The index of the field value that the table will initialize scrolled to
  initialRowIndex?: number;
  fieldConfig?: FieldConfigSource;
  getActions?: GetActionsFunction;
  // Used solely for testing as RTL can't correctly render the table otherwise
  enableVirtualization?: boolean;
  // for MarkdownCell, this flag disables sanitization of HTML content. Configured via config.ini.
  disableSanitizeHtml?: boolean;
  // if true, disables all keyboard events in the table. this is used when previewing a table (i.e. suggestions)
  disableKeyboardEvents?: boolean;
  // temporary feature toggle to manage rollout of content-aware auto column widths (table.autoColumnWidths)
  contentAwareWidthsEnabled?: boolean;
}

/* ---------------------------- Table cell props ---------------------------- */
export interface TableNGProps extends BaseTableProps {}

export type TableCellRenderer = FC<TableCellRendererProps>;

export interface TableCellRendererProps {
  rowIdx: number;
  frame: DataFrame;
  timeRange?: TimeRange;
  value: TableCellValue;
  height: number;
  // flags that are static per column
  field: Field;
  cellOptions: TableCellOptions;
  width: number;
  theme: GrafanaTheme2;
  cellInspect: boolean;
  showFilters: boolean;
  getActions?: GetActionsFunctionLocal;
  disableSanitizeHtml?: boolean;
  getTextColorForBackground: (color: string) => string;
}

export type InspectCellProps = {
  rowIdx?: number;
  value: string;
  mode?: TableCellInspectorMode.code | TableCellInspectorMode.text;
  preformatted?: boolean;
};

export interface TableCellActionsProps {
  field: Field;
  value: TableCellValue;
  displayName: string;
  cellInspect: boolean;
  showFilters: boolean;
  setInspectCell: React.Dispatch<React.SetStateAction<InspectCellProps | null>>;
  className?: string;
  onCellFilterAdded?: TableFilterActionCallback;
}

/* ------------------------- Specialized Cell Props ------------------------- */
export interface RowExpanderNGProps {
  onCellExpand: (e: SyntheticEvent) => void;
  rowId: string;
  isExpanded?: boolean;
}

export interface SparklineCellProps {
  field: Field;
  rowIdx: number;
  theme: GrafanaTheme2;
  timeRange?: TimeRange;
  value: TableCellValue;
  width: number;
}

export interface BarGaugeCellProps {
  field: Field;
  height: number;
  rowIdx: number;
  theme: GrafanaTheme2;
  value: TableCellValue;
  width: number;
}

export interface ImageCellProps {
  cellOptions: TableCellOptions;
  field: Field;
  value: TableCellValue;
  rowIdx: number;
}

export interface DataLinksCellProps {
  field: Field;
  rowIdx: number;
}

export interface GeoCellProps {
  value: TableCellValue;
  height: number;
}

export interface AutoCellProps {
  field: Field;
  value: TableCellValue;
  rowIdx: number;
}

export interface MarkdownCellProps {
  field: Field;
  rowIdx: number;
  disableSanitizeHtml?: boolean;
}

export interface ActionCellProps {
  field: Field;
  rowIdx: number;
  getActions: GetActionsFunctionLocal;
}

export interface PillCellProps {
  theme: GrafanaTheme2;
  field: Field;
  rowIdx: number;
  getTextColorForBackground: (color: string) => string;
}

export interface TableCellStyleOptions {
  textWrap: boolean;
  textAlign: TextAlign;
  shouldOverflow: boolean;
  maxHeight?: number;
}

export type TableCellStyles = (theme: GrafanaTheme2, options: TableCellStyleOptions) => string;

// Comparator for sorting table values
export type Comparator = (a: TableCellValue, b: TableCellValue) => number;

// Type for converting a DataFrame into an array of TableRows
export type FrameToRowsConverter = (frame: DataFrame, nestedRowIndex?: number) => TableRow[];

export interface NestedRowEntry {
  raw: TableRow[];
  final: TableRow[];
  filterResult: ApplyFilterResult;
}

// Type for mapping column names to their field types
export type ColumnTypes = Record<string, FieldType>;

export interface TypographyCtx {
  ctx: CanvasRenderingContext2D;
  fontFamily: string;
  letterSpacing: number;
  avgCharWidth: number;
  estimateHeight: MeasureCellHeight;
  measureHeight: MeasureCellHeight;
}

export type MeasureCellHeight = (
  value: unknown,
  width: number,
  field: Field,
  rowIdx: number,
  lineHeight: number
) => number;
export interface MeasureCellHeightEntry {
  /**
   * given a values and the available width, returns the line count for that value
   */
  measure: MeasureCellHeight;
  /**
   * if getting an accurate line count is expensive, you can provide an estimate method
   * which will be used when looping over the row. the method will only be invoked
   * for the cell which is the maximum line count for the row.
   */
  estimate?: MeasureCellHeight;
  /**
   * indicates which field indexes of the visible fields this measurer applies to.
   */
  fieldIdxs: number[];
}

export type CellRootRenderer = (key: React.Key, props: CellRendererProps<TableRow, TableSummaryRow>) => React.ReactNode;

export interface FromFieldsResult {
  columns: TableColumn[];
  cellRootRenderers: Record<string, CellRootRenderer>;
}

export interface FooterFieldState extends FieldState {
  lastProcessedRowCount: number;
}
