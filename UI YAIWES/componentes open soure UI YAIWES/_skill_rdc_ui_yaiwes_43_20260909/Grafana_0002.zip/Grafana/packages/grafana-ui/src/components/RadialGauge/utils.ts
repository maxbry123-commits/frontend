import {
  type FieldConfig,
  type FieldDisplay,
  GAUGE_DEFAULT_MAXIMUM,
  GAUGE_DEFAULT_MINIMUM,
  getActiveThreshold,
  getDisplayProcessor,
  type GrafanaTheme,
  type GrafanaTheme2,
  type Threshold,
  type ThresholdsConfig,
  ThresholdsMode,
} from '@grafana/data';

import { type RadialGaugeDimensions } from './types';

const DEFAULT_THRESHOLDS: ThresholdsConfig = {
  mode: ThresholdsMode.Absolute,
  steps: [
    { value: -Infinity, color: 'green' },
    { value: 80, color: 'red' },
  ],
};

export function getFieldDisplayProcessor(displayValue: FieldDisplay) {
  if (displayValue.view && displayValue.colIndex != null) {
    const dp = displayValue.view.getFieldDisplayProcessor(displayValue.colIndex);
    if (dp) {
      return dp;
    }
  }

  return getDisplayProcessor();
}

export function getFieldConfigMinMax(fieldDisplay: FieldDisplay) {
  let min = fieldDisplay.field.min ?? 0;
  let max = fieldDisplay.field.max ?? 100;

  // If min and max are equal (can happen for single value fields or if all values are the same)
  // Then we need to adjust them a bit to avoid division by zero
  if (min === max) {
    min -= min * 0.1;
    max += max * 0.1;
  }

  return [min, max];
}

export function getValuePercentageForValue(fieldDisplay: FieldDisplay, value = fieldDisplay.display.numeric) {
  const [min, max] = getFieldConfigMinMax(fieldDisplay);
  return (value - min) / (max - min);
}

export function getValueAngleForValue(
  fieldDisplay: FieldDisplay,
  startAngle: number,
  endAngle: number,
  neutral?: number
) {
  const angleRange = (360 % (startAngle === 0 ? 1 : startAngle)) + endAngle;
  const [min, max] = getFieldConfigMinMax(fieldDisplay);
  // getFieldConfigMinMax can invert bounds when min === max < 0; order before clamping.
  const low = Math.min(min, max);
  const high = Math.max(min, max);

  // Clamp arc geometry to [low, high]. Center text still uses the real value;
  // without this, overflow with a neutral point can produce invalid SVG arcs (#130075).
  const value = Math.min(Math.max(fieldDisplay.display.numeric, low), high);

  const valueAngle = getValuePercentageForValue(fieldDisplay, value) * angleRange;

  let endValueAngle = valueAngle;

  let startValueAngle = 0;
  if (typeof neutral === 'number') {
    const clampedNeutral = Math.min(Math.max(neutral, low), high);
    const neutralAngle = getValuePercentageForValue(fieldDisplay, clampedNeutral) * angleRange;
    if (neutralAngle <= valueAngle) {
      startValueAngle = neutralAngle;
      endValueAngle = valueAngle - neutralAngle;
    } else {
      startValueAngle = valueAngle;
      endValueAngle = neutralAngle - valueAngle;
    }
  }

  const clampedEndValueAngle = Math.min(Math.max(endValueAngle, 0), angleRange);

  return { angleRange, startValueAngle, endValueAngle: clampedEndValueAngle };
}

/**
 * Returns the angle in radians for a given angle in degrees
 * But shifted -90 degrees to make 0 degree angle point upwards
 * @param angle
 * @returns
 */
export function toRad(angle: number) {
  return ((angle - 90) * Math.PI) / 180;
}

/**
 * returns the calculated dimensions for the radial gauge
 * @param width
 * @param height
 * @param endAngle
 * @param glow
 * @param roundedBars
 * @param barWidthFactor
 * @param barIndex
 * @param thresholdBar
 * @param showScaleLabels
 * @returns {RadialGaugeDimensions}
 */
export function calculateDimensions(
  width: number,
  height: number,
  endAngle: number,
  glow: boolean,
  roundedBars: boolean,
  barWidthFactor: number,
  barIndex: number,
  thresholdBar?: boolean,
  showScaleLabels?: boolean
): RadialGaugeDimensions {
  const yMaxAngle = endAngle > 180 ? 180 : endAngle;
  let margin = 0;

  if (glow) {
    margin = 0.02 * Math.min(width, height);
  }

  // Max radius based on width
  let maxRadiusW = width / 2 - margin;

  // Max radius based on height
  let heightRatioV = Math.sin(toRad(yMaxAngle));
  let maxRadiusH = (height - margin * 2) / (1 + heightRatioV);

  let maxRadius = Math.min(maxRadiusW, maxRadiusH);
  let maxRadiusIsLimitedByHeight = maxRadiusH === maxRadius;
  let outerRadius = maxRadius;

  const barWidth = Math.max(barWidthFactor * (maxRadius / 3), 2);

  // When enabling stroke-linecap="round" on a path, the circular endcap is appended outside of the path.
  // If you don't adjust the positioning or the path, then the endcaps will probably clip off the bottom
  // of the panel. To account for this, the circular endcap radius (which is half the bar width) needs
  // to be accounted for. To get the best visual result, we will take some off the radius of the
  // visualization overall and some off of the vertical space by offsetting the centerY upwards.
  const totalEndcapAdjustment = yMaxAngle < 180 && roundedBars ? barWidth * 0.5 : 0;

  // change the factor we multiply here to steal more or less from the size of the gauge vs. the centerY position.
  // there's actually a range of values you could use here to make this work, the 50/50 split looks the best
  // to me, because it handles use cases like bar glow well and avoids clipping on either vertical edge of the panel.
  const radiusEndcapAdjustment = totalEndcapAdjustment * 0.5;
  outerRadius -= radiusEndcapAdjustment;
  maxRadiusH -= radiusEndcapAdjustment;
  maxRadiusW -= radiusEndcapAdjustment;

  // Scale labels
  let scaleLabelsFontSize = 0;
  let scaleLabelsSpacing = 0;
  let scaleLabelsRadius = 0;

  if (showScaleLabels) {
    scaleLabelsRadius = outerRadius;
    const radiusToFontSizeFactor = 0.12;
    scaleLabelsFontSize = Math.max(radiusToFontSizeFactor * Math.pow(outerRadius, 0.92), 10);
    scaleLabelsSpacing = scaleLabelsFontSize / 3;
    const labelsSize = scaleLabelsFontSize * 1.2 + scaleLabelsSpacing;
    outerRadius -= labelsSize;
    maxRadiusW -= labelsSize;
    maxRadiusH -= labelsSize;

    // FIXME: needs coverage
    // For gauges the max label needs a bit more vertical space so that it does not get clipped
    if (maxRadiusIsLimitedByHeight && endAngle < 180) {
      const amount = outerRadius * 0.07;
      scaleLabelsRadius -= amount;
      maxRadiusH -= amount;
      maxRadiusW -= amount;
      outerRadius -= amount;
    }
  }

  // Thresholds bar
  const thresholdsToBarWidth = 0.2 * Math.pow(barWidth, 0.92);
  const thresholdsBarWidth = thresholdBar ? Math.min(Math.max(thresholdsToBarWidth, 4), 12) : 0;
  const thresholdsBarSpacing = Math.min(Math.max(thresholdsBarWidth / 2, 2), 12);
  let thresholdsBarRadius = 0;

  if (thresholdsBarWidth > 0) {
    thresholdsBarRadius = outerRadius - thresholdsBarWidth / 2;
    maxRadiusW -= thresholdsBarWidth + thresholdsBarSpacing;
    maxRadiusH -= thresholdsBarWidth + thresholdsBarSpacing;
    outerRadius = Math.min(maxRadiusW, maxRadiusH);
  }

  let innerRadius = outerRadius - barWidth / 2;

  const belowCenterY = maxRadius * Math.sin(toRad(yMaxAngle));
  const rest = height - belowCenterY - margin * 2 - maxRadius;
  const centerX = width / 2;
  const centerYEndcapAdjustment = totalEndcapAdjustment - radiusEndcapAdjustment;
  const centerY = maxRadius + margin + rest / 2 - centerYEndcapAdjustment;

  if (barIndex > 0) {
    innerRadius = innerRadius - (barWidth + 4) * barIndex;
  }

  return {
    vizWidth: width,
    vizHeight: height,
    margin,
    gaugeBottomY: centerY + belowCenterY,
    radius: innerRadius,
    centerX,
    centerY,
    barWidth,
    barIndex,
    thresholdsBarWidth,
    thresholdsBarSpacing,
    thresholdsBarRadius,
    scaleLabelsFontSize,
    scaleLabelsSpacing,
    scaleLabelsRadius,
  };
}

export function drawRadialArcPath(
  startAngle: number,
  endAngle: number,
  radius: number,
  xOffset = 0,
  yOffset = 0
): string {
  // For some reason a 100% full arc cannot be rendered
  if (endAngle >= 360) {
    endAngle = 359.99;
  }

  const startRadians = toRad(startAngle);
  const endRadians = toRad(startAngle + endAngle);

  const largeArc = endAngle > 180 ? 1 : 0;

  const MAX_DECIMALS = 2;

  const x1 = xOffset + parseFloat((radius * Math.cos(startRadians)).toFixed(MAX_DECIMALS));
  const y1 = yOffset + parseFloat((radius * Math.sin(startRadians)).toFixed(MAX_DECIMALS));
  const x2 = xOffset + parseFloat((radius * Math.cos(endRadians)).toFixed(MAX_DECIMALS));
  const y2 = yOffset + parseFloat((radius * Math.sin(endRadians)).toFixed(MAX_DECIMALS));

  return `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`;
}

export function getAngleBetweenSegments(segmentSpacing: number, segmentCount: number, range: number) {
  // Max spacing is 8 degrees between segments
  // Changing this constant could be considered a breaking change
  const maxAngleBetweenSegments = Math.max(range / 1.5 / segmentCount, 2);
  return segmentSpacing * maxAngleBetweenSegments;
}

export function getOptimalSegmentCount(
  dimensions: RadialGaugeDimensions,
  segmentSpacing: number,
  segmentCount: number,
  range: number
) {
  const angleBetweenSegments = getAngleBetweenSegments(segmentSpacing, segmentCount, range);

  const innerRadius = dimensions.radius - dimensions.barWidth / 2;
  const circumference = Math.PI * innerRadius * 2 * (range / 360);
  const maxSegments = Math.floor(circumference / (angleBetweenSegments + 3));

  return Math.min(maxSegments, segmentCount);
}

export function getThresholdPercentageValue(
  threshold: Threshold,
  thresholdsMode: ThresholdsMode,
  fieldDisplay: FieldDisplay
): number {
  if (thresholdsMode === ThresholdsMode.Percentage) {
    return threshold.value / 100;
  }
  const [min, max] = getFieldConfigMinMax(fieldDisplay);
  return (threshold.value - min) / (max - min);
}

export function getFormattedThresholds(
  decimals: number,
  field: FieldConfig,
  theme: GrafanaTheme | GrafanaTheme2,
  offsetColor = true
): Threshold[] {
  const thresholds = field.thresholds ?? DEFAULT_THRESHOLDS;
  const isPercent = thresholds.mode === ThresholdsMode.Percentage;
  const steps = thresholds.steps;

  let min = field.min ?? GAUGE_DEFAULT_MINIMUM;
  let max = field.max ?? GAUGE_DEFAULT_MAXIMUM;

  if (isPercent) {
    min = 0;
    max = 100;
  }

  const first = getActiveThreshold(min, steps);
  const last = getActiveThreshold(max, steps);
  const formatted: Threshold[] = [];

  if (offsetColor) {
    formatted.push({
      value: parseFloat(min.toFixed(decimals)),
      color: theme.visualization.getColorByName(first.color),
    });
  }

  let skip = offsetColor;
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    if (skip) {
      if (first === step) {
        skip = false;
      }
      continue;
    }
    const prev = steps[i - 1];
    formatted.push({
      value: isFinite(step.value) ? step.value : min,
      color: theme.visualization.getColorByName((offsetColor ? prev : step).color),
    });
    if (step === last) {
      break;
    }
  }
  if (max > last.value) {
    formatted.push({ value: parseFloat(max.toFixed(decimals)), color: theme.visualization.getColorByName(last.color) });
  }
  return formatted;
}

export const IS_SAFARI = (() => {
  if (navigator == null) {
    return false;
  }
  const userAgent = navigator.userAgent;
  const safariVersionMatch = userAgent.match(/Version\/(\d+)\.(\d+)/);
  if (!safariVersionMatch) {
    return false;
  }
  return true;
})();
