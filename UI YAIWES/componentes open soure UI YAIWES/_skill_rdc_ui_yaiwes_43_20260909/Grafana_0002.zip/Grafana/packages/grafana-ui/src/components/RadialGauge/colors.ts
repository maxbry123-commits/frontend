import tinycolor from 'tinycolor2';

import {
  colorManipulator,
  FALLBACK_COLOR,
  type FieldDisplay,
  getFieldColorMode,
  type GrafanaTheme2,
  ThresholdsMode,
} from '@grafana/data';
import { FieldColorModeId } from '@grafana/schema';

import { DEFAULT_DECIMALS } from './constants';
import { type GradientStop } from './types';
import { getThresholdPercentageValue, getValuePercentageForValue, getFormattedThresholds } from './utils';

export function buildGradientColors(
  theme: GrafanaTheme2,
  fieldDisplay: FieldDisplay,
  baseColor = fieldDisplay.display.color ?? FALLBACK_COLOR
): GradientStop[] {
  const colorMode = getFieldColorMode(fieldDisplay.field.color?.mode);

  // thresholds get special handling
  if (colorMode.id === FieldColorModeId.Thresholds) {
    return getFormattedThresholds(
      fieldDisplay.field.decimals ?? DEFAULT_DECIMALS,
      fieldDisplay.field,
      theme,
      false
    ).map((threshold) => {
      const percent = getThresholdPercentageValue(
        threshold,
        fieldDisplay.field.thresholds?.mode ?? ThresholdsMode.Absolute,
        fieldDisplay
      );
      return { color: theme.visualization.getColorByName(threshold.color), percent };
    });
  }

  // Handle continuous color modes before other by-value modes
  if (colorMode.isContinuous && colorMode.getColors) {
    const colors = colorMode.getColors(theme);
    return colors.map((color, idx) => ({ color, percent: idx / (colors.length - 1) }));
  }

  // For value-based colors, we want to stay more true to the specific color,
  // so a radial gradient that adds a bit of light and shade works best
  if (colorMode.isByValue) {
    const darkerColor = tinycolor(baseColor).darken(5);
    const lighterColor = tinycolor(baseColor).spin(20).lighten(10);

    const color1 = theme.isDark ? lighterColor : darkerColor;
    const color2 = theme.isDark ? darkerColor : lighterColor;

    return [
      { color: color1.toString(), percent: 0 },
      { color: color2.toString(), percent: 0.6 },
      { color: color2.toString(), percent: 1 },
    ];
  }

  // For fixed / palette based color scales we can create a more hue and light
  // based linear gradient that we rotate with the value
  const darkerColor = tinycolor(baseColor)
    .spin(-20)
    .darken(theme.isDark ? 15 : 5);
  const lighterColor = tinycolor(baseColor).saturate(20).spin(20).brighten(10).lighten(10);

  const underlyingGradient = [
    { color: theme.isDark ? darkerColor.toString() : lighterColor.toString(), percent: 0 },
    { color: theme.isDark ? lighterColor.toString() : darkerColor.toString(), percent: 1 },
  ];

  // rotate the gradient so that the highest contrasting point is the value, depending on theme.
  const valuePercent = getValuePercentageForValue(fieldDisplay);
  const startColor = theme.isDark
    ? colorAtGradientPercent(underlyingGradient, 1 - valuePercent).toHexString()
    : underlyingGradient[0].color;
  const endColor = theme.isDark
    ? underlyingGradient[1].color
    : colorAtGradientPercent(underlyingGradient, valuePercent).toHexString();
  return [
    { color: startColor, percent: 0 },
    { color: endColor, percent: valuePercent },
    { color: endColor, percent: 1 },
  ];
}

/**
 * get the relevant gradient stops surrounding a given percentage. could be same stop if the
 * percent matches a stop exactly.
 *
 * @param sortedGradientStops - gradient stops sorted by percent
 * @param percent - percentage 0..1
 * @returns {[GradientStop, GradientStop]} - the two gradient stops surrounding the given percentage
 */
export function getGradientStopsForPercent(
  sortedGradientStops: GradientStop[],
  percent: number
): [GradientStop, GradientStop] {
  if (percent <= 0) {
    return [sortedGradientStops[0], sortedGradientStops[0]];
  }
  if (percent >= 1) {
    const last = sortedGradientStops.length - 1;
    return [sortedGradientStops[last], sortedGradientStops[last]];
  }

  // find surrounding stops using binary search
  let lo = 0;
  let hi = sortedGradientStops.length - 1;
  while (lo + 1 < hi) {
    const mid = (lo + hi) >> 1;
    if (percent === sortedGradientStops[mid].percent) {
      return [sortedGradientStops[mid], sortedGradientStops[mid]];
    }

    if (percent < sortedGradientStops[mid].percent) {
      hi = mid;
    } else {
      lo = mid;
    }
  }
  return [sortedGradientStops[lo], sortedGradientStops[hi]];
}

/**
 * @alpha - perhaps this should go in colorManipulator.ts
 * Given color stops (each with a color and percentage 0..1) returns the color at a given percentage.
 * Uses tinycolor.mix for interpolation.
 * @params stops - array of color stops (percentages 0..1)
 * @params percent - percentage 0..1
 * @returns color at the given percentage
 */
export function colorAtGradientPercent(stops: GradientStop[], percent: number): tinycolor.Instance {
  if (!stops || stops.length < 2) {
    throw new Error('colorAtGradientPercent requires at least two color stops');
  }

  const sorted = stops
    .map((s: GradientStop): GradientStop => ({ color: s.color, percent: Math.min(Math.max(0, s.percent), 1) }))
    .sort((a: GradientStop, b: GradientStop) => a.percent - b.percent);

  const [left, right] = getGradientStopsForPercent(sorted, percent);
  const range = right.percent - left.percent;
  const t = range === 0 ? 0 : (percent - left.percent) / range; // 0..1
  return tinycolor.mix(left.color, right.color, t * 100);
}

export function getBarEndcapColors(gradientStops: GradientStop[], percent = 1): [string, string] {
  if (gradientStops.length === 0) {
    throw new Error('getBarEndcapColors requires at least one color stop');
  }

  const startColor = gradientStops[0].color;
  let endColor = gradientStops[gradientStops.length - 1].color;

  // if we have a percentageFilled, use it to get a the correct end color based on where the bar terminates
  if (gradientStops.length >= 2) {
    const endColorByPercentage = colorAtGradientPercent(gradientStops, percent);
    endColor =
      endColorByPercentage.getAlpha() === 1 ? endColorByPercentage.toHexString() : endColorByPercentage.toHex8String();
  }
  return [startColor, endColor];
}

export function getGradientCss(gradientStops: GradientStop[], startAngle: number, endAngle: number): string {
  const range = (endAngle + 360 - startAngle) % 360 || 360;

  const gradientSections = [
    `from ${startAngle}deg`,
    gradientStops.map((stop) => `${stop.color} ${(stop.percent * range).toFixed(2)}deg`).join(', '),
  ];
  if (range !== 360) {
    gradientSections.push(`#0000 0 ${range.toFixed(2)}deg`);
  }

  return `conic-gradient(${gradientSections.join(', ')})`;
}

// the theme does not make the full palette available to us, and we
// don't want transparent colors which our grays usually have.
const GRAY_05 = '#111217';
const GRAY_90 = '#fbfbfb';
const CONTRAST_THRESHOLD_MAX = 4.5;
export const getGuideDotColor = (color: string): string => {
  const darkColor = GRAY_05;
  const lightColor = GRAY_90;
  return colorManipulator.getContrastRatio(darkColor, color) >= CONTRAST_THRESHOLD_MAX ? darkColor : lightColor;
};

export function getEndpointMarkerColors(gradientStops: GradientStop[], percent = 1): [string, string] {
  const [startColor, endColor] = getBarEndcapColors(gradientStops, percent);
  return [getGuideDotColor(startColor), getGuideDotColor(endColor)];
}
