import { type DataFrameView, type FieldDisplay, ThresholdsMode } from '@grafana/data';

import type { RadialGaugeProps } from './RadialGauge';
import { type RadialGaugeDimensions } from './types';
import {
  calculateDimensions,
  toRad,
  getValueAngleForValue,
  drawRadialArcPath,
  getFieldConfigMinMax,
  getFieldDisplayProcessor,
  getAngleBetweenSegments,
  getOptimalSegmentCount,
  getThresholdPercentageValue,
} from './utils';

describe('RadialGauge utils', () => {
  const createFieldDisplay = (value: number, min = 0, max = 100): FieldDisplay => ({
    display: {
      numeric: value,
      text: value.toString(),
      color: 'blue',
    },
    field: {
      min,
      max,
    },
    view: undefined,
    colIndex: 0,
    rowIndex: 0,
    name: 'test',
    getLinks: () => [],
    hasLinks: false,
  });

  describe('getFieldDisplayProcessor', () => {
    it('should return display processor from view when available', () => {
      const mockProcessor = jest.fn();
      const mockView = {
        getFieldDisplayProcessor: jest.fn().mockReturnValue(mockProcessor),
      } as unknown as DataFrameView;

      const fieldDisplay: FieldDisplay = {
        display: { numeric: 50, text: '50', color: 'blue' },
        field: {},
        view: mockView,
        colIndex: 0,
        rowIndex: 0,
        name: 'test',
        getLinks: () => [],
        hasLinks: false,
      };

      const dp = getFieldDisplayProcessor(fieldDisplay);
      expect(dp).toBe(mockProcessor);
      expect(mockView.getFieldDisplayProcessor).toHaveBeenCalledWith(0);
    });

    it('should return default display processor when view is not available', () => {
      const fieldDisplay: FieldDisplay = {
        display: { numeric: 50, text: '50', color: 'blue' },
        field: {},
        view: undefined,
        colIndex: 0,
        rowIndex: 0,
        name: 'test',
        getLinks: () => [],
        hasLinks: false,
      };

      const dp = getFieldDisplayProcessor(fieldDisplay);
      expect(dp).toBeDefined();
      expect(typeof dp).toBe('function');
    });
  });

  describe('getFieldConfigMinMax', () => {
    it('should return min and max from field config when defined', () => {
      const fieldDisplay: FieldDisplay = {
        display: { numeric: 50, text: '50', color: 'blue' },
        field: { min: 10, max: 90 },
        view: undefined,
        colIndex: 0,
        rowIndex: 0,
        name: 'test',
        getLinks: () => [],
        hasLinks: false,
      };

      const [min, max] = getFieldConfigMinMax(fieldDisplay);
      expect(min).toBe(10);
      expect(max).toBe(90);
    });

    it('should return default min and max when not defined in field config', () => {
      const fieldDisplay: FieldDisplay = {
        display: { numeric: 50, text: '50', color: 'blue' },
        field: {},
        view: undefined,
        colIndex: 0,
        rowIndex: 0,
        name: 'test',
        getLinks: () => [],
        hasLinks: false,
      };

      const [min, max] = getFieldConfigMinMax(fieldDisplay);
      expect(min).toBe(0);
      expect(max).toBe(100);
    });

    it('should prevent min and max from being equal', () => {
      const fieldDisplay: FieldDisplay = {
        display: { numeric: 50, text: '50', color: 'blue' },
        field: { min: 10, max: 10 },
        view: undefined,
        colIndex: 0,
        rowIndex: 0,
        name: 'test',
        getLinks: () => [],
        hasLinks: false,
      };

      const [min, max] = getFieldConfigMinMax(fieldDisplay);
      expect(min).not.toBe(max);
    });
  });

  describe('calculateDimensions', () => {
    function calc(overrides: Partial<RadialGaugeProps & { barIndex: number }> = {}) {
      return calculateDimensions(
        overrides.width ?? 200,
        overrides.height ?? 200,
        overrides.shape === 'gauge' ? 110 : 360,
        overrides.glowBar ?? false,
        overrides.roundedBars ?? false,
        overrides.barWidthFactor ?? 0.4,
        overrides.barIndex ?? 0,
        overrides.thresholdsBar ?? false,
        overrides.showScaleLabels ?? false
      );
    }

    it('should calculate basic dimensions for a square gauge', () => {
      const result = calc();

      expect(result).toMatchObject({
        centerX: 100, // width / 2
        centerY: 100, // height / 2
        barWidth: expect.closeTo(13.33, 1),
        radius: expect.closeTo(93.33, 1),
        margin: 0, // no glow
        barIndex: 0,
        thresholdsBarWidth: 0,
        thresholdsBarSpacing: 2,
      });
    });

    it('should handle different aspect ratios', () => {
      const wideGauge = calc({ width: 400, height: 200 });
      const tallGauge = calc({ width: 200, height: 400 });

      expect(wideGauge.centerX).toBe(200);
      expect(wideGauge.centerY).toBe(100);
      expect(tallGauge.centerX).toBe(100);
      expect(tallGauge.centerY).toBe(200);
    });

    it('should apply glow margin when glow is enabled', () => {
      const withoutGlow = calc({ width: 200, height: 200 });
      const withGlow = calc({ width: 200, height: 200, glowBar: true });

      expect(withGlow.margin).toBeGreaterThan(0);
      expect(withoutGlow.margin).toBe(0);
      expect(withGlow.radius).toBeLessThan(withoutGlow.radius); // glow reduces available space
    });

    it('should adjust radius and centerY for rounded bars when endAngle < 180', () => {
      const sharpBars = calc({});
      const roundedCircle = calc({ roundedBars: true, shape: 'circle' });
      const roundedArc = calc({ roundedBars: true, shape: 'gauge' });

      expect(roundedCircle.radius).toEqual(sharpBars.radius);
      expect(roundedArc.radius).toBeLessThan(sharpBars.radius);

      expect(roundedCircle.centerY).toEqual(sharpBars.centerY);
      expect(roundedArc.centerY).not.toEqual(sharpBars.centerY);
    });

    it('should handle threshold bars', () => {
      const withoutThresholds = calc({ width: 200, height: 200 });
      const withThresholds = calc({ width: 200, height: 200, thresholdsBar: true });

      expect(withThresholds.thresholdsBarWidth).toBe(4);
      expect(withThresholds.radius).toBeLessThan(withoutThresholds.radius);
    });

    it('should adjust radius for multiple bars (barIndex > 0)', () => {
      const firstBar = calc({ width: 200, height: 200, barIndex: 0 });
      const secondBar = calc({ width: 200, height: 200, barIndex: 1 });
      const thirdBar = calc({ width: 200, height: 200, barIndex: 2 });

      expect(secondBar.radius).toBeLessThan(firstBar.radius);
      expect(thirdBar.radius).toBeLessThan(secondBar.radius);
      expect(thirdBar.barIndex).toBe(2);
    });

    it('should handle different barWidthFactors', () => {
      const thinBar = calc({ width: 200, height: 200, barWidthFactor: 0.2, barIndex: 0 });
      const thickBar = calc({ width: 200, height: 200, barWidthFactor: 0.8, barIndex: 0 });

      expect(thickBar.barWidth).toBeGreaterThan(thinBar.barWidth);
      expect(thinBar.radius).toBeGreaterThan(thickBar.radius); // thinner bars leave more space
    });

    it('should enforce minimum bar width', () => {
      const result = calc({ width: 50, height: 50, barWidthFactor: 0.01, barIndex: 0 });
      expect(result.barWidth).toBeGreaterThanOrEqual(2);
    });

    it('should optimize space and position for gauge shape', () => {
      const gauge = calc({ width: 200, height: 200, shape: 'gauge', barIndex: 0 });

      // Different end angles should affect the available space differently
      expect(gauge.radius).toBeCloseTo(93.33, 1);
      expect(gauge.centerY).toBeCloseTo(132.89, 1); // centerY can be much lower when shape is a semi circle
    });

    it('should give space for scale labels', () => {
      const gauge = calc({ width: 200, height: 200, shape: 'gauge', showScaleLabels: true, thresholdsBar: true });

      expect(gauge.radius).toBeCloseTo(72, 1);
      expect(gauge.thresholdsBarRadius).toBeCloseTo(82.66, 1);
      expect(gauge.scaleLabelsFontSize).toBeCloseTo(10, 1);
    });
  });

  describe('toRad', () => {
    it('should convert degrees to radians with -90 degree offset', () => {
      expect(toRad(0)).toBeCloseTo(-Math.PI / 2, 5); // 0° becomes -90° in radians
      expect(toRad(90)).toBeCloseTo(0, 5); // 90° becomes 0° in radians
      expect(toRad(180)).toBeCloseTo(Math.PI / 2, 5); // 180° becomes 90° in radians
      expect(toRad(270)).toBeCloseTo(Math.PI, 5); // 270° becomes 180° in radians
    });

    it('should handle negative angles', () => {
      expect(toRad(-90)).toBeCloseTo(-Math.PI, 5);
    });
  });

  describe('getValueAngleForValue', () => {
    it('should calculate angle for value in range', () => {
      const fieldDisplay = createFieldDisplay(50, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360);

      expect(result.startValueAngle).toBe(0);
      expect(result.endValueAngle).toBe(180); // 50% of 360°
      expect(result.angleRange).toBe(360);
    });

    it('should handle different start and end angles', () => {
      const fieldDisplay = createFieldDisplay(50, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 90, 270);

      expect(result.startValueAngle).toBe(0);
      expect(result.endValueAngle).toBe(135); // 50% of 360° range
      expect(result.angleRange).toBe(270);
    });

    it('should clamp angle to maximum range', () => {
      const fieldDisplay = createFieldDisplay(150, 0, 100); // value exceeds max
      const result = getValueAngleForValue(fieldDisplay, 0, 360);

      expect(result.endValueAngle).toBe(360); // clamped to angleRange
    });

    it('should handle minimum values', () => {
      const fieldDisplay = createFieldDisplay(0, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360);

      expect(result.endValueAngle).toBe(0);
    });

    it('should handle maximum values', () => {
      const fieldDisplay = createFieldDisplay(100, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360);

      expect(result.endValueAngle).toBe(360);
    });

    it('should handle values lower than min', () => {
      const fieldDisplay = createFieldDisplay(-50, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 240, 120);

      expect(result.endValueAngle).toBe(0);
    });

    it('should handle values higher than max', () => {
      const fieldDisplay = createFieldDisplay(200, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 240, 120);

      // Expect the angle to be clamped to the maximum range
      expect(result.endValueAngle).toBe(240);
    });

    it('should handle neutral values', () => {
      const fieldDisplay = createFieldDisplay(75, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, 50);

      expect(result.startValueAngle).toBe(180); // Neutral at 50% of 360°
      expect(result.endValueAngle).toBe(90); // 75% - 50% = 25% of 360°
    });

    it('should handle neutral values equal to value', () => {
      const fieldDisplay = createFieldDisplay(50, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, 50);

      expect(result.startValueAngle).toBe(180); // Neutral at 50% of 360°
      expect(result.endValueAngle).toBe(0); // No difference
    });

    it('should handle neutral values greater than value', () => {
      const fieldDisplay = createFieldDisplay(25, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, 150);

      expect(result.startValueAngle).toBe(90);
      expect(result.endValueAngle).toBe(270); // remaining angle to 360
    });

    it('should handle neutral values below range', () => {
      const fieldDisplay = createFieldDisplay(25, 0, 100);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, -50);

      expect(result.startValueAngle).toBe(0);
      expect(result.endValueAngle).toBe(90);
    });

    // Regression for #130075
    // With a neutral point, values outside [min, max] must still produce arcs that fit the gauge.
    it('should clamp overflow above max when neutral is set', () => {
      const fieldDisplay = createFieldDisplay(10, -5, 5);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, 0);

      expect(result.startValueAngle).toBe(180); // neutral at 0
      expect(result.endValueAngle).toBe(180); // fill to max only
    });

    it('should clamp overflow below min when neutral is set', () => {
      const fieldDisplay = createFieldDisplay(-10, -5, 5);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, 0);

      expect(result.startValueAngle).toBe(0); // clamped value at min
      expect(result.endValueAngle).toBe(180); // fill from min to neutral
    });

    // When min === max and both are negative, getFieldConfigMinMax inverts the range.
    // Clamping must use ordered bounds so a constant series still maps to mid-scale.
    it('should keep mid-scale arc when min equals max and both are negative', () => {
      const fieldDisplay = createFieldDisplay(-10, -10, -10);
      const result = getValueAngleForValue(fieldDisplay, 0, 360);

      expect(result.startValueAngle).toBe(0);
      expect(result.endValueAngle).toBe(180);
    });

    it('should keep mid-scale arc with neutral when min equals max and both are negative', () => {
      const fieldDisplay = createFieldDisplay(-10, -10, -10);
      const result = getValueAngleForValue(fieldDisplay, 0, 360, -10);

      expect(result.startValueAngle).toBe(180);
      expect(result.endValueAngle).toBe(0);
    });
  });

  describe('drawRadialArcPath', () => {
    it.each([
      { description: 'quarter arc', startAngle: 0, endAngle: 90 },
      { description: 'half arc', startAngle: 0, endAngle: 180 },
      { description: 'three quarter arc', startAngle: 0, endAngle: 270 },
      { description: 'full circle', startAngle: 0, endAngle: 360 },
      { description: 'narrow radius', startAngle: 0, endAngle: 180, radius: 50 },
      { description: 'with offset', startAngle: 0, endAngle: 90, xOffset: 80, yOffset: 80 },
    ])(`should draw correct path for $description`, ({ startAngle, endAngle, radius = 80, xOffset, yOffset }) => {
      const path = drawRadialArcPath(startAngle, endAngle, radius, xOffset, yOffset);
      expect(path).toMatchSnapshot();
    });

    describe('edge cases', () => {
      it('should adjust 360deg or greater  arcs to avoid SVG rendering issues', () => {
        expect(drawRadialArcPath(0, 360, 80)).toEqual(drawRadialArcPath(0, 359.99, 80));
        // any end angle >360 is clamped to the same 359.99 path
        expect(drawRadialArcPath(0, 380, 80)).toEqual(drawRadialArcPath(0, 359.99, 80));
      });
    });
  });

  describe('getAngleBetweenSegments', () => {
    it('should calculate angle between segments based on spacing and count', () => {
      expect(getAngleBetweenSegments(2, 10, 360)).toBe(48);
      expect(getAngleBetweenSegments(5, 15, 180)).toBe(40);
    });
  });

  describe('getOptimalSegmentCount', () => {
    it('should adjust segment count based on dimensions and spacing', () => {
      const dimensions = {
        vizHeight: 220,
        vizWidth: 220,
        centerX: 100,
        centerY: 100,
        radius: 80,
        barWidth: 20,
        margin: 0,
        barIndex: 0,
        thresholdsBarWidth: 0,
        thresholdsBarSpacing: 0,
        thresholdsBarRadius: 0,
        scaleLabelsFontSize: 0,
        scaleLabelsSpacing: 0,
        scaleLabelsRadius: 0,
        gaugeBottomY: 0,
      } satisfies RadialGaugeDimensions;

      expect(getOptimalSegmentCount(dimensions, 2, 10, 360)).toBe(8);
      expect(getOptimalSegmentCount(dimensions, 1, 5, 360)).toBe(5);
    });
  });

  describe('getThresholdPercentageValue', () => {
    it('should return the correct percentage for absolute thresholds', () => {
      const threshold = { value: 75, label: 'Warning', color: '#fff' };
      const fieldDisplay = createFieldDisplay(75, 0, 200);
      const result = getThresholdPercentageValue(threshold, ThresholdsMode.Absolute, fieldDisplay);
      expect(result).toBe(0.375);
    });

    it('should return the correct percentage for percentage thresholds', () => {
      const threshold = { value: 75, label: 'Warning', color: '#fff' };
      const fieldDisplay = createFieldDisplay(75, 0, 50);
      const result = getThresholdPercentageValue(threshold, ThresholdsMode.Percentage, fieldDisplay);
      expect(result).toBe(0.75);
    });
  });
});
