import { css, cx } from '@emotion/css';
import {
  type ReactElement,
  useCallback,
  useState,
  useRef,
  useImperativeHandle,
  type CSSProperties,
  type AriaRole,
} from 'react';
import * as React from 'react';

import { type GrafanaTheme2, type LinkTarget } from '@grafana/data';
import { t } from '@grafana/i18n';

import { useStyles2 } from '../../themes/ThemeContext';
import { getFocusStyles, getInternalRadius } from '../../themes/mixins';
import { type IconName } from '../../types/icon';
import { Icon } from '../Icon/Icon';
import { Stack } from '../Layout/Stack/Stack';

import { SubMenu } from './SubMenu';

/** @internal */
export type MenuItemElement = HTMLAnchorElement & HTMLButtonElement & HTMLDivElement;

/** @internal */
export interface MenuItemProps<T = unknown> {
  /** Label of the menu item */
  label: string;
  /** Description of item */
  description?: string;
  /** Aria label for accessibility support */
  ariaLabel?: string;
  /** Aria checked for accessibility support */
  ariaChecked?: boolean;
  /** Target of the menu item (i.e. new window)  */
  target?: LinkTarget;
  /** Icon of the menu item */
  icon?: IconName;
  /** Role of the menu item */
  role?: AriaRole;
  /** Url of the menu item */
  url?: string;
  /** Handler for the click behaviour */
  onClick?: (event: React.MouseEvent<HTMLElement>, payload?: T) => void;
  /** Custom MenuItem styles*/
  className?: string;
  /** Active */
  active?: boolean;
  /** Disabled */
  disabled?: boolean;
  /** Show in destructive style (error color) */
  destructive?: boolean;
  tabIndex?: number;
  /** List of menu items for the subMenu */
  childItems?: Array<ReactElement<MenuItemProps>>;
  /** Custom style for SubMenu */
  customSubMenuContainerStyles?: CSSProperties;
  /** Shortcut key combination */
  shortcut?: string;
  /** Test id for e2e tests and fullstory*/
  testId?: string;
  /** CSS color for the icon. Ignored when `destructive` or `disabled` is true. */
  iconColor?: string;
  /* Optional component that will be shown together with other options. Does not get passed any props. */
  component?: React.ComponentType;
}

/** @internal */
export const MenuItem = React.memo(
  React.forwardRef<MenuItemElement, MenuItemProps>((props, ref) => {
    const {
      url,
      icon,
      label,
      description,
      ariaLabel,
      ariaChecked,
      target,
      onClick,
      className,
      active,
      disabled,
      destructive,
      childItems,
      role,
      tabIndex = -1,
      customSubMenuContainerStyles,
      shortcut,
      testId,
      iconColor,
    } = props;
    const styles = useStyles2(getStyles);
    // Ignore iconColor when destructive or disabled — those states own the colors.
    const resolvedIconColor = iconColor && !destructive && !disabled ? iconColor : undefined;
    const [isActive, setIsActive] = useState(active);
    const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);
    const onMouseEnter = useCallback(() => {
      if (disabled) {
        return;
      }

      setIsSubMenuOpen(true);
      setIsActive(true);
    }, [disabled]);
    const onMouseLeave = useCallback(() => {
      if (disabled) {
        return;
      }

      setIsSubMenuOpen(false);
      setIsActive(false);
    }, [disabled]);

    const hasSubMenu = childItems && childItems.length > 0;
    const ItemElement = hasSubMenu ? 'div' : url === undefined ? 'button' : 'a';
    const itemStyle = cx(
      {
        [styles.item]: true,
        [styles.active]: isActive,
        [styles.disabled]: disabled,
        [styles.destructive]: destructive && !disabled,
      },
      className
    );

    const disabledProps = {
      [ItemElement === 'button' ? 'disabled' : 'aria-disabled']: disabled,
      ...(ItemElement === 'a' && disabled && { href: undefined, onClick: undefined }),
      ...(disabled && {
        tabIndex: -1,
        ['data-disabled']: disabled, // used to identify disabled items in Menu.tsx
      }),
    };

    const localRef = useRef<MenuItemElement>(null);
    useImperativeHandle(ref, () => localRef.current!);

    const handleKeys = (event: React.KeyboardEvent) => {
      switch (event.key) {
        case ' ':
          if (ItemElement === 'a' && url) {
            event.preventDefault();
            localRef.current?.click();
          }
          if (hasSubMenu && !isSubMenuOpen) {
            event.preventDefault();
            event.stopPropagation();
            setIsSubMenuOpen(true);
            setIsActive(true);
            return;
          }
          break;
        case 'ArrowRight':
          event.preventDefault();
          event.stopPropagation();
          if (hasSubMenu) {
            setIsSubMenuOpen(true);
            setIsActive(true);
          }
          break;
        case 'Enter':
          if (hasSubMenu && !isSubMenuOpen) {
            event.preventDefault();
            event.stopPropagation();
            setIsSubMenuOpen(true);
            setIsActive(true);
            return;
          }
          break;
        default:
          break;
      }
    };

    const closeSubMenu = () => {
      setIsSubMenuOpen(false);
      setIsActive(false);
      localRef?.current?.focus();
    };

    const hasShortcut = Boolean(shortcut && shortcut.length > 0);

    return (
      <ItemElement
        target={target}
        className={itemStyle}
        rel={target === '_blank' ? 'noopener noreferrer' : undefined}
        href={url}
        onClick={(event) => {
          if (hasSubMenu && !isSubMenuOpen) {
            event.preventDefault();
            event.stopPropagation();
          }
          onClick?.(event);
        }}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onKeyDown={handleKeys}
        // Default to menuitem for all items (links and buttons) so screen readers announce
        // position correctly (e.g. "X of Y") and the menu has proper ARIA semantics.
        // Callers can override via the role prop.
        role={role ?? 'menuitem'}
        data-role="menuitem" // used to identify menuitem in Menu.tsx
        ref={localRef}
        data-testid={testId}
        aria-label={ariaLabel}
        aria-checked={ariaChecked}
        // Announce to screen readers that this item opens a submenu, and whether it is
        // currently expanded, so nested items (e.g. under "More...") are discoverable.
        aria-haspopup={hasSubMenu ? 'menu' : undefined}
        aria-expanded={hasSubMenu ? isSubMenuOpen : undefined}
        tabIndex={tabIndex}
        {...disabledProps}
      >
        <Stack direction="row" justifyContent="flex-start" alignItems="center">
          {icon && (
            <Icon
              name={icon}
              className={cx(styles.icon, resolvedIconColor && css({ color: resolvedIconColor }))}
              aria-hidden
            />
          )}
          <span className={cx(styles.ellipsis, styles.label)}>{label}</span>
          <div className={cx(styles.rightWrapper, { [styles.withShortcut]: hasShortcut })}>
            {hasShortcut && (
              <div className={styles.shortcut}>
                <Icon name="keyboard" title={t('grafana-ui.menu-item.keyboard-shortcut-label', 'Keyboard shortcut')} />
                {shortcut}
              </div>
            )}
            {hasSubMenu && (
              <SubMenu
                parentItemRef={localRef}
                items={childItems}
                isOpen={isSubMenuOpen}
                close={closeSubMenu}
                customStyle={customSubMenuContainerStyles}
              />
            )}
          </div>
        </Stack>
        {description && (
          <div
            className={cx(styles.description, styles.ellipsis, {
              [styles.descriptionWithIcon]: icon !== undefined,
            })}
          >
            {description}
          </div>
        )}
        {props.component ? <props.component /> : null}
      </ItemElement>
    );
  })
);

MenuItem.displayName = 'MenuItem';

const getStyles = (theme: GrafanaTheme2) => {
  const visualRefreshEnabled = theme.flags.visualDesignRefresh;
  const menuPadding = theme.components.menu.padding * theme.spacing.gridSize;

  return {
    item: css({
      background: 'none',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      color: visualRefreshEnabled ? theme.colors.text.primary : theme.colors.text.secondary,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'stretch',
      justifyContent: 'center',
      padding: theme.spacing(0.5, 1.5),
      minHeight: theme.spacing(4),
      borderRadius: getInternalRadius(theme, menuPadding, { parentBorderWidth: 0, parentBorderRadius: 'lg' }),
      margin: 0,
      border: 'none',
      width: '100%',
      position: 'relative',

      '&:hover, &:focus-visible': {
        background: theme.colors.action.hover,
        color: visualRefreshEnabled ? theme.colors.text.maxContrast : theme.colors.text.primary,
        textDecoration: 'none',
      },

      '&:focus-visible': getFocusStyles(theme),
    }),
    label: css(
      !visualRefreshEnabled && {
        color: theme.colors.text.primary,
      }
    ),
    active: css({
      background: theme.colors.action.hover,
      // needed to show active items in forced colors mode
      '@media (forced-colors: active)': {
        outline: '1px solid transparent',
      },
    }),
    destructive: css(
      {
        color: theme.colors.error.text,

        svg: {
          color: theme.colors.error.text,
        },

        '&:hover, &:focus, &:focus-visible': {
          background: theme.colors.error.main,
          color: theme.colors.error.contrastText,

          svg: {
            color: theme.colors.error.contrastText,
          },
        },
      },
      visualRefreshEnabled && {
        '&:hover, &:focus, &:focus-visible': {
          background: theme.colors.error.backgroundEmphasis,
          color: theme.colors.error.textEmphasis,

          svg: {
            color: theme.colors.error.textEmphasis,
          },
        },
      }
    ),
    disabled: css({
      color: theme.colors.action.disabledText,
      label: 'menu-item-disabled',
      '&:hover, &:focus, &:focus-visible': {
        cursor: 'not-allowed',
        background: 'none',
        color: theme.colors.action.disabledText,
      },
    }),
    icon: css({
      opacity: 0.7,
    }),
    rightWrapper: css({
      display: 'flex',
      alignItems: 'center',
      marginLeft: 'auto',
    }),
    withShortcut: css({
      minWidth: theme.spacing(10.5),
    }),
    shortcut: css({
      display: 'flex',
      alignItems: 'center',
      gap: theme.spacing(1),
      marginLeft: theme.spacing(2),
    }),
    description: css({
      ...theme.typography.bodySmall,
      textAlign: 'start',
    }),
    descriptionWithIcon: css({
      marginLeft: theme.spacing(3),
    }),
    ellipsis: css({
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
    }),
  };
};
