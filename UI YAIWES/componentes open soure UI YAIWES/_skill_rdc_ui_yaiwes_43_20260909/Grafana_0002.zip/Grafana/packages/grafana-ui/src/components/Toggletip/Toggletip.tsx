import { css, cx } from '@emotion/css';
import {
  arrow,
  autoUpdate,
  FloatingArrow,
  FloatingFocusManager,
  offset,
  useClick,
  useDismiss,
  useFloating,
  useInteractions,
} from '@floating-ui/react';
import { type Placement } from '@popperjs/core';
import { memo, cloneElement, isValidElement, useRef, useState, type JSX } from 'react';

import { type GrafanaTheme2 } from '@grafana/data';
import { t } from '@grafana/i18n';

import { useStyles2 } from '../../themes/ThemeContext';
import { getPositioningMiddleware } from '../../utils/floating';
import { buildTooltipTheme, getPlacement } from '../../utils/tooltipUtils';
import { IconButton } from '../IconButton/IconButton';
import { getPortalContainer, Portal } from '../Portal/Portal';

import { type ToggletipContent } from './types';

export interface ToggletipProps {
  /** The theme used to display the toggletip */
  theme?: 'info' | 'error';
  /** The title to be displayed on the header */
  title?: JSX.Element | string;
  /** determine whether to show or not the close button **/
  closeButton?: boolean;
  /** Callback function to be called when the toggletip is closed */
  onClose?: () => void;
  /** The preferred placement of the toggletip */
  placement?: Placement;
  /** The text or component that houses the content of the toggleltip */
  content: ToggletipContent;
  /** The text or component to be displayed on the toggletip's bottom */
  footer?: JSX.Element | string;
  /** The UI control users interact with to display toggletips */
  children: JSX.Element;
  /** Determine whether the toggletip should fit its content or not */
  fitContent?: boolean;
  /** Determine whether the toggletip should be shown or not */
  show?: boolean;
  /** Callback function to be called when the toggletip is opened */
  onOpen?: () => void;
  /** Dismiss the toggletip when an ancestor element is scrolled */
  dismissOnScroll?: boolean;
}

/**
 * Toggletips, similar to Tooltips, provide contextual support for users when needed. They are hidden by default, a UI trigger or text link are clicked to set them to their visible state. Toggletips, unlike tooltips, are persistent until a user takes action to dismiss them by clicking on the required “X” (close) trigger. Toggletips are capable of containing varying types of complex content including interactive components, buttons, and dropdowns.
 *
 * https://developers.grafana.com/ui/latest/index.html?path=/docs/overlays-toggletip--docs
 */
export const Toggletip = memo(
  ({
    children,
    theme = 'info',
    placement = 'auto',
    content,
    title,
    closeButton = true,
    onClose,
    footer,
    fitContent = false,
    onOpen,
    show,
    dismissOnScroll = false,
  }: ToggletipProps) => {
    const arrowRef = useRef(null);
    const styles = useStyles2(getStyles);
    const style = styles[theme];
    const [controlledVisible, setControlledVisible] = useState(show);
    const isOpen = show ?? controlledVisible;
    const floatingUIPlacement = getPlacement(placement);

    // the order of middleware is important!
    // `arrow` should almost always be at the end
    // see https://floating-ui.com/docs/arrow#order
    const middleware = [
      offset(8),
      ...getPositioningMiddleware(floatingUIPlacement),
      arrow({
        element: arrowRef,
        padding: 12,
      }),
    ];

    const { context, refs, floatingStyles } = useFloating({
      open: isOpen,
      placement: floatingUIPlacement,
      onOpenChange: (open) => {
        if (show === undefined) {
          setControlledVisible(open);
        }
        if (!open) {
          onClose?.();
        } else {
          onOpen?.();
        }
      },
      middleware,
      whileElementsMounted: autoUpdate,
      strategy: 'fixed',
    });

    const click = useClick(context);
    const dismiss = useDismiss(context, { ancestorScroll: dismissOnScroll });

    const { getReferenceProps, getFloatingProps } = useInteractions([dismiss, click]);

    return (
      <>
        {cloneElement(children, {
          ref: refs.setReference,
          tabIndex: 0,
          'aria-expanded': isOpen,
          ...getReferenceProps(),
        })}
        {isOpen && (
          <Portal>
            <FloatingFocusManager context={context} modal={true} getInsideElements={() => [getPortalContainer()]}>
              <div
                data-testid="toggletip-content"
                className={cx(style.container, {
                  [styles.fitContent]: fitContent,
                })}
                ref={refs.setFloating}
                style={floatingStyles}
                {...getFloatingProps()}
              >
                <FloatingArrow
                  strokeWidth={0.3}
                  stroke={style.borderColor}
                  width={8}
                  height={4}
                  tipRadius={2}
                  className={style.arrow}
                  ref={arrowRef}
                  context={context}
                />
                {Boolean(title) && <div className={style.header}>{title}</div>}
                {closeButton && (
                  <div className={style.headerClose}>
                    <IconButton
                      aria-label={t('grafana-ui.toggletip.close', 'Close')}
                      name="times"
                      data-testid="toggletip-header-close"
                      onClick={() => {
                        setControlledVisible(false);
                        onClose?.();
                      }}
                    />
                  </div>
                )}
                <div className={style.body}>
                  {(typeof content === 'string' || isValidElement(content)) && content}
                  {typeof content === 'function' && content({})}
                </div>
                {Boolean(footer) && <div className={style.footer}>{footer}</div>}
              </div>
            </FloatingFocusManager>
          </Portal>
        )}
      </>
    );
  }
);

Toggletip.displayName = 'Toggletip';

const getStyles = (theme: GrafanaTheme2) => {
  const visualRefreshEnabled = theme.flags.visualDesignRefresh;
  const info = buildTooltipTheme(
    theme,
    theme.colors.background.primary,
    theme.colors.border.weak,
    theme.components.tooltip.text,
    { topBottom: 2, rightLeft: 2 }
  );
  const error = buildTooltipTheme(
    theme,
    theme.colors.error[visualRefreshEnabled ? 'background' : 'main'],
    theme.colors.error[visualRefreshEnabled ? 'border' : 'main'],
    theme.colors.error[visualRefreshEnabled ? 'text' : 'contrastText'],
    { topBottom: 2, rightLeft: 2 }
  );

  return {
    info,
    error,
    fitContent: css({
      maxWidth: 'fit-content',
    }),
  };
};
