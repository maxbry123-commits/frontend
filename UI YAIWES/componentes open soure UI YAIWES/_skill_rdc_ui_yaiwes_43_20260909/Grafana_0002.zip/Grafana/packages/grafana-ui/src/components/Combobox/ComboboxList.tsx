import { cx } from '@emotion/css';
import { useVirtualizer } from '@tanstack/react-virtual';
import type { UseComboboxPropGetters } from 'downshift';
import { useCallback } from 'react';

import { useStyles2 } from '../../themes/ThemeContext';
import { Checkbox } from '../Forms/Checkbox';
import { Icon } from '../Icon/Icon';
import { Stack } from '../Layout/Stack/Stack';
import { ScrollContainer } from '../ScrollContainer/ScrollContainer';

import { AsyncError, LoadingOptions, NotFoundError } from './MessageRows';
import {
  getComboboxStyles,
  MENU_OPTION_HEIGHT,
  MENU_OPTION_HEIGHT_DESCRIPTION,
  MENU_PADDING,
} from './getComboboxStyles';
import { ALL_OPTION_VALUE, type ComboboxOption } from './types';
import { isNewGroup } from './utils';

const VIRTUAL_OVERSCAN_ITEMS = 4;

interface ComboboxListProps<T extends string | number> {
  options: Array<ComboboxOption<T>>;
  highlightedIndex: number | null;
  /** Whether the highlighted option should show a focus ring, rather than just the muted highlight */
  showFocusRing?: boolean;
  selectedItems?: Array<ComboboxOption<T>>;
  scrollRef: React.RefObject<HTMLDivElement | null>;
  getItemProps: UseComboboxPropGetters<ComboboxOption<T>>['getItemProps'];
  enableAllOption?: boolean;
  isMultiSelect?: boolean;
  noOptionsMessage?: string;
  error?: boolean;
  loading?: boolean;
}

export const ComboboxList = <T extends string | number>({
  options,
  highlightedIndex,
  showFocusRing = false,
  selectedItems = [],
  scrollRef,
  getItemProps,
  enableAllOption,
  isMultiSelect = false,
  error = false,
  loading = false,
  noOptionsMessage,
}: ComboboxListProps<T>) => {
  const styles = useStyles2(getComboboxStyles);

  const estimateSize = useCallback(
    (index: number) => {
      const firstGroupItem = isNewGroup(options[index], index > 0 ? options[index - 1] : undefined);
      const hasDescription = 'description' in options[index];
      const hasGroup = 'group' in options[index];

      let itemHeight = MENU_OPTION_HEIGHT;
      if (hasDescription) {
        itemHeight = MENU_OPTION_HEIGHT_DESCRIPTION;
      }
      if (firstGroupItem && hasGroup) {
        itemHeight += MENU_OPTION_HEIGHT;
      }
      return itemHeight;
    },
    [options]
  );

  const rowVirtualizer = useVirtualizer({
    count: options.length,
    getScrollElement: () => scrollRef.current,
    estimateSize,
    getItemKey: (index: number) => options[index]?.value ?? index,
    overscan: VIRTUAL_OVERSCAN_ITEMS,
    // Vertical padding belongs to the virtualizer rather than CSS so that row offsets, the total
    // size and scrollToIndex all account for it. Padding it in CSS instead would shift every row
    // down without the virtualizer knowing, and scrolling would stop short of the focus ring.
    paddingStart: MENU_PADDING,
    paddingEnd: MENU_PADDING,
  });

  const isOptionSelected = useCallback(
    (item: ComboboxOption<T>) => selectedItems.some((opt) => opt.value === item.value),
    [selectedItems]
  );

  const allItemsSelected = enableAllOption && options.length > 1 && selectedItems.length === options.length - 1;

  return (
    <ScrollContainer showScrollIndicators maxHeight="inherit" ref={scrollRef}>
      <div style={{ height: rowVirtualizer.getTotalSize() }} className={styles.menuUlContainer}>
        {rowVirtualizer.getVirtualItems().map((virtualRow, index, allVirtualRows) => {
          const item = options[virtualRow.index];
          const startingNewGroup = isNewGroup(item, options[virtualRow.index - 1]);
          const isHighlighted = highlightedIndex === virtualRow.index && !item.infoOption;

          // Find the item that renders the group header. It can be this same item if this is rendering it.
          const groupHeaderIndex = allVirtualRows.find((row) => {
            const rowItem = options[row.index];
            return rowItem.group === item.group;
          });
          const groupHeaderItem = groupHeaderIndex && options[groupHeaderIndex.index];

          const itemId = `combobox-option-${item.value}`;
          // If we're rendering the group header, this is the ID for it. Otherwise its used on
          // the option for aria-describedby.
          const groupHeaderId = groupHeaderItem ? `combobox-option-group-${groupHeaderItem.value}` : undefined;

          return (
            // Wrapping div should have no styling other than virtual list positioning.
            // It's children (header and option) should appear as flat list items.
            <div
              key={item.value}
              className={styles.listItem}
              style={{
                height: virtualRow.size,
                transform: `translateY(${virtualRow.start}px)`,
              }}
            >
              {/* Group header */}
              {startingNewGroup && (
                <div
                  role="presentation"
                  data-testid="combobox-option-group"
                  id={groupHeaderId}
                  className={cx(
                    styles.optionGroupHeader,
                    item.group && styles.optionGroupLabel,
                    virtualRow.index === 0 && styles.optionFirstGroupHeader
                  )}
                >
                  {item.group}
                </div>
              )}

              {/* Option */}
              <div
                className={cx(
                  styles.option,
                  !isMultiSelect && isOptionSelected(item) && styles.optionSelected,
                  isHighlighted && styles.optionFocused,
                  isHighlighted && showFocusRing && styles.optionFocusRing,
                  item.infoOption && styles.optionInfo
                )}
                {...getItemProps({
                  item: item,
                  index: virtualRow.index,
                  id: itemId,
                  'aria-describedby': groupHeaderId,
                })}
              >
                {isMultiSelect && (
                  <div className={styles.optionAccessory}>
                    {!item.infoOption && (
                      <Checkbox
                        key={itemId}
                        value={allItemsSelected || isOptionSelected(item)}
                        indeterminate={item.value === ALL_OPTION_VALUE && selectedItems.length > 0 && !allItemsSelected}
                        aria-labelledby={itemId}
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        data-testid={`${itemId}-checkbox`}
                      />
                    )}
                  </div>
                )}

                <div className={styles.optionBody}>
                  <Stack direction="row" alignItems="center">
                    {item.icon && <Icon name={item.icon} />}
                    <div className={styles.optionLabel}>{item.label ?? item.value}</div>
                  </Stack>

                  {item.description && <div className={styles.optionDescription}>{item.description}</div>}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div aria-live="polite">
        {error && <AsyncError />}
        {!loading && options.length === 0 && !error && <NotFoundError message={noOptionsMessage} />}
        {loading && options.length === 0 && <LoadingOptions />}
      </div>
    </ScrollContainer>
  );
};
