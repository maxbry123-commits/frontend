import { css, cx } from '@emotion/css';
import { forwardRef, type HTMLProps } from 'react';

import { type GrafanaTheme2 } from '@grafana/data';

import { useStyles2 } from '../../themes/ThemeContext';
import { useFieldContext } from '../Forms/FieldContext';
import { getFocusStyle, sharedInputStyle } from '../Forms/commonStyles';

export interface Props extends Omit<HTMLProps<HTMLTextAreaElement>, 'size'> {
  /** Show an invalid state around the input */
  invalid?: boolean;
}

/**
 * Use for multi line inputs like descriptions.
 *
 * https://developers.grafana.com/ui/latest/index.html?path=/docs/inputs-textarea--docs
 */
export const TextArea = forwardRef<HTMLTextAreaElement, Props>(
  (
    {
      'aria-describedby': ariaDescribedByProp,
      disabled: disabledProp,
      invalid: invalidProp,
      id: idProp,
      className,
      ...props
    },
    ref
  ) => {
    const fieldContext = useFieldContext();
    const invalid = invalidProp ?? fieldContext.invalid;
    const id = idProp ?? fieldContext.id;
    const disabled = disabledProp ?? fieldContext.disabled;
    const ariaDescribedBy = ariaDescribedByProp ?? fieldContext['aria-describedby'];
    const styles = useStyles2(getTextAreaStyle, invalid);

    return (
      <textarea
        {...props}
        id={id}
        disabled={disabled}
        aria-describedby={ariaDescribedBy}
        className={cx(styles.textarea, className)}
        ref={ref}
      />
    );
  }
);

const getTextAreaStyle = (theme: GrafanaTheme2, invalid = false) => ({
  textarea: cx(
    sharedInputStyle(theme),
    getFocusStyle(theme),
    css({
      display: 'block',
      borderRadius: theme.shape.radius.default,
      padding: `${theme.spacing.gridSize / 4}px ${theme.spacing.gridSize}px`,
      width: '100%',
      borderColor: invalid ? theme.colors.error.border : theme.components.input.borderColor,
    })
  ),
});

TextArea.displayName = 'TextArea';
