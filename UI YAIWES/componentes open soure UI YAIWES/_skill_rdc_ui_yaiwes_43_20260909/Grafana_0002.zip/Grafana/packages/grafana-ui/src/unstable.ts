/**
 * THESE COMPONENTS MUST NOT BE USED EXTERNALLY OR IN PLUGINS.
 *
 * Unstable components are still in development and are subject to breaking changes
 * at any point, like feature flags but for components. They must only be used in
 * Grafana core where we can coordinate changes.
 *
 * Once mature, they will be moved to the main export, be available to plugins, and
 * be subject to the standard policies
 */

export * from './utils/skeleton';

export { CodeMirrorEditor } from './components/CodeMirror/CodeEditorLazy';
export { signatureHelp } from './components/CodeMirror/signatureHelp';
export type { SignatureHelpOptions } from './components/CodeMirror/signatureHelp';
export { applyVariableReference, createVariableCompletionSource } from './components/CodeMirror/variableCompletion';
export type { VariableCompletionDisplay, VariableCompletionOptions } from './components/CodeMirror/variableCompletion';
export type {
  CodeMirrorBasicSetup,
  CodeMirrorCompletion,
  CodeMirrorCompletionContext,
  CodeMirrorCompletionMode,
  CodeMirrorCompletionResult,
  CodeMirrorCompletionSource,
  CodeMirrorEditorLanguage,
  CodeMirrorEditorProps,
  CodeMirrorEditorTheme,
  CodeMirrorExtension,
  CodeMirrorSqlDialect,
  SignatureHelp,
  SignatureHelpProvider,
  SignatureInformation,
  SignatureParameter,
} from './components/CodeMirror/types';
export { getQueryFieldConfig } from './components/QueryFieldConfig/queryFieldConfig';
export type { QueryFieldConfig, QueryFieldConfigOptions } from './components/QueryFieldConfig/queryFieldConfig';
export { TableNG } from './components/Table/TableNG/TableNG';
