import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent, { type UserEvent } from '@testing-library/user-event';
import React from 'react';

import { mockComboboxRect } from '../../test-utils/mockDom';
import { Drawer } from '../Drawer/Drawer';
import { Modal } from '../Modal/Modal';

import { MultiCombobox, type MultiComboboxProps } from './MultiCombobox';
import { type ComboboxOption } from './types';
import { DEBOUNCE_TIME_MS } from './useOptions';

describe('MultiCombobox', () => {
  beforeAll(() => {
    mockComboboxRect();
  });

  let user: UserEvent;

  beforeEach(() => {
    user = userEvent.setup();
  });

  it('keeps the caret position when typing in the middle of the input', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];

    render(<MultiCombobox options={options} value={[]} onChange={jest.fn()} />);
    const input = screen.getByRole<HTMLInputElement>('combobox');

    await user.click(input);
    await user.type(input, 'hello');

    input.setSelectionRange(3, 3);

    await user.keyboard('X');

    expect(input).toHaveValue('helXlo');
    expect(input.selectionStart).toBe(4);
    expect(input.selectionEnd).toBe(4);
  });

  it('should render with options', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    render(<MultiCombobox options={options} value={[]} onChange={jest.fn()} />);
    const input = screen.getByRole('combobox');
    user.click(input);
    expect(await screen.findByText('A')).toBeInTheDocument();
    expect(screen.getByText('B')).toBeInTheDocument();
    expect(screen.getByText('C')).toBeInTheDocument();
  });

  it('should render with value', () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    render(<MultiCombobox options={options} value={['a']} onChange={jest.fn()} />);
    expect(screen.getByText('A')).toBeInTheDocument();
  });

  it('should render with placeholder', () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    render(<MultiCombobox options={options} value={[]} onChange={jest.fn()} placeholder="Select" />);
    expect(screen.getByPlaceholderText('Select')).toBeInTheDocument();
  });

  it('should not render with placeholder when options selected', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    render(<MultiCombobox options={options} value={['a']} onChange={jest.fn()} placeholder="Select" />);
    const input = screen.getByRole('combobox');
    expect(input).toHaveAttribute('placeholder', '');
  });

  it.each([
    ['a', 'b', 'c'],
    [1, 2, 3],
  ])('should call onChange with the correct values', async (first, second, third) => {
    const options = [
      { label: 'A', value: first },
      { label: 'B', value: second },
      { label: 'C', value: third },
    ];
    const onChange = jest.fn();

    const ControlledMultiCombobox = (props: MultiComboboxProps<string | number>) => {
      const [value, setValue] = React.useState<string[] | number[]>([]);
      return (
        <MultiCombobox
          {...props}
          value={value}
          onChange={(val) => {
            //@ts-expect-error Don't do this for real life use cases
            setValue(val ?? []);
            onChange(val);
          }}
        />
      );
    };

    render(<ControlledMultiCombobox options={options} value={[]} onChange={onChange} />);
    const input = screen.getByRole('combobox');
    await user.click(input);
    await user.click(await screen.findByRole('option', { name: 'A' }));

    // Second option
    await user.click(screen.getByRole('option', { name: 'C' }));

    // Deselect
    await user.click(screen.getByRole('option', { name: 'A' }));

    expect(onChange).toHaveBeenNthCalledWith(1, [{ label: 'A', value: first }]);
    expect(onChange).toHaveBeenNthCalledWith(2, [
      { label: 'A', value: first },
      { label: 'C', value: third },
    ]);
    expect(onChange).toHaveBeenNthCalledWith(3, [{ label: 'C', value: third }]);
  });

  it('should allow for options to be deselected', async () => {
    // This test ensures that our fix for async options doesn't break sync options
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    const onChange = jest.fn();

    const ControlledMultiCombobox = (props: MultiComboboxProps<string>) => {
      const [value, setValue] = React.useState<string[]>(['a']);
      return (
        <MultiCombobox
          {...props}
          value={value}
          onChange={(val) => {
            setValue(val.map((v) => v.value));
            onChange(val);
          }}
        />
      );
    };

    render(<ControlledMultiCombobox options={options} value={[]} onChange={onChange} />);
    const input = screen.getByRole('combobox');
    await user.click(input);

    // Click on option A to deselect it (it should be selected initially)
    await user.click(await screen.findByRole('option', { name: 'A' }));

    expect(onChange).toHaveBeenCalledWith([]);
  });

  it('should be able to render a value that is not in the options', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    render(<MultiCombobox width={200} options={options} value={['a', 'd', 'c']} onChange={jest.fn()} />);
    await user.click(screen.getByRole('combobox'));
    expect(await screen.findByText('d')).toBeInTheDocument();
  });

  it('should be able to set custom value', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    const onChange = jest.fn();
    render(<MultiCombobox options={options} value={[]} onChange={onChange} createCustomValue />);
    const input = screen.getByRole('combobox');
    await user.click(input);
    await user.type(input, 'D');
    await user.keyboard('{arrowdown}{enter}');
    expect(onChange).toHaveBeenCalledWith([{ label: 'D', value: 'D', description: 'Use custom value' }]);
  });

  it('should be able to add custom value to the selected options', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    const onChange = jest.fn();
    render(<MultiCombobox options={options} value={['a', 'c']} onChange={onChange} createCustomValue />);
    const input = screen.getByRole('combobox');
    await user.click(input);
    await user.type(input, 'D');
    await user.keyboard('{arrowdown}{enter}');
    expect(onChange).toHaveBeenCalledWith([
      { label: 'A', value: 'a' },
      { label: 'C', value: 'c' },
      { label: 'D', value: 'D', description: 'Use custom value' },
    ]);
  });

  it('should remove value when clicking on the close icon of the pill', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    const onChange = jest.fn();
    render(<MultiCombobox width={200} options={options} value={['a', 'b', 'c']} onChange={onChange} />);
    const fistPillRemoveButton = await screen.findByRole('button', { name: 'Remove A' });
    await user.click(fistPillRemoveButton);
    expect(onChange).toHaveBeenCalledWith(options.filter((o) => o.value !== 'a'));
  });

  it('should remove value when clicking on the close icon of the pill when pills are collapsed due to width constraint', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
      { label: 'D', value: 'd' },
    ];
    const onChange = jest.fn();
    render(<MultiCombobox width={40} options={options} value={['a', 'b', 'c', 'd']} onChange={onChange} />);
    const input = screen.getByRole('combobox');
    await user.click(input);
    const removeButton = await screen.findByRole('button', { name: 'Remove D' });
    await user.click(removeButton);
    expect(onChange).toHaveBeenCalledWith(options.filter((o) => o.value !== 'd'));
  });

  it('should remove all selected items when clicking on clear all button', async () => {
    const options = [
      { label: 'A', value: 'a' },
      { label: 'B', value: 'b' },
      { label: 'C', value: 'c' },
    ];
    const onChange = jest.fn();
    render(<MultiCombobox width={200} options={options} value={['a', 'b', 'c']} onChange={onChange} isClearable />);
    const clearAllButton = await screen.findByTitle('Clear all');
    await user.click(clearAllButton);
    expect(onChange).toHaveBeenCalledWith([]);
  });

  it('should open the menu when clicking the toggle button', async () => {
    const options = [
      { label: 'Option 1', value: 'a' },
      { label: 'Option 2', value: 'b' },
      { label: 'Option 3', value: 'c' },
    ];
    render(<MultiCombobox options={options} value={[]} onChange={jest.fn()} />);

    const toggleIcon = screen.getByTestId('icon-angle-down'); // the input element is the interactive element in the a11y tree - this is just decoration
    await userEvent.click(toggleIcon);

    expect(screen.getByRole('listbox')).toBeInTheDocument();
    expect(screen.getByRole('option', { name: 'Option 1' })).toBeInTheDocument();
  });

  describe('all option', () => {
    it('should render all option', async () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      render(<MultiCombobox width={200} options={options} value={['a']} onChange={jest.fn()} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      expect(await screen.findByRole('option', { name: 'Deselect all' })).toBeInTheDocument();
    });

    it('should select all when no items are selected', async () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      const onChange = jest.fn();
      render(<MultiCombobox width={200} options={options} value={[]} onChange={onChange} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.click(await screen.findByRole('option', { name: 'Select all' }));

      expect(onChange).toHaveBeenCalledWith([
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ]);
    });

    it('should deselect all when any items are selected', async () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      const onChange = jest.fn();
      render(<MultiCombobox width={200} options={options} value={['a']} onChange={onChange} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.click(await screen.findByRole('option', { name: 'Deselect all' }));
      expect(onChange).toHaveBeenCalledWith([]);
    });

    it('should deselect all when all items are selected', async () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      const onChange = jest.fn();
      render(
        <MultiCombobox width={200} options={options} value={['a', 'b', 'c']} onChange={onChange} enableAllOption />
      );
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.click(await screen.findByRole('option', { name: 'Deselect all' }));
      expect(onChange).toHaveBeenCalledWith([]);
    });

    it('should select all filtered items when no filtered items are selected', async () => {
      const options = [
        { label: 'Apple', value: 'apple' },
        { label: 'Apricot', value: 'apricot' },
        { label: 'Banana', value: 'banana' },
      ];
      const onChange = jest.fn();
      render(<MultiCombobox width={200} options={options} value={[]} onChange={onChange} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.type(input, 'ap');
      await user.click(await screen.findByRole('option', { name: 'Select all (filtered)' }));
      expect(onChange).toHaveBeenCalledWith([
        { label: 'Apple', value: 'apple' },
        { label: 'Apricot', value: 'apricot' },
      ]);
    });

    it('should deselect all filtered items when any filtered items are selected', async () => {
      const options = [
        { label: 'Apple', value: 'apple' },
        { label: 'Apricot', value: 'apricot' },
        { label: 'Banana', value: 'banana' },
      ];
      const onChange = jest.fn();
      render(
        <MultiCombobox width={200} options={options} value={['apple', 'banana']} onChange={onChange} enableAllOption />
      );
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.type(input, 'ap');
      await user.click(await screen.findByRole('option', { name: 'Deselect all (filtered)' }));
      // 'apple' and 'apricot' match the filter; only 'apple' was selected so both are deselected,
      // leaving 'banana' (which was selected but not in the filter) intact
      expect(onChange).toHaveBeenCalledWith([{ label: 'Banana', value: 'banana' }]);
    });

    it('should keep label names on selected items when searching', async () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      render(<MultiCombobox width={200} options={options} value={['a']} onChange={jest.fn()} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      await user.type(input, 'b');
      expect(screen.getByText('A')).toBeInTheDocument();
    });

    it('should not render All when only one option is available and enableAll is true', async () => {
      const options = [{ label: 'A', value: 'a' }];
      render(<MultiCombobox width={200} options={options} onChange={jest.fn()} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);
      expect(screen.queryByRole('option', { name: 'Select all' })).not.toBeInTheDocument();
    });

    it('should not select option when only one option is available and enableAll is true', async () => {
      const options = [{ label: 'A', value: 'a' }];
      render(<MultiCombobox width={200} options={options} onChange={jest.fn()} enableAllOption />);
      const input = screen.getByRole('combobox');
      await user.click(input);

      const checkbox = screen.getByTestId(`combobox-option-${options[0].value}-checkbox`);
      expect(checkbox).toBeInTheDocument();
      expect(checkbox).not.toBeChecked();
    });
  });

  describe('duplicate and undefined values', () => {
    it('should render only unique pills when value array contains duplicates', () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
        { label: 'C', value: 'c' },
      ];
      render(<MultiCombobox width={200} options={options} value={['a', 'a', 'b']} onChange={jest.fn()} />);
      expect(screen.getByText('A')).toBeInTheDocument();
      expect(screen.getByText('B')).toBeInTheDocument();
      expect(screen.queryByText('C')).not.toBeInTheDocument();
      expect(screen.getAllByText('A')).toHaveLength(1);
    });

    it('should render fallback pills for duplicate values not present in options', () => {
      const options = [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' },
      ];
      render(<MultiCombobox width={200} options={options} value={['d', 'd', 'a']} onChange={jest.fn()} />);
      expect(screen.getByText('A')).toBeInTheDocument();
      // 'd' is not in options but should appear once as a fallback pill, not twice
      expect(screen.getAllByText('d')).toHaveLength(1);
    });
  });

  describe('async', () => {
    const onChangeHandler = jest.fn();
    let user: ReturnType<typeof userEvent.setup>;

    beforeAll(() => {
      user = userEvent.setup({ delay: null });
      jest.useFakeTimers();
    });

    afterAll(() => {
      jest.useRealTimers();
    });

    afterEach(() => {
      onChangeHandler.mockReset();
    });

    // Assume that most apis only return with the value
    const simpleAsyncOptions = [{ value: 'Option 1' }, { value: 'Option 2' }, { value: 'Option 3' }];

    it('should allow async options', async () => {
      const asyncOptions = jest.fn(() => Promise.resolve(simpleAsyncOptions));
      render(<MultiCombobox options={asyncOptions} value={[]} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      // Debounce
      await act(async () => jest.advanceTimersByTime(DEBOUNCE_TIME_MS));

      expect(asyncOptions).toHaveBeenCalled();
    });

    it('should allow async options and select value', async () => {
      const asyncOptions = jest.fn(() => Promise.resolve(simpleAsyncOptions));
      render(<MultiCombobox options={asyncOptions} value={[]} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      const item = await screen.findByRole('option', { name: 'Option 3' });
      await user.click(item);

      expect(onChangeHandler).toHaveBeenCalledWith([simpleAsyncOptions[2]]);
    });

    it('should retain values not returned by the async function', async () => {
      const asyncOptions = jest.fn(() => Promise.resolve(simpleAsyncOptions));
      render(<MultiCombobox options={asyncOptions} value={[{ value: 'Option 69' }]} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      const item = await screen.findByRole('option', { name: 'Option 3' });
      await user.click(item);

      expect(onChangeHandler).toHaveBeenCalledWith([{ value: 'Option 69' }, { value: 'Option 3' }]);
    });

    it('should ignore late responses', async () => {
      const asyncOptions = jest.fn(async (searchTerm: string) => {
        if (searchTerm === 'a') {
          return promiseResolvesWith([{ value: 'first' }], 1500);
        } else if (searchTerm === 'ab') {
          return promiseResolvesWith([{ value: 'second' }], 500);
        } else if (searchTerm === 'abc') {
          return promiseResolvesWith([{ value: 'third' }], 800);
        }

        return Promise.resolve([]);
      });

      render(<MultiCombobox options={asyncOptions} value={[]} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      await user.keyboard('a');
      act(() => jest.advanceTimersByTime(DEBOUNCE_TIME_MS)); // Skip debounce

      await user.keyboard('b');
      act(() => jest.advanceTimersByTime(DEBOUNCE_TIME_MS)); // Skip debounce

      await user.keyboard('c');
      act(() => jest.advanceTimersByTime(500)); // Resolve the second request, should be ignored

      expect(screen.queryByRole('option', { name: 'first' })).not.toBeInTheDocument();
      expect(screen.queryByRole('option', { name: 'second' })).not.toBeInTheDocument();
      expect(screen.queryByRole('option', { name: 'third' })).not.toBeInTheDocument();

      jest.advanceTimersByTime(800); // Resolve the third request, should be shown
      expect(screen.queryByRole('option', { name: 'first' })).not.toBeInTheDocument();
      expect(screen.queryByRole('option', { name: 'second' })).not.toBeInTheDocument();
      expect(await screen.findByRole('option', { name: 'third' })).toBeInTheDocument();

      jest.advanceTimersByTime(1500); // Resolve the first request, should be ignored
      expect(screen.queryByRole('option', { name: 'first' })).not.toBeInTheDocument();
      expect(screen.queryByRole('option', { name: 'second' })).not.toBeInTheDocument();
      expect(screen.getByRole('option', { name: 'third' })).toBeInTheDocument();

      jest.clearAllTimers();
    });

    it('should debounce requests', async () => {
      const asyncOptions = jest.fn(async () => {
        return promiseResolvesWith([{ value: 'Option 3' }], 1);
      });

      render(<MultiCombobox options={asyncOptions} value={[]} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      await user.keyboard('a');
      act(() => jest.advanceTimersByTime(10));

      await user.keyboard('b');
      act(() => jest.advanceTimersByTime(10));

      await user.keyboard('c');
      act(() => jest.advanceTimersByTime(DEBOUNCE_TIME_MS));

      const item = await screen.findByRole('option', { name: 'Option 3' });
      expect(item).toBeInTheDocument();

      expect(asyncOptions).toHaveBeenCalledTimes(1);
      expect(asyncOptions).toHaveBeenCalledWith('abc');
    });

    it('should allow deselecting items', async () => {
      const asyncOptions = jest.fn(() => Promise.resolve(simpleAsyncOptions));
      render(<MultiCombobox options={asyncOptions} value={['Option 1']} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      // Debounce
      await act(async () => jest.advanceTimersByTime(DEBOUNCE_TIME_MS));

      // Click on Option 1 to deselect it (it should already be selected via value prop)
      const item = await screen.findByRole('option', { name: 'Option 1' });
      await user.click(item);

      // Verify onChange was called to remove the item
      expect(onChangeHandler).toHaveBeenCalledWith([]);
    });

    it('should allow deselecting items with async options using ComboboxOption value format', async () => {
      // This test reproduces the bug where deselection doesn't work with async options
      // when the value is passed as ComboboxOption objects
      const asyncOptionsData = [
        { label: 'Integration A', value: 'a' },
        { label: 'Integration B', value: 'b' },
        { label: 'Integration C', value: 'c' },
      ];

      const asyncOptions = jest.fn(() => Promise.resolve(asyncOptionsData));

      // Use a controlled component to simulate the user's scenario
      const ControlledComponent = () => {
        const [selectedValue, setSelectedValue] = React.useState<Array<ComboboxOption<string>>>([
          { label: 'Integration A', value: 'a' },
        ]);

        return (
          <MultiCombobox
            options={asyncOptions}
            value={selectedValue}
            onChange={(options) => {
              onChangeHandler(options);
              setSelectedValue(options);
            }}
          />
        );
      };

      render(<ControlledComponent />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      // Wait for async options to load
      await act(async () => jest.advanceTimersByTime(DEBOUNCE_TIME_MS));

      // Integration A should be selected (shown as pill)
      const pillRemoveButton = screen.getByRole('button', { name: 'Remove Integration A' });
      expect(pillRemoveButton).toBeInTheDocument();

      // Click on Integration A in the dropdown to deselect it
      const item = await screen.findByRole('option', { name: 'Integration A' });
      await user.click(item);

      // Verify onChange was called to remove the item
      expect(onChangeHandler).toHaveBeenCalledWith([]);

      // The pill should be removed
      expect(screen.queryByRole('button', { name: 'Remove Integration A' })).not.toBeInTheDocument();
    });

    it('shows loading message', async () => {
      const loadingMessage = 'Loading options...';
      const asyncOptions = jest.fn(() => Promise.resolve(simpleAsyncOptions));
      render(<MultiCombobox options={asyncOptions} value={['Option 1']} onChange={onChangeHandler} />);

      const input = screen.getByRole('combobox');
      await user.click(input);

      await act(async () => jest.advanceTimersByTime(0));

      expect(await screen.findByText(loadingMessage)).toBeInTheDocument();

      await act(async () => jest.advanceTimersByTime(DEBOUNCE_TIME_MS));

      expect(screen.queryByText(loadingMessage)).not.toBeInTheDocument();
    });
  });

  describe('Escape key behavior in overlays', () => {
    const options = [
      { label: 'Option 1', value: 'a' },
      { label: 'Option 2', value: 'b' },
      { label: 'Option 3', value: 'c' },
    ];

    it('should not close a Modal when pressing Escape while the menu is open', async () => {
      const onDismiss = jest.fn();
      render(
        <Modal title="Test Modal" isOpen onDismiss={onDismiss}>
          <MultiCombobox options={options} value={[]} onChange={jest.fn()} />
        </Modal>
      );

      // Modal auto-focuses the close button on open — wait for focus to settle
      await waitFor(() => expect(screen.getByRole('button', { name: 'Close' })).toHaveFocus());

      const input = screen.getByRole('combobox');
      await user.click(input);
      expect(await screen.findByRole('option', { name: 'Option 1' })).toBeInTheDocument();

      await user.keyboard('{Escape}');
      expect(onDismiss).not.toHaveBeenCalled();
    });

    it('should not close a Drawer when pressing Escape while the menu is open', async () => {
      const onClose = jest.fn();
      render(
        <div className="main-view">
          <Drawer title="Test Drawer" onClose={onClose}>
            <MultiCombobox options={options} value={[]} onChange={jest.fn()} />
          </Drawer>
        </div>
      );

      // Drawer auto-focuses the close button on open — wait for focus to settle
      await waitFor(() => expect(screen.getByRole('button', { name: 'Close' })).toHaveFocus());

      const input = screen.getByRole('combobox');
      await user.click(input);
      expect(await screen.findByRole('option', { name: 'Option 1' })).toBeInTheDocument();

      await user.keyboard('{Escape}');
      expect(onClose).not.toHaveBeenCalled();
    });
  });
});

function promiseResolvesWith(value: ComboboxOption[], timeout = 0) {
  return new Promise<ComboboxOption[]>((resolve) => setTimeout(() => resolve(value), timeout));
}
