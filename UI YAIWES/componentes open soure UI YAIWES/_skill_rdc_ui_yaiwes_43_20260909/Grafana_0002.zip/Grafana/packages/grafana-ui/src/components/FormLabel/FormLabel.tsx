import classNames from 'clsx';
import { type ReactNode } from 'react';

import { Icon } from '../Icon/Icon';
import { Tooltip } from '../Tooltip/Tooltip';
import { type PopoverContent } from '../Tooltip/types';

interface Props {
  children: ReactNode;
  className?: string;
  htmlFor?: string;
  isFocused?: boolean;
  isInvalid?: boolean;
  tooltip?: PopoverContent;
  width?: number | 'auto';
  /** Make tooltip interactive */
  interactive?: boolean;
}

const FormLabel = ({
  children,
  isFocused,
  isInvalid,
  className,
  htmlFor,
  tooltip,
  width,
  interactive,
  ...rest
}: Props) => {
  const classes = classNames(className, `gf-form-label width-${width ? width : '10'}`, {
    'gf-form-label--is-focused': isFocused,
    'gf-form-label--is-invalid': isInvalid,
  });

  return (
    <label className={classes} {...rest} htmlFor={htmlFor}>
      {children}
      {tooltip && (
        <Tooltip placement="top" content={tooltip} theme={'info'} interactive={interactive}>
          <Icon name="info-circle" size="sm" style={{ marginLeft: '10px' }} />
        </Tooltip>
      )}
    </label>
  );
};

/** @alias */
export const InlineFormLabel = FormLabel;
