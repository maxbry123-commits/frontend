import { css, cx } from '@emotion/css';
import { autoUpdate, useClick, useDismiss, useFloating, useInteractions } from '@floating-ui/react';
import { useDialog } from '@react-aria/dialog';
import { FocusScope } from '@react-aria/focus';
import { useOverlay } from '@react-aria/overlays';
import { type FormEvent, useCallback, useRef, useState } from 'react';

import { type RelativeTimeRange, type GrafanaTheme2, type TimeOption } from '@grafana/data';
import { t, Trans } from '@grafana/i18n';

import { useStyles2 } from '../../../themes/ThemeContext';
import { getPositioningMiddleware } from '../../../utils/floating';
import { Button } from '../../Button/Button';
import { Field } from '../../Forms/Field';
import { Icon } from '../../Icon/Icon';
import { getInputStyles, Input } from '../../Input/Input';
import { ScrollContainer } from '../../ScrollContainer/ScrollContainer';
import { TimePickerTitle } from '../TimeRangePicker/TimePickerTitle';
import { TimeRangeList } from '../TimeRangePicker/TimeRangeList';
import { getQuickOptions } from '../options';

import {
  isRangeValid,
  isRelativeFormat,
  mapOptionToRelativeTimeRange,
  mapRelativeTimeRangeToOption,
  type RangeValidation,
} from './utils';

/**
 * @internal
 */
export interface RelativeTimeRangePickerProps {
  timeRange: RelativeTimeRange;
  onChange: (timeRange: RelativeTimeRange) => void;
}

type InputState = {
  value: string;
  validation: RangeValidation;
};

/**
 * https://developers.grafana.com/ui/latest/index.html?path=/docs/date-time-pickers-relativetimerangepicker--docs
 * @internal
 */
export function RelativeTimeRangePicker(props: RelativeTimeRangePickerProps) {
  const { timeRange, onChange } = props;
  const [isOpen, setIsOpen] = useState(false);
  const onClose = useCallback(() => setIsOpen(false), []);
  const timeOption = mapRelativeTimeRangeToOption(timeRange);
  const [from, setFrom] = useState<InputState>({ value: timeOption.from, validation: isRangeValid(timeOption.from) });
  const [to, setTo] = useState<InputState>({ value: timeOption.to, validation: isRangeValid(timeOption.to) });
  const ref = useRef<HTMLDivElement>(null);
  const { overlayProps, underlayProps } = useOverlay(
    { onClose: () => setIsOpen(false), isDismissable: true, isOpen },
    ref
  );
  const { dialogProps } = useDialog({}, ref);
  const validOptions = getQuickOptions().filter((o) => isRelativeFormat(o.from));
  const placement = 'bottom-start';

  // the order of middleware is important!
  // see https://floating-ui.com/docs/arrow#order
  const middleware = getPositioningMiddleware(placement);

  const { context, refs, floatingStyles } = useFloating({
    open: isOpen,
    placement,
    onOpenChange: setIsOpen,
    middleware,
    whileElementsMounted: autoUpdate,
    strategy: 'fixed',
  });

  const click = useClick(context);
  const dismiss = useDismiss(context);

  const { getReferenceProps, getFloatingProps } = useInteractions([dismiss, click]);

  const styles = useStyles2(getStyles(from.validation.errorMessage, to.validation.errorMessage));

  const onChangeTimeOption = (option: TimeOption) => {
    const relativeTimeRange = mapOptionToRelativeTimeRange(option);
    if (!relativeTimeRange) {
      return;
    }
    onClose();
    setFrom({ ...from, value: option.from });
    setTo({ ...to, value: option.to });
    onChange(relativeTimeRange);
  };

  const onOpen = useCallback(
    (event: FormEvent<HTMLButtonElement>) => {
      event.stopPropagation();
      event.preventDefault();
      setIsOpen(!isOpen);
    },
    [isOpen]
  );

  const onApply = (event: FormEvent<HTMLButtonElement>) => {
    event.preventDefault();

    if (!to.validation.isValid || !from.validation.isValid) {
      return;
    }

    const timeRange = mapOptionToRelativeTimeRange({
      from: from.value,
      to: to.value,
      display: '',
    });

    if (!timeRange) {
      return;
    }

    onChange(timeRange);
    setIsOpen(false);
  };

  const { from: timeOptionFrom, to: timeOptionTo } = timeOption;

  return (
    <div className={styles.container}>
      <button
        ref={refs.setReference}
        className={styles.pickerInput}
        type="button"
        onClick={onOpen}
        {...getReferenceProps()}
      >
        <span className={styles.clockIcon}>
          <Icon name="clock-nine" />
        </span>
        <span>
          <Trans i18nKey="time-picker.time-range.from-to">
            {{ timeOptionFrom }} to {{ timeOptionTo }}
          </Trans>
        </span>
        <span className={styles.caretIcon}>
          <Icon name={isOpen ? 'angle-up' : 'angle-down'} size="lg" />
        </span>
      </button>
      {isOpen && (
        <div>
          <div role="presentation" className={styles.backdrop} {...underlayProps} />
          <FocusScope contain autoFocus restoreFocus>
            <div ref={ref} {...overlayProps} {...dialogProps}>
              <div className={styles.content} ref={refs.setFloating} style={floatingStyles} {...getFloatingProps()}>
                <div className={styles.body}>
                  <div className={styles.leftSide}>
                    <ScrollContainer showScrollIndicators>
                      <TimeRangeList
                        title={t('time-picker.time-range.example-title', 'Example time ranges')}
                        options={validOptions}
                        onChange={onChangeTimeOption}
                        value={timeOption}
                      />
                    </ScrollContainer>
                  </div>
                  <div className={styles.rightSide}>
                    <div className={styles.title}>
                      <TimePickerTitle>
                        <Trans i18nKey="time-picker.time-range.specify">Specify time range</Trans>
                      </TimePickerTitle>
                    </div>
                    <Field
                      label={t('time-picker.time-range.from-label', 'From')}
                      invalid={!from.validation.isValid}
                      error={from.validation.errorMessage}
                    >
                      <Input
                        onClick={(event) => event.stopPropagation()}
                        onBlur={() => setFrom({ ...from, validation: isRangeValid(from.value) })}
                        onChange={(event) => setFrom({ ...from, value: event.currentTarget.value })}
                        value={from.value}
                      />
                    </Field>
                    <Field
                      label={t('time-picker.time-range.to-label', 'To')}
                      invalid={!to.validation.isValid}
                      error={to.validation.errorMessage}
                    >
                      <Input
                        onClick={(event) => event.stopPropagation()}
                        onBlur={() => setTo({ ...to, validation: isRangeValid(to.value) })}
                        onChange={(event) => setTo({ ...to, value: event.currentTarget.value })}
                        value={to.value}
                      />
                    </Field>
                    <Button
                      aria-label={t('time-picker.time-range.submit-button-label', 'TimePicker submit button')}
                      onClick={onApply}
                    >
                      <Trans i18nKey="time-picker.time-range.apply">Apply time range</Trans>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </FocusScope>
        </div>
      )}
    </div>
  );
}

const getStyles = (fromError?: string, toError?: string) => (theme: GrafanaTheme2) => {
  const inputStyles = getInputStyles({ theme, invalid: false });
  const bodyMinimumHeight = 250;
  const bodyHeight = bodyMinimumHeight + calculateErrorHeight(theme, fromError) + calculateErrorHeight(theme, toError);

  return {
    backdrop: css({
      position: 'fixed',
      zIndex: theme.zIndex.modalBackdrop,
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
    }),
    container: css({
      display: 'flex',
      position: 'relative',
    }),
    pickerInput: cx(
      inputStyles.input,
      inputStyles.wrapper,
      css({
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        cursor: 'pointer',
        paddingRight: 0,
        paddingLeft: 0,
        lineHeight: `${theme.spacing.gridSize * theme.components.height.md - 2}px`,
      })
    ),
    caretIcon: cx(
      inputStyles.suffix,
      css({
        position: 'relative',
        marginLeft: theme.spacing(0.5),
      })
    ),
    clockIcon: cx(
      inputStyles.prefix,
      css({
        position: 'relative',
        marginRight: theme.spacing(0.5),
      })
    ),
    content: css({
      background: theme.colors.background.primary,
      boxShadow: theme.flags.visualDesignRefresh ? theme.shadows.z2 : theme.shadows.z3,
      position: 'absolute',
      zIndex: theme.zIndex.modal,
      width: '500px',
      top: '100%',
      borderRadius: theme.shape.radius.default,
      border: `1px solid ${theme.colors.border.weak}`,
      left: 0,
      whiteSpace: 'normal',
    }),
    body: css({
      display: 'flex',
      height: `${bodyHeight}px`,
    }),
    description: css({
      color: theme.colors.text.secondary,
      fontSize: theme.typography.size.sm,
    }),
    leftSide: css({
      width: '50% !important',
      borderRight: `1px solid ${theme.colors.border.medium}`,
    }),
    rightSide: css({
      width: '50%',
      padding: theme.spacing(1),
    }),
    title: css({
      marginBottom: theme.spacing(1),
    }),
  };
};

function calculateErrorHeight(theme: GrafanaTheme2, errorMessage?: string): number {
  if (!errorMessage) {
    return 0;
  }

  if (errorMessage.length > 34) {
    return theme.spacing.gridSize * 6.5;
  }

  return theme.spacing.gridSize * 4;
}
