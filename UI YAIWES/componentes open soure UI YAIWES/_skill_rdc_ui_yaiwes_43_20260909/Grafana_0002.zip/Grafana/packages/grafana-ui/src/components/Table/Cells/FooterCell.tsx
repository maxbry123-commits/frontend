import { css } from '@emotion/css';

import { type KeyValue } from '@grafana/data';

import { type FooterItem } from '../types';

export interface FooterProps {
  value: FooterItem;
}

export const FooterCell = (props: FooterProps) => {
  const cell = css({
    width: '100%',
    listStyle: 'none',
  });

  const list = css({
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
  });

  if (props.value && !Array.isArray(props.value)) {
    return <span>{props.value}</span>;
  }

  if (props.value && Array.isArray(props.value) && props.value.length > 0) {
    return (
      <ul className={cell}>
        {props.value.map((v: KeyValue<string>, i) => {
          const key = Object.keys(v)[0];
          return (
            <li className={list} key={i}>
              <span>{key}</span>
              <span>{v[key]}</span>
            </li>
          );
        })}
      </ul>
    );
  }

  return EmptyCell;
};

export const EmptyCell = () => {
  return <span>&nbsp;</span>;
};
