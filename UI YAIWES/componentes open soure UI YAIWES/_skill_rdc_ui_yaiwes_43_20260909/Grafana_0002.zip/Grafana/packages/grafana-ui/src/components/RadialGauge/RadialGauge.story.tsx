import { type Meta, type StoryFn } from '@storybook/react-webpack5';

import {
  applyFieldOverrides,
  type Field,
  FieldType,
  getFieldDisplayValues,
  type GrafanaTheme2,
  toDataFrame,
} from '@grafana/data';
import { FieldColorModeId, type FieldConfig, ThresholdsMode } from '@grafana/schema';

import { useTheme2 } from '../../themes/ThemeContext';
import { Stack } from '../Layout/Stack/Stack';

import { RadialGauge, type RadialGaugeProps } from './RadialGauge';
import { type RadialShape, type RadialTextMode } from './types';

interface StoryProps extends RadialGaugeProps {
  value: number;
  seriesCount: number;
  sparkline: boolean;
  colorScheme: FieldColorModeId;
  decimals: number;
}

const meta: Meta<StoryProps> = {
  title: 'Plugins/RadialGauge',
  component: RadialGauge,
  excludeStories: ['RadialGaugeExample'],
  parameters: {
    controls: {
      exclude: ['theme', 'values', 'vizCount'],
    },
  },
  args: {
    barWidthFactor: 0.2,
    glowBar: false,
    glowCenter: false,
    sparkline: false,
    value: undefined,
    width: 200,
    height: 200,
    shape: 'circle',
    gradient: false,
    seriesCount: 1,
    segmentCount: 0,
    segmentSpacing: 0.2,
    roundedBars: false,
    thresholdsBar: false,
    colorScheme: FieldColorModeId.Thresholds,
    decimals: 0,
    neutral: undefined,
  },
  argTypes: {
    barWidthFactor: { control: { type: 'range', min: 0.1, max: 1, step: 0.01 } },
    width: { control: { type: 'range', min: 50, max: 600 } },
    height: { control: { type: 'range', min: 50, max: 600 } },
    value: { control: { type: 'range', min: 0, max: 110 } },
    roundedBars: { control: 'boolean' },
    sparkline: { control: 'boolean' },
    thresholdsBar: { control: 'boolean' },
    gradient: { control: { type: 'boolean' } },
    seriesCount: { control: { type: 'range', min: 1, max: 20 } },
    segmentCount: { control: { type: 'range', min: 0, max: 100 } },
    segmentSpacing: { control: { type: 'range', min: 0, max: 1, step: 0.01 } },
    endpointMarker: { control: { type: 'select' }, options: ['none', 'point', 'glow'] },
    colorScheme: {
      control: { type: 'select' },
      options: [
        FieldColorModeId.Thresholds,
        FieldColorModeId.Fixed,
        FieldColorModeId.ContinuousGrYlRd,
        FieldColorModeId.ContinuousBlYlRd,
        FieldColorModeId.ContinuousBlPu,
      ],
    },
    decimals: { control: { type: 'range', min: 0, max: 7 } },
    neutral: { control: { type: 'number' } },
  },
};

export const Basic: StoryFn<StoryProps> = (args) => {
  const visualizations: React.ReactNode[] = [];
  const colors = ['blue', 'green', 'red', 'purple', 'orange', 'yellow', 'dark-red', 'dark-blue', 'dark-green'];

  for (let i = 0; i < args.seriesCount; i++) {
    const color = args.colorScheme === FieldColorModeId.Fixed ? colors[i % colors.length] : undefined;

    visualizations.push(
      <RadialGaugeExample {...args} key={i} color={color} seriesCount={0} vizCount={args.seriesCount} />
    );
  }

  return (
    <Stack direction={'row'} gap={3} wrap="wrap">
      {visualizations}
    </Stack>
  );
};

export const Examples: StoryFn<StoryProps> = (args) => {
  return (
    <Stack direction={'column'} gap={3} wrap="wrap">
      <div>Bar width</div>
      <Stack direction="row" alignItems="center" gap={3} wrap="wrap">
        <RadialGaugeExample seriesName="0.1" value={args.value ?? 30} color="blue" gradient barWidthFactor={0.1} />
        <RadialGaugeExample seriesName="0.4" value={args.value ?? 40} color="green" gradient barWidthFactor={0.4} />
        <RadialGaugeExample seriesName="0.6" value={args.value ?? 60} color="red" gradient barWidthFactor={0.6} />
        <RadialGaugeExample seriesName="0.8" value={args.value ?? 70} color="purple" gradient barWidthFactor={0.8} />
      </Stack>
      <div>Effects</div>
      <Stack direction="row" alignItems="center" gap={3} wrap="wrap">
        <RadialGaugeExample value={args.value ?? 30} glowBar glowCenter color="blue" gradient />
        <RadialGaugeExample value={args.value ?? 40} glowBar glowCenter color="green" gradient />
        <RadialGaugeExample value={args.value ?? 60} glowBar glowCenter color="red" gradient roundedBars />
        <RadialGaugeExample value={args.value ?? 70} glowBar glowCenter color="purple" gradient roundedBars />
      </Stack>
      <div>Shape: Gauge & color scale</div>
      <Stack direction="row" alignItems="center" gap={3} wrap="wrap">
        <RadialGaugeExample
          value={40}
          shape="gauge"
          width={250}
          gradient
          colorScheme={FieldColorModeId.ContinuousGrYlRd}
          glowCenter={true}
          barWidthFactor={0.6}
        />
        <RadialGaugeExample
          colorScheme={FieldColorModeId.ContinuousGrYlRd}
          gradient
          width={250}
          value={90}
          barWidthFactor={0.6}
          roundedBars={false}
          glowBar={true}
          glowCenter={true}
          shape="gauge"
        />
      </Stack>
      <div>Sparklines</div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          value={args.value ?? 70}
          color="blue"
          shape="gauge"
          gradient
          sparkline={true}
          glowBar={true}
          glowCenter={true}
          barWidthFactor={0.2}
        />
        <RadialGaugeExample
          value={args.value ?? 30}
          color="green"
          shape="gauge"
          gradient
          sparkline={true}
          glowBar={true}
          glowCenter={true}
          barWidthFactor={0.8}
        />
        <RadialGaugeExample
          value={args.value ?? 50}
          color="red"
          shape="gauge"
          width={250}
          gradient
          sparkline={true}
          glowBar={true}
          glowCenter={true}
          barWidthFactor={0.2}
        />
        <RadialGaugeExample
          value={args.value ?? 50}
          color="red"
          width={250}
          shape="gauge"
          gradient
          sparkline={true}
          glowBar={true}
          glowCenter={true}
          barWidthFactor={0.8}
        />
      </Stack>
      <div>Segmented</div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          value={args.value ?? 70}
          color="green"
          gradient
          glowCenter={true}
          segmentCount={8}
          segmentSpacing={0.1}
          barWidthFactor={0.4}
        />
        <RadialGaugeExample
          value={args.value ?? 30}
          color="purple"
          gradient
          segmentCount={30}
          glowCenter={true}
          barWidthFactor={0.6}
        />
        <RadialGaugeExample
          value={args.value ?? 50}
          color="red"
          gradient
          segmentCount={40}
          glowCenter={true}
          barWidthFactor={1}
          segmentSpacing={0.6}
        />
      </Stack>
      <div>Segmented color scale</div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          value={args.value ?? 80}
          colorScheme={FieldColorModeId.ContinuousGrYlRd}
          glowBar={true}
          glowCenter={true}
          segmentCount={20}
          barWidthFactor={0.4}
        />
        <RadialGaugeExample
          value={args.value ?? 80}
          width={250}
          colorScheme={FieldColorModeId.ContinuousGrYlRd}
          shape="gauge"
          gradient
          glowBar={true}
          glowCenter={true}
          segmentCount={40}
          segmentSpacing={0.5}
          barWidthFactor={0.8}
        />
      </Stack>
      <div>Thresholds</div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          value={args.value ?? 70}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          thresholdsBar={true}
          roundedBars={false}
          glowCenter={true}
          barWidthFactor={0.7}
        />
        <RadialGaugeExample
          value={args.value ?? 70}
          width={250}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          glowCenter={true}
          thresholdsBar={true}
          roundedBars={false}
          shape="gauge"
          barWidthFactor={0.7}
        />
        <RadialGaugeExample
          value={args.value ?? 70}
          width={250}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          glowCenter={true}
          thresholdsBar={true}
          roundedBars={false}
          segmentCount={40}
          segmentSpacing={0.3}
          shape="gauge"
          barWidthFactor={0.7}
        />
      </Stack>
      <div>
        Neutral <em>(range -50 to 50, neutral = 0)</em>
      </div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          min={-50}
          max={50}
          value={-20}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          shape="gauge"
          glowCenter={true}
          roundedBars={false}
          barWidthFactor={0.7}
          neutral={0}
        />
      </Stack>
      <div>
        Overflow with neutral <em>(range -5 to 5, neutral = 0, value = 10 / -10 — #130075)</em>
      </div>
      <Stack direction={'row'} gap={3}>
        <RadialGaugeExample
          min={-5}
          max={5}
          value={10}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          shape="gauge"
          glowCenter={true}
          roundedBars={false}
          barWidthFactor={0.7}
          neutral={0}
          showScaleLabels
        />
        <RadialGaugeExample
          min={-5}
          max={5}
          value={-10}
          colorScheme={FieldColorModeId.Thresholds}
          gradient
          shape="gauge"
          glowCenter={true}
          roundedBars={false}
          barWidthFactor={0.7}
          neutral={0}
          showScaleLabels
        />
      </Stack>
    </Stack>
  );
};

Examples.parameters = {
  controls: { include: ['barWidthFactor', 'value'] },
};

export const MultiSeries: StoryFn<StoryProps> = (args) => {
  return (
    <Stack direction={'column'} gap={3}>
      <RadialGaugeExample color="red" {...args} />
    </Stack>
  );
};

MultiSeries.args = {
  barWidthFactor: 0.2,
};

export const Temp: StoryFn<StoryProps> = (args) => {
  return (
    <Stack direction={'column'} gap={3}>
      <RadialGaugeExample
        {...args}
        colorScheme={FieldColorModeId.ContinuousReds}
        color="red"
        shape="gauge"
        roundedBars={false}
        barWidthFactor={0.8}
      />
    </Stack>
  );
};

interface ExampleProps {
  color?: string;
  seriesName?: string;
  value?: number;
  shape?: RadialShape;
  min?: number;
  max?: number;
  width?: number;
  height?: number;
  gradient?: boolean;
  glowBar?: boolean;
  glowCenter?: boolean;
  barWidthFactor?: number;
  sparkline?: boolean;
  seriesCount?: number;
  vizCount?: number;
  textMode?: RadialTextMode;
  segmentCount?: number;
  segmentSpacing?: number;
  roundedBars?: boolean;
  thresholds?: FieldConfig['thresholds'];
  thresholdsBar?: boolean;
  colorScheme?: FieldColorModeId;
  endpointMarker?: RadialGaugeProps['endpointMarker'];
  decimals?: number;
  unit?: string;
  showScaleLabels?: boolean;
  neutral?: number;
}

const DEFAULT_THRESHOLDS: FieldConfig['thresholds'] = {
  mode: ThresholdsMode.Absolute,
  steps: [
    { value: -Infinity, color: 'green' },
    { value: 65, color: 'orange' },
    { value: 85, color: 'red' },
  ],
};

export function RadialGaugeExample({
  color,
  seriesName,
  value = 70,
  shape = 'circle',
  min = 0,
  max = 100,
  width = 200,
  height = 200,
  gradient = false,
  glowBar = false,
  glowCenter = false,
  barWidthFactor = 0.4,
  sparkline = false,
  seriesCount = 0,
  vizCount = 1,
  textMode = 'auto',
  segmentCount = 0,
  segmentSpacing = 0.1,
  roundedBars = false,
  thresholds = DEFAULT_THRESHOLDS,
  thresholdsBar = false,
  colorScheme = FieldColorModeId.Thresholds,
  endpointMarker = 'glow',
  decimals = 0,
  unit = 'percent',
  showScaleLabels,
  neutral,
}: ExampleProps) {
  const theme = useTheme2();

  if (color) {
    colorScheme = FieldColorModeId.Fixed;
  }

  const frame = toDataFrame({
    name: 'TestData',
    length: 18,
    fields: [
      {
        name: 'Time',
        type: FieldType.time,
        values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
        config: {
          min: 0,
          max: 4,
        },
      },
      {
        name: 'Value',
        type: FieldType.number,
        values: [40, 45, 20, 25, 30, 28, 27, 30, 31, 26, 50, 55, 52, 20, 25, 30, 60, value],
        config: {
          min: min,
          max: max,
          unit,
          decimals: decimals,
          color: { mode: colorScheme, fixedColor: color ? theme.visualization.getColorByName(color) : undefined },
          thresholds,
          displayName: seriesName,
        },
        // Add state and getLinks
        state: {},
        getLinks: () => [],
      },
      ...getExtraSeries(seriesCount, colorScheme, decimals, theme),
    ],
  });

  const data = applyFieldOverrides({
    data: [frame],
    fieldConfig: {
      defaults: {},
      overrides: [],
    },
    replaceVariables: (value) => value,
    timeZone: 'utc',
    theme,
  });

  const values = getFieldDisplayValues({
    fieldConfig: { overrides: [], defaults: {} },
    reduceOptions: { calcs: ['last'] },
    replaceVariables: (value) => value,
    theme: theme,
    data,
    sparkline,
  });

  return (
    <RadialGauge
      values={values}
      width={width}
      height={height}
      barWidthFactor={barWidthFactor}
      gradient={gradient}
      shape={shape}
      glowBar={glowBar}
      glowCenter={glowCenter}
      textMode={textMode}
      vizCount={vizCount}
      segmentCount={segmentCount}
      segmentSpacing={segmentSpacing}
      roundedBars={roundedBars}
      thresholdsBar={thresholdsBar}
      showScaleLabels={showScaleLabels}
      endpointMarker={endpointMarker}
      neutral={neutral}
    />
  );
}

function getExtraSeries(seriesCount: number, colorScheme: FieldColorModeId, decimals: number, theme: GrafanaTheme2) {
  const fields: Field[] = [];
  const colors = ['blue', 'green', 'purple', 'orange', 'yellow'];

  for (let i = 1; i < seriesCount; i++) {
    fields.push({
      name: `Series ${i + 1}`,
      type: FieldType.number,
      values: [40, 45, 20, 25, 30, 28, 27, 30, 31, 26, 50, 55, 52, 20, 25, 30, 60, 20 * (i + 1)],
      config: {
        min: 0,
        max: 100,
        decimals: decimals,
        unit: 'percent',
        color: { mode: colorScheme, fixedColor: theme.visualization.getColorByName(colors[i % colors.length]) },
      },
      // Add state and getLinks
      state: {},
      getLinks: () => [],
    });
  }

  return fields;
}

export default meta;
