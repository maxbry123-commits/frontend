import { css } from '@emotion/css';
import memoize from 'micro-memoize';
import { useMemo } from 'react';

import {
  type GrafanaTheme2,
  classicColors,
  type Field,
  getColorByStringHash,
  FALLBACK_COLOR,
  fieldColorModeRegistry,
  formattedValueToString,
} from '@grafana/data';
import { FieldColorModeId } from '@grafana/schema';

import { getActiveCellSelector, isTableCellStylesKeyEqual } from '../styles';
import { type PillCellProps, type TableCellStyles } from '../types';
import { inferPills } from '../utils';

export function PillCell({ rowIdx, field, theme, getTextColorForBackground }: PillCellProps) {
  const value = field.values[rowIdx];
  const pills: Pill[] = useMemo(() => {
    const pillValues = inferPills(value);
    return pillValues.length > 0
      ? pillValues.map((pill, index) => {
          const renderedValue = formattedValueToString(field.display!(pill));
          const bgColor = getPillColor(renderedValue, field, theme);
          const textColor = getTextColorForBackground(bgColor);
          return {
            value: renderedValue,
            key: `${pill}-${index}`,
            bgColor,
            color: textColor,
          };
        })
      : [];
  }, [value, field, theme, getTextColorForBackground]);

  if (pills.length === 0) {
    return null;
  }

  return pills.map((pill) => (
    <span
      key={pill.key}
      style={{
        backgroundColor: pill.bgColor,
        color: pill.color,
        border: pill.bgColor === TRANSPARENT ? `1px solid ${theme.colors.border.strong}` : undefined,
      }}
    >
      {pill.value}
    </span>
  ));
}

interface Pill {
  value: string;
  key: string;
  bgColor: string;
  color: string;
}

const TRANSPARENT = 'rgba(0,0,0,0)';

// FIXME: this does not yet support "shades of a color"
function getPillColor(value: unknown, field: Field, theme: GrafanaTheme2): string {
  const cfg = field.config;

  if (cfg.mappings?.length ?? 0 > 0) {
    return field.display!(value).color ?? FALLBACK_COLOR;
  }

  if (cfg.color?.mode === FieldColorModeId.Fixed) {
    return theme.visualization.getColorByName(cfg.color?.fixedColor ?? FALLBACK_COLOR);
  }

  let colors = classicColors;
  const configuredColor = cfg.color;
  if (configuredColor) {
    const mode = fieldColorModeRegistry.get(configuredColor.mode);
    if (typeof mode?.getColors === 'function') {
      colors = mode.getColors(theme);
    }
  }

  return getColorByStringHash(colors, String(value));
}

export const getStyles: TableCellStyles = memoize(
  (theme, { textWrap, shouldOverflow, maxHeight }) =>
    css({
      display: 'inline-flex',
      gap: theme.spacing(0.5),
      flexWrap: textWrap ? 'wrap' : 'nowrap',

      ...(shouldOverflow && {
        [getActiveCellSelector(Boolean(maxHeight))]: {
          flexWrap: 'wrap',
        },
      }),

      '> span': {
        display: 'flex',
        padding: theme.spacing(0.25, 0.75),
        borderRadius: theme.shape.radius.default,
        fontSize: theme.typography.bodySmall.fontSize,
        lineHeight: theme.typography.bodySmall.lineHeight,
        whiteSpace: 'nowrap',
      },
    }),
  { isMatchingKey: isTableCellStylesKeyEqual }
);
