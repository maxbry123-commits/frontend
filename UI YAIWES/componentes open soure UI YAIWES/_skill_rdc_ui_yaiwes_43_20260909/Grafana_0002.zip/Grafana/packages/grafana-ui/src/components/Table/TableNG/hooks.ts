import { debounce } from 'lodash';
import {
  useState,
  useMemo,
  useCallback,
  useRef,
  useLayoutEffect,
  type RefObject,
  type CSSProperties,
  useEffect,
} from 'react';

import {
  createDataFrame,
  type DataFrame,
  type Field,
  FieldType,
  formattedValueToString,
  type GrafanaTheme2,
  reduceField,
  ReducerID,
} from '@grafana/data';
import {
  type Column,
  type ColumnWidths,
  type DataGridHandle,
  type DataGridProps,
  type SortColumn,
} from '@grafana/react-data-grid';
import { type MatcherScope } from '@grafana/schema';

import { useTheme2 } from '../../../themes/ThemeContext';
import { type TableColumnResizeActionCallback } from '../types';

import { CELL_HORIZONTAL_CHROME, HEADER_ICON_SPACE, TABLE } from './constants';
import { IS_SAFARI_26 } from './styles';
import {
  type FilterType,
  type FooterFieldState,
  type GetActionsFunctionLocal,
  type NestedRowEntry,
  type SortByBehavior,
  type TableRow,
  type TableSortByFieldState,
  type TableSummaryRow,
  type TypographyCtx,
} from './types';
import {
  getDisplayName,
  applySort,
  getColumnTypes,
  getRowHeight,
  computeColWidths,
  computeContentAwareColWidths,
  buildNestedColumnWidthsMap,
  buildHeaderHeightMeasurers,
  buildCellHeightMeasurers,
  applyFilter,
  compileFrameToRecords,
  isSortableField,
  createTypographyContext,
  extractPixelValue,
} from './utils';

export function useFilteredRows(rows: TableRow[], fields: Field[], hasNestedFrames?: boolean) {
  const [filter, setFilter] = useState<FilterType>({});
  const filterResult = useMemo(
    () => applyFilter(rows, filter, fields, hasNestedFrames),
    [rows, filter, fields, hasNestedFrames]
  );
  return { rows: filterResult.filteredRows, filter, setFilter, filterResult };
}

export interface SortedRowsOptions {
  hasNestedFrames?: boolean;
  initialSortBy?: TableSortByFieldState[];
}

export interface SortedRowsResult {
  rows: TableRow[];
  sortColumns: SortColumn[];
  setSortColumns: React.Dispatch<React.SetStateAction<SortColumn[]>>;
}

interface ManagedSortProps {
  sortByBehavior: SortByBehavior;
  setSortColumns: React.Dispatch<React.SetStateAction<SortColumn[]>>;
  sortBy?: TableSortByFieldState[];
}

export function useManagedSort({ sortByBehavior, setSortColumns, sortBy }: ManagedSortProps) {
  useEffect(() => {
    if (sortByBehavior === 'managed' && sortBy) {
      setSortColumns(
        sortBy.map(({ displayName, desc }) => ({
          columnKey: displayName,
          direction: desc === true ? 'DESC' : 'ASC',
        }))
      );
    }
  }, [setSortColumns, sortBy, sortByBehavior]);
}

export function useSortedRows(
  rows: TableRow[],
  fields: Field[],
  nestedFields: Field[],
  { initialSortBy, hasNestedFrames }: SortedRowsOptions
): SortedRowsResult {
  const allFields = useMemo(() => [...fields, ...nestedFields], [fields, nestedFields]);
  const initialSortColumns = useMemo<SortColumn[]>(
    () =>
      initialSortBy?.flatMap(({ displayName, desc }) => {
        if (!allFields.some((f) => getDisplayName(f) === displayName)) {
          return [];
        }
        return [
          {
            columnKey: displayName,
            direction: desc ? ('DESC' as const) : ('ASC' as const),
          },
        ];
      }) ?? [],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );
  const [sortColumns, setSortColumns] = useState<SortColumn[]>(initialSortColumns);
  const columnTypes = useMemo(() => getColumnTypes(fields), [fields]);

  const sortedRows = useMemo(
    () => applySort(rows, fields, sortColumns, columnTypes, hasNestedFrames),
    [rows, fields, sortColumns, columnTypes, hasNestedFrames]
  );

  return {
    rows: sortedRows,
    sortColumns,
    setSortColumns,
  };
}

export interface PaginatedRowsOptions {
  height: number;
  width: number;
  rowHeight: NonNullable<CSSProperties['height']> | ((row: TableRow) => number);
  headerHeight: number;
  footerHeight: number;
  paginationHeight?: number;
  enabled: boolean;
  hasNestedFrames?: boolean;
  /** When set to a positive value, fixes the number of rows per page instead of deriving it from the panel height. */
  pageSize?: number;
}

export interface PaginatedRowsResult {
  rows: TableRow[];
  page: number;
  setPage: React.Dispatch<React.SetStateAction<number>>;
  numPages: number;
  numRows: number;
  rowsPerPage: number;
  pageRangeStart: number;
  pageRangeEnd: number;
  smallPagination: boolean;
}

// hand-measured. pagination height is 30px, plus 8px top margin
const PAGINATION_HEIGHT = 38;

export function usePaginatedRows(
  rows: TableRow[],
  { height, width, headerHeight, footerHeight, rowHeight, enabled, hasNestedFrames, pageSize }: PaginatedRowsOptions
): PaginatedRowsResult {
  // TODO: allow persisted page selection via url
  const [page, setPage] = useState(0);
  const numRows = useMemo(() => rows.filter((r) => r.__depth === 0).length, [rows]);

  // calculate average row height if row height is variable.
  const avgRowHeight = useMemo(() => {
    if (!enabled) {
      return 0;
    }

    if (typeof rowHeight === 'number') {
      return rowHeight;
    }

    // when using auto-sized rows, we're just going to have to pick a number. the alternative
    // is to measure each row, which we could do but would be expensive.
    if (typeof rowHeight === 'string') {
      return TABLE.MAX_CELL_HEIGHT;
    }

    // we'll just measure 100 rows to estimate (skipping nested rows. we don't want to consider nested rows to avoid hiding and showing
    // them as they are collapsed and expanded)
    let sum = 0;
    let count = 0;
    for (let i = 0; i < Math.min(100, rows.length); i++) {
      const row = rows[i];
      if (row.__depth > 0) {
        continue;
      }
      sum += rowHeight(rows[i]);
      count++;
    }
    return sum / count;
  }, [rows, rowHeight, enabled]);

  const smallPagination = useMemo(() => enabled && width < TABLE.PAGINATION_LIMIT, [enabled, width]);

  // using dimensions of the panel, calculate pagination parameters
  const { numPages, rowsPerPage, pageRangeStart, pageRangeEnd } = useMemo((): {
    numPages: number;
    rowsPerPage: number;
    pageRangeStart: number;
    pageRangeEnd: number;
  } => {
    if (!enabled) {
      return { numPages: 0, rowsPerPage: 0, pageRangeStart: 1, pageRangeEnd: numRows };
    }

    // a user-configured page size takes precedence; otherwise derive rowsPerPage from the height stack
    let rowsPerPage: number;
    if (pageSize != null && pageSize > 0) {
      // ensure at least one row per page so a fractional size in (0, 1) doesn't floor to 0
      rowsPerPage = Math.max(1, Math.floor(pageSize));
    } else {
      const rowAreaHeight = height - headerHeight - footerHeight - PAGINATION_HEIGHT;
      const heightPerRow = Math.floor(rowAreaHeight / (avgRowHeight || 1));
      // ensure at least one row per page is displayed
      rowsPerPage = heightPerRow > 1 ? heightPerRow : 1;
    }

    // calculate row range for pagination summary display
    const pageRangeStart = page * rowsPerPage + 1;
    let pageRangeEnd = pageRangeStart + rowsPerPage - 1;
    if (pageRangeEnd > numRows) {
      pageRangeEnd = numRows;
    }

    const numPages = Math.ceil(numRows / rowsPerPage);
    return {
      numPages,
      rowsPerPage,
      pageRangeStart,
      pageRangeEnd,
    };
  }, [height, headerHeight, footerHeight, avgRowHeight, enabled, numRows, page, pageSize]);

  // safeguard against page overflow on panel resize or other factors
  useLayoutEffect(() => {
    if (!enabled) {
      return;
    }

    // valid page indices are 0..numPages-1, so anything at or past numPages overflows
    if (page > numPages - 1) {
      // resets pagination to the last valid page
      setPage(Math.max(0, numPages - 1));
    }
  }, [numPages, enabled, page, setPage]);

  // apply pagination to the sorted rows
  const paginatedRows = useMemo(() => {
    if (!enabled) {
      return rows;
    }

    const result = [];
    const pageOffset = page * rowsPerPage;

    let count = hasNestedFrames ? -1 * pageOffset : 0;
    let i = hasNestedFrames ? 0 : pageOffset;
    while (count <= rowsPerPage && i < rows.length) {
      const currRow = rows[i];
      i++;

      if (currRow.__depth === 0) {
        count++;
      }
      if (count >= 1 && count <= rowsPerPage) {
        result.push(currRow);
      }
    }

    return result;
  }, [page, rowsPerPage, rows, enabled, hasNestedFrames]);

  return {
    rows: paginatedRows,
    page: enabled ? page : -1,
    numRows,
    setPage,
    numPages,
    rowsPerPage,
    pageRangeStart,
    pageRangeEnd,
    smallPagination,
  };
}

export const useRowCompiler = (dataFrame: DataFrame, nestedFramesFieldName?: string) => {
  const orderedFieldNames = useMemo(() => dataFrame.fields.map(getDisplayName), [dataFrame]);
  const stringified = useMemo(() => JSON.stringify(orderedFieldNames), [orderedFieldNames]);
  return useMemo(
    () => compileFrameToRecords(orderedFieldNames, nestedFramesFieldName),
    [stringified, nestedFramesFieldName] // eslint-disable-line react-hooks/exhaustive-deps
  );
};

export const useNestedRows = (
  rows: TableRow[],
  nestedData: DataFrame[] | undefined,
  hasNestedFrames: boolean,
  nestedFramesFieldName: string | undefined,
  filter: FilterType,
  sortColumns: SortColumn[]
): NestedRowEntry[] => {
  const frameToRecords = useRowCompiler(nestedData?.[0] ?? createDataFrame({ fields: [] }));

  return useMemo(() => {
    const result: NestedRowEntry[] = [];
    if (!hasNestedFrames || !nestedFramesFieldName || !frameToRecords || !nestedData) {
      return result;
    }

    for (const parentRow of rows) {
      // Type guard to check if data exists as it's optional
      const nestedFrame = nestedData[parentRow.__index];
      if (!nestedFrame) {
        continue;
      }

      const rawRows = frameToRecords(nestedFrame, parentRow.__index);
      const filterResult = applyFilter(rawRows, filter, nestedFrame.fields, false, parentRow.__index);
      const sortedRows = applySort(
        filterResult.filteredRows,
        nestedFrame.fields,
        sortColumns,
        getColumnTypes(nestedFrame.fields)
      );
      result[parentRow.__index] = { raw: rawRows, final: sortedRows, filterResult };
    }

    return result;
  }, [hasNestedFrames, nestedFramesFieldName, rows, sortColumns, filter, frameToRecords, nestedData]);
};

interface UseHeaderHeightOptions {
  enabled: boolean;
  fields: Field[];
  columnWidths: number[];
  typographyCtx: TypographyCtx;
  showTypeIcons?: boolean;
}

export function useHeaderHeight({
  fields,
  enabled,
  columnWidths,
  typographyCtx,
  showTypeIcons = false,
}: UseHeaderHeightOptions): number {
  const measurers = useMemo(() => buildHeaderHeightMeasurers(fields, typographyCtx), [fields, typographyCtx]);

  const columnAvailableWidths = useMemo(
    () =>
      columnWidths.map((c, idx) => {
        if (idx >= fields.length) {
          return 0; // no width available for this column yet
        }

        let width = c - CELL_HORIZONTAL_CHROME;
        const field = fields[idx];

        // filtering icon
        if (field.config?.custom?.filterable) {
          width -= HEADER_ICON_SPACE;
        }
        // sorting icon. reserved on every sortable column, not just the currently-sorted one, so a
        // wrapped header doesn't gain a line (shifting the whole grid down) the moment it's sorted.
        if (isSortableField(field)) {
          width -= HEADER_ICON_SPACE;
        }
        // type icon
        if (showTypeIcons) {
          width -= HEADER_ICON_SPACE;
        }
        // sadly, the math for this is off by exactly 1 pixel. shrug.
        return Math.floor(width) - 1;
      }),
    [fields, columnWidths, showTypeIcons]
  );

  const headerHeight = useMemo(() => {
    if (!enabled) {
      return 0;
    }
    return getRowHeight(
      fields,
      { __index: -1, __depth: 0 },
      columnAvailableWidths,
      TABLE.HEADER_HEIGHT,
      measurers,
      TABLE.LINE_HEIGHT,
      TABLE.CELL_PADDING
    );
  }, [fields, enabled, columnAvailableWidths, measurers]);

  return headerHeight;
}

interface UseRowHeightOptions {
  columnWidths: number[];
  fields: Field[];
  hasNestedFrames: boolean;
  defaultHeight: NonNullable<CSSProperties['height']>;
  defaultNestedHeight: NonNullable<CSSProperties['height']>;
  visibleNestedRowCounts: Array<number | null>;
  typographyCtx: TypographyCtx;
  maxHeight?: number;
  nestedData?: DataFrame[] | undefined;
  nestedRows: NestedRowEntry[];
  nestedFields: Field[];
  nestedColWidths: number[];
  nestedFooterHeight?: number;
}

const getTrueColWidths = (cw: number[]): number[] => cw.map((c) => c - CELL_HORIZONTAL_CHROME);

// TODO: maybe there's a way to decouple the nested rows from the top-level rows here.
export function useRowHeight({
  columnWidths,
  fields,
  defaultHeight,
  defaultNestedHeight,
  typographyCtx,
  maxHeight,
  hasNestedFrames,
  nestedData,
  nestedRows,
  nestedFields,
  nestedColWidths,
  visibleNestedRowCounts,
  nestedFooterHeight = 0,
}: UseRowHeightOptions): NonNullable<CSSProperties['height']> | ((row: TableRow) => number) {
  const nestedMeasurers = useMemo(
    () => buildCellHeightMeasurers(nestedFields, typographyCtx, maxHeight),
    [nestedFields, typographyCtx, maxHeight]
  );

  const totalParentWidth = useMemo(() => columnWidths.reduce((acc, width) => acc + width, 0), [columnWidths]);
  const totalNestedWidth = useMemo(() => nestedColWidths.reduce((acc, width) => acc + width, 0), [nestedColWidths]);
  const nestedHasOverflow = useMemo(() => totalParentWidth < totalNestedWidth, [totalParentWidth, totalNestedWidth]);

  const getNestedRowHeightWithCache = useMemo(() => {
    if (typeof defaultNestedHeight === 'string') {
      return () => 0;
    }

    if ((nestedMeasurers?.length ?? 0) === 0) {
      return () => defaultNestedHeight;
    }

    const nestedRowCache: Array<number[] | undefined> = visibleNestedRowCounts.map((count) =>
      count == null ? undefined : Array(count)
    );

    return (row: TableRow) => {
      if (row.__parentIndex == null) {
        return 0;
      }

      const nestedRowCacheEntry = nestedRowCache[row.__parentIndex];
      if (nestedRowCacheEntry == null) {
        return 0;
      }

      const trueNestedColWidths = getTrueColWidths(nestedColWidths);
      let result = nestedRowCacheEntry[row.__index];
      if (result == null) {
        result = nestedRowCacheEntry[row.__index] = getRowHeight(
          nestedFields,
          row,
          trueNestedColWidths,
          defaultNestedHeight,
          nestedMeasurers
        );
      }
      return result;
    };
  }, [nestedFields, nestedColWidths, defaultNestedHeight, nestedMeasurers, visibleNestedRowCounts]);

  const measurers = useMemo(
    () => buildCellHeightMeasurers(fields, typographyCtx, maxHeight),
    [fields, typographyCtx, maxHeight]
  );
  const hasWrappedCols = (measurers?.length ?? 0) > 0;

  const getRowHeightWithCache = useMemo(() => {
    if (typeof defaultHeight === 'string') {
      return () => 0;
    }

    if (!hasWrappedCols) {
      return () => defaultHeight;
    }

    const trueColWidths = getTrueColWidths(columnWidths);
    const cache: Array<number | undefined> = Array(fields[0].values.length);
    return (row: TableRow) => {
      let result = cache[row.__index];
      if (result == null) {
        result = cache[row.__index] = getRowHeight(fields, row, trueColWidths, defaultHeight, measurers);
      }
      return result;
    };
  }, [fields, columnWidths, defaultHeight, measurers, hasWrappedCols]);

  const rowHeight = useMemo(() => {
    // row height is only complicated when there are nested frames or wrapped columns.
    if (typeof defaultHeight === 'string' || !(hasWrappedCols || hasNestedFrames)) {
      return defaultHeight;
    }

    if (typeof defaultNestedHeight === 'string') {
      return defaultNestedHeight;
    }

    return (row: TableRow): number => {
      // nested rows
      if (row.__depth > 0) {
        // if unexpanded, height === 0
        const visibleNestedRowCount = visibleNestedRowCounts[row.__index];
        if (visibleNestedRowCount == null) {
          return 0;
        }

        // if expanded with no rows, height === no data height
        if (visibleNestedRowCount === 0) {
          return TABLE.NESTED_NO_DATA_HEIGHT + TABLE.CELL_PADDING * 2 + nestedFooterHeight;
        }

        const nestedHeaderHeight = nestedData?.[row.__index]?.meta?.custom?.noHeader ? 0 : defaultNestedHeight;
        const nestedRowsHeight = nestedRows[row.__index].final.reduce(
          (acc, row) => acc + getNestedRowHeightWithCache(row),
          0
        );
        const scrollbarHeight = nestedHasOverflow ? TABLE.SCROLLBAR_AFFORDANCE : 0;
        return nestedRowsHeight + nestedHeaderHeight + nestedFooterHeight + TABLE.CELL_PADDING * 2 + scrollbarHeight;
      }

      return row.__parentIndex != null ? getNestedRowHeightWithCache(row) : getRowHeightWithCache(row);
    };
  }, [
    getNestedRowHeightWithCache,
    getRowHeightWithCache,
    defaultHeight,
    defaultNestedHeight,
    hasNestedFrames,
    hasWrappedCols,
    nestedFooterHeight,
    nestedHasOverflow,
    nestedRows,
    nestedData,
    visibleNestedRowCounts,
  ]);

  return rowHeight;
}

interface UseFlatRowHeightOptions {
  columnWidths: number[];
  fields: Field[];
  defaultHeight: NonNullable<CSSProperties['height']>;
  typographyCtx: TypographyCtx;
  maxHeight?: number;
}

/**
 * Simplified row height hook for flat (non-nested) tables.
 * Unlike `useRowHeight`, this does not handle nested frame rows.
 */
export function useFlatRowHeight({
  columnWidths,
  fields,
  defaultHeight,
  typographyCtx,
  maxHeight,
}: UseFlatRowHeightOptions): NonNullable<CSSProperties['height']> | ((row: TableRow) => number) {
  const measurers = useMemo(
    () => buildCellHeightMeasurers(fields, typographyCtx, maxHeight),
    [fields, typographyCtx, maxHeight]
  );
  const hasWrappedCols = (measurers?.length ?? 0) > 0;

  return useMemo(() => {
    if (typeof defaultHeight === 'string' || !hasWrappedCols) {
      return defaultHeight;
    }

    const trueColWidths = getTrueColWidths(columnWidths);
    const cache: Array<number | undefined> = Array(fields[0]?.values.length ?? 0);
    return (row: TableRow) => {
      let result = cache[row.__index];
      if (result == null) {
        result = cache[row.__index] = getRowHeight(fields, row, trueColWidths, defaultHeight, measurers);
      }
      return result;
    };
  }, [fields, columnWidths, defaultHeight, measurers, hasWrappedCols]);
}

/**
 * react-data-grid is a little unwieldy when it comes to column resize events.
 * we want to detect a few different column resize signals:
 *   - dragging the handle (only want to dispatch when handle is released)
 *   - double-clicking the handle (sets the column to the minimum width to fit content)
 * `onColumnResize` dispatches events throughout a dragged resize, and `onColumnWidthsChanged` doesn't
 * emit an event when double-click resizing occurs, so we have to build something custom on top of these
 * behaviors in order to get everything working.
 */
interface UseColumnResizeState {
  columnKey: string | undefined;
  width: number;
  fieldScope?: MatcherScope;
}

const INITIAL_COL_RESIZE_STATE = Object.freeze({ columnKey: undefined, width: 0 }) satisfies UseColumnResizeState;

export function useColumnResize(
  onColumnResize: TableColumnResizeActionCallback = () => {},
  fieldScope?: MatcherScope
): DataGridProps<TableRow, TableSummaryRow>['onColumnResize'] {
  // these must be refs. if we used setState, we would run into race conditions with these event listeners
  const colResizeState = useRef<UseColumnResizeState>({ ...INITIAL_COL_RESIZE_STATE });
  const pointerIsDown = useRef(false);

  // to detect whether we got a double-click resize, we track whether the pointer is currently down
  useLayoutEffect(() => {
    function pointerDown(_event: PointerEvent) {
      pointerIsDown.current = true;
    }

    function pointerUp(_event: PointerEvent) {
      pointerIsDown.current = false;
    }

    window.addEventListener('pointerdown', pointerDown);
    window.addEventListener('pointerup', pointerUp);

    return () => {
      window.removeEventListener('pointerdown', pointerDown);
      window.removeEventListener('pointerup', pointerUp);
    };
  });

  const dispatchEvent = useCallback(() => {
    if (colResizeState.current.columnKey) {
      onColumnResize(
        colResizeState.current.columnKey,
        Math.floor(colResizeState.current.width),
        colResizeState.current.fieldScope
      );
      colResizeState.current = { ...INITIAL_COL_RESIZE_STATE };
    }
    window.removeEventListener('click', dispatchEvent, { capture: true });
  }, [onColumnResize]);

  // this is the callback that gets passed to react-data-grid
  const dataGridResizeHandler = useCallback(
    (column: Column<TableRow, TableSummaryRow>, width: number) => {
      if (!colResizeState.current.columnKey) {
        window.addEventListener('click', dispatchEvent, { capture: true });
      }

      colResizeState.current.columnKey = column.key;
      colResizeState.current.width = width;

      if (fieldScope) {
        colResizeState.current.fieldScope = fieldScope;
      }

      // when double clicking to resize, this handler will fire, but the pointer will not be down,
      // meaning that we should immediately flush the new width
      if (!pointerIsDown.current) {
        dispatchEvent();
      }
    },
    [fieldScope, dispatchEvent]
  );

  return dataGridResizeHandler;
}

export function useScrollbarWidth(ref: RefObject<DataGridHandle | null>, height: number) {
  const [scrollbarWidth, setScrollbarWidth] = useState(0);

  const updateScrollbarDimensions = debounce(() => {
    const el = ref.current?.element;
    if (el) {
      setScrollbarWidth(el!.offsetWidth - el!.clientWidth);
    }
  }, 150);

  useLayoutEffect(() => {
    const el = ref.current?.element;
    if (!el || IS_SAFARI_26) {
      return;
    }

    updateScrollbarDimensions();

    const resizeObserver = new ResizeObserver(updateScrollbarDimensions);
    resizeObserver.observe(el);
    return () => {
      resizeObserver.disconnect();
    };
  }, [ref, height, updateScrollbarDimensions]);

  return scrollbarWidth;
}

/**
 * When present, columns without a configured width are sized to fit their content
 * ({@link computeContentAwareColWidths}) rather than sharing the leftover space evenly. Gated by
 * the `table.autoColumnWidths` feature toggle and threaded down as a prop.
 */
export interface ContentAwareWidths {
  typographyCtx: TypographyCtx;
  headerTypographyCtx: TypographyCtx;
  showTypeIcons?: boolean;
  getActions?: GetActionsFunctionLocal;
}

const pickColWidths = (fields: Field[], availWidth: number, contentAware?: ContentAwareWidths): number[] =>
  contentAware ? computeContentAwareColWidths(fields, availWidth, contentAware) : computeColWidths(fields, availWidth);

/**
 * Builds the typography context the table uses to measure text (row heights, header heights). Shared
 * by the flat and nested tables so the memoization lives in one place.
 */
export function useTypographyCtx(theme: GrafanaTheme2): TypographyCtx {
  return useMemo(
    () =>
      createTypographyContext(
        theme.typography.fontSize,
        theme.typography.fontFamily,
        extractPixelValue(theme.typography.body.letterSpacing!) * theme.typography.fontSize
      ),
    [theme]
  );
}

interface UseContentAwareWidthsOptions {
  enabled: boolean;
  typographyCtx: TypographyCtx;
  showTypeIcons?: boolean;
  getActions?: GetActionsFunctionLocal;
}

/**
 * Assembles the {@link ContentAwareWidths} options for the column width hooks, or `undefined` when
 * content-aware widths are disabled. Header labels render at medium weight, so they are measured
 * with a separate typography context.
 */
export function useContentAwareWidths({
  enabled,
  typographyCtx,
  showTypeIcons = false,
  getActions,
}: UseContentAwareWidthsOptions): ContentAwareWidths | undefined {
  const theme = useTheme2();
  const headerTypographyCtx = useMemo(
    () =>
      createTypographyContext(
        theme.typography.fontSize,
        theme.typography.fontFamily,
        extractPixelValue(theme.typography.body.letterSpacing!) * theme.typography.fontSize,
        theme.typography.fontWeightMedium
      ),
    [theme]
  );
  return useMemo(
    () =>
      enabled
        ? {
            typographyCtx,
            headerTypographyCtx,
            showTypeIcons,
            getActions,
          }
        : undefined,
    [enabled, typographyCtx, headerTypographyCtx, showTypeIcons, getActions]
  );
}

interface UseNestedColWidthsOptions {
  nestedVisibleFields: Field[];
  availableWidth: number;
  structureRev?: number;
  contentAware?: ContentAwareWidths;
}

interface UseNestedColWidthsResult {
  nestedFieldWidths: number[];
  nestedColWidths: ColumnWidths;
  handleNestedColumnWidthsChange: (newColWidths: ColumnWidths) => void;
}

/**
 * Manages per-column widths for nested tables.
 */
export function useNestedColWidths({
  nestedVisibleFields,
  availableWidth,
  structureRev,
  contentAware,
}: UseNestedColWidthsOptions): UseNestedColWidthsResult {
  // before we do anything, figure out what the widths are based on the panel configuration.
  const configuredWidths = useMemo(
    () => pickColWidths(nestedVisibleFields, availableWidth, contentAware),
    [nestedVisibleFields, availableWidth, contentAware]
  );

  const [nestedFieldWidths, setNestedFieldWidths] = useState(() => configuredWidths);
  // Previous config-derived widths, so we can tell which columns actually changed upstream.
  const prevConfiguredWidths = useRef(configuredWidths);

  // Re-sync from config-derived widths whenever they change — structure changes and, crucially,
  // panel resize (availableWidth feeds configuredWidths), so content-aware auto columns re-flow to
  // the new width. We adopt a column's new width only when its *config-derived* width changed; a
  // column that changed only locally (an in-progress manual drag, which persists to field config
  // later on pointer-up) keeps its local width, so an interleaved resize doesn't clobber the drag.
  useEffect(() => {
    const prevConfigured = prevConfiguredWidths.current;
    prevConfiguredWidths.current = configuredWidths;
    setNestedFieldWidths((current) => {
      if (current.length !== configuredWidths.length) {
        return configuredWidths;
      }
      let changed = false;
      const next = current.map((width, i) => {
        if (configuredWidths[i] !== prevConfigured[i]) {
          changed = changed || width !== configuredWidths[i];
          return configuredWidths[i];
        }
        return width;
      });
      return changed ? next : current;
    });
  }, [configuredWidths, structureRev]);

  // this is the representation that react-data-grid wants, which we derive from the source of truth (nestedFieldWidths) on every render
  const nestedColWidths = useMemo(
    () => buildNestedColumnWidthsMap(nestedVisibleFields, nestedFieldWidths),
    [nestedVisibleFields, nestedFieldWidths]
  );

  const handleNestedColumnWidthsChange = useCallback(
    (newColWidths: ColumnWidths) => {
      setNestedFieldWidths(
        nestedVisibleFields.map((f, idx) => {
          const entry = newColWidths.get(getDisplayName(f));
          // ColumnWidth always has a width property (both 'resized' and 'measured' variants)
          return entry != null ? entry.width : nestedFieldWidths[idx];
        })
      );
    },
    [nestedVisibleFields, nestedFieldWidths]
  );

  return { nestedFieldWidths, nestedColWidths, handleNestedColumnWidthsChange };
}

export function useColWidths(
  visibleFields: Field[],
  availableWidth: number,
  frozenColumns?: number,
  resetKey?: Symbol,
  contentAware?: ContentAwareWidths
): [number[], number] {
  const widths = useMemo(
    () => pickColWidths(visibleFields, availableWidth, contentAware),
    // Width override removals can mutate width config onto existing field objects.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [visibleFields, availableWidth, resetKey, contentAware]
  );

  // this is to avoid buggy situations where all visible columns are frozen
  const numFrozenColsFullyInView = useMemo(() => {
    if (!frozenColumns || frozenColumns <= 0) {
      return -1;
    }

    const fullyVisibleCols = widths.reduce(
      ([count, remainingWidth], nextWidth) => {
        if (remainingWidth - nextWidth >= 0) {
          return [count + 1, remainingWidth - nextWidth];
        }
        return [count, 0];
      },
      [0, availableWidth]
    )[0];

    // de-noise memoized changes to the columns array, and only change this
    // number when the number of frozen columns changes or once there are fewer
    // visible columns than the number of frozen columns.
    return Math.min(fullyVisibleCols, frozenColumns);
  }, [widths, availableWidth, frozenColumns]);

  return [widths, numFrozenColsFullyInView];
}

const isReducer = (maybeReducer: string): maybeReducer is ReducerID => maybeReducer in ReducerID;
const nonMathReducers = new Set<ReducerID>([
  ReducerID.allValues,
  ReducerID.changeCount,
  ReducerID.count,
  ReducerID.countAll,
  ReducerID.distinctCount,
  ReducerID.first,
  ReducerID.firstNotNull,
  ReducerID.last,
  ReducerID.lastNotNull,
  ReducerID.uniqueValues,
]);
const isNonMathReducer = (reducer: string) => isReducer(reducer) && nonMathReducers.has(reducer);
const noFormattingReducers = new Set<ReducerID>([ReducerID.count, ReducerID.countAll]);
const shouldReducerSkipFormatting = (reducer: string) => isReducer(reducer) && noFormattingReducers.has(reducer);

export const useReducerEntries = (
  field: Field,
  rows: TableRow[],
  displayName: string,
  colIdx: number
): Array<[string, string | null]> => {
  return useMemo(() => {
    const reducers: string[] = field.config.custom?.footer?.reducers ?? [];

    if (
      reducers.length === 0 ||
      (field.type !== FieldType.number && reducers.every((reducerId) => !isNonMathReducer(reducerId)))
    ) {
      return [];
    }

    // Create a new state object that matches the original behavior exactly
    const newState: FooterFieldState = {
      lastProcessedRowCount: 0,
      ...(field.state || {}), // Preserve any existing state properties
    };

    // Assign back to field
    field.state = newState;

    const currentRowCount = rows.length;
    const lastRowCount = newState.lastProcessedRowCount;

    // Check if we need to invalidate the cache
    if (lastRowCount !== currentRowCount) {
      // Cache should be invalidated as row count has changed
      if (newState.calcs) {
        delete newState.calcs;
      }
      // Update the row count tracker
      newState.lastProcessedRowCount = currentRowCount;
    }

    // Calculate all specified reducers
    const results: Record<string, number | null> = reduceField({
      field: {
        ...field,
        values: rows.map((row) => row[displayName]),
      },
      reducers,
    });

    return reducers.map((reducerId) => {
      if (
        results[reducerId] === undefined ||
        // For non-number fields, only show special count reducers
        (field.type !== FieldType.number && !isNonMathReducer(reducerId)) ||
        // for countAll, only show the reducer in the first column
        (reducerId === ReducerID.countAll && colIdx !== 0)
      ) {
        return [reducerId, null];
      }

      const value = results[reducerId];
      let result = null;
      if (!shouldReducerSkipFormatting(reducerId) && field.display) {
        result = formattedValueToString(field.display(value));
      } else if (value != null) {
        result = String(value);
      }

      return [reducerId, result];
    });
  }, [field, rows, displayName, colIdx]);
};
