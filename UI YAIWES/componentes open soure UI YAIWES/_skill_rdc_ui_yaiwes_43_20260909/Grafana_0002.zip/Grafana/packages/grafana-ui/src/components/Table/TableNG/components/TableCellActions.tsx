import { memo } from 'react';

import { selectors } from '@grafana/e2e-selectors';
import { t } from '@grafana/i18n';

import { IconButton } from '../../../IconButton/IconButton';
import { useOpenLayersContext } from '../../geo';
import { FILTER_FOR_OPERATOR, FILTER_OUT_OPERATOR, type TableCellActionsProps } from '../types';
import { buildInspectValue } from '../utils';

export const TableCellActions = memo(
  ({ field, value, setInspectCell, onCellFilterAdded, className, cellInspect, showFilters }: TableCellActionsProps) => {
    const { formatGeometry } = useOpenLayersContext();

    return (
      // stopping propagation to prevent clicks within the actions menu from triggering the cell click events
      // for things like the data links tooltip.
      // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
      <div className={className} onClick={(ev) => ev.stopPropagation()}>
        {cellInspect && (
          <IconButton
            name="eye"
            data-testid={selectors.components.Panels.Visualization.TableNG.cellActions.inspectButton}
            aria-label={t('grafana-ui.table.cell-inspect-tooltip', 'Inspect value')}
            onClick={() => {
              const [inspectValue, mode] = buildInspectValue(value, field, formatGeometry);
              setInspectCell({ value: inspectValue, mode });
            }}
          />
        )}
        {showFilters && (
          <>
            <IconButton
              name={'filter-plus'}
              data-testid={selectors.components.Panels.Visualization.TableNG.cellActions.filterForButton}
              aria-label={t('grafana-ui.table.cell-filter-on', 'Filter for value')}
              onClick={() => {
                onCellFilterAdded?.({
                  key: field.name,
                  operator: FILTER_FOR_OPERATOR,
                  value: String(value ?? ''),
                });
              }}
            />
            <IconButton
              name={'filter-minus'}
              data-testid={selectors.components.Panels.Visualization.TableNG.cellActions.filterOutButton}
              aria-label={t('grafana-ui.table.cell-filter-out', 'Filter out value')}
              onClick={() => {
                onCellFilterAdded?.({
                  key: field.name,
                  operator: FILTER_OUT_OPERATOR,
                  value: String(value ?? ''),
                });
              }}
            />
          </>
        )}
      </div>
    );
  }
);
TableCellActions.displayName = 'TableCellActions';
