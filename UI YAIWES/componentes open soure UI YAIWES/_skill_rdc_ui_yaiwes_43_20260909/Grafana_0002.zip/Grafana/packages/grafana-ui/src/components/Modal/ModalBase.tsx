import { cx } from '@emotion/css';
import { FloatingFocusManager, useDismiss, useFloating, useInteractions, useRole } from '@floating-ui/react';
import { OverlayContainer } from '@react-aria/overlays';
import { type ComponentProps, type PropsWithChildren, useRef } from 'react';
import { CSSTransition } from 'react-transition-group';

import { useStyles2, useTheme2 } from '../../themes/ThemeContext';
import { getPortalContainer } from '../Portal/Portal';

import { getModalStyles } from './getModalStyles';

export interface ModalBaseProps {
  className?: string;
  closeOnEscape?: boolean;
  closeOnBackdropClick?: boolean;
  trapFocus?: boolean;
  /**
   * What receives focus when the modal opens: an index into the modal's
   * tabbable elements, or a ref to the element itself. Defaults to the first
   * tabbable element, which is usually the close button. Pass a negative number
   * to leave focus alone — for content that focuses itself, such as an input
   * that autofocuses on mount. The focus trap stays active either way.
   */
  initialFocus?: ComponentProps<typeof FloatingFocusManager>['initialFocus'];
  isOpen?: boolean;
  onDismiss?: () => void;
  onClickBackdrop?: () => void;
  'aria-label'?: string;
  'aria-labelledby'?: string;
}

export function ModalBase({
  children,
  className,
  isOpen = false,
  closeOnEscape = true,
  closeOnBackdropClick = false,
  trapFocus = true,
  initialFocus,
  onDismiss,
  onClickBackdrop,
  'aria-label': ariaLabel,
  'aria-labelledby': ariaLabelledBy,
}: PropsWithChildren<ModalBaseProps>) {
  const styles = useStyles2(getModalStyles);
  const theme = useTheme2();
  const backdropRef = useRef<HTMLDivElement>(null);

  const { context, refs } = useFloating({
    open: isOpen,
    onOpenChange: (open) => {
      if (!open) {
        onDismiss?.();
      }
    },
  });

  const dismiss = useDismiss(context, {
    escapeKey: closeOnEscape,
    outsidePress: (event) => {
      // The portal container is "inside" the modal (see getInsideElements below), so presses
      // there must not dismiss it — except on the backdrop, which also renders there.
      const target = event.target instanceof Node ? event.target : null;
      const portalContainer = getPortalContainer();
      if (
        target &&
        portalContainer !== document.body &&
        portalContainer.contains(target) &&
        !backdropRef.current?.contains(target)
      ) {
        return false;
      }
      if (onClickBackdrop) {
        onClickBackdrop();
        return false;
      }
      return closeOnBackdropClick;
    },
  });

  const role = useRole(context, {
    role: 'dialog',
  });

  const { getFloatingProps } = useInteractions([dismiss, role]);

  if (!isOpen) {
    return null;
  }

  return (
    <OverlayContainer>
      <CSSTransition
        nodeRef={backdropRef}
        in={true}
        appear={true}
        timeout={theme.transitions.duration.standard}
        classNames={{ appear: styles.modalBackdropAppear, appearActive: styles.modalBackdropActive }}
      >
        <div role="presentation" ref={backdropRef} className={styles.modalBackdrop} />
      </CSSTransition>
      <FloatingFocusManager
        context={context}
        modal={trapFocus}
        initialFocus={initialFocus}
        getInsideElements={() => [getPortalContainer()]}
      >
        <CSSTransition
          nodeRef={refs.floating}
          in={true}
          appear={true}
          timeout={theme.transitions.duration.shortest}
          classNames={{ appear: styles.modalAppear, appearActive: styles.modalAppearActive }}
        >
          <div
            className={cx(styles.modal, className)}
            ref={refs.setFloating}
            aria-label={ariaLabel}
            aria-labelledby={ariaLabelledBy}
            {...getFloatingProps()}
          >
            {children}
          </div>
        </CSSTransition>
      </FloatingFocusManager>
    </OverlayContainer>
  );
}
