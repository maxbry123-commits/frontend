import { css } from '@emotion/css';

import { type GrafanaTheme2, locale } from '@grafana/data';

import { useStyles2 } from '../../themes/ThemeContext';

type CounterVariant = 'primary' | 'secondary';
export interface CounterProps {
  value: number;
  variant?: CounterVariant;
  /** When provided and value exceeds it, renders "{cappedAt}+" instead of the exact value. */
  cappedAt?: number;
}

export const Counter = ({ value, variant = 'secondary', cappedAt }: CounterProps) => {
  const styles = useStyles2(getStyles, variant);
  const isCapped = cappedAt !== undefined && value > cappedAt;

  return <span className={styles.counter}>{isCapped ? `${locale(cappedAt, 0).text}+` : locale(value, 0).text}</span>;
};

const getStyles = (theme: GrafanaTheme2, variant: CounterVariant) => ({
  counter: css({
    label: 'counter',
    marginLeft: theme.spacing(1),
    borderRadius: theme.spacing(3),
    backgroundColor: variant === 'primary' ? theme.colors.primary.main : theme.colors.secondary.main,
    padding: theme.spacing(0.25, 1),
    color: theme.colors.text.secondary,
    fontWeight: theme.typography.fontWeightMedium,
    fontSize: theme.typography.size.sm,
  }),
});
