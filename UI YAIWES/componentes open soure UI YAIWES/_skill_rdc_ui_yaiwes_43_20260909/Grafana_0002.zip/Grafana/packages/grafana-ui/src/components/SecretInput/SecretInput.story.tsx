import { type StoryFn, type Meta } from '@storybook/react-webpack5';
import { useState, type ChangeEvent } from 'react';

import { Field } from '../Forms/Field';

import { SecretInput } from './SecretInput';
import mdx from './SecretInput.mdx';

const meta: Meta<typeof SecretInput> = {
  title: 'Inputs/SecretInput',
  component: SecretInput,
  parameters: {
    docs: {
      page: mdx,
    },
    controls: {
      exclude: [
        'prefix',
        'suffix',
        'addonBefore',
        'addonAfter',
        'type',
        'disabled',
        'invalid',
        'loading',
        'before',
        'after',
      ],
    },
  },
  args: {
    width: 50,
    placeholder: 'Enter your secret...',
  },
  argTypes: {
    width: { control: { type: 'range', min: 10, max: 200, step: 10 } },
  },
};

export default meta;

const Template: StoryFn<typeof SecretInput> = (args) => {
  const [secret, setSecret] = useState('');

  return (
    <Field label="Your secret password">
      <SecretInput
        width={args.width}
        value={secret}
        isConfigured={args.isConfigured}
        revealable={args.revealable}
        placeholder={args.placeholder}
        onChange={(event: ChangeEvent<HTMLInputElement>) => setSecret(event.target.value.trim())}
        onReset={() => setSecret('')}
      />
    </Field>
  );
};

export const basic = Template.bind({});

basic.args = {
  isConfigured: false,
  revealable: false,
};

export const revealable = Template.bind({});

revealable.args = {
  isConfigured: false,
  revealable: true,
};

export const secretIsConfigured = Template.bind({});

secretIsConfigured.args = {
  isConfigured: true,
};
