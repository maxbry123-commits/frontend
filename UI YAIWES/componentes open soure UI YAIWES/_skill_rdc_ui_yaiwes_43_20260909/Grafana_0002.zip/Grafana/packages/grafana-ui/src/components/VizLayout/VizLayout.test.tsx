import { render, screen } from '@testing-library/react';

import { selectors } from '@grafana/e2e-selectors';

import { VizLayout } from './VizLayout';

jest.mock('react-use', () => ({
  ...jest.requireActual('react-use'),
  useMeasure: jest.fn(),
}));

// eslint-disable-next-line @typescript-eslint/no-require-imports
const mockUseMeasure: jest.Mock = require('react-use').useMeasure;

const noMeasure = { width: 0, height: 0, top: 0, left: 0, bottom: 0, right: 0, x: 0, y: 0 };

describe('VizLayout', () => {
  beforeEach(() => {
    mockUseMeasure.mockReturnValue([jest.fn(), noMeasure]);
    Object.defineProperty(document.body, 'clientWidth', { value: 2000, configurable: true });
  });

  afterEach(() => {
    Object.defineProperty(document.body, 'clientWidth', { value: 0, configurable: true });
  });

  describe('without legend', () => {
    it('renders container with correct testid', () => {
      render(
        <VizLayout width={800} height={600}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toBeInTheDocument();
    });

    it('applies width and height as inline styles on the container', () => {
      render(
        <VizLayout width={400} height={300}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toHaveStyle({
        width: '400px',
        height: '300px',
      });
    });

    it('calls children render prop with full width and height', () => {
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600}>
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(800, 600);
    });

    it('does not render the legend testid', () => {
      render(
        <VizLayout width={800} height={600}>
          {() => null}
        </VizLayout>
      );
      expect(screen.queryByTestId(selectors.components.VizLayout.legend)).not.toBeInTheDocument();
    });
  });

  describe('with null legend', () => {
    it('renders like no-legend when legend is null', () => {
      render(
        <VizLayout width={800} height={600} legend={null}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toBeInTheDocument();
      expect(screen.queryByTestId(selectors.components.VizLayout.legend)).not.toBeInTheDocument();
    });
  });

  describe('with bottom legend', () => {
    const legend = (
      <VizLayout.Legend placement="bottom">
        <div>legend content</div>
      </VizLayout.Legend>
    );

    it('renders legend with correct testid', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.legend)).toBeInTheDocument();
    });

    it('sets flexDirection column on the container', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toHaveStyle({ flexDirection: 'column' });
    });

    it('applies custom maxHeight to the legend element', () => {
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="bottom" maxHeight="20%">
              <div />
            </VizLayout.Legend>
          }
        >
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.legend)).toHaveStyle({ maxHeight: '20%' });
    });

    it('does not force full height on the scroll container', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      const scrollBox = screen.getByTestId(selectors.components.VizLayout.legend).firstElementChild;
      expect(scrollBox).not.toHaveStyle({ height: '100%' });
    });

    it('does not call children before the legend height is measured', () => {
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {children}
        </VizLayout>
      );
      expect(children).not.toHaveBeenCalled();
    });

    it('calls children with reduced height once legend is measured', () => {
      mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, height: 100 }]);
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(800, 500);
    });

    it('preserves full height when legend height equals container height', () => {
      mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, height: 600 }]);
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(800, 600);
    });
  });

  describe('with right legend', () => {
    const legend = (
      <VizLayout.Legend placement="right">
        <div>legend content</div>
      </VizLayout.Legend>
    );

    it('renders legend with correct testid', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.legend)).toBeInTheDocument();
    });

    it('sets flexDirection row on the container', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toHaveStyle({ flexDirection: 'row' });
    });

    it('applies custom maxWidth to the legend element', () => {
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="right" maxWidth="30%">
              <div />
            </VizLayout.Legend>
          }
        >
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.legend)).toHaveStyle({ maxWidth: '30%' });
    });

    it('calls children with reduced width once legend is measured', () => {
      mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, width: 150 }]);
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(650, 600);
    });

    it('calls children with reduced width when an explicit legend width prop is set', () => {
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="right" width={200}>
              <div />
            </VizLayout.Legend>
          }
        >
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(600, 600);
    });

    it('prefers the measured legend width over the width prop once measured', () => {
      // maxWidth can clamp the legend below the requested width. Sizing the chart from the
      // raw prop would then leave a dead gap between the chart and the legend.
      mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, width: 480 }]);
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="right" width={600} maxWidth="60%">
              <div />
            </VizLayout.Legend>
          }
        >
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(320, 600);
    });

    it('sets the legend width style when an explicit width prop is provided', () => {
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="right" width={200}>
              <div />
            </VizLayout.Legend>
          }
        >
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.legend)).toHaveStyle({ width: '200px' });
    });

    it('gives the scroll container full height so legend content can use percentage heights', () => {
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {() => null}
        </VizLayout>
      );
      const scrollBox = screen.getByTestId(selectors.components.VizLayout.legend).firstElementChild;
      expect(scrollBox).toHaveStyle({ height: '100%' });
    });

    it('preserves full width when legend width equals container width', () => {
      mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, width: 800 }]);
      const children = jest.fn().mockReturnValue(null);
      render(
        <VizLayout width={800} height={600} legend={legend}>
          {children}
        </VizLayout>
      );
      expect(children).toHaveBeenCalledWith(800, 600);
    });

    describe('with a string (css) legend width', () => {
      it('applies the string width as-is to the legend element', () => {
        render(
          <VizLayout
            width={800}
            height={600}
            legend={
              <VizLayout.Legend placement="right" width="35%">
                <div />
              </VizLayout.Legend>
            }
          >
            {() => null}
          </VizLayout>
        );
        expect(screen.getByTestId(selectors.components.VizLayout.legend)).toHaveStyle({ width: '35%' });
      });

      it('does not apply maxWidth when a string width is set', () => {
        render(
          <VizLayout
            width={800}
            height={600}
            legend={
              <VizLayout.Legend placement="right" width="35%" maxWidth="50%">
                <div />
              </VizLayout.Legend>
            }
          >
            {() => null}
          </VizLayout>
        );
        expect(screen.getByTestId(selectors.components.VizLayout.legend)).not.toHaveStyle({ maxWidth: '50%' });
      });

      it('does not subtract a fixed pixel amount from the chart width for a string width', () => {
        // With a css width the legend size is not known up-front, so the chart
        // width comes solely from the measured legend, not from the width prop.
        mockUseMeasure.mockReturnValue([jest.fn(), { ...noMeasure, width: 150 }]);
        const children = jest.fn().mockReturnValue(null);
        render(
          <VizLayout
            width={800}
            height={600}
            legend={
              <VizLayout.Legend placement="right" width="35%">
                <div />
              </VizLayout.Legend>
            }
          >
            {children}
          </VizLayout>
        );
        expect(children).toHaveBeenCalledWith(650, 600);
      });

      it('still applies maxWidth when width is a number', () => {
        render(
          <VizLayout
            width={800}
            height={600}
            legend={
              <VizLayout.Legend placement="right" width={200} maxWidth="50%">
                <div />
              </VizLayout.Legend>
            }
          >
            {() => null}
          </VizLayout>
        );
        const el = screen.getByTestId(selectors.components.VizLayout.legend);
        expect(el).toHaveStyle({ width: '200px', maxWidth: '50%' });
      });
    });
  });

  describe('small screen behavior', () => {
    it('forces bottom placement for a right legend when viewport is below the lg breakpoint', () => {
      Object.defineProperty(document.body, 'clientWidth', { value: 100, configurable: true });
      render(
        <VizLayout
          width={800}
          height={600}
          legend={
            <VizLayout.Legend placement="right">
              <div />
            </VizLayout.Legend>
          }
        >
          {() => null}
        </VizLayout>
      );
      expect(screen.getByTestId(selectors.components.VizLayout.container)).toHaveStyle({ flexDirection: 'column' });
    });
  });
});
