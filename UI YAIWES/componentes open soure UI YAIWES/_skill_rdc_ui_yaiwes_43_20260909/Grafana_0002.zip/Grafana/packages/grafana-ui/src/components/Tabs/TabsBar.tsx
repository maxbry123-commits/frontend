import { css, cx } from '@emotion/css';
import { forwardRef, type ReactNode } from 'react';

import { type GrafanaTheme2 } from '@grafana/data';

import { useStyles2 } from '../../themes/ThemeContext';

export interface Props extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
  /** Children should be a single <Tab /> or an array of <Tab /> */
  children: ReactNode;
  className?: string;
  /** For hiding the bottom border (on PageHeader for example) */
  hideBorder?: boolean;
}

/**
 * A composition component for rendering a TabBar with Tabs for navigation.
 *
 * https://developers.grafana.com/ui/latest/index.html?path=/docs/navigation-tabs--docs
 */
export const TabsBar = forwardRef<HTMLDivElement, Props>(
  ({ children, className, hideBorder = false, ...rest }, ref) => {
    const styles = useStyles2(getStyles);

    return (
      <div className={cx(styles.tabsWrapper, hideBorder && styles.noBorder, className)} ref={ref} {...rest}>
        <div className={styles.tabs} role="tablist">
          {children}
        </div>
      </div>
    );
  }
);

const getStyles = (theme: GrafanaTheme2) => ({
  tabsWrapper: css({
    borderBottom: `1px solid ${theme.colors.border.weak}`,
    overflowX: 'auto',
  }),
  noBorder: css({
    borderBottom: 0,
  }),
  tabs: css({
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
  }),
});

TabsBar.displayName = 'TabsBar';
