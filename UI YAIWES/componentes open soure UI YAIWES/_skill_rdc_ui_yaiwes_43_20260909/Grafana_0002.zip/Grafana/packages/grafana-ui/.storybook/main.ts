import path, { dirname, join } from 'node:path';
import type { StorybookConfig } from '@storybook/react-webpack5';
import remarkGfm from 'remark-gfm';
import { copyAssetsSync } from './copyAssets.ts';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

const coreComponentsGlobs: StorybookConfig['stories'] = [
  // Specific high-level documentation pages
  '../src/Intro.mdx',
  '../src/DesignPrinciples.mdx',
  '../src/VoiceAndTone.mdx',
  '../src/Accessibility.mdx',

  // All the other stories
  '../src/**/*.story.tsx',
];

const alertingComponentsGlobs: StorybookConfig['stories'] = [
  {
    titlePrefix: 'Alerting',
    directory: '../../grafana-alerting/src',
    files: 'Intro.mdx',
  },
  {
    titlePrefix: 'Alerting',
    directory: '../../grafana-alerting/src',
    files: process.env.NODE_ENV === 'production' ? '**/!(*.internal).story.tsx' : '**/*.story.tsx',
  },
];

const stories = [...coreComponentsGlobs, ...alertingComponentsGlobs];

// Copy the assets required by storybook before starting the storybook server.
copyAssetsSync();

const mainConfig: StorybookConfig = {
  stories,

  addons: [
    {
      name: getAbsolutePath('@storybook/addon-docs'),
      options: {
        mdxPluginOptions: {
          mdxCompileOptions: {
            remarkPlugins: [remarkGfm],
          },
        },
      },
    },
    getAbsolutePath('@storybook/addon-a11y'),
    {
      name: '@storybook/preset-scss',
      options: {
        styleLoaderOptions: {
          // this is required for theme switching .use() and .unuse()
          injectType: 'lazyStyleTag',
        },
        cssLoaderOptions: {
          url: false,
          importLoaders: 2,
        },
        sassLoaderOptions: {
          sassOptions: {
            // silencing these warnings since we're planning to remove sass when angular is gone
            silenceDeprecations: ['import', 'global-builtin'],
          },
        },
      },
    },
    getAbsolutePath('@storybook/addon-webpack5-compiler-swc'),
  ],

  framework: {
    name: getAbsolutePath('@storybook/react-webpack5'),
    options: {
      fastRefresh: true,
      builder: {
        fsCache: true,
      },
    },
  },

  logLevel: 'debug',
  staticDirs: ['static', { from: 'images', to: 'images' }],

  typescript: {
    check: true,
    reactDocgen: 'react-docgen-typescript',
    reactDocgenTypescriptOptions: {
      tsconfigPath: path.resolve(import.meta.dirname, 'tsconfig.json'),
      shouldExtractLiteralValuesFromEnum: true,
      shouldRemoveUndefinedFromOptional: true,
      propFilter: (prop) => (prop.parent ? !/node_modules/.test(prop.parent.fileName) : true),
      savePropValueAsString: true,
    },
  },

  swc: () => ({
    jsc: {
      transform: {
        react: {
          runtime: 'automatic',
        },
      },
    },
  }),

  webpackFinal: async (config) => {
    // expose jquery as a global so jquery plugins don't break at runtime.
    config.module?.rules?.push({
      test: require.resolve('jquery'),
      loader: 'expose-loader',
      options: {
        exposes: ['$', 'jQuery'],
      },
    });

    // Tell storybook to resolve imports with the @grafana-app/source condition for
    // the packages in this repo.
    if (config && config.resolve) {
      if (Array.isArray(config.resolve.conditionNames)) {
        config.resolve.conditionNames.unshift('@grafana-app/source');
      } else {
        config.resolve.conditionNames = ['@grafana-app/source', '...'];
      }
    }

    return config;
  },

  features: {
    backgrounds: false,
  },
};

function getAbsolutePath(value: string): any {
  return dirname(require.resolve(join(value, 'package.json')));
}

export default mainConfig;
