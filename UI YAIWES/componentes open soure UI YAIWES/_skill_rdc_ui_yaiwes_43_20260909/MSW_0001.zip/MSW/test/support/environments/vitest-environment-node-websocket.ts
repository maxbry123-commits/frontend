/**
 * Node.js environment superset that has a global WebSocket API.
 */
import { builtinEnvironments, type Environment } from 'vitest/runtime'
import { WebSocket } from 'undici'

export default <Environment>{
  name: 'node-with-websocket',
  viteEnvironment: 'ssr',
  async setup(global, options) {
    /**
     * @note It's crucial this extend the Node.js environment.
     * JSDOM polyfills the global "Event", making it unusable
     * with Node's "EventTarget".
     */
    const { teardown } = await builtinEnvironments.node.setup(global, options)

    if (Reflect.get(globalThis, 'WebSocket') == null) {
      Reflect.set(globalThis, 'WebSocket', WebSocket)
    }

    return {
      teardown,
    }
  },
}
