---
title: Install Grafana Loki locally
menuTitle: Install locally
description: Describes how to install and run Grafana Loki locally.
aliases:
  - ../../installation/local/
weight: 500
---

# Install Grafana Loki locally

To log events with Grafana Loki, download and install Loki.

- Loki is the logging engine.
- [Grafana Alloy](https://grafana.com/docs/alloy/latest/) is recommended for sending logs to Loki.

The configuration runs Loki as a single binary.

{{< admonition type="note" >}}
Grafana Loki does not come with any included authentication layer. You must run an authenticating reverse proxy in front of your services to prevent unauthorized access to Loki (for example, nginx). Refer to [Manage authentication](https://grafana.com/docs/loki/<LOKI_VERSION>/operations/authentication/) for a list of open-source reverse proxies you can use.
{{< /admonition >}}

## Install using APT or RPM package manager

1. Add the Grafana [Advanced Package Tool (APT)](https://apt.grafana.com/) or [RPM Package Manager (RPM)](https://rpm.grafana.com/) package repository following the linked instructions.
1. Install Loki
   1. Using `dnf`

      ```bash
      dnf update
      dnf install loki
      ```

   1. Using `apt-get`

      ```bash
      apt-get update
      apt-get install loki
      ```

## Install manually

1. Browse to the [release page](https://github.com/grafana/loki/releases/).
1. Find the **Assets** section for the version that you want to install.
1. Download the Loki archive file that corresponds to your system.

   Don't download LogCLI or Loki Canary at this time.
   LogCLI allows you to run Loki queries in a command line interface.
   [Loki Canary](https://grafana.com/docs/loki/<LOKI_VERSION>/operations/loki-canary/) is a tool to audit Loki performance.

1. Extract the package contents into a directory. This is where Loki will run.
1. In the command line, change directory (`cd` on most systems) to the directory with Loki.

   Copy and paste the following command into your command line to download a generic configuration file.

   Use the Git references that match your downloaded Loki version to get the correct configuration file.
   For example, if you are using Loki version 3.6.0, you need to use the `https://raw.githubusercontent.com/grafana/loki/v3.6.0/cmd/loki/loki-local-config.yaml` URL to download the configuration file.

   ```bash
   wget https://raw.githubusercontent.com/grafana/loki/main/cmd/loki/loki-local-config.yaml
   ```

1. Run the following command to start Loki:

   **Windows**

   ```bash
   .\loki-windows-amd64.exe --config.file=loki-local-config.yaml
   ```

   **Linux**

   ```bash
   ./loki-linux-amd64 -config.file=loki-local-config.yaml
   ```

Loki runs and displays Loki logs in your command line and on http://localhost:3100/metrics.

The next step is running an agent to send logs to Loki.
Refer to [Grafana Alloy](https://grafana.com/docs/alloy/latest/) for the recommended log collection agent.

## Release binaries - openSUSE Linux only

Every release includes binaries for Loki.
You can find them on the [Releases page](https://github.com/grafana/loki/releases).

## Community openSUSE Linux packages

The community provides packages of Loki for openSUSE Linux.
To install them:

1. Add the repository `https://download.opensuse.org/repositories/security:/logging/` to your system.
   For example, if you are using Leap 15.1, run:

   ```bash
   sudo zypper ar https://download.opensuse.org/repositories/security:/logging/openSUSE_Leap_15.1/security:logging.repo
   sudo zypper ref
   ```

1. Install the Loki package:

   ```bash
   zypper in loki
   ```

1. Start and enable the Loki service:

   ```bash
   systemd start loki
   systemd enable loki
   ```

1. Modify the `/etc/loki/loki.yaml` configuration file as needed.
