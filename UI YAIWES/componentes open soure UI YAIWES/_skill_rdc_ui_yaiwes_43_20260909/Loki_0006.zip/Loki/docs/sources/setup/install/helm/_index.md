---
title: Install Grafana Loki with Helm
menuTitle: Install using Helm
description: Overview of topics for how to install Grafana Loki on Kubernetes with Helm.
aliases:
  - ../../installation/helm/
weight: 200
keywords:
  - helm 
  - scalable
  - simple-scalable
  - installation
---

# Install Grafana Loki with Helm

The [Helm](https://helm.sh/) chart lets you configure, install, and upgrade Grafana Loki within a Kubernetes cluster.

This guide references the Loki community Helm chart and contains the following sections:

{{< section menuTitle="true" >}}

If you are installing Grafana Enterprise Logs, follow the [GEL Helm installation](https://grafana.com/docs/enterprise-logs/<ENTERPRISE_LOGS_VERSION>/setup/helm/).

{{< admonition type="note" >}}
Grafana Labs maintains the GEL Helm charts in the Loki repository.  Grafana Community Champions now maintain the Loki Helm charts in the [Grafana-community/helm-charts repo](https://github.com/grafana-community/helm-charts). Issues and pull requests for the Loki chart should be opened against the community repository.
{{< /admonition >}}

## Deployment Recommendations

Loki is designed to be run in two states:
* [Monolithic](https://grafana.com/docs/loki/<LOKI_VERSION>/get-started/deployment-modes/#monolithic-mode): Recommended when you are running Loki as part of a small meta monitoring stack.
* [Microservices](https://grafana.com/docs/loki/<LOKI_VERSION>/get-started/deployment-modes/#microservices-mode): For workloads that require high availability and scalability. Loki is deployed in this mode internally at Grafana Labs.

{{< admonition type="tip" >}}
Loki can also be deployed in [Simple Scalable mode](https://grafana.com/docs/loki/<LOKI_VERSION>/get-started/deployment-modes/#simple-scalable). But Simple Scalable Deployment (SSD) mode is being deprecated and removed in Loki 4.0. For the best possible experience in production, we recommend deploying Loki in *microservices* mode.
{{< /admonition >}}

## Cloud Deployment Guides

The following guides provide step-by-step instructions for deploying Loki on cloud providers:

- [Amazon EKS](https://grafana.com/docs/loki/<LOKI_VERSION>/setup/install/helm/deployment-guides/aws/)
- [Azure AKS](https://grafana.com/docs/loki/<LOKI_VERSION>/setup/install/helm/deployment-guides/azure/)
- [Google GKE](https://grafana.com/docs/loki/<LOKI_VERSION>/setup/install/helm/deployment-guides/gcp/)

## Reference

You can find reference documentation for the Loki Helm chart values in the [Helm Chart Reference](https://grafana.com/docs/loki/<LOKI_VERSION>/setup/install/helm/reference/) or view the source [values.yaml file](https://github.com/grafana-community/helm-charts/blob/main/charts/loki/values.yaml).
