---
title: Docker driver client
menuTItle:  Docker driver
description: Provides instructions for how to install, upgrade, and remove the Docker driver client, used to send logs to Loki.
aliases: 
- ../clients/docker-driver/
weight:  400
---
# Docker driver client

Loki provides a Docker plugin that will read logs from Docker
containers and ship them to Loki. The plugin can be configured to send the logs
to a private Loki instance or Grafana Cloud.

{{< admonition type="note" >}}
The Docker driver is maintained as part of the Loki project, but is listed among Loki's [third-party clients](../#third-party-clients) and does not carry the same support commitment as [Grafana Alloy](https://grafana.com/docs/alloy/latest/).
{{< /admonition >}}

{{< admonition type="note" >}}
Docker plugins are not supported on Windows; see the [Docker Engine managed plugin system](https://docs.docker.com/engine/extend) documentation for more information.
{{< /admonition >}}

Documentation on configuring the Loki Docker Driver can be found on the [configuration page](https://grafana.com/docs/loki/<LOKI_VERSION>/send-data/docker-driver/configuration/).
If you have any questions or issues using the Docker plugin, open an issue in
the [Loki repository](https://github.com/grafana/loki/issues).

## Install the Docker driver client

The Docker plugin must be installed on each Docker host that will be running containers you want to collect logs from.

Run the following command to install the plugin, updating the release version, or changing the architecture (`arm64` and `amd64` are currently supported), if needed:

```bash
docker plugin install grafana/loki-docker-driver:3.6.0-amd64 --alias loki --grant-all-permissions
```

{{< admonition type="note" >}}
Add `-arm64` to the image tag for ARM64 hosts.
{{< /admonition >}}

To check installed plugins, use the `docker plugin ls` command.
Plugins that have started successfully are listed as enabled:

```bash
docker plugin ls
```

You should see output similar to the following:

```bash
ID                  NAME         DESCRIPTION           ENABLED
ac720b8fcfdb        loki         Loki Logging Driver   true
```

Once you have successfully installed the plugin you can [configure](https://grafana.com/docs/loki/<LOKI_VERSION>/send-data/docker-driver/configuration/) it.

## Upgrade the Docker driver client

The upgrade process involves disabling the existing plugin, upgrading (changing version and architecture as needed), then
re-enabling and restarting Docker:

```bash
docker plugin disable loki --force
docker plugin upgrade loki grafana/loki-docker-driver:3.6.0-arm64 --grant-all-permissions
docker plugin enable loki
systemctl restart docker
```

{{< admonition type="note" >}}
Update the version number to the appropriate version.
{{< /admonition >}}

## Uninstall the Docker driver client

To cleanly uninstall the plugin, disable and remove it:

```bash
docker plugin disable loki --force
docker plugin rm loki
```

## Known Issue: Deadlocked Docker Daemon

The driver keeps all logs in memory and will drop log entries if Loki is not reachable and if the quantity of `loki-retries` has been exceeded. To avoid the dropping of log entries, setting `loki-retries` to zero allows unlimited retries; the driver will continue trying forever until Loki is again reachable. Trying forever may have undesired consequences, because the Docker daemon will wait for the Loki driver to process all logs of a container, until the container is removed. Thus, the Docker daemon might wait forever if the container is stuck.

The wait time can be lowered by setting `loki-retries=2`, `loki-max-backoff=800ms`, `loki-timeout=1s` and `keep-file=true`. This way the daemon will be locked only for a short time and the JSON log files will be retained on disk when the Loki client is unable to re-connect.

Also you can use non-blocking mode by setting `services.logger.logging.options.mode=non-blocking` in your `docker-compose` file. Non-blocking means that the process of writing logs to Loki will not block the main flow of an application or service if Loki is temporarily unavailable or unable to process log messages. In non-blocking mode, log messages will be buffered and sent to Loki asynchronously, which allows the main thread to continue working without delay. If Loki is unavailable, log messages will be stored in a buffer and sent when Loki becomes available again. However, this setting is useful to prevent blocking the main flow of an application or service due to logging issues, but it can also lead to loss of log messages if the buffer overflows or if Loki is unavailable for a long time.

To avoid this issue, use the Alloy [`loki.source.docker`](https://grafana.com/docs/alloy/latest/reference/components/loki/loki.source.docker/) component or [`discovery.docker`](https://grafana.com/docs/alloy/latest/reference/components/discovery/discovery.docker/) for Docker service discovery.
