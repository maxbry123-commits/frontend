package common

type MouseClickOptions struct {
	Button     string `json:"button"`
	ClickCount int64  `json:"clickCount"`
	Delay      int64  `json:"delay"`
}

type MouseDblClickOptions struct {
	Button string `json:"button"`
	Delay  int64  `json:"delay"`
}

type MouseDownUpOptions struct {
	Button     string `json:"button"`
	ClickCount int64  `json:"clickCount"`
}

type MouseMoveOptions struct {
	Steps int64 `json:"steps"`
}

func NewMouseClickOptions() *MouseClickOptions {
	return &MouseClickOptions{
		Button:     "left",
		ClickCount: 1,
		Delay:      0,
	}
}

func (o *MouseClickOptions) ToMouseDownUpOptions() *MouseDownUpOptions {
	o2 := NewMouseDownUpOptions()
	o2.Button = o.Button
	o2.ClickCount = o.ClickCount
	return o2
}

func NewMouseDblClickOptions() *MouseDblClickOptions {
	return &MouseDblClickOptions{
		Button: "left",
		Delay:  0,
	}
}

// ToMouseClickOptions converts MouseDblClickOptions to a MouseClickOptions.
func (o *MouseDblClickOptions) ToMouseClickOptions() *MouseClickOptions {
	o2 := NewMouseClickOptions()
	o2.Button = o.Button
	o2.ClickCount = 2
	o2.Delay = o.Delay
	return o2
}

func NewMouseDownUpOptions() *MouseDownUpOptions {
	return &MouseDownUpOptions{
		Button:     "left",
		ClickCount: 1,
	}
}

func NewMouseMoveOptions() *MouseMoveOptions {
	return &MouseMoveOptions{
		Steps: 1,
	}
}
