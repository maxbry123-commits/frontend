package browser

import (
	"github.com/grafana/sobek"

	"go.k6.io/k6/v2/internal/js/modules/k6/browser/common"
)

func mapResponseEvent(vu moduleVU, event common.PageEvent) mapping {
	return mapResponse(vu, event.Response)
}

// mapResponse to the JS module.
//
//nolint:funlen
func mapResponse(vu moduleVU, r *common.Response) mapping {
	if r == nil {
		return nil
	}
	maps := mapping{
		"allHeaders": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				r.WaitForRawHeaders()
				return r.AllHeaders(), nil
			})
		},
		"body": func() *sobek.Promise {
			rt := vu.Runtime()
			promise, res, rej := rt.NewPromise()
			callback := vu.RegisterCallback()
			go func() {
				body, err := r.Body()
				if err != nil {
					callback(func() error {
						return rej(err)
					})
					return
				}
				callback(func() error {
					buf := vu.Runtime().NewArrayBuffer(body)
					return res(&buf)
				})
			}()
			return promise
		},
		"frame": func() mapping {
			return mapFrame(vu, r.Frame())
		},
		"headerValue": func(name string) *sobek.Promise {
			return promise(vu, func() (any, error) {
				r.WaitForRawHeaders()
				v, ok := r.HeaderValue(name)
				if !ok {
					return nil, nil
				}
				return v, nil
			})
		},
		"headerValues": func(name string) *sobek.Promise {
			return promise(vu, func() (any, error) {
				r.WaitForRawHeaders()
				return r.HeaderValues(name), nil
			})
		},
		"headers": r.Headers,
		"headersArray": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				r.WaitForRawHeaders()
				return r.HeadersArray(), nil
			})
		},
		"json": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				return r.JSON() //nolint: wrapcheck
			})
		},
		"ok": r.Ok,
		"request": func() mapping {
			return mapRequest(vu, r.Request())
		},
		"securityDetails": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				return r.SecurityDetails(), nil
			})
		},
		"serverAddr": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				return r.ServerAddr(), nil
			})
		},
		"size": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				return r.Size(), nil
			})
		},
		"status":     r.Status,
		"statusText": r.StatusText,
		"url":        r.URL,
		"text": func() *sobek.Promise {
			return promise(vu, func() (any, error) {
				return r.Text() //nolint:wrapcheck
			})
		},
	}

	return maps
}
