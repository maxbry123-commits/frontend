package cloudlog

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"go.k6.io/k6/v2/internal/lib/testutils"
)

// TestPusher is the canonical case: entries fired before and after SetConfig
// are buffered and then pushed to the configured endpoint, carrying the
// bearer token and the required test_run_id label.
func TestPusher(t *testing.T) {
	t.Parallel()

	type received struct {
		body string
		auth string
	}
	recvCh := make(chan received, 1)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		select {
		case recvCh <- received{body: string(b), auth: req.Header.Get("Authorization")}:
		default:
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))

	// Fired BEFORE SetConfig: must be buffered until the pusher is configured.
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "before-config"}))

	p.SetConfig(Config{
		PushURL:    srv.URL,
		Token:      "test-token",
		TestRunID:  "run-123",
		PushPeriod: 20 * time.Millisecond,
	})

	// Fired AFTER SetConfig: still buffered until Listen drains.
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "after-config"}))

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	var got received
	select {
	case got = <-recvCh:
	case <-time.After(2 * time.Second):
		t.Fatal("no push received from the pusher")
	}

	assert.Equal(t, "Bearer test-token", got.auth)
	assert.Contains(t, got.body, "before-config")
	assert.Contains(t, got.body, "after-config")
	assert.Contains(t, got.body, `"test_run_id":"run-123"`)

	cancel()
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after ctx was cancelled")
	}
}

// TestPusher_UnconfiguredDrainsOnCtxDone covers the --no-cloud-logs / early
// exit path: without SetConfig, Listen returns promptly on ctx.Done and never
// pushes.
func TestPusher_UnconfiguredDrainsOnCtxDone(t *testing.T) {
	t.Parallel()

	srv := httptest.NewServer(http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
		t.Errorf("pusher made an HTTP request while unconfigured")
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "buffered"}))

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	cancel()
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return promptly on ctx.Done while unconfigured")
	}
}

// TestPusher_FireNeverBlocks keeps the logging path non-blocking: with no
// Listen draining, Fire returns immediately even past the buffer capacity and
// over-cap entries are counted as dropped.
func TestPusher_FireNeverBlocks(t *testing.T) {
	t.Parallel()

	p := New(testutils.NewLogger(t))

	const overflow = 10
	total := bufferCap + overflow

	fired := make(chan struct{})
	go func() {
		for range total {
			_ = p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "x"})
		}
		close(fired)
	}()

	select {
	case <-fired:
	case <-time.After(2 * time.Second):
		t.Fatal("Fire blocked when the buffer was full")
	}

	assert.Equal(t, int64(overflow), p.dropped.Load())
}

// TestPusher_ReportsDroppedLogs proves the front-buffer drop counter is
// surfaced rather than silently discarded, even when the loki hook's own
// per-batch limit is already exhausted: the notice must bypass that limit. The
// limit is set well below the number of forwarded entries so a naive push
// (subject to the limit) would drop the notice itself.
//
// It also asserts push ordering: the notice shares the "warning" stream with
// the loki hook's own limit-drop message, so across pushes that stream's
// timestamps must be non-decreasing, otherwise Loki with unordered_writes=false
// rejects the older write.
func TestPusher_ReportsDroppedLogs(t *testing.T) {
	t.Parallel()

	var (
		mu       sync.Mutex
		requests []string // request bodies, in the order the server received them
	)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		mu.Lock()
		requests = append(requests, string(b))
		mu.Unlock()
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	const overflow = 7

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:   srv.URL,
		Token:     "tok",
		TestRunID: "run-dropped",
		// Deliberately far below bufferCap: forwarding the buffered entries
		// exhausts the loki per-batch limit, so the notice must bypass it.
		Limit:      10,
		PushPeriod: time.Hour, // only the shutdown push
	})

	// Overflow the buffer before Listen consumes anything, so exactly `overflow`
	// entries are dropped by Fire.
	for range bufferCap + overflow {
		require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "x"}))
	}
	require.Equal(t, int64(overflow), p.dropped.Load())

	ctx := t.Context()
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	require.NoError(t, p.Drain(context.Background()))
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after Drain")
	}

	mu.Lock()
	defer mu.Unlock()

	assert.Contains(t, strings.Join(requests, ""),
		"dropped 7 log messages because the cloud log buffer was full",
		"the front-buffer drop count must survive the loki per-batch limit")

	// Collect the "warning" stream timestamps in the order they were pushed and
	// assert they never go backwards across requests.
	type lokiPush struct {
		Streams []struct {
			Stream map[string]string `json:"stream"`
			Values [][]string        `json:"values"`
		} `json:"streams"`
	}
	var warnTS []int64
	for _, body := range requests {
		var lp lokiPush
		require.NoError(t, json.Unmarshal([]byte(body), &lp))
		for _, s := range lp.Streams {
			if s.Stream["level"] != logrus.WarnLevel.String() {
				continue
			}
			for _, v := range s.Values {
				require.GreaterOrEqual(t, len(v), 1)
				ts, err := strconv.ParseInt(v[0], 10, 64)
				require.NoError(t, err)
				warnTS = append(warnTS, ts)
			}
		}
	}
	require.GreaterOrEqual(t, len(warnTS), 2,
		"expected both the loki limit-drop warning and the cloud-buffer notice")
	for i := 1; i < len(warnTS); i++ {
		assert.GreaterOrEqual(t, warnTS[i], warnTS[i-1],
			"warning-stream timestamps must not go backwards across pushes "+
				"(an out-of-order write is rejected by Loki with unordered_writes=false)")
	}
}

// TestPusher_TestRunIDLabelKept locks the backend's hard requirement: even
// when AllowedLabels omits test_run_id, the pushed stream still carries it as
// a label (the backend 401s a push whose stream lacks it).
func TestPusher_TestRunIDLabelKept(t *testing.T) {
	t.Parallel()

	recvCh := make(chan string, 1)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		select {
		case recvCh <- string(b):
		default:
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:       srv.URL,
		Token:         "tok",
		TestRunID:     "run-xyz",
		PushPeriod:    20 * time.Millisecond,
		AllowedLabels: []string{"level"}, // deliberately omits test_run_id
	})
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "hello"}))

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	select {
	case body := <-recvCh:
		assert.Contains(t, body, `"test_run_id":"run-xyz"`)
	case <-time.After(2 * time.Second):
		t.Fatal("no push received from the pusher")
	}

	cancel()
	<-listenDone
}

// TestPusher_EmptyAllowedLabelsKeepsTestRunID guards the empty-slice edge: an
// explicitly empty K6_CLOUD_LOGS_ALLOWED_LABELS decodes to a non-nil []string{},
// which must still keep the required test_run_id label rather than strip every
// label from the stream.
func TestPusher_EmptyAllowedLabelsKeepsTestRunID(t *testing.T) {
	t.Parallel()

	recvCh := make(chan string, 1)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		select {
		case recvCh <- string(b):
		default:
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:       srv.URL,
		Token:         "tok",
		TestRunID:     "run-empty-labels",
		PushPeriod:    20 * time.Millisecond,
		AllowedLabels: []string{}, // non-nil empty, as envconfig decodes ""
	})
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "hello"}))

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	select {
	case body := <-recvCh:
		assert.Contains(t, body, `"test_run_id":"run-empty-labels"`)
	case <-time.After(2 * time.Second):
		t.Fatal("no push received from the pusher")
	}

	cancel()
	<-listenDone
}

// TestPusher_Drain covers the pre-notify drain: after entries are pushed while
// the run is open, Drain returns without hanging, drives Listen to return even
// though ctx was never cancelled, and is idempotent on a second call.
func TestPusher_Drain(t *testing.T) {
	t.Parallel()

	type received struct {
		body string
		auth string
	}
	recvCh := make(chan received, 8)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		select {
		case recvCh <- received{body: string(b), auth: req.Header.Get("Authorization")}:
		default:
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:    srv.URL,
		Token:      "drain-token",
		TestRunID:  "run-drain",
		PushPeriod: 20 * time.Millisecond,
	})

	for _, msg := range []string{"entry-a", "entry-b", "entry-c"} {
		require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: msg}))
	}

	// ctx stays alive for the whole test: shutdown must be driven by Drain,
	// not by a ctx cancel.
	ctx := t.Context()
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	// Entries reach the backend via the periodic push while the run is open,
	// carrying the bearer token and the required test_run_id label.
	var got received
	select {
	case got = <-recvCh:
	case <-time.After(2 * time.Second):
		t.Fatal("no push received from the pusher")
	}
	assert.Equal(t, "Bearer drain-token", got.auth)
	assert.Contains(t, got.body, `"test_run_id":"run-drain"`)

	// Drain returns once the flush has completed; it must not hang.
	require.NoError(t, p.Drain(context.Background()))

	// Drain drove Listen to return, even though ctx was never cancelled.
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after Drain")
	}

	// Idempotent: a second Drain returns nil immediately.
	require.NoError(t, p.Drain(context.Background()))
}

// TestPusher_DrainUnconfigured covers the --out cloud / --no-cloud-logs case:
// without SetConfig, Drain is a no-op that returns nil immediately and makes
// no HTTP request.
func TestPusher_DrainUnconfigured(t *testing.T) {
	t.Parallel()

	p := New(testutils.NewLogger(t))
	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.InfoLevel, Message: "buffered"}))

	require.NoError(t, p.Drain(context.Background()))
}

// TestPusher_DrainContextTimeout locks Drain's ctx contract: when the flush
// cannot complete (here Listen is never started, so doneCh never closes), a
// done ctx unblocks Drain with the ctx error rather than blocking forever.
func TestPusher_DrainContextTimeout(t *testing.T) {
	t.Parallel()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:   "http://127.0.0.1:0",
		Token:     "tok",
		TestRunID: "run",
	})

	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	require.ErrorIs(t, p.Drain(ctx), context.Canceled)
}

// TestPusher_FiltersBelowConfiguredLevel locks the backend-level directive:
// with Level "info" the pusher pushes info/warn/error entries but filters out
// the less-severe debug entry, even though the loki hook's Fire enqueues
// unconditionally. Entries reach the backend via the periodic push.
func TestPusher_FiltersBelowConfiguredLevel(t *testing.T) {
	t.Parallel()

	var (
		mu   sync.Mutex
		body strings.Builder
	)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		mu.Lock()
		body.Write(b)
		mu.Unlock()
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:    srv.URL,
		Token:      "tok",
		TestRunID:  "run-lvl",
		Level:      "info",
		PushPeriod: 20 * time.Millisecond,
	})

	// Fired debug-first, so by the time the others are pushed the debug entry
	// has already been through the forward path (and been filtered).
	for _, e := range []*logrus.Entry{
		{Time: time.Now(), Level: logrus.DebugLevel, Message: "msg-debug"},
		{Time: time.Now(), Level: logrus.InfoLevel, Message: "msg-info"},
		{Time: time.Now(), Level: logrus.WarnLevel, Message: "msg-warn"},
		{Time: time.Now(), Level: logrus.ErrorLevel, Message: "msg-error"},
	} {
		require.NoError(t, p.Fire(e))
	}

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	got := func() string {
		mu.Lock()
		defer mu.Unlock()
		return body.String()
	}

	// The info/warn/error entries (at or above the configured level) are pushed.
	require.Eventually(t, func() bool {
		b := got()
		return strings.Contains(b, "msg-info") &&
			strings.Contains(b, "msg-warn") &&
			strings.Contains(b, "msg-error")
	}, 2*time.Second, 10*time.Millisecond, "info/warn/error entries were not pushed")

	// The debug entry is below the configured level, so it is never pushed.
	assert.NotContains(t, got(), "msg-debug")

	cancel()
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after ctx was cancelled")
	}
}

// TestPusher_EmptyLevelKeepsAll is the variant: an unset Level keeps all
// levels, so even a debug entry is pushed.
func TestPusher_EmptyLevelKeepsAll(t *testing.T) {
	t.Parallel()

	var (
		mu   sync.Mutex
		body strings.Builder
	)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		mu.Lock()
		body.Write(b)
		mu.Unlock()
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:    srv.URL,
		Token:      "tok",
		TestRunID:  "run-empty",
		Level:      "", // unset => keep all levels
		PushPeriod: 20 * time.Millisecond,
	})

	require.NoError(t, p.Fire(&logrus.Entry{Time: time.Now(), Level: logrus.DebugLevel, Message: "msg-debug"}))

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	require.Eventually(t, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return strings.Contains(body.String(), "msg-debug")
	}, 2*time.Second, 10*time.Millisecond, "debug entry was not pushed with empty level")

	cancel()
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after ctx was cancelled")
	}
}

// TestPusher_InvalidLevelDefaultsToInfo verifies that an unparseable Level
// (which can only come from the backend) neither disables the push nor keeps
// all levels: it falls back to info, so debug is dropped while info and above
// are still pushed.
func TestPusher_InvalidLevelDefaultsToInfo(t *testing.T) {
	t.Parallel()

	var (
		mu   sync.Mutex
		body strings.Builder
	)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		mu.Lock()
		body.Write(b)
		mu.Unlock()
		w.WriteHeader(http.StatusNoContent)
	}))
	defer srv.Close()

	p := New(testutils.NewLogger(t))
	p.SetConfig(Config{
		PushURL:    srv.URL,
		Token:      "tok",
		TestRunID:  "run-badlvl",
		Level:      "bogus", // invalid => fall back to info
		PushPeriod: 20 * time.Millisecond,
	})

	// Debug fired first, so if it were going to be pushed it would land no
	// later than the info/error entries.
	for _, e := range []*logrus.Entry{
		{Time: time.Now(), Level: logrus.DebugLevel, Message: "msg-debug"},
		{Time: time.Now(), Level: logrus.InfoLevel, Message: "msg-info"},
		{Time: time.Now(), Level: logrus.ErrorLevel, Message: "msg-error"},
	} {
		require.NoError(t, p.Fire(e))
	}

	ctx, cancel := context.WithCancel(context.Background())
	listenDone := make(chan struct{})
	go func() {
		p.Listen(ctx)
		close(listenDone)
	}()

	got := func() string {
		mu.Lock()
		defer mu.Unlock()
		return body.String()
	}

	// info/error (at or above the info fallback) are pushed despite the
	// invalid level, proving the push is not disabled.
	require.Eventually(t, func() bool {
		b := got()
		return strings.Contains(b, "msg-info") && strings.Contains(b, "msg-error")
	}, 2*time.Second, 10*time.Millisecond, "info/error not pushed with an invalid level")

	// debug (below info) is dropped, proving the fallback is info, not all.
	assert.NotContains(t, got(), "msg-debug")

	cancel()
	select {
	case <-listenDone:
	case <-time.After(2 * time.Second):
		t.Fatal("Listen did not return after ctx was cancelled")
	}
}
