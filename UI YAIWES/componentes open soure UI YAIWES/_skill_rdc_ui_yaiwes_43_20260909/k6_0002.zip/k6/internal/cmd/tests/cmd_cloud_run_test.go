package tests

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	k6cloud "github.com/grafana/k6-cloud-openapi-client-go/k6"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"go.k6.io/k6/v2/errext/exitcodes"
	provtest "go.k6.io/k6/v2/internal/cloudapi/provisioning/test"
	v6 "go.k6.io/k6/v2/internal/cloudapi/v6"
	"go.k6.io/k6/v2/internal/cloudapi/v6/v6test"
	"go.k6.io/k6/v2/internal/cmd"
	"go.k6.io/k6/v2/internal/lib/testutils"
	"go.k6.io/k6/v2/lib/fsext"
)

func TestK6CloudRun(t *testing.T) {
	t.Parallel()
	runCloudTests(t, setupK6CloudRunCmd)
}

func setupK6CloudRunCmd(cliFlags []string) []string {
	return append([]string{"k6", "cloud", "run"}, append(cliFlags, "test.js")...)
}

// TestCloudRunWithArchive tests that if k6 uses a static archive with the script inside that has cloud options like:
//
//	export let options = {
//		cloud: {
//			name: "my load test",
//			projectID: 124,
//			note: "lorem ipsum",
//		}
//	};
//
// actually sends to the cloud the archive with the correct metadata (metadata.json), like:
//
//	"cloud": {
//	    "name": "my load test",
//	    "note": "lorem ipsum",
//	    "projectID": 124
//	}
func TestCloudRunWithArchive(t *testing.T) {
	t.Parallel()

	ts := NewGlobalTestState(t)

	inspectArchive := func(req *http.Request) {
		// v6 API uses "script" as the multipart field name (v1 used "file").
		file, _, err := req.FormFile("script")
		assert.NoError(t, err)
		assert.NotNil(t, file)

		// temporary write the archive for file system
		data, err := io.ReadAll(file)
		assert.NoError(t, err)

		tmpPath := filepath.Join(ts.Cwd, "archive_to_cloud.tar")
		require.NoError(t, fsext.WriteFile(ts.FS, tmpPath, data, 0o644))

		// check what inside
		require.NoError(t, testutils.Untar(t, ts.FS, tmpPath, "tmp/"))

		metadataRaw, err := fsext.ReadFile(ts.FS, "tmp/metadata.json")
		require.NoError(t, err)

		metadata := struct {
			Options struct {
				Cloud struct {
					Name      string `json:"name"`
					Note      string `json:"note"`
					ProjectID int    `json:"projectID"`
				} `json:"cloud"`
			} `json:"options"`
		}{}

		// then unpacked metadata should not contain any environment variables passed at the moment of archive creation
		require.NoError(t, json.Unmarshal(metadataRaw, &metadata))
		require.Equal(t, "my load test", metadata.Options.Cloud.Name)
		require.Equal(t, "lorem ipsum", metadata.Options.Cloud.Note)
		require.Equal(t, 124, metadata.Options.Cloud.ProjectID)
	}

	srv := v6test.NewServer(t, v6test.Config{
		InspectArchive: inspectArchive,
	})

	data, err := os.ReadFile(filepath.Join("testdata/archives", "archive_v1.0.0_with_cloud_option.tar")) //nolint:forbidigo // it's a test
	require.NoError(t, err)

	require.NoError(t, fsext.WriteFile(ts.FS, filepath.Join(ts.Cwd, "archive.tar"), data, 0o644))

	ts.CmdArgs = []string{"k6", "cloud", "run", "--verbose", "--log-output=stdout", "archive.tar"}
	ts.Env["K6_SHOW_CLOUD_LOGS"] = "false" // no mock for the logs yet
	ts.Env["K6_CLOUD_HOST_V6"] = srv.URL
	ts.Env["K6_CLOUD_TOKEN"] = "foo" // doesn't matter, we mock the cloud
	ts.Env["K6_CLOUD_STACK_ID"] = "1"

	cmd.ExecuteWithGlobalState(ts.GlobalState)

	stdout := ts.Stdout.String()
	t.Log(stdout)
	assert.NotContains(t, stdout, `not logged in`)
	assert.Contains(t, stdout, `execution: cloud`)
	assert.Contains(t, stdout, `hello world from archive`)
	assert.Contains(t, stdout, `output: https://stack.grafana.com/a/k6-app/runs/123`)
	assert.Contains(t, stdout, `test status: Finished`)
}

func TestCloudRunCommandIncompatibleFlags(t *testing.T) {
	t.Parallel()

	testCases := []struct {
		name               string
		cliArgs            []string
		wantStderrContains string
	}{
		{
			name:               "using --linger should be incompatible with k6 cloud run",
			cliArgs:            []string{"--linger"},
			wantStderrContains: "the --linger flag can only be used in conjunction with the --local-execution flag",
		},
		{
			name:               "using --exit-on-running should be incompatible with k6 cloud run --local-execution",
			cliArgs:            []string{"--local-execution", "--exit-on-running"},
			wantStderrContains: "the --local-execution flag is not compatible with the --exit-on-running flag",
		},
		{
			name:               "using --show-logs should be incompatible with k6 cloud run --local-execution",
			cliArgs:            []string{"--local-execution", "--show-logs"},
			wantStderrContains: "the --local-execution flag is not compatible with the --show-logs flag",
		},
		{
			name:               "--secret-source=cloud is not a valid value",
			cliArgs:            []string{"--secret-source=cloud"},
			wantStderrContains: "'cloud' is not a valid value for --secret-source",
		},
		{
			name:               "--secret-source=cloud is not a valid value even with --local-execution",
			cliArgs:            []string{"--local-execution", "--secret-source=cloud"},
			wantStderrContains: "'cloud' is not a valid value for --secret-source",
		},
		{
			name:               "using --no-cloud-secrets without --local-execution should fail",
			cliArgs:            []string{"--no-cloud-secrets"},
			wantStderrContains: "the --no-cloud-secrets flag can only be used in conjunction with the --local-execution flag",
		},
		{
			name:               "using --no-cloud-logs without --local-execution should fail",
			cliArgs:            []string{"--no-cloud-logs"},
			wantStderrContains: "the --no-cloud-logs flag can only be used in conjunction with the --local-execution flag",
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			ts := getSimpleCloudTestState(t, nil, setupK6CloudRunCmd, tc.cliArgs, nil)
			ts.ExpectedExitCode = int(exitcodes.InvalidConfig)
			cmd.ExecuteWithGlobalState(ts.GlobalState)

			stderr := ts.Stderr.String()
			assert.Contains(t, stderr, tc.wantStderrContains)
		})
	}
}

func TestCloudRunLocalExecution(t *testing.T) {
	t.Parallel()

	t.Run("should upload the test archive via presigned S3 URL as a default", func(t *testing.T) {
		t.Parallel()

		script := `
export const options = {
  cloud: {
      name: 'Hello k6 Cloud!',
      projectID: 123456,
  },
};

export default function() {};`

		ts := makeTestState(t, script, []string{"--local-execution"})

		srv := provtest.NewServer(t)

		// v6 CreateOrFindLoadTest: POST /cloud/v6/projects/{projectID}/load_tests
		srv.HandleCreateLoadTest(123456, func(w http.ResponseWriter, r *http.Request) {
			assert.Equal(t, http.MethodPost, r.Method)
			res := k6cloud.NewLoadTestApiModelWithDefaults()
			res.SetId(provtest.DefaultLoadTestID)
			writeProvJSON(w, http.StatusCreated, res)
		})

		// start_local_execution: check request body and return response
		var startCalled atomic.Bool
		srv.HandleStartLocalExecution(provtest.DefaultLoadTestID, func(w http.ResponseWriter, r *http.Request) {
			startCalled.Store(true)

			body, err := io.ReadAll(r.Body)
			require.NoError(t, err)

			var payload map[string]any
			require.NoError(t, json.Unmarshal(body, &payload))

			// Verify options field is present and contains resolved lib.Options
			assert.Contains(t, payload, "options")

			// Verify archive_size > 0
			assert.Contains(t, payload, "archive_size")
			archiveSize, ok := payload["archive_size"].(float64)
			assert.True(t, ok, "archive_size should be a number")
			assert.Greater(t, archiveSize, float64(0), "archive_size should be > 0")

			resp := provtest.DefaultStartLocalExecutionResponse()
			// Override URLs to point to the test server
			uploadURL := srv.URL + provtest.PresignedUploadPath
			resp.SetArchiveUploadUrl(uploadURL)
			resp.SetTestRunDetailsPageUrl(fmt.Sprintf("%s/runs/%d", srv.URL, provtest.DefaultTestRunID))
			// Override metrics push URL to point to the test server
			rc := resp.GetRuntimeConfig()
			m := rc.GetMetrics()
			m.SetPushUrl(srv.URL + "/v1/metrics")
			rc.SetMetrics(m)
			// Point the logs push_url at the test server too, so the
			// configured pusher never contacts the real logs host.
			l := rc.GetLogs()
			l.SetPushUrl(srv.URL + logsPushPath)
			rc.SetLogs(l)
			resp.SetRuntimeConfig(rc)
			writeProvJSON(w, http.StatusOK, resp)
		})

		// presigned archive upload
		var archiveUploaded atomic.Bool
		srv.HandlePresignedUpload(provtest.PresignedUploadPath, func(w http.ResponseWriter, r *http.Request) {
			archiveUploaded.Store(true)
			body, err := io.ReadAll(r.Body)
			require.NoError(t, err)
			assert.Greater(t, len(body), 0, "archive upload body should not be empty")
			assert.Equal(t, "application/x-tar", r.Header.Get("Content-Type"))
			w.WriteHeader(http.StatusOK)
		})

		// v6 FetchTestRun: return "initializing" immediately
		srv.HandleFetchTestRun(provtest.DefaultTestRunID, []v6.TestProgress{
			{Status: v6.StatusInitializing},
		})

		// notify: verify it's called
		var notifyCalled atomic.Bool
		srv.HandleNotify(provtest.DefaultTestRunID, func(w http.ResponseWriter, _ *http.Request) {
			notifyCalled.Store(true)
			w.WriteHeader(http.StatusOK)
		})

		// catch-all for metrics pushes and other calls
		srv.Mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		stdout := ts.Stdout.String()
		t.Log(stdout)
		assert.Contains(t, stdout, "execution: local")
		assert.Contains(t, stdout, fmt.Sprintf("output: cloud (%s/runs/%d)", srv.URL, provtest.DefaultTestRunID))
		assert.True(t, startCalled.Load(), "start_local_execution should have been called")
		assert.True(t, archiveUploaded.Load(), "archive should have been uploaded via presigned URL")
		assert.True(t, notifyCalled.Load(), "notify should have been called at test end")
	})

	t.Run("does not upload the archive when --no-archive-upload is provided", func(t *testing.T) {
		t.Parallel()

		script := `
export const options = {
  cloud: {
      name: 'Hello k6 Cloud!',
      projectID: 123456,
  },
};

export default function() {};`

		ts := makeTestState(t, script, []string{"--local-execution", "--no-archive-upload"})

		srv := provtest.NewServer(t)

		srv.HandleCreateLoadTest(123456, func(w http.ResponseWriter, _ *http.Request) {
			res := k6cloud.NewLoadTestApiModelWithDefaults()
			res.SetId(provtest.DefaultLoadTestID)
			writeProvJSON(w, http.StatusCreated, res)
		})

		// start_local_execution: verify archive_size is null
		srv.HandleStartLocalExecution(provtest.DefaultLoadTestID, func(w http.ResponseWriter, r *http.Request) {
			body, err := io.ReadAll(r.Body)
			require.NoError(t, err)

			var payload map[string]any
			require.NoError(t, json.Unmarshal(body, &payload))

			// archive_size should be explicitly null (Go JSON unmarshals null as nil)
			assert.Contains(t, payload, "archive_size")
			assert.Nil(t, payload["archive_size"], "archive_size should be null when --no-archive-upload is provided")

			resp := provtest.DefaultStartLocalExecutionResponse()
			// No upload URL when --no-archive-upload is set
			resp.ArchiveUploadUrl.Unset()
			resp.SetTestRunDetailsPageUrl(fmt.Sprintf("%s/runs/%d", srv.URL, provtest.DefaultTestRunID))
			rc := resp.GetRuntimeConfig()
			m := rc.GetMetrics()
			m.SetPushUrl(srv.URL + "/v1/metrics")
			rc.SetMetrics(m)
			// Point the logs push_url at the test server too, so the
			// configured pusher never contacts the real logs host.
			l := rc.GetLogs()
			l.SetPushUrl(srv.URL + logsPushPath)
			rc.SetLogs(l)
			resp.SetRuntimeConfig(rc)
			writeProvJSON(w, http.StatusOK, resp)
		})

		// Archive upload should NOT be called
		var archiveUploaded atomic.Bool
		srv.HandlePresignedUpload(provtest.PresignedUploadPath, func(w http.ResponseWriter, _ *http.Request) {
			archiveUploaded.Store(true)
			w.WriteHeader(http.StatusOK)
		})

		srv.HandleFetchTestRun(provtest.DefaultTestRunID, []v6.TestProgress{
			{Status: v6.StatusInitializing},
		})

		srv.HandleNotify(provtest.DefaultTestRunID, func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		srv.Mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		stdout := ts.Stdout.String()
		t.Log(stdout)
		assert.Contains(t, stdout, "execution: local")
		assert.Contains(t, stdout, fmt.Sprintf("output: cloud (%s/runs/%d)", srv.URL, provtest.DefaultTestRunID))
		assert.False(t, archiveUploaded.Load(), "archive should NOT have been uploaded when --no-archive-upload is set")
	})

	t.Run("the script can read the test run id to the environment", func(t *testing.T) {
		t.Parallel()

		script := `
export const options = {
  cloud: {
      name: 'Hello k6 Cloud!',
      projectID: 123456,
  },
};

export default function() {
	` + "console.log(`The test run id is ${__ENV.K6_CLOUDRUN_TEST_RUN_ID}`);" + `
};`

		ts := makeTestState(t, script, []string{"--local-execution", "--log-output=stdout"})

		srv := provtest.NewServer(t)

		srv.HandleCreateLoadTest(123456, func(w http.ResponseWriter, _ *http.Request) {
			res := k6cloud.NewLoadTestApiModelWithDefaults()
			res.SetId(provtest.DefaultLoadTestID)
			writeProvJSON(w, http.StatusCreated, res)
		})

		srv.HandleStartLocalExecution(provtest.DefaultLoadTestID, func(w http.ResponseWriter, _ *http.Request) {
			resp := provtest.DefaultStartLocalExecutionResponse()
			uploadURL := srv.URL + provtest.PresignedUploadPath
			resp.SetArchiveUploadUrl(uploadURL)
			resp.SetTestRunDetailsPageUrl(fmt.Sprintf("%s/runs/%d", srv.URL, provtest.DefaultTestRunID))
			rc := resp.GetRuntimeConfig()
			m := rc.GetMetrics()
			m.SetPushUrl(srv.URL + "/v1/metrics")
			rc.SetMetrics(m)
			// Point the logs push_url at the test server too, so the
			// configured pusher never contacts the real logs host.
			l := rc.GetLogs()
			l.SetPushUrl(srv.URL + logsPushPath)
			rc.SetLogs(l)
			resp.SetRuntimeConfig(rc)
			writeProvJSON(w, http.StatusOK, resp)
		})

		srv.HandlePresignedUpload(provtest.PresignedUploadPath, func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		srv.HandleFetchTestRun(provtest.DefaultTestRunID, []v6.TestProgress{
			{Status: v6.StatusInitializing},
		})

		srv.HandleNotify(provtest.DefaultTestRunID, func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		srv.Mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		stdout := ts.Stdout.String()
		t.Log(stdout)
		assert.Contains(t, stdout, "execution: local")
		assert.Contains(t, stdout, fmt.Sprintf("output: cloud (%s/runs/%d)", srv.URL, provtest.DefaultTestRunID))
		assert.Contains(t, stdout, "The test run id is "+strconv.Itoa(int(provtest.DefaultTestRunID)))
	})

	t.Run("reuses existing test run when K6_CLOUD_PUSH_REF_ID is set", func(t *testing.T) {
		t.Parallel()

		script := `
export const options = {
  cloud: {
	  name: 'Hello k6 Cloud!',
	  projectID: 123456,
  },
};

export default function() {
    ` + "console.log(`The test run id is ${__ENV.K6_CLOUDRUN_TEST_RUN_ID}`);" + `
};`

		ts := makeTestState(t, script, []string{"--local-execution", "--log-output=stdout"})

		const pushRefID = "99999"
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = pushRefID

		srv := getTestServer(t, map[string]http.Handler{
			"POST ^/v1/tests$": http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
				require.Fail(t, "CreateTestRun must not be called when K6_CLOUD_PUSH_REF_ID is set")
			}),
			"POST ^/provisioning/v1/": http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
				require.Fail(t, "provisioning API must not be called when K6_CLOUD_PUSH_REF_ID is set")
			}),
			"POST ^/cloud/v6/projects/": http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
				require.Fail(t, "v6 load_tests API must not be called when K6_CLOUD_PUSH_REF_ID is set")
			}),
		})
		t.Cleanup(srv.Close)
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		stdout := ts.Stdout.String()
		t.Log(stdout)

		assert.Contains(t, stdout, "execution: local")
		assert.Contains(t, stdout, "output: cloud (https://app.k6.io/runs/"+pushRefID+")")
		assert.Contains(t, stdout, "The test run id is "+pushRefID)
	})
}

func TestCloudRunLocalExecutionNoCloudSecrets(t *testing.T) {
	t.Parallel()

	script := `
export const options = {
  cloud: {
      name: 'Test no-cloud-secrets',
      projectID: 123456,
  },
};
export default function() {};`

	ts := makeTestState(t, script, []string{"--local-execution", "--no-cloud-secrets"})

	srv := provtest.NewServer(t)

	srv.HandleCreateLoadTest(123456, func(w http.ResponseWriter, _ *http.Request) {
		res := k6cloud.NewLoadTestApiModelWithDefaults()
		res.SetId(provtest.DefaultLoadTestID)
		writeProvJSON(w, http.StatusCreated, res)
	})

	srv.HandleStartLocalExecution(provtest.DefaultLoadTestID, func(w http.ResponseWriter, _ *http.Request) {
		resp := provtest.DefaultStartLocalExecutionResponse()
		uploadURL := srv.URL + provtest.PresignedUploadPath
		resp.SetArchiveUploadUrl(uploadURL)
		resp.SetTestRunDetailsPageUrl(fmt.Sprintf("%s/runs/%d", srv.URL, provtest.DefaultTestRunID))
		rc := resp.GetRuntimeConfig()
		m := rc.GetMetrics()
		m.SetPushUrl(srv.URL + "/v1/metrics")
		rc.SetMetrics(m)
		// Point the logs push_url at the test server too, so the
		// configured pusher never contacts the real logs host.
		l := rc.GetLogs()
		l.SetPushUrl(srv.URL + logsPushPath)
		rc.SetLogs(l)
		resp.SetRuntimeConfig(rc)
		writeProvJSON(w, http.StatusOK, resp)
	})

	srv.HandlePresignedUpload(provtest.PresignedUploadPath, func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	srv.HandleFetchTestRun(provtest.DefaultTestRunID, []v6.TestProgress{
		{Status: v6.StatusInitializing},
	})

	srv.HandleNotify(provtest.DefaultTestRunID, func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	srv.Mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	ts.Env["K6_CLOUD_HOST"] = srv.URL
	ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

	cmd.ExecuteWithGlobalState(ts.GlobalState)

	// --no-cloud-secrets must prevent the cloud source from being registered.
	assert.Nil(t, ts.CloudSecretSource, "cloud secret source should not be registered when --no-cloud-secrets is set")
}

func TestCloudRunLocalExecutionCloudLogPusher(t *testing.T) {
	t.Parallel()

	// The VU logs one line so the pusher has a deterministic entry to push;
	// console.log routes through the same logger the pusher hooks.
	script := `
export const options = {
  cloud: {
      name: 'Test cloud logs',
      projectID: 123456,
  },
};
export default function() { console.log('hello from the vu'); };`

	t.Run("registers the pusher for --local-execution", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		rec := setupLocalExecutionProvMock(t, ts)

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		assert.NotNil(t, ts.CloudLogPusher,
			"cloud log pusher should be registered for k6 cloud run --local-execution")

		// The self-provisioned flow must configure the pusher from the
		// provisioning response: streams are pushed with the scoped token
		// and the result's TestRunID as the test_run_id label.
		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		assert.Equal(t, "Bearer test-run-token-abc", auths[0])
		assert.Contains(t, bodies[0],
			fmt.Sprintf(`"test_run_id":"%d"`, provtest.DefaultTestRunID))
	})

	t.Run("configures the pusher from env for an externally-provisioned run", func(t *testing.T) {
		t.Parallel()

		rec := &logPushRecorder{}
		const pushRefID = "99999"

		srv := getTestServer(t, map[string]http.Handler{
			"POST ^" + logsPushPath + "$": http.HandlerFunc(rec.handler),
			"POST ^/v1/tests$": http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
				require.Fail(t, "CreateTestRun must not be called when K6_CLOUD_PUSH_REF_ID is set")
			}),
			"POST ^/provisioning/v1/": http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
				require.Fail(t, "provisioning API must not be called when K6_CLOUD_PUSH_REF_ID is set")
			}),
		})
		t.Cleanup(srv.Close)

		ts := makeTestState(t, script, []string{"--local-execution"})
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = pushRefID
		ts.Env["K6_CLOUD_LOGS_PUSH_URL"] = srv.URL + logsPushPath
		// An external orchestrator supplies the scoped metrics push creds
		// (PR #6133); they must be set together, and the same token is used
		// as the Bearer for the logs push.
		ts.Env["K6_CLOUD_METRICS_PUSH_URL"] = srv.URL + "/v1/metrics"
		ts.Env["K6_CLOUD_TEST_RUN_TOKEN"] = "ext-token"

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		require.NotNil(t, ts.CloudLogPusher,
			"cloud log pusher should be registered for an externally-provisioned --local-execution run")

		// The externally-provisioned flow reads the logs config and token
		// from env; the run id is the PushRefID.
		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		assert.Equal(t, "Bearer ext-token", auths[0])
		assert.Contains(t, bodies[0], `"test_run_id":"`+pushRefID+`"`)
	})

	t.Run("externally-provisioned run keeps test_run_id with empty allowed labels", func(t *testing.T) {
		t.Parallel()

		rec := &logPushRecorder{}
		const pushRefID = "99999"

		srv := getTestServer(t, map[string]http.Handler{
			"POST ^" + logsPushPath + "$": http.HandlerFunc(rec.handler),
		})
		t.Cleanup(srv.Close)

		ts := makeTestState(t, script, []string{"--local-execution"})
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = pushRefID
		ts.Env["K6_CLOUD_LOGS_PUSH_URL"] = srv.URL + logsPushPath
		ts.Env["K6_CLOUD_METRICS_PUSH_URL"] = srv.URL + "/v1/metrics"
		ts.Env["K6_CLOUD_TEST_RUN_TOKEN"] = "ext-token"
		// An explicitly empty allow-list decodes to []string{}; the required
		// test_run_id label must still survive rather than be stripped.
		ts.Env["K6_CLOUD_LOGS_ALLOWED_LABELS"] = ""

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		_, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		assert.Contains(t, bodies[0], `"test_run_id":"`+pushRefID+`"`,
			"test_run_id must survive an empty K6_CLOUD_LOGS_ALLOWED_LABELS")
	})

	t.Run("does not register the pusher with --no-cloud-logs", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution", "--no-cloud-logs"})
		rec := setupLocalExecutionProvMock(t, ts)

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		assert.Nil(t, ts.CloudLogPusher,
			"cloud log pusher should not be registered when --no-cloud-logs is set")
		_, bodies := rec.snapshot()
		assert.Empty(t, bodies, "no logs should be pushed when --no-cloud-logs is set")
	})

	t.Run("does not register the pusher for non-local-execution", func(t *testing.T) {
		t.Parallel()

		ts := NewGlobalTestState(t)
		require.NoError(t, fsext.WriteFile(ts.FS, filepath.Join(ts.Cwd, "test.js"), []byte(script), 0o644))
		ts.CmdArgs = []string{"k6", "run", "test.js"}

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		assert.Nil(t, ts.CloudLogPusher,
			"cloud log pusher should not be registered for a non-local-execution run")
	})

	// The subtests below mirror TestCloudMetricsPushCredentials (which pins the metrics
	// push-credential resolution) for the cloud *log* push: the observable
	// is which bearer token / URL k6 streams logs with across the
	// self-provisioned, externally-provisioned and legacy paths. The
	// sentinel token consts (scopedToken, bogusToken, extToken,
	// staleConfigToken, orgToken) are shared with
	// cmd_cloud_run_push_credentials_test.go.

	// A2 (log): a stray K6_CLOUD_TEST_RUN_TOKEN in the env must NOT override
	// the run-scoped token the self-provisioned flow gets from provisioning.
	// The token is programmatic-only (no envconfig), so the stray is inert.
	t.Run("self-provisioned log push ignores a stray token env var", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		rec := setupLocalExecutionProvMock(t, ts)
		ts.Env["K6_CLOUD_TEST_RUN_TOKEN"] = bogusToken

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		for _, a := range auths {
			assert.Equalf(t, "Bearer "+scopedToken, a,
				"log push must use the run-scoped token, not the stray env token %q", bogusToken)
		}
	})

	// A3 (log): a stray K6_CLOUD_LOGS_PUSH_URL must NOT override the
	// provisioning-supplied logs URL. conf.Apply(runtime_config) overwrites
	// the env value. If it leaked, the push would go to the unroutable host
	// and the provisioning logs endpoint (rec) would record nothing.
	t.Run("self-provisioned log push ignores a stray logs-push-URL env var", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		rec := setupLocalExecutionProvMock(t, ts)
		ts.Env["K6_CLOUD_LOGS_PUSH_URL"] = "http://stray.invalid/logs/push"

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies,
			"log push must hit the provisioning logs URL, not the stray env URL")
		for _, a := range auths {
			assert.Equal(t, "Bearer "+scopedToken, a)
		}
	})

	// A4 (log): both stray env vars at once — scoped token + provisioning URL
	// must still win.
	t.Run("self-provisioned log push ignores both stray env vars", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		rec := setupLocalExecutionProvMock(t, ts)
		ts.Env["K6_CLOUD_TEST_RUN_TOKEN"] = bogusToken
		ts.Env["K6_CLOUD_LOGS_PUSH_URL"] = "http://stray.invalid/logs/push"

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies,
			"log push must hit the provisioning logs URL with the scoped token")
		for _, a := range auths {
			assert.Equal(t, "Bearer "+scopedToken, a)
		}
	})

	// A8 (log): a stale testRunToken living in the k6 config file must NOT
	// override the run-scoped token in the self-provisioned flow.
	t.Run("self-provisioned log push ignores a stale config-file token", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		rec := setupLocalExecutionProvMock(t, ts)
		cfg := []byte(`{"collectors":{"cloud":{"testRunToken":"` + staleConfigToken + `"}}}`)
		require.NoError(t, ts.FS.MkdirAll(filepath.Dir(ts.Flags.ConfigFilePath), 0o755))
		require.NoError(t, fsext.WriteFile(ts.FS, ts.Flags.ConfigFilePath, cfg, 0o644))

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		auths, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		for _, a := range auths {
			assert.Equalf(t, "Bearer "+scopedToken, a,
				"log push must use the run-scoped token, not the stale config token %q", staleConfigToken)
		}
	})

	// B2 (log): partial scoped creds (only the token) must error before any
	// log push happens.
	t.Run("errors on partial scoped creds and pushes no logs", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution", "--log-output=stdout"})
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = "99999"
		ts.Env["K6_CLOUD_TEST_RUN_TOKEN"] = extToken // only one of the required pair
		ts.ExpectedExitCode = -1

		rec := &logPushRecorder{}
		srv := getTestServer(t, map[string]http.Handler{
			"POST ^" + logsPushPath + "$": http.HandlerFunc(rec.handler),
		})
		t.Cleanup(srv.Close)
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		out := ts.Stdout.String() + ts.Stderr.String()
		assert.Contains(t, out, "must be set together",
			"expected a clear both-or-neither error for partial scoped creds")
		_, bodies := rec.snapshot()
		assert.Empty(t, bodies, "no cloud log push should happen when the run errors out")
	})

	// A logs push URL in the externally-provisioned flow is useless without the
	// scoped token; it must error rather than silently stream nothing.
	t.Run("errors when a logs push URL is set without a token", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution", "--log-output=stdout"})
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = "99999"
		ts.Env["K6_CLOUD_LOGS_PUSH_URL"] = "http://logs.invalid/push"
		// No K6_CLOUD_TEST_RUN_TOKEN (nor the K6_CLOUD_METRICS_PUSH_URL it
		// pairs with), so there is no token to authenticate the logs push.
		ts.ExpectedExitCode = -1

		srv := getTestServer(t, map[string]http.Handler{})
		t.Cleanup(srv.Close)
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		out := ts.Stdout.String() + ts.Stderr.String()
		assert.Contains(t, out, "K6_CLOUD_LOGS_PUSH_URL requires K6_CLOUD_TEST_RUN_TOKEN")
	})

	// A5/A6 (log): the legacy `k6 run --out=cloud` path must not register a
	// cloud log pusher at all (log streaming is a --local-execution feature).
	t.Run("does not register the pusher for k6 run --out=cloud", func(t *testing.T) {
		t.Parallel()

		ts := getSingleFileTestState(t, script, []string{"-v", "--log-output=stdout", "--out=cloud"}, 0)
		ts.Env["K6_CLOUD_TOKEN"] = orgToken
		const refID = 1337
		srv := getTestServer(t, map[string]http.Handler{
			"POST ^/v1/tests$": http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				w.WriteHeader(http.StatusOK)
				_, _ = fmt.Fprintf(w, `{"reference_id": "%d", "config": {}}`, refID)
			}),
		})
		t.Cleanup(srv.Close)
		ts.Env["K6_CLOUD_HOST"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		assert.Nil(t, ts.CloudLogPusher,
			"cloud log streaming is only for cloud run --local-execution, not --out=cloud")
	})

	// A6 (log): a PushRefID relay run with no scoped creds and no logs push
	// URL must not push logs anywhere (the pusher stays unconfigured).
	t.Run("relay run without a logs push URL pushes no logs", func(t *testing.T) {
		t.Parallel()

		ts := makeTestState(t, script, []string{"--local-execution"})
		ts.Env["K6_CLOUD_PUSH_REF_ID"] = "99999"

		rec := &logPushRecorder{}
		srv := getTestServer(t, map[string]http.Handler{
			"POST ^/v1/tests$":            failHandler(t, "CreateTestRun must not be called with PushRefID"),
			"POST ^/provisioning/v1/":     failHandler(t, "provisioning API must not be called with PushRefID"),
			"POST ^" + logsPushPath + "$": http.HandlerFunc(rec.handler),
		})
		t.Cleanup(srv.Close)
		ts.Env["K6_CLOUD_HOST"] = srv.URL
		ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		_, bodies := rec.snapshot()
		assert.Empty(t, bodies,
			"a relay run with no logs push URL must not push logs anywhere")
	})

	// "and more" (beyond the metrics matrix): the pusher must honour the
	// backend-configured log level. The logger runs at debug (-v) so
	// console.debug reaches the pusher hook; the provisioning logs config
	// (level=info) must then drop it before pushing, while info survives.
	t.Run("self-provisioned log push filters lines below the configured level", func(t *testing.T) {
		t.Parallel()

		lvlScript := `
export const options = { cloud: { name: 'Test cloud logs', projectID: 123456 } };
export default function() {
	console.debug('debug-line-must-be-filtered');
	console.log('info-line-must-be-pushed');
};`
		ts := makeTestState(t, lvlScript, []string{"--local-execution", "-v", "--log-output=stdout"})
		rec := setupLocalExecutionProvMock(t, ts)

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		_, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		all := strings.Join(bodies, "\n")
		assert.Contains(t, all, "info-line-must-be-pushed",
			"info-level lines should be pushed")
		assert.NotContains(t, all, "debug-line-must-be-filtered",
			"debug-level lines must be filtered out by the configured level (info)")
	})

	// A logged secret must reach the cloud only in redacted form: the
	// secrets-redaction hook runs before the pusher observes an entry
	// (root.go), so the push never carries the raw value. Guards that
	// property end to end.
	t.Run("redacts secrets before pushing logs", func(t *testing.T) {
		t.Parallel()

		const secret = "super-secret-value"
		secretScript := `
import secrets from "k6/secrets";
export const options = { cloud: { name: 'Test cloud logs', projectID: 123456 } };
export default async function() {
	const s = await secrets.get("mykey");
	console.log("the secret is " + s);
};`
		ts := makeTestState(t, secretScript, []string{
			"--local-execution", "--no-cloud-secrets",
			"--secret-source=mock=mykey=" + secret,
		})
		rec := setupLocalExecutionProvMock(t, ts)

		cmd.ExecuteWithGlobalState(ts.GlobalState)

		_, bodies := rec.snapshot()
		require.NotEmpty(t, bodies, "expected at least one cloud log push")
		all := strings.Join(bodies, "\n")
		assert.Contains(t, all, "***SECRET_REDACTED***",
			"the log line should reach the cloud only in redacted form")
		assert.NotContains(t, all, secret,
			"the raw secret must never reach the cloud log push")
	})
}

// logsPushPath is the path the local-execution mocks use for the cloud
// logs push endpoint, overriding the real host baked into
// DefaultStartLocalExecutionResponse so tests never contact it.
const logsPushPath = "/logs/v1/push"

// logPushRecorder captures cloud log pushes received by the mock server so
// tests can assert on the pusher wiring (auth header + test_run_id label).
type logPushRecorder struct {
	mu     sync.Mutex
	auths  []string
	bodies []string
}

func (r *logPushRecorder) handler(w http.ResponseWriter, req *http.Request) {
	body, _ := io.ReadAll(req.Body)
	r.mu.Lock()
	r.auths = append(r.auths, req.Header.Get("Authorization"))
	r.bodies = append(r.bodies, string(body))
	r.mu.Unlock()
	w.WriteHeader(http.StatusNoContent)
}

func (r *logPushRecorder) snapshot() (auths, bodies []string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]string(nil), r.auths...), append([]string(nil), r.bodies...)
}

// setupLocalExecutionProvMock wires a provisioning mock server for a
// k6 cloud run --local-execution flow and points ts at it. It mirrors the
// handlers used by TestCloudRunLocalExecutionNoCloudSecrets. The returned
// recorder captures any cloud log pushes; the logs push_url is overridden
// onto the mock server so the real logs host is never contacted.
func setupLocalExecutionProvMock(t *testing.T, ts *GlobalTestState) *logPushRecorder {
	t.Helper()

	rec := &logPushRecorder{}
	srv := provtest.NewServer(t)

	srv.HandleCreateLoadTest(123456, func(w http.ResponseWriter, _ *http.Request) {
		res := k6cloud.NewLoadTestApiModelWithDefaults()
		res.SetId(provtest.DefaultLoadTestID)
		writeProvJSON(w, http.StatusCreated, res)
	})

	srv.HandleStartLocalExecution(provtest.DefaultLoadTestID, func(w http.ResponseWriter, _ *http.Request) {
		resp := provtest.DefaultStartLocalExecutionResponse()
		uploadURL := srv.URL + provtest.PresignedUploadPath
		resp.SetArchiveUploadUrl(uploadURL)
		resp.SetTestRunDetailsPageUrl(fmt.Sprintf("%s/runs/%d", srv.URL, provtest.DefaultTestRunID))
		rc := resp.GetRuntimeConfig()
		m := rc.GetMetrics()
		m.SetPushUrl(srv.URL + "/v1/metrics")
		rc.SetMetrics(m)
		l := rc.GetLogs()
		l.SetPushUrl(srv.URL + logsPushPath)
		rc.SetLogs(l)
		resp.SetRuntimeConfig(rc)
		writeProvJSON(w, http.StatusOK, resp)
	})

	srv.HandlePresignedUpload(provtest.PresignedUploadPath, func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	srv.HandleFetchTestRun(provtest.DefaultTestRunID, []v6.TestProgress{
		{Status: v6.StatusInitializing},
	})

	srv.HandleNotify(provtest.DefaultTestRunID, func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	srv.Mux.HandleFunc("POST "+logsPushPath, rec.handler)

	srv.Mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	ts.Env["K6_CLOUD_HOST"] = srv.URL
	ts.Env["K6_CLOUD_HOST_V6"] = srv.URL

	return rec
}

func makeTestState(tb testing.TB, script string, cliFlags []string) *GlobalTestState {
	if cliFlags == nil {
		cliFlags = []string{"-v", "--log-output=stdout"}
	}

	ts := NewGlobalTestState(tb)
	require.NoError(tb, fsext.WriteFile(ts.FS, filepath.Join(ts.Cwd, "test.js"), []byte(script), 0o644))
	ts.CmdArgs = append(append([]string{"k6", "cloud", "run"}, cliFlags...), "test.js")
	ts.Env["K6_CLOUD_TOKEN"] = "foo"     // doesn't matter, we mock the cloud
	ts.Env["K6_CLOUD_STACK_ID"] = "1234" // doesn't matter, we mock the cloud

	return ts
}

func writeProvJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(v); err != nil {
		panic(fmt.Errorf("writeProvJSON: encoding JSON: %w", err))
	}
}
