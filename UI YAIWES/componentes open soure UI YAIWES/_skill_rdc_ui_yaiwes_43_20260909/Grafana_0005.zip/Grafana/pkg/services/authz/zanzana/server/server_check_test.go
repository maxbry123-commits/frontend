package server

import (
	"fmt"
	"testing"

	authzv1 "github.com/grafana/authlib/authz/proto/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/grafana/grafana/pkg/apimachinery/utils"
	"github.com/grafana/grafana/pkg/util/testutil"
)

func TestIntegrationServerCheck(t *testing.T) {
	testutil.SkipIntegrationTestInShortMode(t)

	server := setupOpenFGAServer(t)
	setup(t, server)

	newReq := func(subject, verb, group, resource, subresource, folder, name string) *authzv1.CheckRequest {
		return &authzv1.CheckRequest{
			Namespace:   namespace,
			Subject:     subject,
			Verb:        verb,
			Group:       group,
			Resource:    resource,
			Subresource: subresource,
			Name:        name,
			Folder:      folder,
		}
	}

	t.Run("user:1 should only be able to read resource:dashboard.grafana.app/dashboards/1", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		// sanity check
		res, err = server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "2"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())

		// sanity check no access to subresource
		res, err = server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "1", "1"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:2 should be able to read resource:dashboard.grafana.app/dashboards/1 through group_resource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:2", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:3 should be able to read resource:dashboard.grafana.app/dashboards/1 with set relation", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:3", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		// sanity check
		res, err = server.Check(newContextWithNamespace(), newReq("user:3", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "2"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:4 should be able to read all dashboard.grafana.app/dashboards in folder 1 and 3", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:4", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:4", utils.VerbGet, dashboardGroup, dashboardResource, "", "3", "2"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		// sanity check
		res, err = server.Check(newContextWithNamespace(), newReq("user:4", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "2"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:4", utils.VerbGet, dashboardGroup, dashboardResource, "", "2", "2"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:5 should be able to read resource:dashboard.grafana.app/dashboards/1 through folder with set relation", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:5", utils.VerbGet, dashboardGroup, dashboardResource, "", "1", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:6 should be able to read folder 1 ", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:6", utils.VerbGet, folderGroup, folderResource, "", "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:7 should be able to read folder one through group_resource access", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:7", utils.VerbGet, folderGroup, folderResource, "", "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:7", utils.VerbGet, folderGroup, folderResource, "", "", "10"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:8 should be able to read all resoruce:dashboard.grafana.app/dashboar in folder 6 through folder 5", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:8", utils.VerbGet, dashboardGroup, dashboardResource, "", "6", "10"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:8", utils.VerbGet, dashboardGroup, dashboardResource, "", "5", "11"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:8", utils.VerbGet, folderGroup, folderResource, "", "4", "12"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:9 should be able to create dashboards in folder 5", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:9", utils.VerbCreate, dashboardGroup, dashboardResource, "", "5", ""))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:10 should be able to read dashboard status for dashboard 10", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:10", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "", "10"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:10", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:11 should be able to read dashboard status for dashboard 10 through group_resource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:11", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "", "10"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:12 should be able to read dashboard status for all dashboards in folder 5", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:12", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "5", "10"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:12", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "5", "11"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		// inherited from folder 5
		res, err = server.Check(newContextWithNamespace(), newReq("user:12", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "6", "12"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:12", utils.VerbGet, dashboardGroup, dashboardResource, statusSubresource, "1", "13"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:13 should be able to read folder status for all subfolders of folder 5", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:13", utils.VerbGet, folderGroup, folderResource, statusSubresource, "", "5"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:13", utils.VerbGet, folderGroup, folderResource, statusSubresource, "", "6"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:13", utils.VerbGet, folderGroup, folderResource, statusSubresource, "", "4"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:14 should be able to read team subresources for team 1", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:14", utils.VerbGet, "iam.grafana.app", "teams", statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:15 should be able to read user subresources for user 1", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:15", utils.VerbGet, "iam.grafana.app", "users", statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:16 should be able to read serviceaccount subresources for serviceaccount 1", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:16", utils.VerbGet, "iam.grafana.app", "serviceaccounts", statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:17 should be able to view dashboards in folder 4 and all subfolders", func(t *testing.T) {
		// Check for folders
		res, err := server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, folderGroup, folderResource, "", "", "4"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, folderGroup, folderResource, "", "", "5"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, folderGroup, folderResource, "", "", "6"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		// Check for dashboards
		res, err = server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, dashboardGroup, dashboardResource, "", "4", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed(), "user should be able to view dashboards in folder 4")

		res, err = server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, dashboardGroup, dashboardResource, "", "5", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed(), "user should be able to view dashboards in folder 5")

		res, err = server.Check(newContextWithNamespace(), newReq("user:17", utils.VerbGet, dashboardGroup, dashboardResource, "", "6", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed(), "user should be able to view dashboards in folder 6")
	})

	t.Run("user:18 should be able to create folder in root folder", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:18", utils.VerbCreate, folderGroup, folderResource, "", "", ""))
		require.NoError(t, err)
		assert.Equal(t, true, res.GetAllowed())
	})

	t.Run("user:18 should be able to create dashboard in root folder", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:18", utils.VerbCreate, dashboardGroup, dashboardResource, "", "", ""))
		require.NoError(t, err)
		assert.Equal(t, true, res.GetAllowed())
	})

	t.Run("user should check dashboard access through teams from request", func(t *testing.T) {
		req := newReq("user:contextual", utils.VerbGet, dashboardGroup, dashboardResource, "", "", "ctx-check-dashboard")
		req.Teams = []string{"ctx-check"}
		res, err := server.Check(newContextWithNamespace(), req)
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())

		res, err = server.Check(newContextWithNamespace(), newReq("user:contextual", utils.VerbGet, dashboardGroup, dashboardResource, "", "", "ctx-check-dashboard"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user should check dashboard access with one thousand request teams", func(t *testing.T) {
		groups := make([]string, 1000)
		for i := range groups {
			groups[i] = fmt.Sprintf("irrelevant-%04d", i)
		}
		groups[999] = "ctx-1000"

		req := newReq("user:contextual-1000", utils.VerbGet, dashboardGroup, dashboardResource, "", "", "ctx-1000-dashboard")
		req.Teams = groups
		res, err := server.Check(newContextWithNamespace(), req)
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("wildcard name for typed resource should be allowed when subject has group_resource get_permissions and returns no error", func(t *testing.T) {
		// user:19 has get_permissions on the group_resource for users — they can manage
		// permissions for all users. A check with name="*" must succeed via group_resource only.
		res, err := server.Check(newContextWithNamespace(), newReq("user:19", utils.VerbGetPermissions, userGroup, userResource, "", "", "*"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	// Typed `create` checks. user / service-account have no per-object `create`, so a named
	// create check must resolve to denied rather than issue an invalid Check that errors.
	t.Run("named create check on user without access is denied, not errored", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbCreate, userGroup, userResource, "", "", "someuser"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("named create check on service-account without access is denied, not errored", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbCreate, serviceAccountGroup, serviceAccountResource, "", "", "some-sa"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("user:20 create check on users is allowed via group_resource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:20", utils.VerbCreate, userGroup, userResource, "", "", ""))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:21 (team admin) create check on their team is denied: team create is group_resource only", func(t *testing.T) {
		// teams have no per-object `create`; being admin of a team does not grant creating it.
		res, err := server.Check(newContextWithNamespace(), newReq("user:21", utils.VerbCreate, teamGroup, teamResource, "", "", "admin-team"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	// Subresource `create` must still resolve even though the base `create` relation does not
	// exist on user / service-account: the base-relation guard must not block the subresource
	// branch (the model defines resource_create for these types).
	t.Run("user:22 subresource create on a user is allowed via resource_create", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:22", utils.VerbCreate, userGroup, userResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:23 subresource create on a service-account is allowed via resource_create", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:23", utils.VerbCreate, serviceAccountGroup, serviceAccountResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("user:1 subresource create without grant is denied, not errored", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbCreate, userGroup, userResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	// user/team have no subresource get/set_permissions in the model (folder-only). A subresource
	// permissions check on them must not issue can_resource_get_permissions (which OpenFGA would
	// reject); the subresource branch is skipped and it resolves via the base relation instead.
	t.Run("user subresource get_permissions is denied, not errored", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbGetPermissions, userGroup, userResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("team subresource set_permissions is denied, not errored", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq("user:1", utils.VerbSetPermissions, teamGroup, teamResource, statusSubresource, "", "1"))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})
}

func TestIntegrationServerCheckGenericDatasourceCreate(t *testing.T) {
	testutil.SkipIntegrationTestInShortMode(t)

	server := setupOpenFGAServer(t)
	setup(t, server)

	newReq := func(verb, group, resource, subresource, name string) *authzv1.CheckRequest {
		return &authzv1.CheckRequest{
			Namespace:   namespace,
			Subject:     "user:u1",
			Verb:        verb,
			Group:       group,
			Resource:    resource,
			Subresource: subresource,
			Name:        name,
		}
	}

	t.Run("allows the granted query subresource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, datasourceResource, datasourceQuerySubresource, "ds-1",
		))
		require.NoError(t, err)
		assert.True(t, res.GetAllowed())
	})

	t.Run("denies another datasource UID", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, datasourceResource, datasourceQuerySubresource, "ds-2",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("subresource query tuple does not grant reading the datasource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbGet, datasourceGroup, datasourceResource, "", "ds-1",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("subresource query tuple does not grant creating the datasource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, datasourceResource, "", "ds-1",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("denies another group", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, "prometheus.datasource.grafana.app", datasourceResource, datasourceQuerySubresource, "ds-1",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("denies another resource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, "connections", datasourceQuerySubresource, "ds-1",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("denies another subresource", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, datasourceResource, "metadata", "ds-1",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})

	t.Run("does not grant group-wide datasource create", func(t *testing.T) {
		res, err := server.Check(newContextWithNamespace(), newReq(
			utils.VerbCreate, datasourceGroup, datasourceResource, "", "",
		))
		require.NoError(t, err)
		assert.False(t, res.GetAllowed())
	})
}
