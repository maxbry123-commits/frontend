package server

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"hash/fnv"
	"io"
	"sort"
	"strings"
	"time"

	authzv1 "github.com/grafana/authlib/authz/proto/v1"
	openfgav1 "github.com/openfga/api/proto/openfga/v1"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"google.golang.org/grpc"
	"google.golang.org/protobuf/proto"

	"github.com/grafana/grafana/pkg/services/authz/zanzana"
	"github.com/grafana/grafana/pkg/services/authz/zanzana/common"
)

func (s *Server) List(ctx context.Context, r *authzv1.ListRequest) (*authzv1.ListResponse, error) {
	release, err := s.acquireSlot("List", r.GetNamespace())
	if err != nil {
		return nil, err
	}
	defer release()

	ctx, span := s.tracer.Start(ctx, "server.List")
	defer span.End()
	span.SetAttributes(attribute.String("namespace", r.GetNamespace()))

	ctxLogger := s.logger.FromContext(ctx).New(
		"subject", r.GetSubject(),
		"namespace", r.GetNamespace(),
		"group", r.GetGroup(),
		"resource", r.GetResource(),
		"subresource", r.GetSubresource(),
		"verb", r.GetVerb(),
	)
	defer func(t time.Time) {
		s.metrics.requestDurationSeconds.WithLabelValues("List").Observe(time.Since(t).Seconds())
		ctxLogger.Debug("List execution time", "duration", time.Since(t).Milliseconds())
	}(time.Now())

	res, err := s.list(ctx, r)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		s.logger.Error("failed to perform list request", "error", err, "namespace", r.GetNamespace())
		return nil, errors.New("failed to perform list request")
	}

	return res, nil
}

func (s *Server) list(ctx context.Context, r *authzv1.ListRequest) (*authzv1.ListResponse, error) {
	if err := authorize(ctx, r.GetNamespace(), s.cfg); err != nil {
		return nil, err
	}

	store, err := s.getStoreInfo(ctx, r.GetNamespace())
	if err != nil {
		return nil, fmt.Errorf("failed to get openfga store: %w", err)
	}

	contextuals, err := s.getContextuals(r.GetSubject(), r.GetTeams())
	if err != nil {
		return nil, fmt.Errorf("failed to get contextual tuples: %w", err)
	}

	relation := common.VerbMapping[r.GetVerb()]
	resource := common.NewResourceInfoFromList(r)

	res, err := s.checkGroupResource(ctx, r.GetSubject(), relation, resource, contextuals, store)
	if err != nil {
		return nil, fmt.Errorf("failed to check group resource: %w", err)
	}

	if res.GetAllowed() {
		return &authzv1.ListResponse{All: true}, nil
	}

	if resource.IsGeneric() {
		return s.listGeneric(ctx, r.GetSubject(), relation, resource, contextuals, store)
	}

	return s.listTyped(ctx, r.GetSubject(), relation, resource, contextuals, store)
}

func (s *Server) listTyped(ctx context.Context, subject, relation string, resource common.ResourceInfo, contextuals *openfgav1.ContextualTupleKeys, store *zanzana.StoreInfo) (*authzv1.ListResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.listTyped")
	defer span.End()

	var (
		subresourceRelation = common.SubresourceRelation(relation)
		resourceCtx         = resource.Context()
	)

	// The subresource branch is gated on the subresource relation, independently of the base
	// relation: a type may support e.g. resource_create without a per-object base create
	// (user / service-account), so the base-relation guard below must not block it.
	var items []string
	if resource.HasSubresource() && resource.IsValidRelation(subresourceRelation) {
		// List requested subresources
		res, err := s.listObjects(ctx, &openfgav1.ListObjectsRequest{
			StoreId:              store.ID,
			AuthorizationModelId: store.ModelID,
			Type:                 resource.Type(),
			Relation:             common.SubresourcePermissionRelation(subresourceRelation),
			User:                 subject,
			Context:              resourceCtx,
		}, contextuals)

		if err != nil {
			return nil, err
		}

		items = append(items, typedObjects(resource.Type(), res.GetObjects())...)
	}

	// List all resources the subject has direct access to via the base relation.
	if resource.IsValidRelation(relation) {
		// Use optimized folder permission relations for permission management
		listRelation := relation
		if resource.Type() == common.TypeFolder {
			listRelation = common.FolderPermissionRelation(relation)
		}

		res, err := s.listObjects(ctx, &openfgav1.ListObjectsRequest{
			StoreId:              store.ID,
			AuthorizationModelId: store.ModelID,
			Type:                 resource.Type(),
			Relation:             listRelation,
			User:                 subject,
		}, contextuals)
		if err != nil {
			return nil, err
		}
		items = append(items, typedObjects(resource.Type(), res.GetObjects())...)
	}

	return &authzv1.ListResponse{
		Items: items,
	}, nil
}

func (s *Server) listGeneric(ctx context.Context, subject, relation string, resource common.ResourceInfo, contextuals *openfgav1.ContextualTupleKeys, store *zanzana.StoreInfo) (*authzv1.ListResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.listGeneric")
	defer span.End()

	var (
		folderRelation     = common.SubresourceRelation(relation)
		folderListRelation = common.FolderPermissionRelation(relation) // Optimized for permission management
		resourceCtx        = resource.Context()
	)

	// 1. List all folders subject has access to resource type in
	var folders []string
	if common.IsSubresourceRelation(folderRelation) {
		res, err := s.listObjects(ctx, &openfgav1.ListObjectsRequest{
			StoreId:              store.ID,
			AuthorizationModelId: store.ModelID,
			Type:                 common.TypeFolder,
			Relation:             common.SubresourcePermissionRelation(folderRelation),
			User:                 subject,
			Context:              resourceCtx,
		}, contextuals)

		if err != nil {
			return nil, err
		}

		folders = res.GetObjects()
	}

	// Special case for folder permission based resources (like dashboards in a folder)
	if isFolderPermissionBasedResource(resource.GroupResource()) {
		res, err := s.listObjects(ctx, &openfgav1.ListObjectsRequest{
			StoreId:              store.ID,
			AuthorizationModelId: store.ModelID,
			Type:                 common.TypeFolder,
			Relation:             folderListRelation,
			User:                 subject,
			Context:              resourceCtx,
		}, contextuals)

		if err != nil {
			return nil, err
		}

		folders = append(folders, res.GetObjects()...)
	}

	// 2. List all resource directly assigned to subject
	var objects []string
	if resource.IsValidRelation(relation) {
		res, err := s.listObjects(ctx, &openfgav1.ListObjectsRequest{
			StoreId:              store.ID,
			AuthorizationModelId: store.ModelID,
			Type:                 common.TypeResource,
			Relation:             relation,
			User:                 subject,
			Context:              resourceCtx,
		}, contextuals)
		if err != nil {
			return nil, err
		}

		objects = res.GetObjects()
	}

	return &authzv1.ListResponse{
		Folders: folderObject(folders),
		Items:   genericObjects(resource.GroupResource(), objects),
	}, nil
}

func (s *Server) listObjects(
	ctx context.Context,
	req *openfgav1.ListObjectsRequest,
	contextuals *openfgav1.ContextualTupleKeys,
) (*openfgav1.ListObjectsResponse, error) {
	chunks := contextualTupleChunks(contextuals)
	if len(chunks) == 0 {
		return s.doOpenFGAListObjects(ctx, cloneListObjectsRequestWithContextualTuples(req, nil))
	}
	if len(chunks) == 1 {
		return s.doOpenFGAListObjects(ctx, cloneListObjectsRequestWithContextualTuples(req, chunks[0]))
	}

	seen := make(map[string]struct{})
	var objects []string
	for _, chunk := range chunks {
		res, err := s.doOpenFGAListObjects(ctx, cloneListObjectsRequestWithContextualTuples(req, chunk))
		if err != nil {
			return nil, err
		}
		for _, object := range res.GetObjects() {
			if _, ok := seen[object]; ok {
				continue
			}
			seen[object] = struct{}{}
			objects = append(objects, object)
		}
	}
	sort.Strings(objects)
	return &openfgav1.ListObjectsResponse{Objects: objects}, nil
}

func cloneListObjectsRequestWithContextualTuples(req *openfgav1.ListObjectsRequest, contextuals *openfgav1.ContextualTupleKeys) *openfgav1.ListObjectsRequest {
	out := proto.Clone(req).(*openfgav1.ListObjectsRequest)
	out.ContextualTuples = contextuals
	return out
}

// doOpenFGAListObjects resolves ListObjects via OpenFGA's StreamedListObjects RPC (see streamedListObjects),
// aggregating all streamed objects. That avoids unary ListObjects max-result truncation for large sets.
func (s *Server) doOpenFGAListObjects(ctx context.Context, req *openfgav1.ListObjectsRequest) (*openfgav1.ListObjectsResponse, error) {
	fn := s.streamedListObjects

	if s.cfg.CacheSettings.CheckQueryCacheEnabled {
		return s.listObjectCached(ctx, req, fn)
	}

	res, err := fn(ctx, req)
	if err != nil {
		s.logger.Error("failed to perform openfga ListObjects request", "error", errors.Unwrap(err), "user", req.GetUser(), "type", req.GetType(), "relation", req.GetRelation())
		return nil, err
	}

	return res, nil
}

type listFn func(ctx context.Context, req *openfgav1.ListObjectsRequest, opts ...grpc.CallOption) (*openfgav1.ListObjectsResponse, error)

func (s *Server) listObjectCached(ctx context.Context, req *openfgav1.ListObjectsRequest, fn listFn) (*openfgav1.ListObjectsResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.listObjectCached")
	defer span.End()

	key, err := getRequestHash(req)
	if err != nil {
		return nil, err
	}

	if res, ok := s.cache.Get(key); ok {
		return res.(*openfgav1.ListObjectsResponse), nil
	}

	res, err := fn(ctx, req)
	if err != nil {
		return nil, err
	}

	s.cache.Set(key, res, 0)
	return res, nil
}

func (s *Server) streamedListObjects(ctx context.Context, req *openfgav1.ListObjectsRequest, opts ...grpc.CallOption) (*openfgav1.ListObjectsResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.streamedListObjects")
	defer span.End()

	ctx, cancel := s.withListObjectsClientDeadline(ctx)
	defer cancel()

	r := &openfgav1.StreamedListObjectsRequest{
		StoreId:              req.GetStoreId(),
		AuthorizationModelId: req.GetAuthorizationModelId(),
		Type:                 req.GetType(),
		Relation:             req.GetRelation(),
		User:                 req.GetUser(),
		Context:              req.GetContext(),
		ContextualTuples:     req.ContextualTuples,
	}

	stream, err := s.openFGAClient.StreamedListObjects(ctx, r, opts...)
	if err != nil {
		return nil, err
	}

	var objects []string
	for {
		res, err := stream.Recv()
		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}
			return nil, err
		}
		objects = append(objects, res.GetObject())
	}

	if ctx.Err() != nil {
		return nil, fmt.Errorf("streamed list objects interrupted: %w", ctx.Err())
	}

	return &openfgav1.ListObjectsResponse{
		Objects: objects,
	}, nil
}

// withListObjectsClientDeadline returns a context that expires slightly before cfg.ListObjectsDeadline
// (the OpenFGA server-side stream deadline). That lets the client cancel first and avoids racing the
// server/stream deadline. For server deadlines under 1s, uses a small margin instead of deadline-1s.
func (s *Server) withListObjectsClientDeadline(ctx context.Context) (context.Context, context.CancelFunc) {
	deadline := s.cfg.ListObjectsDeadline
	if deadline <= 0 {
		deadline = 3 * time.Second
	}
	client := deadline - time.Second
	if client > 0 {
		return context.WithTimeout(ctx, client)
	}
	// deadline <= 1s: leave a margin under the server deadline without extending the budget.
	if deadline > time.Millisecond {
		client = deadline - time.Millisecond
	} else {
		client = deadline / 2
	}
	if client <= 0 {
		client = deadline
	}
	return context.WithTimeout(ctx, client)
}

func getRequestHash(req *openfgav1.ListObjectsRequest) (string, error) {
	hash := fnv.New64a()
	_, err := hash.Write([]byte(req.String()))
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(hash.Sum(nil)), nil
}

func typedObjects(typ string, objects []string) []string {
	prefix := typ + ":"
	out := make([]string, len(objects))
	for i := range objects {
		out[i] = strings.TrimPrefix(objects[i], prefix)
	}
	return out
}

func genericObjects(gr string, objects []string) []string {
	prefix := common.TypeResourcePrefix + gr + "/"
	out := make([]string, len(objects))
	for i := range objects {
		out[i] = strings.TrimPrefix(objects[i], prefix)
	}
	return out
}

func folderObject(objects []string) []string {
	out := make([]string, len(objects))
	for i := range objects {
		out[i] = strings.TrimPrefix(objects[i], common.TypeFolderPrefix)
	}
	return out
}
