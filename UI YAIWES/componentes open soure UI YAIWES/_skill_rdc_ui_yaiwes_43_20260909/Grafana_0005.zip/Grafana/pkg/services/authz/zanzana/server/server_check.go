package server

import (
	"context"
	"errors"
	"fmt"
	"time"

	authzv1 "github.com/grafana/authlib/authz/proto/v1"
	openfgav1 "github.com/openfga/api/proto/openfga/v1"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"google.golang.org/protobuf/types/known/structpb"

	"github.com/grafana/grafana/pkg/services/authz/zanzana"
	"github.com/grafana/grafana/pkg/services/authz/zanzana/common"
)

func (s *Server) Check(ctx context.Context, r *authzv1.CheckRequest) (*authzv1.CheckResponse, error) {
	release, err := s.acquireSlot("Check", r.GetNamespace())
	if err != nil {
		return nil, err
	}
	defer release()

	ctx, span := s.tracer.Start(ctx, "server.Check")
	defer span.End()
	span.SetAttributes(attribute.String("namespace", r.GetNamespace()))

	ctxLogger := s.logger.FromContext(ctx).New(
		"subject", r.GetSubject(),
		"namespace", r.GetNamespace(),
		"group", r.GetGroup(),
		"resource", r.GetResource(),
		"subresource", r.GetSubresource(),
		"verb", r.GetVerb(),
	)
	defer func(t time.Time) {
		s.metrics.requestDurationSeconds.WithLabelValues("Check").Observe(time.Since(t).Seconds())
		ctxLogger.Debug("Check execution time", "duration", time.Since(t).Milliseconds())
	}(time.Now())

	if err := s.mtReconciler.EnsureNamespace(ctx, r.GetNamespace()); err != nil {
		return nil, fmt.Errorf("failed to reconcile namespace: %w", err)
	}

	res, err := s.check(ctx, r)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		s.logger.Error("failed to perform check request", "error", err, "namespace", r.GetNamespace())
		return nil, errors.New("failed to perform check request")
	}

	return res, nil
}

func (s *Server) check(ctx context.Context, r *authzv1.CheckRequest) (*authzv1.CheckResponse, error) {
	if err := authorize(ctx, r.GetNamespace(), s.cfg); err != nil {
		return nil, err
	}

	store, err := s.getStoreInfo(ctx, r.GetNamespace())
	if err != nil {
		return nil, fmt.Errorf("failed to get openfga store: %w", err)
	}

	relation := common.VerbMapping[r.GetVerb()]

	contextuals, err := s.getContextuals(r.GetSubject(), r.GetTeams())
	if err != nil {
		return nil, fmt.Errorf("failed to get contextual tuples: %w", err)
	}

	resource := common.NewResourceInfoFromCheck(r)
	res, err := s.checkGroupResource(ctx, r.GetSubject(), relation, resource, contextuals, store)
	if err != nil {
		return nil, fmt.Errorf("failed to check group resource: %w", err)
	}

	if res.GetAllowed() {
		return res, nil
	}

	if resource.IsGeneric() {
		res, err = s.checkGeneric(ctx, r.GetSubject(), relation, resource, contextuals, store)
		if err != nil {
			return nil, fmt.Errorf("failed to check generic resource: %w", err)
		}
		return res, nil
	}

	res, err = s.checkTyped(ctx, r.GetSubject(), relation, resource, contextuals, store)
	if err != nil {
		return nil, fmt.Errorf("failed to check typed resource: %w", err)
	}
	return res, nil
}

// checkGroupResource check if subject has access to the full "GroupResource", if they do they can access every object
// within it.
func (s *Server) checkGroupResource(ctx context.Context, subject, relation string, resource common.ResourceInfo, contextuals *openfgav1.ContextualTupleKeys, store *zanzana.StoreInfo) (*authzv1.CheckResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.checkGroupResource")
	defer span.End()

	if !common.IsGroupResourceRelation(relation) {
		return &authzv1.CheckResponse{Allowed: false}, nil
	}

	res, err := s.openfgaCheck(ctx, store, subject, relation, resource.GroupResourceIdent(), contextuals, nil)
	if err != nil {
		return nil, err
	}

	return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
}

// checkTyped checks on our typed resources e.g. folder.
func (s *Server) checkTyped(ctx context.Context, subject, relation string, resource common.ResourceInfo, contextuals *openfgav1.ContextualTupleKeys, store *zanzana.StoreInfo) (*authzv1.CheckResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.checkTyped")
	defer span.End()

	var (
		resourceIdent       = resource.ResourceIdent()
		resourceCtx         = resource.Context()
		subresourceRelation = common.SubresourceRelation(relation)
	)

	// The subresource branch is gated on the subresource relation, independently of the base
	// relation: a type may support e.g. resource_create without a per-object base create
	// (user / service-account), so the base-relation guard below must not block it.
	if resource.HasSubresource() && resource.IsValidRelation(subresourceRelation) {
		// Check if subject has access as a subresource
		res, err := s.openfgaCheck(ctx, store, subject, common.SubresourcePermissionRelation(subresourceRelation), resourceIdent, contextuals, resourceCtx)
		if err != nil {
			return nil, err
		}

		if res.GetAllowed() {
			return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
		}
	}

	if !resource.IsValidRelation(relation) || resourceIdent == "" {
		return &authzv1.CheckResponse{Allowed: false}, nil
	}

	// Use optimized folder permission relations for permission management
	checkRelation := relation
	if resource.Type() == common.TypeFolder {
		checkRelation = common.FolderPermissionRelation(relation)
	}

	// Check if subject has direct access to resource
	res, err := s.openfgaCheck(ctx, store, subject, checkRelation, resourceIdent, contextuals, nil)
	if err != nil {
		return nil, err
	}

	return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
}

// checkGeneric check our generic "resource" type. It checks:
// 1. If subject has access as a sub resource for a folder.
// 2. If subject has direct access to resource.
func (s *Server) checkGeneric(ctx context.Context, subject, relation string, resource common.ResourceInfo, contextuals *openfgav1.ContextualTupleKeys, store *zanzana.StoreInfo) (*authzv1.CheckResponse, error) {
	ctx, span := s.tracer.Start(ctx, "server.checkGeneric")
	defer span.End()

	var (
		folderIdent         = resource.FolderIdent()
		resourceCtx         = resource.Context()
		folderRelation      = common.SubresourceRelation(relation)
		folderCheckRelation = common.FolderPermissionRelation(relation)
	)

	if folderIdent != "" && isFolderPermissionBasedResource(resource.GroupResource()) {
		// Check if resource inherits permissions from the folder (like dashboards in a folder)
		res, err := s.openfgaCheck(ctx, store, subject, folderCheckRelation, folderIdent, contextuals, resourceCtx)
		if err != nil {
			return nil, err
		}

		if res.GetAllowed() {
			return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
		}
	}

	if folderIdent != "" && common.IsSubresourceRelation(folderRelation) {
		// Check if subject has access as a sub resource for the folder
		res, err := s.openfgaCheck(ctx, store, subject, common.SubresourcePermissionRelation(folderRelation), folderIdent, contextuals, resourceCtx)
		if err != nil {
			return nil, err
		}

		if res.GetAllowed() {
			return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
		}
	}

	resourceIdent := resource.ResourceIdent()
	if !resource.IsValidRelation(relation) || resourceIdent == "" {
		return &authzv1.CheckResponse{Allowed: false}, nil
	}

	// Check if subject has direct access to resource
	res, err := s.openfgaCheck(ctx, store, subject, relation, resourceIdent, contextuals, resourceCtx)
	if err != nil {
		return nil, err
	}

	return &authzv1.CheckResponse{Allowed: res.GetAllowed()}, nil
}

func (s *Server) openfgaCheck(ctx context.Context, store *zanzana.StoreInfo, subject, relation, object string, contextuals *openfgav1.ContextualTupleKeys, resourceCtx *structpb.Struct) (*openfgav1.CheckResponse, error) {
	chunks := contextualTupleChunks(contextuals)
	if len(chunks) == 0 {
		return s.doOpenFGACheck(ctx, store, subject, relation, object, nil, resourceCtx)
	}
	if len(chunks) == 1 {
		return s.doOpenFGACheck(ctx, store, subject, relation, object, chunks[0], resourceCtx)
	}

	var last *openfgav1.CheckResponse
	for _, chunk := range chunks {
		res, err := s.doOpenFGACheck(ctx, store, subject, relation, object, chunk, resourceCtx)
		if err != nil {
			return nil, err
		}
		if res.GetAllowed() {
			return res, nil
		}
		last = res
	}
	return last, nil
}

func (s *Server) doOpenFGACheck(ctx context.Context, store *zanzana.StoreInfo, subject, relation, object string, contextuals *openfgav1.ContextualTupleKeys, resourceCtx *structpb.Struct) (*openfgav1.CheckResponse, error) {
	res, err := s.openFGAClient.Check(ctx, &openfgav1.CheckRequest{
		StoreId:              store.ID,
		AuthorizationModelId: store.ModelID,
		TupleKey: &openfgav1.CheckRequestTupleKey{
			User:     subject,
			Relation: relation,
			Object:   object,
		},
		Context:          resourceCtx,
		ContextualTuples: contextuals,
	})

	if err != nil {
		s.logger.Error("failed to perform check", "error", err, "subject", subject, "relation", relation, "object", object)
		return nil, fmt.Errorf("failed to perform openfga Check request: %w", err)
	}

	return res, nil
}

var folderPermissionBasedResourceExceptions = map[string]bool{
	// allow all resources to inherit permissions from the folder
}

func isFolderPermissionBasedResource(resource string) bool {
	return !folderPermissionBasedResourceExceptions[resource]
}
