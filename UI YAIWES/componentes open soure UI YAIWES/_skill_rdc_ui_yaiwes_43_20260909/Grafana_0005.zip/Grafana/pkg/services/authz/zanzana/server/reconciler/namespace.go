package reconciler

import (
	"context"
	"fmt"
	"strconv"
	"time"

	openfgav1 "github.com/openfga/api/proto/openfga/v1"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/wrapperspb"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"

	iamv0 "github.com/grafana/grafana/apps/iam/pkg/apis/iam/v0alpha1"
	"github.com/grafana/grafana/pkg/infra/tracing"
	authzextv1 "github.com/grafana/grafana/pkg/services/authz/proto/v1"
	"github.com/grafana/grafana/pkg/services/authz/zanzana"
	"github.com/grafana/grafana/pkg/services/authz/zanzana/common"
)

// anonymousSettingsGVR is the setting.grafana.app resource that holds per-namespace
// (per-tenant) INI-style configuration, including the [auth.anonymous] section.
var anonymousSettingsGVR = schema.GroupVersionResource{
	Group:    "setting.grafana.app",
	Version:  "v1beta1",
	Resource: "settings",
}

const (
	// anonymousSettingsSection is the config section carrying anonymous-access settings.
	anonymousSettingsSection = "auth.anonymous"
	// anonymousSettingsSectionSelector filters Setting resources down to the anonymous section.
	anonymousSettingsSectionSelector = "section=" + anonymousSettingsSection
	anonymousSettingKeyEnabled       = "enabled"
	anonymousSettingKeyOrgRole       = "org_role"

	// anonymousUserID matches the identifier used for the anonymous subject at check time
	// (and by the legacy reconciler): anonymous:0.
	anonymousUserID = "0"
	// anonymousDefaultOrgRole mirrors the [auth.anonymous] org_role ini default.
	anonymousDefaultOrgRole = "Viewer"
)

// tupleKey generates a unique string key for a tuple based on user, relation, and object.
// Conditions are intentionally excluded from the key — they are compared separately in
// computeDiffStreaming so that condition changes trigger a delete+re-add.
// Uses null-byte separators to prevent collisions between field values.
func tupleKey(tuple *openfgav1.TupleKey) string {
	return tuple.GetUser() + "\x00" + tuple.GetRelation() + "\x00" + tuple.GetObject()
}

// fetchGlobalRolePerms fetches cluster-scoped GlobalRole resources and collects their
// permissions. The returned map is shared across all namespace workers for Role
// composition and per-namespace injection.
func (r *Reconciler) fetchGlobalRolePerms(ctx context.Context) (
	map[string][]*authzextv1.RolePermission,
	error,
) {
	ctx, span := r.tracer.Start(ctx, "reconciler.fetchGlobalRolePerms")
	defer span.End()

	crd := iamv0.GlobalRoleInfo.GroupVersionResource()

	clients, err := r.clientFactory.Clients(ctx, "")
	if err != nil {
		return nil, tracing.Errorf(span, "failed to get cluster clients: %w", err)
	}
	resourceClient, _, err := clients.ForResource(ctx, crd)
	if err != nil {
		return nil, tracing.Errorf(span, "failed to get client for %s: %w", crd, err)
	}

	// 1. Collect all GlobalRole objects into a map for two-pass resolution.
	allGlobalRoles := make(map[string]*iamv0.GlobalRole)
	err = listAndProcess(ctx, resourceClient, r.cfg.listPageSize(), func(item *unstructured.Unstructured) error {
		var gr iamv0.GlobalRole
		if err := convertUnstructured(item, &gr); err != nil {
			return err
		}
		allGlobalRoles[gr.Name] = &gr
		return nil
	})
	if err != nil {
		return nil, tracing.Errorf(span, "failed to list GlobalRoles: %w", err)
	}

	// 2. Collect permissions for each GlobalRole.
	resolvedPerms, err := resolveAllGlobalRolePermissions(allGlobalRoles)
	if err != nil {
		return nil, tracing.Errorf(span, "failed to resolve GlobalRole permissions: %w", err)
	}

	span.SetAttributes(attribute.Int("global_roles.count", len(resolvedPerms)))

	return resolvedPerms, nil
}

// resolveAllGlobalRolePermissions collects the effective permissions for each GlobalRole.
// GlobalRoles do not support RoleRefs, so each role's permissions are simply its own Permissions list.
func resolveAllGlobalRolePermissions(
	allGlobalRoles map[string]*iamv0.GlobalRole,
) (map[string][]*authzextv1.RolePermission, error) {
	resolved := make(map[string][]*authzextv1.RolePermission, len(allGlobalRoles))

	for name, gr := range allGlobalRoles {
		perms := make([]*authzextv1.RolePermission, 0, len(gr.Spec.Permissions))
		for _, p := range gr.Spec.Permissions {
			perms = append(perms, &authzextv1.RolePermission{Action: p.Action, Scope: p.Scope})
		}
		resolved[name] = perms
	}

	return resolved, nil
}

// fetchAnonymousTuples reads the per-namespace anonymous-access config from the
// setting.grafana.app apiserver and, when anonymous access is enabled, injects the
// anonymous role assignment tuple (anonymous:0#assignee@role:basic_<org_role>) into dest.
//
// In a multi-tenant deployment there is no single instance config: each namespace (tenant)
// can enable anonymous access with a different org role. This mirrors the legacy
// anonymousRoleBindingsCollector, but sources the config per-namespace instead of from
// process-global cfg.Anonymous.
//
// It is a no-op when the settings apiserver is not wired into the client factory (no
// settings_apiserver_url in standalone mode, or the setting.grafana.app apiserver is not
// registered in the embedded loopback client). In that case the anonymous role is simply
// not reconciled. Anonymous reconciliation is therefore automatically active whenever the
// settings apiserver is reachable, without a separate feature switch.
//
// When anonymous access is disabled (or unset), no tuple is added; because the reconciler
// performs a full-store sync, any previously-written anonymous tuple is then pruned.
func (r *Reconciler) fetchAnonymousTuples(ctx context.Context, namespace string, dest map[string]*openfgav1.TupleKey) error {
	ctx, span := r.tracer.Start(ctx, "reconciler.addAnonymousTuples", trace.WithAttributes(
		attribute.String("namespace", namespace),
	))
	defer span.End()

	clients, err := r.clientFactory.Clients(ctx, namespace)
	if err != nil {
		// Client acquisition is shared with the CRD fetch (which already ran and would have
		// surfaced this). Skip anonymous reconciliation rather than failing on it here.
		r.logger.Debug("skipping anonymous reconcile: failed to get clients",
			"namespace", namespace, "error", err)
		return nil
	}

	resourceClient, _, err := clients.ForResource(ctx, anonymousSettingsGVR)
	if err != nil {
		// The settings apiserver is not wired for this deployment; anonymous access is not
		// reconciled. This is the expected path when settings_apiserver_url is unset (standalone)
		// or the setting.grafana.app apiserver is absent (embedded OSS).
		r.logger.Debug("skipping anonymous reconcile: settings apiserver unavailable",
			"namespace", namespace, "error", err)
		return nil
	}

	list, err := resourceClient.List(ctx, metav1.ListOptions{LabelSelector: anonymousSettingsSectionSelector})
	if err != nil {
		// The settings client exists but the list failed (transient error, apiserver down, etc.).
		// Break the error chain (%v, not %w) so a NotFound is never misinterpreted by
		// reconcileNamespace as "namespace deleted" (which would delete the store). Returning an
		// error aborts this namespace's reconcile, leaving existing tuples untouched to avoid
		// flapping the anonymous tuple.
		return tracing.Errorf(span, "failed to list anonymous settings: %v", err)
	}

	var enabled bool
	orgRole := ""
	for i := range list.Items {
		obj := list.Items[i].Object
		section, _, _ := unstructured.NestedString(obj, "spec", "section")
		if section != anonymousSettingsSection {
			continue
		}
		key, _, _ := unstructured.NestedString(obj, "spec", "key")
		value, _, _ := unstructured.NestedString(obj, "spec", "value")
		switch key {
		case anonymousSettingKeyEnabled:
			enabled, _ = strconv.ParseBool(value)
		case anonymousSettingKeyOrgRole:
			orgRole = value
		}
	}

	if !enabled {
		return nil
	}

	if orgRole == "" {
		orgRole = anonymousDefaultOrgRole
	}

	basicRole := common.TranslateBasicRole(orgRole)
	if basicRole == "" {
		r.logger.Warn("skipping anonymous role tuple: invalid org_role",
			"namespace", namespace, "org_role", orgRole)
		return nil
	}

	tuple := &openfgav1.TupleKey{
		User:     common.NewTupleEntry(common.TypeAnonymous, anonymousUserID, ""),
		Relation: common.RelationAssignee,
		Object:   common.NewTupleEntry(common.TypeRole, basicRole, ""),
	}
	dest[tupleKey(tuple)] = tuple

	span.SetAttributes(attribute.String("anonymous.basic_role", basicRole))
	return nil
}

// fetchAndTranslateTuples fetches CRDs from Unistore and translates them directly into a
// map keyed by tupleKey.
//
// GlobalRole tuples are injected selectively: only GlobalRoles that are NOT referenced by any
// namespace Role are added standalone. GlobalRoles that ARE referenced already have their
// permissions inlined into the namespace Role's tuples via TranslateRoleToTuples composition.
func (r *Reconciler) fetchAndTranslateTuples(ctx context.Context, namespace string) (map[string]*openfgav1.TupleKey, error) {
	ctx, span := r.tracer.Start(ctx, "reconciler.fetchAndTranslateTuples", trace.WithAttributes(
		attribute.String("namespace", namespace),
	))
	defer span.End()

	globalRolePerms := r.getGlobalRolePerms()
	expectedMap := make(map[string]*openfgav1.TupleKey, len(globalRolePerms)*2)

	// Track which GlobalRoles are referenced by namespace Roles via RoleRefs.
	// Those have their permissions inlined and must not be added as standalone tuples.
	referencedGlobalRoles := make(map[string]bool)

	// Map resource types to their translation functions
	translators := map[string]func(*unstructured.Unstructured) ([]*openfgav1.TupleKey, error){
		"folders": TranslateFolderToTuples,
		"roles": func(obj *unstructured.Unstructured) ([]*openfgav1.TupleKey, error) {
			// Collect RoleRefs so we know which GlobalRoles are already inlined.
			var role iamv0.Role
			if err := convertUnstructured(obj, &role); err == nil {
				for _, ref := range role.Spec.RoleRefs {
					referencedGlobalRoles[ref.Name] = true
				}
			}
			return TranslateRoleToTuples(obj, globalRolePerms)
		},
		"rolebindings":        TranslateRoleBindingToTuples,
		"resourcepermissions": TranslateResourcePermissionToTuples,
		"teams":               TranslateTeamToMemberTuples,
		"users":               TranslateUserToTuples,
		"serviceaccounts":     TranslateServiceAccountToTuples,
	}

	// Process each crd type and insert translated tuples directly into the map
	for _, crd := range r.cfg.CRDs {
		translator, ok := translators[crd.Resource]
		if !ok {
			return nil, tracing.Errorf(span, "no translator found for resource type: %s", crd.Resource)
		}

		if err := r.fetchAndTranslateCRD(ctx, namespace, crd, translator, expectedMap); err != nil {
			return nil, tracing.Errorf(span, "failed to process %s: %w", crd.Resource, err)
		}
	}

	// For GlobalRoles not referenced by any namespace Role, add their tuples directly.
	// Referenced GlobalRoles are already inlined into namespace Role tuples above.
	for roleName, perms := range globalRolePerms {
		if referencedGlobalRoles[roleName] {
			continue
		}
		tuples, err := zanzana.RoleToTuples(roleName, perms)
		if err != nil {
			return nil, tracing.Errorf(span, "failed to generate tuples for unlinked GlobalRole %s: %w", roleName, err)
		}
		for _, t := range tuples {
			expectedMap[tupleKey(t)] = t
		}
	}

	// Inject the per-namespace anonymous role assignment. This is a no-op when the settings
	// apiserver is not wired (see fetchAnonymousTuples). A genuine failure aborts the reconcile
	// (and is never a NotFound), so reconcileNamespace won't misread it as "namespace deleted".
	if err := r.fetchAnonymousTuples(ctx, namespace, expectedMap); err != nil {
		return nil, tracing.Errorf(span, "failed to reconcile anonymous settings: %w", err)
	}

	return expectedMap, nil
}

// fetchAndTranslateCRD fetches CRDs of a specific type and inserts translated tuples
// directly into the destination map
func (r *Reconciler) fetchAndTranslateCRD(
	ctx context.Context,
	namespace string,
	crd schema.GroupVersionResource,
	translator func(*unstructured.Unstructured) ([]*openfgav1.TupleKey, error),
	dest map[string]*openfgav1.TupleKey,
) error {
	ctx, span := r.tracer.Start(ctx, "reconciler.fetchAndTranslateCRD", trace.WithAttributes(
		attribute.String("crd.group", crd.Group),
		attribute.String("crd.version", crd.Version),
		attribute.String("crd.resource", crd.Resource),
	))
	defer span.End()

	start := time.Now()
	objectsFetched := 0
	tuplesProduced := 0

	// Get the dynamic client for this namespace
	clients, err := r.clientFactory.Clients(ctx, namespace)
	if err != nil {
		return tracing.Errorf(span, "failed to get clients for namespace %s: %w", namespace, err)
	}

	// Get the resource interface for the specific CRD
	resourceClient, _, err := clients.ForResource(ctx, crd)
	if err != nil {
		return tracing.Errorf(span, "failed to get client for resource %s: %w", crd.String(), err)
	}

	// Stream through pages using the Kubernetes dynamic client
	err = listAndProcess(ctx, resourceClient, r.cfg.listPageSize(), func(item *unstructured.Unstructured) error {
		objectsFetched++
		tuples, err := translator(item)
		if err != nil {
			return fmt.Errorf("failed to translate %s/%s: %w", crd.Resource, item.GetName(), err)
		}
		tuplesProduced += len(tuples)
		for _, t := range tuples {
			dest[tupleKey(t)] = t
		}
		return nil
	})

	if err != nil {
		return tracing.Error(span, err)
	}

	elapsed := time.Since(start)

	span.SetAttributes(
		attribute.Int("crd.objects_fetched", objectsFetched),
		attribute.Int("crd.tuples_produced", tuplesProduced),
	)
	r.metrics.crdFetchDurationSeconds.WithLabelValues(crd.Resource).Observe(elapsed.Seconds())

	return nil
}

// listAndProcess is a helper function that lists all resources and processes each one.
// It handles pagination using Kubernetes continuation tokens.
func listAndProcess(ctx context.Context, client dynamic.ResourceInterface, pageSize int64, fn func(*unstructured.Unstructured) error) error {
	var continueToken string

	for {
		list, err := client.List(ctx, metav1.ListOptions{
			Limit:    pageSize,
			Continue: continueToken,
		})
		if err != nil {
			return fmt.Errorf("failed to list resources: %w", err)
		}

		for i := range list.Items {
			if err := fn(&list.Items[i]); err != nil {
				return err
			}
		}

		continueToken = list.GetContinue()
		if continueToken == "" {
			break
		}
	}

	return nil
}

// computeDiffStreaming reads current tuples from Zanzana page-by-page and computes the diff
// against expectedMap. It mutates expectedMap by deleting matched entries; after return,
// remaining entries in expectedMap are returned as toAdd.
func (r *Reconciler) computeDiffStreaming(
	ctx context.Context, namespace string,
	expectedMap map[string]*openfgav1.TupleKey,
) (toAdd, toDelete []*openfgav1.TupleKey, err error) {
	ctx, span := r.tracer.Start(ctx, "reconciler.computeDiffStreaming", trace.WithAttributes(
		attribute.String("namespace", namespace),
	))
	defer span.End()

	// Get store info for the namespace. The reconciler runs as a background
	// worker without end-user claims, so it calls the internal ReadTuples helper
	// (mirroring WriteTuples) to bypass the public-API authorization check.
	storeInfo, err := r.server.GetOrCreateStore(ctx, namespace)
	if err != nil {
		return nil, nil, tracing.Errorf(span, "failed to get store info: %w", err)
	}

	pagesRead := 0
	var continuationToken string

	// Read current tuples page-by-page and diff against expected
	for {
		req := &openfgav1.ReadRequest{
			PageSize:          wrapperspb.Int32(r.cfg.zanzanaReadPageSize()),
			ContinuationToken: continuationToken,
		}

		resp, err := r.server.ReadTuples(ctx, storeInfo, req)
		if err != nil {
			return nil, nil, tracing.Errorf(span, "failed to read tuples: %w", err)
		}

		pagesRead++

		for _, tuple := range resp.GetTuples() {
			key := tupleKey(tuple.GetKey())
			if expected, exists := expectedMap[key]; exists {
				if proto.Equal(expected.GetCondition(), tuple.GetKey().GetCondition()) {
					// Tuple is fully in sync — remove from expected
					delete(expectedMap, key)
				} else {
					// Same identity but condition changed — delete old, keep expected for re-add
					toDelete = append(toDelete, tuple.GetKey())
				}
			} else {
				// Tuple exists in Zanzana but not expected — needs deletion
				toDelete = append(toDelete, tuple.GetKey())
			}
		}

		if resp.GetContinuationToken() == "" {
			break
		}
		continuationToken = resp.GetContinuationToken()
	}

	// Remaining entries in expectedMap are missing from Zanzana — need to be added
	toAdd = make([]*openfgav1.TupleKey, 0, len(expectedMap))
	for _, tuple := range expectedMap {
		toAdd = append(toAdd, tuple)
	}

	span.SetAttributes(
		attribute.Int("diff.pages_read", pagesRead),
		attribute.Int("diff.tuples_to_add", len(toAdd)),
		attribute.Int("diff.tuples_to_delete", len(toDelete)),
	)

	return toAdd, toDelete, nil
}

// writeTuplesToZanzana applies the diff (additions and deletions) to Zanzana in batches.
// If a batch fails, it logs the error and continues with the next batch.
// Uses the server's WriteTuples method directly to avoid authzextv1 ↔ openfgav1 conversions.
func (r *Reconciler) writeTuplesToZanzana(ctx context.Context, namespace string, toAdd, toDelete []*openfgav1.TupleKey) error {
	ctx, span := r.tracer.Start(ctx, "reconciler.writeTuplesToZanzana", trace.WithAttributes(
		attribute.String("namespace", namespace),
	))
	defer span.End()

	// Get store info for the namespace
	storeInfo, err := r.server.GetOrCreateStore(ctx, namespace)
	if err != nil {
		return tracing.Errorf(span, "failed to get store info: %w", err)
	}

	// Convert toDelete to TupleKeyWithoutCondition (required for deletes)
	deleteTuples := make([]*openfgav1.TupleKeyWithoutCondition, len(toDelete))
	for i, tuple := range toDelete {
		deleteTuples[i] = &openfgav1.TupleKeyWithoutCondition{
			User:     tuple.User,
			Relation: tuple.Relation,
			Object:   tuple.Object,
		}
	}

	// Determine batch size (default to 100 if not configured or set to 0)
	batchSize := r.cfg.WriteBatchSize
	if batchSize <= 0 {
		batchSize = 100
	}

	span.SetAttributes(
		attribute.Int("write.total_adds", len(toAdd)),
		attribute.Int("write.total_deletes", len(deleteTuples)),
		attribute.Int("write.batch_size", batchSize),
	)

	// If total tuples fit in one batch, write directly
	totalTuples := len(toAdd) + len(deleteTuples)
	if totalTuples <= batchSize {
		err := r.server.WriteTuples(ctx, storeInfo, toAdd, deleteTuples)
		if err == nil {
			r.metrics.tuplesWrittenTotal.WithLabelValues("add").Add(float64(len(toAdd)))
			r.metrics.tuplesWrittenTotal.WithLabelValues("delete").Add(float64(len(deleteTuples)))
			span.SetAttributes(attribute.Int("write.failed_batches", 0))
			return nil
		}
		r.metrics.batchFailuresTotal.Inc()
		span.SetAttributes(attribute.Int("write.failed_batches", 1))
		return tracing.Error(span, err)
	}

	// Process in batches
	failedBatches := 0
	successfulBatches := 0
	addCounter := r.metrics.tuplesWrittenTotal.WithLabelValues("add")
	deleteCounter := r.metrics.tuplesWrittenTotal.WithLabelValues("delete")

	// Split writes into batches
	for i := 0; i < len(toAdd); i += batchSize {
		end := min(i+batchSize, len(toAdd))
		batchWrites := toAdd[i:end]

		if err := r.server.WriteTuples(ctx, storeInfo, batchWrites, nil); err != nil {
			r.logger.Error("Failed to write batch of additions",
				"namespace", namespace,
				"batchStart", i,
				"batchSize", len(batchWrites),
				"error", err,
			)
			r.metrics.batchFailuresTotal.Inc()
			failedBatches++
		} else {
			addCounter.Add(float64(len(batchWrites)))
			successfulBatches++
		}
	}

	// Split deletes into batches
	for i := 0; i < len(deleteTuples); i += batchSize {
		end := min(i+batchSize, len(deleteTuples))
		batchDeletes := deleteTuples[i:end]

		if err := r.server.WriteTuples(ctx, storeInfo, nil, batchDeletes); err != nil {
			r.logger.Error("Failed to write batch of deletions",
				"namespace", namespace,
				"batchStart", i,
				"batchSize", len(batchDeletes),
				"error", err,
			)
			r.metrics.batchFailuresTotal.Inc()
			failedBatches++
		} else {
			deleteCounter.Add(float64(len(batchDeletes)))
			successfulBatches++
		}
	}

	span.SetAttributes(attribute.Int("write.failed_batches", failedBatches))

	if failedBatches > 0 {
		r.metrics.errorsTotal.WithLabelValues("write_tuples_partial").Inc()
	}

	r.logger.Info("Completed batched tuple writes",
		"namespace", namespace,
		"successfulBatches", successfulBatches,
		"failedBatches", failedBatches,
		"totalWrites", len(toAdd),
		"totalDeletes", len(deleteTuples),
	)

	// Return error if any batches failed (for metrics/logging at higher level)
	if failedBatches > 0 {
		return tracing.Errorf(span, "failed to write %d out of %d batches", failedBatches, successfulBatches+failedBatches)
	}

	return nil
}
