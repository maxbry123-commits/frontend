package rbac

import (
	"fmt"
	"slices"
	"strings"

	"github.com/grafana/grafana/pkg/apimachinery/utils"
	"github.com/grafana/grafana/pkg/services/accesscontrol"
	"github.com/grafana/grafana/pkg/services/accesscontrol/ossaccesscontrol"
)

// Mapping maps a verb to a RBAC action and a resource name to a RBAC scope.
type Mapping interface {
	// action returns the action for the given verb.
	// If no action is found, it returns false.
	Action(verb string) (string, bool)
	// ActionSets returns the action sets for the given verb.
	// Empty is expected for resources that are not granted via managed folder/dashboard
	// (or other) action sets. Folder-scoped kinds such as dashboards, folders, alert
	// rules, and variables must include folders:view/edit/admin so onlyStoreActionSets
	// grants still authorize.
	ActionSets(verb string) []string
	// scope returns the scope for the given resource name.
	Scope(name string) string
	// prefix returns the scope prefix for the translation.
	Prefix() string
	// AllActions returns all the actions for the translation.
	AllActions() []string
	// HasFolderSupport returns true if the translation supports folders.
	HasFolderSupport() bool
	// SkipScope returns true if the translation does not require a scope for the given verb.
	SkipScope(verb string) bool
	// Resource returns the K8s resource name for this mapping.
	Resource() string
	SkipWildcard() bool
}

type translation struct {
	resource         string
	attribute        string
	verbMapping      map[string]string
	actionSetMapping map[string][]string
	folderSupport    bool
	// actions to skip scope on, e.g., create actions
	skipScopeOnVerb map[string]bool
	// use this option if you need to limit access to users that can access all resources
	useWildcardScope bool
	skipWildcard     bool
}

func (t translation) Action(verb string) (string, bool) {
	action, ok := t.verbMapping[verb]
	return action, ok
}

func (t translation) ActionSets(verb string) []string {
	actionSets := t.actionSetMapping[verb]
	return actionSets
}

func (t translation) Scope(name string) string {
	if t.useWildcardScope {
		return "*"
	}
	return t.resource + ":" + t.attribute + ":" + name
}

func (t translation) Prefix() string {
	return t.resource + ":" + t.attribute + ":"
}

func (t translation) AllActions() []string {
	actions := make([]string, 0, len(t.verbMapping))
	actionsMap := make(map[string]bool)
	for _, action := range t.verbMapping {
		if actionsMap[action] {
			continue
		}
		actionsMap[action] = true
		actions = append(actions, action)
	}
	return actions
}

func (t translation) HasFolderSupport() bool {
	return t.folderSupport
}

func (t translation) SkipScope(verb string) bool {
	if t.skipScopeOnVerb != nil {
		return t.skipScopeOnVerb[verb]
	}
	return false
}

func (t translation) Resource() string {
	return t.resource
}

func (t translation) SkipWildcard() bool {
	return t.skipWildcard
}

// MapperRegistry is a registry of mappers that maps a group and resource to a translation.
type MapperRegistry interface {
	// Get returns the permission mapper for the given group and resource.
	// If no translation is found, it returns false.
	Get(group, resource, subresource string) (Mapping, bool)
	// GetAPIResourceName returns the API resource name (e.g. "repositories") for the given group and resource.
	// Use this to send the canonical resource name in Check requests instead of legacy names (e.g. "provisioning.repositories").
	// Returns ("", false) if no translation is found.
	GetAPIResourceName(group, resource string) (string, bool)
	// GetAll returns all the translations for the given group
	GetAll(group string) []Mapping
	// ResourceMappings returns all translations for the given group with their API resource names.
	ResourceMappings(group string) []ResourceMapping
	// GetGroups returns all registered group names
	GetGroups() []string
}

// ResourceMapping pairs a registered API resource name with its translation.
type ResourceMapping struct {
	APIResource string
	Mapping     Mapping
}

type mapper map[string]map[string]translation

func newResourceTranslation(resource string, attribute string, folderSupport bool, skipScopeOnVerb map[string]bool) translation {
	defaultMapping := func(r string) map[string]string {
		return map[string]string{
			utils.VerbGet:              fmt.Sprintf("%s:read", r),
			utils.VerbList:             fmt.Sprintf("%s:read", r),
			utils.VerbWatch:            fmt.Sprintf("%s:read", r),
			utils.VerbCreate:           fmt.Sprintf("%s:create", r),
			utils.VerbUpdate:           fmt.Sprintf("%s:write", r),
			utils.VerbPatch:            fmt.Sprintf("%s:write", r),
			utils.VerbDelete:           fmt.Sprintf("%s:delete", r),
			utils.VerbDeleteCollection: fmt.Sprintf("%s:delete", r),
			utils.VerbGetPermissions:   fmt.Sprintf("%s.permissions:read", r),
			utils.VerbSetPermissions:   fmt.Sprintf("%s.permissions:write", r),
		}
	}

	return translation{
		resource:        resource,
		attribute:       attribute,
		verbMapping:     defaultMapping(resource),
		folderSupport:   folderSupport,
		skipScopeOnVerb: skipScopeOnVerb,
	}
}

// newDashboardTranslation creates a translation for dashboards and also maps the actions to action sets
func newDashboardTranslation() translation {
	dashTranslation := newResourceTranslation("dashboards", "uid", true, nil)

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range dashTranslation.verbMapping {
		var dashActionSets []string

		// Dashboard creation is only part of folder action sets, so we handle it separately
		if rbacAction == "dashboards:create" {
			dashActionSets = append(dashActionSets, "folders:edit")
			dashActionSets = append(dashActionSets, "folders:admin")
		}

		if slices.Contains(ossaccesscontrol.DashboardViewActions, rbacAction) {
			dashActionSets = append(dashActionSets, "dashboards:view")
			dashActionSets = append(dashActionSets, "folders:view")
		}
		if slices.Contains(ossaccesscontrol.DashboardEditActions, rbacAction) {
			dashActionSets = append(dashActionSets, "dashboards:edit")
			dashActionSets = append(dashActionSets, "folders:edit")
		}
		if slices.Contains(ossaccesscontrol.DashboardAdminActions, rbacAction) {
			dashActionSets = append(dashActionSets, "dashboards:admin")
			dashActionSets = append(dashActionSets, "folders:admin")
		}
		actionSetMapping[verb] = dashActionSets
	}

	dashTranslation.actionSetMapping = actionSetMapping
	return dashTranslation
}

// newNotebookTranslation creates a translation for notebooks. Notebooks have their own
// notebooks:* actions and a notebooks:uid: scope, but are folder-scoped like dashboards, so
// their verbs map onto the folder action sets (folders:view/edit/admin) and folder grants
// cover them. The notebooks:view/edit/admin object action sets (for per-notebook sharing) are
// added later together with the notebook resource-permission service.
func newNotebookTranslation() translation {
	nbTranslation := newResourceTranslation("notebooks", "uid", true, nil)

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range nbTranslation.verbMapping {
		var actionSets []string

		// Notebook creation is only part of the folder action sets, so handle it separately.
		if rbacAction == "notebooks:create" {
			actionSets = append(actionSets, "folders:edit")
			actionSets = append(actionSets, "folders:admin")
		}
		// The permission verbs come from the default translation. set_permissions is never a granted
		// notebook action (no per-notebook permissions management) — it's mapped to folders:admin only
		// so the trash folder-admin check (TrashAuthorizer.FolderAdmin) resolves. get_permissions
		// falls through with no action set (nothing reads a notebook's permission list), so it's denied.
		if rbacAction == "notebooks.permissions:write" {
			actionSets = append(actionSets, "folders:admin")
		}

		if slices.Contains(ossaccesscontrol.NotebookViewActions, rbacAction) {
			actionSets = append(actionSets, "folders:view")
		}
		if slices.Contains(ossaccesscontrol.NotebookEditActions, rbacAction) {
			actionSets = append(actionSets, "folders:edit")
		}
		if slices.Contains(ossaccesscontrol.NotebookAdminActions, rbacAction) {
			actionSets = append(actionSets, "folders:admin")
		}
		actionSetMapping[verb] = actionSets
	}

	nbTranslation.actionSetMapping = actionSetMapping
	return nbTranslation
}

// newFolderTranslation creates a translation for folders and also maps the actions to action sets
func newFolderTranslation() translation {
	folderTranslation := newResourceTranslation("folders", "uid", true, nil)

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range folderTranslation.verbMapping {
		var actionSets []string
		// Folder creation has not been added to the FolderEditActions and FolderAdminActions slices (https://github.com/grafana/identity-access-team/issues/794)
		// so we handle it as a special case for now
		if rbacAction == "folders:create" {
			actionSets = append(actionSets, "folders:edit")
			actionSets = append(actionSets, "folders:admin")
		}
		if slices.Contains(ossaccesscontrol.FolderViewActions, rbacAction) {
			actionSets = append(actionSets, "folders:view")
		}
		if slices.Contains(ossaccesscontrol.FolderEditActions, rbacAction) {
			actionSets = append(actionSets, "folders:edit")
		}
		if slices.Contains(ossaccesscontrol.FolderAdminActions, rbacAction) {
			actionSets = append(actionSets, "folders:admin")
		}
		actionSetMapping[verb] = actionSets
	}
	folderTranslation.actionSetMapping = actionSetMapping
	return folderTranslation
}

func newDatasourceQueryTranslation() translation {
	dsTranslation := newResourceTranslation("datasources", "uid", false, map[string]bool{utils.VerbCreate: true})

	dsTranslation.actionSetMapping = map[string][]string{
		// utils.VerbWatch: {"datasources:query"},
		utils.VerbGet:              {"datasources:query", "datasources:admin", "datasources:edit"},
		utils.VerbList:             {"datasources:query", "datasources:admin", "datasources:edit"},
		utils.VerbUpdate:           {"datasources:edit", "datasources:admin"},
		utils.VerbPatch:            {"datasources:edit", "datasources:admin"},
		utils.VerbDelete:           {"datasources:edit", "datasources:admin"},
		utils.VerbDeleteCollection: {"datasources:edit", "datasources:admin"},
		utils.VerbGetPermissions:   {"datasources:admin"},
		utils.VerbSetPermissions:   {"datasources:admin"},
	}
	return dsTranslation
}

// newServiceAccountTranslation creates a translation for service accounts and maps actions to action sets.
// Service accounts only have Edit and Admin permission levels — there is no View level.
func newServiceAccountTranslation() translation {
	saTranslation := newResourceTranslation("serviceaccounts", "uid", false, map[string]bool{utils.VerbCreate: true})

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range saTranslation.verbMapping {
		var (
			actionSets    []string
			containsEdit  = slices.Contains(ossaccesscontrol.ServiceAccountEditActions, rbacAction)
			containsAdmin = slices.Contains(ossaccesscontrol.ServiceAccountAdminActions, rbacAction)
		)
		if containsEdit {
			actionSets = append(actionSets, "serviceaccounts:edit")
			actionSets = append(actionSets, "serviceaccounts:admin")
		} else if containsAdmin {
			actionSets = append(actionSets, "serviceaccounts:admin")
		}
		actionSetMapping[verb] = actionSets
	}

	saTranslation.actionSetMapping = actionSetMapping
	return saTranslation
}

// newRoutingTreeTranslation maps the notifications.alerting.grafana.app
// routingtrees resource to the granular, per-resource managed route actions
// (notifications.alerting.grafana.app/routingtrees:get, ...:uid:<name>) and to
// the view/edit/admin action sets registered by RoutePermissionsService.
func newRoutingTreeTranslation() translation {
	verbMapping := map[string]string{
		utils.VerbGet:              accesscontrol.ActionAlertingManagedRoutesRead,
		utils.VerbList:             accesscontrol.ActionAlertingManagedRoutesRead,
		utils.VerbWatch:            accesscontrol.ActionAlertingManagedRoutesRead,
		utils.VerbCreate:           accesscontrol.ActionAlertingManagedRoutesCreate,
		utils.VerbUpdate:           accesscontrol.ActionAlertingManagedRoutesWrite,
		utils.VerbPatch:            accesscontrol.ActionAlertingManagedRoutesWrite,
		utils.VerbDelete:           accesscontrol.ActionAlertingManagedRoutesDelete,
		utils.VerbDeleteCollection: accesscontrol.ActionAlertingManagedRoutesDelete,
		utils.VerbGetPermissions:   accesscontrol.ActionAlertingRoutesPermissionsWrite,
		utils.VerbSetPermissions:   accesscontrol.ActionAlertingRoutesPermissionsRead,
	}

	const (
		viewSet  = "notifications.alerting.grafana.app/routingtrees:view"
		editSet  = "notifications.alerting.grafana.app/routingtrees:edit"
		adminSet = "notifications.alerting.grafana.app/routingtrees:admin"
	)

	actionSetMapping := make(map[string][]string)
	for verb, action := range verbMapping {
		switch {
		case slices.Contains(ossaccesscontrol.RoutesViewActions, action):
			actionSetMapping[verb] = []string{viewSet, editSet, adminSet}
		case slices.Contains(ossaccesscontrol.RoutesEditActions, action):
			actionSetMapping[verb] = []string{editSet, adminSet}
		case slices.Contains(ossaccesscontrol.RoutesAdminActions, action):
			actionSetMapping[verb] = []string{adminSet}
		}
	}

	return translation{
		resource:         accesscontrol.AlertingRoutesKind,
		attribute:        "uid",
		verbMapping:      verbMapping,
		actionSetMapping: actionSetMapping,
		folderSupport:    false,
		skipScopeOnVerb:  map[string]bool{utils.VerbCreate: true},
	}
}

// newAlertmanagerImportsTranslation maps the notifications.alerting.grafana.app
// alertmanagerimports resource to its granular, per-resource actions. There is
// no resource permissions service for this resource, so it has no action sets.
func newAlertmanagerImportsTranslation() translation {
	return translation{
		resource:  accesscontrol.AlertingAlertmanagerImportsKind,
		attribute: "uid",
		verbMapping: map[string]string{
			utils.VerbGet:              accesscontrol.ActionAlertingAlertmanagerImportsRead,
			utils.VerbList:             accesscontrol.ActionAlertingAlertmanagerImportsRead,
			utils.VerbWatch:            accesscontrol.ActionAlertingAlertmanagerImportsRead,
			utils.VerbCreate:           accesscontrol.ActionAlertingAlertmanagerImportsCreate,
			utils.VerbUpdate:           accesscontrol.ActionAlertingAlertmanagerImportsWrite,
			utils.VerbPatch:            accesscontrol.ActionAlertingAlertmanagerImportsWrite,
			utils.VerbDelete:           accesscontrol.ActionAlertingAlertmanagerImportsDelete,
			utils.VerbDeleteCollection: accesscontrol.ActionAlertingAlertmanagerImportsDelete,
		},
		folderSupport:   false,
		skipScopeOnVerb: map[string]bool{utils.VerbCreate: true},
	}
}

// newAlertRuleTranslation maps the rule resources in rules.alerting.grafana.app
// (alertrules, recordingrules, rulesequences) to the alert.rules:* actions.
//
// Alert-rule permissions are always folder-scoped: they are granted on the folder
// scope (folders:uid:<uid>), never on a per-rule scope. Authorization therefore
// flows entirely through folder inheritance (folderSupport: true), which the check
// path evaluates against the object's parent folder using a hardcoded folders:uid:
// prefix — independent of this translation's resource.
//
// The resource is deliberately "alert.rules" (not "folders"). The direct-scope
// check builds Scope(name) from the request's object name (the rule UID); with a
// "folders" resource that would produce folders:uid:<ruleUID>, which could collide
// with a real folder grant when a rule UID happens to equal a folder UID and grant
// unintended access. Using "alert.rules" yields alert.rules:uid:<ruleUID>, a scope
// no grant ever has, so the direct-scope check is a guaranteed no-op and only the
// folder-inheritance path decides access.
//
// The alert.rules:* actions are also part of the folder view/edit/admin action
// sets, so users granted via managed folder roles are matched too.
func newAlertRuleTranslation() translation {
	t := translation{
		// See doc comment: "alert.rules" makes the per-object direct-scope check a
		// no-op; folder inheritance (below) does the real authorization.
		resource:  "alert.rules",
		attribute: "uid",
		verbMapping: map[string]string{
			utils.VerbGet:              accesscontrol.ActionAlertingRuleRead,
			utils.VerbList:             accesscontrol.ActionAlertingRuleRead,
			utils.VerbWatch:            accesscontrol.ActionAlertingRuleRead,
			utils.VerbCreate:           accesscontrol.ActionAlertingRuleCreate,
			utils.VerbUpdate:           accesscontrol.ActionAlertingRuleUpdate,
			utils.VerbPatch:            accesscontrol.ActionAlertingRuleUpdate,
			utils.VerbDelete:           accesscontrol.ActionAlertingRuleDelete,
			utils.VerbDeleteCollection: accesscontrol.ActionAlertingRuleDelete,
		},
		folderSupport: true,
	}

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range t.verbMapping {
		var actionSets []string
		if slices.Contains(ossaccesscontrol.FolderViewActions, rbacAction) {
			actionSets = append(actionSets, "folders:view")
		}
		if slices.Contains(ossaccesscontrol.FolderEditActions, rbacAction) {
			actionSets = append(actionSets, "folders:edit")
		}
		if slices.Contains(ossaccesscontrol.FolderAdminActions, rbacAction) {
			actionSets = append(actionSets, "folders:admin")
		}
		actionSetMapping[verb] = actionSets
	}
	t.actionSetMapping = actionSetMapping
	return t
}

// newVariableTranslation maps dashboard.grafana.app/variables to variables:*
// and to the folder view/edit/admin action sets. Managed folder roles only
// persist those action-set tokens when onlyStoreActionSets is on, so without
// this mapping an Editor with folder Edit cannot create/update/delete
// folder-scoped variables even though FolderEditActions includes variables:*.
func newVariableTranslation() translation {
	t := newResourceTranslation("variables", "uid", true, nil)

	actionSetMapping := make(map[string][]string)
	for verb, rbacAction := range t.verbMapping {
		var actionSets []string
		if slices.Contains(ossaccesscontrol.FolderViewActions, rbacAction) {
			actionSets = append(actionSets, "folders:view")
		}
		if slices.Contains(ossaccesscontrol.FolderEditActions, rbacAction) {
			actionSets = append(actionSets, "folders:edit")
		}
		if slices.Contains(ossaccesscontrol.FolderAdminActions, rbacAction) {
			actionSets = append(actionSets, "folders:admin")
		}
		actionSetMapping[verb] = actionSets
	}
	t.actionSetMapping = actionSetMapping
	return t
}

// newSettingsTranslation maps setting.grafana.app/settings to the legacy
// settings:read / settings:write actions. The K8s object name is the section,
// so it lands in the conventional "uid" (object-name) attribute and the scope
// is settings:uid:<section>. Settings are authorized per section; key-level
// granularity is intentionally dropped.
func newSettingsTranslation() translation {
	return translation{
		resource:  "settings",
		attribute: "uid",
		verbMapping: map[string]string{
			utils.VerbGet:              accesscontrol.ActionSettingsRead,
			utils.VerbList:             accesscontrol.ActionSettingsRead,
			utils.VerbWatch:            accesscontrol.ActionSettingsRead,
			utils.VerbCreate:           accesscontrol.ActionSettingsWrite,
			utils.VerbUpdate:           accesscontrol.ActionSettingsWrite,
			utils.VerbPatch:            accesscontrol.ActionSettingsWrite,
			utils.VerbDelete:           accesscontrol.ActionSettingsWrite,
			utils.VerbDeleteCollection: accesscontrol.ActionSettingsWrite,
		},
		folderSupport: false,
	}
}

func NewMapperRegistry() MapperRegistry {
	skipScopeOnAllVerbs := map[string]bool{
		utils.VerbCreate:           true,
		utils.VerbGet:              true,
		utils.VerbUpdate:           true,
		utils.VerbPatch:            true,
		utils.VerbDelete:           true,
		utils.VerbDeleteCollection: true,
		utils.VerbList:             true,
		utils.VerbWatch:            true,
		utils.VerbGetPermissions:   true,
		utils.VerbSetPermissions:   true,
	}

	mapper := mapper(map[string]map[string]translation{
		"notifications.alerting.grafana.app": {
			"routingtrees":        newRoutingTreeTranslation(),
			"alertmanagerimports": newAlertmanagerImportsTranslation(),
		},
		"rules.alerting.grafana.app": {
			// All rule resources share the folder-scoped alert.rules:* actions.
			"alertrules":     newAlertRuleTranslation(),
			"recordingrules": newAlertRuleTranslation(),
			"rulesequences":  newAlertRuleTranslation(),
		},
		// Assistant-pushed alert-rule embeddings, authorized like the native rule kinds above.
		"assistant.alertrules.ext.grafana.app": {
			"alertrules": newAlertRuleTranslation(),
		},
		"dashboard.grafana.app": {
			"dashboards":    newDashboardTranslation(),
			"notebooks":     newNotebookTranslation(),
			"librarypanels": newResourceTranslation("library.panels", "uid", true, nil),
			"variables":     newVariableTranslation(),
			// Annotations subresource for dashboards
			// Uses dashboard scope (dashboards:uid:...) but annotation actions
			"dashboards/annotations": translation{
				resource:  "dashboards",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbGet:              "annotations:read",
					utils.VerbList:             "annotations:read",
					utils.VerbWatch:            "annotations:read",
					utils.VerbCreate:           "annotations:create",
					utils.VerbUpdate:           "annotations:write",
					utils.VerbPatch:            "annotations:write",
					utils.VerbDelete:           "annotations:delete",
					utils.VerbDeleteCollection: "annotations:delete",
				},
				// Mirror dashboard action sets so managed roles like "dashboards:view" also grant annotations:read.
				actionSetMapping: map[string][]string{
					utils.VerbGet:              {"dashboards:view", "folders:view", "dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbList:             {"dashboards:view", "folders:view", "dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbWatch:            {"dashboards:view", "folders:view", "dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbCreate:           {"dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbUpdate:           {"dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbPatch:            {"dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbDelete:           {"dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
					utils.VerbDeleteCollection: {"dashboards:edit", "folders:edit", "dashboards:admin", "folders:admin"},
				},
				folderSupport: true,
			},
		},
		"folder.grafana.app": {
			"folders": newFolderTranslation(),
		},
		"playlist.grafana.app": {
			// Playlists only define two actions (playlists:read / playlists:write) and are
			// neither folder-scoped nor scope-checked by their own authorizer, so writes map
			// to playlists:write and create skips scope. This lets the provisioning export
			// preflight (run under the requesting user) authorize playlists like other kinds.
			"playlists": translation{
				resource:  "playlists",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbGet:              "playlists:read",
					utils.VerbList:             "playlists:read",
					utils.VerbWatch:            "playlists:read",
					utils.VerbCreate:           "playlists:write",
					utils.VerbUpdate:           "playlists:write",
					utils.VerbPatch:            "playlists:write",
					utils.VerbDelete:           "playlists:write",
					utils.VerbDeleteCollection: "playlists:write",
				},
				folderSupport:   false,
				skipScopeOnVerb: map[string]bool{utils.VerbCreate: true},
			},
		},
		"iam.grafana.app": {
			"permissions": translation{
				resource:  "permissions",
				attribute: "type",
				verbMapping: map[string]string{
					utils.VerbCreate: "roles:write",
					utils.VerbUpdate: "roles:write",
					utils.VerbPatch:  "roles:write",
				},
				folderSupport: false,
				skipWildcard:  true,
			},
			// Users is a special case. We translate user permissions from id to uid based.
			"users": translation{
				resource:  "users",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbCreate:           "users:create",
					utils.VerbGet:              "org.users:read",
					utils.VerbUpdate:           "org.users:write",
					utils.VerbPatch:            "org.users:write",
					utils.VerbDelete:           "org.users:remove",
					utils.VerbDeleteCollection: "users:delete",
					utils.VerbList:             "org.users:read",
					utils.VerbWatch:            "org.users:read",
					utils.VerbGetPermissions:   "users.permissions:read",
					utils.VerbSetPermissions:   "users.permissions:write",
				},
				folderSupport:   false,
				skipScopeOnVerb: map[string]bool{utils.VerbCreate: true},
			},
			"serviceaccounts": newServiceAccountTranslation(),
			// Teams is a special case. We translate user permissions from id to uid based.
			"teams": newResourceTranslation("teams", "uid", false, map[string]bool{utils.VerbCreate: true}),
			"globalroles": translation{
				resource:  "roles",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbGet:   "roles:read",
					utils.VerbList:  "roles:read",
					utils.VerbWatch: "roles:read",
				},
				folderSupport:    false,
				useWildcardScope: true,
			},
			"roles": translation{
				resource:  "roles",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbCreate:           "roles:write",
					utils.VerbGet:              "roles:read",
					utils.VerbUpdate:           "roles:write",
					utils.VerbPatch:            "roles:write",
					utils.VerbDelete:           "roles:delete",
					utils.VerbDeleteCollection: "roles:delete",
					utils.VerbList:             "roles:read",
					utils.VerbWatch:            "roles:read",
				},
				folderSupport: false,
				// No need to skip scope on create for roles because we translate `permissions:type:delegate` to `roles:*``
				skipScopeOnVerb: nil,
			},
			"rolebindings": translation{
				resource: "rolebindings",
				// rolebidings should only be modifiable by admins with a wildcard access
				useWildcardScope: true,
				verbMapping: map[string]string{
					utils.VerbCreate:           "users.roles:add",
					utils.VerbGet:              "users.roles:read",
					utils.VerbUpdate:           "users.roles:add",
					utils.VerbPatch:            "users.roles:add",
					utils.VerbDelete:           "users.roles:remove",
					utils.VerbDeleteCollection: "users.roles:remove",
					utils.VerbList:             "users.roles:read",
					utils.VerbWatch:            "users.roles:read",
				},
				folderSupport: false,
			},
		},
		"provisioning.grafana.app": {
			"repositories": newResourceTranslation("provisioning.repositories", "uid", false, skipScopeOnAllVerbs),
			"connections":  newResourceTranslation("provisioning.connections", "uid", false, skipScopeOnAllVerbs),
			"jobs":         newResourceTranslation("provisioning.jobs", "uid", false, skipScopeOnAllVerbs),
			"historicjobs": newResourceTranslation("provisioning.historicjobs", "uid", false, skipScopeOnAllVerbs),
			"settings":     newResourceTranslation("provisioning.settings", "", false, skipScopeOnAllVerbs),
			"stats":        newResourceTranslation("provisioning.stats", "", false, skipScopeOnAllVerbs),
		},
		"secret.grafana.app": {
			"securevalues": newResourceTranslation("secret.securevalues", "uid", false, nil),
			"keepers":      newResourceTranslation("secret.keepers", "uid", false, nil),
		},
		"query.grafana.app": {
			"query": translation{
				resource:  "datasources",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbCreate: "datasources:query",
				},
				folderSupport:   false,
				skipScopeOnVerb: nil,
			},
		},
		"datasource.grafana.app": { // duplicate the query group here
			"query": translation{
				resource:  "datasources",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbCreate: "datasources:query",
				},
				folderSupport:   false,
				skipScopeOnVerb: nil,
			},
		},
		"*.datasource.grafana.app": {
			"datasources": newDatasourceQueryTranslation(),
			"datasources/query": translation{
				resource:  "datasources",
				attribute: "uid",
				verbMapping: map[string]string{
					utils.VerbCreate: "datasources:query",
				},
				folderSupport:   false,
				skipScopeOnVerb: nil,
			},
		},
		"plugins.grafana.app": {
			"plugins": newResourceTranslation("plugins.plugins", "uid", false, nil),
			"metas":   newResourceTranslation("plugins.metas", "uid", false, nil),
		},
		"advisor.grafana.app": {
			"checks":       newResourceTranslation("advisor.checks", "uid", false, nil),
			"checktypes":   newResourceTranslation("advisor.checktypes", "uid", false, nil),
			"register":     newResourceTranslation("advisor.register", "uid", false, nil),
			"translations": newResourceTranslation("advisor.translations", "uid", false, nil),
		},
		"annotation.grafana.app": {
			// Uses "type" as scope attribute for org-level annotations (e.g. annotations:type:organization).
			// No actionSetMapping — dashboard action sets don't apply to org-level annotations.
			"annotations": newResourceTranslation("annotations", "type", false, nil),
		},
		"setting.grafana.app": {
			"settings": newSettingsTranslation(),
		},
	})

	return mapper
}

// findGroupKey returns the registry key for group, using exact match first,
// then wildcard match. A wildcard key has the form "*.<suffix>" (e.g. "*.datasource.grafana.app");
// group matches if it has that suffix, is longer than the suffix (non-empty prefix), and the prefix
// contains no dot (so "loki.datasource.grafana.app" matches but "foo.loki.datasource.grafana.app" does not).
// Group starting with "*" never matches (so we never exact-match a wildcard registry key as input).
func (m mapper) findGroupKey(group string) (string, bool) {
	if strings.HasPrefix(group, "*") {
		return "", false
	}
	if _, ok := m[group]; ok {
		return group, true
	}
	for key := range m {
		// is this a wildcard key?
		if len(key) < 2 || key[0] != '*' || key[1] != '.' {
			continue
		}
		suffix := key[1:]                              // remove the leading "*"
		prefix, ok := strings.CutSuffix(group, suffix) // loki.datasource.grafana.app -> loki
		if !ok || prefix == "" {
			continue
		}
		// prefix must be a single segment (no nested dots)
		if strings.Contains(prefix, ".") {
			continue
		}
		return key, true
	}
	return "", false
}

// newPermissionsDelegationTranslation maps a delegation check to the RBAC
// action being delegated. It mirrors the static permissions entry, except the
// action comes from the request rather than a fixed verb mapping, so holding
// a permissions:type:* scope on one action cannot authorize delegating another.
func newPermissionsDelegationTranslation(action string) Mapping {
	return &translation{
		resource:  "permissions",
		attribute: "type",
		verbMapping: map[string]string{
			utils.VerbCreate: action,
			utils.VerbUpdate: action,
			utils.VerbPatch:  action,
		},
		folderSupport: false,
		skipWildcard:  true,
	}
}

func (m mapper) Get(group, resource, subresource string) (Mapping, bool) {
	// Delegation checks name the RBAC action being delegated as the subresource
	// of the permissions pseudo-resource. The actions are open-ended, so the
	// translation is built from the request instead of the static table. Only
	// action-shaped values (containing a colon) are captured, so a real
	// subresource of a future permissions resource falls through untouched.
	if group == "iam.grafana.app" && resource == "permissions" && strings.Contains(subresource, ":") {
		return newPermissionsDelegationTranslation(subresource), true
	}

	groupKey, ok := m.findGroupKey(group)
	if !ok {
		return nil, false
	}

	lookupResource := resource
	if subresource != "" {
		lookupResource = resource + "/" + subresource
	}

	resources := m[groupKey]
	t, ok := resources[lookupResource]
	if !ok {
		return nil, false
	}

	return &t, true
}

func (m mapper) GetAPIResourceName(group, resource string) (string, bool) {
	groupKey, ok := m.findGroupKey(group)
	if !ok {
		return "", false
	}
	resources := m[groupKey]
	if _, ok := resources[resource]; ok {
		return resource, true
	}
	// Fall back to matching on the translation's scope resource. Iterate in sorted
	// key order so the result is deterministic when several API resources share the
	// same scope resource (e.g. rules.alerting.grafana.app alertrules/recordingrules/
	// rulesequences all map to "alert.rules"); map iteration order must never decide it.
	apiResources := make([]string, 0, len(resources))
	for apiResource := range resources {
		apiResources = append(apiResources, apiResource)
	}
	slices.Sort(apiResources)
	for _, apiResource := range apiResources {
		if resources[apiResource].Resource() == resource {
			return apiResource, true
		}
	}
	return "", false
}

func (m mapper) GetAll(group string) []Mapping {
	groupKey, ok := m.findGroupKey(group)
	if !ok {
		return nil
	}

	resources := m[groupKey]

	translations := make([]Mapping, 0, len(resources))
	for _, t := range resources {
		translations = append(translations, &t)
	}

	return translations
}

func (m mapper) ResourceMappings(group string) []ResourceMapping {
	groupKey, ok := m.findGroupKey(group)
	if !ok {
		return nil
	}

	resources := m[groupKey]
	mappings := make([]ResourceMapping, 0, len(resources))
	for apiResource, t := range resources {
		mapping := t
		mappings = append(mappings, ResourceMapping{
			APIResource: apiResource,
			Mapping:     &mapping,
		})
	}

	return mappings
}

func (m mapper) GetGroups() []string {
	groups := make([]string, 0, len(m))
	for group := range m {
		groups = append(groups, group)
	}
	return groups
}
