package frontend

import (
	"fmt"
	"maps"
	"net/http"

	"github.com/open-feature/go-sdk/openfeature"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/endpoints/request"

	"github.com/grafana/grafana/pkg/infra/tracing"
	"github.com/grafana/grafana/pkg/plugins/pluginscdn"
	"github.com/grafana/grafana/pkg/services/contexthandler"
	"github.com/grafana/grafana/pkg/services/featuremgmt"
	"github.com/grafana/grafana/pkg/services/licensing"
	settingservice "github.com/grafana/grafana/pkg/services/setting"
	"github.com/grafana/grafana/pkg/setting"
	"github.com/grafana/grafana/pkg/web"
)

// RequestConfigMiddleware manages per-request configuration.
//
// When Settings Service is configured and namespace is present in baggage header:
// - Fetches tenant-specific overrides from Settings Service
// - Merges overrides with base configuration
// - Stores final configuration in context
//
// Otherwise, uses base configuration for all requests.
func RequestConfigMiddleware(cfg *setting.Cfg, license licensing.Licensing, settingsService settingservice.Service, pluginsCDN *pluginscdn.Service) web.Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, span := tracing.Start(r.Context(), "frontend.RequestConfigMiddleware")
			defer span.End()

			reqCtx := contexthandler.FromContext(ctx)
			logger := reqCtx.Logger

			ofClient := openfeature.NewDefaultClient()
			fullFrontendSettingsEnabled, _ := ofClient.BooleanValue(ctx, featuremgmt.FlagFrontendServiceReducedBootDataAPI, false, openfeature.TransactionContext(ctx))

			// Create base request config from global settings
			// This is the default configuration that will be used for all requests
			requestConfig, err := NewFSRequestConfig(ctx, cfg, license, pluginsCDN, fullFrontendSettingsEnabled)

			if err != nil {
				logger.Error("failed to create request config", "err", err)
				span.RecordError(err)
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
				return
			}

			if fullFrontendSettingsEnabled && requestConfig.FullFrontendSettings != nil {
				namespace := request.NamespaceValue(ctx)
				requestConfig.FullFrontendSettings.Namespace = namespace

				// Merge the per-request OpenFeature evaluation context into the base
				// context already on the settings, so the frontend can evaluate feature
				// flags with the same context. Per-request values take precedence.
				evalCtx := openfeature.TransactionContext(ctx)
				openFeatureContext := make(map[string]string, len(requestConfig.FullFrontendSettings.OpenFeatureContext)+len(evalCtx.Attributes())+1)
				maps.Copy(openFeatureContext, requestConfig.FullFrontendSettings.OpenFeatureContext)
				for key, value := range evalCtx.Attributes() {
					if str, ok := value.(string); ok {
						openFeatureContext[key] = str
					} else {
						openFeatureContext[key] = fmt.Sprintf("%v", value)
					}
				}

				// Explicitly set namespace
				openFeatureContext["namespace"] = namespace
				requestConfig.FullFrontendSettings.OpenFeatureContext = openFeatureContext
			}

			// Fetch tenant-specific configuration if the settings service is configured and namespace is present
			if settingsService != nil {
				namespace, ok := request.NamespaceFrom(ctx)

				if ok && namespace != "" {
					// Fetch tenant overrides for relevant sections only
					selector := metav1.LabelSelector{
						MatchExpressions: []metav1.LabelSelectorRequirement{{
							Key:      "section",
							Operator: metav1.LabelSelectorOpIn,
							Values:   []string{"security", "analytics"},
						}, {
							Key:      "source",
							Operator: metav1.LabelSelectorOpIn,
							Values:   []string{"us"},
						}},
					}

					settings, err := settingsService.ListAsIni(ctx, selector)
					if err != nil {
						settingsFetchMetric.WithLabelValues("error").Inc()
						logger.Error("failed to fetch tenant settings", "namespace", namespace, "err", err)
						// Fall back to base config
					} else {
						settingsFetchMetric.WithLabelValues("success").Inc()
						// Merge tenant overrides with base config
						requestConfig.ApplyOverrides(settings, logger, fullFrontendSettingsEnabled)
					}
				}
			}

			// Store config in context for other middleware/handlers to use
			ctx = requestConfig.WithContext(ctx)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}
