package userk8s

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/rest"

	"github.com/grafana/grafana/apps/iam/pkg/apis/iam/v0alpha1"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/infra/log"
	"github.com/grafana/grafana/pkg/infra/tracing"
	"github.com/grafana/grafana/pkg/services/apiserver"
	"github.com/grafana/grafana/pkg/services/contexthandler/ctxkey"
	contextmodel "github.com/grafana/grafana/pkg/services/contexthandler/model"
	"github.com/grafana/grafana/pkg/services/user"
	"github.com/grafana/grafana/pkg/setting"
)

func TestUserK8sService_Create(t *testing.T) {
	tests := []struct {
		name           string
		cmd            *user.CreateUserCommand
		cfg            *setting.Cfg
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		expectErr      bool
		expectUser     *user.User
	}{
		{
			name:           "successfully creates a user",
			requesterOrgID: 1,
			cmd: &user.CreateUserCommand{
				Login: "jdoe",
				Email: "jdoe@example.com",
				Name:  "John Doe",
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				now := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:              "some-uid",
						Namespace:         "org-1",
						CreationTimestamp: metav1.NewTime(now),
					},
					Spec: v0alpha1.UserSpec{
						Login: "jdoe",
						Email: "jdoe@example.com",
						Title: "John Doe",
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:     "some-uid",
				OrgID:   1,
				Login:   "jdoe",
				Email:   "jdoe@example.com",
				Name:    "John Doe",
				Created: time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "maps admin, disabled, emailVerified, provisioned and role fields",
			requesterOrgID: 2,
			cmd: &user.CreateUserCommand{
				Login:          "admin-user",
				Email:          "admin@example.com",
				IsAdmin:        true,
				IsDisabled:     false,
				EmailVerified:  true,
				IsProvisioned:  true,
				DefaultOrgRole: "Admin",
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:      "admin-uid",
						Namespace: "org-2",
					},
					Spec: v0alpha1.UserSpec{
						Login:         "admin-user",
						Email:         "admin@example.com",
						GrafanaAdmin:  true,
						EmailVerified: true,
						Provisioned:   true,
						Role:          "Admin",
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:           "admin-uid",
				OrgID:         2,
				Login:         "admin-user",
				Email:         "admin@example.com",
				IsAdmin:       true,
				EmailVerified: true,
				IsProvisioned: true,
			},
		},
		{
			name:           "maps external auth info into the user spec",
			requesterOrgID: 1,
			cmd: &user.CreateUserCommand{
				Login: "jdoe",
				Email: "jdoe@example.com",
				ExternalAuthInfo: []user.ExternalAuthInfo{
					{Module: "authproxy", AuthID: "jdoe"},
					{Module: "oauth_github", AuthID: "42", ExternalUID: "ext-123"},
				},
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				var sent v0alpha1.User
				_ = json.NewDecoder(r.Body).Decode(&sent)
				if assert.Len(t, sent.Spec.ExternalAuthInfo, 2) {
					assert.Equal(t, "authproxy", sent.Spec.ExternalAuthInfo[0].Module)
					assert.Equal(t, "jdoe", sent.Spec.ExternalAuthInfo[0].AuthID)
					assert.Nil(t, sent.Spec.ExternalAuthInfo[0].ExternalUID, "empty externalUID should be omitted")
					assert.Equal(t, "oauth_github", sent.Spec.ExternalAuthInfo[1].Module)
					if assert.NotNil(t, sent.Spec.ExternalAuthInfo[1].ExternalUID) {
						assert.Equal(t, "ext-123", *sent.Spec.ExternalAuthInfo[1].ExternalUID)
					}
				}

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{Name: "some-uid", Namespace: "org-1"},
					Spec:       sent.Spec,
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:   "some-uid",
				OrgID: 1,
				Login: "jdoe",
				Email: "jdoe@example.com",
				ExternalAuthInfo: []user.ExternalAuthInfo{
					{Module: "authproxy", AuthID: "jdoe"},
					{Module: "oauth_github", AuthID: "42", ExternalUID: "ext-123"},
				},
			},
		},
		{
			name:           "uses provided UID when set",
			requesterOrgID: 1,
			cmd: &user.CreateUserCommand{
				UID:   "explicit-uid",
				Login: "user2",
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				meta := body["metadata"].(map[string]any)
				assert.Equal(t, "explicit-uid", meta["name"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:      "explicit-uid",
						Namespace: "org-1",
					},
					Spec: v0alpha1.UserSpec{Login: "user2"},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:   "explicit-uid",
				OrgID: 1,
				Login: "user2",
			},
		},
		{
			name:           "email is empty then email gets the login value",
			requesterOrgID: 1,
			cmd: &user.CreateUserCommand{
				Login: "jdoe",
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				spec := body["spec"].(map[string]any)
				assert.Equal(t, "jdoe", spec["email"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:      "some-uid",
						Namespace: "org-1",
					},
					Spec: v0alpha1.UserSpec{
						Login: "jdoe",
						Email: "jdoe",
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:   "some-uid",
				OrgID: 1,
				Login: "jdoe",
				Email: "jdoe",
			},
		},
		{
			name:           "role is empty then it is set to autoAssignOrgRole",
			requesterOrgID: 1,
			cmd: &user.CreateUserCommand{
				Login: "jdoe",
				Email: "jdoe@example.com",
			},
			cfg: &setting.Cfg{AutoAssignOrgRole: "Viewer"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				spec := body["spec"].(map[string]any)
				assert.Equal(t, "Viewer", spec["role"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:      "some-uid",
						Namespace: "org-1",
					},
					Spec: v0alpha1.UserSpec{
						Login: "jdoe",
						Email: "jdoe@example.com",
						Role:  "Viewer",
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:   "some-uid",
				OrgID: 1,
				Login: "jdoe",
				Email: "jdoe@example.com",
			},
		},
		{
			name: "fails if there is no orgId in the context",
			cmd: &user.CreateUserCommand{
				Login: "jdoe",
				Email: "jdoe@example.com",
			},
			expectErr: true,
		},
		{
			name: "propagates error from k8s client",
			cmd: &user.CreateUserCommand{
				Login: "failing-user",
				OrgID: 1,
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "k8s error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.CreateUserCommand{Login: "any-user", OrgID: 1},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.CreateUserCommand{Login: "any-user", OrgID: 1},
			noReqContext: true,
			expectErr:    true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				requesterOrgID: tt.requesterOrgID,
				cfg:            tt.cfg,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.Create(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.expectUser.UID, result.UID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
			assert.Equal(t, tt.expectUser.Name, result.Name)
			assert.Equal(t, tt.expectUser.IsAdmin, result.IsAdmin)
			assert.Equal(t, tt.expectUser.IsDisabled, result.IsDisabled)
			assert.Equal(t, tt.expectUser.EmailVerified, result.EmailVerified)
			assert.Equal(t, tt.expectUser.IsProvisioned, result.IsProvisioned)
			assert.Equal(t, tt.expectUser.Created.UTC(), result.Created.UTC())
			assert.Equal(t, tt.expectUser.ExternalAuthInfo, result.ExternalAuthInfo)
		})
	}
}

func TestUserK8sService_GetByID(t *testing.T) {
	makeListResponse := func(users ...v0alpha1.User) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			items := make([]any, 0, len(users))
			for _, u := range users {
				items = append(items, u)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"apiVersion": "v1",
				"kind":       "List",
				"items":      items,
			})
		}
	}

	tests := []struct {
		name           string
		cmd            *user.GetUserByIDQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectErrIs    error
		expectUser     *user.User
	}{
		{
			name:           "successfully retrieves a user by internal ID",
			requesterOrgID: 1,
			cmd:            &user.GetUserByIDQuery{ID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "labelSelector=grafana.app")
				assert.Contains(t, r.URL.RawQuery, "42")
				makeListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.User{
				ID:            42,
				UID:           "some-uid",
				OrgID:         1,
				Login:         "jdoe",
				Email:         "jdoe@example.com",
				Name:          "John Doe",
				IsAdmin:       true,
				EmailVerified: true,
				LastSeenAt:    time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "maps all user fields correctly",
			requesterOrgID: 2,
			cmd:            &user.GetUserByIDQuery{ID: 7},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				now := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
				u := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:              "admin-uid",
						Namespace:         "org-2",
						Labels:            map[string]string{"grafana.app/deprecatedInternalID": "7"},
						CreationTimestamp: metav1.NewTime(now),
					},
					Spec: v0alpha1.UserSpec{
						Login:         "admin",
						Email:         "admin@example.com",
						Title:         "Admin User",
						GrafanaAdmin:  true,
						Disabled:      true,
						EmailVerified: true,
						Provisioned:   true,
					},
					Status: v0alpha1.UserStatus{
						LastSeenAt: time.Date(2025, 3, 15, 12, 0, 0, 0, time.UTC).Unix(),
					},
				}
				makeListResponse(u)(w, r)
			},
			expectUser: &user.User{
				ID:            7,
				UID:           "admin-uid",
				OrgID:         2,
				Login:         "admin",
				Email:         "admin@example.com",
				Name:          "Admin User",
				IsAdmin:       true,
				IsDisabled:    true,
				EmailVerified: true,
				IsProvisioned: true,
				Created:       time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC),
				LastSeenAt:    time.Date(2025, 3, 15, 12, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "returns ErrUserNotFound when no user matches",
			requesterOrgID: 1,
			cmd:            &user.GetUserByIDQuery{ID: 99},
			serverResponse: makeListResponse(),
			expectErr:      true,
			expectErrIs:    user.ErrUserNotFound,
		},
		{
			name:           "returns error when multiple users found with same internal ID",
			requesterOrgID: 1,
			cmd:            &user.GetUserByIDQuery{ID: 5},
			serverResponse: makeListResponse(
				newTestK8sUser("uid-1", "org-1", "user-a", "a@example.com"),
				newTestK8sUser("uid-2", "org-1", "user-b", "b@example.com"),
			),
			expectErr: true,
		},
		{
			name:           "propagates error from k8s client",
			requesterOrgID: 1,
			cmd:            &user.GetUserByIDQuery{ID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "k8s error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetUserByIDQuery{ID: 42},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.GetUserByIDQuery{ID: 42},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.GetUserByIDQuery{ID: 42},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetByID(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				if tt.expectErrIs != nil {
					require.ErrorIs(t, err, tt.expectErrIs)
				}
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.expectUser.ID, result.ID)
			assert.Equal(t, tt.expectUser.UID, result.UID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
			assert.Equal(t, tt.expectUser.Name, result.Name)
			assert.Equal(t, tt.expectUser.IsAdmin, result.IsAdmin)
			assert.Equal(t, tt.expectUser.IsDisabled, result.IsDisabled)
			assert.Equal(t, tt.expectUser.EmailVerified, result.EmailVerified)
			assert.Equal(t, tt.expectUser.IsProvisioned, result.IsProvisioned)
			assert.Equal(t, tt.expectUser.Created.UTC(), result.Created.UTC())
			assert.Equal(t, tt.expectUser.LastSeenAt.UTC(), result.LastSeenAt.UTC())
		})
	}
}

func TestUserK8sService_GetByUID(t *testing.T) {
	makeGetResponse := func(u v0alpha1.User) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(u)
		}
	}

	tests := []struct {
		name           string
		cmd            *user.GetUserByUIDQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noRequester    bool
		expectErr      bool
		expectErrIs    error
		expectUser     *user.User
	}{
		{
			name:           "successfully retrieves a user by UID",
			requesterOrgID: 1,
			cmd:            &user.GetUserByUIDQuery{UID: "some-uid"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.Path, "some-uid")
				makeGetResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.User{
				ID:            42,
				UID:           "some-uid",
				OrgID:         1,
				Login:         "jdoe",
				Email:         "jdoe@example.com",
				Name:          "John Doe",
				IsAdmin:       true,
				EmailVerified: true,
				LastSeenAt:    time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "returns ErrUserNotFound when user does not exist",
			requesterOrgID: 1,
			cmd:            &user.GetUserByUIDQuery{UID: "missing-uid"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusNotFound)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Reason:   metav1.StatusReasonNotFound,
					Code:     http.StatusNotFound,
				})
			},
			expectErr:   true,
			expectErrIs: user.ErrUserNotFound,
		},
		{
			name:           "propagates non-not-found error from k8s client",
			requesterOrgID: 1,
			cmd:            &user.GetUserByUIDQuery{UID: "some-uid"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "k8s error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetUserByUIDQuery{UID: "some-uid"},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.GetUserByUIDQuery{UID: "some-uid"},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetByUID(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				if tt.expectErrIs != nil {
					require.ErrorIs(t, err, tt.expectErrIs)
				}
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.expectUser.ID, result.ID)
			assert.Equal(t, tt.expectUser.UID, result.UID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
			assert.Equal(t, tt.expectUser.Name, result.Name)
			assert.Equal(t, tt.expectUser.IsAdmin, result.IsAdmin)
			assert.Equal(t, tt.expectUser.EmailVerified, result.EmailVerified)
		})
	}
}

func TestUserK8sService_ListByIdOrUID(t *testing.T) {
	mkUser := func(uid string) v0alpha1.User {
		return v0alpha1.User{
			TypeMeta: metav1.TypeMeta{
				APIVersion: v0alpha1.GroupVersion.Identifier(),
				Kind:       "User",
			},
			ObjectMeta: metav1.ObjectMeta{
				Name:      uid,
				Namespace: "org-1",
				Labels:    map[string]string{"grafana.app/deprecatedInternalID": "42"},
			},
			Spec: v0alpha1.UserSpec{Login: uid, Email: uid + "@example.com"},
		}
	}

	// makeHandler dispatches list-by-internal-ID (labelSelector query) and
	// get-by-UID (resource name in path) requests against the fake apiserver.
	makeHandler := func(byUID map[string]v0alpha1.User, byInternalID []v0alpha1.User) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			if r.URL.Query().Get("labelSelector") != "" {
				items := make([]any, 0, len(byInternalID))
				for _, u := range byInternalID {
					items = append(items, u)
				}
				_ = json.NewEncoder(w).Encode(map[string]any{"apiVersion": "v1", "kind": "List", "items": items})
				return
			}
			if u, ok := byUID[path.Base(r.URL.Path)]; ok {
				_ = json.NewEncoder(w).Encode(u)
				return
			}
			w.WriteHeader(http.StatusNotFound)
			_ = json.NewEncoder(w).Encode(metav1.Status{
				TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
				Status:   metav1.StatusFailure,
				Reason:   metav1.StatusReasonNotFound,
				Code:     http.StatusNotFound,
			})
		}
	}

	serverErr := func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		_ = json.NewEncoder(w).Encode(metav1.Status{
			TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
			Status:   metav1.StatusFailure,
			Code:     http.StatusInternalServerError,
		})
	}

	tests := []struct {
		name           string
		uids           []string
		ids            []int64
		requesterOrgID int64
		serverResponse func(http.ResponseWriter, *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectUIDs     []string
	}{
		{
			name:           "resolves users by UID",
			requesterOrgID: 1,
			uids:           []string{"uid-a", "uid-b"},
			serverResponse: makeHandler(map[string]v0alpha1.User{
				"uid-a": mkUser("uid-a"),
				"uid-b": mkUser("uid-b"),
			}, nil),
			expectUIDs: []string{"uid-a", "uid-b"},
		},
		{
			name:           "resolves users by internal ID",
			requesterOrgID: 1,
			ids:            []int64{7},
			serverResponse: makeHandler(nil, []v0alpha1.User{mkUser("uid-c")}),
			expectUIDs:     []string{"uid-c"},
		},
		{
			name:           "deduplicates users matched by both UID and internal ID",
			requesterOrgID: 1,
			uids:           []string{"uid-a"},
			ids:            []int64{7},
			serverResponse: makeHandler(
				map[string]v0alpha1.User{"uid-a": mkUser("uid-a")},
				[]v0alpha1.User{mkUser("uid-a")},
			),
			expectUIDs: []string{"uid-a"},
		},
		{
			name:           "skips UIDs that are not found",
			requesterOrgID: 1,
			uids:           []string{"uid-a", "missing"},
			serverResponse: makeHandler(map[string]v0alpha1.User{"uid-a": mkUser("uid-a")}, nil),
			expectUIDs:     []string{"uid-a"},
		},
		{
			name:           "skips internal IDs that resolve to no user",
			requesterOrgID: 1,
			ids:            []int64{99},
			serverResponse: makeHandler(nil, nil),
			expectUIDs:     []string{},
		},
		{
			name:           "skips empty UID strings without calling the server",
			requesterOrgID: 1,
			uids:           []string{""},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				t.Errorf("server should not be called for an empty UID")
			},
			expectUIDs: []string{},
		},
		{
			name:           "propagates non-not-found error on UID get",
			requesterOrgID: 1,
			uids:           []string{"uid-a"},
			serverResponse: serverErr,
			expectErr:      true,
		},
		{
			name:           "propagates error on internal ID list",
			requesterOrgID: 1,
			ids:            []int64{7},
			serverResponse: serverErr,
			expectErr:      true,
		},
		{
			name:           "returns error when multiple users found for an internal ID",
			requesterOrgID: 1,
			ids:            []int64{5},
			serverResponse: makeHandler(nil, []v0alpha1.User{mkUser("uid-a"), mkUser("uid-b")}),
			expectErr:      true,
		},
		{
			name:           "returns error when config provider not initialized",
			requesterOrgID: 1,
			uids:           []string{"uid-a"},
			nilProvider:    true,
			expectErr:      true,
		},
		{
			name:           "returns error when no request context",
			requesterOrgID: 1,
			uids:           []string{"uid-a"},
			noReqContext:   true,
			expectErr:      true,
		},
		{
			name:           "returns error when no requester in context",
			requesterOrgID: 1,
			uids:           []string{"uid-a"},
			noRequester:    true,
			expectErr:      true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.ListByIdOrUID(ctx, tt.uids, tt.ids)

			if tt.expectErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			gotUIDs := make([]string, 0, len(result))
			for _, u := range result {
				gotUIDs = append(gotUIDs, u.UID)
			}
			assert.Equal(t, tt.expectUIDs, gotUIDs)
		})
	}
}

func TestUserK8sService_GetByEmail(t *testing.T) {
	tests := []struct {
		name           string
		cmd            *user.GetUserByEmailQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectUser     *user.User
	}{
		{
			name:           "successfully retrieves a user by email",
			requesterOrgID: 1,
			cmd:            &user.GetUserByEmailQuery{Email: "jdoe@example.com"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
				now := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
				resp := v0alpha1.UserList{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					Items: []v0alpha1.User{
						{
							TypeMeta: metav1.TypeMeta{
								APIVersion: v0alpha1.GroupVersion.Identifier(),
								Kind:       "User",
							},
							ObjectMeta: metav1.ObjectMeta{
								Name:              "some-uid",
								Namespace:         "org-1",
								CreationTimestamp: metav1.NewTime(now),
							},
							Spec: v0alpha1.UserSpec{
								Login: "jdoe",
								Email: "jdoe@example.com",
								Title: "John Doe",
							},
							Status: v0alpha1.UserStatus{
								LastSeenAt: time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC).Unix(),
							},
						},
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:        "some-uid",
				OrgID:      1,
				Login:      "jdoe",
				Email:      "jdoe@example.com",
				Name:       "John Doe",
				Created:    time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC),
				LastSeenAt: time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "lowercases email before querying",
			requesterOrgID: 1,
			cmd:            &user.GetUserByEmailQuery{Email: "JDOE@EXAMPLE.COM"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
				resp := v0alpha1.UserList{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					Items: []v0alpha1.User{
						{
							TypeMeta: metav1.TypeMeta{
								APIVersion: v0alpha1.GroupVersion.Identifier(),
								Kind:       "User",
							},
							ObjectMeta: metav1.ObjectMeta{
								Name:      "some-uid",
								Namespace: "org-1",
							},
							Spec: v0alpha1.UserSpec{
								Login: "jdoe",
								Email: "jdoe@example.com",
							},
							Status: v0alpha1.UserStatus{
								LastSeenAt: time.Date(2025, 2, 10, 8, 30, 0, 0, time.UTC).Unix(),
							},
						},
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:        "some-uid",
				OrgID:      1,
				Login:      "jdoe",
				Email:      "jdoe@example.com",
				LastSeenAt: time.Date(2025, 2, 10, 8, 30, 0, 0, time.UTC),
			},
		},
		{
			name:           "maps all user fields correctly",
			requesterOrgID: 2,
			cmd:            &user.GetUserByEmailQuery{Email: "admin@example.com"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				resp := v0alpha1.UserList{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					Items: []v0alpha1.User{
						{
							TypeMeta: metav1.TypeMeta{
								APIVersion: v0alpha1.GroupVersion.Identifier(),
								Kind:       "User",
							},
							ObjectMeta: metav1.ObjectMeta{
								Name:      "admin-uid",
								Namespace: "org-2",
							},
							Spec: v0alpha1.UserSpec{
								Login:         "admin",
								Email:         "admin@example.com",
								GrafanaAdmin:  true,
								Disabled:      true,
								EmailVerified: true,
								Provisioned:   true,
							},
							Status: v0alpha1.UserStatus{
								// LastSeenAt is stored as Unix seconds (not millis)
								LastSeenAt: time.Date(2025, 3, 15, 12, 0, 0, 0, time.UTC).Unix(),
							},
						},
					},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectUser: &user.User{
				UID:           "admin-uid",
				OrgID:         2,
				Login:         "admin",
				Email:         "admin@example.com",
				IsAdmin:       true,
				IsDisabled:    true,
				EmailVerified: true,
				IsProvisioned: true,
				LastSeenAt:    time.Date(2025, 3, 15, 12, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "returns ErrUserNotFound when list is empty",
			requesterOrgID: 1,
			cmd:            &user.GetUserByEmailQuery{Email: "notfound@example.com"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				resp := v0alpha1.UserList{}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
			expectErr: true,
		},
		{
			name:           "propagates error from k8s client",
			requesterOrgID: 1,
			cmd:            &user.GetUserByEmailQuery{Email: "jdoe@example.com"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "k8s error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetUserByEmailQuery{Email: "jdoe@example.com"},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.GetUserByEmailQuery{Email: "jdoe@example.com"},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.GetUserByEmailQuery{Email: "jdoe@example.com"},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetByEmail(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.expectUser.UID, result.UID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
			assert.Equal(t, tt.expectUser.Name, result.Name)
			assert.Equal(t, tt.expectUser.IsAdmin, result.IsAdmin)
			assert.Equal(t, tt.expectUser.IsDisabled, result.IsDisabled)
			assert.Equal(t, tt.expectUser.EmailVerified, result.EmailVerified)
			assert.Equal(t, tt.expectUser.IsProvisioned, result.IsProvisioned)
			assert.Equal(t, tt.expectUser.Created.UTC(), result.Created.UTC())
			assert.Equal(t, tt.expectUser.LastSeenAt.UTC(), result.LastSeenAt.UTC())
		})
	}
}

func TestUserK8sService_GetByLogin(t *testing.T) {
	userList := func(users ...v0alpha1.User) v0alpha1.UserList {
		return v0alpha1.UserList{
			TypeMeta: metav1.TypeMeta{
				APIVersion: v0alpha1.GroupVersion.Identifier(),
				Kind:       "User",
			},
			Items: users,
		}
	}

	tests := []struct {
		name           string
		cmd            *user.GetUserByLoginQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectUser     *user.User
	}{
		{
			name:           "finds user by login",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "jdoe"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(userList(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")))
			},
			expectUser: &user.User{UID: "some-uid", OrgID: 1, Login: "jdoe", Email: "jdoe@example.com"},
		},
		{
			name:           "lowercases login before querying",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "JDOE"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(userList(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")))
			},
			expectUser: &user.User{UID: "some-uid", OrgID: 1, Login: "jdoe", Email: "jdoe@example.com"},
		},
		{
			name:           "finds user by email when LoginOrEmail contains @",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "jdoe@example.com"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(userList(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")))
			},
			expectUser: &user.User{UID: "some-uid", OrgID: 1, Login: "jdoe", Email: "jdoe@example.com"},
		},
		{
			name:           "falls back to login when email lookup returns no results",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "jdoe@example.com"},
			serverResponse: func() func(w http.ResponseWriter, r *http.Request) {
				callCount := 0
				return func(w http.ResponseWriter, r *http.Request) {
					w.Header().Set("Content-Type", "application/json")
					callCount++
					if callCount == 1 {
						// First call: email lookup returns empty
						assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
						_ = json.NewEncoder(w).Encode(userList())
					} else {
						// Second call: login lookup returns the user
						assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe%40example.com")
						_ = json.NewEncoder(w).Encode(userList(newTestK8sUser("some-uid", "org-1", "jdoe@example.com", "")))
					}
				}
			}(),
			expectUser: &user.User{UID: "some-uid", OrgID: 1, Login: "jdoe@example.com"},
		},
		{
			name:           "returns ErrUserNotFound when neither email nor login match",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "notfound"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(userList())
			},
			expectErr: true,
		},
		{
			name:           "propagates error from k8s client on login query",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "jdoe"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:           "propagates error from k8s client on email fallback to login query",
			requesterOrgID: 1,
			cmd:            &user.GetUserByLoginQuery{LoginOrEmail: "jdoe@example.com"},
			serverResponse: func() func(w http.ResponseWriter, r *http.Request) {
				callCount := 0
				return func(w http.ResponseWriter, r *http.Request) {
					w.Header().Set("Content-Type", "application/json")
					callCount++
					if callCount == 1 {
						// First call: email lookup returns empty, triggering login fallback
						_ = json.NewEncoder(w).Encode(userList())
					} else {
						// Second call: login lookup returns error
						w.WriteHeader(http.StatusInternalServerError)
						_ = json.NewEncoder(w).Encode(metav1.Status{
							TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
							Status:   metav1.StatusFailure,
							Code:     http.StatusInternalServerError,
						})
					}
				}
			}(),
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetUserByLoginQuery{LoginOrEmail: "jdoe"},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.GetUserByLoginQuery{LoginOrEmail: "jdoe"},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.GetUserByLoginQuery{LoginOrEmail: "jdoe"},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetByLogin(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.expectUser.UID, result.UID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
		})
	}
}

func strPtr(s string) *string { return &s }

func TestUserK8sService_Update(t *testing.T) {
	trueVal := true
	falseVal := false

	tests := []struct {
		name           string
		cmd            *user.UpdateUserCommand
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
	}{
		{
			name:           "successfully updates a user",
			requesterOrgID: 1,
			cmd: &user.UpdateUserCommand{
				UserID: 42,
				Name:   "Jane Doe",
				Email:  "jane@example.com",
				Login:  "janedoe",
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet {
					// List response
					resp := v0alpha1.User{
						TypeMeta: metav1.TypeMeta{
							APIVersion: v0alpha1.GroupVersion.Identifier(),
							Kind:       "User",
						},
						ObjectMeta: metav1.ObjectMeta{
							Name:      "some-uid",
							Namespace: "org-1",
							Labels:    map[string]string{"grafana.app/deprecatedInternalID": "42"},
						},
						Spec: v0alpha1.UserSpec{Login: "jdoe", Email: "jdoe@example.com"},
					}
					list := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{resp},
					}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(list)
					return
				}
				// Update response
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				spec := body["spec"].(map[string]any)
				assert.Equal(t, "Jane Doe", spec["title"])
				assert.Equal(t, "jane@example.com", spec["email"])
				assert.Equal(t, "janedoe", spec["login"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{Name: "some-uid", Namespace: "org-1"},
					Spec:       v0alpha1.UserSpec{Login: "janedoe", Email: "jane@example.com", Title: "Jane Doe"},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
		},
		{
			name:           "updates optional boolean fields",
			requesterOrgID: 1,
			cmd: &user.UpdateUserCommand{
				UserID:         7,
				IsDisabled:     &trueVal,
				EmailVerified:  &falseVal,
				IsGrafanaAdmin: &trueVal,
				IsProvisioned:  &falseVal,
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet {
					resp := v0alpha1.User{
						TypeMeta: metav1.TypeMeta{
							APIVersion: v0alpha1.GroupVersion.Identifier(),
							Kind:       "User",
						},
						ObjectMeta: metav1.ObjectMeta{
							Name:      "some-uid",
							Namespace: "org-1",
							Labels:    map[string]string{"grafana.app/deprecatedInternalID": "7"},
						},
						Spec: v0alpha1.UserSpec{Login: "user7"},
					}
					list := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{resp},
					}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(list)
					return
				}
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				spec := body["spec"].(map[string]any)
				assert.Equal(t, true, spec["disabled"])
				assert.Equal(t, false, spec["emailVerified"])
				assert.Equal(t, true, spec["grafanaAdmin"])
				assert.Equal(t, false, spec["provisioned"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{Name: "some-uid", Namespace: "org-1"},
					Spec:       v0alpha1.UserSpec{Login: "user7", Disabled: true, GrafanaAdmin: true},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
		},
		{
			name:           "updates external auth info",
			requesterOrgID: 1,
			cmd: &user.UpdateUserCommand{
				UserID: 7,
				ExternalAuthInfo: []user.ExternalAuthInfo{
					{Module: "authproxy", AuthID: "jdoe"},
					{Module: "oauth_github", AuthID: "42", ExternalUID: "ext-123"},
				},
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet {
					resp := v0alpha1.User{
						TypeMeta: metav1.TypeMeta{
							APIVersion: v0alpha1.GroupVersion.Identifier(),
							Kind:       "User",
						},
						ObjectMeta: metav1.ObjectMeta{
							Name:      "some-uid",
							Namespace: "org-1",
							Labels:    map[string]string{"grafana.app/deprecatedInternalID": "7"},
						},
						Spec: v0alpha1.UserSpec{Login: "user7"},
					}
					list := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{resp},
					}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(list)
					return
				}
				var sent v0alpha1.User
				_ = json.NewDecoder(r.Body).Decode(&sent)
				if assert.Len(t, sent.Spec.ExternalAuthInfo, 2) {
					assert.Equal(t, "authproxy", sent.Spec.ExternalAuthInfo[0].Module)
					assert.Equal(t, "jdoe", sent.Spec.ExternalAuthInfo[0].AuthID)
					assert.Nil(t, sent.Spec.ExternalAuthInfo[0].ExternalUID, "empty externalUID should be omitted")
					assert.Equal(t, "oauth_github", sent.Spec.ExternalAuthInfo[1].Module)
					if assert.NotNil(t, sent.Spec.ExternalAuthInfo[1].ExternalUID) {
						assert.Equal(t, "ext-123", *sent.Spec.ExternalAuthInfo[1].ExternalUID)
					}
				}

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{Name: "some-uid", Namespace: "org-1"},
					Spec:       sent.Spec,
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
		},
		{
			name:           "updates the org role",
			requesterOrgID: 1,
			cmd: &user.UpdateUserCommand{
				UserID:  7,
				OrgRole: strPtr("Editor"),
			},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet {
					resp := v0alpha1.User{
						TypeMeta: metav1.TypeMeta{
							APIVersion: v0alpha1.GroupVersion.Identifier(),
							Kind:       "User",
						},
						ObjectMeta: metav1.ObjectMeta{
							Name:      "some-uid",
							Namespace: "org-1",
							Labels:    map[string]string{"grafana.app/deprecatedInternalID": "7"},
						},
						Spec: v0alpha1.UserSpec{Login: "user7", Role: "Admin"},
					}
					list := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{resp},
					}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(list)
					return
				}
				var body map[string]any
				_ = json.NewDecoder(r.Body).Decode(&body)
				spec := body["spec"].(map[string]any)
				assert.Equal(t, "Editor", spec["role"])

				resp := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{Name: "some-uid", Namespace: "org-1"},
					Spec:       v0alpha1.UserSpec{Login: "user7", Role: "Editor"},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(resp)
			},
		},
		{
			name:           "returns not found when user does not exist",
			requesterOrgID: 1,
			cmd:            &user.UpdateUserCommand{UserID: 99},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				list := map[string]any{
					"apiVersion": "v1",
					"kind":       "List",
					"items":      []any{},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(list)
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.UpdateUserCommand{UserID: 1},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.UpdateUserCommand{UserID: 1},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.UpdateUserCommand{UserID: 1},
			noRequester: true,
			expectErr:   true,
		},
		{
			name:           "returns error when list returns multiple users",
			requesterOrgID: 1,
			cmd:            &user.UpdateUserCommand{UserID: 5},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				user1 := v0alpha1.User{
					TypeMeta:   metav1.TypeMeta{APIVersion: v0alpha1.GroupVersion.Identifier(), Kind: "User"},
					ObjectMeta: metav1.ObjectMeta{Name: "uid-1", Namespace: "org-1"},
					Spec:       v0alpha1.UserSpec{Login: "user-a"},
				}
				user2 := v0alpha1.User{
					TypeMeta:   metav1.TypeMeta{APIVersion: v0alpha1.GroupVersion.Identifier(), Kind: "User"},
					ObjectMeta: metav1.ObjectMeta{Name: "uid-2", Namespace: "org-1"},
					Spec:       v0alpha1.UserSpec{Login: "user-b"},
				}
				list := map[string]any{
					"apiVersion": "v1",
					"kind":       "List",
					"items":      []any{user1, user2},
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(list)
			},
			expectErr: true,
		},
		{
			name:           "returns error when list call fails",
			requesterOrgID: 1,
			cmd:            &user.UpdateUserCommand{UserID: 5},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "internal server error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:           "propagates error from client.Update",
			requesterOrgID: 1,
			cmd:            &user.UpdateUserCommand{UserID: 5},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet {
					resp := v0alpha1.User{
						TypeMeta:   metav1.TypeMeta{APIVersion: v0alpha1.GroupVersion.Identifier(), Kind: "User"},
						ObjectMeta: metav1.ObjectMeta{Name: "uid-1", Namespace: "org-1"},
						Spec:       v0alpha1.UserSpec{Login: "user-a"},
					}
					list := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{resp},
					}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(list)
					return
				}
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusConflict)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "conflict",
					Code:     http.StatusConflict,
				})
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			err := svc.Update(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestUserK8sService_Delete(t *testing.T) {
	tests := []struct {
		name           string
		cmd            *user.DeleteUserCommand
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
	}{
		{
			name:           "successfully deletes a user",
			requesterOrgID: 1,
			cmd:            &user.DeleteUserCommand{UserID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				if r.Method == http.MethodGet {
					resp := map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")},
					}
					_ = json.NewEncoder(w).Encode(resp)
					return
				}
				assert.Equal(t, http.MethodDelete, r.Method)
				assert.Contains(t, r.URL.Path, "some-uid")
				w.WriteHeader(http.StatusOK)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusSuccess,
					Code:     http.StatusOK,
				})
			},
		},
		{
			name:           "returns ErrUserNotFound when no user matches",
			requesterOrgID: 1,
			cmd:            &user.DeleteUserCommand{UserID: 99},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(map[string]any{
					"apiVersion": "v1",
					"kind":       "List",
					"items":      []any{},
				})
			},
			expectErr: true,
		},
		{
			name:           "returns error when multiple users found with same internal ID",
			requesterOrgID: 1,
			cmd:            &user.DeleteUserCommand{UserID: 5},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(map[string]any{
					"apiVersion": "v1",
					"kind":       "List",
					"items": []any{
						newTestK8sUser("uid-1", "org-1", "user-a", "a@example.com"),
						newTestK8sUser("uid-2", "org-1", "user-b", "b@example.com"),
					},
				})
			},
			expectErr: true,
		},
		{
			name:           "returns error when list call fails",
			requesterOrgID: 1,
			cmd:            &user.DeleteUserCommand{UserID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "internal server error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:           "propagates error from client.Delete",
			requesterOrgID: 1,
			cmd:            &user.DeleteUserCommand{UserID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				if r.Method == http.MethodGet {
					_ = json.NewEncoder(w).Encode(map[string]any{
						"apiVersion": "v1",
						"kind":       "List",
						"items":      []any{newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")},
					})
					return
				}
				w.WriteHeader(http.StatusConflict)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "conflict",
					Code:     http.StatusConflict,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.DeleteUserCommand{UserID: 42},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.DeleteUserCommand{UserID: 42},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.DeleteUserCommand{UserID: 42},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			err := svc.Delete(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestUserK8sService_UpdateLastSeenAt(t *testing.T) {
	makeListResponse := func(userID int64, lastSeenAtSec int64) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			switch r.Method {
			case http.MethodGet:
				resp := map[string]any{
					"apiVersion": v0alpha1.GroupVersion.Identifier(),
					"kind":       "UserList",
					"items": []any{
						map[string]any{
							"apiVersion": v0alpha1.GroupVersion.Identifier(),
							"kind":       "User",
							"metadata": map[string]any{
								"name":      "some-uid",
								"namespace": "org-1",
								"labels":    map[string]any{"grafana.app/deprecatedInternalID": strconv.FormatInt(userID, 10)},
							},
							"spec":   map[string]any{"login": "jdoe"},
							"status": map[string]any{"lastSeenAt": lastSeenAtSec},
						},
					},
				}
				_ = json.NewEncoder(w).Encode(resp)
			case http.MethodPut:
				_ = json.NewEncoder(w).Encode(map[string]any{
					"apiVersion": v0alpha1.GroupVersion.Identifier(),
					"kind":       "User",
					"metadata":   map[string]any{"name": "some-uid", "namespace": "org-1"},
					"spec":       map[string]any{"login": "jdoe"},
					"status":     map[string]any{"lastSeenAt": time.Now().Unix()},
				})
			}
		}
	}

	tests := []struct {
		name         string
		cmd          *user.UpdateUserLastSeenAtCommand
		cfg          *setting.Cfg
		noReqContext bool
		nilProvider  bool
		serverFn     func(http.ResponseWriter, *http.Request)
		expectErr    bool
		expectErrIs  error
	}{
		{
			name:     "successfully updates last seen at",
			cmd:      &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			cfg:      &setting.Cfg{UserLastSeenUpdateInterval: 5 * time.Minute},
			serverFn: makeListResponse(42, 0),
		},
		{
			name:        "skips update when last seen is within the interval",
			cmd:         &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			cfg:         &setting.Cfg{UserLastSeenUpdateInterval: 1 * time.Hour},
			serverFn:    makeListResponse(42, time.Now().Unix()), // just seen
			expectErr:   true,
			expectErrIs: user.ErrLastSeenUpToDate,
		},
		{
			name: "returns ErrUserNotFound when no user matches the label selector",
			cmd:  &user.UpdateUserLastSeenAtCommand{UserID: 99, OrgID: 1},
			cfg:  &setting.Cfg{UserLastSeenUpdateInterval: 5 * time.Minute},
			serverFn: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(map[string]any{
					"apiVersion": v0alpha1.GroupVersion.Identifier(),
					"kind":       "UserList",
					"items":      []any{},
				})
			},
			expectErr:   true,
			expectErrIs: user.ErrUserNotFound,
		},
		{
			name: "returns error when multiple users found with same internal ID",
			cmd:  &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			cfg:  &setting.Cfg{UserLastSeenUpdateInterval: 5 * time.Minute},
			serverFn: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				item := map[string]any{
					"apiVersion": v0alpha1.GroupVersion.Identifier(),
					"kind":       "User",
					"metadata": map[string]any{
						"name":      "uid-1",
						"namespace": "org-1",
						"labels":    map[string]any{"grafana.app/deprecatedInternalID": "42"},
					},
					"spec":   map[string]any{"login": "user1"},
					"status": map[string]any{"lastSeenAt": 0},
				}
				_ = json.NewEncoder(w).Encode(map[string]any{
					"apiVersion": v0alpha1.GroupVersion.Identifier(),
					"kind":       "UserList",
					"items":      []any{item, item},
				})
			},
			expectErr: true,
		},
		{
			name: "returns error when k8s list fails",
			cmd:  &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			cfg:  &setting.Cfg{UserLastSeenUpdateInterval: 5 * time.Minute},
			serverFn: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1},
			nilProvider: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				noReqContext:   tt.noReqContext,
				nilProvider:    tt.nilProvider,
				cfg:            tt.cfg,
				serverResponse: tt.serverFn,
			})

			err := svc.UpdateLastSeenAt(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				if tt.expectErrIs != nil {
					require.ErrorIs(t, err, tt.expectErrIs)
				}
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestUserK8sService_UpdateLastSeenAt_UsesStatusSubresource(t *testing.T) {
	var putPath string
	var putBody map[string]any

	serverFn := func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.Method {
		case http.MethodGet:
			_ = json.NewEncoder(w).Encode(map[string]any{
				"apiVersion": v0alpha1.GroupVersion.Identifier(),
				"kind":       "UserList",
				"items": []any{
					map[string]any{
						"apiVersion": v0alpha1.GroupVersion.Identifier(),
						"kind":       "User",
						"metadata": map[string]any{
							"name":            "some-uid",
							"namespace":       "org-1",
							"resourceVersion": "123",
							"labels":          map[string]any{"grafana.app/deprecatedInternalID": "42"},
						},
						"spec":   map[string]any{"login": "jdoe"},
						"status": map[string]any{"lastSeenAt": 0},
					},
				},
			})
		case http.MethodPut:
			putPath = r.URL.Path
			_ = json.NewDecoder(r.Body).Decode(&putBody)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"apiVersion": v0alpha1.GroupVersion.Identifier(),
				"kind":       "User",
				"metadata":   map[string]any{"name": "some-uid", "namespace": "org-1"},
				"spec":       map[string]any{"login": "jdoe"},
				"status":     map[string]any{"lastSeenAt": time.Now().Unix()},
			})
		}
	}

	svc, ctx := setupServiceAndCtx(t, svcTestSetup{
		cfg:            &setting.Cfg{UserLastSeenUpdateInterval: 5 * time.Minute},
		serverResponse: serverFn,
	})

	err := svc.UpdateLastSeenAt(ctx, &user.UpdateUserLastSeenAtCommand{UserID: 42, OrgID: 1})
	require.NoError(t, err)

	require.True(t, strings.HasSuffix(putPath, "/users/some-uid/status"),
		"expected update to target the status subresource, got %q", putPath)

	status, ok := putBody["status"].(map[string]any)
	require.True(t, ok, "expected status in PUT body, got %v", putBody)
	require.NotZero(t, status["lastSeenAt"], "expected lastSeenAt to be set in the status update")
}

func TestUserK8sService_GetSignedInUser(t *testing.T) {
	makeUserListResponse := func(users ...v0alpha1.User) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			list := v0alpha1.UserList{
				TypeMeta: metav1.TypeMeta{
					APIVersion: v0alpha1.GroupVersion.Identifier(),
					Kind:       "UserList",
				},
				Items: users,
			}
			_ = json.NewEncoder(w).Encode(list)
		}
	}

	tests := []struct {
		name           string
		cmd            *user.GetSignedInUserQuery
		requesterOrgID int64
		serverResponse func(http.ResponseWriter, *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectErrIs    error
		expectUser     *user.SignedInUser
	}{
		{
			name:           "finds user by UserID via label selector",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "labelSelector=grafana.app")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "finds user by Login via field selector",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Login: "jdoe", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "lowercases login before querying",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Login: "JDOE", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "finds user by Email via field selector",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Email: "jdoe@example.com", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "lowercases email before querying",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Email: "JDOE@EXAMPLE.COM", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.email%3Djdoe%40example.com")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "uses OrgID from query when provided",
			requesterOrgID: 99,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 5},
			serverResponse: makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")),
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          5,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "falls back to orgID from context when query OrgID is zero",
			requesterOrgID: 3,
			cmd:            &user.GetSignedInUserQuery{UserID: 42},
			serverResponse: makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")),
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          3,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "sets OrgID to -1 and OrgName to 'Org missing' when role is empty",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				u := newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")
				u.Spec.Role = ""
				makeUserListResponse(u)(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          -1,
				OrgName:        "Org missing",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "sets OrgID to -1 and OrgName to 'Org missing' when role is invalid",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				u := newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")
				u.Spec.Role = "InvalidRole"
				makeUserListResponse(u)(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          -1,
				OrgName:        "Org missing",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "returns ErrNoUniqueID when no identifier provided",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{OrgID: 1},
			expectErr:      true,
			expectErrIs:    user.ErrNoUniqueID,
		},
		{
			name:           "returns ErrUserNotFound when UserID lookup returns empty list",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 99, OrgID: 1},
			serverResponse: makeUserListResponse(),
			expectErr:      true,
			expectErrIs:    user.ErrUserNotFound,
		},
		{
			name:           "returns ErrUserNotFound when Login lookup returns empty list",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Login: "notfound", OrgID: 1},
			serverResponse: makeUserListResponse(),
			expectErr:      true,
			expectErrIs:    user.ErrUserNotFound,
		},
		{
			name:           "returns ErrUserNotFound when Email lookup returns empty list",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Email: "notfound@example.com", OrgID: 1},
			serverResponse: makeUserListResponse(),
			expectErr:      true,
			expectErrIs:    user.ErrUserNotFound,
		},
		{
			name:           "returns error when multiple users found by UserID",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			serverResponse: makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"), newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com")),
			expectErr:      true,
		},
		{
			name:           "returns error when k8s list call fails",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.GetSignedInUserQuery{UserID: 42, OrgID: 1},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester and no OrgID in query",
			cmd:         &user.GetSignedInUserQuery{UserID: 42},
			noRequester: true,
			expectErr:   true,
		},
		{
			name:           "prefers UserID over Login and Email",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{UserID: 42, Login: "other", Email: "other@example.com", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "labelSelector=grafana.app")
				assert.NotContains(t, r.URL.RawQuery, "fieldSelector")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "prefers Login over Email when UserID is zero",
			requesterOrgID: 1,
			cmd:            &user.GetSignedInUserQuery{Login: "jdoe", Email: "other@example.com", OrgID: 1},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "fieldSelector=spec.login%3Djdoe")
				makeUserListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectUser: &user.SignedInUser{
				UserUID:        "some-uid",
				OrgID:          1,
				OrgRole:        "Admin",
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
				EmailVerified:  true,
				LastSeenAt:     time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetSignedInUser(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				if tt.expectErrIs != nil {
					require.ErrorIs(t, err, tt.expectErrIs)
				}
				return
			}

			require.NoError(t, err)
			require.NotNil(t, result)
			assert.Equal(t, tt.expectUser.UserUID, result.UserUID)
			assert.Equal(t, tt.expectUser.OrgID, result.OrgID)
			assert.Equal(t, tt.expectUser.OrgRole, result.OrgRole)
			assert.Equal(t, tt.expectUser.OrgName, result.OrgName)
			assert.Equal(t, tt.expectUser.Login, result.Login)
			assert.Equal(t, tt.expectUser.Email, result.Email)
			assert.Equal(t, tt.expectUser.Name, result.Name)
			assert.Equal(t, tt.expectUser.IsGrafanaAdmin, result.IsGrafanaAdmin)
			assert.Equal(t, tt.expectUser.IsDisabled, result.IsDisabled)
			assert.Equal(t, tt.expectUser.EmailVerified, result.EmailVerified)
			if !tt.expectUser.LastSeenAt.IsZero() {
				assert.Equal(t, tt.expectUser.LastSeenAt.UTC(), result.LastSeenAt.UTC())
			}
		})
	}
}

func TestUserK8sService_GetProfile(t *testing.T) {
	makeListResponse := func(users ...v0alpha1.User) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			items := make([]any, 0, len(users))
			for _, u := range users {
				items = append(items, u)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"apiVersion": "v1",
				"kind":       "List",
				"items":      items,
			})
		}
	}

	tests := []struct {
		name           string
		cmd            *user.GetUserProfileQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		noReqContext   bool
		noRequester    bool
		expectErr      bool
		expectErrIs    error
		expectProfile  *user.UserProfileDTO
	}{
		{
			name:           "successfully retrieves a user profile by internal ID",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.RawQuery, "labelSelector=grafana.app")
				assert.Contains(t, r.URL.RawQuery, "42")
				makeListResponse(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))(w, r)
			},
			expectProfile: &user.UserProfileDTO{
				ID:             42,
				UID:            "some-uid",
				OrgID:          1,
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
			},
		},
		{
			name:           "maps all profile fields correctly",
			requesterOrgID: 2,
			cmd:            &user.GetUserProfileQuery{UserID: 7},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				now := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
				u := v0alpha1.User{
					TypeMeta: metav1.TypeMeta{
						APIVersion: v0alpha1.GroupVersion.Identifier(),
						Kind:       "User",
					},
					ObjectMeta: metav1.ObjectMeta{
						Name:              "admin-uid",
						Namespace:         "org-2",
						Labels:            map[string]string{"grafana.app/deprecatedInternalID": "7"},
						CreationTimestamp: metav1.NewTime(now),
					},
					Spec: v0alpha1.UserSpec{
						Login:        "admin",
						Email:        "admin@example.com",
						Title:        "Admin User",
						GrafanaAdmin: true,
						Disabled:     true,
						Provisioned:  true,
					},
				}
				makeListResponse(u)(w, r)
			},
			expectProfile: &user.UserProfileDTO{
				ID:             7,
				UID:            "admin-uid",
				OrgID:          2,
				Login:          "admin",
				Email:          "admin@example.com",
				Name:           "Admin User",
				IsGrafanaAdmin: true,
				IsDisabled:     true,
				IsProvisioned:  true,
				CreatedAt:      time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC),
			},
		},
		{
			name:           "resolves by UID via a namespaced GET when UID is set",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 42, UID: "some-uid"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				// UID lookups must use a named GET, never a label-selector list.
				assert.Contains(t, r.URL.Path, "users/some-uid")
				assert.NotContains(t, r.URL.RawQuery, "labelSelector")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(newTestK8sUser("some-uid", "org-1", "jdoe", "jdoe@example.com"))
			},
			expectProfile: &user.UserProfileDTO{
				ID:             42,
				UID:            "some-uid",
				OrgID:          1,
				Login:          "jdoe",
				Email:          "jdoe@example.com",
				Name:           "John Doe",
				IsGrafanaAdmin: true,
			},
		},
		{
			name:           "returns ErrUserNotFound when UID GET 404s",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 42, UID: "missing-uid"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusNotFound)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Reason:   metav1.StatusReasonNotFound,
					Code:     http.StatusNotFound,
				})
			},
			expectErr:   true,
			expectErrIs: user.ErrUserNotFound,
		},
		{
			name:           "returns ErrUserNotFound when no user matches",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 99},
			serverResponse: makeListResponse(),
			expectErr:      true,
			expectErrIs:    user.ErrUserNotFound,
		},
		{
			name:           "returns error when multiple users found with same internal ID",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 5},
			serverResponse: makeListResponse(
				newTestK8sUser("uid-1", "org-1", "user-a", "a@example.com"),
				newTestK8sUser("uid-2", "org-1", "user-b", "b@example.com"),
			),
			expectErr: true,
		},
		{
			name:           "propagates error from k8s client",
			requesterOrgID: 1,
			cmd:            &user.GetUserProfileQuery{UserID: 42},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Message:  "k8s error",
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when config provider not initialized",
			cmd:         &user.GetUserProfileQuery{UserID: 42},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:         "returns error when no request context",
			cmd:          &user.GetUserProfileQuery{UserID: 42},
			noReqContext: true,
			expectErr:    true,
		},
		{
			name:        "returns error when no requester in context",
			cmd:         &user.GetUserProfileQuery{UserID: 42},
			noRequester: true,
			expectErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				noReqContext:   tt.noReqContext,
				noRequester:    tt.noRequester,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.GetProfile(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				if tt.expectErrIs != nil {
					require.ErrorIs(t, err, tt.expectErrIs)
				}
				return
			}

			require.NoError(t, err)
			require.NotNil(t, result)
			assert.Equal(t, tt.expectProfile.ID, result.ID)
			assert.Equal(t, tt.expectProfile.UID, result.UID)
			assert.Equal(t, tt.expectProfile.OrgID, result.OrgID)
			assert.Equal(t, tt.expectProfile.Login, result.Login)
			assert.Equal(t, tt.expectProfile.Email, result.Email)
			assert.Equal(t, tt.expectProfile.Name, result.Name)
			assert.Equal(t, tt.expectProfile.IsGrafanaAdmin, result.IsGrafanaAdmin)
			assert.Equal(t, tt.expectProfile.IsDisabled, result.IsDisabled)
			assert.Equal(t, tt.expectProfile.IsProvisioned, result.IsProvisioned)
			if !tt.expectProfile.CreatedAt.IsZero() {
				assert.Equal(t, tt.expectProfile.CreatedAt.UTC(), result.CreatedAt.UTC())
			}
		})
	}
}

func TestUserK8sService_Search(t *testing.T) {
	searchResponse := func(hits ...v0alpha1.GetSearchUsersUserHit) func(http.ResponseWriter, *http.Request) {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{
				TotalHits: int64(len(hits)),
				Hits:      hits,
			})
		}
	}

	tests := []struct {
		name           string
		cmd            *user.SearchUsersQuery
		requesterOrgID int64
		serverResponse func(w http.ResponseWriter, r *http.Request)
		nilProvider    bool
		expectErr      bool
		expectResult   *user.SearchUserQueryResult
	}{
		{
			name:           "returns hits with all fields mapped correctly",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{},
			serverResponse: searchResponse(v0alpha1.GetSearchUsersUserHit{
				Name:          "uid-one",
				Title:         "John Doe",
				Login:         "jdoe",
				Email:         "jdoe@example.com",
				LastSeenAt:    time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC).Unix(),
				LastSeenAtAge: "5 days",
				Provisioned:   true,
			}),
			expectResult: &user.SearchUserQueryResult{
				TotalCount: 1,
				Page:       1,
				PerPage:    500,
				Users: []*user.UserSearchHitDTO{
					{
						UID:           "uid-one",
						Name:          "John Doe",
						Login:         "jdoe",
						Email:         "jdoe@example.com",
						LastSeenAt:    time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC),
						LastSeenAtAge: "5 days",
						IsProvisioned: true,
					},
				},
			},
		},
		{
			name: "uses orgID from cmd when set",
			cmd:  &user.SearchUsersQuery{OrgID: 2},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.Path, "org-2")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{})
			},
		},
		{
			name:           "falls back to orgID from context when cmd.OrgID is zero",
			requesterOrgID: 3,
			cmd:            &user.SearchUsersQuery{},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Contains(t, r.URL.Path, "org-3")
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{})
			},
		},
		{
			name:           "passes query parameter to the search endpoint",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{Query: "doe"},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Equal(t, "doe", r.URL.Query().Get("query"))
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{})
			},
		},
		{
			name:           "uses default limit 500 and page 1 when cmd values are zero",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Equal(t, "500", r.URL.Query().Get("limit"))
				assert.Equal(t, "1", r.URL.Query().Get("page"))
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{})
			},
			expectResult: &user.SearchUserQueryResult{Page: 1, PerPage: 500},
		},
		{
			name:           "passes limit and page from cmd to the search endpoint",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{Limit: 25, Page: 3},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				assert.Equal(t, "25", r.URL.Query().Get("limit"))
				assert.Equal(t, "3", r.URL.Query().Get("page"))
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{})
			},
			expectResult: &user.SearchUserQueryResult{Page: 3, PerPage: 25},
		},
		{
			name:           "returns empty users slice when there are no hits",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{},
			serverResponse: searchResponse(),
			expectResult: &user.SearchUserQueryResult{
				TotalCount: 0,
				Page:       1,
				PerPage:    500,
			},
		},
		{
			name:           "propagates error from the search request",
			requesterOrgID: 1,
			cmd:            &user.SearchUsersQuery{},
			serverResponse: func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				_ = json.NewEncoder(w).Encode(metav1.Status{
					TypeMeta: metav1.TypeMeta{APIVersion: "v1", Kind: "Status"},
					Status:   metav1.StatusFailure,
					Code:     http.StatusInternalServerError,
				})
			},
			expectErr: true,
		},
		{
			name:        "returns error when client generator not initialized",
			cmd:         &user.SearchUsersQuery{OrgID: 1},
			nilProvider: true,
			expectErr:   true,
		},
		{
			name:      "returns error when no orgID in context and cmd.OrgID is zero",
			cmd:       &user.SearchUsersQuery{},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc, ctx := setupServiceAndCtx(t, svcTestSetup{
				nilProvider:    tt.nilProvider,
				requesterOrgID: tt.requesterOrgID,
				serverResponse: tt.serverResponse,
			})

			result, err := svc.Search(ctx, tt.cmd)

			if tt.expectErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.NotNil(t, result)

			if tt.expectResult == nil {
				return
			}

			assert.Equal(t, tt.expectResult.TotalCount, result.TotalCount)
			assert.Equal(t, tt.expectResult.Page, result.Page)
			assert.Equal(t, tt.expectResult.PerPage, result.PerPage)

			if tt.expectResult.Users != nil {
				require.Len(t, result.Users, len(tt.expectResult.Users))
				for i, expected := range tt.expectResult.Users {
					got := result.Users[i]
					assert.Equal(t, expected.UID, got.UID, "UID")
					assert.Equal(t, expected.Name, got.Name, "Name")
					assert.Equal(t, expected.Login, got.Login, "Login")
					assert.Equal(t, expected.Email, got.Email, "Email")
					assert.Equal(t, expected.IsProvisioned, got.IsProvisioned, "IsProvisioned")
					assert.Equal(t, expected.LastSeenAtAge, got.LastSeenAtAge, "LastSeenAtAge")
					if !expected.LastSeenAt.IsZero() {
						assert.Equal(t, expected.LastSeenAt.UTC(), got.LastSeenAt.UTC(), "LastSeenAt")
					}
				}
			} else {
				assert.Empty(t, result.Users)
			}
		})
	}
}

func newTestK8sUser(uid, namespace, login, email string) v0alpha1.User {
	return v0alpha1.User{
		TypeMeta: metav1.TypeMeta{
			APIVersion: v0alpha1.GroupVersion.Identifier(),
			Kind:       "User",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      uid,
			Namespace: namespace,
			Labels:    map[string]string{"grafana.app/deprecatedInternalID": "42"},
		},
		Spec: v0alpha1.UserSpec{
			Login:         login,
			Email:         email,
			Title:         "John Doe",
			GrafanaAdmin:  true,
			EmailVerified: true,
			Role:          "Admin",
		},
		Status: v0alpha1.UserStatus{
			LastSeenAt: time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC).Unix(),
		},
	}
}

type testDirectRestConfigProvider struct {
	serverURL string
}

func (p *testDirectRestConfigProvider) GetDirectRestConfig(_ *contextmodel.ReqContext) *rest.Config {
	return &rest.Config{Host: p.serverURL}
}

func (p *testDirectRestConfigProvider) DirectlyServeHTTP(_ http.ResponseWriter, _ *http.Request) {}

func (p *testDirectRestConfigProvider) IsReady() bool { return true }

var _ apiserver.DirectRestConfigProvider = (*testDirectRestConfigProvider)(nil)

func contextWithReqContext() context.Context {
	reqCtx := &contextmodel.ReqContext{}
	return context.WithValue(context.Background(), ctxkey.Key{}, reqCtx)
}

type svcTestSetup struct {
	nilProvider    bool
	noReqContext   bool
	noRequester    bool
	requesterOrgID int64
	cfg            *setting.Cfg
	serverResponse func(http.ResponseWriter, *http.Request)
}

func setupServiceAndCtx(t *testing.T, s svcTestSetup) (*UserK8sService, context.Context) {
	t.Helper()
	tracer := tracing.InitializeTracerForTest()

	var svc *UserK8sService
	if s.nilProvider {
		svc = NewUserK8sService(log.NewNopLogger(), s.cfg, nil, tracer)
	} else {
		ts := httptest.NewServer(http.HandlerFunc(s.serverResponse))
		t.Cleanup(ts.Close)
		svc = NewUserK8sService(log.NewNopLogger(), s.cfg, &testDirectRestConfigProvider{serverURL: ts.URL}, tracer)
	}

	ctx := contextWithReqContext()
	if s.noReqContext {
		ctx = context.Background()
	}
	if !s.noRequester && s.requesterOrgID != 0 {
		ctx = identity.WithRequester(ctx, &identity.StaticRequester{OrgID: s.requesterOrgID})
	}

	return svc, ctx
}

func TestUserK8sService_Search_MapsExtendedFields(t *testing.T) {
	created := time.Date(2024, 1, 2, 3, 4, 5, 0, time.UTC)
	lastSeen := time.Date(2025, 6, 1, 10, 0, 0, 0, time.UTC)

	var gotAccessControlParam string
	svc, ctx := setupServiceAndCtx(t, svcTestSetup{
		requesterOrgID: 1,
		serverResponse: func(w http.ResponseWriter, r *http.Request) {
			gotAccessControlParam = r.URL.Query().Get("accesscontrol")
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(v0alpha1.GetSearchUsersResponse{
				TotalHits: 1,
				Hits: []v0alpha1.GetSearchUsersUserHit{{
					Name:          "uid-one",
					Title:         "John Doe",
					Login:         "jdoe",
					Email:         "jdoe@example.com",
					Role:          "Admin",
					AccessControl: map[string]bool{"org.users:write": true},
					LastSeenAt:    lastSeen.Unix(),
					LastSeenAtAge: "5 days",
					Provisioned:   true,
					Disabled:      true,
					InternalId:    42,
					Created:       created.UnixMilli(),
				}},
			})
		},
	})

	result, err := svc.Search(ctx, &user.SearchUsersQuery{IncludeAccessControl: true})
	require.NoError(t, err)
	require.Len(t, result.Users, 1)

	assert.Equal(t, "true", gotAccessControlParam)

	got := result.Users[0]
	assert.Equal(t, int64(42), got.ID)
	assert.Equal(t, "uid-one", got.UID)
	assert.Equal(t, "Admin", got.Role)
	assert.Equal(t, map[string]bool{"org.users:write": true}, got.AccessControl)
	assert.True(t, got.IsDisabled)
	assert.True(t, got.IsProvisioned)
	assert.Equal(t, created.UTC(), got.Created.UTC())
	assert.Equal(t, lastSeen.UTC(), got.LastSeenAt.UTC())
}
