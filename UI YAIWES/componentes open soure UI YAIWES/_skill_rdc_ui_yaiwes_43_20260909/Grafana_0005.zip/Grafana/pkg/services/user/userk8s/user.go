package userk8s

import (
	"context"
	"encoding/json"
	"errors"
	"strconv"
	"strings"
	"time"

	sdkk8s "github.com/grafana/grafana-app-sdk/k8s"
	"github.com/grafana/grafana-app-sdk/resource"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/trace"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/rest"

	iamv0alpha1 "github.com/grafana/grafana/apps/iam/pkg/apis/iam/v0alpha1"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/apimachinery/utils"
	"github.com/grafana/grafana/pkg/infra/log"
	"github.com/grafana/grafana/pkg/infra/tracing"
	"github.com/grafana/grafana/pkg/registry/apis/iam/common"
	"github.com/grafana/grafana/pkg/registry/apis/iam/legacysort"
	iamuser "github.com/grafana/grafana/pkg/registry/apis/iam/user"
	"github.com/grafana/grafana/pkg/services/apiserver"
	"github.com/grafana/grafana/pkg/services/apiserver/endpoints/request"
	"github.com/grafana/grafana/pkg/services/contexthandler"
	"github.com/grafana/grafana/pkg/services/user"
	"github.com/grafana/grafana/pkg/setting"
	"github.com/grafana/grafana/pkg/util"
)

type UserK8sService struct {
	logger          log.Logger
	namespaceMapper request.NamespaceMapper
	configProvider  apiserver.DirectRestConfigProvider
	config          *setting.Cfg
	tracer          tracing.Tracer
}

var _ user.Service = (*UserK8sService)(nil)

func NewUserK8sService(logger log.Logger, cfg *setting.Cfg, configProvider apiserver.DirectRestConfigProvider, tracer tracing.Tracer) *UserK8sService {
	return &UserK8sService{
		logger:          logger,
		namespaceMapper: request.GetNamespaceMapper(cfg),
		configProvider:  configProvider,
		config:          cfg,
		tracer:          tracer,
	}
}

// getRestConfig returns a per-request rest.Config whose Transport injects the
// caller identity from ctx's *contextmodel.ReqContext. Returns an error if
// either the provider or the request context is missing — callers in
// userimpl.Service route those cases to the legacy path.
func (s *UserK8sService) getRestConfig(ctx context.Context) (*rest.Config, error) {
	if s.configProvider == nil {
		return nil, errors.New("config provider not initialized")
	}
	reqCtx := contexthandler.FromContext(ctx)
	if reqCtx == nil {
		return nil, errors.New("no request context")
	}
	cfg := s.configProvider.GetDirectRestConfig(reqCtx)
	if cfg == nil {
		return nil, errors.New("rest config not available")
	}
	return cfg, nil
}

func (s *UserK8sService) getUserClient(ctx context.Context) (*iamv0alpha1.UserClient, error) {
	cfg, err := s.getRestConfig(ctx)
	if err != nil {
		return nil, err
	}
	cfg.APIPath = "apis"
	registry := sdkk8s.NewClientRegistry(*cfg, sdkk8s.DefaultClientConfig())
	return iamv0alpha1.NewUserClientFromGenerator(registry)
}

func (s *UserK8sService) getRESTClient(ctx context.Context) (*rest.RESTClient, error) {
	cfg, err := s.getRestConfig(ctx)
	if err != nil {
		return nil, err
	}
	dynCfg := dynamic.ConfigFor(cfg)
	dynCfg.GroupVersion = &iamv0alpha1.GroupVersion
	return rest.RESTClientFor(dynCfg)
}

func (s *UserK8sService) Create(ctx context.Context, cmd *user.CreateUserCommand) (*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.create", trace.WithAttributes(
		attribute.String("login", cmd.Login),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in Create", "err", err)
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		return nil, err
	}

	uid := cmd.UID
	if uid == "" {
		uid = util.GenerateShortUID()
	}

	role := cmd.DefaultOrgRole
	if role == "" && s.config != nil {
		role = s.config.AutoAssignOrgRole
	}

	if cmd.Email == "" {
		cmd.Email = cmd.Login
	}

	k8sUser := &iamv0alpha1.User{
		ObjectMeta: metav1.ObjectMeta{
			Name:      uid,
			Namespace: namespace,
		},
		Spec: iamv0alpha1.UserSpec{
			Login:            strings.ToLower(cmd.Login),
			Email:            strings.ToLower(cmd.Email),
			Title:            cmd.Name,
			GrafanaAdmin:     cmd.IsAdmin,
			Disabled:         cmd.IsDisabled,
			EmailVerified:    cmd.EmailVerified,
			Provisioned:      cmd.IsProvisioned,
			Role:             role,
			ExternalAuthInfo: toExternalAuthInfo(cmd.ExternalAuthInfo),
		},
	}

	created, err := client.Create(ctx, k8sUser, resource.CreateOptions{})
	if err != nil {
		ctxLogger.Error("k8s user create failed", "namespace", namespace, "orgID", orgID, "login", cmd.Login, "err", err)
		span.RecordError(err)
		return nil, err
	}

	return toUser(created, orgID), nil
}

func (s *UserK8sService) CreateServiceAccount(ctx context.Context, cmd *user.CreateUserCommand) (*user.User, error) {
	return nil, errors.New("not implemented")
}

func (s *UserK8sService) Delete(ctx context.Context, cmd *user.DeleteUserCommand) error {
	ctx, span := s.tracer.Start(ctx, "user.delete", trace.WithAttributes(
		attribute.Int64("userID", cmd.UserID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in Delete", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	existing, err := s.getByInternalID(ctx, ctxLogger, client, cmd.UserID, namespace)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	err = client.Delete(ctx, resource.Identifier{
		Namespace: namespace,
		Name:      existing.Name,
	}, resource.DeleteOptions{})
	if err != nil {
		ctxLogger.Error("k8s user delete failed", "namespace", namespace, "orgID", orgID, "userID", cmd.UserID, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	return nil
}

func (s *UserK8sService) GetByID(ctx context.Context, cmd *user.GetUserByIDQuery) (*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.getByID", trace.WithAttributes(
		attribute.Int64("userID", cmd.ID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in GetByID", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	found, err := s.getByInternalID(ctx, ctxLogger, client, cmd.ID, namespace)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	return toUser(found, orgID), nil
}

func (s *UserK8sService) GetByUID(ctx context.Context, cmd *user.GetUserByUIDQuery) (*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.getByUID", trace.WithAttributes(
		attribute.String("userUID", cmd.UID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in GetByUID", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	found, err := client.Get(ctx, resource.Identifier{Namespace: namespace, Name: cmd.UID})
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil, user.ErrUserNotFound
		}
		ctxLogger.Error("k8s user get by UID failed", "namespace", namespace, "userUID", cmd.UID, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	return toUser(found, orgID), nil
}

// ListByIdOrUID resolves users by their k8s UID (resource name) and/or legacy
// internal ID, deduplicating users matched by both. Users that don't resolve are
// omitted, matching the legacy "WHERE uid IN (...) OR id IN (...)" semantics.
func (s *UserK8sService) ListByIdOrUID(ctx context.Context, uids []string, intIDs []int64) ([]*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.listByIdOrUID")
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in ListByIdOrUID", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	users := make([]*user.User, 0, len(uids)+len(intIDs))
	seen := make(map[string]struct{}, len(uids)+len(intIDs))

	for _, uid := range uids {
		if uid == "" {
			continue
		}
		found, err := client.Get(ctx, resource.Identifier{Namespace: namespace, Name: uid})
		if err != nil {
			if apierrors.IsNotFound(err) {
				continue
			}
			ctxLogger.Error("k8s user get by UID failed", "namespace", namespace, "userUID", uid, "err", err)
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
		if _, ok := seen[found.Name]; ok {
			continue
		}
		seen[found.Name] = struct{}{}
		users = append(users, toUser(found, orgID))
	}

	for _, id := range intIDs {
		found, err := s.getByInternalID(ctx, ctxLogger, client, id, namespace)
		if err != nil {
			if errors.Is(err, user.ErrUserNotFound) {
				continue
			}
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
		if _, ok := seen[found.Name]; ok {
			continue
		}
		seen[found.Name] = struct{}{}
		users = append(users, toUser(found, orgID))
	}

	return users, nil
}

func (s *UserK8sService) GetByLoginWithPassword(_ context.Context, _ *user.GetUserByLoginQuery) (*user.User, error) {
	return nil, errors.New("not implemented")
}

func (s *UserK8sService) GetByLogin(ctx context.Context, cmd *user.GetUserByLoginQuery) (*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.getByLogin", trace.WithAttributes(
		attribute.String("loginOrEmail", cmd.LoginOrEmail),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	loginOrEmail := strings.ToLower(cmd.LoginOrEmail)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in GetByLogin", "err", err)
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		return nil, err
	}

	if strings.Contains(loginOrEmail, "@") {
		u, err := s.getByFieldSelector(ctx, ctxLogger, client, "spec.email", loginOrEmail, namespace, orgID)
		if err != nil && !errors.Is(err, user.ErrUserNotFound) {
			span.RecordError(err)
			return nil, err
		}
		if u != nil {
			return u, nil
		}
	}

	u, err := s.getByFieldSelector(ctx, ctxLogger, client, "spec.login", loginOrEmail, namespace, orgID)
	if err != nil {
		span.RecordError(err)
		return nil, err
	}

	return u, nil
}

func (s *UserK8sService) GetByEmail(ctx context.Context, cmd *user.GetUserByEmailQuery) (*user.User, error) {
	ctx, span := s.tracer.Start(ctx, "user.getByEmail", trace.WithAttributes(
		attribute.String("email", cmd.Email),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in GetByEmail", "err", err)
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		return nil, err
	}

	u, err := s.getByFieldSelector(ctx, ctxLogger, client, "spec.email", strings.ToLower(cmd.Email), namespace, orgID)
	if err != nil {
		span.RecordError(err)
		return nil, err
	}

	return u, nil
}

func (s *UserK8sService) Update(ctx context.Context, cmd *user.UpdateUserCommand) error {
	ctx, span := s.tracer.Start(ctx, "user.update", trace.WithAttributes(
		attribute.Int64("userID", cmd.UserID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in Update", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	existing, err := s.getByInternalID(ctx, ctxLogger, client, cmd.UserID, namespace)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	if cmd.Name != "" {
		existing.Spec.Title = cmd.Name
	}
	if cmd.Email != "" {
		existing.Spec.Email = strings.ToLower(cmd.Email)
	}
	if cmd.Login != "" {
		existing.Spec.Login = strings.ToLower(cmd.Login)
	}
	if cmd.IsDisabled != nil {
		existing.Spec.Disabled = *cmd.IsDisabled
	}
	if cmd.EmailVerified != nil {
		existing.Spec.EmailVerified = *cmd.EmailVerified
	}
	if cmd.IsGrafanaAdmin != nil {
		existing.Spec.GrafanaAdmin = *cmd.IsGrafanaAdmin
	}
	if cmd.IsProvisioned != nil {
		existing.Spec.Provisioned = *cmd.IsProvisioned
	}
	if cmd.OrgRole != nil {
		existing.Spec.Role = *cmd.OrgRole
	}
	if cmd.ExternalAuthInfo != nil {
		existing.Spec.ExternalAuthInfo = toExternalAuthInfo(cmd.ExternalAuthInfo)
	}

	_, err = client.Update(ctx, existing, resource.UpdateOptions{})
	if err != nil {
		ctxLogger.Error("k8s user update failed", "namespace", namespace, "orgID", orgID, "userID", cmd.UserID, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	return nil
}

func (s *UserK8sService) UpdateLastSeenAt(ctx context.Context, cmd *user.UpdateUserLastSeenAtCommand) error {
	ctx, span := s.tracer.Start(ctx, "user.updateLastSeenAt", trace.WithAttributes(
		attribute.Int64("userID", cmd.UserID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	namespace := s.namespaceMapper(cmd.OrgID)
	span.SetAttributes(attribute.Int64("orgID", cmd.OrgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	existing, err := s.getByInternalID(ctx, ctxLogger, client, cmd.UserID, namespace)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	if existing.Status.LastSeenAt != 0 {
		lastSeen := time.Unix(existing.Status.LastSeenAt, 0)
		if time.Since(lastSeen) <= s.config.UserLastSeenUpdateInterval {
			return user.ErrLastSeenUpToDate
		}
	}

	existing.Status.LastSeenAt = time.Now().Unix()

	// Use a full Update (not UpdateStatus) to avoid a bug in UserClient.UpdateStatus
	// which constructs a new User with an empty Spec, causing the status subresource
	// path to persist an empty spec and corrupt the stored user data.
	_, err = client.Update(ctx, existing, resource.UpdateOptions{
		Subresource:     "status",
		ResourceVersion: existing.ResourceVersion,
	})
	if err != nil {
		ctxLogger.Error("k8s user update status failed", "namespace", namespace, "orgID", cmd.OrgID, "userID", cmd.UserID, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return err
	}

	return nil
}

func (s *UserK8sService) GetSignedInUser(ctx context.Context, cmd *user.GetSignedInUserQuery) (*user.SignedInUser, error) {
	ctx, span := s.tracer.Start(ctx, "user.getSignedInUser", trace.WithAttributes(
		attribute.Int64("userID", cmd.UserID),
		attribute.Int64("orgID", cmd.OrgID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID := cmd.OrgID
	if orgID <= 0 {
		var err error
		orgID, err = s.getOrgID(ctx, ctxLogger)
		if err != nil {
			ctxLogger.Error("failed to get orgID from context in GetSignedInUser", "err", err)
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	var found *iamv0alpha1.User
	var lookupErr error
	switch {
	case cmd.UserID > 0:
		found, lookupErr = s.getByInternalID(ctx, ctxLogger, client, cmd.UserID, namespace)
	case cmd.Login != "":
		found, lookupErr = s.getByFieldSelectorRaw(ctx, ctxLogger, client, "spec.login", strings.ToLower(cmd.Login), namespace)
	case cmd.Email != "":
		found, lookupErr = s.getByFieldSelectorRaw(ctx, ctxLogger, client, "spec.email", strings.ToLower(cmd.Email), namespace)
	default:
		span.RecordError(user.ErrNoUniqueID)
		span.SetStatus(codes.Error, user.ErrNoUniqueID.Error())
		return nil, user.ErrNoUniqueID
	}

	if lookupErr != nil {
		span.RecordError(lookupErr)
		span.SetStatus(codes.Error, lookupErr.Error())
		return nil, lookupErr
	}

	return toSignedInUser(found, orgID), nil
}

func (s *UserK8sService) Search(ctx context.Context, cmd *user.SearchUsersQuery) (*user.SearchUserQueryResult, error) {
	ctx, span := s.tracer.Start(ctx, "user.search", trace.WithAttributes(
		attribute.String("query", cmd.Query),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID := cmd.OrgID
	if orgID == 0 {
		var err error
		orgID, err = s.getOrgID(ctx, ctxLogger)
		if err != nil {
			ctxLogger.Error("failed to get orgID from context in Search", "err", err)
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	restClient, err := s.getRESTClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s rest client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	limit := cmd.Limit
	if limit <= 0 {
		limit = common.DefaultListLimit
	}
	page := cmd.Page
	if page <= 0 {
		page = 1
	}

	req := restClient.Get().
		AbsPath("apis", iamv0alpha1.APIGroup, iamv0alpha1.APIVersion, "namespaces", namespace, "searchUsers").
		Param("limit", strconv.Itoa(limit)).
		Param("page", strconv.Itoa(page))
	if cmd.Query != "" {
		req = req.Param("query", cmd.Query)
	}
	if cmd.IncludeAccessControl {
		req = req.Param("accesscontrol", "true")
	}
	for _, sortParam := range legacysort.ConvertToSortParams(cmd.SortOpts, iamuser.UserSortFieldMapping()) {
		req = req.Param("sort", sortParam)
	}

	raw, err := req.DoRaw(ctx)
	if err != nil {
		ctxLogger.Error("k8s user search request failed", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	var searchResp iamv0alpha1.GetSearchUsersResponse
	if err := json.Unmarshal(raw, &searchResp); err != nil {
		ctxLogger.Error("failed to decode k8s user search response", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	users := make([]*user.UserSearchHitDTO, 0, len(searchResp.Hits))
	for _, hit := range searchResp.Hits {
		users = append(users, &user.UserSearchHitDTO{
			ID:            hit.InternalId,
			UID:           hit.Name,
			Name:          hit.Title,
			Login:         hit.Login,
			Email:         hit.Email,
			Role:          hit.Role,
			AccessControl: hit.AccessControl,
			LastSeenAt:    time.Unix(hit.LastSeenAt, 0),
			LastSeenAtAge: hit.LastSeenAtAge,
			Created:       time.UnixMilli(hit.Created),
			IsDisabled:    hit.Disabled,
			IsProvisioned: hit.Provisioned,
			AuthModule:    user.AuthModuleConversion(hit.ExternalAuthModules),
		})
	}

	return &user.SearchUserQueryResult{
		TotalCount: searchResp.TotalHits,
		Users:      users,
		Page:       page,
		PerPage:    limit,
	}, nil
}

func (s *UserK8sService) BatchDisableUsers(ctx context.Context, cmd *user.BatchDisableUsersCommand) error {
	return errors.New("not implemented")
}

func (s *UserK8sService) GetProfile(ctx context.Context, cmd *user.GetUserProfileQuery) (*user.UserProfileDTO, error) {
	ctx, span := s.tracer.Start(ctx, "user.getProfile", trace.WithAttributes(
		attribute.Int64("userID", cmd.UserID),
	))
	defer span.End()

	ctxLogger := s.logger.FromContext(ctx)

	orgID, err := s.getOrgID(ctx, ctxLogger)
	if err != nil {
		ctxLogger.Error("failed to get orgID from context in GetProfile", "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	namespace := s.namespaceMapper(orgID)
	span.SetAttributes(attribute.Int64("orgID", orgID))

	client, err := s.getUserClient(ctx)
	if err != nil {
		ctxLogger.Error("failed to get k8s client", "namespace", namespace, "err", err)
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
		return nil, err
	}

	var found *iamv0alpha1.User
	if cmd.UID != "" {
		found, err = client.Get(ctx, resource.Identifier{Namespace: namespace, Name: cmd.UID})
		if err != nil {
			if apierrors.IsNotFound(err) {
				return nil, user.ErrUserNotFound
			}
			ctxLogger.Error("k8s user get by UID failed", "namespace", namespace, "userUID", cmd.UID, "err", err)
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
	} else {
		found, err = s.getByInternalID(ctx, ctxLogger, client, cmd.UserID, namespace)
		if err != nil {
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
			return nil, err
		}
	}

	return toUserProfileDTO(found, orgID), nil
}

func (s *UserK8sService) GetUsageStats(ctx context.Context) map[string]any {
	return map[string]any{}
}

func getUserID(u *iamv0alpha1.User) int64 {
	if meta, err := utils.MetaAccessor(u); err == nil {
		return meta.GetDeprecatedInternalID() // nolint:staticcheck
	}
	return 0
}

func (s *UserK8sService) getOrgID(ctx context.Context, logger log.Logger) (int64, error) {
	requester, err := identity.GetRequester(ctx)
	if err == nil {
		return requester.GetOrgID(), nil
	}

	logger.Debug("failed to get requester from context, falling back to orgID", "error", err)
	orgID, ok := identity.OrgIDFrom(ctx)
	if ok {
		return orgID, nil
	}

	return 0, errors.New("failed to get orgID: no requester or orgID in context")
}

func (s *UserK8sService) getByInternalID(ctx context.Context, logger log.Logger, client *iamv0alpha1.UserClient, userID int64, namespace string) (*iamv0alpha1.User, error) {
	labelSelector := utils.LabelKeyDeprecatedInternalID + "=" + strconv.FormatInt(userID, 10)
	list, err := client.List(ctx, namespace, resource.ListOptions{
		LabelFilters: []string{labelSelector},
	})
	if err != nil {
		logger.Error("k8s user list failed", "namespace", namespace, "userID", userID, "err", err)
		return nil, err
	}

	if len(list.Items) == 0 {
		return nil, user.ErrUserNotFound
	}

	if len(list.Items) > 1 {
		logger.Error("multiple users found with same deprecated internal ID", "namespace", namespace, "userID", userID, "count", len(list.Items))
		return nil, errors.New("multiple users found")
	}

	return &list.Items[0], nil
}

func (s *UserK8sService) getByFieldSelectorRaw(ctx context.Context, logger log.Logger, client *iamv0alpha1.UserClient, field, value, namespace string) (*iamv0alpha1.User, error) {
	list, err := client.List(ctx, namespace, resource.ListOptions{
		FieldSelectors: []string{field + "=" + value},
	})
	if err != nil {
		logger.Error("k8s user list failed", "field", field, "value", value, "err", err)
		return nil, err
	}
	if len(list.Items) == 0 {
		return nil, user.ErrUserNotFound
	}
	return &list.Items[0], nil
}

func (s *UserK8sService) getByFieldSelector(ctx context.Context, logger log.Logger, client *iamv0alpha1.UserClient, field, value, namespace string, orgID int64) (*user.User, error) {
	found, err := s.getByFieldSelectorRaw(ctx, logger, client, field, value, namespace)
	if err != nil {
		return nil, err
	}
	return toUser(found, orgID), nil
}

func toSignedInUser(u *iamv0alpha1.User, orgID int64) *user.SignedInUser {
	userID := getUserID(u)

	signedInUser := &user.SignedInUser{
		UserID:         userID,
		UserUID:        u.Name,
		OrgID:          orgID,
		Login:          u.Spec.Login,
		Name:           u.Spec.Title,
		Email:          u.Spec.Email,
		EmailVerified:  u.Spec.EmailVerified,
		IsGrafanaAdmin: u.Spec.GrafanaAdmin,
		IsDisabled:     u.Spec.Disabled,
		LastSeenAt:     time.Unix(u.Status.LastSeenAt, 0),
	}

	role := identity.RoleType(u.Spec.Role)
	if role.IsValid() {
		signedInUser.OrgRole = role
	} else {
		signedInUser.OrgID = -1
		signedInUser.OrgName = "Org missing"
	}

	return signedInUser
}

func toUserProfileDTO(u *iamv0alpha1.User, orgID int64) *user.UserProfileDTO {
	return &user.UserProfileDTO{
		ID:             getUserID(u),
		UID:            u.Name,
		Email:          u.Spec.Email,
		Name:           u.Spec.Title,
		Login:          u.Spec.Login,
		OrgID:          orgID,
		IsGrafanaAdmin: u.Spec.GrafanaAdmin,
		IsDisabled:     u.Spec.Disabled,
		IsProvisioned:  u.Spec.Provisioned,
		UpdatedAt:      u.GetUpdateTimestamp(),
		CreatedAt:      u.CreationTimestamp.Time,
		AuthModules:    authModules(u.Spec.ExternalAuthInfo),
	}
}

func toUser(u *iamv0alpha1.User, orgID int64) *user.User {
	return &user.User{
		ID:               getUserID(u),
		UID:              u.Name,
		OrgID:            orgID,
		Login:            u.Spec.Login,
		Email:            u.Spec.Email,
		Name:             u.Spec.Title,
		IsAdmin:          u.Spec.GrafanaAdmin,
		IsDisabled:       u.Spec.Disabled,
		EmailVerified:    u.Spec.EmailVerified,
		IsProvisioned:    u.Spec.Provisioned,
		OrgRole:          u.Spec.Role,
		Created:          u.CreationTimestamp.Time,
		Updated:          u.GetUpdateTimestamp(),
		LastSeenAt:       time.Unix(u.Status.LastSeenAt, 0),
		ExternalAuthInfo: fromExternalAuthInfo(u.Spec.ExternalAuthInfo),
	}
}

func toExternalAuthInfo(in []user.ExternalAuthInfo) []iamv0alpha1.UserExternalAuthInfo {
	if len(in) == 0 {
		return nil
	}
	out := make([]iamv0alpha1.UserExternalAuthInfo, 0, len(in))
	for _, l := range in {
		info := iamv0alpha1.UserExternalAuthInfo{Module: l.Module, AuthID: l.AuthID}
		if l.ExternalUID != "" {
			externalUID := l.ExternalUID
			info.ExternalUID = &externalUID
		}
		out = append(out, info)
	}
	return out
}

func fromExternalAuthInfo(in []iamv0alpha1.UserExternalAuthInfo) []user.ExternalAuthInfo {
	if len(in) == 0 {
		return nil
	}
	out := make([]user.ExternalAuthInfo, 0, len(in))
	for _, l := range in {
		info := user.ExternalAuthInfo{Module: l.Module, AuthID: l.AuthID}
		if l.ExternalUID != nil {
			info.ExternalUID = *l.ExternalUID
		}
		out = append(out, info)
	}
	return out
}

func authModules(in []iamv0alpha1.UserExternalAuthInfo) []string {
	if len(in) == 0 {
		return nil
	}
	out := make([]string, 0, len(in))
	for _, l := range in {
		out = append(out, l.Module)
	}
	return out
}
