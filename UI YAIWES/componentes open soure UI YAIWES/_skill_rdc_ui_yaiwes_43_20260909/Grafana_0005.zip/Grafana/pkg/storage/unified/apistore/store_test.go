// SPDX-License-Identifier: AGPL-3.0-only
// Provenance-includes-location: https://github.com/kubernetes/kubernetes/blob/master/staging/src/k8s.io/apiserver/pkg/storage/cacher/cacher_test.go
// Provenance-includes-license: Apache-2.0
// Provenance-includes-copyright: The Kubernetes Authors.

package apistore_test

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	utilruntime "k8s.io/apimachinery/pkg/util/runtime"
	"k8s.io/apiserver/pkg/apis/example"
	examplev1 "k8s.io/apiserver/pkg/apis/example/v1"
	"k8s.io/apiserver/pkg/storage"
	"k8s.io/apiserver/pkg/storage/storagebackend"

	claims "github.com/grafana/authlib/types"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	storagetesting "github.com/grafana/grafana/pkg/apiserver/storage/testing"
	"github.com/grafana/grafana/pkg/storage/unified/apistore"
	"github.com/grafana/grafana/pkg/storage/unified/resourcepb"
	"github.com/grafana/grafana/pkg/util/testutil"
)

func init() {
	metav1.AddToGroupVersion(scheme, metav1.SchemeGroupVersion)
	utilruntime.Must(example.AddToScheme(scheme))
	utilruntime.Must(examplev1.AddToScheme(scheme))

	// Make sure there is a user in every context
	storagetesting.NewContext = func() context.Context {
		testUserA := &identity.StaticRequester{
			Type:           claims.TypeUser,
			Login:          "testuser",
			UserID:         123,
			UserUID:        "u123",
			OrgRole:        identity.RoleAdmin,
			IsGrafanaAdmin: true, // can do anything
		}
		return identity.WithRequester(context.Background(), testUserA)
	}
}

// GetPodAttrs returns labels and fields of a given object for filtering purposes.
func GetPodAttrs(obj runtime.Object) (labels.Set, fields.Set, error) {
	pod, ok := obj.(*example.Pod)
	if !ok {
		return nil, nil, fmt.Errorf("not a pod")
	}
	return labels.Set(pod.Labels), PodToSelectableFields(pod), nil
}

// PodToSelectableFields returns a field set that represents the object
// TODO: fields are not labels, and the validation rules for them do not apply.
func PodToSelectableFields(pod *example.Pod) fields.Set {
	// The purpose of allocation with a given number of elements is to reduce
	// amount of allocations needed to create the fields.Set. If you add any
	// field here or the number of object-meta related fields changes, this should
	// be adjusted.
	podSpecificFieldsSet := make(fields.Set, 5)
	podSpecificFieldsSet["spec.nodeName"] = pod.Spec.NodeName
	podSpecificFieldsSet["spec.restartPolicy"] = string(pod.Spec.RestartPolicy)
	podSpecificFieldsSet["status.phase"] = string(pod.Status.Phase)
	return AddObjectMetaFieldsSet(podSpecificFieldsSet, &pod.ObjectMeta, true)
}

func AddObjectMetaFieldsSet(source fields.Set, objectMeta *metav1.ObjectMeta, hasNamespaceField bool) fields.Set {
	source["metadata.name"] = objectMeta.Name
	if hasNamespaceField {
		source["metadata.namespace"] = objectMeta.Namespace
	}
	return source
}

func checkStorageInvariants(s storage.Interface) storagetesting.KeyValidation {
	return func(ctx context.Context, t *testing.T, key string) {
		obj := &example.Pod{}
		err := s.Get(ctx, key, storage.GetOptions{}, obj)
		if err != nil {
			t.Fatalf("Get failed: %v", err)
		}
	}
}

func TestCreate(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestCreate(ctx, t, store, checkStorageInvariants(store))
}

// No TTL support in unifed storage
// func TestCreateWithTTL(t *testing.T) {
// 	ctx, store, destroyFunc, err := testSetup(t)
// 	defer destroyFunc()
// 	assert.NoError(t, err)
// 	storagetesting.RunTestCreateWithTTL(ctx, t, store)
// }

func TestCreateWithKeyExist(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestCreateWithKeyExist(ctx, t, store)
}

func TestValidUpdate(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestValidUpdate(ctx, t, store)
}

// conditionalUpdateOnDeletedReturnsConflict asserts that a conditional
// (optimistic-concurrency) update — one whose object carries a resourceVersion — against a
// key that no longer exists returns Conflict, rather than resurrecting the object or failing
// with the opaque "resourceVersion should not be set on objects to be created" create error.
// This is the deleted-in-window race a read-then-write caller hits when the object is deleted
// between its read and its update.
func conditionalUpdateOnDeletedReturnsConflict(ctx context.Context, t *testing.T, store storage.Interface) {
	t.Helper()
	key := storagetesting.KeyFunc("test-ns", "gone")
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		return &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "gone", Namespace: "test-ns", ResourceVersion: "12345"}}, nil, nil
	}

	err := store.GuaranteedUpdate(ctx, key, &example.Pod{}, true /* ignoreNotFound */, nil, tryUpdate, nil)
	require.Error(t, err)
	assert.True(t, apierrors.IsConflict(err), "expected a Conflict error, got: %v", err)
}

// unconditionalUpsertOnMissingCreates asserts that an unconditional write (no
// resourceVersion) against a missing key still upserts — create-on-update is only suppressed
// for conditional updates.
func unconditionalUpsertOnMissingCreates(ctx context.Context, t *testing.T, store storage.Interface) {
	t.Helper()
	key := storagetesting.KeyFunc("test-ns", "fresh")
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		return &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "fresh", Namespace: "test-ns"}}, nil, nil
	}

	out := &example.Pod{}
	err := store.GuaranteedUpdate(ctx, key, out, true /* ignoreNotFound */, nil, tryUpdate, nil)
	require.NoError(t, err)
	assert.Equal(t, "fresh", out.Name)
}

func TestGuaranteedUpdateConditionalOnDeletedReturnsConflict(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)
	conditionalUpdateOnDeletedReturnsConflict(ctx, t, store)
}

func TestGuaranteedUpdateUnconditionalUpsertOnMissingCreates(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)
	unconditionalUpsertOnMissingCreates(ctx, t, store)
}

// TestIntegrationGuaranteedUpdateCreateOnUpdate exercises the create-on-update behavior
// against every storage backend (including the real SQL-backed unified store), so the
// Conflict-on-deleted semantics are verified end-to-end and not just against the in-memory
// file backend.
func TestIntegrationGuaranteedUpdateCreateOnUpdate(t *testing.T) {
	testutil.SkipIntegrationTestInShortMode(t)

	for _, s := range []StorageType{StorageTypeFile, StorageTypeUnified} {
		t.Run(string(s), func(t *testing.T) {
			t.Run("conditional update on deleted returns conflict", func(t *testing.T) {
				ctx, store, destroyFunc, err := testSetup(t, withStorageType(s))
				defer destroyFunc()
				require.NoError(t, err)
				conditionalUpdateOnDeletedReturnsConflict(ctx, t, store)
			})

			t.Run("unconditional upsert on missing creates", func(t *testing.T) {
				ctx, store, destroyFunc, err := testSetup(t, withStorageType(s))
				defer destroyFunc()
				require.NoError(t, err)
				unconditionalUpsertOnMissingCreates(ctx, t, store)
			})
		})
	}
}

// TestGuaranteedUpdateFailsFastOnNonRetryableError guards against re-running a deterministic
// update failure. Admission validation runs inside the tryUpdate closure on every attempt, so a
// terminal error like a BadRequest (e.g. "Dashboard refresh interval is too low") can never
// succeed on retry — it must return immediately rather than exhausting the retry budget. Because
// each loop iteration issues exactly one Read before calling tryUpdate, counting tryUpdate calls
// also asserts the object is read only once.
func TestGuaranteedUpdateFailsFastOnNonRetryableError(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)

	key := storagetesting.KeyFunc("test-ns", "foo")
	require.NoError(t, store.Create(ctx, key, &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "foo", Namespace: "test-ns"}}, &example.Pod{}, 0))

	attempts := 0
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		attempts++
		return nil, nil, apierrors.NewBadRequest("Dashboard refresh interval is too low")
	}

	err = store.GuaranteedUpdate(ctx, key, &example.Pod{}, false, nil, tryUpdate, nil)
	require.Error(t, err)
	assert.True(t, apierrors.IsBadRequest(err), "expected a BadRequest error, got: %v", err)
	assert.Equal(t, 1, attempts, "non-retryable error must not be retried")
}

func TestGuaranteedUpdateFailsFastOnTryUpdateConflict(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)

	key := storagetesting.KeyFunc("test-ns", "foo")
	require.NoError(t, store.Create(ctx, key, &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "foo", Namespace: "test-ns"}}, &example.Pod{}, 0))

	attempts := 0
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		attempts++
		return nil, nil, apierrors.NewConflict(schema.GroupResource{Resource: "pods"}, "foo", errors.New("optimistic lock"))
	}

	err = store.GuaranteedUpdate(ctx, key, &example.Pod{}, false, nil, tryUpdate, nil)
	require.Error(t, err)
	assert.True(t, apierrors.IsConflict(err), "expected a Conflict error, got: %v", err)
	assert.Equal(t, 1, attempts, "a conflict from tryUpdate is terminal and must not be retried")
}

func TestGuaranteedUpdateRetriesOnStorageConflict(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)

	key := storagetesting.KeyFunc("test-ns", "foo")
	require.NoError(t, store.Create(ctx, key, &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "foo", Namespace: "test-ns"}}, &example.Pod{}, 0))

	attempts := 0
	tryUpdate := func(input runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		attempts++
		if attempts == 1 {
			competing := func(in runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
				pod := in.(*example.Pod)
				pod.Spec.Subdomain = "raced"
				return pod, nil, nil
			}
			require.NoError(t, store.GuaranteedUpdate(ctx, key, &example.Pod{}, false, nil, competing, nil))
		}
		pod := input.(*example.Pod)
		pod.Spec.Hostname = "updated"
		return pod, nil, nil
	}

	out := &example.Pod{}
	err = store.GuaranteedUpdate(ctx, key, out, false, nil, tryUpdate, nil)
	require.NoError(t, err)
	assert.Equal(t, 2, attempts, "should re-read once after losing the compare-and-swap")
	assert.Equal(t, "updated", out.Spec.Hostname)
	assert.Equal(t, "raced", out.Spec.Subdomain, "the competing write must be preserved")
}

func TestGuaranteedUpdateStopsOnCanceledContext(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)

	key := storagetesting.KeyFunc("test-ns", "foo")
	require.NoError(t, store.Create(ctx, key, &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "foo", Namespace: "test-ns"}}, &example.Pod{}, 0))

	canceled, cancel := context.WithCancel(ctx)
	cancel()

	attempts := 0
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		attempts++
		return nil, nil, errors.New("should not be reached")
	}

	err = store.GuaranteedUpdate(canceled, key, &example.Pod{}, false, nil, tryUpdate, nil)
	require.ErrorIs(t, err, context.Canceled)
	assert.Equal(t, 0, attempts, "a canceled context must not issue any attempt")
}

func TestGuaranteedUpdatePreconditionFailureStaysInvalidObj(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	require.NoError(t, err)

	key := storagetesting.KeyFunc("test-ns", "foo")
	require.NoError(t, store.Create(ctx, key, &example.Pod{ObjectMeta: metav1.ObjectMeta{Name: "foo", Namespace: "test-ns"}}, &example.Pod{}, 0))

	wrongUID := types.UID("not-the-stored-uid")
	attempts := 0
	tryUpdate := func(_ runtime.Object, _ storage.ResponseMeta) (runtime.Object, *uint64, error) {
		attempts++
		return nil, nil, errors.New("should not be reached")
	}

	err = store.GuaranteedUpdate(ctx, key, &example.Pod{}, false, &storage.Preconditions{UID: &wrongUID}, tryUpdate, nil)
	require.Error(t, err)
	assert.True(t, storage.IsInvalidObj(err), "precondition error must stay unwrapped, got: %v", err)
	assert.Equal(t, 0, attempts, "a failed precondition must not call tryUpdate")
}

func TestGet(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestGet(ctx, t, store)
}

func TestUnconditionalDelete(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestUnconditionalDelete(ctx, t, store)
}

func TestConditionalDelete(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestConditionalDelete(ctx, t, store)
}

func TestDeleteWithSuggestion(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestDeleteWithSuggestion(ctx, t, store)
}

func TestDeleteWithSuggestionAndConflict(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestDeleteWithSuggestionAndConflict(ctx, t, store)
}

func TestDeleteWithConflict(t *testing.T) {
	ctx, store, destroyFunc, err := testSetup(t)
	defer destroyFunc()
	assert.NoError(t, err)
	storagetesting.RunTestDeleteWithConflict(ctx, t, store)
}

type resourceClientMock struct {
	resourcepb.ResourceStoreClient
	resourcepb.ResourceStatsClient
	resourcepb.ResourceIndexClient
	resourcepb.ManagedObjectIndexClient
	resourcepb.BulkStoreClient
	resourcepb.BlobStoreClient
	resourcepb.DiagnosticsClient
	resourcepb.QuotasClient
}

// always return GRPC Unauthenticated code
func (r resourceClientMock) List(ctx context.Context, in *resourcepb.ListRequest, opts ...grpc.CallOption) (*resourcepb.ListResponse, error) {
	return &resourcepb.ListResponse{}, status.Error(codes.Unauthenticated, "missing token")
}

func TestGRPCtoHTTPStatusMapping(t *testing.T) {
	t.Run("ensure that GRPC Unauthenticated code gets translated to HTTP StatusUnauthorized", func(t *testing.T) {
		s, _, err := apistore.NewStorage(
			&storagebackend.ConfigForResource{},
			resourceClientMock{},
			nil,
			nil,
			nil,
			nil,
			nil,
			nil,
			nil,
			nil,
			apistore.StorageOptions{})
		require.NoError(t, err)

		err = s.GetList(context.Background(), "/group/resource.grafana.app/resource/resources/namespace/default", storage.ListOptions{}, nil)
		require.Error(t, err)

		var statusError *apierrors.StatusError
		ok := errors.As(err, &statusError)
		require.Equal(t, true, ok)
		require.Equal(t, int(statusError.Status().Code), http.StatusUnauthorized)
	})
}

// TODO: this test relies on update
//func TestDeleteWithSuggestionOfDeletedObject(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestDeleteWithSuggestionOfDeletedObject(ctx, t, store)
//}

//func TestValidateDeletionWithSuggestion(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestValidateDeletionWithSuggestion(ctx, t, store)
//}
//
//func TestPreconditionalDeleteWithSuggestion(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestPreconditionalDeleteWithSuggestion(ctx, t, store)
//}

//func TestList(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestList(ctx, t, store, func(ctx context.Context, t *testing.T, rv string) {
//
//	}, true)
//}

//func compact(store *Storage) storagetesting.Compaction {
//	return func(ctx context.Context, t *testing.T, resourceVersion string) {
//		// tests expect that the resource version is incremented after compaction:
//		// https://github.com/kubernetes/apiserver/blob/4f7f407e71725f4056328bbeb6d6139843716ca6/pkg/storage/etcd3/compact.go#L137
//		_ = store.getNewResourceVersion()
//	}
//}

//func TestGetListNonRecursive(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestGetListNonRecursive(ctx, t, compact(store.(*Storage)), store)
//}

//func checkStorageCalls(t *testing.T, pageSize, estimatedProcessedObjects uint64) {
//	if reads := getReadsAndReset(); reads != estimatedProcessedObjects {
//		t.Errorf("unexpected reads: %d, expected: %d", reads, estimatedProcessedObjects)
//	}
//	estimatedGetCalls := uint64(1)
//	if pageSize != 0 {
//		// We expect that kube-apiserver will be increasing page sizes
//		// if not full pages are received, so we should see significantly less
//		// than 1000 pages (which would be result of talking to etcd with page size
//		// copied from pred.Limit).
//		// The expected number of calls is n+1 where n is the smallest n so that:
//		// pageSize + pageSize * 2 + pageSize * 4 + ... + pageSize * 2^n >= podCount.
//		// For pageSize = 1, podCount = 1000, we get n+1 = 10, 2 ^ 10 = 1024.
//		currLimit := pageSize
//		for sum := uint64(1); sum < estimatedProcessedObjects; {
//			currLimit *= 2
//			if currLimit > 10000 {
//				currLimit = 10000
//			}
//			sum += currLimit
//			estimatedGetCalls++
//		}
//	}
//	if reads := getReadsAndReset(); reads != estimatedGetCalls {
//		t.Errorf("unexpected reads: %d, expected: %d", reads, estimatedProcessedObjects)
//	}
//}

//func TestListContinuation(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestListContinuation(ctx, t, store, checkStorageCalls)
//}
//
//func TestListPaginationRareObject(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestListPaginationRareObject(ctx, t, store, checkStorageCalls)
//}
//
//func TestListContinuationWithFilter(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestListContinuationWithFilter(ctx, t, store, checkStorageCalls)
//}
//
//func TestListInconsistentContinuation(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestListInconsistentContinuation(ctx, t, store, compact(store.(*Storage)))
//}
//
//func TestConsistentList(t *testing.T) {
//	// TODO(#109831): Enable use of this test and run it.
//}
//
//func TestGuaranteedUpdate(t *testing.T) {
//	// ctx, store, destroyFunc, err := testSetup(t)
//	// defer destroyFunc()
//	// assert.NoError(t, err)
//	// storagetesting.RunTestGuaranteedUpdate(ctx, t, store, nil)
//}
//
//func TestGuaranteedUpdateWithTTL(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestGuaranteedUpdateWithTTL(ctx, t, store)
//}
//
//func TestGuaranteedUpdateChecksStoredData(t *testing.T) {
//	// ctx, store, destroyFunc, err := testSetup(t)
//	// defer destroyFunc()
//	// assert.NoError(t, err)
//	// storagetesting.RunTestGuaranteedUpdateChecksStoredData(ctx, t, store)
//}
//
//func TestGuaranteedUpdateWithConflict(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestGuaranteedUpdateWithConflict(ctx, t, store)
//}
//
//func TestGuaranteedUpdateWithSuggestionAndConflict(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestGuaranteedUpdateWithSuggestionAndConflict(ctx, t, store)
//}

func TestTransformationFailure(t *testing.T) {
	// TODO(#109831): Enable use of this test and run it.
}

//func TestCount(t *testing.T) {
//	ctx, store, destroyFunc, err := testSetup(t)
//	defer destroyFunc()
//	assert.NoError(t, err)
//	storagetesting.RunTestCount(ctx, t, store)
//}
