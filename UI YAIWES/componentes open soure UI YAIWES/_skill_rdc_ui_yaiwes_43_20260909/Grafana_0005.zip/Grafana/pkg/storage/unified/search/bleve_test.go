package search

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/blevesearch/bleve/v2"
	blevesearch "github.com/blevesearch/bleve/v2/search"
	"github.com/blevesearch/bleve/v2/search/query"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	bolterrors "go.etcd.io/bbolt/errors"
	"go.uber.org/goleak"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/selection"

	authlib "github.com/grafana/authlib/types"

	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/apimachinery/utils"
	"github.com/grafana/grafana/pkg/infra/log"
	authzextv1 "github.com/grafana/grafana/pkg/services/authz/proto/v1"
	foldermodel "github.com/grafana/grafana/pkg/services/folder"
	"github.com/grafana/grafana/pkg/services/user"
	"github.com/grafana/grafana/pkg/storage/unified/resource"
	"github.com/grafana/grafana/pkg/storage/unified/resourcepb"
	"github.com/grafana/grafana/pkg/storage/unified/search/builders"
)

// This verifies that we close all indexes properly and shutdown all background goroutines from our tests.
// (Except for goroutines running specific functions. If possible we should fix this, esp. our own updateIndexSizeMetric.)
func TestMain(m *testing.M) {
	goleak.VerifyTestMain(m,
		goleak.IgnoreTopFunction("github.com/open-feature/go-sdk/openfeature.(*eventExecutor).startEventListener.func1.1"),
		goleak.IgnoreTopFunction("github.com/blevesearch/bleve_index_api.AnalysisWorker"), // These don't stop when index is closed.
		goleak.IgnoreAnyFunction("net/http.(*http2clientConnReadLoop).run"),               // HTTP/2 keep-alive from cloud provider SDKs in integration tests.
	)
}

func TestBleveBackend(t *testing.T) {
	tmpdir, err := os.MkdirTemp("", "grafana-bleve-test")
	require.NoError(t, err)

	// Register the dashboard provider so the static fields.* mapping is built
	// from declared fields, as in production; without it custom fields drop.
	backend, err := NewBleveBackend(BleveOptions{
		Root:          tmpdir,
		FileThreshold: 5, // with more than 5 items we create a file on disk
		SearchFields: resource.NewSearchFieldsRegistry(nil, nil, map[resource.LowerGroupResource]resource.SearchFieldsProvider{
			resource.NewLowerGroupResource("dashboard.grafana.app", "dashboards"): DashboardSearchFieldsProviderForTest(),
		}),
	}, nil)
	require.NoError(t, err)
	t.Cleanup(backend.Stop)

	testBleveBackend(t, backend)
}

func TestBleveSearchRootFolderExpansion(t *testing.T) {
	tmpdir, err := os.MkdirTemp("", "grafana-bleve-test")
	require.NoError(t, err)

	// Register the dashboard provider so the index is built from declared
	// fields, as in production.
	backend, err := NewBleveBackend(BleveOptions{
		Root:          tmpdir,
		FileThreshold: 5,
		SearchFields: resource.NewSearchFieldsRegistry(nil, nil, map[resource.LowerGroupResource]resource.SearchFieldsProvider{
			resource.NewLowerGroupResource("dashboard.grafana.app", "dashboards"): DashboardSearchFieldsProviderForTest(),
		}),
	}, nil)
	require.NoError(t, err)
	t.Cleanup(backend.Stop)

	key := &resourcepb.ResourceKey{
		Namespace: "default",
		Group:     "dashboard.grafana.app",
		Resource:  "dashboards",
	}
	ctx := identity.WithRequester(context.Background(), &user.SignedInUser{Namespace: "ns"})

	// Index three dashboards: one at the root using the legacy empty sentinel,
	// one at the root using the canonical "general" sentinel, and one nested.
	doc := func(name, folder string) *resource.BulkIndexItem {
		return &resource.BulkIndexItem{
			Action: resource.ActionIndex,
			Doc: &resource.IndexableDocument{
				RV:     1,
				Name:   name,
				Key:    &resourcepb.ResourceKey{Name: name, Namespace: "ns", Group: key.Group, Resource: key.Resource},
				Title:  name,
				Folder: folder,
				Fields: map[string]any{},
			},
		}
	}
	index, err := backend.BuildIndex(ctx, resource.NamespacedResource{
		Namespace: key.Namespace,
		Group:     key.Group,
		Resource:  key.Resource,
	}, 3, "test", func(index resource.ResourceIndex) (int64, error) {
		if err := index.BulkIndex(&resource.BulkIndexRequest{
			Items: []*resource.BulkIndexItem{
				doc("legacy-root", ""),
				doc("general-root", foldermodel.GeneralFolderUID),
				doc("nested", "other"),
			},
		}); err != nil {
			return 0, err
		}
		return 1, nil
	}, nil, false, time.Time{}, 0)
	require.NoError(t, err)

	searchFolder := func(operator string, values ...string) []string {
		rsp, err := index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_FOLDER,
					Operator: operator,
					Values:   values,
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Nil(t, rsp.Error)
		names := make([]string, 0, len(rsp.Results.Rows))
		for _, row := range rsp.Results.Rows {
			names = append(names, row.Key.Name)
		}
		return names
	}

	t.Run("querying the canonical root matches both root sentinels", func(t *testing.T) {
		names := searchFolder(string(selection.Equals), foldermodel.GeneralFolderUID)
		require.ElementsMatch(t, []string{"legacy-root", "general-root"}, names)
	})

	t.Run("querying the legacy root matches both root sentinels", func(t *testing.T) {
		names := searchFolder(string(selection.Equals), "")
		require.ElementsMatch(t, []string{"legacy-root", "general-root"}, names)
	})

	t.Run("a non-root folder is not expanded", func(t *testing.T) {
		names := searchFolder(string(selection.Equals), "other")
		require.ElementsMatch(t, []string{"nested"}, names)
	})

	t.Run("root is expanded inside an in-list alongside other folders", func(t *testing.T) {
		names := searchFolder(string(selection.In), "other", foldermodel.GeneralFolderUID)
		require.ElementsMatch(t, []string{"legacy-root", "general-root", "nested"}, names)
	})
}

func testBleveBackend(t *testing.T, backend *bleveBackend) {
	dashboardskey := &resourcepb.ResourceKey{
		Namespace: "default",
		Group:     "dashboard.grafana.app",
		Resource:  "dashboards",
	}
	folderKey := &resourcepb.ResourceKey{
		Namespace: dashboardskey.Namespace,
		Group:     "folder.grafana.app",
		Resource:  "folders",
	}

	rv := int64(10)
	ctx := identity.WithRequester(context.Background(), &user.SignedInUser{Namespace: "ns"})
	var dashboardsIndex resource.ResourceIndex
	var foldersIndex resource.ResourceIndex

	t.Run("build dashboards", func(t *testing.T) {
		key := dashboardskey

		index, err := backend.BuildIndex(ctx, resource.NamespacedResource{
			Namespace: key.Namespace,
			Group:     key.Group,
			Resource:  key.Resource,
		}, 2, "test", func(index resource.ResourceIndex) (int64, error) {
			err := index.BulkIndex(&resource.BulkIndexRequest{
				Items: []*resource.BulkIndexItem{
					{
						Action: resource.ActionIndex,
						Doc: &resource.IndexableDocument{
							RV:   1,
							Name: "aaa",
							Key: &resourcepb.ResourceKey{
								Name:      "aaa",
								Namespace: "ns",
								Group:     "dashboard.grafana.app",
								Resource:  "dashboards",
							},
							Title:  "aaa (dash)",
							Folder: "xxx",
							Fields: map[string]any{
								builders.DASHBOARD_PANEL_TYPES:       []string{"timeseries", "table"},
								builders.DASHBOARD_ERRORS_TODAY:      25,
								builders.DASHBOARD_VIEWS_LAST_1_DAYS: 50,
							},
							Labels: map[string]string{
								utils.LabelKeyDeprecatedInternalID: "10", // nolint:staticcheck
							},
							Tags:            []string{"aa", "bb"},
							OwnerReferences: []string{"iam.grafana.app/Team/engineering"},
							Manager: &utils.ManagerProperties{
								Kind:     utils.ManagerKindRepo,
								Identity: "repo-1",
							},
							Source: &utils.SourceProperties{
								Path:            "path/to/aaa.json",
								Checksum:        "xyz",
								TimestampMillis: 1609462800000, // 2021
							},
						},
					},
					{
						Action: resource.ActionIndex,
						Doc: &resource.IndexableDocument{
							RV:   2,
							Name: "bbb",
							Key: &resourcepb.ResourceKey{
								Name:      "bbb",
								Namespace: "ns",
								Group:     "dashboard.grafana.app",
								Resource:  "dashboards",
							},
							Title:  "bbb (dash)",
							Folder: "xxx",
							Fields: map[string]any{
								builders.DASHBOARD_PANEL_TYPES:       []string{"timeseries"},
								builders.DASHBOARD_ERRORS_TODAY:      40,
								builders.DASHBOARD_VIEWS_LAST_1_DAYS: 100,
							},
							Tags: []string{"aa"},
							Labels: map[string]string{
								"region":                           "east",
								utils.LabelKeyDeprecatedInternalID: "11", // nolint:staticcheck
							},
							OwnerReferences: []string{"iam.grafana.app/Team/marketing", "iam.grafana.app/User/admin"},
							Manager: &utils.ManagerProperties{
								Kind:     utils.ManagerKindRepo,
								Identity: "repo-1",
							},
							Source: &utils.SourceProperties{
								Path:            "path/to/bbb.json",
								Checksum:        "hijk",
								TimestampMillis: 1640998800000, // 2022
							},
						},
					},
					{
						Action: resource.ActionIndex,
						Doc: &resource.IndexableDocument{
							RV: 3,
							Key: &resourcepb.ResourceKey{
								Name:      "ccc",
								Namespace: "ns",
								Group:     "dashboard.grafana.app",
								Resource:  "dashboards",
							},
							Name:   "ccc",
							Title:  "ccc (dash)",
							Folder: "zzz",
							Manager: &utils.ManagerProperties{
								Kind:     utils.ManagerKindRepo,
								Identity: "repo2",
							},
							Source: &utils.SourceProperties{
								Path: "path/in/repo2.yaml",
							},
							Fields: map[string]any{},
							Tags:   []string{"aa"},
							Labels: map[string]string{
								"region": "west",
							},
						},
					},
				},
			})
			if err != nil {
				return 0, err
			}
			return rv, nil
		}, nil, false, time.Time{}, 0)
		require.NoError(t, err)
		require.NotNil(t, index)
		dashboardsIndex = index

		rsp, err := index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
			},
			Limit: 100000,
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: resource.SEARCH_FIELD_TITLE, Desc: true}, // ccc,bbb,aaa
			},
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tags": {
					Field: "tags",
					Limit: 100,
				},
			},
		}, nil, nil)
		require.NoError(t, err)
		require.Nil(t, rsp.Error)
		require.NotNil(t, rsp.Results)
		require.NotNil(t, rsp.Facet)

		resource.AssertTableSnapshot(t, filepath.Join("testdata", "manual-dashboard.json"), rsp.Results)

		// Get the tags facets
		facet, ok := rsp.Facet["tags"]
		require.True(t, ok)
		disp, err := json.MarshalIndent(facet, "", "  ")
		require.NoError(t, err)
		//fmt.Printf("%s\n", disp)
		require.JSONEq(t, `{
			"field": "tags",
			"total": 4,
			"terms": [
				{
					"term": "aa",
					"count": 3
				},
				{
					"term": "bb",
					"count": 1
				}
			]
		}`, string(disp))

		count, _ := index.DocCount(ctx, "", nil)
		assert.Equal(t, int64(3), count)

		count, _ = index.DocCount(ctx, "zzz", nil)
		assert.Equal(t, int64(1), count)

		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Labels: []*resourcepb.Requirement{{
					Key:      utils.LabelKeyDeprecatedInternalID, // nolint:staticcheck
					Operator: "in",
					Values:   []string{"10", "11"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(2), rsp.TotalHits)
		require.Equal(t, []string{"aaa", "bbb"}, []string{
			rsp.Results.Rows[0].Key.Name,
			rsp.Results.Rows[1].Key.Name,
		})

		// search by owner reference
		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_OWNER_REFERENCES,
					Operator: "=",
					Values:   []string{"iam.grafana.app/Team/engineering"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(1), rsp.TotalHits)
		require.Equal(t, "aaa", rsp.Results.Rows[0].Key.Name)

		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_OWNER_REFERENCES,
					Operator: "=",
					Values:   []string{"iam.grafana.app/Team/marketing"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(1), rsp.TotalHits)
		require.Equal(t, "bbb", rsp.Results.Rows[0].Key.Name)

		// search by owner reference - multiple values with Equals (AND)
		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_OWNER_REFERENCES,
					Operator: "=",
					Values:   []string{"iam.grafana.app/Team/marketing", "iam.grafana.app/User/admin"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(1), rsp.TotalHits)
		require.Equal(t, "bbb", rsp.Results.Rows[0].Key.Name)

		// search by owner reference - multiple values (OR)
		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_OWNER_REFERENCES,
					Operator: "in",
					Values:   []string{"iam.grafana.app/Team/engineering", "iam.grafana.app/User/admin"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(2), rsp.TotalHits)
		names := []string{rsp.Results.Rows[0].Key.Name, rsp.Results.Rows[1].Key.Name}
		assert.Contains(t, names, "aaa")
		assert.Contains(t, names, "bbb")

		// can get sprinkles fields and sort by them
		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
			},
			Limit:  100000,
			Fields: []string{builders.DASHBOARD_ERRORS_TODAY, builders.DASHBOARD_VIEWS_LAST_1_DAYS, "fieldThatDoesntExist"},
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "fields." + builders.DASHBOARD_VIEWS_LAST_1_DAYS, Desc: true},
			},
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, 2, len(rsp.Results.Columns))
		require.Equal(t, builders.DASHBOARD_ERRORS_TODAY, rsp.Results.Columns[0].Name)
		require.Equal(t, builders.DASHBOARD_VIEWS_LAST_1_DAYS, rsp.Results.Columns[1].Name)
		// sorted descending so should start with highest dashboard_views_last_1_days (100)
		val, err := resource.DecodeCell(rsp.Results.Columns[1], 0, rsp.Results.Rows[0].Cells[1])
		require.NoError(t, err)
		require.Equal(t, int64(100), val)

		// check auth will exclude results we don't have access to
		rsp, err = index.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": false}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
			},
			Limit:  100000,
			Fields: []string{builders.DASHBOARD_ERRORS_TODAY, builders.DASHBOARD_VIEWS_LAST_1_DAYS, "fieldThatDoesntExist"},
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "fields." + builders.DASHBOARD_VIEWS_LAST_1_DAYS, Desc: true},
			},
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, 0, len(rsp.Results.Rows))

		// Now look for repositories
		found, err := index.ListManagedObjects(ctx, &resourcepb.ListManagedObjectsRequest{
			Kind: "repo",
			Id:   "repo-1",
		}, nil)
		require.NoError(t, err)
		jj, err := json.MarshalIndent(found, "", "  ")
		require.NoError(t, err)
		fmt.Printf("%s\n", string(jj))
		// NOTE "hash" -> "checksum" requires changing the protobuf
		require.JSONEq(t, `{
			"items": [
				{
					"object": {
						"namespace": "ns",
						"group": "dashboard.grafana.app",
						"resource": "dashboards",
						"name": "aaa"
					},
					"path": "path/to/aaa.json",
					"hash": "xyz",
					"time": 1609462800000,
					"title": "aaa (dash)",
					"folder": "xxx"
				},
				{
					"object": {
						"namespace": "ns",
						"group": "dashboard.grafana.app",
						"resource": "dashboards",
						"name": "bbb"
					},
					"path": "path/to/bbb.json",
					"hash": "hijk",
					"time": 1640998800000,
					"title": "bbb (dash)",
					"folder": "xxx"
				}
			]
		}`, string(jj))

		counts, err := index.CountManagedObjects(ctx, nil)
		require.NoError(t, err)
		jj, err = json.MarshalIndent(counts, "", "  ")
		require.NoError(t, err)
		fmt.Printf("%s\n", string(jj))
		require.JSONEq(t, `[
			{
				"kind": "repo",
				"id": "repo-1",
				"group": "dashboard.grafana.app",
				"resource": "dashboards",
				"count": 2
			},
			{
				"kind": "repo",
				"id": "repo2",
				"group": "dashboard.grafana.app",
				"resource": "dashboards",
				"count": 1
			}
		]`, string(jj))
	})

	t.Run("build folders", func(t *testing.T) {
		key := folderKey

		index, err := backend.BuildIndex(ctx, resource.NamespacedResource{
			Namespace: key.Namespace,
			Group:     key.Group,
			Resource:  key.Resource,
		}, 2, "test", func(index resource.ResourceIndex) (int64, error) {
			err := index.BulkIndex(&resource.BulkIndexRequest{
				Items: []*resource.BulkIndexItem{
					{
						Action: resource.ActionIndex,
						Doc: &resource.IndexableDocument{
							RV:   1,
							Name: "zzz",
							Key: &resourcepb.ResourceKey{
								Name:      "zzz",
								Namespace: "ns",
								Group:     "folder.grafana.app",
								Resource:  "folders",
							},
							Title: "zzz (folder)",
							Manager: &utils.ManagerProperties{
								Kind:     utils.ManagerKindRepo,
								Identity: "repo-1",
							},
							Source: &utils.SourceProperties{
								Path:            "path/to/folder.json",
								Checksum:        "xxxx",
								TimestampMillis: 300,
							},
							Labels: map[string]string{
								utils.LabelKeyDeprecatedInternalID: "123",
							},
						},
					},
					{
						Action: resource.ActionIndex,
						Doc: &resource.IndexableDocument{
							RV:   2,
							Name: "yyy",
							Key: &resourcepb.ResourceKey{
								Name:      "yyy",
								Namespace: "ns",
								Group:     "folder.grafana.app",
								Resource:  "folders",
							},
							Title: "yyy (folder)",
							Labels: map[string]string{
								"region":                           "west",
								utils.LabelKeyDeprecatedInternalID: "321",
							},
						},
					},
				},
			})
			if err != nil {
				return 0, err
			}
			return rv, nil
		}, nil, false, time.Time{}, 0)
		require.NoError(t, err)
		require.NotNil(t, index)
		foldersIndex = index

		rsp, err := index.Search(ctx, NewStubAccessClient(map[string]bool{"folders": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Nil(t, rsp.Error)
		require.NotNil(t, rsp.Results)
		require.Nil(t, rsp.Facet)

		resource.AssertTableSnapshot(t, filepath.Join("testdata", "manual-folder.json"), rsp.Results)
	})

	t.Run("folder NotIn field filter excludes matching names", func(t *testing.T) {
		require.NotNil(t, foldersIndex)
		key := folderKey

		// NotIn should exclude the named folder from results
		rsp, err := foldersIndex.Search(ctx, NewStubAccessClient(map[string]bool{"folders": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{{
					Key:      resource.SEARCH_FIELD_NAME,
					Operator: string(selection.NotIn),
					Values:   []string{"zzz"},
				}},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(1), rsp.TotalHits)
		require.Equal(t, "yyy", rsp.Results.Rows[0].Key.Name)
	})

	t.Run("folder In and NotIn on same field compose correctly", func(t *testing.T) {
		require.NotNil(t, foldersIndex)
		key := folderKey

		// In selects both folders, NotIn excludes one — should return only the non-excluded one.
		// This is the exact query pattern used by GetChildren to exclude the k6 folder
		// while also filtering by allowed folder UIDs.
		rsp, err := foldersIndex.Search(ctx, NewStubAccessClient(map[string]bool{"folders": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: key,
				Fields: []*resourcepb.Requirement{
					{
						Key:      resource.SEARCH_FIELD_NAME,
						Operator: string(selection.In),
						Values:   []string{"zzz", "yyy"},
					},
					{
						Key:      resource.SEARCH_FIELD_NAME,
						Operator: string(selection.NotIn),
						Values:   []string{"zzz"},
					},
				},
			},
			Limit: 100000,
		}, nil, nil)
		require.NoError(t, err)
		require.Equal(t, int64(1), rsp.TotalHits)
		require.Equal(t, "yyy", rsp.Results.Rows[0].Key.Name)
	})

	t.Run("simple federation", func(t *testing.T) {
		// The other tests must run first to build the indexes
		require.NotNil(t, dashboardsIndex)
		require.NotNil(t, foldersIndex)

		// Use a federated query to get both results together, sorted by title
		rsp, err := dashboardsIndex.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true, "folders": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: dashboardskey,
			},
			Fields: []string{
				"title", "_id",
			},
			Federated: []*resourcepb.ResourceKey{
				folderKey, // This will join in the
			},
			Limit: 100000,
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "title", Desc: false},
			},
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tags": {
					Field: resource.SEARCH_FIELD_TAGS,
					Limit: 100,
				},
			},
		}, []resource.ResourceIndex{foldersIndex}, nil) // << note the folder index matches the federation request
		require.NoError(t, err)
		require.Nil(t, rsp.Error)
		require.NotNil(t, rsp.Results)
		require.NotNil(t, rsp.Facet)

		// Sorted across two indexes
		sorted := make([]string, 0, len(rsp.Results.Rows))
		for _, row := range rsp.Results.Rows {
			sorted = append(sorted, string(row.Cells[0]))
		}
		require.Equal(t, []string{
			"aaa (dash)",
			"bbb (dash)",
			"ccc (dash)",
			"yyy (folder)",
			"zzz (folder)",
		}, sorted)

		resource.AssertTableSnapshot(t, filepath.Join("testdata", "manual-federated.json"), rsp.Results)

		facet, ok := rsp.Facet["tags"]
		require.True(t, ok)
		disp, err := json.MarshalIndent(facet, "", "  ")
		require.NoError(t, err)
		require.JSONEq(t, `{
			"field": "tags",
			"total": 4,
			"missing": 2,
			"terms": [
				{
					"term": "aa",
					"count": 3
				},
				{
					"term": "bb",
					"count": 1
				}
			]
		}`, string(disp))

		// now only when we have permissions to see dashboards
		rsp, err = dashboardsIndex.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": true, "folders": false}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: dashboardskey,
			},
			Fields: []string{
				"title", "_id",
			},
			Federated: []*resourcepb.ResourceKey{
				folderKey, // This will join in the
			},
			Limit: 100000,
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "title", Desc: false},
			},
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tags": {
					Field: resource.SEARCH_FIELD_TAGS,
					Limit: 100,
				},
			},
		}, []resource.ResourceIndex{foldersIndex}, nil) // << note the folder index matches the federation request

		require.NoError(t, err)
		require.Equal(t, 3, len(rsp.Results.Rows))
		require.Equal(t, "dashboards", rsp.Results.Rows[0].Key.Resource)
		require.Equal(t, "dashboards", rsp.Results.Rows[1].Key.Resource)
		require.Equal(t, "dashboards", rsp.Results.Rows[2].Key.Resource)

		// now only when we have permissions to see folders
		rsp, err = dashboardsIndex.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": false, "folders": true}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: dashboardskey,
			},
			Fields: []string{
				"title", "_id",
			},
			Federated: []*resourcepb.ResourceKey{
				folderKey, // This will join in the
			},
			Limit: 100000,
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "title", Desc: false},
			},
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tags": {
					Field: resource.SEARCH_FIELD_TAGS,
					Limit: 100,
				},
			},
		}, []resource.ResourceIndex{foldersIndex}, nil) // << note the folder index matches the federation request

		require.NoError(t, err)
		require.Equal(t, 2, len(rsp.Results.Rows))
		require.Equal(t, "folders", rsp.Results.Rows[0].Key.Resource)
		require.Equal(t, "folders", rsp.Results.Rows[1].Key.Resource)

		// now when we have permissions to see nothing
		rsp, err = dashboardsIndex.Search(ctx, NewStubAccessClient(map[string]bool{"dashboards": false, "folders": false}), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{
				Key: dashboardskey,
			},
			Fields: []string{
				"title", "_id",
			},
			Federated: []*resourcepb.ResourceKey{
				folderKey, // This will join in the
			},
			Limit: 100000,
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "title", Desc: false},
			},
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tags": {
					Field: resource.SEARCH_FIELD_TAGS,
					Limit: 100,
				},
			},
		}, []resource.ResourceIndex{foldersIndex}, nil) // << note the folder index matches the federation request

		require.NoError(t, err)
		require.Equal(t, 0, len(rsp.Results.Rows))
	})
}

func TestGetSortFields(t *testing.T) {
	dashboardFields, err := resource.SearchableFieldsFromProvider(DashboardSearchFieldsProviderForTest(), "dashboard.grafana.app", "dashboards")
	require.NoError(t, err)
	idx := &bleveIndex{
		fields:       dashboardFields,
		searchFields: newKindSearchFields(DashboardSearchFieldsProviderForTest(), "dashboard.grafana.app", "dashboards", nil),
	}

	t.Run("will prepend 'fields.' to sort fields when they are dashboard fields", func(t *testing.T) {
		searchReq := &resourcepb.ResourceSearchRequest{
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "views_total", Desc: false},
			},
		}
		sortFields := idx.getSortFields(searchReq)
		assert.Equal(t, []string{"fields.views_total", resource.SEARCH_FIELD_NAME}, sortFields)
	})
	t.Run("will prepend sort fields with a '-' when sort is Desc", func(t *testing.T) {
		searchReq := &resourcepb.ResourceSearchRequest{
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "views_total", Desc: true},
			},
		}
		sortFields := idx.getSortFields(searchReq)
		assert.Equal(t, []string{"-fields.views_total", resource.SEARCH_FIELD_NAME}, sortFields)
	})
	t.Run("will not prepend 'fields.' to common fields", func(t *testing.T) {
		searchReq := &resourcepb.ResourceSearchRequest{
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: "description", Desc: false},
			},
		}
		sortFields := idx.getSortFields(searchReq)
		assert.Equal(t, []string{"description", resource.SEARCH_FIELD_NAME}, sortFields)
	})
	t.Run("will use title_phrase for title and append name as tie-breaker", func(t *testing.T) {
		searchReq := &resourcepb.ResourceSearchRequest{
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: resource.SEARCH_FIELD_TITLE, Desc: false},
			},
		}
		sortFields := idx.getSortFields(searchReq)
		assert.Equal(t, []string{resource.SEARCH_FIELD_TITLE_PHRASE, resource.SEARCH_FIELD_NAME}, sortFields)
	})
	t.Run("will not append a duplicate name sort", func(t *testing.T) {
		searchReq := &resourcepb.ResourceSearchRequest{
			SortBy: []*resourcepb.ResourceSearchRequest_Sort{
				{Field: resource.SEARCH_FIELD_NAME, Desc: true},
			},
		}
		sortFields := idx.getSortFields(searchReq)
		assert.Equal(t, []string{"-" + resource.SEARCH_FIELD_NAME}, sortFields)
	})
}

func TestBleveSearchRequestDefaultSortIncludesNameTieBreaker(t *testing.T) {
	idx := &bleveIndex{
		fields:       resource.StandardSearchFields(),
		searchFields: newKindSearchFields(nil, "", "", nil),
	}

	t.Run("sorts match-all by title then name", func(t *testing.T) {
		searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			Limit:   10,
		}, nil, false, nil)
		require.Nil(t, errResult)
		require.Len(t, searchReq.Sort, 2)

		titleSort, ok := searchReq.Sort[0].(*blevesearch.SortField)
		require.True(t, ok)
		assert.Equal(t, resource.SEARCH_FIELD_TITLE_PHRASE, titleSort.Field)
		assert.False(t, titleSort.Desc)

		nameSort, ok := searchReq.Sort[1].(*blevesearch.SortField)
		require.True(t, ok)
		assert.Equal(t, resource.SEARCH_FIELD_NAME, nameSort.Field)
		assert.False(t, nameSort.Desc)
	})

	t.Run("sorts queries by score then name", func(t *testing.T) {
		searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			Limit:   10,
			Query:   "grafana",
		}, nil, false, nil)
		require.Nil(t, errResult)
		require.Len(t, searchReq.Sort, 2)
		_, ok := searchReq.Sort[0].(*blevesearch.SortScore)
		require.True(t, ok)

		nameSort, ok := searchReq.Sort[1].(*blevesearch.SortField)
		require.True(t, ok)
		assert.Equal(t, resource.SEARCH_FIELD_NAME, nameSort.Field)
		assert.False(t, nameSort.Desc)
	})

	t.Run("uses declared keyword facet fields", func(t *testing.T) {
		searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			Limit:   10,
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"tagValues": {Field: resource.SEARCH_FIELD_TAGS, Limit: 10},
			},
		}, nil, false, nil)
		require.Nil(t, errResult)
		require.Contains(t, searchReq.Facets, "tagValues")
		assert.Equal(t, resource.SEARCH_FIELD_TAGS, searchReq.Facets["tagValues"].Field)
	})

	t.Run("rejects fields without facet capability", func(t *testing.T) {
		searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			Limit:   10,
			Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
				"region": {Field: "labels.region", Limit: 10},
			},
		}, nil, false, nil)
		require.Nil(t, searchReq)
		require.NotNil(t, errResult)
		assert.Contains(t, errResult.Message, `field "labels.region" does not support faceting`)
	})

	// Both the bleve term trimmer and the post-rank aggregator use the limit as
	// a slice bound, so a negative one has to be turned away before either runs.
	t.Run("rejects a negative facet limit", func(t *testing.T) {
		for _, postRankAuthz := range []bool{false, true} {
			searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
				Options: &resourcepb.ListOptions{},
				Limit:   10,
				Facet: map[string]*resourcepb.ResourceSearchRequest_Facet{
					"tagValues": {Field: resource.SEARCH_FIELD_TAGS, Limit: -1},
				},
			}, nil, postRankAuthz, nil)
			require.Nil(t, searchReq)
			require.NotNil(t, errResult)
			assert.Contains(t, errResult.Message, `facet "tagValues" has a negative limit`)
		}
	})
}

func TestBleveTrashSearchFailsWhenDeletedDocumentsAreNotIndexed(t *testing.T) {
	tests := []struct {
		name                  string
		wantsDeletedDocuments bool
		message               string
	}{
		{
			name:    "indexing is disabled",
			message: "trash is not available for this resource because indexing deleted documents is disabled",
		},
		{
			name:                  "index is awaiting rebuild",
			wantsDeletedDocuments: true,
			message:               "trash is not available for this resource until its search index has been rebuilt",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			idx := &bleveIndex{
				fields:                resource.StandardSearchFields(),
				searchFields:          newKindSearchFields(nil, "", "", nil),
				wantsDeletedDocuments: tc.wantsDeletedDocuments,
			}
			searchReq, errResult := idx.toBleveSearchRequest(t.Context(), &resourcepb.ResourceSearchRequest{
				Options:   &resourcepb.ListOptions{},
				Limit:     10,
				IsDeleted: true,
			}, nil, false, nil)

			require.Nil(t, searchReq)
			require.NotNil(t, errResult)
			assert.Equal(t, int32(http.StatusServiceUnavailable), errResult.Code)
			assert.Equal(t, tc.message, errResult.Message)
		})
	}
}

// TestBleveSortCapabilityCheck covers both the counting and the rejecting mode.
func TestBleveSortCapabilityCheck(t *testing.T) {
	const group, kindResource = "example.grafana.app", "widgets"
	// v1 and v2 declare different fields on purpose: a request naming no version
	// is validated against the union.
	provider := resource.NewMapProvider(map[schema.GroupVersionResource][]resource.SearchFieldDefinition{
		{Group: group, Version: "v1", Resource: kindResource}: {
			{
				Name:         "note",
				Type:         resource.SearchFieldTypeString,
				Capabilities: []resource.SearchCapability{resource.SearchCapabilityFilter, resource.SearchCapabilitySort},
			},
			{
				Name:         "category",
				Type:         resource.SearchFieldTypeString,
				Capabilities: []resource.SearchCapability{resource.SearchCapabilityFilter, resource.SearchCapabilityRetrieve},
			},
		},
		{Group: group, Version: "v2", Resource: kindResource}: {
			{
				Name:         "weight",
				Type:         resource.SearchFieldTypeInt64,
				Capabilities: []resource.SearchCapability{resource.SearchCapabilitySort, resource.SearchCapabilityRetrieve},
			},
		},
	}, map[schema.GroupResource]string{{Group: group, Resource: kindResource}: "v1"})

	newIndex := func(enforce bool) *bleveIndex {
		return &bleveIndex{
			key:                   resource.NamespacedResource{Namespace: "ns", Group: group, Resource: kindResource},
			fields:                resource.StandardSearchFields(),
			searchFields:          newKindSearchFields(provider, group, kindResource, []string{"spec.slug"}),
			enforceSortCapability: enforce,
			logger:                log.NewNopLogger(),
		}
	}

	sortBy := func(field string) *resourcepb.ResourceSearchRequest {
		return &resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			Limit:   10,
			SortBy:  []*resourcepb.ResourceSearchRequest_Sort{{Field: field}},
		}
	}

	accepted := []struct {
		name  string
		field string
	}{
		{"standard sortable field", resource.SEARCH_FIELD_TITLE},
		{"physical title variant", resource.SEARCH_FIELD_TITLE_PHRASE},
		{"name", resource.SEARCH_FIELD_NAME},
		{"folder", resource.SEARCH_FIELD_FOLDER},
		{"per-kind field, bare name", "note"},
		{"per-kind field, prefixed name", resource.SEARCH_FIELD_PREFIX + "note"},
		// Declared by v2 only.
		{"field declared by another version", resource.SEARCH_FIELD_PREFIX + "weight"},
	}
	for _, tc := range accepted {
		t.Run("accepts "+tc.name, func(t *testing.T) {
			searchReq, errResult := newIndex(true).toBleveSearchRequest(t.Context(), sortBy(tc.field), nil, false, nil)
			require.Nil(t, errResult)
			require.NotNil(t, searchReq)
		})
	}

	rejected := []struct {
		name  string
		field string
	}{
		{"standard retrieve-only field", resource.SEARCH_FIELD_CREATED},
		{"per-kind field without sort", "category"},
		{"per-kind field without sort, prefixed", resource.SEARCH_FIELD_PREFIX + "category"},
		{"undeclared field", "nonexistent"},
		{"label", "labels.region"},
		// A standard field lives top-level, so nothing is indexed under this path.
		{"standard field under the per-kind prefix", resource.SEARCH_FIELD_PREFIX + resource.SEARCH_FIELD_TITLE},
		// Selectable fields exist to be filtered on; nothing sorts on them.
		{"selectable field", resource.SEARCH_SELECTABLE_FIELDS_PREFIX + "spec.slug"},
	}
	for _, tc := range rejected {
		t.Run("rejects "+tc.name, func(t *testing.T) {
			searchReq, errResult := newIndex(true).toBleveSearchRequest(t.Context(), sortBy(tc.field), nil, false, nil)
			require.Nil(t, searchReq)
			require.NotNil(t, errResult)
			assert.Contains(t, errResult.Message, fmt.Sprintf("field %q does not support sorting", tc.field))
		})

		t.Run("counts but allows "+tc.name+" with enforcement off", func(t *testing.T) {
			idx := newIndex(false)
			reg := prometheus.NewPedanticRegistry()
			idx.indexMetrics = resource.ProvideIndexMetrics(reg)

			searchReq, errResult := idx.toBleveSearchRequest(t.Context(), sortBy(tc.field), nil, false, nil)
			require.Nil(t, errResult)
			require.NotNil(t, searchReq)
			assert.Equal(t, 1, testutil.CollectAndCount(idx.indexMetrics.SearchCapabilityViolations, "index_server_search_capability_violations_total"))
		})
	}

	// Trash fields are refused on a live search, so they cannot go in the list above.
	t.Run("accepts a trash field when searching deleted resources", func(t *testing.T) {
		idx := newIndex(true)
		idx.keepsDeletedDocuments = true
		idx.wantsDeletedDocuments = true
		req := sortBy(resource.SEARCH_FIELD_DELETION_TIME)
		req.IsDeleted = true
		_, errResult := idx.toBleveSearchRequest(t.Context(), req, nil, false, nil)
		require.Nil(t, errResult)
	})

	t.Run("an index without declarations still allows standard sortable fields", func(t *testing.T) {
		idx := &bleveIndex{
			fields:                resource.StandardSearchFields(),
			enforceSortCapability: true,
			logger:                log.NewNopLogger(),
		}
		_, errResult := idx.toBleveSearchRequest(t.Context(), sortBy(resource.SEARCH_FIELD_TITLE), nil, false, nil)
		require.Nil(t, errResult)

		_, errResult = idx.toBleveSearchRequest(t.Context(), sortBy(resource.SEARCH_FIELD_CREATED), nil, false, nil)
		require.NotNil(t, errResult)
	})
}

var _ authlib.AccessClient = (*StubAccessClient)(nil)

func NewStubAccessClient(permissions map[string]bool) *StubAccessClient {
	return &StubAccessClient{resourceResponses: permissions}
}

type StubAccessClient struct {
	resourceResponses map[string]bool // key is the resource name, and bool if what the checker will return
}

func (nc *StubAccessClient) Check(ctx context.Context, id authlib.AuthInfo, req authlib.CheckRequest, folder string) (authlib.CheckResponse, error) {
	return authlib.CheckResponse{Allowed: nc.resourceResponses[req.Resource]}, nil
}

func (nc *StubAccessClient) Compile(ctx context.Context, id authlib.AuthInfo, req authlib.ListRequest) (authlib.ItemChecker, authlib.Zookie, error) {
	return func(name, folder string) bool {
		return nc.resourceResponses[req.Resource]
	}, authlib.NoopZookie{}, nil
}

func (nc *StubAccessClient) BatchCheck(ctx context.Context, id authlib.AuthInfo, req authlib.BatchCheckRequest) (authlib.BatchCheckResponse, error) {
	results := make(map[string]authlib.BatchCheckResult, len(req.Checks))
	for _, check := range req.Checks {
		results[check.CorrelationID] = authlib.BatchCheckResult{
			Allowed: nc.resourceResponses[check.Resource],
		}
	}
	return authlib.BatchCheckResponse{
		Results: results,
	}, nil
}

func (nc StubAccessClient) Read(ctx context.Context, req *authzextv1.ReadRequest) (*authzextv1.ReadResponse, error) {
	return nil, nil
}

func (nc StubAccessClient) Write(ctx context.Context, req *authzextv1.WriteRequest) error {
	return nil
}

func TestSafeInt64ToInt(t *testing.T) {
	tests := []struct {
		name    string
		input   int64
		want    int
		wantErr bool
	}{
		{
			name:  "Valid int64 within int range",
			input: 42,
			want:  42,
		},
		{
			name:    "Overflow int64 value",
			input:   math.MaxInt64,
			want:    0,
			wantErr: true,
		},
		{
			name:    "Underflow int64 value",
			input:   math.MinInt64,
			want:    0,
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := safeInt64ToInt(tt.input)
			if tt.wantErr {
				require.Error(t, err)
				return
			}
			require.Equal(t, tt.want, got)
		})
	}
}

func Test_isPathWithinRoot(t *testing.T) {
	tests := []struct {
		name string
		dir  string
		root string
		want bool
	}{
		{
			name: "valid path",
			dir:  "/path/to/my-file/",
			root: "/path/to/",
			want: true,
		},
		{
			name: "valid path without trailing slash",
			dir:  "/path/to/my-file",
			root: "/path/to",
			want: true,
		},
		{
			name: "path with double slashes",
			dir:  "/path//to//my-file/",
			root: "/path/to/",
			want: true,
		},
		{
			name: "invalid path: ..",
			dir:  "/path/../above/",
			root: "/path/to/",
		},
		{
			name: "invalid path: \\",
			dir:  "\\path/to",
			root: "/path/to/",
		},
		{
			name: "invalid path: not under safe dir",
			dir:  "/path/to.txt",
			root: "/path/to/",
		},
		{
			name: "invalid path: empty paths",
			dir:  "",
			root: "/path/to/",
		},
		{
			name: "invalid path: different path",
			dir:  "/other/path/to/my-file/",
			root: "/Some/other/path",
		},
		{
			name: "invalid path: empty safe path",
			dir:  "/path/to/",
			root: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			require.Equal(t, tt.want, isPathWithinRoot(tt.dir, tt.root))
		})
	}
}

const (
	buildVersion         = "12.3.45-789"
	defaultFileThreshold = 5
	defaultIndexCacheTTL = 1 * time.Minute
)

func setupBleveBackend(t *testing.T, options ...setupOption) (*bleveBackend, prometheus.Gatherer) {
	reg := prometheus.NewRegistry()
	metrics := resource.ProvideIndexMetrics(reg)

	opts := BleveOptions{
		FileThreshold: defaultFileThreshold,
		IndexCacheTTL: defaultIndexCacheTTL,
		Logger:        log.NewNopLogger(),
		BuildVersion:  buildVersion,
	}
	for _, opt := range options {
		opt(&opts)
	}
	if opts.Root == "" {
		opts.Root = t.TempDir()
	}

	backend, err := NewBleveBackend(opts, metrics)
	require.NoError(t, err)
	require.NotNil(t, backend)
	t.Cleanup(backend.Stop)
	return backend, reg
}

type setupOption func(options *BleveOptions)

func withIndexCacheTTL(ttl time.Duration) setupOption {
	return func(options *BleveOptions) {
		options.IndexCacheTTL = ttl
	}
}

func withFileThreshold(threshold int) setupOption {
	return func(options *BleveOptions) {
		options.FileThreshold = int64(threshold)
	}
}

func withRootDir(root string) setupOption {
	return func(options *BleveOptions) {
		options.Root = root
	}
}

func withOwnsIndexFn(fn func(key resource.NamespacedResource) (bool, error)) setupOption {
	return func(options *BleveOptions) {
		options.OwnsIndex = fn
	}
}

func withIndexMinUpdateInterval(d time.Duration) setupOption {
	return func(options *BleveOptions) {
		options.IndexMinUpdateInterval = d
	}
}

func withSearchFields(reg *resource.SearchFieldsRegistry) setupOption {
	return func(options *BleveOptions) {
		options.SearchFields = reg
	}
}

func withRequiredIndexFeatures(features ...resource.IndexFeature) setupOption {
	return func(options *BleveOptions) {
		options.RequiredIndexFeatures = features
	}
}

func withPostRankAuthzEnabled() setupOption {
	return func(options *BleveOptions) {
		options.PostRankAuthzEnabled = true
	}
}

// TestRequiredIndexFeaturesFollowPostRankAuthz covers the gate that keeps the
// stored facet mapping from rebuilding indexes that serve facets from bleve.
func TestRequiredIndexFeaturesFollowPostRankAuthz(t *testing.T) {
	nativeFacets, _ := setupBleveBackend(t)
	require.NotContains(t, nativeFacets.requiredFeatures, resource.IndexFeatureStoredFacets)

	postRank, _ := setupBleveBackend(t, withPostRankAuthzEnabled())
	require.Contains(t, postRank.requiredFeatures, resource.IndexFeatureStoredFacets)
}

// TestBuildIndexReuseChecksRequiredFeatures covers an on-disk index built before
// a mapping change: a binary requiring an index feature the index lacks rebuilds
// rather than serve wrong answers, and reuses the index when it requires none.
func TestBuildIndexReuseChecksRequiredFeatures(t *testing.T) {
	ns := resource.NamespacedResource{Namespace: "test", Group: "group", Resource: "resource"}

	const (
		firstIndexDocsCount  = 10
		secondIndexDocsCount = 20
	)

	for _, tc := range []struct {
		name             string
		required         []resource.IndexFeature
		expectedDocCount int64
	}{
		{
			name:             "no required feature reuses the index",
			expectedDocCount: firstIndexDocsCount,
		},
		{
			name:             "newly required feature rebuilds the index",
			required:         []resource.IndexFeature{"beta"},
			expectedDocCount: secondIndexDocsCount,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			tmpDir := t.TempDir()

			backend, _ := setupBleveBackend(t, withFileThreshold(5), withRootDir(tmpDir))
			_, err := backend.BuildIndex(t.Context(), ns, firstIndexDocsCount, "test", indexTestDocs(ns, firstIndexDocsCount, 100), nil, false, time.Time{}, 0)
			require.NoError(t, err)
			backend.Stop()

			newBackend, _ := setupBleveBackend(t, withFileThreshold(5), withRootDir(tmpDir), withRequiredIndexFeatures(tc.required...))
			idx, err := newBackend.BuildIndex(t.Context(), ns, secondIndexDocsCount, "test", indexTestDocs(ns, secondIndexDocsCount, 100), nil, false, time.Time{}, 0)
			require.NoError(t, err)

			cnt, err := idx.DocCount(t.Context(), "", nil)
			require.NoError(t, err)
			require.Equal(t, tc.expectedDocCount, cnt)
		})
	}
}

// TestValidateDownloadedIndexChecksRequiredFeatures covers the other way an
// outdated index arrives: a snapshot from an older binary, which snapshot
// selection accepts on version alone.
func TestValidateDownloadedIndexChecksRequiredFeatures(t *testing.T) {
	newIndexWithoutFeatures := func(t *testing.T) bleve.Index {
		t.Helper()
		idx, err := newBleveIndex("", bleve.NewIndexMapping(), time.Now(), buildVersion, nil, "", false)
		require.NoError(t, err)
		t.Cleanup(func() { _ = idx.Close() })
		require.NoError(t, setRV(idx, 42))
		return idx
	}

	t.Run("accepted when no feature is required", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withRootDir(t.TempDir()))

		rv, err := backend.validateDownloadedIndex(newIndexWithoutFeatures(t))
		require.NoError(t, err)
		require.Equal(t, int64(42), rv)
	})

	t.Run("rejected when it lacks a required feature", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withRootDir(t.TempDir()), withRequiredIndexFeatures("alpha"))

		_, err := backend.validateDownloadedIndex(newIndexWithoutFeatures(t))
		require.ErrorContains(t, err, "missing required index features [alpha]")
	})
}

// The setting is read once, when the index is created, so later changes cannot
// leave trash missing whatever was deleted while it was off.
func TestNewBleveIndexRecordsKeepsDeletedDocuments(t *testing.T) {
	for _, keep := range []bool{true, false} {
		idx, err := newBleveIndex("", bleve.NewIndexMapping(), time.Now(), buildVersion, nil, "", keep)
		require.NoError(t, err)
		t.Cleanup(func() { _ = idx.Close() })

		bi, err := getBuildInfo(idx)
		require.NoError(t, err)
		require.Equal(t, keep, slices.Contains(bi.Features, resource.IndexFeatureHoldsDeletedDocuments))
		require.Equal(t, keep, slices.Contains(bi.resourceBuildInfo().Features, resource.IndexFeatureHoldsDeletedDocuments))

		// Only an index holding deleted documents needs a reader that filters them.
		if keep {
			require.Equal(t, []resource.IndexFeature{resource.IndexFeatureHoldsDeletedDocuments}, bi.ReaderRequirements)
		} else {
			require.Empty(t, bi.ReaderRequirements)
		}
	}
}

// A local index whose build info cannot be read is discarded: there is no way to
// tell whether it declares a requirement this binary cannot meet.
func TestReuseFileIndexRejectsUnreadableBuildInfo(t *testing.T) {
	newIndexOnDisk := func(t *testing.T, rawBuildInfo []byte) string {
		t.Helper()
		resourceDir := t.TempDir()
		idx, err := newBleveIndex(filepath.Join(resourceDir, "index-dir"), bleve.NewIndexMapping(), time.Now(), buildVersion, nil, "", false)
		require.NoError(t, err)
		require.NoError(t, setRV(idx, 42))
		if rawBuildInfo != nil {
			require.NoError(t, idx.SetInternal([]byte(internalBuildInfoKey), rawBuildInfo))
		}
		require.NoError(t, idx.Close())
		return resourceDir
	}

	logger := log.New("bleve-test")

	t.Run("reused when build info is readable", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withRootDir(t.TempDir()))
		idx, _, rv, err := backend.tryReuseFileIndex(newIndexOnDisk(t, nil), time.Time{}, logger)
		require.NoError(t, err)
		require.NotNil(t, idx)
		require.Equal(t, int64(42), rv)
		require.NoError(t, idx.Close())
	})

	t.Run("discarded when build info cannot be parsed", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withRootDir(t.TempDir()))
		idx, _, _, err := backend.tryReuseFileIndex(newIndexOnDisk(t, []byte("{not json")), time.Time{}, logger)
		require.NoError(t, err)
		require.Nil(t, idx)
	})
}

// Stands in for an index written by a newer binary.
func newIndexDeclaringRequirements(t *testing.T, requirements ...resource.IndexFeature) bleve.Index {
	t.Helper()
	idx, err := newBleveIndex("", bleve.NewIndexMapping(), time.Now(), buildVersion, nil, "", false)
	require.NoError(t, err)
	t.Cleanup(func() { _ = idx.Close() })
	require.NoError(t, setRV(idx, 42))

	bi, err := getBuildInfo(idx)
	require.NoError(t, err)
	bi.ReaderRequirements = requirements
	raw, err := json.Marshal(bi)
	require.NoError(t, err)
	require.NoError(t, idx.SetInternal([]byte(internalBuildInfoKey), raw))
	return idx
}

// Backstops selection, which can only check snapshots whose manifest carries the
// requirements.
func TestValidateDownloadedIndexChecksReaderRequirements(t *testing.T) {
	backend, _ := setupBleveBackend(t, withRootDir(t.TempDir()))

	t.Run("rejected for a requirement this binary does not know", func(t *testing.T) {
		_, err := backend.validateDownloadedIndex(newIndexDeclaringRequirements(t, "feature-from-the-future"))
		require.ErrorContains(t, err, "does not understand [feature-from-the-future]")
	})

	t.Run("accepted when every requirement is understood", func(t *testing.T) {
		rv, err := backend.validateDownloadedIndex(newIndexDeclaringRequirements(t, resource.IndexFeatureDeletedMarker))
		require.NoError(t, err)
		require.Equal(t, int64(42), rv)
	})

	t.Run("accepted when none are declared", func(t *testing.T) {
		rv, err := backend.validateDownloadedIndex(newIndexDeclaringRequirements(t))
		require.NoError(t, err)
		require.Equal(t, int64(42), rv)
	})
}
func TestMemoryBleveIndexCanBeCopiedToFilesystem(t *testing.T) {
	mapper, err := GetBleveMappings(nil, "", "", nil)
	require.NoError(t, err)

	buildTime := time.Date(2026, 5, 18, 10, 0, 0, 0, time.UTC)
	selectableFields := []string{"team"}
	source, err := newBleveIndex("", mapper, buildTime, buildVersion, selectableFields, "", false)
	require.NoError(t, err)
	defer func() { require.NoError(t, source.Close()) }()

	key := &resourcepb.ResourceKey{
		Namespace: "default",
		Group:     "dashboard.grafana.app",
		Resource:  "dashboards",
		Name:      "dash-1",
	}
	wrapped := &bleveIndex{index: source}
	require.NoError(t, wrapped.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{
		{
			Action: resource.ActionIndex,
			Doc: &resource.IndexableDocument{
				Key:   key,
				Name:  key.Name,
				Title: "Production Overview",
			},
		},
		{
			Action: resource.ActionIndex,
			Doc: &resource.IndexableDocument{
				Key: &resourcepb.ResourceKey{
					Namespace: key.Namespace,
					Group:     key.Group,
					Resource:  key.Resource,
					Name:      "dash-2",
				},
				Name:  "dash-2",
				Title: "Staging Overview",
			},
		},
	}}))
	require.NoError(t, setRV(source, 42))

	copyable, ok := source.(bleve.IndexCopyable)
	require.True(t, ok)

	destDir := filepath.Join(t.TempDir(), "filesystem-index")
	require.NoError(t, copyable.CopyTo(bleve.FileSystemDirectory(destDir)))

	copied, err := bleve.OpenUsing(destDir, map[string]interface{}{"bolt_timeout": boltTimeout})
	require.NoError(t, err)
	defer func() { require.NoError(t, copied.Close()) }()

	count, err := copied.DocCount()
	require.NoError(t, err)
	assert.Equal(t, uint64(2), count)

	query := bleve.NewTermQuery("production overview")
	query.SetField(resource.SEARCH_FIELD_TITLE_PHRASE)
	result, err := copied.Search(bleve.NewSearchRequest(query))
	require.NoError(t, err)
	require.Len(t, result.Hits, 1)
	assert.Equal(t, resource.SearchID(key), result.Hits[0].ID)

	rv, err := getRV(copied)
	require.NoError(t, err)
	assert.Equal(t, int64(42), rv)

	buildInfo, err := getBuildInfo(copied)
	require.NoError(t, err)
	assert.Equal(t, buildTime.Unix(), buildInfo.BuildTime)
	assert.Equal(t, buildVersion, buildInfo.BuildVersion)
	assert.Equal(t, selectableFields, buildInfo.SelectableFields)

	snapshotMutationCount, err := readSnapshotMutationCount(copied)
	require.NoError(t, err)
	assert.Equal(t, int64(2), snapshotMutationCount)
}

func TestBuildIndexExpiration(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	type testCase struct {
		inMemory         bool
		owned            bool
		ownedCheckError  error
		expectedEviction bool
	}

	cacheTTL := time.Millisecond

	for name, tc := range map[string]testCase{
		"memory index should expire, if owned": {
			inMemory:         true,
			owned:            true,
			expectedEviction: true,
		},
		"memory index should expire, if not owned": {
			inMemory:         true,
			owned:            false,
			expectedEviction: true,
		},
		"memory index should expire, if ownership check fails": {
			inMemory:         true,
			ownedCheckError:  errors.New("error"),
			expectedEviction: true,
		},
		"file index should NOT expire, if owned": {
			inMemory:         false,
			owned:            true,
			expectedEviction: false,
		},
		"file index should expire, if not owned": {
			inMemory:         false,
			owned:            false,
			expectedEviction: true,
		},
		"file index should NOT expire, if ownership check fails": {
			inMemory:         false,
			ownedCheckError:  errors.New("error"),
			expectedEviction: false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			backend, reg := setupBleveBackend(t, withIndexCacheTTL(cacheTTL), withOwnsIndexFn(func(key resource.NamespacedResource) (bool, error) {
				return tc.owned, tc.ownedCheckError
			}))

			docs := 1
			if !tc.inMemory {
				docs = defaultFileThreshold
			}
			builtIndex, err := backend.BuildIndex(context.Background(), ns, int64(docs), "test", indexTestDocs(ns, docs, 100), nil, false, time.Time{}, 0)
			require.NoError(t, err)

			// Evict indexes.
			backend.runEvictExpiredOrUnownedIndexes(time.Now().Add(5 * time.Minute))

			if tc.expectedEviction {
				idx := backend.GetIndex(ns)
				require.Nil(t, idx)

				_, err = builtIndex.DocCount(context.Background(), "", nil)
				require.ErrorIs(t, err, bleve.ErrorIndexClosed)

				// Verify that there are no open indexes.
				checkOpenIndexes(t, reg, 0, 0)
			} else {
				idx := backend.GetIndex(ns)
				require.NotNil(t, idx)

				cnt, err := builtIndex.DocCount(context.Background(), "", nil)
				require.NoError(t, err)
				require.Equal(t, int64(docs), cnt)

				// Verify that index is still open
				if tc.inMemory {
					checkOpenIndexes(t, reg, 1, 0)
				} else {
					checkOpenIndexes(t, reg, 0, 1)
				}
			}
		})
	}
}

func TestCloseAllIndexes(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}
	ns2 := resource.NamespacedResource{
		Namespace: "test2",
		Group:     "group",
		Resource:  "resource",
	}

	tmpDir := t.TempDir()
	backend1, reg := setupBleveBackend(t, withRootDir(tmpDir))
	_, err := backend1.BuildIndex(context.Background(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)
	_, err = backend1.BuildIndex(context.Background(), ns2, 1 /* memory based */, "test", indexTestDocs(ns2, 1, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)

	// Verify two open indexes.
	checkOpenIndexes(t, reg, 1, 1)
	backend1.closeAllIndexes()

	// Verify that there are no open indexes after closeAllIndexes call.
	checkOpenIndexes(t, reg, 0, 0)
}

func TestBuildIndex(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	for _, rebuild := range []bool{false, true} {
		testName := fmt.Sprintf("rebuild=%t", rebuild)

		t.Run(testName, func(t *testing.T) {
			tmpDir := t.TempDir()

			const (
				firstIndexDocsCount  = 10
				secondIndexDocsCount = 1000
			)

			var lastImportTime time.Time
			if rebuild {
				// Pass time.Now() to force rebuild
				lastImportTime = time.Now()
			}
			// else: zero time means no rebuild based on import time

			{
				backend, _ := setupBleveBackend(t, withFileThreshold(5), withRootDir(tmpDir))
				_, err := backend.BuildIndex(context.Background(), ns, firstIndexDocsCount, "test", indexTestDocs(ns, firstIndexDocsCount, 100), nil, false, lastImportTime, 0)
				require.NoError(t, err)
				backend.Stop()
			}

			// Make sure we pass at least 1 nanosecond (alwaysRebuildDueToAge) to ensure that the index needs to be rebuild.
			time.Sleep(1 * time.Millisecond)

			newBackend, _ := setupBleveBackend(t, withFileThreshold(5), withRootDir(tmpDir))
			idx, err := newBackend.BuildIndex(context.Background(), ns, secondIndexDocsCount, "test", indexTestDocs(ns, secondIndexDocsCount, 100), nil, false, lastImportTime, 0)
			require.NoError(t, err)

			cnt, err := idx.DocCount(context.Background(), "", nil)
			require.NoError(t, err)
			if rebuild {
				require.Equal(t, int64(secondIndexDocsCount), cnt, "Index has been not rebuilt")
			} else {
				require.Equal(t, int64(firstIndexDocsCount), cnt, "Index has not been reused")
			}
		})
	}
}

func TestBuildIndexDoesNotReuseFileIndexWithoutResourceVersion(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}
	tmpDir := t.TempDir()
	backend, _ := setupBleveBackend(t, withRootDir(tmpDir))

	mapper, err := GetBleveMappings(nil, ns.Group, ns.Resource, nil)
	require.NoError(t, err)
	resourceDir := backend.getResourceDir(ns)
	require.NoError(t, os.MkdirAll(resourceDir, 0o750))
	unfinished, err := newBleveIndex(filepath.Join(resourceDir, formatIndexName(time.Now())), mapper, time.Now(), buildVersion, nil, "", false)
	require.NoError(t, err)
	rv, err := getRV(unfinished)
	require.NoError(t, err)
	require.Zero(t, rv)
	require.NoError(t, unfinished.Close())

	buildCalls := 0
	builder := func(index resource.ResourceIndex) (int64, error) {
		buildCalls++
		return indexTestDocs(ns, 10, 100)(index)
	}
	idx, err := backend.BuildIndex(t.Context(), ns, 10, "test", builder, nil, false, time.Time{}, 0)
	require.NoError(t, err)
	require.Equal(t, 1, buildCalls)

	count, err := idx.DocCount(t.Context(), "", nil)
	require.NoError(t, err)
	require.Equal(t, int64(10), count)
	require.Equal(t, int64(100), idx.(*bleveIndex).resourceVersion.Load())
	verifyDirEntriesCount(t, resourceDir, 1)
}

func TestBuildIndexAdaptivePromotion(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	t.Run("small build stays in memory", func(t *testing.T) {
		backend, reg := setupBleveBackend(t, withFileThreshold(5))

		idx, err := backend.BuildIndex(t.Context(), ns, 100, "test", indexTestDocs(ns, 4, 100), nil, false, time.Time{}, 0)
		require.NoError(t, err)

		bleveIdx := idx.(*bleveIndex)
		assert.Equal(t, indexStorageMemory, bleveIdx.indexStorage)
		assert.False(t, bleveIdx.expiration.IsZero())
		verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
		checkOpenIndexes(t, reg, 1, 0)
	})

	t.Run("build crossing threshold promotes to filesystem", func(t *testing.T) {
		backend, reg := setupBleveBackend(t, withFileThreshold(5))

		idx, err := backend.BuildIndex(t.Context(), ns, 1, "test", indexTestDocs(ns, 5, 100), nil, false, time.Time{}, 0)
		require.NoError(t, err)

		bleveIdx := idx.(*bleveIndex)
		assert.Equal(t, indexStorageFile, bleveIdx.indexStorage)
		assert.True(t, bleveIdx.expiration.IsZero())
		verifyDirEntriesCount(t, backend.getResourceDir(ns), 1)
		checkOpenIndexes(t, reg, 0, 1)

		cnt, err := idx.DocCount(t.Context(), "", nil)
		require.NoError(t, err)
		assert.Equal(t, int64(5), cnt)

		resp := searchTitle(t, idx, "Document", 10, ns)
		assert.Equal(t, int64(5), resp.TotalHits)

		assert.Equal(t, int64(100), bleveIdx.resourceVersion.Load())
		rv, err := getRV(bleveIdx.index)
		require.NoError(t, err)
		assert.Equal(t, int64(100), rv)

		buildInfo, err := getBuildInfo(bleveIdx.index)
		require.NoError(t, err)
		assert.Equal(t, buildVersion, buildInfo.BuildVersion)
		assert.NotZero(t, buildInfo.BuildTime)

		mutationCount, err := bleveIdx.getSnapshotMutationCount()
		require.NoError(t, err)
		assert.Equal(t, int64(5), mutationCount)
	})

	t.Run("incremental update does not promote memory index", func(t *testing.T) {
		backend, reg := setupBleveBackend(t, withFileThreshold(5))

		idx, err := backend.BuildIndex(t.Context(), ns, 1, "test", indexTestDocs(ns, 1, 100), updateTestDocs(ns, 5), false, time.Time{}, 0)
		require.NoError(t, err)
		bleveIdx := idx.(*bleveIndex)
		require.Equal(t, indexStorageMemory, bleveIdx.indexStorage)

		_, err = idx.UpdateIndex(t.Context())
		require.NoError(t, err)

		assert.Equal(t, indexStorageMemory, bleveIdx.indexStorage)
		verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
		checkOpenIndexes(t, reg, 1, 0)

		cnt, err := idx.DocCount(t.Context(), "", nil)
		require.NoError(t, err)
		assert.Equal(t, int64(5), cnt)
	})

	t.Run("build failure before promotion leaves no filesystem directory", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withFileThreshold(5))

		idx, err := backend.BuildIndex(t.Context(), ns, 100, "test", func(resource.ResourceIndex) (int64, error) {
			return 0, errors.New("fail before promotion")
		}, nil, false, time.Time{}, 0)
		require.Error(t, err)
		require.Nil(t, idx)
		verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
		require.Empty(t, backend.inFlightBuildDirs)
	})

	t.Run("build failure after promotion removes filesystem directory", func(t *testing.T) {
		backend, _ := setupBleveBackend(t, withFileThreshold(5))

		idx, err := backend.BuildIndex(t.Context(), ns, 100, "test", func(index resource.ResourceIndex) (int64, error) {
			_, buildErr := indexTestDocs(ns, 5, 100)(index)
			require.NoError(t, buildErr)
			return 0, errors.New("fail after promotion")
		}, nil, false, time.Time{}, 0)
		require.Error(t, err)
		require.Nil(t, idx)
		verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
		require.Empty(t, backend.inFlightBuildDirs)
	})
}

func TestRebuildingIndexClosesPreviousCachedIndex(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	for name, testCase := range map[string]struct {
		firstInMemory  bool
		secondInMemory bool
	}{
		"in-memory, in-memory": {true, true},
		"in-memory, file":      {true, false},
		"file, in-memory":      {false, true},
		"file, file":           {false, false},
	} {
		t.Run(name, func(t *testing.T) {
			backend, reg := setupBleveBackend(t, withIndexCacheTTL(time.Nanosecond))

			firstDocs := 100
			if testCase.firstInMemory {
				firstDocs = 1
			}
			firstIndex, err := backend.BuildIndex(context.Background(), ns, int64(firstDocs), "test", indexTestDocs(ns, firstDocs, 100), nil, false, time.Time{}, 0)
			require.NoError(t, err)

			if testCase.firstInMemory {
				verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
			} else {
				verifyDirEntriesCount(t, backend.getResourceDir(ns), 1)
			}

			openInMemoryIndexes := 0

			secondDocs := 100
			if testCase.secondInMemory {
				secondDocs = 1
				openInMemoryIndexes = 1
			}
			secondIndex, err := backend.BuildIndex(context.Background(), ns, int64(secondDocs), "test", indexTestDocs(ns, secondDocs, 100), nil, false, time.Time{}, 0)
			require.NoError(t, err)

			if testCase.secondInMemory {
				verifyDirEntriesCount(t, backend.getResourceDir(ns), 0)
			} else {
				verifyDirEntriesCount(t, backend.getResourceDir(ns), 1)
			}

			// Verify that first and second index are different, and first one is now closed.
			require.NotEqual(t, firstIndex, secondIndex)

			_, err = firstIndex.DocCount(context.Background(), "", nil)
			require.ErrorIs(t, err, bleve.ErrorIndexClosed)

			cnt, err := secondIndex.DocCount(context.Background(), "", nil)
			require.NoError(t, err)
			require.Equal(t, int64(secondDocs), cnt)

			checkOpenIndexes(t, reg, openInMemoryIndexes, 1-openInMemoryIndexes)
		})
	}
}

func checkOpenIndexes(t *testing.T, reg prometheus.Gatherer, memory, file int) {
	require.NoError(t, testutil.GatherAndCompare(reg, bytes.NewBufferString(fmt.Sprintf(`
		# HELP index_server_open_indexes Number of open indexes per storage type. An open index corresponds to single resource group.
		# TYPE index_server_open_indexes gauge
		index_server_open_indexes{index_storage="memory"} %d
		index_server_open_indexes{index_storage="file"} %d
	`, memory, file)), "index_server_open_indexes"))
}

func verifyDirEntriesCount(t *testing.T, dir string, count int) {
	ents, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			ents = nil
			// This is fine, if dir doesn't exist.
		} else {
			require.NoError(t, err)
		}
	}
	require.Len(t, ents, count)
}

func indexTestDocs(ns resource.NamespacedResource, docs int, listRV int64) resource.BuildFn {
	return func(index resource.ResourceIndex) (int64, error) {
		items := make([]*resource.BulkIndexItem, 0, docs)
		for i := range docs {
			items = append(items, &resource.BulkIndexItem{
				Action: resource.ActionIndex,
				Doc: &resource.IndexableDocument{
					Key: &resourcepb.ResourceKey{
						Namespace: ns.Namespace,
						Group:     ns.Group,
						Resource:  ns.Resource,
						Name:      fmt.Sprintf("doc%d", i),
					},
					Title: fmt.Sprintf("Document %d", i),
				},
			})
		}

		err := index.BulkIndex(&resource.BulkIndexRequest{Items: items})
		return listRV, err
	}
}

func updateTestDocs(ns resource.NamespacedResource, docs int) resource.UpdateFn {
	cnt := 0

	return func(context context.Context, index resource.ResourceIndex, sinceRV int64) (newRV int64, updatedDocs int, _ error) {
		cnt++

		items := make([]*resource.BulkIndexItem, 0, docs)
		for i := range docs {
			items = append(items, &resource.BulkIndexItem{
				Action: resource.ActionIndex,
				Doc: &resource.IndexableDocument{
					Key: &resourcepb.ResourceKey{
						Namespace: ns.Namespace,
						Group:     ns.Group,
						Resource:  ns.Resource,
						Name:      fmt.Sprintf("doc%d", i),
					},
					Title: fmt.Sprintf("Document %d (gen_%d)", i, cnt),
				},
			})
		}

		err := index.BulkIndex(&resource.BulkIndexRequest{Items: items})
		// Simulate RV increase
		return sinceRV + int64(docs), docs, err
	}
}

func updateTestDocsReturningMillisTimestamp(ns resource.NamespacedResource, docs int) (resource.UpdateFn, *atomic.Int64) {
	cnt := 0
	var updateCalls atomic.Int64

	return func(context context.Context, index resource.ResourceIndex, sinceRV int64) (newRV int64, updatedDocs int, _ error) {
		now := time.Now()
		updateCalls.Add(1)

		cnt++

		items := make([]*resource.BulkIndexItem, 0, docs)
		for i := range docs {
			items = append(items, &resource.BulkIndexItem{
				Action: resource.ActionIndex,
				Doc: &resource.IndexableDocument{
					Key: &resourcepb.ResourceKey{
						Namespace: ns.Namespace,
						Group:     ns.Group,
						Resource:  ns.Resource,
						Name:      fmt.Sprintf("doc%d", i),
					},
					Title: fmt.Sprintf("Document %d (gen_%d)", i, cnt),
				},
			})
		}

		err := index.BulkIndex(&resource.BulkIndexRequest{Items: items})
		return now.UnixMilli(), docs, err
	}, &updateCalls
}

func TestCleanOldIndexes(t *testing.T) {
	dir := t.TempDir()

	b, _ := setupBleveBackend(t, withRootDir(dir))

	t.Run("with skip", func(t *testing.T) {
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-1/a"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-2/b"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-3/c"), 0750))

		b.cleanOldIndexes(dir, "index-2")
		files, err := os.ReadDir(dir)
		require.NoError(t, err)
		require.Len(t, files, 1)
		require.Equal(t, "index-2", files[0].Name())
	})

	t.Run("without skip", func(t *testing.T) {
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-1/a"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-2/b"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-3/c"), 0750))

		b.cleanOldIndexes(dir, "")
		files, err := os.ReadDir(dir)
		require.NoError(t, err)
		require.Len(t, files, 0)
	})

	t.Run("in-flight build directory is preserved", func(t *testing.T) {
		dir := t.TempDir()
		b, _ := setupBleveBackend(t, withRootDir(dir))

		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-1/a"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-2/b"), 0750))
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "index-3/c"), 0750))

		// Pretend a concurrent BuildIndex is using index-2.
		inFlightDir := filepath.Join(dir, "index-2")
		b.registerInFlightBuildDir(inFlightDir)
		t.Cleanup(func() { b.unregisterInFlightBuildDir(inFlightDir) })

		b.cleanOldIndexes(dir, "index-3")

		names := dirEntryNames(t, dir)
		require.ElementsMatch(t, []string{"index-2", "index-3"}, names,
			"in-flight directory and skipName must both survive cleanup")
	})
}

func TestReserveIndexDirSkipsInFlightReservation(t *testing.T) {
	dir := t.TempDir()
	b, _ := setupBleveBackend(t, withRootDir(dir))
	resourceDir := filepath.Join(dir, "resource")

	firstDir, firstName, err := b.reserveIndexDir(resourceDir)
	require.NoError(t, err)
	defer b.unregisterInFlightBuildDir(firstDir)

	secondDir, secondName, err := b.reserveIndexDir(resourceDir)
	require.NoError(t, err)
	defer b.unregisterInFlightBuildDir(secondDir)

	require.NotEqual(t, firstName, secondName)
	require.NotEqual(t, firstDir, secondDir)
	require.NoDirExists(t, firstDir)
	require.NoDirExists(t, secondDir)
	require.Len(t, b.inFlightBuildDirs, 2)
}

func dirEntryNames(t *testing.T, dir string) []string {
	t.Helper()
	entries, err := os.ReadDir(dir)
	require.NoError(t, err)
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		names = append(names, e.Name())
	}
	return names
}

// TestBuildIndexConcurrentBuildsForSameKeyDoNotDeleteEachOthersDirs covers
// the case of two concurrent BuildIndex calls for the same key, the second
// finishing first and running cleanOldIndexes while the first is still
// building. cleanOldIndexes must skip the first build's directory, otherwise
// the still-running build's segments get wiped from disk and persists fail
// with ENOENT.
func TestBuildIndexConcurrentBuildsForSameKeyDoNotDeleteEachOthersDirs(t *testing.T) {
	backend, _ := setupBleveBackend(t, withFileThreshold(1))
	ns := resource.NamespacedResource{Namespace: "ns", Group: "group", Resource: "res"}
	resourceDir := backend.getResourceDir(ns)

	// Seed the cache with a file-based index so the subsequent rebuilds skip
	// the cold-start reuse path (which would otherwise collide on the bolt
	// lock of the already-open initial index).
	_, err := backend.BuildIndex(t.Context(), ns, 100, "init",
		indexTestDocs(ns, 1, 1),
		nil, false, time.Time{}, 0)
	require.NoError(t, err)
	initDirs := dirEntryNames(t, resourceDir)
	require.Len(t, initDirs, 1)

	// Start build A and park its builder after promotion, so A's directory is on
	// disk and registered as in-flight while B runs.
	aEntered := make(chan struct{})
	aRelease := make(chan struct{})
	aDone := make(chan struct{})
	go func() {
		defer close(aDone)
		_, _ = backend.BuildIndex(t.Context(), ns, 100, "build-a",
			func(index resource.ResourceIndex) (int64, error) {
				if err := index.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{{
					Action: resource.ActionIndex,
					Doc: &resource.IndexableDocument{
						Key:   &resourcepb.ResourceKey{Namespace: ns.Namespace, Group: ns.Group, Resource: ns.Resource, Name: "doc-a"},
						Title: "Document A",
					},
				}}}); err != nil {
					return 0, err
				}
				close(aEntered)
				<-aRelease
				return 1, nil
			}, nil, true, time.Time{}, 0)
	}()
	<-aEntered

	// A's directory is the new entry that appeared since the initial build.
	var aDir string
	for _, name := range dirEntryNames(t, resourceDir) {
		if name != initDirs[0] {
			aDir = name
			break
		}
	}
	require.NotEmpty(t, aDir)

	// Run B to completion. B's cleanOldIndexes runs while A is still in flight.
	_, err = backend.BuildIndex(t.Context(), ns, 100, "build-b",
		indexTestDocs(ns, 1, 2),
		nil, true, time.Time{}, 0)
	require.NoError(t, err)

	require.Contains(t, dirEntryNames(t, resourceDir), aDir,
		"A's directory was deleted by B's cleanOldIndexes while A was still in flight")

	// Let A finish so its goroutine cleans up before the test ends.
	close(aRelease)
	<-aDone

	require.Empty(t, backend.inFlightBuildDirs,
		"in-flight directory registrations leaked after both builds finished")
}

// TestBuildIndexColdStartReuseRejectionDoesNotLeakInFlightDir guards against
// a leak in the path where findPreviousFileBasedIndex registers the reused
// directory but tryReuseFileIndex then rejects it because its BuildTime
// predates lastImportTime. Without unregistering on the reject path, the
// stale directory would remain registered for the lifetime of the process,
// causing cleanOldIndexes to skip it forever.
func TestBuildIndexColdStartReuseRejectionDoesNotLeakInFlightDir(t *testing.T) {
	backend, _ := setupBleveBackend(t, withFileThreshold(1))
	ns := resource.NamespacedResource{Namespace: "ns", Group: "group", Resource: "res"}

	// Build an initial file-based index so a directory exists on disk.
	_, err := backend.BuildIndex(t.Context(), ns, 100, "init",
		func(_ resource.ResourceIndex) (int64, error) { return 1, nil },
		nil, false, time.Time{}, 0)
	require.NoError(t, err)

	// Drop the cached entry and close the index, simulating a fresh process
	// boot that finds an out-of-date persisted index on disk.
	backend.cacheMx.Lock()
	prev := backend.cache[ns]
	delete(backend.cache, ns)
	backend.cacheMx.Unlock()
	require.NotNil(t, prev)
	require.NoError(t, prev.stopUpdaterAndCloseIndex())

	// Call BuildIndex with lastImportTime > the existing index's BuildTime.
	// tryReuseFileIndex opens the on-disk dir, sees the build is stale, and
	// closes + rejects it; createEmptyFileIndex then builds a fresh one.
	_, err = backend.BuildIndex(t.Context(), ns, 100, "rebuild-after-import",
		func(_ resource.ResourceIndex) (int64, error) { return 2, nil },
		nil, false, time.Now().Add(time.Hour), 0)
	require.NoError(t, err)

	require.Empty(t, backend.inFlightBuildDirs,
		"in-flight directory registrations leaked after cold-start reuse rejection")
}

func TestBleveIndexWithFailures(t *testing.T) {
	t.Run("in-memory index", func(t *testing.T) {
		testBleveIndexWithFailures(t, false)
	})
	t.Run("file-based index", func(t *testing.T) {
		testBleveIndexWithFailures(t, true)
	})
}

func testBleveIndexWithFailures(t *testing.T, fileBased bool) {
	backend, _ := setupBleveBackend(t)

	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	docs := 1
	if fileBased {
		docs = defaultFileThreshold
	}
	_, err := backend.BuildIndex(context.Background(), ns, int64(docs), "test", func(index resource.ResourceIndex) (int64, error) {
		if fileBased {
			_, buildErr := indexTestDocs(ns, docs, 100)(index)
			require.NoError(t, buildErr)
		}
		return 0, fmt.Errorf("fail")
	}, nil, false, time.Time{}, 0)
	require.Error(t, err)

	// Even though previous build of the index failed, new building of the index should work.
	_, err = backend.BuildIndex(context.Background(), ns, int64(docs), "test", indexTestDocs(ns, docs, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)
}

func TestIndexUpdate(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t)
	idx, err := be.BuildIndex(t.Context(), ns, defaultFileThreshold*2 /* file based */, "test", indexTestDocs(ns, 10, 100), updateTestDocs(ns, 5), false, time.Time{}, 0)
	require.NoError(t, err)

	resp := searchTitle(t, idx, "gen", 10, ns)
	require.Equal(t, int64(0), resp.TotalHits)

	// Update index.
	_, err = idx.UpdateIndex(context.Background())
	require.NoError(t, err)

	// Verify that index was updated -- number of docs didn't change, but we can search "gen_1" documents now.
	require.Equal(t, 10, docCount(t, idx))
	require.Equal(t, int64(5), searchTitle(t, idx, "gen_1", 10, ns).TotalHits)

	// Update index again.
	_, err = idx.UpdateIndex(context.Background())
	require.NoError(t, err)
	// Verify that index was updated again -- we can search "gen_2" now. "gen_1" documents are gone.
	require.Equal(t, 10, docCount(t, idx))
	require.Equal(t, int64(0), searchTitle(t, idx, "gen_1", 10, ns).TotalHits)
	require.Equal(t, int64(5), searchTitle(t, idx, "gen_2", 10, ns).TotalHits)
}

func TestConcurrentIndexUpdateAndBuildIndex(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t)

	updaterFn := func(context context.Context, index resource.ResourceIndex, sinceRV int64) (newRV int64, updatedDocs int, _ error) {
		items := make([]*resource.BulkIndexItem, 0, 5)
		for i := range 5 {
			items = append(items, &resource.BulkIndexItem{
				Action: resource.ActionIndex,
				Doc: &resource.IndexableDocument{
					Key: &resourcepb.ResourceKey{
						Namespace: ns.Namespace,
						Group:     ns.Group,
						Resource:  ns.Resource,
						Name:      fmt.Sprintf("doc%d", i),
					},
					Title: fmt.Sprintf("Document %d (gen_%d)", i, 5),
				},
			})
		}

		err := index.BulkIndex(&resource.BulkIndexRequest{Items: items})
		// Simulate RV increase
		return sinceRV + int64(5), 5, err
	}

	idx, err := be.BuildIndex(t.Context(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), updaterFn, false, time.Time{}, 0)
	require.NoError(t, err)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	_, err = idx.UpdateIndex(ctx)
	require.NoError(t, err)

	_, err = be.BuildIndex(t.Context(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), updaterFn, false, time.Time{}, 0)
	require.NoError(t, err)

	_, err = idx.UpdateIndex(ctx)
	require.Contains(t, err.Error(), bleve.ErrorIndexClosed.Error())
}

func TestConcurrentIndexUpdateSearchAndRebuild(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t)

	_, err := be.BuildIndex(t.Context(), ns, 10, "test", indexTestDocs(ns, 10, 100), updateTestDocs(ns, 5), false, time.Time{}, 0)
	require.NoError(t, err)

	wg := sync.WaitGroup{}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var rebuilds, updates, searches atomic.Int64
	const searchConcurrency = 25
	for i := range searchConcurrency {
		wg.Go(func() {
			for ctx.Err() == nil {
				select {
				case <-ctx.Done():
					return
				case <-time.After(time.Duration(i) * time.Millisecond): // introduce small jitter
				}

				idx := be.GetIndex(ns)
				_, err := idx.UpdateIndex(ctx)
				if err != nil {
					if errors.Is(err, bleve.ErrorIndexClosed) || errors.Is(err, context.Canceled) {
						continue
					}
					require.NoError(t, err)
				}
				updates.Add(1)

				resp, err := idx.Search(ctx, nil, &resourcepb.ResourceSearchRequest{
					Options: &resourcepb.ListOptions{
						Key: &resourcepb.ResourceKey{
							Namespace: ns.Namespace,
							Group:     ns.Group,
							Resource:  ns.Resource,
						},
					},
					Fields: []string{"title"},
					Query:  "Document",
					Limit:  10,
				}, nil, nil)
				if err != nil {
					if errors.Is(err, bleve.ErrorIndexClosed) || errors.Is(err, context.Canceled) {
						continue
					}
					require.NoError(t, err)
				}
				require.Equal(t, int64(10), resp.TotalHits)
				searches.Add(1)
			}
		})
	}

	wg.Go(func() {
		for ctx.Err() == nil {
			_, err := be.BuildIndex(t.Context(), ns, 10, "test", indexTestDocs(ns, 10, 100), updateTestDocs(ns, 5), false, time.Time{}, 0)
			require.NoError(t, err)
			rebuilds.Add(1)
		}
	})

	time.Sleep(5 * time.Second)
	cancel()
	wg.Wait()

	t.Log("Updates:", updates.Load(), "searches:", searches.Load(), "rebuilds:", rebuilds.Load())
}

// Verify concurrent updates and searches work as expected.
func TestConcurrentIndexUpdateAndSearch(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t)

	idx, err := be.BuildIndex(t.Context(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), updateTestDocs(ns, 5), false, time.Time{}, 0)
	require.NoError(t, err)

	wg := sync.WaitGroup{}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// We count how many goroutines received given updated RV. We expect at least some RVs to be returned to multiple
	// goroutines, if batching works.
	mu := sync.Mutex{}
	updatedRVs := map[int64]int{}

	const searchConcurrency = 25
	for range searchConcurrency {
		wg.Go(func() {
			prevRV := int64(0)
			for ctx.Err() == nil {
				// We use t.Context() here to avoid getting errors from context cancellation.
				rv, err := idx.UpdateIndex(t.Context())
				require.NoError(t, err)
				require.Greater(t, rv, prevRV) // Each update should return new RV (that's how our update function works)
				require.Equal(t, int64(10), searchTitle(t, idx, "Document", 10, ns).TotalHits)
				prevRV = rv

				mu.Lock()
				updatedRVs[rv]++
				mu.Unlock()
			}
		})
	}

	time.Sleep(1 * time.Second)
	cancel()
	wg.Wait()

	// Check that some RVs were updated due to requests from multiple goroutines
	var rvUpdatedByMultipleGoroutines int64
	for rv, count := range updatedRVs {
		if count > 1 {
			rvUpdatedByMultipleGoroutines = rv
			break
		}
	}
	require.Greater(t, rvUpdatedByMultipleGoroutines, int64(0))
}

func TestConcurrentIndexUpdateAndSearchWithIndexMinUpdateInterval(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	const minInterval = 100 * time.Millisecond
	be, _ := setupBleveBackend(t, withIndexMinUpdateInterval(minInterval))

	updateFn, updateCalls := updateTestDocsReturningMillisTimestamp(ns, 5)
	idx, err := be.BuildIndex(t.Context(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), updateFn, false, time.Time{}, 0)
	require.NoError(t, err)

	wg := sync.WaitGroup{}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var attemptedUpdates atomic.Int64

	// Verify that each returned RV (unix timestamp in millis) is either the same as before, or at least minInterval later.
	const searchConcurrency = 10
	for range searchConcurrency {
		wg.Go(func() {
			var collectedRVs []int64
			for ctx.Err() == nil {
				attemptedUpdates.Add(1)

				// We use t.Context() here to avoid getting errors from context cancellation.
				rv, err := idx.UpdateIndex(t.Context())
				require.NoError(t, err)

				if len(collectedRVs) == 0 || collectedRVs[len(collectedRVs)-1] != rv {
					collectedRVs = append(collectedRVs, rv)
				}

				require.Equal(t, int64(10), searchTitle(t, idx, "Document", 10, ns).TotalHits)
			}

			t.Log(collectedRVs)
			for i := 1; i < len(collectedRVs); i++ {
				// We allow next RV to be 0.9*minInterval later, to account for possible clock skew between time measurements.
				// (We get measurements from update function, but check is done on times inside updater)
				require.GreaterOrEqual(t, collectedRVs[i], collectedRVs[i-1]+(9*int64(minInterval/time.Millisecond)/10))
			}
		})
	}

	// Run updates and searches for this time.
	testTime := 1 * time.Second

	time.Sleep(testTime)
	cancel()
	wg.Wait()

	expectedMaxCalls := int64(testTime / minInterval)
	require.LessOrEqual(t, updateCalls.Load(), expectedMaxCalls+1)
	require.Greater(t, attemptedUpdates.Load(), updateCalls.Load())

	t.Log("Attempted updates:", attemptedUpdates.Load(), "update calls:", updateCalls.Load())
}

func TestIndexUpdateWithErrors(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t)

	updateErr := fmt.Errorf("failed to update index")
	updaterFn := func(context context.Context, index resource.ResourceIndex, sinceRV int64) (newRV int64, updatedDocs int, _ error) {
		time.Sleep(100 * time.Millisecond)
		return 0, 0, updateErr
	}
	idx, err := be.BuildIndex(t.Context(), ns, 10 /* file based */, "test", indexTestDocs(ns, 10, 100), updaterFn, false, time.Time{}, 0)
	require.NoError(t, err)

	t.Run("update fail", func(t *testing.T) {
		_, err = idx.UpdateIndex(t.Context())
		require.ErrorIs(t, err, updateErr)
	})

	t.Run("update timeout", func(t *testing.T) {
		ctx, cancel := context.WithTimeout(context.Background(), 1*time.Millisecond)
		defer cancel()

		_, err = idx.UpdateIndex(ctx)
		require.ErrorIs(t, err, context.DeadlineExceeded)
	})

	t.Run("context canceled", func(t *testing.T) {
		// Canceled context
		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		_, err = idx.UpdateIndex(ctx)
		require.ErrorIs(t, err, context.Canceled)
	})
}

func TestIndexBuildInfo(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	be, _ := setupBleveBackend(t, withFileThreshold(100))
	index, err := be.BuildIndex(t.Context(), ns, 10, "test", indexTestDocs(ns, 10, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)

	buildInfo, err := getBuildInfo(index.(*bleveIndex).index)
	require.NoError(t, err)
	require.NotNil(t, buildInfo)
	require.Equal(t, buildVersion, buildInfo.BuildVersion)
	require.InDelta(t, float64(time.Now().Unix()), buildInfo.BuildTime, 30) // allow 30 seconds of drift
}

func TestIndexBuildInfoSearchFieldsHashRoundTrip(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}
	hash := "deadbeefcafef00d"
	hashes := map[resource.LowerGroupResource]string{
		resource.NewLowerGroupResource(ns.Group, ns.Resource): hash,
	}

	be, _ := setupBleveBackend(t, withFileThreshold(100), withSearchFields(resource.NewSearchFieldsRegistry(nil, hashes, nil)))
	index, err := be.BuildIndex(t.Context(), ns, 10, "test", indexTestDocs(ns, 10, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)

	buildInfo, err := index.BuildInfo()
	require.NoError(t, err)
	assert.Equal(t, hash, buildInfo.SearchFieldsHash)

	// Indexes built without a registered hash record an empty string.
	nsOther := resource.NamespacedResource{Namespace: "test", Group: "other", Resource: "things"}
	indexOther, err := be.BuildIndex(t.Context(), nsOther, 10, "test", indexTestDocs(nsOther, 10, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)

	buildInfoOther, err := indexOther.BuildInfo()
	require.NoError(t, err)
	assert.Equal(t, "", buildInfoOther.SearchFieldsHash)
}

func TestInvalidBuildVersion(t *testing.T) {
	opts := BleveOptions{
		Root:         t.TempDir(),
		BuildVersion: "invalid",
	}
	_, err := NewBleveBackend(opts, nil)
	require.ErrorContains(t, err, "cannot parse build version")
}

func searchTitle(t *testing.T, idx resource.ResourceIndex, query string, limit int, ns resource.NamespacedResource) *resourcepb.ResourceSearchResponse {
	resp, err := idx.Search(t.Context(), nil, &resourcepb.ResourceSearchRequest{
		Options: &resourcepb.ListOptions{
			Key: &resourcepb.ResourceKey{
				Namespace: ns.Namespace,
				Group:     ns.Group,
				Resource:  ns.Resource,
			},
		},
		Fields: []string{"title"},
		Query:  query,
		Limit:  int64(limit),
	}, nil, nil)
	require.NoError(t, err)
	return resp
}

func docCount(t *testing.T, idx resource.ResourceIndex) int {
	cnt, err := idx.DocCount(context.Background(), "", nil)
	require.NoError(t, err)
	return int(cnt)
}

func TestBuildIndexReturnsErrorWhenIndexLocked(t *testing.T) {
	ns := resource.NamespacedResource{
		Namespace: "test",
		Group:     "group",
		Resource:  "resource",
	}

	tmpDir := t.TempDir()

	// First, create a file-based index with one backend and keep it open
	backend1, reg1 := setupBleveBackend(t, withRootDir(tmpDir))
	index1, err := backend1.BuildIndex(context.Background(), ns, 100 /* file based */, "test", indexTestDocs(ns, 10, 100), nil, false, time.Time{}, 0)
	require.NoError(t, err)
	require.NotNil(t, index1)

	// Verify first index is file-based
	bleveIdx1, ok := index1.(*bleveIndex)
	require.True(t, ok)
	require.Equal(t, indexStorageFile, bleveIdx1.indexStorage)
	checkOpenIndexes(t, reg1, 0, 1)

	// Now create a second backend using the same directory
	// This simulates another instance trying to open the same index
	backend2, _ := setupBleveBackend(t, withRootDir(tmpDir))

	// BuildIndex should detect the file is locked and return an error after timeout
	now := time.Now()
	timeout, err := time.ParseDuration(boltTimeout)
	require.NoError(t, err)
	index2, err := backend2.BuildIndex(context.Background(), ns, 100 /* file based */, "test", indexTestDocs(ns, 10, 100), nil, false, time.Time{}, 0)
	require.Error(t, err)
	require.ErrorIs(t, err, bolterrors.ErrTimeout)
	require.Nil(t, index2)
	require.GreaterOrEqual(t, time.Since(now).Milliseconds(), timeout.Milliseconds()-500, "BuildIndex should have waited for approximately boltTimeout duration")

	// Clean up: close first backend to release the file lock
	backend1.Stop()
}

// TestBleveTextFieldFilterAndSort covers a per-kind field that is both searched
// as text and used for exact filters and sorting. Those three uses need
// different index fields, and only the keyword copy can answer the last two.
func TestBleveTextFieldFilterAndSort(t *testing.T) {
	group, kindResource := "example.grafana.app", "widgets"
	gvr := schema.GroupVersionResource{Group: group, Version: "v1", Resource: kindResource}
	provider := resource.NewMapProvider(map[schema.GroupVersionResource][]resource.SearchFieldDefinition{
		gvr: {{
			Name: "note",
			Type: resource.SearchFieldTypeString,
			Capabilities: []resource.SearchCapability{
				resource.SearchCapabilityText,
				resource.SearchCapabilityFilter,
				resource.SearchCapabilitySort,
			},
		}},
	}, nil)

	backend, err := NewBleveBackend(BleveOptions{
		Root:          t.TempDir(),
		FileThreshold: 5,
		SearchFields: resource.NewSearchFieldsRegistry(nil, nil, map[resource.LowerGroupResource]resource.SearchFieldsProvider{
			resource.NewLowerGroupResource(group, kindResource): provider,
		}),
	}, nil)
	require.NoError(t, err)
	t.Cleanup(backend.Stop)

	key := &resourcepb.ResourceKey{Namespace: "ns", Group: group, Resource: kindResource}
	ctx := identity.WithRequester(context.Background(), &user.SignedInUser{Namespace: "ns"})

	doc := func(name, note string) *resource.BulkIndexItem {
		return &resource.BulkIndexItem{
			Action: resource.ActionIndex,
			Doc: &resource.IndexableDocument{
				RV:     1,
				Name:   name,
				Key:    &resourcepb.ResourceKey{Name: name, Namespace: "ns", Group: group, Resource: kindResource},
				Title:  name,
				Fields: map[string]any{"note": note},
			},
		}
	}
	index, err := backend.BuildIndex(ctx, resource.NamespacedResource{
		Namespace: key.Namespace, Group: key.Group, Resource: key.Resource,
	}, 3, "test", func(index resource.ResourceIndex) (int64, error) {
		if err := index.BulkIndex(&resource.BulkIndexRequest{
			Items: []*resource.BulkIndexItem{
				doc("one", "Zeta Apple"),
				doc("two", "beta gamma"),
				doc("three", "Cherry Tart"),
			},
		}); err != nil {
			return 0, err
		}
		return 1, nil
	}, nil, false, time.Time{}, 0)
	require.NoError(t, err)

	names := func(req *resourcepb.ResourceSearchRequest) []string {
		req.Limit = 100
		req.Options.Key = key
		rsp, err := index.Search(ctx, NewStubAccessClient(map[string]bool{kindResource: true}), req, nil, nil)
		require.NoError(t, err)
		require.Nil(t, rsp.Error)
		out := make([]string, 0, len(rsp.Results.Rows))
		for _, row := range rsp.Results.Rows {
			out = append(out, row.Key.Name)
		}
		return out
	}

	t.Run("filter matches the whole value, ignoring case", func(t *testing.T) {
		got := names(&resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{Fields: []*resourcepb.Requirement{{
				Key: "note", Operator: string(selection.Equals), Values: []string{"zeta apple"},
			}}},
		})
		assert.Equal(t, []string{"one"}, got)
	})

	t.Run("filter does not match a single word of the value", func(t *testing.T) {
		got := names(&resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{Fields: []*resourcepb.Requirement{{
				Key: "note", Operator: string(selection.Equals), Values: []string{"Zeta"},
			}}},
		})
		assert.Empty(t, got)
	})

	// Sorting on the analyzed field would order by each value's first token
	// ("apple" before "beta"), which is not the order a user asked for.
	t.Run("sort orders by the whole value, ignoring case", func(t *testing.T) {
		got := names(&resourcepb.ResourceSearchRequest{
			Options: &resourcepb.ListOptions{},
			SortBy:  []*resourcepb.ResourceSearchRequest_Sort{{Field: "note"}},
		})
		assert.Equal(t, []string{"two", "three", "one"}, got)
	})

	t.Run("text search still matches single words", func(t *testing.T) {
		got := names(&resourcepb.ResourceSearchRequest{
			Options:     &resourcepb.ListOptions{},
			Query:       "apple",
			QueryFields: []*resourcepb.ResourceSearchRequest_QueryField{{Name: "fields.note"}},
		})
		assert.Equal(t, []string{"one"}, got)
	})
}

// TestIsDeletedMarkerIndexing pins how the marker reaches the index. A document
// that does not carry it must leave no trace under that field, which is what
// lets documents written before the marker existed count as live.
func TestIsDeletedMarkerIndexing(t *testing.T) {
	const group, kindResource = "example.test", "widgets"
	key := resource.NamespacedResource{Namespace: "default", Group: group, Resource: kindResource}

	backend, err := NewBleveBackend(BleveOptions{
		Root:          t.TempDir(),
		FileThreshold: 5, // stay in memory
	}, nil)
	require.NoError(t, err)
	t.Cleanup(backend.Stop)

	doc := func(name string, deleted, provisioned *bool) *resource.BulkIndexItem {
		return &resource.BulkIndexItem{
			Action: resource.ActionIndex,
			Doc: &resource.IndexableDocument{
				Key:           &resourcepb.ResourceKey{Namespace: key.Namespace, Group: group, Resource: kindResource, Name: name},
				Title:         name,
				IsDeleted:     deleted,
				IsProvisioned: provisioned,
			},
		}
	}

	index, err := backend.BuildIndex(t.Context(), key, 3, "test", func(index resource.ResourceIndex) (int64, error) {
		return 1, index.BulkIndex(&resource.BulkIndexRequest{
			Items: []*resource.BulkIndexItem{
				doc("live-unset", nil, nil),
				doc("live-explicit", new(false), nil),
				doc("trashed", new(true), new(true)),
			},
		})
	}, nil, false, time.Time{}, 0)
	require.NoError(t, err)

	bi, ok := index.(*bleveIndex)
	require.True(t, ok)

	markerHits := func(t *testing.T, field string, value bool) []string {
		t.Helper()
		q := bleve.NewBoolFieldQuery(value)
		q.SetField(field)
		res, err := bi.index.Search(bleve.NewSearchRequest(q))
		require.NoError(t, err)
		names := make([]string, 0, len(res.Hits))
		for _, hit := range res.Hits {
			names = append(names, hit.ID)
		}
		slices.Sort(names)
		return names
	}

	assert.Equal(t, []string{"default/example.test/widgets/trashed"}, markerHits(t, resource.SEARCH_FIELD_IS_DELETED, true))
	assert.Equal(t, []string{"default/example.test/widgets/trashed"}, markerHits(t, resource.SEARCH_FIELD_IS_PROVISIONED, true))
	assert.Equal(t, []string{"default/example.test/widgets/live-explicit"}, markerHits(t, resource.SEARCH_FIELD_IS_DELETED, false))

	// The marker is not a declared field, so callers cannot ask for it and it
	// stays out of the hash that forces reindexing.
	for _, field := range []string{resource.SEARCH_FIELD_IS_DELETED, resource.SEARCH_FIELD_IS_PROVISIONED} {
		assert.Nil(t, resource.StandardSearchFields().Field(field))
		assert.False(t, bi.isDeclaredField(field))
	}
}

// An index built before these fields were mapped drops them silently, which would
// leave a deleted document looking live. BulkIndex removes such a document
// instead, so trash is missing from search rather than leaking into it, until the
// index is rebuilt.
func TestBulkIndexRemovesMarkedDocumentsWhenTrashFieldsAreNotMapped(t *testing.T) {
	mapper, err := GetBleveMappings(nil, "", "", nil)
	require.NoError(t, err)
	raw, err := newBleveIndex("", mapper, time.Now(), buildVersion, nil, "", false)
	require.NoError(t, err)
	t.Cleanup(func() { _ = raw.Close() })

	key := &resourcepb.ResourceKey{Namespace: "default", Group: "g", Resource: "r", Name: "dash-1"}
	doc := func(deleted *bool) *resource.BulkIndexItem {
		return &resource.BulkIndexItem{
			Action: resource.ActionIndex,
			Doc:    &resource.IndexableDocument{Key: key, Title: "Production Overview", IsDeleted: deleted},
		}
	}

	// features left empty: an index whose mapping predates the marker.
	legacy := &bleveIndex{index: raw, logger: log.NewNopLogger()}
	require.NoError(t, legacy.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{doc(nil)}}))
	count, err := raw.DocCount()
	require.NoError(t, err)
	require.Equal(t, uint64(1), count)

	require.NoError(t, legacy.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{doc(new(true))}}))
	count, err = raw.DocCount()
	require.NoError(t, err)
	assert.Equal(t, uint64(0), count, "marked document should be removed, not indexed as live")

	// An index mapping the markers but not the trash fields is no better: the
	// document would be served without a deleter and in arbitrary order. The
	// producer refuses such an index too, so both writers agree.
	partial := &bleveIndex{index: raw, features: []resource.IndexFeature{resource.IndexFeatureDeletedMarker}, logger: log.NewNopLogger()}
	require.NoError(t, partial.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{doc(new(true))}}))
	count, err = raw.DocCount()
	require.NoError(t, err)
	assert.Equal(t, uint64(0), count, "a partially mapped index should not keep the document either")

	// An index that maps everything a deleted document needs keeps it.
	current := &bleveIndex{index: raw, features: resource.CurrentIndexFeatures(), logger: log.NewNopLogger()}
	require.NoError(t, current.BulkIndex(&resource.BulkIndexRequest{Items: []*resource.BulkIndexItem{doc(new(true))}}))
	count, err = raw.DocCount()
	require.NoError(t, err)
	assert.Equal(t, uint64(1), count)
}

// TestScopeQueryTrashBrowseDrivesOffTheMarker pins the shape for a trash browse
// with nothing to match on. Bleve only ever drives iteration from the Must side,
// so leaving match-all there and testing the marker as a Filter would read every
// document in the index to find the few deleted ones.
func TestScopeQueryTrashBrowseDrivesOffTheMarker(t *testing.T) {
	scoped, ok := scopeQuery(bleve.NewMatchAllQuery(), true, 0).(*query.BooleanQuery)
	require.True(t, ok)

	assert.Equal(t, []string{resource.SEARCH_FIELD_IS_DELETED}, boolFieldsOf(t, scoped.Must),
		"the marker has to drive iteration, not sit in Filter")
	assert.Equal(t, []string{resource.SEARCH_FIELD_IS_PROVISIONED}, boolFieldsOf(t, scoped.MustNot))
	assert.Nil(t, scoped.Filter)

	// A real query drives iteration itself, so the marker moves to Filter where it
	// does not score.
	textQuery := bleve.NewMatchQuery("hello")
	scoped, ok = scopeQuery(textQuery, true, 0).(*query.BooleanQuery)
	require.True(t, ok)
	assert.Equal(t, []string{resource.SEARCH_FIELD_IS_DELETED}, boolFieldsOf(t, scoped.Filter))
	assert.Equal(t, []string{resource.SEARCH_FIELD_IS_PROVISIONED}, boolFieldsOf(t, scoped.MustNot))

	// Live searches only exclude the marker; provisioning is irrelevant to them.
	scoped, ok = scopeQuery(bleve.NewMatchAllQuery(), false, 0).(*query.BooleanQuery)
	require.True(t, ok)
	assert.Equal(t, []string{resource.SEARCH_FIELD_IS_DELETED}, boolFieldsOf(t, scoped.MustNot))
	assert.Nil(t, scoped.Filter)
}

// boolFieldsOf returns the fields of the boolean-field queries in a clause,
// looking through the conjunction or disjunction bleve wraps clauses in.
func boolFieldsOf(t *testing.T, clause query.Query) []string {
	t.Helper()
	var fields []string
	var walk func(query.Query)
	walk = func(q query.Query) {
		switch typed := q.(type) {
		case *query.BoolFieldQuery:
			fields = append(fields, typed.FieldVal)
		case *query.ConjunctionQuery:
			for _, sub := range typed.Conjuncts {
				walk(sub)
			}
		case *query.DisjunctionQuery:
			for _, sub := range typed.Disjuncts {
				walk(sub)
			}
		}
	}
	walk(clause)
	return fields
}

// TestScopeQueryKeepsScores pins both scopes to the unscoped query's scores. The
// marker has to sit in a non-scoring position, or absolute scores move with the
// amount of trash in the index.
func TestScopeQueryKeepsScores(t *testing.T) {
	key := resource.NamespacedResource{Namespace: "default", Group: "example.test", Resource: "widgets"}

	backend, err := NewBleveBackend(BleveOptions{Root: t.TempDir(), FileThreshold: 5}, nil)
	require.NoError(t, err)
	t.Cleanup(backend.Stop)

	docs := []struct {
		name    string
		title   string
		deleted bool
	}{
		{name: "live-1", title: "hello world"},
		{name: "live-2", title: "hello hello world of hello"},
		{name: "trashed-1", title: "hello there", deleted: true},
		{name: "trashed-2", title: "hello hello there", deleted: true},
	}
	index, err := backend.BuildIndex(t.Context(), key, 5, "test", func(index resource.ResourceIndex) (int64, error) {
		items := make([]*resource.BulkIndexItem, 0, len(docs))
		for _, d := range docs {
			doc := &resource.IndexableDocument{
				Key:   &resourcepb.ResourceKey{Namespace: key.Namespace, Group: key.Group, Resource: key.Resource, Name: d.name},
				Title: d.title,
			}
			if d.deleted {
				doc.IsDeleted = new(true)
			}
			items = append(items, &resource.BulkIndexItem{Action: resource.ActionIndex, Doc: doc})
		}
		return 1, index.BulkIndex(&resource.BulkIndexRequest{Items: items})
	}, nil, false, time.Time{}, 0)
	require.NoError(t, err)
	bi, ok := index.(*bleveIndex)
	require.True(t, ok)

	textQuery := bleve.NewMatchQuery("hello")
	textQuery.SetField(resource.SEARCH_FIELD_TITLE)

	scores := func(q query.Query) map[string]float64 {
		req := bleve.NewSearchRequest(q)
		req.Size = 10
		res, err := bi.index.Search(req)
		require.NoError(t, err)
		out := map[string]float64{}
		for _, hit := range res.Hits {
			out[hit.ID] = hit.Score
		}
		return out
	}

	id := func(name string) string { return key.Namespace + "/" + key.Group + "/" + key.Resource + "/" + name }

	unscoped := scores(textQuery)
	require.Len(t, unscoped, len(docs))

	assert.Equal(t, map[string]float64{
		id("live-1"): unscoped[id("live-1")],
		id("live-2"): unscoped[id("live-2")],
	}, scores(scopeQuery(textQuery, false, 0)))

	assert.Equal(t, map[string]float64{
		id("trashed-1"): unscoped[id("trashed-1")],
		id("trashed-2"): unscoped[id("trashed-2")],
	}, scores(scopeQuery(textQuery, true, 0)))
}
