package vector

import (
	"database/sql"
	"embed"
	"fmt"
	"reflect"
	"text/template"
	"time"

	pgvector "github.com/pgvector/pgvector-go"

	"github.com/grafana/grafana/pkg/storage/unified/sql/sqltemplate"
)

//go:embed data/*.sql
var sqlTemplatesFS embed.FS

var sqlTemplates = template.Must(
	template.New("sql").ParseFS(sqlTemplatesFS, `data/*.sql`),
)

func mustTemplate(filename string) *template.Template {
	if t := sqlTemplates.Lookup(filename); t != nil {
		return t
	}
	panic(fmt.Sprintf("template file not found: %s", filename))
}

var (
	sqlVectorCollectionUpsert            = mustTemplate("vector_collection_upsert.sql")
	sqlVectorCollectionRefreshMeta       = mustTemplate("vector_collection_refresh_meta.sql")
	sqlVectorCollectionDeleteUIDs        = mustTemplate("vector_collection_delete_uids.sql")
	sqlVectorCollectionDeleteAll         = mustTemplate("vector_collection_delete_all.sql")
	sqlVectorCollectionDeleteSubresource = mustTemplate("vector_collection_delete_subresources.sql")
	sqlVectorNamespaceDeleteEmbeddings   = mustTemplate("vector_namespace_delete_embeddings.sql")
	sqlVectorNamespaceDeleteQueryCache   = mustTemplate("vector_namespace_delete_query_cache.sql")
	sqlVectorNamespaceDeleteRateBuckets  = mustTemplate("vector_namespace_delete_rate_buckets.sql")
	sqlVectorNamespaceDeletePromoted     = mustTemplate("vector_namespace_delete_promoted.sql")
	sqlVectorCollectionGetContent        = mustTemplate("vector_collection_get_content.sql")
	sqlVectorCollectionExists            = mustTemplate("vector_collection_exists.sql")
	sqlVectorCollectionContentVersion    = mustTemplate("vector_collection_content_version.sql")
	sqlVectorCollectionUpdateVersion     = mustTemplate("vector_collection_update_version.sql")
	sqlVectorCollectionSearch            = mustTemplate("vector_collection_search.sql")
	sqlVectorCollectionLexicalSearch     = mustTemplate("vector_collection_lexical_search.sql")
	sqlVectorBackfillJobsList            = mustTemplate("vector_backfill_jobs_list.sql")
	sqlVectorBackfillJobsCreate          = mustTemplate("vector_backfill_jobs_create.sql")
	sqlVectorBackfillJobsReopen          = mustTemplate("vector_backfill_jobs_reopen.sql")
	sqlVectorBackfillJobsUpdate          = mustTemplate("vector_backfill_jobs_update.sql")
	sqlVectorBackfillJobsSetError        = mustTemplate("vector_backfill_jobs_set_error.sql")
	sqlVectorBackfillJobsComplete        = mustTemplate("vector_backfill_jobs_complete.sql")
	sqlQueryCacheGet                     = mustTemplate("query_cache_get.sql")
	sqlQueryCacheCount                   = mustTemplate("query_cache_count.sql")
	sqlQueryCacheEvictOldest             = mustTemplate("query_cache_evict_oldest.sql")
	sqlQueryCacheInsert                  = mustTemplate("query_cache_insert.sql")
	sqlRateBucketIncrement               = mustTemplate("rate_bucket_increment.sql")
	sqlRateBucketSweep                   = mustTemplate("rate_bucket_sweep.sql")
	sqlVectorCatalogList                 = mustTemplate("vector_catalog_list.sql")
	sqlVectorCatalogInsert               = mustTemplate("vector_catalog_insert.sql")
)

// All queries target `embeddings` and include `resource = $1 AND
// namespace = $2` so nested partition pruning routes to one leaf.

type sqlVectorCollectionUpsertRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Vector    *Vector
	Embedding any // pgvector.HalfVector
}

// ComputeTS gates the stored tsvector to external rows; internal rows
// keep NULL (bleve is their lexical index).
func (r *sqlVectorCollectionUpsertRequest) ComputeTS() bool {
	return isExternalPartitionKey(r.Resource)
}

func (r *sqlVectorCollectionUpsertRequest) Validate() error {
	if r.Resource == "" {
		return fmt.Errorf("missing resource")
	}
	if r.Vector == nil {
		return fmt.Errorf("missing vector")
	}
	return nil
}

type sqlVectorCollectionRefreshMetaRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	UID       string
	Rows      []VectorMeta
}

func (r *sqlVectorCollectionRefreshMetaRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	if len(r.Rows) == 0 {
		return fmt.Errorf("rows must not be empty")
	}
	for i := range r.Rows {
		if r.Rows[i].Title == "" {
			return fmt.Errorf("rows[%d]: missing title", i)
		}
	}
	return nil
}

type sqlVectorCollectionDeleteUIDsRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	AllModels bool
	UIDs      []string
}

func (r *sqlVectorCollectionDeleteUIDsRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || (r.Model == "" && !r.AllModels) {
		return fmt.Errorf("missing required fields")
	}
	if len(r.UIDs) == 0 {
		return fmt.Errorf("uids must not be empty")
	}
	return nil
}

func (r *sqlVectorCollectionDeleteUIDsRequest) UIDsSlice() reflect.Value {
	return reflect.ValueOf(r.UIDs)
}

type sqlVectorCollectionDeleteAllRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	AllModels bool
	Limit     int
}

func (r *sqlVectorCollectionDeleteAllRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || (r.Model == "" && !r.AllModels) {
		return fmt.Errorf("missing required fields")
	}
	if r.Limit <= 0 {
		return fmt.Errorf("limit must be positive")
	}
	return nil
}

type sqlVectorCollectionDeleteSubresourcesRequest struct {
	sqltemplate.SQLTemplate
	Resource     string
	Namespace    string
	Model        string
	UID          string
	Subresources []string
}

func (r *sqlVectorCollectionDeleteSubresourcesRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	if len(r.Subresources) == 0 {
		return fmt.Errorf("subresources must not be empty")
	}
	return nil
}

func (r *sqlVectorCollectionDeleteSubresourcesRequest) SubresourcesSlice() reflect.Value {
	return reflect.ValueOf(r.Subresources)
}

// sqlVectorNamespaceDeleteRequest deletes every row for a namespace across all
// resources/models. Shared by the four namespace-scoped delete templates
// (embeddings, query_embedding_cache, vector_search_rate_buckets, vector_promoted).
type sqlVectorNamespaceDeleteRequest struct {
	sqltemplate.SQLTemplate
	Namespace string
}

func (r *sqlVectorNamespaceDeleteRequest) Validate() error {
	if r.Namespace == "" {
		return fmt.Errorf("missing namespace")
	}
	return nil
}

type sqlVectorCollectionExistsResponse struct {
	Exists int
}

type sqlVectorCollectionExistsRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	UID       string
	Response  *sqlVectorCollectionExistsResponse
}

func (r *sqlVectorCollectionExistsRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	return nil
}

func (r *sqlVectorCollectionExistsRequest) Results() (*sqlVectorCollectionExistsResponse, error) {
	cp := *r.Response
	return &cp, nil
}

// MinVersion is NULL (Valid=false) when the uid has no rows: MIN() over zero rows still returns one row.
type sqlVectorCollectionContentVersionResponse struct {
	MinVersion sql.NullInt64
}

type sqlVectorCollectionContentVersionRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	UID       string
	Response  *sqlVectorCollectionContentVersionResponse
}

func (r *sqlVectorCollectionContentVersionRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	return nil
}

func (r *sqlVectorCollectionContentVersionRequest) Results() (*sqlVectorCollectionContentVersionResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlVectorCollectionUpdateVersionRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	UID       string
	Version   int
}

func (r *sqlVectorCollectionUpdateVersionRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	if r.Version < 1 {
		return fmt.Errorf("version must be at least 1")
	}
	return nil
}

type sqlVectorBackfillJobsListResponse struct {
	ID          int64
	Model       string
	Resource    string
	StoppingRV  int64
	LastSeenKey sql.NullString
	IsComplete  bool
	LastError   sql.NullString
}

type sqlVectorBackfillJobsListRequest struct {
	sqltemplate.SQLTemplate
	Model    string
	Response *sqlVectorBackfillJobsListResponse
}

func (r *sqlVectorBackfillJobsListRequest) Validate() error {
	if r.Model == "" {
		return fmt.Errorf("missing model")
	}
	return nil
}

func (r *sqlVectorBackfillJobsListRequest) Results() (*sqlVectorBackfillJobsListResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlVectorCatalogListRequest struct {
	sqltemplate.SQLTemplate
	Response *sqlVectorCatalogListResponse
}

func (r *sqlVectorCatalogListRequest) Validate() error { return nil }

func (r *sqlVectorCatalogListRequest) Results() (*sqlVectorCatalogListResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlVectorCatalogListResponse struct {
	GroupName    string
	Resource     string
	PartitionKey string
	IsExternal   bool
}

type sqlVectorCatalogInsertRequest struct {
	sqltemplate.SQLTemplate
	GroupName    string
	Resource     string
	PartitionKey string
	IsExternal   bool
}

func (r *sqlVectorCatalogInsertRequest) Validate() error {
	if r.GroupName == "" || r.Resource == "" || r.PartitionKey == "" {
		return fmt.Errorf("missing required fields")
	}
	return nil
}

type sqlVectorBackfillJobsCreateRequest struct {
	sqltemplate.SQLTemplate
	Model          string
	Resource       string
	StoppingRV     int64
	ContentVersion int
}

func (r *sqlVectorBackfillJobsCreateRequest) Validate() error {
	if r.Model == "" {
		return fmt.Errorf("missing model")
	}
	if r.Resource == "" {
		return fmt.Errorf("missing resource")
	}
	if r.StoppingRV <= 0 {
		return fmt.Errorf("stopping_rv must be positive")
	}
	if r.ContentVersion < 1 {
		return fmt.Errorf("content_version must be at least 1")
	}
	return nil
}

// Reopens jobs whose content_version trails Version; the IN clause also matches the ”-catch-all job.
type sqlVectorBackfillJobsReopenRequest struct {
	sqltemplate.SQLTemplate
	Model      string
	Resource   string
	Version    int
	StoppingRV int64
}

func (r *sqlVectorBackfillJobsReopenRequest) Validate() error {
	if r.Model == "" {
		return fmt.Errorf("missing model")
	}
	if r.Resource == "" {
		return fmt.Errorf("missing resource")
	}
	if r.Version < 1 {
		return fmt.Errorf("version must be at least 1")
	}
	if r.StoppingRV <= 0 {
		return fmt.Errorf("stopping_rv must be positive")
	}
	return nil
}

type sqlVectorBackfillJobsUpdateRequest struct {
	sqltemplate.SQLTemplate
	ID          int64
	LastSeenKey sql.NullString
	LastError   sql.NullString
}

func (r *sqlVectorBackfillJobsUpdateRequest) Validate() error {
	if r.ID == 0 {
		return fmt.Errorf("missing id")
	}
	return nil
}

type sqlVectorBackfillJobsSetErrorRequest struct {
	sqltemplate.SQLTemplate
	ID        int64
	LastError sql.NullString
}

func (r *sqlVectorBackfillJobsSetErrorRequest) Validate() error {
	if r.ID == 0 {
		return fmt.Errorf("missing id")
	}
	return nil
}

type sqlVectorBackfillJobsCompleteRequest struct {
	sqltemplate.SQLTemplate
	ID int64
}

func (r *sqlVectorBackfillJobsCompleteRequest) Validate() error {
	if r.ID == 0 {
		return fmt.Errorf("missing id")
	}
	return nil
}

type sqlVectorCollectionGetContentResponse struct {
	Subresource string
	Content     string
	Folder      string
}

type sqlVectorCollectionGetContentRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	UID       string
	Response  *sqlVectorCollectionGetContentResponse
}

func (r *sqlVectorCollectionGetContentRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" || r.UID == "" {
		return fmt.Errorf("missing required fields")
	}
	return nil
}

func (r *sqlVectorCollectionGetContentRequest) Results() (*sqlVectorCollectionGetContentResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlVectorCollectionSearchResponse struct {
	UID         string
	Title       string
	Subresource string
	Content     string
	Score       float64
	Folder      string
	// []byte, not json.RawMessage: only *[]byte scans a NULL without error,
	// and metadata is optional on external rows.
	Metadata []byte
}

// MetadataFilterGroup is one filter rendered as OR-ed JSONB containments:
// ( metadata @> j1 OR metadata @> j2 ... ) — IN semantics across values.
type MetadataFilterGroup struct {
	JSONs []string // e.g. `{"datasource_uids":["ds1"]}`
}

// vectorSearchFilterArgs are the filter predicates shared by the semantic
// and lexical templates so the legs can't diverge. nil/empty = no filter.
type vectorSearchFilterArgs struct {
	UIDValues            []string
	FolderValues         []string
	MetadataFilterGroups []MetadataFilterGroup
}

func (r *vectorSearchFilterArgs) UIDFilter() bool {
	return len(r.UIDValues) > 0
}

func (r *vectorSearchFilterArgs) UIDFilterSlice() reflect.Value {
	return reflect.ValueOf(r.UIDValues)
}

func (r *vectorSearchFilterArgs) FolderFilter() bool {
	return len(r.FolderValues) > 0
}

func (r *vectorSearchFilterArgs) FolderFilterSlice() reflect.Value {
	return reflect.ValueOf(r.FolderValues)
}

type sqlVectorCollectionSearchRequest struct {
	sqltemplate.SQLTemplate
	Resource       string
	Namespace      string
	Model          string
	QueryEmbedding any // pgvector.HalfVector
	Limit          int64
	Response       *sqlVectorCollectionSearchResponse

	vectorSearchFilterArgs
}

func (r *sqlVectorCollectionSearchRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" {
		return fmt.Errorf("missing required fields")
	}
	if r.Limit <= 0 {
		return fmt.Errorf("limit must be positive")
	}
	return nil
}

func (r *sqlVectorCollectionSearchRequest) Results() (*sqlVectorCollectionSearchResponse, error) {
	// Response is reused across Scan calls; shallow copy is safe because Scan
	// allocates a fresh []byte for Metadata.
	cp := *r.Response
	return &cp, nil
}

type sqlVectorCollectionLexicalSearchResponse struct {
	UID         string
	Title       string
	Folder      string
	Subresource string
	Content     string
	// See sqlVectorCollectionSearchResponse.Metadata.
	Metadata []byte
	Rank     float64
}

type sqlVectorCollectionLexicalSearchRequest struct {
	sqltemplate.SQLTemplate
	Resource  string
	Namespace string
	Model     string
	Query     string
	Limit     int64
	Response  *sqlVectorCollectionLexicalSearchResponse

	vectorSearchFilterArgs
}

func (r *sqlVectorCollectionLexicalSearchRequest) Validate() error {
	if r.Resource == "" || r.Namespace == "" || r.Model == "" {
		return fmt.Errorf("missing required fields")
	}
	if r.Query == "" {
		return fmt.Errorf("query must not be empty")
	}
	if r.Limit <= 0 {
		return fmt.Errorf("limit must be positive")
	}
	return nil
}

func (r *sqlVectorCollectionLexicalSearchRequest) Results() (*sqlVectorCollectionLexicalSearchResponse, error) {
	// Response is reused across Scan calls; shallow copy is safe because Scan
	// allocates a fresh []byte for Metadata.
	cp := *r.Response
	return &cp, nil
}

type sqlQueryCacheGetResponse struct {
	Embedding pgvector.HalfVector
}

type sqlQueryCacheGetRequest struct {
	sqltemplate.SQLTemplate
	Namespace string
	Model     string
	QueryHash string
	Response  *sqlQueryCacheGetResponse
}

func (r *sqlQueryCacheGetRequest) Validate() error {
	if r.Namespace == "" || r.Model == "" || r.QueryHash == "" {
		return fmt.Errorf("missing required fields")
	}
	return nil
}

func (r *sqlQueryCacheGetRequest) Results() (*sqlQueryCacheGetResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlQueryCacheCountResponse struct {
	Count int64
}

type sqlQueryCacheCountRequest struct {
	sqltemplate.SQLTemplate
	Namespace string
	Response  *sqlQueryCacheCountResponse
}

func (r *sqlQueryCacheCountRequest) Validate() error {
	if r.Namespace == "" {
		return fmt.Errorf("missing namespace")
	}
	return nil
}

func (r *sqlQueryCacheCountRequest) Results() (*sqlQueryCacheCountResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlQueryCacheEvictOldestRequest struct {
	sqltemplate.SQLTemplate
	Namespace string
	Limit     int64
}

func (r *sqlQueryCacheEvictOldestRequest) Validate() error {
	if r.Namespace == "" {
		return fmt.Errorf("missing namespace")
	}
	if r.Limit <= 0 {
		return fmt.Errorf("limit must be positive")
	}
	return nil
}

type sqlQueryCacheInsertRequest struct {
	sqltemplate.SQLTemplate
	Namespace string
	Model     string
	QueryHash string
	Embedding any // pgvector.HalfVector
}

func (r *sqlQueryCacheInsertRequest) Validate() error {
	if r.Namespace == "" || r.Model == "" || r.QueryHash == "" {
		return fmt.Errorf("missing required fields")
	}
	if r.Embedding == nil {
		return fmt.Errorf("missing embedding")
	}
	return nil
}

type sqlRateBucketIncrementResponse struct {
	Count int64
}

type sqlRateBucketIncrementRequest struct {
	sqltemplate.SQLTemplate
	Namespace   string
	WindowStart time.Time
	Response    *sqlRateBucketIncrementResponse
}

func (r *sqlRateBucketIncrementRequest) Validate() error {
	if r.Namespace == "" {
		return fmt.Errorf("missing namespace")
	}
	if r.WindowStart.IsZero() {
		return fmt.Errorf("missing window_start")
	}
	return nil
}

func (r *sqlRateBucketIncrementRequest) Results() (*sqlRateBucketIncrementResponse, error) {
	cp := *r.Response
	return &cp, nil
}

type sqlRateBucketSweepRequest struct {
	sqltemplate.SQLTemplate
	Cutoff time.Time
}

func (r *sqlRateBucketSweepRequest) Validate() error {
	if r.Cutoff.IsZero() {
		return fmt.Errorf("missing cutoff")
	}
	return nil
}
