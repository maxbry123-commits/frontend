package reconciler

import (
	"context"
	"encoding/json"
	"errors"
	"iter"
	"maps"
	"net/http"
	"sync"
	"time"

	"github.com/grafana/grafana/pkg/storage/unified/resource"
	"github.com/grafana/grafana/pkg/storage/unified/resourcepb"
	"github.com/grafana/grafana/pkg/storage/unified/search/embed"
	"github.com/grafana/grafana/pkg/storage/unified/search/embed/embedder"
	"github.com/grafana/grafana/pkg/storage/unified/search/vector"
	"github.com/grafana/grafana/pkg/storage/unified/search/vector/filter"
)

// fakeStorage stubs the bits of resource.StorageBackend the reconciler uses.
// ListModifiedSince returns the configured changes (filtered by sinceRv)
// and a latestRv equal to the highest RV in the slice. Empty namespace
// on the request runs cross-namespace, mirroring the real backends.
type fakeStorage struct {
	resource.UnimplementedStorageBackend
	mu       sync.Mutex
	changes  []*resource.ModifiedResource
	listErr  error
	watchErr error
	watchCh  chan *resource.WrittenEvent
	itemErr  error // returned from the iterator partway through
	itemErrI int   // index after which to inject itemErr

	latestRvOverride int64 // RV reported as the snapshot ceiling, instead of the highest in changes
	lookback         int64 // widens the listing floor to sinceRv-lookback, like the backend's searchLookback

	// onYield, if set, fires once per resource the ListModifiedSince
	// iterator yields — lets tests observe iterator progress at each flush.
	onYield func()

	lastCalledWith []*time.Time // the lastCalledWithSinceRv argument of every ListModifiedSince call

	// folders backs ReadResource for FolderTitleResolver: namespace+"/"+uid
	// -> title. An unset entry reads as NotFound.
	folders map[string]string
	readErr error
}

// setFolderTitle makes ReadResource resolve namespace/uid to title, so the
// reconciler's (uncached) FolderTitleResolver can look it up.
func (f *fakeStorage) setFolderTitle(namespace, uid, title string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.folders == nil {
		f.folders = map[string]string{}
	}
	f.folders[namespace+"/"+uid] = title
}

// emit synchronously delivers a watch event on the channel set up by
// startWatch. Tests use it to drive the watch path.
func (f *fakeStorage) emit(ev *resource.WrittenEvent) {
	f.mu.Lock()
	ch := f.watchCh
	f.mu.Unlock()
	if ch == nil {
		return
	}
	ch <- ev
}

func (f *fakeStorage) WriteEvent(context.Context, resource.WriteEvent) (int64, error) {
	panic("not implemented")
}

// ReadResource backs FolderTitleResolver.Title. Titles are seeded via
// setFolderTitle; anything else reads as NotFound, matching a folder that
// doesn't exist rather than a real storage fault (use readErr for that).
func (f *fakeStorage) ReadResource(_ context.Context, req *resourcepb.ReadRequest) *resource.BackendReadResponse {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.readErr != nil {
		return &resource.BackendReadResponse{Error: &resourcepb.ErrorResult{Code: http.StatusInternalServerError, Message: f.readErr.Error()}}
	}
	title, ok := f.folders[req.Key.Namespace+"/"+req.Key.Name]
	if !ok {
		return &resource.BackendReadResponse{Error: &resourcepb.ErrorResult{Code: http.StatusNotFound}}
	}
	value, _ := json.Marshal(map[string]any{"spec": map[string]any{"title": title}})
	return &resource.BackendReadResponse{Value: value}
}
func (f *fakeStorage) ListIterator(context.Context, *resourcepb.ListRequest, func(resource.ListIterator) error) (int64, error) {
	panic("not implemented")
}
func (f *fakeStorage) ListHistory(context.Context, *resourcepb.ListRequest, func(resource.ListIterator) error) (int64, error) {
	panic("not implemented")
}

// WatchWriteEvents returns a channel the test can push events onto via
// emit(). Closing happens when the parent ctx ends (handled by the test
// harness). Tests that need watch errors set watchErr.
func (f *fakeStorage) WatchWriteEvents(ctx context.Context) (<-chan *resource.WrittenEvent, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.watchErr != nil {
		return nil, f.watchErr
	}
	if f.watchCh == nil {
		f.watchCh = make(chan *resource.WrittenEvent, 16)
	}
	return f.watchCh, nil
}

// GetResourceStats returns one ResourceStats per distinct
// (namespace, group, resource) seen in `changes`. Used elsewhere in
// the codebase; the reconciler doesn't call it directly post-refactor.
func (f *fakeStorage) GetResourceStats(_ context.Context, nsr resource.NamespacedResource, _ int) ([]resource.ResourceStats, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	seen := map[string]resource.ResourceStats{}
	for _, c := range f.changes {
		if c.Key.Group != nsr.Group || c.Key.Resource != nsr.Resource {
			continue
		}
		k := c.Key.Namespace
		s, ok := seen[k]
		if !ok {
			s = resource.ResourceStats{
				NamespacedResource: resource.NamespacedResource{
					Namespace: c.Key.Namespace,
					Group:     c.Key.Group,
					Resource:  c.Key.Resource,
				},
			}
		}
		s.Count++
		if c.ResourceVersion > s.ResourceVersion {
			s.ResourceVersion = c.ResourceVersion
		}
		seen[k] = s
	}
	out := make([]resource.ResourceStats, 0, len(seen))
	for _, s := range seen {
		out = append(out, s)
	}
	return out, nil
}

func (f *fakeStorage) ListModifiedSince(_ context.Context, key resource.NamespacedResource, sinceRv int64, lastCalledWithSinceRv *time.Time) (int64, iter.Seq2[*resource.ModifiedResource, error]) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.lastCalledWith = append(f.lastCalledWith, lastCalledWithSinceRv)
	if f.listErr != nil {
		err := f.listErr
		return 0, func(yield func(*resource.ModifiedResource, error) bool) {
			yield(nil, err)
		}
	}
	// Snapshot the slice + per-iteration error config so the iterator
	// closes over a stable view. The reconciler runs the iter outside the
	// lock, and the test may mutate state afterwards. Empty namespace
	// runs cross-namespace, mirroring the real backends.
	matches := make([]*resource.ModifiedResource, 0, len(f.changes))
	var latestRv int64
	for _, c := range f.changes {
		// latestRv mirrors the KV backend: the latest event RV in the
		// store, across every resource and independent of both the
		// group/resource filter and the sinceRv cutoff below.
		if c.ResourceVersion > latestRv {
			latestRv = c.ResourceVersion
		}
		if c.Key.Group != key.Group || c.Key.Resource != key.Resource {
			continue
		}
		if key.Namespace != "" && c.Key.Namespace != key.Namespace {
			continue
		}
		// A non-nil lastCalledWithSinceRv makes the real backend skip its
		// lookback window, so mirror that here.
		floor := sinceRv
		if lastCalledWithSinceRv == nil {
			floor -= f.lookback
		}
		if c.ResourceVersion <= floor {
			continue
		}
		matches = append(matches, c)
	}
	if f.latestRvOverride != 0 {
		latestRv = f.latestRvOverride
	}
	itemErr := f.itemErr
	itemErrI := f.itemErrI
	onYield := f.onYield
	return latestRv, func(yield func(*resource.ModifiedResource, error) bool) {
		for i, c := range matches {
			if itemErr != nil && i == itemErrI {
				if !yield(nil, itemErr) {
					return
				}
				continue
			}
			if onYield != nil {
				onYield()
			}
			if !yield(c, nil) {
				return
			}
		}
	}
}

// fakeVector records calls and lets tests inspect upserts/deletes/checkpoint advancement.
type fakeVector struct {
	mu sync.Mutex

	latestRV     int64
	upserts      [][]vector.Vector
	deletes      []deleteCall
	delsubs      []deleteSubsCall
	storedSubs   map[string]map[string]string // ns|model|res|uid -> sub -> content
	storedFolder map[string]string            // ns|model|res|uid -> folder
	upsertErr    error
	upsertErrFn  func(vs []vector.Vector) error // dynamic error decision
	deleteErr    error

	// onUpsert, if set, fires at the start of each upsert. Paired with
	// fakeStorage.onYield to snapshot iterator progress at each flush.
	onUpsert func()

	lockUnavailable bool
	lockAttempts    int
	lockReleases    int

	setLatestRVCalls int
	setLatestRVErr   error
	getLatestRVErr   error

	ensuredPartitions  []string
	ensurePartitionErr error

	backfillJobs      []backfillJobCall
	createBackfillErr error

	counts    []vector.EmbeddingCount
	countsErr error
}

type backfillJobCall struct {
	Model          string
	Resource       string
	StoppingRV     int64
	ContentVersion int
}

type deleteCall struct{ Namespace, Model, Resource, UID string }
type deleteSubsCall struct {
	Namespace, Model, Resource, UID string
	Subresources                    []string
}

func newFakeVector() *fakeVector {
	return &fakeVector{
		storedSubs:   map[string]map[string]string{},
		storedFolder: map[string]string{},
	}
}

func subsKey(ns, model, res, uid string) string { return ns + "|" + model + "|" + res + "|" + uid }

func (f *fakeVector) ResolveCollection(_ context.Context, group, resource string) (vector.Collection, bool, error) {
	return vector.Collection{Group: group, Resource: resource, PartitionKey: resource}, true, nil
}

func (f *fakeVector) EnsureCollection(_ context.Context, group, resource string, isExternal bool) (vector.Collection, error) {
	key := resource
	if isExternal {
		key += "_external"
	}
	return vector.Collection{Group: group, Resource: resource, PartitionKey: key, IsExternal: isExternal}, nil
}

func (f *fakeVector) Search(context.Context, string, string, string, []float32, int, ...vector.SearchFilter) ([]vector.VectorSearchResult, error) {
	return nil, nil
}
func (f *fakeVector) Upsert(_ context.Context, vs []vector.Vector) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.upsertLocked(vs)
}

func (f *fakeVector) UpsertReplaceSubresources(_ context.Context, ns, model, res, uid string, changed []vector.Vector, _ []vector.VectorMeta, desired []string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	// Mirror the real backend: delete subresources not in `desired`, then upsert `changed`.
	keep := make(map[string]struct{}, len(desired))
	for _, s := range desired {
		keep[s] = struct{}{}
	}
	key := subsKey(ns, model, res, uid)
	stored := f.storedSubs[key]
	var stale []string
	for sub := range stored {
		if _, ok := keep[sub]; !ok {
			stale = append(stale, sub)
		}
	}
	if len(stale) > 0 {
		f.delsubs = append(f.delsubs, deleteSubsCall{ns, model, res, uid, stale})
		for _, s := range stale {
			delete(stored, s)
		}
	}
	if len(changed) == 0 {
		return nil
	}
	return f.upsertLocked(changed)
}

func (f *fakeVector) upsertLocked(vs []vector.Vector) error {
	if f.onUpsert != nil {
		f.onUpsert()
	}
	if f.upsertErrFn != nil {
		if err := f.upsertErrFn(vs); err != nil {
			return err
		}
	}
	if f.upsertErr != nil {
		return f.upsertErr
	}
	f.upserts = append(f.upserts, vs)
	for _, v := range vs {
		k := subsKey(v.Namespace, v.Model, v.Resource, v.UID)
		if f.storedSubs[k] == nil {
			f.storedSubs[k] = map[string]string{}
		}
		f.storedSubs[k][v.Subresource] = v.Content
		f.storedFolder[k] = v.Folder
	}
	return nil
}
func (f *fakeVector) DeleteRows(_ context.Context, ns, model, res string, sel vector.DeleteSelector) (int64, bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.deleteErr != nil {
		return 0, false, f.deleteErr
	}
	for _, uid := range sel.UIDs {
		f.deletes = append(f.deletes, deleteCall{ns, model, res, uid})
		delete(f.storedSubs, subsKey(ns, model, res, uid))
	}
	return int64(len(sel.UIDs)), false, nil
}

// storedContentFor returns the subresource content currently indexed for
// a UID, so tests can assert a replay left it alone.
func (f *fakeVector) storedContentFor(ns, res, uid string) map[string]string {
	f.mu.Lock()
	defer f.mu.Unlock()
	return maps.Clone(f.storedSubs[subsKey(ns, testModel, res, uid)])
}

func (f *fakeVector) DeleteSubresources(_ context.Context, ns, model, res, uid string, subs []string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.delsubs = append(f.delsubs, deleteSubsCall{ns, model, res, uid, subs})
	if m := f.storedSubs[subsKey(ns, model, res, uid)]; m != nil {
		for _, s := range subs {
			delete(m, s)
		}
	}
	return nil
}
func (f *fakeVector) UpdateMetadata(_ context.Context, _, _ string, _ *filter.Filter, _ json.RawMessage, _ []string) (int64, error) {
	return 0, nil
}

func (f *fakeVector) DeleteNamespace(_ context.Context, _ string) (int64, error) {
	return 0, nil
}
func (f *fakeVector) GetSubresourceContent(_ context.Context, ns, model, res, uid string) (map[string]string, string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	key := subsKey(ns, model, res, uid)
	out := map[string]string{}
	maps.Copy(out, f.storedSubs[key])
	if len(out) == 0 {
		return nil, "", nil
	}
	return out, f.storedFolder[key], nil
}
func (f *fakeVector) Exists(context.Context, string, string, string, string) (bool, error) {
	return false, nil
}
func (f *fakeVector) ContentVersion(context.Context, string, string, string, string) (int, bool, error) {
	return 0, false, nil
}
func (f *fakeVector) UpdateContentVersion(context.Context, string, string, string, string, int) error {
	return nil
}
func (f *fakeVector) CountStoredEmbeddings(context.Context) ([]vector.EmbeddingCount, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.counts, f.countsErr
}
func (f *fakeVector) GetLatestRV(context.Context) (int64, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.getLatestRVErr != nil {
		return 0, f.getLatestRVErr
	}
	return f.latestRV, nil
}
func (f *fakeVector) SetLatestRV(_ context.Context, rv int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.setLatestRVCalls++
	if f.setLatestRVErr != nil {
		return f.setLatestRVErr
	}
	if rv > f.latestRV {
		f.latestRV = rv
	}
	return nil
}
func (f *fakeVector) ListIncompleteBackfillJobs(context.Context, string) ([]vector.BackfillJob, error) {
	return nil, nil
}
func (f *fakeVector) EnsureResourcePartition(_ context.Context, res string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.ensurePartitionErr != nil {
		return f.ensurePartitionErr
	}
	f.ensuredPartitions = append(f.ensuredPartitions, res)
	return nil
}
func (f *fakeVector) CreateBackfillJob(_ context.Context, model, res string, stoppingRV int64, contentVersion int) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.createBackfillErr != nil {
		return f.createBackfillErr
	}
	f.backfillJobs = append(f.backfillJobs, backfillJobCall{Model: model, Resource: res, StoppingRV: stoppingRV, ContentVersion: contentVersion})
	return nil
}

func (f *fakeVector) ReopenStaleBackfillJobs(context.Context, string, string, int, int64) (bool, error) {
	return false, nil
}
func (f *fakeVector) UpdateBackfillJobCheckpoint(context.Context, int64, string, string) error {
	return nil
}
func (f *fakeVector) MarkBackfillJobError(context.Context, int64, string) error { return nil }
func (f *fakeVector) CompleteBackfillJob(context.Context, int64) error          { return nil }
func (f *fakeVector) TryAcquireBackfillLock(context.Context) (func(), bool, error) {
	return func() {}, true, nil
}
func (f *fakeVector) TryAcquireReconcilerLock(context.Context) (func(), bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.lockAttempts++
	if f.lockUnavailable {
		return nil, false, nil
	}
	return func() {
		f.mu.Lock()
		defer f.mu.Unlock()
		f.lockReleases++
	}, true, nil
}
func (f *fakeVector) WithEntityLock(ctx context.Context, _, _, _ string, fn func(context.Context) error) error {
	return fn(ctx)
}

// fakeBackfiller records that Run was invoked and blocks until ctx is
// cancelled, mirroring the real backfiller's lifetime semantics.
type fakeBackfiller struct {
	mu      sync.Mutex
	runs    int
	blocked bool
}

func (f *fakeBackfiller) Run(ctx context.Context) error {
	f.mu.Lock()
	f.runs++
	block := f.blocked
	f.mu.Unlock()
	if block {
		<-ctx.Done()
		return ctx.Err()
	}
	return nil
}

func (f *fakeBackfiller) runCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.runs
}

// fakeText is a deterministic embedder used by the reconciler. It
// records each EmbedText invocation so tests can assert on the *number*
// of pooled calls — the whole point of the reconcile-cycle batching.
type fakeText struct {
	mu       sync.Mutex
	dim      int
	calls    int     // number of EmbedText invocations
	textSets [][]int // counts of texts per call (per-call sizes)
	failNext error   // if non-nil, returned from the next EmbedText call
}

func (f *fakeText) EmbedText(_ context.Context, in embedder.EmbedTextInput) (embedder.EmbedTextOutput, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.calls++
	f.textSets = append(f.textSets, []int{len(in.Texts)})
	if f.failNext != nil {
		err := f.failNext
		f.failNext = nil
		return embedder.EmbedTextOutput{}, err
	}
	out := embedder.EmbedTextOutput{Embeddings: make([]embedder.Embedding, len(in.Texts))}
	for i := range in.Texts {
		dense := make([]float32, f.dim)
		for j := range dense {
			dense[j] = 0.5
		}
		out.Embeddings[i] = embedder.Embedding{Dense: dense}
	}
	return out, nil
}

func newFakeEmbedder(text *fakeText) *embedder.Embedder {
	return &embedder.Embedder{
		TextEmbedder: text,
		Model:        "test-model",
		VectorType:   embedder.VectorTypeDense,
		Metric:       embedder.CosineDistance,
		Dimensions:   uint32(text.dim),
	}
}

var errBoom = errors.New("boom")

// fakeBroadcaster is the smallest viable resource.Broadcaster impl for
// the reconciler tests. It returns a single subscriber channel, lets
// the test push events via emit(), and records unsubscribe calls so
// we can assert clean shutdown.
type fakeBroadcaster struct {
	mu              sync.Mutex
	subscribeErr    error
	ch              chan *resource.WrittenEvent
	subscribeCalls  int
	unsubscribeCh   <-chan *resource.WrittenEvent
	unsubscribeOnce sync.Once
}

func newFakeBroadcaster() *fakeBroadcaster {
	return &fakeBroadcaster{ch: make(chan *resource.WrittenEvent, 16)}
}

func (b *fakeBroadcaster) Subscribe(_ context.Context, _, _ string) (<-chan *resource.WrittenEvent, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.subscribeCalls++
	if b.subscribeErr != nil {
		return nil, b.subscribeErr
	}
	return b.ch, nil
}

func (b *fakeBroadcaster) Unsubscribe(ch <-chan *resource.WrittenEvent) {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.unsubscribeCh = ch
	// Closing once so consumeWatchEvents exits via the `!ok` branch
	// (the real broadcaster has the same behavior on Unsubscribe).
	b.unsubscribeOnce.Do(func() { close(b.ch) })
}

func (b *fakeBroadcaster) emit(ev *resource.WrittenEvent) {
	b.ch <- ev
}

// fakeBuilder is a second embed.Builder, for the cross-builder cursor
// behavior the single real builder can't reach.
type fakeBuilder struct {
	group    string
	resource string
}

func (b fakeBuilder) Group() string            { return b.group }
func (b fakeBuilder) Resource() string         { return b.resource }
func (b fakeBuilder) MaxItemsPerResource() int { return 0 }
func (b fakeBuilder) Version() int             { return 1 }

func (b fakeBuilder) Extract(_ context.Context, key *resourcepb.ResourceKey, value []byte, _ string) ([]embed.Item, error) {
	if len(value) == 0 {
		return nil, nil
	}
	if string(value) == "boom" {
		return nil, errBoom
	}
	return []embed.Item{{
		UID:     key.Name,
		Title:   key.Name,
		Content: string(value),
	}}, nil
}

// hasUpsertFor reports whether any upsert wrote a vector for this
// resource, for tests that care that a document was embedded at all.
func (f *fakeVector) hasUpsertFor(namespace, resource, uid string) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, batch := range f.upserts {
		for _, v := range batch {
			if v.Namespace == namespace && v.Resource == resource && v.UID == uid {
				return true
			}
		}
	}
	return false
}
