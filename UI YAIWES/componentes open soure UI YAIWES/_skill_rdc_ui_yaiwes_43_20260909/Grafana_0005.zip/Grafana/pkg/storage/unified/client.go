package unified

import (
	"context"
	"fmt"
	"path/filepath"
	"time"

	"github.com/fullstorydev/grpchan"
	grpcUtils "github.com/grafana/grafana/pkg/storage/unified/resource/grpc"
	"github.com/grafana/grafana/pkg/storage/unified/resourcepb"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc"
	"go.opentelemetry.io/otel"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/keepalive"

	"github.com/grafana/authlib/types"
	"github.com/grafana/dskit/flagext"
	"github.com/grafana/dskit/grpcclient"
	"github.com/grafana/dskit/middleware"
	"github.com/grafana/dskit/services"
	infraDB "github.com/grafana/grafana/pkg/infra/db"
	"github.com/grafana/grafana/pkg/infra/nats"
	"github.com/grafana/grafana/pkg/infra/tracing"
	secrets "github.com/grafana/grafana/pkg/registry/apis/secret/contracts"
	"github.com/grafana/grafana/pkg/services/apiserver/options"
	authnGrpcUtils "github.com/grafana/grafana/pkg/services/authn/grpcutils"
	"github.com/grafana/grafana/pkg/services/featuremgmt"
	"github.com/grafana/grafana/pkg/setting"
	"github.com/grafana/grafana/pkg/storage/legacysql"
	"github.com/grafana/grafana/pkg/storage/unified/federated"
	"github.com/grafana/grafana/pkg/storage/unified/resource"
	"github.com/grafana/grafana/pkg/storage/unified/resource/kv"
	"github.com/grafana/grafana/pkg/storage/unified/search"
	"github.com/grafana/grafana/pkg/storage/unified/search/builders"
	"github.com/grafana/grafana/pkg/storage/unified/search/embed/embedder"
	"github.com/grafana/grafana/pkg/storage/unified/search/rerank"
	"github.com/grafana/grafana/pkg/storage/unified/search/vector"
	"github.com/grafana/grafana/pkg/storage/unified/sql"
	sqldb "github.com/grafana/grafana/pkg/storage/unified/sql/db"
	"github.com/grafana/grafana/pkg/util/scheduler"
)

type Options struct {
	Cfg            *setting.Cfg
	Features       featuremgmt.FeatureToggles
	DB             infraDB.DB
	Tracer         tracing.Tracer
	Reg            prometheus.Registerer
	Authzc         types.AccessClient
	Docs           resource.DocumentBuilderSupplier
	SecureValues   secrets.InlineSecureValueSupport
	VectorBackend  vector.VectorBackend
	Embedder       *embedder.Embedder
	Reranker       *rerank.Reranker
	DashboardStats builders.DashboardStats
	KV             kv.KV
	EDB            sqldb.DBProvider
	// ExperimentalKV, when set, routes flagged use-cases in the in-process KV
	// storage backend to an alternative KV. Nil disables the routing.
	ExperimentalKV *resource.ExperimentalKVOptions
	// Publisher announces committed writes on the NATS bus. It is wired into the
	// in-process storage backend so a monolith run (storage_type=unified) emits
	// the same resource-change notifications as the storage-server module. Nil-safe
	// and gated on Enabled(): a disabled bus simply publishes nothing.
	Publisher nats.Publisher
	// Subscriber backs the shadow NATS notifier when nats.notifier_shadow is on.
	// Like Publisher, it is wired in-process so a monolith can run the shadow;
	// gated on Enabled(), so a disabled bus starts nothing.
	Subscriber nats.Subscriber
}

// natsEventSubscriber adapts nats.Subscriber to resource.EventSubscriber for the
// in-process shadow notifier (mirrors the adapter in pkg/server). Needed because
// nats.Subscriber.Subscribe takes a nats.MessageHandler and variadic options the
// resource interface does not expose.
type natsEventSubscriber struct {
	sub nats.Subscriber
}

func (a natsEventSubscriber) Enabled() bool { return a.sub.Enabled() }

func (a natsEventSubscriber) Subscribe(ctx context.Context, subject string, handler func(subject string, data []byte)) (resource.Subscription, error) {
	return a.sub.Subscribe(ctx, subject, nats.MessageHandler(handler))
}

func NatsStorageBackendOptions(cfg *setting.Cfg, publisher nats.Publisher, subscriber nats.Subscriber) []sql.StorageBackendOption {
	var opts []sql.StorageBackendOption
	if publisher != nil {
		opts = append(opts, sql.WithEventPublisher(publisher))
	}
	if subscriber == nil {
		return opts
	}
	switch {
	case cfg.NATS.Notifier:
		opts = append(opts, sql.WithNatsNotifier(natsEventSubscriber{sub: subscriber}))
	case cfg.NATS.NotifierShadow:
		opts = append(opts, sql.WithNatsNotifierShadow(natsEventSubscriber{sub: subscriber}))
	}
	return opts
}

type clientMetrics struct {
	requestDuration *prometheus.HistogramVec
	requestRetries  *prometheus.CounterVec
}

// This adds a UnifiedStorage client into the wire dependency tree
func ProvideUnifiedStorageClient(opts *Options,
	storageMetrics *resource.StorageMetrics,
	indexMetrics *resource.BleveIndexMetrics,
	vectorMetrics *resource.VectorMetrics,
	gcGate *resource.GCGate,
) (resource.ResourceClient, error) {
	apiserverCfg := opts.Cfg.SectionWithEnvOverrides("grafana-apiserver")
	client, err := newClient(options.StorageOptions{
		StorageType:             options.StorageType(apiserverCfg.Key("storage_type").MustString(string(options.StorageTypeUnified))),
		DataPath:                apiserverCfg.Key("storage_path").MustString(filepath.Join(opts.Cfg.DataPath, "grafana-apiserver")),
		Address:                 apiserverCfg.Key("address").MustString(""),
		SearchServerAddress:     apiserverCfg.Key("search_server_address").MustString(""),
		BlobStoreURL:            apiserverCfg.Key("blob_url").MustString(""),
		BlobThresholdBytes:      apiserverCfg.Key("blob_threshold_bytes").MustInt(options.BlobThresholdDefault),
		GrpcClientKeepaliveTime: apiserverCfg.Key("grpc_client_keepalive_time").MustDuration(options.DefaultGrpcClientKeepaliveTime),
	}, opts.Cfg, opts.Features, opts.Tracer, opts.Reg, opts.Authzc, opts.Docs, storageMetrics, indexMetrics, vectorMetrics, opts.SecureValues, opts.VectorBackend, opts.Embedder, opts.Reranker, opts.DashboardStats, opts.KV, opts.EDB, gcGate, opts.Publisher, opts.Subscriber, opts.ExperimentalKV)
	if err == nil {
		// Used to get the folder stats
		// Pass cfg directly so the federated client reads the current dual-writer mode
		// at query time, not at creation time. This is important because auto-migration
		// may set Mode5 after the client is created during startup.
		client = federated.NewFederatedClient(
			client, // The original
			legacysql.NewDatabaseProvider(opts.DB),
			opts.Cfg,
		)
	}

	return client, err
}

func newClient(opts options.StorageOptions,
	cfg *setting.Cfg,
	features featuremgmt.FeatureToggles,
	tracer tracing.Tracer,
	reg prometheus.Registerer,
	authzc types.AccessClient,
	docs resource.DocumentBuilderSupplier,
	storageMetrics *resource.StorageMetrics,
	indexMetrics *resource.BleveIndexMetrics,
	vectorMetrics *resource.VectorMetrics,
	secure secrets.InlineSecureValueSupport,
	vectorBackend vector.VectorBackend,
	embedderInstance *embedder.Embedder,
	rerankerInstance *rerank.Reranker,
	dashboardStats builders.DashboardStats,
	kvStore kv.KV,
	eDB sqldb.DBProvider,
	gcGate *resource.GCGate,
	eventPublisher nats.Publisher,
	eventSubscriber nats.Subscriber,
	experimentalKV *resource.ExperimentalKVOptions,
) (resource.ResourceClient, error) {
	ctx := context.Background()

	switch opts.StorageType {
	case options.StorageTypeFile:
		backend, err := sql.NewFileBackend(cfg, kvStore)
		if err != nil {
			return nil, err
		}

		server, err := resource.NewResourceServer(resource.ResourceServerOptions{
			Backend: backend,
			Blob: resource.BlobConfig{
				URL: opts.BlobStoreURL,
			},
		})
		if err != nil {
			return nil, err
		}
		return resource.NewLocalResourceClient(server), nil

	case options.StorageTypeUnifiedGrpc:
		if opts.Address == "" {
			return nil, fmt.Errorf("expecting address for storage_type: %s", opts.StorageType)
		}

		var (
			conn      grpc.ClientConnInterface
			indexConn grpc.ClientConnInterface
			err       error
			metrics   = newClientMetrics(reg)
		)

		conn, err = grpcConn(opts.Address, metrics, opts.GrpcClientKeepaliveTime)
		if err != nil {
			return nil, err
		}

		if opts.SearchServerAddress != "" {
			indexConn, err = grpcConn(opts.SearchServerAddress, metrics, opts.GrpcClientKeepaliveTime)

			if err != nil {
				return nil, err
			}
		} else {
			indexConn = conn
		}

		// Create a resource client
		return resource.NewResourceClient(conn, indexConn, cfg, features, tracer)

	default:
		searchOptions, err := search.NewSearchOptions(cfg, docs, indexMetrics, nil, nil)
		if err != nil {
			return nil, err
		}

		storageOpts := append([]sql.StorageBackendOption{sql.WithVectorBackend(vectorBackend)},
			NatsStorageBackendOptions(cfg, eventPublisher, eventSubscriber)...)
		if experimentalKV != nil {
			storageOpts = append(storageOpts, sql.WithExperimentalKV(experimentalKV))
		}
		backend, err := sql.NewStorageBackend(cfg, eDB, reg, storageMetrics, false, kvStore, gcGate, storageOpts...)
		if err != nil {
			return nil, err
		}

		if backendService, ok := backend.(services.Service); ok {
			if err := services.StartAndAwaitRunning(ctx, backendService); err != nil {
				return nil, fmt.Errorf("failed to start storage backend: %w", err)
			}
		}

		serverOptions := sql.ServerOptions{
			Backend:        backend,
			VectorBackend:  vectorBackend,
			Embedder:       embedderInstance,
			Reranker:       rerankerInstance,
			Cfg:            cfg,
			Tracer:         tracer,
			Reg:            reg,
			AccessClient:   authzc,
			SearchOptions:  searchOptions,
			StorageMetrics: storageMetrics,
			IndexMetrics:   indexMetrics,
			VectorMetrics:  vectorMetrics,
			Features:       features,
			SecureValues:   secure,
			DashboardStats: dashboardStats,
		}

		if cfg.QOSEnabled {
			qosReg := prometheus.WrapRegistererWithPrefix("resource_server_qos_", reg)
			queue := scheduler.NewQueue(&scheduler.QueueOptions{
				MaxSizePerTenant: cfg.QOSMaxSizePerTenant,
				Registerer:       qosReg,
				Logger:           cfg.Logger,
			})
			if err := services.StartAndAwaitRunning(ctx, queue); err != nil {
				return nil, fmt.Errorf("failed to start queue: %w", err)
			}
			scheduler, err := scheduler.NewScheduler(queue, &scheduler.Config{
				NumWorkers: cfg.QOSNumberWorker,
				Logger:     cfg.Logger,
			})
			if err != nil {
				return nil, fmt.Errorf("failed to create scheduler: %w", err)
			}

			err = services.StartAndAwaitRunning(ctx, scheduler)
			if err != nil {
				return nil, fmt.Errorf("failed to start scheduler: %w", err)
			}
			serverOptions.QOSQueue = queue
		}

		// only enable if an overrides file path is provided
		if cfg.OverridesFilePath != "" {
			overridesSvc, err := resource.NewOverridesService(ctx, cfg.Logger, reg, tracer, resource.ReloadOptions{
				FilePath:     cfg.OverridesFilePath,
				ReloadPeriod: cfg.OverridesReloadInterval,
			})
			if err != nil {
				return nil, err
			}

			serverOptions.OverridesService = overridesSvc
		}

		server, err := sql.NewResourceServer(serverOptions)
		if err != nil {
			return nil, err
		}

		return resource.NewLocalResourceClient(server), nil
	}
}

func NewStorageApiSearchClient(cfg *setting.Cfg, features featuremgmt.FeatureToggles) (resourcepb.ResourceIndexClient, error) {
	var searchClient resourcepb.ResourceIndexClient
	var err error
	if cfg.EnableSearchClient {
		searchClient, err = NewSearchClient(cfg, features)
		if err != nil {
			return nil, fmt.Errorf("failed to create search client: %w", err)
		}
	}
	return searchClient, nil
}

func NewSearchClient(cfg *setting.Cfg, features featuremgmt.FeatureToggles) (resourcepb.ResourceIndexClient, error) {
	apiserverCfg := cfg.SectionWithEnvOverrides("grafana-apiserver")
	searchServerAddress := apiserverCfg.Key("search_server_address").MustString("")
	grpcClientKeepaliveTime := apiserverCfg.Key("grpc_client_keepalive_time").MustDuration(options.DefaultGrpcClientKeepaliveTime)

	if searchServerAddress == "" {
		return nil, fmt.Errorf("expecting search_server_address to be set for search client under grafana-apiserver section")
	}

	metrics := newClientMetrics(prometheus.NewRegistry())
	conn, err := grpcConn(searchServerAddress, metrics, grpcClientKeepaliveTime)
	if err != nil {
		return nil, err
	}

	// When the modern grpc client auth is enabled, mirror NewRemoteResourceClient
	// and use the authlib interceptor with IDTokenExtractor.
	//nolint:staticcheck // not yet migrated to OpenFeature
	if features != nil && features.IsEnabledGlobally(featuremgmt.FlagAppPlatformGrpcClientAuth) {
		clientCfg := authnGrpcUtils.ReadGrpcClientConfig(cfg)
		clientInt, err := resource.NewAuthnGrpcClientInterceptor(
			otel.Tracer("github.com/grafana/grafana/pkg/storage/unified"),
			resource.RemoteResourceClientConfig{
				Token:            clientCfg.Token,
				TokenExchangeURL: clientCfg.TokenExchangeURL,
				Audiences:        []string{"resourceStore"},
				Namespace:        clientCfg.TokenNamespace,
				AllowInsecure:    cfg.Env == setting.Dev,
				IsDev:            cfg.Env == setting.Dev,
			},
		)
		if err != nil {
			return nil, fmt.Errorf("could not create authn interceptor for search client: %w", err)
		}
		cc := grpchan.InterceptClientConn(conn, clientInt.UnaryClientInterceptor, clientInt.StreamClientInterceptor)
		return resourcepb.NewResourceIndexClient(cc), nil
	}

	cc := grpchan.InterceptClientConn(conn, grpcUtils.UnaryClientInterceptor, grpcUtils.StreamClientInterceptor)
	return resourcepb.NewResourceIndexClient(cc), nil
}

// grpcConn creates a new gRPC connection to the provided address.
func grpcConn(address string, metrics *clientMetrics, clientKeepaliveTime time.Duration) (*grpc.ClientConn, error) {
	// Report gRPC status code errors as labels.
	unary, stream := instrument(metrics.requestDuration, middleware.ReportGRPCStatusOption)

	// Add middleware to retry on transient connection issues. Note that
	// we do not implement it for streams, as we don't currently use streams.
	retryCfg := retryConfig{
		Max:           3,
		Backoff:       time.Second,
		BackoffJitter: 0.1,
	}
	unary = append(unary, unaryRetryInterceptor(retryCfg))
	unary = append(unary, unaryRetryInstrument(metrics.requestRetries))

	cfg := grpcclient.Config{}
	// Set the defaults that are normally set by Config.RegisterFlags.
	flagext.DefaultValues(&cfg)

	opts, err := cfg.DialOption(unary, stream, nil)
	if err != nil {
		return nil, fmt.Errorf("could not instrument grpc client: %w", err)
	}

	opts = append(opts, grpc.WithStatsHandler(otelgrpc.NewClientHandler()))
	opts = append(opts, grpc.WithTransportCredentials(insecure.NewCredentials()))

	// Use round_robin to balance requests more evenly over the available Storage server.
	opts = append(opts, grpc.WithDefaultServiceConfig(`{"loadBalancingPolicy":"round_robin"}`))

	// Disable looking up service config from TXT DNS records.
	// This reduces the number of requests made to the DNS servers.
	opts = append(opts, grpc.WithDisableServiceConfig())

	opts = append(opts, connectionBackoffOptions())

	if clientKeepaliveTime > 0 {
		opts = append(opts, grpc.WithKeepaliveParams(keepalive.ClientParameters{
			Time:    clientKeepaliveTime,
			Timeout: 10 * time.Second,
		}))
	}
	// Create a connection to the gRPC server
	return grpc.NewClient(address, opts...)
}

// GrpcConn is the public constructor that can be used for testing.
// TODO: also use grpc_client_keepalive_time here.
func GrpcConn(address string, reg prometheus.Registerer) (*grpc.ClientConn, error) {
	metrics := newClientMetrics(reg)
	return grpcConn(address, metrics, 0)
}

// instrument is the same as grpcclient.Instrument but without the middleware.ClientUserHeaderInterceptor
// and middleware.StreamClientUserHeaderInterceptor as we don't need them.
func instrument(requestDuration *prometheus.HistogramVec, instrumentationLabelOptions ...middleware.InstrumentationOption) ([]grpc.UnaryClientInterceptor, []grpc.StreamClientInterceptor) {
	return []grpc.UnaryClientInterceptor{
			middleware.UnaryClientInstrumentInterceptor(requestDuration, instrumentationLabelOptions...),
		}, []grpc.StreamClientInterceptor{
			middleware.StreamClientInstrumentInterceptor(requestDuration, instrumentationLabelOptions...),
		}
}

func newClientMetrics(reg prometheus.Registerer) *clientMetrics {
	// This works for now as the Provide function is only called once during startup.
	// We might eventually want to tight this factory to a struct for more runtime control.
	return &clientMetrics{
		requestDuration: promauto.With(reg).NewHistogramVec(prometheus.HistogramOpts{
			Name:    "resource_server_client_request_duration_seconds",
			Help:    "Time spent executing requests to the resource server.",
			Buckets: prometheus.ExponentialBuckets(0.008, 4, 7),

			NativeHistogramBucketFactor:     1.1,
			NativeHistogramMaxBucketNumber:  160,
			NativeHistogramMinResetDuration: time.Hour,
		}, []string{"operation", "status_code"}),
		requestRetries: promauto.With(reg).NewCounterVec(prometheus.CounterOpts{
			Name: "resource_server_client_request_retries_total",
			Help: "Total number of retries for requests to the resource server.",
		}, []string{"operation"}),
	}
}
