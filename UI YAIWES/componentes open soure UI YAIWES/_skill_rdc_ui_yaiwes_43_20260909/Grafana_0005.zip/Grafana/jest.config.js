// We set this specifically for 2 reasons.
// 1. It makes sense for both CI tests and local tests to behave the same so issues are found earlier
// 2. Any wrong timezone handling could be hidden if we use UTC/GMT local time (which would happen in CI).
process.env.TZ = 'Pacific/Easter'; // UTC-06:00 or UTC-05:00 depending on daylight savings

const esModules = [
  '@faker-js/faker',
  '@wojtekmaj/date-utils',
  'ol',
  'd3',
  'd3-color',
  'd3-interpolate',
  'delaunator',
  'get-user-locale',
  'internmap',
  'robust-predicates',
  'leven',
  'nanoid',
  'marked',
  'memoize',
  'mimic-function',
  'monaco-promql',
  'react-calendar',
  '@kusto/monaco-kusto',
  'monaco-editor',
  '@msagl',
  'lodash-es',
  'vscode-languageserver-types',
  '@bsull/augurs',
  '@grafana/react-data-grid',
  '@grafana/llm',
  'pkce-challenge',
  'quickselect',
  'rbush',
  'earcut',
  'pbf',
  'geotiff',
  'uuid',
  '@react-hookz/web',
  '@ver0/deep-equal',
  '@marcbachmann/cel-js',
].join('|');

module.exports = {
  verbose: false,
  // Recycle a worker once it exceeds this cap so heap growth over a run (most acute during
  // coverage) can't accumulate unbounded. Applies even at --maxWorkers=1, where Jest restarts
  // the single worker between test files. Per-worker cap, not a reservation; tune via --logHeapUsage.
  workerIdleMemoryLimit: '1GB',
  testEnvironment: 'jsdom',
  testEnvironmentOptions: {
    customExportConditions: ['@grafana-app/source', 'browser'],
  },
  transform: {
    '^.+\\.(ts|tsx|js|jsx)$': [require.resolve('ts-jest')],
  },
  transformIgnorePatterns: [
    // Transform listed ESM packages at the top level or nested under another package
    // (e.g. @grafana/plugin-ui → uuid). Top-level still uses prefix matching so
    // entries like `d3` continue to cover related packages (d3-force, etc.).
    `/node_modules/(?!(?:${esModules})|(?:.*/(?:${esModules})/))`,
  ],
  moduleDirectories: ['public', 'node_modules'],
  roots: ['<rootDir>/public/app', '<rootDir>/public/test', '<rootDir>/packages', '<rootDir>/scripts/tests'],
  testRegex: '(\\.|/)(test)\\.(jsx?|tsx?)$',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'cjs'],
  setupFiles: ['jest-canvas-mock', './public/test/jest-setup.ts'],
  testTimeout: 30000,
  resolver: `<rootDir>/public/test/jest-resolver.js`,
  setupFilesAfterEnv: ['./public/test/setupTests.ts'],
  globals: {
    __webpack_public_path__: '', // empty string
  },
  moduleNameMapper: {
    '\\.(svg|png|jpg)': '<rootDir>/public/test/mocks/images.ts',
    '\\.css': '<rootDir>/public/test/mocks/style.ts',
    'react-inlinesvg': '<rootDir>/public/test/mocks/react-inlinesvg.tsx',
    // resolve directly as monaco and kusto don't have main property in package.json which jest needs
    '^monaco-editor$': 'monaco-editor/esm/vs/editor/editor.api.js',
    '@kusto/monaco-kusto': '@kusto/monaco-kusto/release/esm/monaco.contribution.js',
    // near-membrane-dom won't work in a nodejs environment.
    '@locker/near-membrane-dom': '<rootDir>/public/test/mocks/nearMembraneDom.ts',
    // prevent systemjs amd extra from breaking tests.
    'systemjs/dist/extras/amd': '<rootDir>/public/test/mocks/systemjsAMDExtra.ts',
    '@bsull/augurs': '<rootDir>/public/test/mocks/augurs.ts',
    // Mock @grafana/assistant to prevent initialization errors in tests
    '^@grafana/assistant$': '<rootDir>/public/test/mocks/assistant.ts',
    // Mock measureText to prevent invalid calculations with uPlot
    '^@grafana/ui/src/utils/measureText$': '<rootDir>/packages/grafana-ui/src/utils/measureText.ts',
  },
  // Log the test results with dynamic Loki tags. Drone CI only
  reporters: ['default', ['<rootDir>/public/test/log-reporter.js', { enable: process.env.DRONE === 'true' }]],
  watchPlugins: ['jest-watch-typeahead/filename', 'jest-watch-typeahead/testname'],
  testPathIgnorePatterns: [
    '/node_modules/',
    // Decoupled plugins run their own tests so ignoring them here.
    '<rootDir>/public/app/plugins/datasource/azuremonitor',
    '<rootDir>/public/app/plugins/datasource/cloudwatch',
    '<rootDir>/public/app/plugins/datasource/grafana-testdata-datasource',
    '<rootDir>/public/app/plugins/datasource/graphite',
  ],
};
