/**
 * Copyright 2017 Google Inc. All rights reserved.
 * Modifications copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { playwrightTest as it, expect } from '../config/browserTest';
import fs from 'fs';
import path from 'path';

it.skip(({ mode }) => mode !== 'default', 'Remote persistent contexts are not supported');

it('should support hasTouch option', async ({ server, launchPersistent }) => {
  const { page } = await launchPersistent({ hasTouch: true });
  await page.goto(server.PREFIX + '/mobile.html');
  expect(await page.evaluate(() => 'ontouchstart' in window)).toBe(true);
});

it('should work in persistent context', async ({ server, launchPersistent, browserName }) => {
  const { page } = await launchPersistent({ viewport: { width: 320, height: 480 }, isMobile: true });
  await page.goto(server.PREFIX + '/empty.html');
  expect(await page.evaluate(() => window.innerWidth)).toBe(980);
});

it('should support colorScheme option', async ({ launchPersistent }) => {
  const { page } = await launchPersistent({ colorScheme: 'dark' });
  expect(await page.evaluate(() => matchMedia('(prefers-color-scheme: light)').matches)).toBe(false);
  expect(await page.evaluate(() => matchMedia('(prefers-color-scheme: dark)').matches)).toBe(true);
});

it('should support reducedMotion option', async ({ launchPersistent }) => {
  const { page } = await launchPersistent({ reducedMotion: 'reduce' });
  expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toBe(true);
  expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: no-preference)').matches)).toBe(false);
});

it('should support forcedColors option', async ({ launchPersistent, browserName }) => {
  const { page } = await launchPersistent({ forcedColors: 'active' });
  expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(true);
  expect(await page.evaluate(() => matchMedia('(forced-colors: none)').matches)).toBe(false);
});

it('should support contrast option', async ({ launchPersistent }) => {
  const { page } = await launchPersistent({ contrast: 'more' });
  expect.soft(await page.evaluate(() => matchMedia('(prefers-contrast: more)').matches)).toBe(true);
  expect.soft(await page.evaluate(() => matchMedia('(prefers-contrast: no-preference)').matches)).toBe(false);
});

it('should support timezoneId option', async ({ launchPersistent, browserName }) => {
  const { page } = await launchPersistent({ locale: 'en-US', timezoneId: 'America/Jamaica' });
  expect(await page.evaluate(() => new Date(1479579154987).toString())).toBe('Sat Nov 19 2016 13:12:34 GMT-0500 (Eastern Standard Time)');
});

it('should support locale option', async ({ launchPersistent }) => {
  const { page } = await launchPersistent({ locale: 'fr-FR' });
  expect(await page.evaluate(() => navigator.language)).toBe('fr-FR');
});

it('should support geolocation and permissions options', async ({ server, launchPersistent }) => {
  const { page } = await launchPersistent({ geolocation: { longitude: 10, latitude: 10 }, permissions: ['geolocation'] });
  await page.goto(server.EMPTY_PAGE);
  const geolocation = await page.evaluate(() => new Promise(resolve => navigator.geolocation.getCurrentPosition(position => {
    resolve({ latitude: position.coords.latitude, longitude: position.coords.longitude });
  })));
  expect(geolocation).toEqual({ latitude: 10, longitude: 10 });
});

it('should support ignoreHTTPSErrors option', async ({ httpsServer, launchPersistent }) => {
  const { page } = await launchPersistent({ ignoreHTTPSErrors: true });
  let error = null;
  const response = await page.goto(httpsServer.EMPTY_PAGE).catch(e => error = e);
  expect(error).toBe(null);
  expect(response.ok()).toBe(true);
});

it('should support extraHTTPHeaders option', async ({ server, launchPersistent }) => {
  const { page } = await launchPersistent({ extraHTTPHeaders: { foo: 'bar' } });
  const [request] = await Promise.all([
    server.waitForRequest('/empty.html'),
    page.goto(server.EMPTY_PAGE),
  ]);
  expect(request.headers['foo']).toBe('bar');
});

it('should accept userDataDir', async ({ createUserDataDir, browserType }) => {
  const userDataDir = await createUserDataDir();
  const context = await browserType.launchPersistentContext(userDataDir);
  expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
  await context.close();
  expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
});

it('should accept relative userDataDir', async ({ createUserDataDir, browserType }) => {
  const userDataDir = await createUserDataDir();
  const context = await browserType.launchPersistentContext(path.relative(process.cwd(), path.join(userDataDir, 'foobar')));
  expect(fs.readdirSync(path.join(userDataDir, 'foobar')).length).toBeGreaterThan(0);
  await context.close();
});

it('should restore state from userDataDir', async ({ browserType, server, createUserDataDir, channel }) => {
  it.slow();
  it.fixme(channel === 'webkit-wsl', 'Pending local storage writes are lost on close, see https://github.com/microsoft/playwright-browsers/issues/2275');

  const userDataDir = await createUserDataDir();
  const browserContext = await browserType.launchPersistentContext(userDataDir);
  const page = await browserContext.newPage();
  await page.goto(server.EMPTY_PAGE);
  await page.evaluate(() => localStorage.hey = 'hello');
  // Browsers do not persist local storage immediately, they do it asynchronously in another process.
  // Navigate away to give it a chance to save (best-effort).
  await page.goto(server.EMPTY_PAGE);
  await browserContext.close();

  const browserContext2 = await browserType.launchPersistentContext(userDataDir);
  const page2 = await browserContext2.newPage();
  await page2.goto(server.EMPTY_PAGE);
  expect(await page2.evaluate(() => localStorage.hey)).toBe('hello');
  await browserContext2.close();

  const userDataDir2 = await createUserDataDir();
  const browserContext3 = await browserType.launchPersistentContext(userDataDir2);
  const page3 = await browserContext3.newPage();
  await page3.goto(server.EMPTY_PAGE);
  expect(await page3.evaluate(() => localStorage.hey)).not.toBe('hello');
  await browserContext3.close();
});

it('should create userDataDir if it does not exist', async ({ createUserDataDir, browserType }) => {
  const userDataDir = path.join(await createUserDataDir(), 'nonexisting');
  const context = await browserType.launchPersistentContext(userDataDir);
  await context.close();
  expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
});

it('should goto about:blank on relaunched persistent context', {
  annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41216' },
}, async ({ browserType, createUserDataDir, browserName, isBidi }) => {
  it.fixme(browserName === 'firefox' && !isBidi);

  const userDataDir = await createUserDataDir();

  const context1 = await browserType.launchPersistentContext(userDataDir);
  await context1.pages()[0].goto('about:blank');
  await context1.close();

  // When relaunching with an existing profile, Firefox session restore can race with the user's goto and cause "interrupted by another navigation".
  // This issue is timing-sensitive and might not fire on every run, so rely on CI's --repeat-each matrix for coverage.
  const context2 = await browserType.launchPersistentContext(userDataDir);
  await context2.pages()[0].goto('about:blank');
  expect(context2.pages()[0].url()).toBe('about:blank');
  await context2.close();
});

it('should have default URL when launching browser', async ({ launchPersistent }) => {
  const { context } = await launchPersistent();
  const urls = context.pages().map(page => page.url());
  expect(urls).toEqual(['about:blank']);
});

it('should throw if page argument is passed', async ({ browserType, server, createUserDataDir, browserName, isBidi }) => {
  it.skip(browserName === 'firefox' && !isBidi);

  const options = { args: [server.EMPTY_PAGE] };
  const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
  expect(error.message).toContain('can not specify page');
});

it('should have passed URL when launching with ignoreDefaultArgs: true', async ({ browserType, server, createUserDataDir, toImpl, browserName }) => {
  const userDataDir = await createUserDataDir();
  const args = (await toImpl(browserType).defaultArgs((browserType as any)._playwright._defaultLaunchOptions, 'persistent', userDataDir, 0)).filter(a => a !== 'about:blank');
  const options = {
    args: browserName === 'firefox' ? [...args, '-new-tab', server.EMPTY_PAGE] : [...args, server.EMPTY_PAGE],
    ignoreDefaultArgs: true,
  };
  const browserContext = await browserType.launchPersistentContext(userDataDir, options);
  if (!browserContext.pages().length)
    await browserContext.waitForEvent('page');
  await browserContext.pages()[0].waitForLoadState();
  const gotUrls = browserContext.pages().map(page => page.url());
  expect(gotUrls).toEqual([server.EMPTY_PAGE]);
  await browserContext.close();
});

it('should handle timeout', async ({ browserType, createUserDataDir }) => {
  const options: any = { timeout: 5000, __testHookBeforeCreateBrowser: () => new Promise(f => setTimeout(f, 6000)) };
  const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
  expect(error.message).toContain(`browserType.launchPersistentContext: Timeout 5000ms exceeded.`);
});

it('should handle exception', async ({ browserType, createUserDataDir }) => {
  const e = new Error('Dummy');
  const options: any = { __testHookBeforeCreateBrowser: () => { throw e; } };
  const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
  expect(error.message).toContain('Dummy');
});

it('should fire close event for a persistent context', async ({ launchPersistent }) => {
  const { context } = await launchPersistent();
  let closed = false;
  context.on('close', () => closed = true);
  await context.close();
  expect(closed).toBe(true);
});

it('coverage should work', async ({ server, launchPersistent, browserName }) => {
  it.skip(browserName !== 'chromium');

  const { page } = await launchPersistent();
  await page.coverage.startJSCoverage();
  await page.goto(server.PREFIX + '/jscoverage/simple.html', { waitUntil: 'load' });
  const coverage = await page.coverage.stopJSCoverage();
  expect(coverage.length).toBe(1);
  expect(coverage[0].url).toContain('/jscoverage/simple.html');
  expect(coverage[0].functions.find(f => f.functionName === 'foo').ranges[0].count).toEqual(1);
});

it('should respect selectors', async ({ playwright, launchPersistent }) => {
  const defaultContextCSS = () => ({
    query(root, selector) {
      return root.querySelector(selector);
    },
    queryAll(root: HTMLElement, selector: string) {
      return Array.from(root.querySelectorAll(selector));
    }
  });
  await playwright.selectors.register('defaultContextCSS', defaultContextCSS);

  const { page } = await launchPersistent();
  await page.setContent(`<div>hello</div>`);
  expect(await page.innerHTML('css=div')).toBe('hello');
  expect(await page.innerHTML('defaultContextCSS=div')).toBe('hello');
});

it('should connect to a browser with the default page', async ({ browserType, createUserDataDir }) => {
  const options: any = { __testHookOnConnectToBrowser: () => new Promise(f => setTimeout(f, 3000)) };
  const context = await browserType.launchPersistentContext(await createUserDataDir(), options);
  expect(context.pages().length).toBe(1);
  await context.close();
});

it('should support har option', async ({ launchPersistent, asset }) => {
  const path = asset('har-fulfill.har');
  const { page } = await launchPersistent();
  await page.routeFromHAR(path);
  await page.goto('http://no.playwright/');
  // HAR contains a redirect for the script that should be followed automatically.
  expect(await page.evaluate('window.value')).toBe('foo');
  // HAR contains a POST for the css file that should not be used.
  await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(255, 0, 0)');
});

it('user agent is up to date', async ({ launchPersistent, browser }) => {
  const { userAgent } = await (browser as any)._channel.defaultUserAgentForTest();
  const { context, page } = await launchPersistent();
  expect(await page.evaluate(() => navigator.userAgent)).toBe(userAgent);
  await context.close();
});

it('dialog.accept should work', {
  annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/35663' }
}, async ({ launchPersistent }) => {
  const { context, page } = await launchPersistent();
  await page.goto('data:text/html,<html><title>Title</title><button onclick="alert(\'Alert\')">Button</button></html>');
  let shown = false;
  page.on('dialog', dialog => {
    shown = true;
    void dialog.accept();
  });
  await page.getByRole('button', { name: 'Button' }).click();
  expect(shown).toBe(true);
  await context.close();
});

it('CacheStorage entry should survive page.reload()', {
  annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41618' }
}, async ({ launchPersistent, server }) => {
  const { context, page } = await launchPersistent();
  await page.goto(server.EMPTY_PAGE);
  await page.evaluate(async () => {
    const cache = await caches.open('repro-cache');
    await cache.put('/meta', new Response('payload'));
  });

  await page.reload();

  const after = await page.evaluate(async () => {
    const cache = await caches.open('repro-cache');
    const resp = await cache.match('/meta');
    return resp ? await resp.text() : null;
  });
  expect(after).toBe('payload');
  await context.close();
});

it('exposes browser', async ({ launchPersistent }) => {
  const { context } = await launchPersistent();
  const browser = context.browser();
  expect(browser.version()).toBeTruthy();
  const page = await browser.newPage();
  await page.goto('data:text/html,<html><title>Title</title></html>');
  expect(await page.title()).toBe('Title');
  await browser.close();
  expect(context.pages().length).toBe(0);
  // Next line should not throw.
  await context.close();
});

it('should support storage.getDirectory()', {
  annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/18235' }
}, async ({ launchPersistent, server }) => {
  const { context } = await launchPersistent();
  const page = await context.newPage();
  await page.goto(server.EMPTY_PAGE);
  const name = await page.evaluate(async () => {
    const dir = await navigator.storage.getDirectory();
    return dir.name;
  }).catch(e => e);
  expect(name).toBe('');
  await context.close();
});
