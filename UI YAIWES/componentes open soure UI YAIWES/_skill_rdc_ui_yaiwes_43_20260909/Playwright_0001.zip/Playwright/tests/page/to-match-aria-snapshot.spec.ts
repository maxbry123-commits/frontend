/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { stripAnsi } from '../config/utils';
import { test, expect } from './pageTest';

test('should match page', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);
  await expect(page).toMatchAriaSnapshot(`
    - heading "title"
  `);
});

test('should match page complex', async ({ page }) => {
  await page.setContent(`
    <h1>Microsoft</h1>
    <div>Open source projects and samples from Microsoft</div>
    <ul>
      <li>
        <a href="about:blank">Playwright</a>
      </li>
    </ul>`);

  await expect(page).toMatchAriaSnapshot(`
    - heading "Microsoft"
    - text: Open source projects and samples from Microsoft
    - list:
      - listitem:
        - link "Playwright"
  `);
});

test('should match page with not', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);
  await expect(page).not.toMatchAriaSnapshot(`
    - heading "wrong"
  `);
});

test('should fail page with timeout', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);
  const e = await expect(page).toMatchAriaSnapshot(`
    - heading "wrong"
  `, { timeout: 2000 }).catch(e => e);
  expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
  expect(stripAnsi(e.message)).toContain('Timeout:  2000ms');
  expect(stripAnsi(e.message)).not.toContain('Locator');
});

test('should match', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);
  await expect(page).toMatchAriaSnapshot(`
    - heading "title"
  `);
});

test('should match in list', async ({ page }) => {
  await page.setContent(`
    <h1>title</h1>
    <h1>title 2</h1>
  `);
  await expect(page).toMatchAriaSnapshot(`
    - heading "title"
  `);
});

test('should match list with accessible name', async ({ page }) => {
  await page.setContent(`
    <ul aria-label="my list">
      <li>one</li>
      <li>two</li>
    </ul>
  `);
  await expect(page).toMatchAriaSnapshot(`
    - list "my list":
      - listitem: "one"
      - listitem: "two"
  `);
});

test('should match deep item', async ({ page }) => {
  await page.setContent(`
    <div>
      <h1>title</h1>
      <h1>title 2</h1>
    </div>
  `);
  await expect(page).toMatchAriaSnapshot(`
    - heading "title"
  `);
});

test('should match complex', async ({ page }) => {
  await page.setContent(`
    <ul>
      <li>
        <a href='about:blank'>link</a>
      </li>
    </ul>
  `);
  await expect(page).toMatchAriaSnapshot(`
    - list:
      - listitem:
        - link "link"
  `);
});

test('should match regex', async ({ page }) => {
  {
    await page.setContent(`<h1>Issues 12</h1>`);
    await expect(page).toMatchAriaSnapshot(`
      - heading ${/Issues \d+/}
    `);
  }
  {
    await page.setContent(`<h1>Issues 1/2</h1>`);
    await expect(page).toMatchAriaSnapshot(`
      - heading ${/Issues 1[/]2/}
    `);
  }
  {
    await page.setContent(`<h1>Issues 1[</h1>`);
    await expect(page).toMatchAriaSnapshot(`
      - heading ${/Issues 1\[/}
    `);
  }
  {
    await page.setContent(`<h1>Issues 1]]2</h1>`);
    await expect(page).toMatchAriaSnapshot(`
      - heading ${/Issues 1[\]]]2/}
    `);
  }
});

test('should allow text nodes', async ({ page }) => {
  await page.setContent(`
    <h1>Microsoft</h1>
    <div>Open source projects and samples from Microsoft</div>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - heading "Microsoft"
    - text: "Open source projects and samples from Microsoft"
  `);
});

test('details visibility', async ({ page }) => {
  await page.setContent(`
    <details>
      <summary>Summary</summary>
      <div>Details</div>
    </details>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - group: "Summary"
  `);
});

test('checked attribute', async ({ page }) => {
  await page.setContent(`
    <input type='checkbox' checked />
  `);

  await expect(page).toMatchAriaSnapshot(`
    - checkbox
  `);

  await expect(page).toMatchAriaSnapshot(`
    - checkbox [checked]
  `);

  await expect(page).toMatchAriaSnapshot(`
    - checkbox [checked=true]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - checkbox [checked=false]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - checkbox [checked=mixed]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - checkbox [checked=5]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a boolean or "mixed"');
  }
});

test('disabled attribute', async ({ page }) => {
  await page.setContent(`
    <button disabled>Click me</button>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [disabled]
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [disabled=true]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [disabled=false]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [disabled=invalid]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a boolean');
  }
});

test('expanded attribute', async ({ page }) => {
  await page.setContent(`
    <button aria-expanded="true">Toggle</button>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [expanded]
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [expanded=true]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [expanded=false]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [expanded=invalid]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a boolean');
  }
});

test('level attribute', async ({ page }) => {
  await page.setContent(`
    <h2>Section Title</h2>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - heading
  `);

  await expect(page).toMatchAriaSnapshot(`
    - heading [level=2]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - heading [level=3]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - heading [level=two]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a number');
  }
});

test('pressed attribute', async ({ page }) => {
  await page.setContent(`
    <button aria-pressed="true">Like</button>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [pressed]
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [pressed=true]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [pressed=false]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  // Test for 'mixed' state
  await page.setContent(`
    <button aria-pressed="mixed">Like</button>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - button [pressed=mixed]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [pressed=true]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
    expect(stripAnsi(e.message)).toContain('Timeout:  1000ms');
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - button [pressed=5]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a boolean or "mixed"');
  }
});

test('selected attribute', async ({ page }) => {
  await page.setContent(`
    <table>
      <tr aria-selected="true">
        <td>Row</td>
      </tr>
      <tr>
        <td>Row 2</td>
      </tr>
    </table>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - row
    - row
  `);

  await expect(page).toMatchAriaSnapshot(`
    - row [selected]
    - row
  `);

  await expect(page).toMatchAriaSnapshot(`
    - row [selected=true]
    - row [selected=false]
  `);

  await expect(page.locator('table')).toMatchAriaSnapshot(`
    - table:
      - rowgroup:
        - row [selected=true]
        - row [selected=false]
  `);

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - row [selected=false]
      - row [selected=false]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(`expect(page).toMatchAriaSnapshot(expected) failed

Timeout: 1000ms
- Expected  - 2
+ Received  + 6

- - row [selected=false]
- - row [selected=false]
+ - table:
+   - rowgroup:
+     - row "Row" [selected]:
+       - cell "Row"
+     - row \"Row 2\":
+       - cell \"Row 2\"

Call log:
`);
  }

  {
    const e = await expect(page).toMatchAriaSnapshot(`
      - row [selected=invalid]
    `, { timeout: 1000 }).catch(e => e);
    expect(stripAnsi(e.message)).toContain(' attribute must be a boolean');
  }
});

test('integration test', async ({ page }) => {
  await page.setContent(`
    <h1>Microsoft</h1>
    <div>Open source projects and samples from Microsoft</div>
    <ul>
      <li>
        <details>
          <summary>
            Verified
          </summary>
          <div>
            <div>
              <p>
                We've verified that the organization <strong>microsoft</strong> controls the domain:
              </p>
              <ul>
                <li class="mb-1">
                  <strong>opensource.microsoft.com</strong>
                </li>
              </ul>
              <div>
                <a href="about: blank">Learn more about verified organizations</a>
              </div>
            </div>
          </div>
        </details>
      </li>
      <li>
        <a href="about:blank">
          <summary title="Label: GitHub Sponsor">Sponsor</summary>
        </a>
      </li>
    </ul>`);

  await expect(page).toMatchAriaSnapshot(`
    - heading "Microsoft"
    - text: Open source projects and samples from Microsoft
    - list:
      - listitem:
        - group: Verified
      - listitem:
        - link "Sponsor"
  `);
});

test('integration test 2', async ({ page }) => {
  await page.setContent(`
    <div>
      <header>
        <h1>todos</h1>
        <input placeholder="What needs to be done?">
      </header>
    </div>`);
  await expect(page).toMatchAriaSnapshot(`
    - heading "todos"
    - textbox "What needs to be done?"
  `);
});

test('expected formatter', async ({ page }) => {
  await page.setContent(`
    <div>
      <header>
        <h1>todos</h1>
        <input placeholder="What needs to be done?">
        <button>Time 15:30</button>
      </header>
    </div>`);
  const error = await expect(page).toMatchAriaSnapshot(`
    - heading "todos"
    - textbox "Wrong text"
  `, { timeout: 1 }).catch(e => e);

  // Note that error message should not contain any regular expressions,
  // unlike the baseline generated by --update-snapshots.
  expect(stripAnsi(error.message)).toContain(`expect(page).toMatchAriaSnapshot(expected) failed

Timeout: 1ms
- Expected  - 2
+ Received  + 4

- - heading "todos"
- - textbox "Wrong text"
+ - banner:
+   - heading "todos" [level=1]
+   - textbox "What needs to be done?"
+   - button "Time 15:30"

Call log:
`);
});

test('should unpack escaped names', async ({ page }) => {
  {
    await page.setContent(`
      <button>Click: me</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - 'button "Click: me"'
    `);
    await expect(page).toMatchAriaSnapshot(`
      - 'button /Click: me/'
    `);
  }

  {
    await page.setContent(`
      <button>Click / me</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button "Click / me"
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button /Click \\/ me/
    `);
    await expect(page).toMatchAriaSnapshot(`
      - 'button /Click \\/ me/'
    `);
  }

  {
    await page.setContent(`
      <button>Click " me</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button "Click \\\" me"
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button /Click \" me/
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button /Click \\\" me/
    `);
  }

  {
    await page.setContent(`
      <button>Click \\ me</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button "Click \\\\ me"
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button /Click \\\\ me/
    `);
    await expect(page).toMatchAriaSnapshot(`
      - 'button /Click \\\\ me/'
    `);
  }

  {
    await page.setContent(`
      <button>Click ' me</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - 'button "Click '' me"'
    `);
  }

  {
    await page.setContent(`
      <h1>heading "name" [level=1]</h1>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - heading "heading \\"name\\" [level=1]" [level=1]
    `);
  }

  {
    await page.setContent(`
      <h1>heading \\" [level=2]</h1>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - |
          heading    "heading \\\\\\" [level=2]" [
             level  =   1   ]
    `);
  }
});

test('should report error in YAML', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      heading "title"
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "heading \\"title\\""
Error: Aria snapshot must be a YAML sequence, elements starting with " -"

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading: a:
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading: a:"
Error: Nested mappings are not allowed in compact mappings at line 1, column 12:

- heading: a:
           ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }
});

test('should report error in YAML keys', async ({ page }) => {
  await page.setContent(`<h1>title</h1>`);

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading "title
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading \\"title"
Error: Unterminated string:

heading "title
              ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading /title
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading /title"
Error: Unterminated regex:

heading /title
              ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading [level=a]
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading [level=a]"
Error: Value of "level" attribute must be a number:

heading [level=a]
               ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading [expanded=FALSE]
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading [expanded=FALSE]"
Error: Value of "expanded" attribute must be a boolean:

heading [expanded=FALSE]
                  ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading [checked=foo]
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading [checked=foo]"
Error: Value of "checked" attribute must be a boolean or "mixed":

heading [checked=foo]
                 ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading [level=]
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading [level=]"
Error: Value of "level" attribute must be a number:

heading [level=]
               ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading [bogus]
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading [bogus]"
Error: Unsupported attribute [bogus]:

heading [bogus]
         ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }

  {
    const error = await expect(page).toMatchAriaSnapshot(`
      - heading invalid
    `).catch(e => e);
    expect.soft(stripAnsi(error.message)).toBe(`expect(page).toMatchAriaSnapshot(expected) failed

Expected: "- heading invalid"
Error: Unexpected input:

heading invalid
        ^

Call log:
  - Expect "toMatchAriaSnapshot" with timeout 10000ms
`);
  }
});

test('call log should contain actual snapshot', async ({ page }) => {
  await page.setContent(`<h1>todos</h1>`);
  const error = await expect(page).toMatchAriaSnapshot(`
    - heading "wrong"
  `, { timeout: 3000 }).catch(e => e);

  expect(stripAnsi(error.message)).toContain(`unexpected value "- heading "todos" [level=1]"`);
});

test('should parse attributes', async ({ page }) => {
  {
    await page.setContent(`
      <button aria-pressed="mixed">hello world</button>
    `);
    await expect(page).toMatchAriaSnapshot(`
      - button [pressed=mixed ]
    `);
  }

  {
    await page.setContent(`
      <h2>hello world</h2>
    `);
    await expect(page.locator('body')).not.toMatchAriaSnapshot(`
      - heading [level =  -3 ]
    `);
  }
});

test('should not unshift actual template text', async ({ page }) => {
  await page.setContent(`
    <h1>title</h1>
    <h1>title 2</h1>
  `);
  const error = await expect(page).toMatchAriaSnapshot(`
        - heading "title" [level=1]
    - heading "title 2" [level=1]
  `, { timeout: 1000 }).catch(e => e);
  expect(stripAnsi(error.message)).toContain(`
    - heading "title" [level=1]
- heading "title 2" [level=1]`);
});

test('should not match what is not matched', async ({ page }) => {
  await page.setContent(`<p>Text</p>`);
  const error = await expect(page).toMatchAriaSnapshot(`
    - paragraph:
      - button "bogus"
  `).catch(e => e);
  expect(stripAnsi(error.message)).toContain(`
- - paragraph:
-   - button "bogus"
+ - paragraph: Text`);
});

test('should match url', async ({ page }) => {
  await page.setContent(`
    <a href='https://example.com'>Link</a>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - link:
      - /url: /.*example.com/
  `);
});

test('should detect unexpected children: equal', async ({ page }) => {
  await page.setContent(`
    <ul>
      <li>One</li>
      <li>Two</li>
      <li>Three</li>
    </ul>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - list:
      - listitem: "One"
      - listitem: "Three"
  `);

  const e = await expect(page).toMatchAriaSnapshot(`
    - list:
      - /children: equal
      - listitem: "One"
      - listitem: "Three"
  `, { timeout: 1000 }).catch(e => e);

  expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
  expect(stripAnsi(e.message)).toContain('+   - listitem: Two');
});

test('should detect unexpected children: deep-equal', async ({ page }) => {
  await page.setContent(`
    <ul>
      <li>
        <ul>
          <li>1.1</li>
          <li>1.2</li>
        </ul>
      </li>
    </ul>
  `);

  await expect(page).toMatchAriaSnapshot(`
    - list:
      - listitem:
        - list:
          - listitem: 1.1
  `);

  await expect(page).toMatchAriaSnapshot(`
    - list:
      - /children: equal
      - listitem:
        - list:
          - listitem: 1.1
  `);

  const e = await expect(page).toMatchAriaSnapshot(`
    - list:
      - /children: deep-equal
      - listitem:
        - list:
          - listitem: 1.1
  `, { timeout: 1000 }).catch(e => e);

  expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
  expect(stripAnsi(e.message)).toContain('+       - listitem: \"1.2\"');
});

test('should allow restoring contain mode inside deep-equal', async ({ page }) => {
  await page.setContent(`
    <ul>
      <li>
        <ul>
          <li>1.1</li>
          <li>1.2</li>
        </ul>
      </li>
    </ul>
  `);

  const e = await expect(page).toMatchAriaSnapshot(`
    - list:
      - /children: deep-equal
      - listitem:
        - list:
          - listitem: 1.1
  `, { timeout: 1000 }).catch(e => e);

  expect(stripAnsi(e.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
  expect(stripAnsi(e.message)).toContain('+       - listitem: \"1.2\"');

  await expect(page).toMatchAriaSnapshot(`
    - list:
      - /children: deep-equal
      - listitem:
        - list:
          - /children: contain
          - listitem: 1.1
  `);
});

test('top-level deep-equal', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36456' } }, async ({ page }) => {
  await page.setContent(`
    <ul>
      <li>
        <ul>
          <li>1.1</li>
          <li>1.2</li>
        </ul>
      </li>
    </ul>
  `);

  const error = await expect(page).toMatchAriaSnapshot(`
    - /children: deep-equal
    - list
  `, { timeout: 1000 }).catch(e => e);

  expect(stripAnsi(error.message)).toContain(`
- - /children: deep-equal
- - list
+ - list:
+   - listitem:
+     - list:
+       - listitem: "1.1"
+       - listitem: "1.2"
  `.trim());
});


test('generated snapshot includes text children when name is longer than text', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40079' } }, async ({ page }) => {
  await page.setContent(`
    <section>
      <div role="progressbar" aria-label="Alpha Beta" aria-valuenow="7" aria-valuemin="0" aria-valuemax="10">
        <span>Alpha</span>
        <span>7</span>
      </div>
    </section>
  `);
  await expect(page.locator('section')).toMatchAriaSnapshot(`
    - /children: deep-equal
    - progressbar "Alpha Beta": Alpha 7
  `);
});

test('treat bad regex as a string', async ({ page }) => {
  await page.setContent(`<a href="/foo">Log in</a>`);
  const error = await expect(page).toMatchAriaSnapshot(`
    - link "Log in":
      - /url: /[a/
  `, { timeout: 1 }).catch(e => e);
  expect(stripAnsi(error.message)).toContain('expect(page).toMatchAriaSnapshot(expected) failed');
  expect(stripAnsi(error.message)).toContain('-   - /url: /[a/');
  expect(stripAnsi(error.message)).toContain('+   - /url: /foo');
});

test('invalid attribute', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/34839' } }, async ({ page }) => {
  await page.setContent(`
    <input type="text" aria-label="Email" aria-invalid="true" value="not-an-email">
    <input type="text" aria-label="Name" value="Alice">
  `);

  await expect(page).toMatchAriaSnapshot(`
    - textbox "Email" [invalid]: not-an-email
    - textbox "Name": Alice
  `);

  await expect(page).toMatchAriaSnapshot(`
    - textbox "Email" [invalid=true]: not-an-email
    - textbox "Name" [invalid=false]: Alice
  `);

  // `aria-invalid="grammar"` and `aria-invalid="spelling"` surface their underlying value.
  await page.setContent(`
    <input type="text" aria-label="Bio" aria-invalid="grammar">
    <input type="text" aria-label="Note" aria-invalid="spelling">
  `);
  await expect(page).toMatchAriaSnapshot(`
    - textbox "Bio" [invalid=grammar]
    - textbox "Note" [invalid=spelling]
  `);

  // A `grammar` value is distinct from a plain `true` invalid state.
  const error = await expect(page).toMatchAriaSnapshot(`
    - textbox "Bio" [invalid]
  `, { timeout: 1 }).catch(e => e);
  expect(stripAnsi(error.message)).toContain('[invalid=grammar]');

  // Any other non-false value falls back to `true`.
  await page.setContent(`<input type="text" aria-label="Zip" aria-invalid="garbage">`);
  await expect(page).toMatchAriaSnapshot(`
    - textbox "Zip" [invalid]
  `);
});
