/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { spawnSync } from 'child_process';
import { test, expect, mcpServerPath } from './fixtures';

test.describe.configure({
  retries: 1,
});

test('cdp server', async ({ cdpServer, startClient, server }) => {
  await cdpServer.start();
  const { client } = await startClient({ args: [`--cdp-endpoint=${cdpServer.endpoint}`] });
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`- generic [active] [ref=e1]: Hello, world!`),
  });
});

test('cdp server reuse tab', async ({ cdpServer, startClient, server }) => {
  const browserContext = await cdpServer.start();
  const { client } = await startClient({ args: [`--cdp-endpoint=${cdpServer.endpoint}`] });

  const [page] = browserContext.pages();
  await page.goto(server.HELLO_WORLD);

  expect(await client.callTool({
    name: 'browser_click',
    arguments: {
      element: 'Hello, world!',
      target: 'f0',
    },
  })).toHaveResponse({
    error: `Error: "f0" does not match any elements.`,
    isError: true,
  });

  expect(await client.callTool({
    name: 'browser_snapshot',
  })).toHaveResponse({
    page: `- Page URL: ${server.HELLO_WORLD}
- Page Title: Title`,
    inlineSnapshot: `- generic [active] [ref=e1]: Hello, world!`,
  });
});

test('cdp connection uses noDefaults', async ({ cdpServer, startClient }) => {
  test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41661' });
  const browserContext = await cdpServer.start();
  const [page] = browserContext.pages();
  await page.emulateMedia({ media: 'print' });
  expect(await page.evaluate(() => matchMedia('print').matches)).toBe(true);

  const { client } = await startClient({ args: [`--cdp-endpoint=${cdpServer.endpoint}`] });
  await client.callTool({ name: 'browser_snapshot' });

  expect(await page.evaluate(() => matchMedia('print').matches)).toBe(true);
});

test('should throw connection error and allow re-connecting', async ({ cdpServer, startClient, server }) => {
  const { client } = await startClient({ args: [`--cdp-endpoint=${cdpServer.endpoint}`] });

  server.setContent('/', `
    <title>Title</title>
    <body>Hello, world!</body>
  `, 'text/html');

  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.PREFIX },
  })).toHaveResponse({
    error: expect.stringContaining(`connect ECONNREFUSED`),
    isError: true,
  });
  await cdpServer.start();
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.PREFIX },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`- generic [active] [ref=e1]: Hello, world!`),
  });
});

test('auto-recover when remote browser disconnects mid-session', async ({ cdpServer, startClient, server }) => {
  const browserContext = await cdpServer.start();
  const { client } = await startClient({ args: [`--cdp-endpoint=${cdpServer.endpoint}`] });

  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`Hello, world!`),
  });

  // Simulate the remote browser dying mid-session (e.g. CDP endpoint session timeout).
  await browserContext.close();

  // The next call hits the dead backend; it must error and let the MCP server discard
  // the backend so the next call can transparently establish a fresh connection.
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    isError: true,
  });

  // Bring the CDP endpoint back. The next call should reconnect transparently —
  // no manual browser_close needed (regression test for playwright-mcp#1588).
  await cdpServer.start();
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`Hello, world!`),
  });
});

test('transparently reconnects when the remote browser is restarted', async ({ cdpServer, startClient, server }) => {
  const browserContext = await cdpServer.start();
  const { client, stderr } = await startClient({
    args: [`--cdp-endpoint=${cdpServer.endpoint}`],
    env: { DEBUG: 'pw:mcp:backend' },
  });

  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`Hello, world!`),
  });

  await browserContext.close();
  await expect.poll(() => stderr()).toContain('browser disconnected');
  await cdpServer.start();

  // The very next tool call must reconnect, with no failed call in between.
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    snapshot: expect.stringContaining(`Hello, world!`),
  });
});

test('does not support --device', async () => {
  const result = spawnSync('node', [
    ...mcpServerPath, '--device=Pixel 5', '--cdp-endpoint=http://localhost:1234',
  ]);
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(1);
  expect(result.stderr.toString()).toContain('Device emulation is not supported with cdpEndpoint.');
});

test('cdp server with headers', async ({ startClient, server }) => {
  let authHeader = '';
  server.setRoute('/json/version/', (req, res) => {
    authHeader = req.headers['authorization'];
    res.end();
  });

  const { client } = await startClient({ args: [`--cdp-endpoint=${server.PREFIX}`, '--cdp-header', 'Authorization: Bearer 1234567890'] });
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    isError: true,
  });
  expect(authHeader).toBe('Bearer 1234567890');
});

test('cdp server with empty and complex headers', async ({ startClient, server }) => {
  let customHeader = '';
  let emptyHeader = '';
  server.setRoute('/json/version/', (req, res) => {
    customHeader = req.headers['x-forwarded-proto'] as string;
    emptyHeader = req.headers['x-empty'] as string;
    res.end();
  });

  const { client } = await startClient({
    args: [
      `--cdp-endpoint=${server.PREFIX}`,
      '--cdp-header', 'X-Forwarded-Proto: value:with:colons',
      '--cdp-header', 'X-Empty'
    ]
  });
  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    isError: true,
  });
  expect(customHeader).toBe('value:with:colons');
  expect(emptyHeader).toBe('');
});
