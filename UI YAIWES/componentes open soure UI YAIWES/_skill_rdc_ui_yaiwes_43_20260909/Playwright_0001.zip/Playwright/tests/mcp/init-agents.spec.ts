/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { test, expect, writeFiles } from './fixtures';
import { utils } from '../../packages/playwright-core/lib/coreBundle';
import path from 'path';
import fs from 'fs';

const { spawnAsync } = utils;

async function runInitAgents(options?: { args?: string[], cwd?: string }): Promise<{stdout: string, stderr: string, code: number | null, error?: Error}> {
  const result = await spawnAsync('npx', [
    'playwright', 'init-agents',
    ...(options?.args || []),
  ], {
    cwd: options?.cwd,
    shell: true,
  });
  return result;
}

test('create seed file default', async ({  }) => {
  const baseDir = await writeFiles({
    'playwright.config.ts': `
      module.exports = {};
    `,
  });

  await runInitAgents({
    cwd: baseDir,
    args: ['--loop', 'claude'],
  });
  expect(fs.existsSync(path.join(baseDir, 'seed.spec.ts'))).toBe(true);
});

test('create seed file with --project', async ({  }) => {
  const baseDir = await writeFiles({
    'playwright.config.ts': `
      module.exports = { projects: [{ name: 'foo', testDir: 'foo/e2e' }, { name: 'bar', testDir: 'bar/e2e' }, ] };
    `,
  });

  await runInitAgents({
    cwd: baseDir,
    args: ['--loop', 'vscode', '--project', 'bar'],
  });
  expect(fs.existsSync(path.join(baseDir, 'bar', 'e2e', 'seed.spec.ts'))).toBe(true);
});

test('create seed file with --config', async ({  }) => {
  const baseDir = await writeFiles({
    'custom/playwright.config.ts': `
      module.exports = { projects: [{ name: 'foo', testDir: 'foo/e2e' }, { name: 'bar', testDir: 'bar/e2e' }, ] };
    `,
  });

  await runInitAgents({
    cwd: baseDir,
    args: ['--loop', 'vscode', '--config', 'custom/playwright.config.ts', '--project', 'bar'],
  });
  expect(fs.existsSync(path.join(baseDir, 'custom', 'bar', 'e2e', 'seed.spec.ts'))).toBe(true);
});

test('claude generates correct mcp config', async ({  }) => {
  const baseDir = await writeFiles({
    'playwright.config.ts': `module.exports = {};`,
  });

  await runInitAgents({ cwd: baseDir, args: ['--loop', 'claude'] });

  const mcpJson = JSON.parse(fs.readFileSync(path.join(baseDir, '.mcp.json'), 'utf-8'));
  if (process.platform === 'win32') {
    expect(mcpJson.mcpServers['playwright-test'].command).toBe('cmd');
    expect(mcpJson.mcpServers['playwright-test'].args).toEqual(['/c', 'npx', 'playwright', 'run-test-mcp-server']);
  } else {
    expect(mcpJson.mcpServers['playwright-test'].command).toBe('npx');
    expect(mcpJson.mcpServers['playwright-test'].args).toEqual(['playwright', 'run-test-mcp-server']);
  }
});

test('codex generates agent toml files', async ({  }) => {
  const baseDir = await writeFiles({
    'playwright.config.ts': `module.exports = {};`,
  });

  await runInitAgents({ cwd: baseDir, args: ['--loop', 'codex'] });

  const agentsDir = path.join(baseDir, '.codex', 'agents');
  expect(fs.existsSync(agentsDir)).toBe(true);

  const plannerToml = fs.readFileSync(path.join(agentsDir, 'playwright_test_planner.toml'), 'utf-8');
  expect(plannerToml).toContain(`name = "playwright_test_planner"`);
  expect(plannerToml).toContain(`[mcp_servers.playwright-test]`);
  expect(plannerToml).toContain(`developer_instructions = """`);
  if (process.platform === 'win32') {
    expect(plannerToml).toContain(`command = "cmd"`);
    expect(plannerToml).toContain(`args = ["/c", "npx", "playwright", "run-test-mcp-server"]`);
  } else {
    expect(plannerToml).toContain(`command = "npx"`);
    expect(plannerToml).toContain(`args = ["playwright", "run-test-mcp-server"]`);
  }

  expect(plannerToml).toContain(`sandbox_mode = "read-only"`);
  expect(plannerToml).toMatch(/enabled_tools = \[[^\]]*"planner_save_plan"[^\]]*\]/);
  expect(plannerToml).toMatch(/enabled_tools = \[[^\]]*"browser_navigate"[^\]]*\]/);

  const healerToml = fs.readFileSync(path.join(agentsDir, 'playwright_test_healer.toml'), 'utf-8');
  expect(healerToml).toContain(`sandbox_mode = "workspace-write"`);
  expect(healerToml).toMatch(/enabled_tools = \[[^\]]*"test_debug"[^\]]*\]/);
});

test('init-skills installs all skills', async ({  }) => {
  const baseDir = await writeFiles({});

  await spawnAsync('npx', ['playwright', 'init-skills'], { cwd: baseDir, shell: true });

  for (const skill of ['playwright-cli', 'playwright-component-testing', 'playwright-trace'])
    expect(fs.existsSync(path.join(baseDir, '.claude', 'skills', skill, 'SKILL.md'))).toBe(true);
  expect(fs.existsSync(path.join(baseDir, '.claude', 'skills', 'playwright-cli', 'references', 'tracing.md'))).toBe(true);
});

test('init-skills installs into .agents with --loop agents', async ({  }) => {
  const baseDir = await writeFiles({});

  await spawnAsync('npx', ['playwright', 'init-skills', '--loop', 'agents'], { cwd: baseDir, shell: true });

  for (const skill of ['playwright-cli', 'playwright-component-testing', 'playwright-trace'])
    expect(fs.existsSync(path.join(baseDir, '.agents', 'skills', skill, 'SKILL.md'))).toBe(true);
});
