/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import crypto from 'crypto';
import fs from 'fs';
import { pathToFileURL } from 'url';

import { test, expect } from './fixtures';

const p = process.platform === 'win32' ? 'c:\\non\\existent\\folder' : '/non/existent/folder';

test('should use separate user data by root path', async ({ startClient, server }, testInfo) => {
  const { client } = await startClient({
    clientName: 'Visual Studio Code',
    roots: [
      {
        name: 'test',
        uri: 'file://' + p.replace(/\\/g, '/'),
      }
    ],
  });

  await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  });

  const hash = createHash(p);
  const [file] = await fs.promises.readdir(testInfo.outputPath('ms-playwright'));
  expect(file).toContain(hash);
});

test('should list all tools when listRoots is slow', async ({ startClient }) => {
  const { client } = await startClient({
    clientName: 'Another custom client',
    roots: [],
    rootsResponseDelay: 1000,
  });
  const tools = await client.listTools();
  expect(tools.tools.length).toBeGreaterThan(10);
});

test('should tolerate malformed roots', async ({ startClient, server }, testInfo) => {
  const { client } = await startClient({
    clientName: 'Visual Studio Code',
    roots: [
      {
        name: 'test',
        uri: 'bogus://' + p.replace(/\\/g, '/'),
      }
    ],
  });

  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    code: expect.stringContaining(`page.goto('http://localhost`),
  });

  const [file] = await fs.promises.readdir(testInfo.outputPath('ms-playwright'));
  expect(file).toMatch(/mcp-.*/);
});

test('should tolerate WSL client roots on Windows server', async ({ startClient, server }, testInfo) => {
  test.skip(process.platform !== 'win32');
  const { client } = await startClient({
    clientName: 'client',
    roots: [
      {
        name: 'test',
        uri: 'file:///mnt/c/users/username/Desktop',
      }
    ],
  });

  expect(await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  })).toHaveResponse({
    code: expect.stringContaining(`page.goto('http://localhost`),
  });

  const [file] = await fs.promises.readdir(testInfo.outputPath('ms-playwright'));
  expect(file).toMatch(/mcp-.*/);
});

function createHash(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex').slice(0, 7);
}

test('should return relative paths when root is specified', async ({ startClient, server }, testInfo) => {
  const rootPath = testInfo.outputPath('workspace');
  await fs.promises.mkdir(rootPath, { recursive: true });

  const { client } = await startClient({
    clientName: 'test-client',
    roots: [
      {
        name: 'workspace',
        uri: pathToFileURL(rootPath).toString(),
      },
    ],
  });

  await client.callTool({
    name: 'browser_navigate',
    arguments: { url: server.HELLO_WORLD },
  });

  expect(await client.callTool({
    name: 'browser_take_screenshot',
    arguments: { filename: 'screenshot.png' },
  })).toHaveResponse({
    result: expect.stringContaining(`[Screenshot of viewport](./screenshot.png)`),
  });
});
