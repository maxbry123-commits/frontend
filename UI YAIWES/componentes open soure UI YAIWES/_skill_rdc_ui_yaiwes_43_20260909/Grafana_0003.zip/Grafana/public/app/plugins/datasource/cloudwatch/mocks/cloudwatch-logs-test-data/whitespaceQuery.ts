export const logsTestDataWhitespaceOnlyQuery = {
  query: `   `,
};
