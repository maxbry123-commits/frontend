import { css } from '@emotion/css';

import { type GrafanaTheme2, type DataSourceInstanceSettings } from '@grafana/data';
import { ConfigSection } from '@grafana/plugin-ui';
import { DataSourcePicker } from '@grafana/runtime';
import { useHasDataSourceInstance } from '@grafana/runtime/unstable';
import { Alert, Field, InlineField, useStyles2 } from '@grafana/ui';

const getStyles = (theme: GrafanaTheme2) => ({
  infoText: css({
    paddingBottom: theme.spacing(2),
    color: theme.colors.text.secondary,
  }),
});

interface Props {
  datasourceUid?: string;
  onChange: (uid: string) => void;
  newFormStyling?: boolean;
}

const xRayDsId = 'grafana-x-ray-datasource';

export function XrayLinkConfig({ newFormStyling, datasourceUid, onChange }: Props) {
  const { isLoading, error, hasInstance: hasXrayDatasource } = useHasDataSourceInstance(xRayDsId);

  const styles = useStyles2(getStyles);

  return newFormStyling ? (
    <ConfigSection
      title="Application Signals trace link"
      description="Grafana will automatically create a link to a trace in Application Signals data source if logs contain @xrayTraceId field"
    >
      {!isLoading && !error && !hasXrayDatasource && (
        <Alert
          title={
            'There is no Application Signals datasource to link to. First add an Application Signals data source and then link it to Cloud Watch. '
          }
          severity="info"
        />
      )}
      <Field
        htmlFor="data-source-picker"
        label="Data source"
        description="Application Signals data source containing traces"
      >
        <DataSourcePicker
          pluginId={xRayDsId}
          onChange={(ds: DataSourceInstanceSettings) => onChange(ds.uid)}
          current={datasourceUid}
          noDefault={true}
        />
      </Field>
    </ConfigSection>
  ) : (
    <>
      <h3 className="page-heading">Application Signals trace link</h3>

      <div className={styles.infoText}>
        Grafana will automatically create a link to a trace in Application Signals data source if logs contain
        @xrayTraceId field
      </div>

      {!isLoading && !error && !hasXrayDatasource && (
        <Alert
          title={
            'There is no Application Signals datasource to link to. First add an Application Signals data source and then link it to Cloud Watch. '
          }
          severity="info"
        />
      )}

      <div className="gf-form-group">
        <InlineField
          htmlFor="data-source-picker"
          label="Data source"
          labelWidth={28}
          tooltip="Application Signals data source containing traces"
        >
          <DataSourcePicker
            pluginId={xRayDsId}
            onChange={(ds: DataSourceInstanceSettings) => onChange(ds.uid)}
            current={datasourceUid}
            noDefault={true}
          />
        </InlineField>
      </div>
    </>
  );
}
