export const forbiddenElements = ['iframe'];
