import { css } from '@emotion/css';
import { useMemo, useState } from 'react';

import { type GrafanaTheme2, type SelectableValue } from '@grafana/data';
import { Trans, t } from '@grafana/i18n';
import { Alert, Button, Card, ConfirmModal, Field, LinkButton, Select, Stack, Tooltip, useStyles2 } from '@grafana/ui';

import { hasConfiguredUid, isOperatorManaged } from '../../utils/autoSync';

import { AutoSyncStatusBadge } from './AutoSyncStatusBadge';
import { useAutoSyncConfiguration } from './useAutoSyncConfiguration';

interface AutoSyncConfigurationProps {
  /** Identifier of the staged import occupying the shared `extra_config` slot, if there is one. */
  stagedConfigIdentifier?: string;
}

export function AutoSyncConfiguration({ stagedConfigIdentifier }: AutoSyncConfigurationProps) {
  const styles = useStyles2(getStyles);
  const {
    state,
    autoSyncEligibleAlertmanagers,
    selectedUid,
    setSelectedUid,
    save,
    disableSync,
    isPending,
    isLoading,
    notReadyMessage,
  } = useAutoSyncConfiguration();

  const [showDisableConfirm, setShowDisableConfirm] = useState(false);

  const options = useMemo<Array<SelectableValue<string>>>(
    () =>
      autoSyncEligibleAlertmanagers.map((ds) => ({
        value: ds.uid,
        label: ds.name,
        imgUrl: ds.typeLogoUrl,
      })),
    [autoSyncEligibleAlertmanagers]
  );

  const operatorManaged = isOperatorManaged(state);
  const showDisableSync = state.kind === 'configured' || state.kind === 'orphan-uid';
  const showSave = state.kind === 'unconfigured' || state.kind === 'orphan-uid';
  const savedUid = hasConfiguredUid(state) ? state.uid : '';

  // A sync tick writes its datasource UID into the single extra_config slot without replacing what is
  // already there, so it fails server-side unless the slot is empty or holds that same UID.
  const slotBlocksSyncFrom = (uid: string) => Boolean(stagedConfigIdentifier) && stagedConfigIdentifier !== uid;

  const savingWouldBreakSync = slotBlocksSyncFrom(selectedUid);
  const runningSyncIsBroken = Boolean(savedUid) && slotBlocksSyncFrom(savedUid);

  const saveDisabledReason = getSaveDisabledReason({ notReadyMessage, selectedUid, savedUid, savingWouldBreakSync });

  const handleDisableConfirm = async () => {
    setShowDisableConfirm(false);
    await disableSync();
  };

  return (
    <Card
      noMargin
      className={styles.cardSpacing}
      role="region"
      aria-label={t('alerting.settings.auto-sync.title', 'Auto-sync configuration')}
    >
      <Card.Heading>
        <Stack alignItems="center" gap={1}>
          <Trans i18nKey="alerting.settings.auto-sync.title">Auto-sync configuration</Trans>
          <AutoSyncStatusBadge state={state} />
        </Stack>
      </Card.Heading>
      <Card.Description>
        <Trans i18nKey="alerting.settings.auto-sync.description">
          Continuously sync alert configuration from a Mimir or Cortex Alertmanager datasource into Grafana.
        </Trans>
      </Card.Description>
      <Card.Meta>
        <div className={styles.formColumn}>
          {state.kind === 'orphan-uid' && (
            <Alert
              severity="warning"
              title={t('alerting.settings.auto-sync.orphan-warning-title', 'Configured datasource not found')}
            >
              <Trans i18nKey="alerting.settings.auto-sync.orphan-warning" values={{ uid: state.uid }}>
                The configured datasource UID {'{{uid}}'} is not available. Disable sync or restore the datasource to
                continue.
              </Trans>
            </Alert>
          )}
          {operatorManaged && (
            <Alert
              severity="info"
              title={t('alerting.settings.auto-sync.operator-managed-title', 'Managed by operator')}
            >
              <Trans i18nKey="alerting.settings.auto-sync.operator-managed-info">
                This value is set by the <code>[unified_alerting] external_alertmanager_uid</code> key in grafana.ini
                and cannot be changed from the UI. Edit the configuration file and restart Grafana, or remove the key to
                manage sync from here.
              </Trans>
            </Alert>
          )}
          {(runningSyncIsBroken || (showSave && savingWouldBreakSync)) && (
            <StagedConflictAlert identifier={stagedConfigIdentifier} isRunningSyncBroken={runningSyncIsBroken} />
          )}
          <div className={styles.formRow}>
            <Field
              noMargin
              label={t('alerting.settings.auto-sync.picker-label', 'Datasource')}
              className={styles.field}
              htmlFor="auto-sync-datasource-picker"
            >
              {state.kind === 'no-datasources' ? (
                <div className={styles.noDatasourcesRow}>
                  <span className={styles.muted}>
                    <Trans i18nKey="alerting.settings.auto-sync.picker-empty">
                      No Mimir or Cortex datasources available
                    </Trans>
                  </span>
                  <LinkButton
                    href="/connections/datasources/alertmanager"
                    icon="plus"
                    variant="secondary"
                    fill="outline"
                  >
                    <Trans i18nKey="alerting.settings.auto-sync.add-datasource-link">Add Mimir datasource</Trans>
                  </LinkButton>
                </div>
              ) : (
                <Select
                  inputId="auto-sync-datasource-picker"
                  aria-label={t('alerting.settings.auto-sync.picker-label', 'Datasource')}
                  options={options}
                  value={selectedUid || null}
                  // Stays selectable during a conflict: picking the staged identifier's datasource resolves it.
                  onChange={(option) => option?.value && setSelectedUid(option.value)}
                  disabled={operatorManaged || isLoading}
                  isLoading={isLoading}
                  width={50}
                  placeholder={t(
                    'alerting.settings.auto-sync.picker-placeholder',
                    'Select a Mimir or Cortex Alertmanager datasource…'
                  )}
                  noOptionsMessage={t(
                    'alerting.settings.auto-sync.picker-empty',
                    'No Mimir or Cortex datasources available'
                  )}
                />
              )}
            </Field>
            {state.kind !== 'no-datasources' && (
              <Stack direction="row" gap={1} alignItems="flex-end">
                {showDisableSync && (
                  <Button
                    variant="destructive"
                    fill="outline"
                    onClick={() => setShowDisableConfirm(true)}
                    disabled={isPending}
                    icon="times"
                  >
                    <Trans i18nKey="alerting.settings.auto-sync.action-disable">Disable sync</Trans>
                  </Button>
                )}
                {showSave && (
                  <Tooltip content={saveDisabledReason ?? ''} show={saveDisabledReason ? undefined : false}>
                    <span className={styles.tooltipTarget}>
                      <Button
                        variant="primary"
                        onClick={() => save()}
                        disabled={Boolean(saveDisabledReason) || isPending}
                      >
                        <Trans i18nKey="common.save">Save</Trans>
                      </Button>
                    </span>
                  </Tooltip>
                )}
              </Stack>
            )}
          </div>
        </div>
      </Card.Meta>
      <ConfirmModal
        isOpen={showDisableConfirm}
        title={t('alerting.settings.auto-sync.disable-confirm-title', 'Disable Mimir Alertmanager auto-sync?')}
        body={
          hasConfiguredUid(state)
            ? t(
                'alerting.settings.auto-sync.disable-confirm-body',
                'Disabling will stop continuous sync from datasource {{uid}}. You can re-enable it later by selecting a datasource again.',
                { uid: state.uid }
              )
            : t(
                'alerting.settings.auto-sync.disable-confirm-body-generic',
                'Disabling will stop continuous sync. You can re-enable it later by selecting a datasource again.'
              )
        }
        confirmText={t('alerting.settings.auto-sync.disable-confirm-action', 'Disable sync')}
        onConfirm={handleDisableConfirm}
        onDismiss={() => setShowDisableConfirm(false)}
      />
    </Card>
  );
}

interface StagedConflictAlertProps {
  identifier?: string;
  /** Sync is enabled and its ticks are already failing, rather than a save being blocked before the fact. */
  isRunningSyncBroken: boolean;
}

function StagedConflictAlert({ identifier, isRunningSyncBroken }: StagedConflictAlertProps) {
  return (
    <Alert
      severity={isRunningSyncBroken ? 'error' : 'warning'}
      title={
        isRunningSyncBroken
          ? t('alerting.settings.auto-sync.staged-conflict-active-title', 'Auto-sync is not running')
          : t(
              'alerting.settings.auto-sync.staged-conflict-title',
              'Auto-sync is unavailable while a configuration is staged'
            )
      }
    >
      <Trans i18nKey="alerting.settings.auto-sync.staged-conflict-body" values={{ identifier }}>
        Grafana holds one imported configuration at a time, and {'{{identifier}}'} currently occupies that slot. Promote
        or revert it below to free auto-sync.
      </Trans>
    </Alert>
  );
}

function getSaveDisabledReason({
  notReadyMessage,
  selectedUid,
  savedUid,
  savingWouldBreakSync,
}: {
  notReadyMessage: string | undefined;
  selectedUid: string;
  savedUid: string;
  savingWouldBreakSync: boolean;
}): string | undefined {
  // Set exactly when the hook is not ready, and already distinguishes an unseeded singleton from a
  // failed read — the second is not something waiting fixes.
  if (notReadyMessage) {
    return notReadyMessage;
  }
  if (savingWouldBreakSync) {
    return t(
      'alerting.settings.auto-sync.save-disabled-staged-config',
      'Promote or revert the staged configuration before enabling auto-sync.'
    );
  }
  if (!selectedUid || selectedUid === savedUid) {
    return t(
      'alerting.settings.auto-sync.save-disabled-no-selection',
      'Select a Mimir or Cortex Alertmanager datasource to enable saving.'
    );
  }
  return undefined;
}

const getStyles = (theme: GrafanaTheme2) => ({
  cardSpacing: css({
    '& > * + *': {
      marginTop: theme.spacing(2),
    },
  }),
  formColumn: css({
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
    width: '100%',
  }),
  formRow: css({
    display: 'flex',
    gap: theme.spacing(2),
    alignItems: 'flex-end',
    width: '100%',
  }),
  field: css({
    marginBottom: 0,
  }),
  noDatasourcesRow: css({
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
    padding: theme.spacing(1, 0),
    width: '100%',
  }),
  muted: css({
    color: theme.colors.text.secondary,
  }),
  tooltipTarget: css({
    display: 'inline-flex',
  }),
});
