package engine

import (
	"flag"
	"fmt"
	"net"
	"net/http"
	"time"

	"github.com/go-kit/log"
	"github.com/go-kit/log/level"
	"github.com/gorilla/mux"
	"github.com/grafana/dskit/services"
	"github.com/pkg/errors"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/thanos-io/objstore"

	"github.com/grafana/loki/v3/pkg/dataobj/consumer/logsobj"
	"github.com/grafana/loki/v3/pkg/dataobj/metastore"
	"github.com/grafana/loki/v3/pkg/engine/internal/executor"
	"github.com/grafana/loki/v3/pkg/engine/internal/scheduler/wire"
	"github.com/grafana/loki/v3/pkg/engine/internal/worker"
	"github.com/grafana/loki/v3/pkg/scratch"
)

// WorkerConfig represents the configuration for the [Worker].
type WorkerConfig struct {
	WorkerThreads int `yaml:"worker_threads" category:"experimental"`

	SchedulerLookupAddress  string        `yaml:"scheduler_lookup_address" category:"experimental"`
	SchedulerLookupInterval time.Duration `yaml:"scheduler_lookup_interval" category:"experimental"`
}

func (cfg *WorkerConfig) RegisterFlagsWithPrefix(prefix string, f *flag.FlagSet) {
	f.IntVar(&cfg.WorkerThreads, prefix+"worker-threads", 0, "Experimental: Number of worker threads to spawn. Each worker thread runs one task at a time. 0 means to use GOMAXPROCS value.")
	f.StringVar(&cfg.SchedulerLookupAddress, prefix+"scheduler-lookup-address", "", "Experimental: Address holding DNS SRV records of schedulers to connect to.")
	f.DurationVar(&cfg.SchedulerLookupInterval, prefix+"scheduler-lookup-interval", 10*time.Second, "Experimental: Interval at which to lookup new schedulers by DNS SRV records.")
}

// WorkerParams holds parameters for constructing a new [Worker].
type WorkerParams struct {
	Logger    log.Logger          // Logger for optional log messages.
	Bucket    objstore.Bucket     // Bucket to read stored data from.
	Metastore metastore.Metastore // Metastore to access indexes.

	// DataBucket reads source log objects during LogMerge compaction. When
	// Bucket is prefixed with the index-storage prefix (compaction wiring),
	// source log objects live at the unprefixed dataobj root and must be read
	// through this bucket. Optional; nil falls back to Bucket.
	DataBucket objstore.Bucket

	Config   WorkerConfig   // Configuration for the worker.
	Executor ExecutorConfig // Configuration for task execution.

	// Local scheduler to connect to. If LocalScheduler is nil, the worker can
	// still connect to remote schedulers.
	LocalScheduler *Scheduler

	// Address to advertise to other workers and schedulers. Must be set when
	// the worker runs in remote transport mode.
	//
	// If nil, the worker only listens for in-process connections.
	AdvertiseAddr net.Addr

	// Absolute path of the endpoint where the frame handler is registered.
	// Used for connecting to scheduler and other workers.
	Endpoint string

	// StreamFilterer is an optional filterer that can filter streams based on their labels.
	// When set, streams are filtered before scanning.
	StreamFilterer executor.RequestStreamFilterer

	// ScratchStore is an optional scratch store for index merge operations.
	// Required for compaction tasks; may be nil for query-only workers.
	ScratchStore scratch.Store

	// IndexobjCfg is the builder config for compacted index objects.
	// Required for compaction tasks; may be the zero value for query-only workers.
	IndexobjCfg logsobj.BuilderBaseConfig

	// LogsobjCfg is the builder config for compacted log objects
	// Required for compaction tasks; may be the zero-value for query-only workers.
	LogsobjCfg logsobj.BuilderBaseConfig

	// IndexMergeObserver is used  by compaction to populate output-size
	// histograms. Optional; nil for query-only workers.
	IndexMergeObserver executor.IndexMergeObserver
	LogMergeObserver   executor.LogMergeObserver
}

// Worker requests tasks from a [Scheduler] and executes them. Task results are
// sent to other [Worker] instances or back to the [Scheduler].
type Worker struct {
	// Our public API is a lightweight wrapper around the internal API.

	inner    *worker.Worker
	endpoint string
	handler  http.Handler
}

// NewWorker creates a new Worker instance. Use [Worker.Service] to manage the
// lifecycle of the Worker.
func NewWorker(params WorkerParams, reg prometheus.Registerer) (*Worker, error) {
	if params.Config.SchedulerLookupAddress != "" && params.Config.SchedulerLookupInterval == 0 {
		return nil, errors.New("scheduler lookup interval must be non-zero when a scheduler lookup address is provided")
	}

	if params.Config.SchedulerLookupInterval < time.Second {
		level.Warn(params.Logger).Log("msg", "scheduler lookup interval is configured to be less than 1 second, overriding to 1 second")
		params.Config.SchedulerLookupInterval = time.Second
	}

	if params.Endpoint == "" {
		params.Endpoint = "/api/v2/frame"
	}

	var (
		listener wire.Listener
		handler  http.Handler
		dialer   wire.Dialer

		// localSchedulerAddress is the local scheduler to connect to. Left nil
		// when using remote transport.
		localSchedulerAddress net.Addr
	)

	switch {
	case params.AdvertiseAddr != nil:
		remoteListener := wire.NewHTTP2Listener(
			params.AdvertiseAddr,
			wire.WithHTTP2ListenerLogger(params.Logger),
		)
		listener, handler = remoteListener, remoteListener
		dialer = wire.NewHTTP2Dialer(params.Endpoint)

	case params.LocalScheduler != nil:
		localListener := &wire.Local{Address: wire.LocalWorker}
		listener = localListener

		schedulerListener, ok := params.LocalScheduler.listener.(*wire.Local)
		if !ok {
			return nil, errors.New("scheduler is not configured for local traffic")
		}

		dialer = wire.NewLocalDialer(localListener, schedulerListener)
		localSchedulerAddress = wire.LocalScheduler

	default:
		return nil, errors.New("either an advertise address or a local scheduler listener must be provided")
	}

	taskCaches, err := executor.NewTaskCacheRegistry(params.Executor.TaskResultsCache.Config, reg, params.Logger)
	if err != nil {
		return nil, fmt.Errorf("creating task results cache: %w", err)
	}

	inner, err := worker.New(worker.Config{
		Logger:     params.Logger,
		Bucket:     params.Bucket,
		DataBucket: params.DataBucket,
		Metastore:  params.Metastore,

		Dialer:   dialer,
		Listener: listener,

		SchedulerAddress:        localSchedulerAddress,
		SchedulerLookupAddress:  params.Config.SchedulerLookupAddress,
		SchedulerLookupInterval: params.Config.SchedulerLookupInterval,

		BatchSize:     int64(params.Executor.BatchSize),
		PrefetchBytes: int64(params.Executor.PrefetchBytes),
		NumThreads:    params.Config.WorkerThreads,

		Endpoint: params.Endpoint,

		StreamFilterer: params.StreamFilterer,
		TaskCaches:     taskCaches,
		ScratchStore:   params.ScratchStore,
		IndexobjCfg:    params.IndexobjCfg,
		LogsobjCfg:     params.LogsobjCfg,

		IndexMergeObserver: params.IndexMergeObserver,
		LogMergeObserver:   params.LogMergeObserver,
	})
	if err != nil {
		return nil, err
	}

	return &Worker{
		inner:    inner,
		endpoint: params.Endpoint,
		handler:  handler,
	}, nil
}

// RegisterWorkerServer registers the [wire.Listener] of the inner worker as
// http.Handler on the provided router.
//
// RegisterWorkerServer is a no-op if an advertise address is not provided.
func (w *Worker) RegisterWorkerServer(router *mux.Router) {
	if w.handler == nil {
		return
	}
	router.Path(w.endpoint).Methods("POST").Handler(w.handler)
}

// Service returns the service used to manage the lifecycle of the Worker.
func (w *Worker) Service() services.Service {
	return w.inner.Service()
}

// RegisterMetrics registers metrics about w to report to reg.
func (w *Worker) RegisterMetrics(reg prometheus.Registerer) error {
	return w.inner.RegisterMetrics(reg)
}

// UnregisterMetrics unregisters metrics about w from reg.
func (w *Worker) UnregisterMetrics(reg prometheus.Registerer) {
	w.inner.UnregisterMetrics(reg)
}
