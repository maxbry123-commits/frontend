package physical

import (
	"bytes"
	"fmt"
	"regexp"
	"strings"

	"github.com/apache/arrow-go/v18/arrow"
	"github.com/apache/arrow-go/v18/arrow/memory"
	"github.com/apache/arrow-go/v18/arrow/scalar"

	"github.com/grafana/loki/v3/pkg/dataobj/sections/logs"
	"github.com/grafana/loki/v3/pkg/engine/internal/executor/matchutil"
	"github.com/grafana/loki/v3/pkg/engine/internal/types"
)

// BuildLogsPredicate builds a [logs.Predicate] from an expr. The columns slice
// determines available columns that can be referenced by the expression.
//
// The returned predicate performs no filtering on stream ID; callers must use
// [logs.AndPredicate] and manually include filters for stream IDs if desired.
//
// References to columns that do not exist in the columns slice map to a
// [logs.FalsePredicate].
//
// BuildLogsPredicate returns an error if:
//
//   - Expressions cannot be represented as a boolean value
//   - An expression is not supported (such as comparing two columns or comparing
//     two literals).
//
// The structural errors returned here are the canonical "can the executor
// evaluate this?" answer: the physical planner calls [validateLogsPredicate]
// (a thin wrapper that discards the predicate) at the end of [Planner.Optimize]
// so unsupported expressions surface as planning errors rather than execution
// errors.
func BuildLogsPredicate(expr Expression, columns []*logs.Column) (logs.Predicate, error) {
	switch expr := expr.(type) {
	case UnaryExpression:
		return buildLogsUnaryPredicate(expr, columns)

	case BinaryExpression:
		return buildLogsBinaryPredicate(expr, columns)

	case *LiteralExpr:
		if expr.ValueType() == types.Loki.Bool {
			val := expr.Value().(bool)
			if val {
				return logs.TruePredicate{}, nil
			}
			return logs.FalsePredicate{}, nil
		}

	case *ColumnExpr:
		// TODO(rfratto): This would add support for statements like
		//
		// SELECT * WHERE boolean_column
		//
		// (where boolean_column is a column containing boolean values). No such
		// column type exists now, so I'm leaving it unsupported here for the time
		// being.
		return nil, fmt.Errorf("plain column references (%s) are unsupported for logs predicates", expr)

	default:
		// TODO(rfratto): This doesn't yet cover two potential future cases:
		//
		// * A plain boolean literal
		// * A reference to a column containing boolean values
		return nil, fmt.Errorf("expression %[1]s (type %[1]T) cannot be interpreted as a boolean", expr)
	}

	return nil, fmt.Errorf("expression %[1]s (type %[1]T) cannot be interpreted as a boolean", expr)
}

// validateLogsPredicate reports whether expr can be converted into a
// [logs.Predicate]. It is a thin wrapper around [BuildLogsPredicate] that
// discards the resulting predicate.
//
// Because BuildLogsPredicate's "unsupported" branches are structural
// (operator/expression shape, literal type, regex compilation, value/op
// compatibility), passing a nil columns slice is sufficient: missing-column
// branches degrade silently into True/False predicates without raising errors.
func validateLogsPredicate(expr Expression) error {
	_, err := BuildLogsPredicate(expr, nil)
	return err
}

func buildLogsUnaryPredicate(expr UnaryExpression, columns []*logs.Column) (logs.Predicate, error) {
	unaryExpr, ok := expr.(*UnaryExpr)
	if !ok {
		return nil, fmt.Errorf("expected UnaryExpr, got %[1]T", expr)
	}

	inner, err := BuildLogsPredicate(unaryExpr.Left, columns)
	if err != nil {
		return nil, fmt.Errorf("building unary predicate: %w", err)
	}

	switch unaryExpr.Op {
	case types.UnaryOpNot:
		return logs.NotPredicate{Inner: inner}, nil
	}

	return nil, fmt.Errorf("unsupported unary operator %s in logs predicate", unaryExpr.Op)
}

var logsComparisonBinaryOps = map[types.BinaryOp]struct{}{
	types.BinaryOpEq:                            {},
	types.BinaryOpNeq:                           {},
	types.BinaryOpGt:                            {},
	types.BinaryOpGte:                           {},
	types.BinaryOpLt:                            {},
	types.BinaryOpLte:                           {},
	types.BinaryOpMatchSubstr:                   {},
	types.BinaryOpNotMatchSubstr:                {},
	types.BinaryOpMatchRe:                       {},
	types.BinaryOpNotMatchRe:                    {},
	types.BinaryOpMatchPattern:                  {},
	types.BinaryOpNotMatchPattern:               {},
	types.BinaryOpEqCaseInsensitive:             {},
	types.BinaryOpNotEqCaseInsensitive:          {},
	types.BinaryOpMatchSubstrCaseInsensitive:    {},
	types.BinaryOpNotMatchSubstrCaseInsensitive: {},
}

func buildLogsBinaryPredicate(expr BinaryExpression, columns []*logs.Column) (logs.Predicate, error) {
	binaryExpr, ok := expr.(*BinaryExpr)
	if !ok {
		return nil, fmt.Errorf("expected BinaryExpr, got %[1]T", expr)
	}

	switch binaryExpr.Op {
	case types.BinaryOpAnd:
		left, err := BuildLogsPredicate(binaryExpr.Left, columns)
		if err != nil {
			return nil, fmt.Errorf("building left binary predicate: %w", err)
		}
		right, err := BuildLogsPredicate(binaryExpr.Right, columns)
		if err != nil {
			return nil, fmt.Errorf("building right binary predicate: %w", err)
		}
		return logs.AndPredicate{Left: left, Right: right}, nil

	case types.BinaryOpOr:
		left, err := BuildLogsPredicate(binaryExpr.Left, columns)
		if err != nil {
			return nil, fmt.Errorf("building left binary predicate: %w", err)
		}
		right, err := BuildLogsPredicate(binaryExpr.Right, columns)
		if err != nil {
			return nil, fmt.Errorf("building right binary predicate: %w", err)
		}
		return logs.OrPredicate{Left: left, Right: right}, nil
	}

	if _, ok := logsComparisonBinaryOps[binaryExpr.Op]; ok {
		return buildLogsComparison(binaryExpr, columns)
	}

	return nil, fmt.Errorf("expression %[1]s (type %[1]T) cannot be interpreted as a boolean", expr)
}

func buildLogsComparison(expr *BinaryExpr, columns []*logs.Column) (logs.Predicate, error) {
	// Currently, we only support comparisons where the left-hand side is a
	// [ColumnExpr] and the right-hand side is a [LiteralExpr].
	//
	// Support for other cases could be added in the future:
	//
	// * LHS LiteralExpr, RHS ColumnExpr could be supported by inverting the
	//   operation.
	// * LHS LiteralExpr, RHS LiteralExpr could be supported by evaluating the
	//   expresion immediately.
	// * LHS ColumnExpr, RHS ColumnExpr could be supported in the future, but would need
	//   support down to the dataset level.

	columnRef, leftValid := expr.Left.(*ColumnExpr)
	literalExpr, rightValid := expr.Right.(*LiteralExpr)

	if !leftValid || !rightValid {
		return nil, fmt.Errorf("binary comparisons require the left-hand operation to reference a column (got %T) and the right-hand operation to be a literal (got %T)", expr.Left, expr.Right)
	}

	// findLogsColumn may return nil for col if the referenced column doesn't
	// exist; this is handled in the switch statement below and converts to
	// either [logs.FalsePredicate] or [logs.TruePredicate] depending on the
	// operation.
	col, err := findLogsColumn(columnRef.Ref, columns)
	if err != nil {
		return nil, fmt.Errorf("finding column %s: %w", columnRef.Ref, err)
	}

	s, err := buildLogsScalar(literalExpr)
	if err != nil {
		return nil, err
	}

	// When the column is absent from this section, LogQL says an absent label
	// compares as the empty string "" — the same semantic the post-scan filter
	// layer already applies. Evaluate the operator against "" and prune the
	// section accordingly. predicateForAbsentColumn returns ok=false to
	// indicate the op/literal combination isn't string-shaped and the caller
	// should fall through to the per-op default (preserved below for null
	// literals and for numeric comparisons that aren't meaningful against "").
	if col == nil {
		if p, ok, err := predicateForAbsentColumn(expr.Op, s); err != nil {
			return nil, err
		} else if ok {
			return p, nil
		}
	}

	switch expr.Op {
	case types.BinaryOpEq:
		if col == nil && s.IsValid() {
			return logs.FalsePredicate{}, nil // Column(NULL) == non-null: always fails
		} else if col == nil && !s.IsValid() {
			return logs.TruePredicate{}, nil // Column(NULL) == NULL: always passes
		}
		return logs.EqualPredicate{Column: col, Value: s}, nil

	case types.BinaryOpNeq:
		if col == nil && s.IsValid() {
			return logs.TruePredicate{}, nil // Column(NULL) != non-null: always passes
		} else if col == nil && !s.IsValid() {
			return logs.FalsePredicate{}, nil // Column(NULL) != NULL: always fails
		}
		return logs.NotPredicate{Inner: logs.EqualPredicate{Column: col, Value: s}}, nil

	case types.BinaryOpGt:
		if col == nil {
			return logs.FalsePredicate{}, nil // Column(NULL) > value: always fails
		}
		return logs.GreaterThanPredicate{Column: col, Value: s}, nil

	case types.BinaryOpGte:
		if col == nil {
			return logs.FalsePredicate{}, nil // Column(NULL) >= value: always fails
		}
		return logs.OrPredicate{
			Left:  logs.GreaterThanPredicate{Column: col, Value: s},
			Right: logs.EqualPredicate{Column: col, Value: s},
		}, nil

	case types.BinaryOpLt:
		if col == nil {
			return logs.FalsePredicate{}, nil // Column(NULL) < value: always fails
		}
		return logs.LessThanPredicate{Column: col, Value: s}, nil

	case types.BinaryOpLte:
		if col == nil {
			return logs.FalsePredicate{}, nil // Column(NULL) <= value: always fails
		}
		return logs.OrPredicate{
			Left:  logs.LessThanPredicate{Column: col, Value: s},
			Right: logs.EqualPredicate{Column: col, Value: s},
		}, nil

	case types.BinaryOpMatchSubstr, types.BinaryOpMatchRe, types.BinaryOpMatchPattern:
		if col == nil {
			return logs.FalsePredicate{}, nil // Match operations against a non-existent column will always fail.
		}
		return buildLogsMatch(col, expr.Op, s)

	case types.BinaryOpNotMatchSubstr, types.BinaryOpNotMatchRe, types.BinaryOpNotMatchPattern:
		if col == nil {
			return logs.TruePredicate{}, nil // Not match operations against a non-existent column will always pass.
		}
		return buildLogsMatch(col, expr.Op, s)

	case types.BinaryOpEqCaseInsensitive:
		if col == nil && s.IsValid() {
			return logs.FalsePredicate{}, nil // Column(NULL) == non-null: always fails
		} else if col == nil && !s.IsValid() {
			return logs.TruePredicate{}, nil // Column(NULL) == NULL: always passes
		}
		return buildLogsCaseInsensitiveMatch(col, expr.Op, s)

	case types.BinaryOpNotEqCaseInsensitive:
		if col == nil && s.IsValid() {
			return logs.TruePredicate{}, nil // Column(NULL) != non-null: always passes
		} else if col == nil && !s.IsValid() {
			return logs.FalsePredicate{}, nil // Column(NULL) != NULL: always fails
		}
		inner, err := buildLogsCaseInsensitiveMatch(col, types.BinaryOpEqCaseInsensitive, s)
		if err != nil {
			return nil, err
		}
		return logs.NotPredicate{Inner: inner}, nil

	case types.BinaryOpMatchSubstrCaseInsensitive:
		if col == nil {
			return logs.FalsePredicate{}, nil // Match operations against a non-existent column will always fail.
		}
		return buildLogsCaseInsensitiveMatch(col, expr.Op, s)

	case types.BinaryOpNotMatchSubstrCaseInsensitive:
		if col == nil {
			return logs.TruePredicate{}, nil // Not match operations against a non-existent column will always pass.
		}
		return buildLogsCaseInsensitiveMatch(col, expr.Op, s)
	}

	return nil, fmt.Errorf("unsupported binary operator %s in logs predicate", expr.Op)
}

// predicateForAbsentColumn returns the section-level predicate for an
// expression of the form `<absent column> op literal`. LogQL semantics — also
// applied by the post-scan filter layer — treat an absent label as the empty
// string "", so for string-typed literals the predicate reduces to a constant:
// evaluate `"" op literal` and return TruePredicate (every row in the section
// matches) or FalsePredicate (none match).
//
// Returns ok=false for non-string literals (null, integer, timestamp, etc.) so
// the caller can fall through to the per-op default — those literals don't
// have a meaningful "" comparison and the prior, conservative section-prune
// behaviour is preserved.
func predicateForAbsentColumn(op types.BinaryOp, s scalar.Scalar) (logs.Predicate, bool, error) {
	var lit string
	switch v := s.(type) {
	case *scalar.String:
		lit = string(v.Data())
	case *scalar.Binary:
		lit = string(v.Data())
	default:
		return nil, false, nil
	}

	var matches bool
	switch op {
	case types.BinaryOpEq:
		matches = lit == ""
	case types.BinaryOpNeq:
		matches = lit != ""
	case types.BinaryOpGt:
		matches = "" > lit // always false ("" is the smallest string)
	case types.BinaryOpGte:
		matches = "" >= lit // true only when lit == ""
	case types.BinaryOpLt:
		matches = "" < lit // true for any non-empty lit
	case types.BinaryOpLte:
		matches = true // "" <= anything
	case types.BinaryOpMatchSubstr:
		matches = strings.Contains("", lit) // true only when lit == ""
	case types.BinaryOpNotMatchSubstr:
		matches = !strings.Contains("", lit)
	case types.BinaryOpMatchRe:
		re, err := regexp.Compile(lit)
		if err != nil {
			return nil, false, err
		}
		matches = re.MatchString("")
	case types.BinaryOpNotMatchRe:
		re, err := regexp.Compile(lit)
		if err != nil {
			return nil, false, err
		}
		matches = !re.MatchString("")
	case types.BinaryOpEqCaseInsensitive:
		matches = matchutil.EqualUpper([]byte(""), []byte(lit))
	case types.BinaryOpNotEqCaseInsensitive:
		matches = !matchutil.EqualUpper([]byte(""), []byte(lit))
	case types.BinaryOpMatchSubstrCaseInsensitive:
		matches = matchutil.ContainsUpper([]byte(""), []byte(lit))
	case types.BinaryOpNotMatchSubstrCaseInsensitive:
		matches = !matchutil.ContainsUpper([]byte(""), []byte(lit))
	default:
		// Pattern ops and any future ops without an "" evaluation rule:
		// leave to the per-op default.
		return nil, false, nil
	}

	if matches {
		return logs.TruePredicate{}, true, nil
	}
	return logs.FalsePredicate{}, true, nil
}

// findLogsColumn finds a column by ref in the slice of columns. If ref is invalid,
// findLogsColumn returns an error. If the column does not exist, findLogsColumn
// returns nil.
func findLogsColumn(ref types.ColumnRef, columns []*logs.Column) (*logs.Column, error) {
	if ref.Type != types.ColumnTypeBuiltin && ref.Type != types.ColumnTypeMetadata && ref.Type != types.ColumnTypeAmbiguous {
		return nil, fmt.Errorf("invalid column ref %s, expected builtin or metadata", ref)
	}

	columnMatch := func(ref types.ColumnRef, column *logs.Column) bool {
		switch {
		case ref.Type == types.ColumnTypeBuiltin && ref.Column == types.ColumnNameBuiltinTimestamp:
			return column.Type == logs.ColumnTypeTimestamp
		case ref.Type == types.ColumnTypeBuiltin && ref.Column == types.ColumnNameBuiltinMessage:
			return column.Type == logs.ColumnTypeMessage
		case ref.Type == types.ColumnTypeMetadata || ref.Type == types.ColumnTypeAmbiguous:
			return column.Name == ref.Column
		}

		return false
	}

	for _, column := range columns {
		if columnMatch(ref, column) {
			return column, nil
		}
	}

	return nil, nil
}

// buildLogsScalar builds a dataobj-compatible [scalar.Scalar] from a
// [types.Literal].
func buildLogsScalar(expr *LiteralExpr) (scalar.Scalar, error) {
	// [logs.ReaderOptions.Validate] specifies that all scalars must be one of
	// the given types:
	//
	// * [scalar.Null] (of any types)
	// * [scalar.Int64]
	// * [scalar.Uint64]
	// * [scalar.Timestamp] (nanosecond precision)
	// * [scalar.Binary]
	//
	// All of our mappings below evaluate to one of the above types.

	switch lit := expr.Literal().(type) {
	case types.NullLiteral:
		return scalar.ScalarNull, nil
	case types.IntegerLiteral:
		return scalar.NewInt64Scalar(lit.Value()), nil
	case types.BytesLiteral:
		// [types.BytesLiteral] refers to byte sizes, not binary data.
		return scalar.NewInt64Scalar(int64(lit.Value())), nil
	case types.TimestampLiteral:
		ts := arrow.Timestamp(lit.Value())
		tsType := arrow.FixedWidthTypes.Timestamp_ns
		return scalar.NewTimestampScalar(ts, tsType), nil
	case types.StringLiteral:
		buf := memory.NewBufferBytes([]byte(lit.Value()))
		return scalar.NewBinaryScalar(buf, arrow.BinaryTypes.Binary), nil
	}

	return nil, fmt.Errorf("unsupported literal type %T", expr)
}

func buildLogsMatch(col *logs.Column, op types.BinaryOp, value scalar.Scalar) (logs.Predicate, error) {
	// All the match operations require the value to be a string or a binary.
	var find []byte

	switch value := value.(type) {
	case *scalar.Binary:
		find = value.Data()
	case *scalar.String:
		find = value.Data()
	default:
		return nil, fmt.Errorf("unsupported scalar type %T for op %s, expected binary or string", value, op)
	}

	switch op {
	case types.BinaryOpMatchSubstr:
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return bytes.Contains(getLogsBytes(value), find)
			},
		}, nil

	case types.BinaryOpNotMatchSubstr:
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return !bytes.Contains(getLogsBytes(value), find)
			},
		}, nil

	case types.BinaryOpMatchRe:
		re, err := regexp.Compile(string(find))
		if err != nil {
			return nil, err
		}
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return re.Match(getLogsBytes(value))
			},
		}, nil

	case types.BinaryOpNotMatchRe:
		re, err := regexp.Compile(string(find))
		if err != nil {
			return nil, err
		}
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return !re.Match(getLogsBytes(value))
			},
		}, nil
	}

	// NOTE(rfratto): [types.BinaryOpMatchPattern] and [types.BinaryOpNotMatchPattern]
	// are currently unsupported.
	return nil, fmt.Errorf("unrecognized match operation %s", op)
}

func getLogsBytes(value scalar.Scalar) []byte {
	if !value.IsValid() {
		return nil
	}

	switch value := value.(type) {
	case *scalar.Binary:
		return value.Data()
	case *scalar.String:
		return value.Data()
	}

	return nil
}

func buildLogsCaseInsensitiveMatch(col *logs.Column, op types.BinaryOp, value scalar.Scalar) (logs.Predicate, error) {
	// All case-insensitive match operations require the value to be a string or binary.
	var find []byte

	switch value := value.(type) {
	case *scalar.Binary:
		find = value.Data()
	case *scalar.String:
		find = value.Data()
	default:
		return nil, fmt.Errorf("unsupported scalar type %T for op %s, expected binary or string", value, op)
	}

	switch op {
	case types.BinaryOpEqCaseInsensitive:
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return matchutil.EqualUpper(getLogsBytes(value), find)
			},
		}, nil

	case types.BinaryOpMatchSubstrCaseInsensitive:
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return matchutil.ContainsUpper(getLogsBytes(value), find)
			},
		}, nil

	case types.BinaryOpNotMatchSubstrCaseInsensitive:
		return logs.FuncPredicate{
			Column: col,
			Keep: func(_ *logs.Column, value scalar.Scalar) bool {
				return !matchutil.ContainsUpper(getLogsBytes(value), find)
			},
		}, nil
	}

	return nil, fmt.Errorf("unrecognized case-insensitive match operation %s", op)
}

// logsPredicateIsUnsatisfiable reports whether p can never match a row.
func logsPredicateIsUnsatisfiable(p logs.Predicate) bool {
	switch p := p.(type) {
	case logs.FalsePredicate:
		return true
	case logs.TruePredicate:
		return false
	case logs.AndPredicate:
		return logsPredicateIsUnsatisfiable(p.Left) || logsPredicateIsUnsatisfiable(p.Right)
	case logs.OrPredicate:
		return logsPredicateIsUnsatisfiable(p.Left) && logsPredicateIsUnsatisfiable(p.Right)
	case logs.NotPredicate:
		return logsPredicateIsSatisfiableForAllRows(p.Inner)
	default:
		return false
	}
}

// logsPredicateIsSatisfiableForAllRows reports whether p matches every row.
func logsPredicateIsSatisfiableForAllRows(p logs.Predicate) bool {
	switch p := p.(type) {
	case logs.TruePredicate:
		return true
	case logs.FalsePredicate:
		return false
	case logs.AndPredicate:
		return logsPredicateIsSatisfiableForAllRows(p.Left) && logsPredicateIsSatisfiableForAllRows(p.Right)
	case logs.OrPredicate:
		return logsPredicateIsSatisfiableForAllRows(p.Left) || logsPredicateIsSatisfiableForAllRows(p.Right)
	case logs.NotPredicate:
		return logsPredicateIsUnsatisfiable(p.Inner)
	default:
		return false
	}
}

// LogsPredicatesAreUnsatisfiable reports whether the conjunction of predicates
// can never match a row. Multiple predicates passed to [logs.Reader] are ANDed.
func LogsPredicatesAreUnsatisfiable(predicates []logs.Predicate) bool {
	for _, p := range predicates {
		if logsPredicateIsUnsatisfiable(p) {
			return true
		}
	}
	return false
}
