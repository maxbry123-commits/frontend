package physical

import (
	"testing"

	"github.com/oklog/ulid/v2"
	"github.com/stretchr/testify/require"

	compactionv2pb "github.com/grafana/loki/v3/pkg/dataobj/compaction/v2/proto"
)

func TestLogMerge_CloneIsDeepCopy(t *testing.T) {
	orig := &LogMerge{
		NodeID:         ulid.Make(),
		Tenant:         "tenant-29",
		ToCWindowStart: 1715126400_000_000_000,
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: "objects/aa/bb", SectionIndex: 0, MinKey: []string{"a"}, MaxKey: []string{"f"}},
				},
			},
		},
		SortSchema: []string{"label:service_name"},
	}

	clone := orig.Clone().(*LogMerge)

	require.NotEqual(t, orig.ID(), clone.ID(), "Clone must produce a fresh ULID")

	clone.Runs[0].Sections[0].MinKey[0] = "MUTATED"
	clone.Runs[0].Sections[0].MaxKey[0] = "MUTATED"
	clone.SortSchema[0] = "MUTATED"

	require.Equal(t, []string{"a"}, orig.Runs[0].Sections[0].MinKey,
		"Clone must deep-copy nested SectionRef.MinKey")
	require.Equal(t, []string{"f"}, orig.Runs[0].Sections[0].MaxKey,
		"Clone must deep-copy nested SectionRef.MaxKey")
	require.Equal(t, "label:service_name", orig.SortSchema[0],
		"Clone must deep-copy SortSchema")
}

// TestLogMerge_Clone_TolerateNilElements verifies cloneRuns does not
// panic on nil *RunRef or nil *SectionRef entries.
func TestLogMerge_Clone_TolerateNilElements(t *testing.T) {
	orig := &LogMerge{
		NodeID: ulid.Make(),
		Runs: []*compactionv2pb.RunRef{
			nil,
			{Sections: []*compactionv2pb.SectionRef{nil}},
		},
	}
	require.NotPanics(t, func() { _ = orig.Clone() })
}

func TestLogMerge_Clone_AllowsNilRuns(t *testing.T) {
	orig := &LogMerge{NodeID: ulid.Make()}
	cloned := orig.Clone().(*LogMerge)
	require.Nil(t, cloned.Runs)
	require.Nil(t, cloned.SortSchema)
}
