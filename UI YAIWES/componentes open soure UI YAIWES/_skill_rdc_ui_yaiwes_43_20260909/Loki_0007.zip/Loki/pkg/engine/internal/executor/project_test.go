package executor

import (
	"testing"
	"time"

	"github.com/apache/arrow-go/v18/arrow"
	"github.com/stretchr/testify/require"

	"github.com/grafana/loki/v3/pkg/engine/internal/assertions"
	"github.com/grafana/loki/v3/pkg/engine/internal/planner/physical"
	"github.com/grafana/loki/v3/pkg/engine/internal/semconv"
	"github.com/grafana/loki/v3/pkg/engine/internal/types"
	"github.com/grafana/loki/v3/pkg/logql/log"
	"github.com/grafana/loki/v3/pkg/util/arrowtest"
)

func init() {
	assertions.Enabled = true
}

func TestNewProjectPipeline(t *testing.T) {
	fields := []arrow.Field{
		semconv.FieldFromFQN("utf8.builtin.name", false),
		semconv.FieldFromFQN("int64.builtin.age", false),
		semconv.FieldFromFQN("utf8.builtin.city", false),
	}

	t.Run("project single column", func(t *testing.T) {
		// Create input data
		inputCSV := "Alice,30,New York\nBob,25,Boston\nCharlie,35,Seattle"
		inputRecord, err := CSVToArrow(fields, inputCSV)
		require.NoError(t, err)

		// Create input pipeline
		inputPipeline := NewBufferedPipeline(inputRecord)

		// Create projection columns (just the "name" column)
		columns := []physical.Expression{
			&physical.ColumnExpr{
				Ref: createColumnRef("name"),
			},
		}

		// Create project pipeline
		e := newExpressionEvaluator()
		projectPipeline, err := NewProjectPipeline(inputPipeline, &physical.Projection{Expressions: columns}, e)
		require.NoError(t, err)

		// Create expected output
		expectedCSV := "Alice\nBob\nCharlie"
		expectedFields := []arrow.Field{
			semconv.FieldFromFQN("utf8.builtin.name", false),
		}
		expectedRecord, err := CSVToArrow(expectedFields, expectedCSV)
		require.NoError(t, err)

		expectedPipeline := NewBufferedPipeline(expectedRecord)

		// Assert that the pipelines produce equal results
		AssertPipelinesEqual(t, projectPipeline, expectedPipeline)
	})

	t.Run("project multiple columns", func(t *testing.T) {
		// Create input data
		inputCSV := "Alice,30,New York\nBob,25,Boston\nCharlie,35,Seattle"
		inputRecord, err := CSVToArrow(fields, inputCSV)
		require.NoError(t, err)

		// Create input pipeline
		inputPipeline := NewBufferedPipeline(inputRecord)

		// Create projection columns (both "name" and "city" columns)
		columns := []physical.Expression{
			&physical.ColumnExpr{
				Ref: createColumnRef("name"),
			},
			&physical.ColumnExpr{
				Ref: createColumnRef("city"),
			},
		}

		// Create project pipeline
		e := newExpressionEvaluator()
		projectPipeline, err := NewProjectPipeline(inputPipeline, &physical.Projection{Expressions: columns}, e)
		require.NoError(t, err)

		// Create expected output
		expectedCSV := "Alice,New York\nBob,Boston\nCharlie,Seattle"
		expectedFields := []arrow.Field{
			semconv.FieldFromFQN("utf8.builtin.name", false),
			semconv.FieldFromFQN("utf8.builtin.city", false),
		}
		expectedRecord, err := CSVToArrow(expectedFields, expectedCSV)
		require.NoError(t, err)

		expectedPipeline := NewBufferedPipeline(expectedRecord)

		// Assert that the pipelines produce equal results
		AssertPipelinesEqual(t, projectPipeline, expectedPipeline)
	})

	t.Run("project with multiple input batches", func(t *testing.T) {
		// Create input data split across multiple records
		inputCSV1 := "Alice,30,New York\nBob,25,Boston"
		inputCSV2 := "Charlie,35,Seattle\nDave,40,Portland"

		inputRecord1, err := CSVToArrow(fields, inputCSV1)
		require.NoError(t, err)

		inputRecord2, err := CSVToArrow(fields, inputCSV2)
		require.NoError(t, err)

		// Create input pipeline with multiple batches
		inputPipeline := NewBufferedPipeline(inputRecord1, inputRecord2)

		// Create projection columns
		columns := []physical.Expression{
			&physical.ColumnExpr{
				Ref: createColumnRef("name"),
			},
			&physical.ColumnExpr{
				Ref: createColumnRef("age"),
			},
		}

		// Create project pipeline
		e := newExpressionEvaluator()
		projectPipeline, err := NewProjectPipeline(inputPipeline, &physical.Projection{Expressions: columns}, e)
		require.NoError(t, err)

		// Create expected output also split across multiple records
		expectedFields := []arrow.Field{
			semconv.FieldFromFQN("utf8.builtin.name", false),
			semconv.FieldFromFQN("int64.builtin.age", false),
		}

		expected := `
Alice,30
Bob,25
Charlie,35
Dave,40
		`

		expectedRecord, err := CSVToArrow(expectedFields, expected)
		require.NoError(t, err)

		expectedPipeline := NewBufferedPipeline(expectedRecord)

		// Assert that the pipelines produce equal results
		AssertPipelinesEqual(t, projectPipeline, expectedPipeline)
	})

	t.Run("drop", func(t *testing.T) {
		schema := arrow.NewSchema(
			[]arrow.Field{
				semconv.FieldFromFQN("utf8.builtin.service", false),
				semconv.FieldFromFQN("int64.metadata.count", false),
				semconv.FieldFromFQN("int64.parsed.count", false),
			}, nil)

		rows := arrowtest.Rows{
			{"utf8.builtin.service": "loki", "int64.metadata.count": 1, "int64.parsed.count": 1},
			{"utf8.builtin.service": "loki", "int64.metadata.count": 2, "int64.parsed.count": 4},
			{"utf8.builtin.service": "loki", "int64.metadata.count": 3, "int64.parsed.count": 9},
		}

		for _, tc := range []struct {
			name           string
			columns        []physical.Expression
			expectedFields []arrow.Field
		}{
			{
				name: "single column",
				columns: []physical.Expression{
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "service", Type: types.ColumnTypeAmbiguous}},
				},
				expectedFields: []arrow.Field{
					semconv.FieldFromFQN("int64.metadata.count", false),
					semconv.FieldFromFQN("int64.parsed.count", false),
				},
			},
			{
				name: "single ambiguous column",
				columns: []physical.Expression{
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "count", Type: types.ColumnTypeAmbiguous}},
				},
				expectedFields: []arrow.Field{
					semconv.FieldFromFQN("utf8.builtin.service", false),
				},
			},
			{
				name: "single non-ambiguous column",
				columns: []physical.Expression{
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "count", Type: types.ColumnTypeMetadata}},
				},
				expectedFields: []arrow.Field{
					semconv.FieldFromFQN("utf8.builtin.service", false),
					semconv.FieldFromFQN("int64.parsed.count", false),
				},
			},
			{
				name: "multiple columns",
				columns: []physical.Expression{
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "service", Type: types.ColumnTypeBuiltin}},
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "count", Type: types.ColumnTypeParsed}},
				},
				expectedFields: []arrow.Field{
					semconv.FieldFromFQN("int64.metadata.count", false),
				},
			},
			{
				name: "non existent columns",
				columns: []physical.Expression{
					&physical.ColumnExpr{Ref: types.ColumnRef{Column: "__error__", Type: types.ColumnTypeAmbiguous}},
				},
				expectedFields: []arrow.Field{
					semconv.FieldFromFQN("utf8.builtin.service", false),
					semconv.FieldFromFQN("int64.metadata.count", false),
					semconv.FieldFromFQN("int64.parsed.count", false),
				},
			},
		} {
			t.Run(tc.name, func(t *testing.T) {
				// Create input data with message column containing logfmt
				input := NewArrowtestPipeline(schema, rows)

				// Create project pipeline
				proj := &physical.Projection{
					Expressions: tc.columns,
					All:         true,
					Drop:        true,
				}
				pipeline, err := NewProjectPipeline(input, proj, newExpressionEvaluator())
				require.NoError(t, err)

				ctx := t.Context()
				record, err := pipeline.Read(ctx)
				require.NoError(t, err)

				// Verify the output has the expected number of fields
				outputSchema := record.Schema()
				require.Equal(t, len(tc.expectedFields), outputSchema.NumFields())
				require.Equal(t, tc.expectedFields, outputSchema.Fields())
			})
		}
	})
}

func TestNewProjectPipeline_ProjectionFunction_ExpandWithCast(t *testing.T) {
	for _, tt := range []struct {
		name           string
		schema         *arrow.Schema
		input          arrowtest.Rows
		columnExprs    []physical.Expression
		expectedFields int
		expectedOutput arrowtest.Rows
	}{
		{
			name: "cast numeric value from label",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.metadata.status_code", true),
				semconv.FieldFromFQN("utf8.label.response_time", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "request processed", "utf8.metadata.status_code": "200", "utf8.label.response_time": "150"},
				{"utf8.builtin.message": "slow request", "utf8.metadata.status_code": "200", "utf8.label.response_time": "500"},
				{"utf8.builtin.message": "error occurred", "utf8.metadata.status_code": "500", "utf8.label.response_time": "100"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastFloat,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("response_time")},
				},
			},
			expectedFields: 4, // 4 columns: message, status_code, response_time, value
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "request processed", "utf8.metadata.status_code": "200", "utf8.label.response_time": "150", "float64.generated.value": 150.0},
				{"utf8.builtin.message": "slow request", "utf8.metadata.status_code": "200", "utf8.label.response_time": "500", "float64.generated.value": 500.0},
				{"utf8.builtin.message": "error occurred", "utf8.metadata.status_code": "500", "utf8.label.response_time": "100", "float64.generated.value": 100.0},
			},
		},
		{
			name: "cast bytes value from label",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.parsed.data_size", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "data uploaded", "utf8.parsed.data_size": "1KiB"},
				{"utf8.builtin.message": "large upload", "utf8.parsed.data_size": "5MiB"},
				{"utf8.builtin.message": "small file", "utf8.parsed.data_size": "512B"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastBytes,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("data_size")},
				},
			},
			expectedFields: 3, // 4 columns: message, data_size, value
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "data uploaded", "utf8.parsed.data_size": "1KiB", "float64.generated.value": 1024.0},
				{"utf8.builtin.message": "large upload", "utf8.parsed.data_size": "5MiB", "float64.generated.value": 5242880.0},
				{"utf8.builtin.message": "small file", "utf8.parsed.data_size": "512B", "float64.generated.value": 512.0},
			},
		},
		{
			name: "cast duration value from parsed field",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.metadata.status_code", true),
				semconv.FieldFromFQN("utf8.parsed.request_duration", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "request completed", "utf8.metadata.status_code": "200", "utf8.parsed.request_duration": "1.5s"},
				{"utf8.builtin.message": "fast request", "utf8.metadata.status_code": "200", "utf8.parsed.request_duration": "250ms"},
				{"utf8.builtin.message": "slow request", "utf8.metadata.status_code": "500", "utf8.parsed.request_duration": "30s"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastDuration,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("request_duration")},
				},
			},
			expectedFields: 4, // 4 columns: message, status_code, request_duration, value
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "request completed", "utf8.metadata.status_code": "200", "utf8.parsed.request_duration": "1.5s", "float64.generated.value": 1.5},
				{"utf8.builtin.message": "fast request", "utf8.metadata.status_code": "200", "utf8.parsed.request_duration": "250ms", "float64.generated.value": 0.25},
				{"utf8.builtin.message": "slow request", "utf8.metadata.status_code": "500", "utf8.parsed.request_duration": "30s", "float64.generated.value": 30.0},
			},
		},
		{
			name: "cast duration_seconds value from label",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.metadata.status_code", true),
				semconv.FieldFromFQN("utf8.parsed.timeout", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "timeout set", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "2m"},
				{"utf8.builtin.message": "short timeout", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "10s"},
				{"utf8.builtin.message": "long timeout", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "1h"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastDuration,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("timeout")},
				},
			},
			expectedFields: 4, // 4 columns: message, status_code, timeout, value
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "timeout set", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "2m", "float64.generated.value": 120.0},
				{"utf8.builtin.message": "short timeout", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "10s", "float64.generated.value": 10.0},
				{"utf8.builtin.message": "long timeout", "utf8.metadata.status_code": "200", "utf8.parsed.timeout": "1h", "float64.generated.value": 3600.0},
			},
		},
		{
			name: "mixed valid and invalid values with null handling",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.parsed.mixed_values", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "valid numeric", "utf8.parsed.mixed_values": "42.5"},
				{"utf8.builtin.message": "invalid numeric", "utf8.parsed.mixed_values": "not_a_number"},
				{"utf8.builtin.message": "valid bytes", "utf8.parsed.mixed_values": "1KB"},
				{"utf8.builtin.message": "invalid bytes", "utf8.parsed.mixed_values": "invalid_bytes"},
				{"utf8.builtin.message": "empty string", "utf8.parsed.mixed_values": ""},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastFloat,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("mixed_values")},
				},
			},
			expectedFields: 5,
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "valid numeric", "utf8.parsed.mixed_values": "42.5",
					"float64.generated.value":          42.5,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "invalid numeric", "utf8.parsed.mixed_values": "not_a_number",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "not_a_number": invalid syntax`}, //invalid
				{"utf8.builtin.message": "valid bytes", "utf8.parsed.mixed_values": "1KB",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "1KB": invalid syntax`}, // 1KB is not a valid float but doesn't error
				{"utf8.builtin.message": "invalid bytes", "utf8.parsed.mixed_values": "invalid_bytes",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "invalid_bytes": invalid syntax`}, // invalid but doesn't error
				{"utf8.builtin.message": "empty string", "utf8.parsed.mixed_values": "",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "": invalid syntax`}, // empty string gets error from previous parsing
			},
		},
		{
			name: "existing error columns - last error wins",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.parsed.mixed_values", true),
				semconv.FieldFromIdent(semconv.ColumnIdentError, false),
				semconv.FieldFromIdent(semconv.ColumnIdentErrorDetails, false),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "valid numeric", "utf8.parsed.mixed_values": "42.5", "utf8.generated.__error__": "", "utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "invalid numeric", "utf8.parsed.mixed_values": "not_a_number", "utf8.generated.__error__": "My error", "utf8.generated.__error_details__": "Some error"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastFloat,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("mixed_values")},
				},
			},
			expectedFields: 5,
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "valid numeric", "utf8.parsed.mixed_values": "42.5",
					"float64.generated.value":          42.5,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "invalid numeric", "utf8.parsed.mixed_values": "not_a_number",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "not_a_number": invalid syntax`},
			},
		},
		{
			name: "edge cases for numeric parsing",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.parsed.edge_values", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "scientific notation", "utf8.parsed.edge_values": "1.23e+02"},
				{"utf8.builtin.message": "negative number", "utf8.parsed.edge_values": "-456.78"},
				{"utf8.builtin.message": "only whitespace", "utf8.parsed.edge_values": "   "},
				{"utf8.builtin.message": "mixed text and numbers", "utf8.parsed.edge_values": "123abc"},
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastFloat,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("edge_values")},
				},
			},
			expectedFields: 5,
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "scientific notation",
					"utf8.parsed.edge_values":          "1.23e+02",
					"float64.generated.value":          123.0,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""}, // empty string gets error from previous parsing
				{"utf8.builtin.message": "negative number",
					"utf8.parsed.edge_values":          "-456.78",
					"float64.generated.value":          -456.78,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""}, // empty string gets error from previous parsing
				{"utf8.builtin.message": "only whitespace", "utf8.parsed.edge_values": "   ",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "   ": invalid syntax`}, // empty string gets error from previous parsing
				{"utf8.builtin.message": "mixed text and numbers",
					"utf8.parsed.edge_values":          "123abc",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `strconv.ParseFloat: parsing "123abc": invalid syntax`}, // empty string gets error from previous parsing
			},
		},
		{
			name: "negative durations and edge cases",
			schema: arrow.NewSchema([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromFQN("utf8.parsed.duration_values", true),
			}, nil),
			input: arrowtest.Rows{
				{"utf8.builtin.message": "negative duration", "utf8.parsed.duration_values": "-5s"},
				{"utf8.builtin.message": "zero duration", "utf8.parsed.duration_values": "0s"},
				{"utf8.builtin.message": "fractional duration", "utf8.parsed.duration_values": "1.5s"},
				{"utf8.builtin.message": "invalid duration", "utf8.parsed.duration_values": "5 seconds"}, // space makes it invalid
			},
			columnExprs: []physical.Expression{
				&physical.UnaryExpr{
					Op:   types.UnaryOpCastDuration,
					Left: &physical.ColumnExpr{Ref: createAmbiguousColumnRef("duration_values")},
				},
			},
			expectedFields: 5,
			expectedOutput: arrowtest.Rows{
				{"utf8.builtin.message": "negative duration",
					"utf8.parsed.duration_values":      "-5s",
					"float64.generated.value":          -5.0,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "zero duration",
					"utf8.parsed.duration_values":      "0s",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "fractional duration",
					"utf8.parsed.duration_values":      "1.5s",
					"float64.generated.value":          1.5,
					"utf8.generated.__error__":         "",
					"utf8.generated.__error_details__": ""},
				{"utf8.builtin.message": "invalid duration",
					"utf8.parsed.duration_values":      "5 seconds",
					"float64.generated.value":          0.0,
					"utf8.generated.__error__":         types.SampleExtractionErrorType,
					"utf8.generated.__error_details__": `time: unknown unit " seconds" in duration "5 seconds"`}, // empty string gets error from previous parsing
			},
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			// Create input data
			input := NewArrowtestPipeline(
				tt.schema,
				tt.input,
			)

			e := newExpressionEvaluator()
			pipeline, err := NewProjectPipeline(
				input,
				&physical.Projection{
					Expressions: tt.columnExprs,
					Expand:      true,
					All:         true,
				},
				e)
			require.NoError(t, err)
			defer pipeline.Close()

			// Read first record
			ctx := t.Context()
			record, err := pipeline.Read(ctx)
			require.NoError(t, err)

			// Verify the output has the expected number of fields
			outputSchema := record.Schema()
			require.Equal(t, tt.expectedFields, outputSchema.NumFields())

			// Convert record to rows for comparison
			actual, err := arrowtest.RecordRows(record)
			require.NoError(t, err)
			require.Equal(t, tt.expectedOutput, actual)
		})
	}
}

func TestNewProjectPipeline_ProjectionFunction_ExpandWithBinOn(t *testing.T) {
	t.Run("calculates a simple expression with 1 input", func(t *testing.T) {
		colTs := "timestamp_ns.builtin.timestamp"
		colVal := "float64.generated.value"
		colEnv := "utf8.label.env"
		colSvc := "utf8.label.service"

		schema := arrow.NewSchema([]arrow.Field{
			semconv.FieldFromFQN(colTs, false),
			semconv.FieldFromFQN(colVal, false),
			semconv.FieldFromFQN(colEnv, false),
			semconv.FieldFromFQN(colSvc, false),
		}, nil)

		rowsPipeline1 := []arrowtest.Rows{
			{
				{colTs: time.Unix(20, 0).UTC(), colVal: float64(230), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(15, 0).UTC(), colVal: float64(120), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(10, 0).UTC(), colVal: float64(260), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(12, 0).UTC(), colVal: float64(250), colEnv: "dev", colSvc: "distributor"},
			},
		}
		input1 := NewArrowtestPipeline(schema, rowsPipeline1...)

		// value / 10
		projection := &physical.Projection{
			Expressions: []physical.Expression{
				&physical.BinaryExpr{
					Left: &physical.ColumnExpr{
						Ref: types.ColumnRef{
							Column: types.ColumnNameGeneratedValue,
							Type:   types.ColumnTypeGenerated,
						},
					},
					Right: physical.NewLiteral(float64(10)),
					Op:    types.BinaryOpDiv,
				},
			},
			All:    true,
			Expand: true,
		}

		pipeline, err := NewProjectPipeline(input1, projection, newExpressionEvaluator())
		require.NoError(t, err)
		defer pipeline.Close()

		// Read the pipeline output
		record, err := pipeline.Read(t.Context())
		require.NoError(t, err)

		expect := arrowtest.Rows{
			{colTs: time.Unix(20, 0).UTC(), colVal: float64(23), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(15, 0).UTC(), colVal: float64(12), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(10, 0).UTC(), colVal: float64(26), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(12, 0).UTC(), colVal: float64(25), colEnv: "dev", colSvc: "distributor"},
		}

		rows, err := arrowtest.RecordRows(record)
		require.NoError(t, err, "should be able to convert record back to rows")
		require.Equal(t, len(expect), len(rows), "number of rows should match")
		require.ElementsMatch(t, expect, rows)
	})

	t.Run("calculates a complex expression with 1 input", func(t *testing.T) {
		colTs := "timestamp_ns.builtin.timestamp"
		colVal := "float64.generated.value"
		colEnv := "utf8.label.env"
		colSvc := "utf8.label.service"

		schema := arrow.NewSchema([]arrow.Field{
			semconv.FieldFromFQN(colTs, false),
			semconv.FieldFromFQN(colVal, false),
			semconv.FieldFromFQN(colEnv, false),
			semconv.FieldFromFQN(colSvc, false),
		}, nil)

		rowsPipeline1 := []arrowtest.Rows{
			{
				{colTs: time.Unix(20, 0).UTC(), colVal: float64(230), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(15, 0).UTC(), colVal: float64(120), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(10, 0).UTC(), colVal: float64(260), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(12, 0).UTC(), colVal: float64(250), colEnv: "dev", colSvc: "distributor"},
			},
		}
		input1 := NewArrowtestPipeline(schema, rowsPipeline1...)

		// value * 10 + 100 / 10
		projection := &physical.Projection{
			Expressions: []physical.Expression{
				&physical.BinaryExpr{
					Left: &physical.BinaryExpr{
						Left: &physical.ColumnExpr{
							Ref: types.ColumnRef{
								Column: types.ColumnNameGeneratedValue,
								Type:   types.ColumnTypeGenerated,
							},
						},
						Right: physical.NewLiteral(float64(10)),
						Op:    types.BinaryOpMul,
					},
					Right: &physical.BinaryExpr{
						Left:  physical.NewLiteral(float64(100)),
						Right: physical.NewLiteral(float64(10)),
						Op:    types.BinaryOpDiv,
					},
					Op: types.BinaryOpAdd,
				},
			},
			All:    true,
			Expand: true,
		}

		pipeline, err := NewProjectPipeline(input1, projection, newExpressionEvaluator())
		require.NoError(t, err)
		defer pipeline.Close()

		// Read the pipeline output
		record, err := pipeline.Read(t.Context())
		require.NoError(t, err)

		expect := arrowtest.Rows{
			{colTs: time.Unix(20, 0).UTC(), colVal: float64(2310), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(15, 0).UTC(), colVal: float64(1210), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(10, 0).UTC(), colVal: float64(2610), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(12, 0).UTC(), colVal: float64(2510), colEnv: "dev", colSvc: "distributor"},
		}

		rows, err := arrowtest.RecordRows(record)
		require.NoError(t, err, "should be able to convert record back to rows")
		require.Equal(t, len(expect), len(rows), "number of rows should match")
		require.ElementsMatch(t, expect, rows)
	})

	t.Run("calculates a complex ex", func(t *testing.T) {
		colTs := "timestamp_ns.builtin.timestamp"
		colVal := "float64.generated.value"
		colValLeft := "float64.generated.value_left"
		colValRight := "float64.generated.value_right"
		colEnv := "utf8.label.env"
		colSvc := "utf8.label.service"

		schema := arrow.NewSchema([]arrow.Field{
			semconv.FieldFromFQN(colTs, false),
			semconv.FieldFromFQN(colValLeft, false),
			semconv.FieldFromFQN(colValRight, false),
			semconv.FieldFromFQN(colEnv, false),
			semconv.FieldFromFQN(colSvc, false),
		}, nil)

		rowsPipeline1 := []arrowtest.Rows{
			{
				{colTs: time.Unix(20, 0).UTC(), colValLeft: float64(230), colValRight: float64(2), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(15, 0).UTC(), colValLeft: float64(120), colValRight: float64(10), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(10, 0).UTC(), colValLeft: float64(260), colValRight: float64(4), colEnv: "prod", colSvc: "distributor"},
				{colTs: time.Unix(12, 0).UTC(), colValLeft: float64(250), colValRight: float64(20), colEnv: "dev", colSvc: "distributor"},
			},
		}
		input1 := NewArrowtestPipeline(schema, rowsPipeline1...)

		// value_left / value_right
		projection := &physical.Projection{
			Expressions: []physical.Expression{
				&physical.BinaryExpr{
					Left: &physical.ColumnExpr{
						Ref: types.ColumnRef{
							Column: "value_left",
							Type:   types.ColumnTypeGenerated,
						},
					},
					Right: &physical.ColumnExpr{
						Ref: types.ColumnRef{
							Column: "value_right",
							Type:   types.ColumnTypeGenerated,
						},
					},
					Op: types.BinaryOpDiv,
				},
			},
			All:    true,
			Expand: true,
		}

		pipeline, err := NewProjectPipeline(input1, projection, newExpressionEvaluator())
		require.NoError(t, err)
		defer pipeline.Close()

		// Read the pipeline output
		record, err := pipeline.Read(t.Context())
		require.NoError(t, err)

		expect := arrowtest.Rows{
			{colTs: time.Unix(20, 0).UTC(), colValLeft: float64(230), colValRight: float64(2), colVal: float64(115), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(15, 0).UTC(), colValLeft: float64(120), colValRight: float64(10), colVal: float64(12), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(10, 0).UTC(), colValLeft: float64(260), colValRight: float64(4), colVal: float64(65), colEnv: "prod", colSvc: "distributor"},
			{colTs: time.Unix(12, 0).UTC(), colValLeft: float64(250), colValRight: float64(20), colVal: float64(12.5), colEnv: "dev", colSvc: "distributor"},
		}

		rows, err := arrowtest.RecordRows(record)
		require.NoError(t, err, "should be able to convert record back to rows")
		require.Equal(t, len(expect), len(rows), "number of rows should match")
		require.ElementsMatch(t, expect, rows)
	})
}

// Helper to create a column reference
func createColumnRef(name string) types.ColumnRef {
	return types.ColumnRef{
		Column: name,
		Type:   types.ColumnTypeBuiltin,
	}
}

// Helper to create a column reference
func createAmbiguousColumnRef(name string) types.ColumnRef {
	return types.ColumnRef{
		Column: name,
		Type:   types.ColumnTypeAmbiguous,
	}
}

func TestNewProjectPipeline_DuplicateColumnPanic(t *testing.T) {
	t.Run("duplicate columns from mixed json and logfmt parsers", func(t *testing.T) {
		schema := arrow.NewSchema([]arrow.Field{
			semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
			semconv.FieldFromFQN("utf8.parsed.status", true),
		}, nil)

		// Simulate output from JSON parser that extracted "status" field
		rows := arrowtest.Rows{
			// Row 1: JSON line that was parsed and extracted "status"
			{
				"utf8.builtin.message": `{"level":"info","status":200}`,
				"utf8.parsed.status":   "200",
			},
			// Row 2: Logfmt line that will also parse and extract "status"
			{
				"utf8.builtin.message":                `level=info status=404 method=GET`,
				"utf8.parsed.status":                  nil,
				semconv.ColumnIdentError.FQN():        "error message",
				semconv.ColumnIdentErrorDetails.FQN(): "error details",
			},
			// Row 3: Another JSON line with status
			{
				"utf8.builtin.message": `{"level":"error","status":500}`,
				"utf8.parsed.status":   "500",
			},
			// Row 4: Logfmt line that will not parse and extract "status"
			{
				"utf8.builtin.message":                `level=info method=GET`,
				"utf8.parsed.status":                  nil,
				semconv.ColumnIdentError.FQN():        "error message",
				semconv.ColumnIdentErrorDetails.FQN(): "error details",
			},
		}

		input := NewArrowtestPipeline(schema, rows)

		// Create an expression that parses logfmt from message, which will also extract "status"
		// This simulates a query like: | json | logfmt
		// where both parsers extract the same field name
		evaluator := newExpressionEvaluator()

		parseExpr := &physical.VariadicExpr{
			Op: types.VariadicOpParseLogfmt,
			Expressions: []physical.Expression{
				&physical.ColumnExpr{
					Ref: types.ColumnRef{
						Column: "message",
						Type:   types.ColumnTypeBuiltin,
					},
				},
				physical.NewLiteral([]string{}),
				physical.NewLiteral(false),
				physical.NewLiteral(false),
			},
		}

		proj := &physical.Projection{
			Expressions: []physical.Expression{parseExpr},
			All:         true,
			Expand:      true,
		}

		pipeline, err := NewProjectPipeline(input, proj, evaluator)
		require.NoError(t, err)

		ctx := t.Context()
		record, err := pipeline.Read(ctx)
		require.NoError(t, err)

		expectedRows := arrowtest.Rows{
			// Row 1: JSON parsed status="200", logfmt fails → keep "200".
			// Non-strict logfmt does not add [__error__] / [__error_details__].
			{
				"utf8.builtin.message": `{"level":"info","status":200}`,
				"utf8.parsed.level":    nil, // logfmt didn't parse, so null
				"utf8.parsed.method":   nil,
				"utf8.parsed.status":   "200", // Kept from original JSON parse
			},
			// Row 2: No previous status (null), logfmt parses status="404" → use "404"
			{
				"utf8.builtin.message": `level=info status=404 method=GET`,
				"utf8.parsed.level":    "info",
				"utf8.parsed.method":   "GET",
				"utf8.parsed.status":   "404",
			},
			// Row 3: JSON parsed status="500", logfmt fails → keep "500"
			{
				"utf8.builtin.message": `{"level":"error","status":500}`,
				"utf8.parsed.level":    nil,
				"utf8.parsed.method":   nil,
				"utf8.parsed.status":   "500",
			},
			// Row 4: No previous status (null), logfmt also does't parse status
			{
				"utf8.builtin.message": `level=info method=GET`,
				"utf8.parsed.level":    "info",
				"utf8.parsed.method":   "GET",
				"utf8.parsed.status":   nil,
			},
		}

		actualRows, err := arrowtest.RecordRows(record)
		require.NoError(t, err)
		require.Equal(t, expectedRows, actualRows)
	})

	t.Run("duplicate columns from same parser multiple times", func(t *testing.T) {
		// Another scenario: a field already exists and gets parsed again
		schema := arrow.NewSchema([]arrow.Field{
			semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
			semconv.FieldFromFQN("utf8.parsed.user", true),
			semconv.FieldFromFQN("utf8.parsed.action", true),
		}, nil)

		rows := arrowtest.Rows{
			{
				"utf8.builtin.message": `{"user":"alice","action":"login","timestamp":"2024-01-01"}`,
				"utf8.parsed.user":     "bob",
				"utf8.parsed.action":   "logout",
			},
			{
				"utf8.builtin.message": `{"action":"login","timestamp":"2024-01-01"}`,
				"utf8.parsed.user":     "bob",
				"utf8.parsed.action":   "logout",
			},
		}

		input := NewArrowtestPipeline(schema, rows)

		evaluator := newExpressionEvaluator()

		// Parse JSON from message which will extract "user" and "action" again
		parseExpr := &physical.VariadicExpr{
			Op: types.VariadicOpParseJSON,
			Expressions: []physical.Expression{
				&physical.ColumnExpr{
					Ref: types.ColumnRef{
						Column: "message",
						Type:   types.ColumnTypeBuiltin,
					},
				},
				physical.NewLiteral([]string{}),
				physical.NewLiteral(false),
				physical.NewLiteral(false),
			},
		}

		proj := &physical.Projection{
			Expressions: []physical.Expression{parseExpr},
			All:         true,
			Expand:      true,
		}

		pipeline, err := NewProjectPipeline(input, proj, evaluator)
		require.NoError(t, err)

		ctx := t.Context()
		record, err := pipeline.Read(ctx)
		require.NoError(t, err)

		expectedRows := arrowtest.Rows{
			{
				"utf8.builtin.message":  `{"user":"alice","action":"login","timestamp":"2024-01-01"}`,
				"utf8.parsed.action":    "login",
				"utf8.parsed.timestamp": "2024-01-01",
				"utf8.parsed.user":      "alice",
			},
			{
				"utf8.builtin.message":  `{"action":"login","timestamp":"2024-01-01"}`,
				"utf8.parsed.action":    "login",
				"utf8.parsed.timestamp": "2024-01-01",
				"utf8.parsed.user":      "bob", //from first parse
			},
		}

		actualRows, err := arrowtest.RecordRows(record)
		require.NoError(t, err)
		require.Equal(t, expectedRows, actualRows)
	})
}

func TestNewProjectPipeline_LabelFmtRenameDropsSourceColumn(t *testing.T) {
	ts := time.Unix(1700000000, 0).UTC()

	msg := "rename bar to foo"
	tests := []struct {
		name string
		// dataFields/dataValues are the input columns in addition to the
		// constant message and timestamp columns.
		dataFields []arrow.Field
		dataValues arrowtest.Row
		labelFmts  []log.LabelFmt
		expected   arrowtest.Rows
	}{
		{
			name:       "stream label source is dropped",
			dataFields: []arrow.Field{semconv.FieldFromFQN("utf8.label.bar", false)},
			dataValues: arrowtest.Row{"utf8.label.bar": "dev"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "bar", Rename: true}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "dev",
			}},
		},
		{
			name:       "parsed source is dropped",
			dataFields: []arrow.Field{semconv.FieldFromFQN("utf8.parsed.bar", false)},
			dataValues: arrowtest.Row{"utf8.parsed.bar": "dev"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "bar", Rename: true}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "dev",
			}},
		},
		{
			name:       "metadata source is dropped",
			dataFields: []arrow.Field{semconv.FieldFromFQN("utf8.metadata.bar", false)},
			dataValues: arrowtest.Row{"utf8.metadata.bar": "dev"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "bar", Rename: true}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "dev",
			}},
		},
		{
			// Generated columns are not label-like, so the source column survives
			// the rename even though its short name matches the rename source.
			name:       "generated source is preserved",
			dataFields: []arrow.Field{semconv.FieldFromFQN("utf8.generated.bar", false)},
			dataValues: arrowtest.Row{"utf8.generated.bar": "dev"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "bar", Rename: true}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.generated.bar":             "dev",
				"utf8.parsed.foo":                "dev",
			}},
		},
		{
			// Collision: the rename destination `foo` already exists as a label.
			// Both the source `bar` and the existing `foo` label are dropped,
			// and the rename's value lands at `parsed.foo` (mirrors v1, where
			// LabelsFormatter calls lbs.Set(ParsedLabel, "foo", "dev") which
			// deletes any stream-label `foo` before writing the parsed value).
			name: "rename overwrites existing destination label",
			dataFields: []arrow.Field{
				semconv.FieldFromFQN("utf8.label.foo", false),
				semconv.FieldFromFQN("utf8.label.bar", false),
			},
			dataValues: arrowtest.Row{"utf8.label.foo": "old", "utf8.label.bar": "dev"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "bar", Rename: true}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "dev",
			}},
		},
		{
			// Template renders to empty (literal ""); the pre-existing destination
			// label `foo` is removed and the new `parsed.foo` carries the rendered
			// empty value. v1 semantics: a template always writes its result,
			// including an empty result.
			name: "template literal empty overwrites existing destination",
			dataFields: []arrow.Field{
				semconv.FieldFromFQN("utf8.label.foo", false),
			},
			dataValues: arrowtest.Row{"utf8.label.foo": "old"},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "", Rename: false}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "",
			}},
		},
		{
			// Template references a label whose value is empty; the rendered
			// result is "" and lands at `parsed.foo`, while the pre-existing
			// `label.foo` is dropped.
			name: "template referencing empty-valued label overwrites existing destination",
			dataFields: []arrow.Field{
				semconv.FieldFromFQN("utf8.label.foo", false),
				semconv.FieldFromFQN("utf8.label.bar", false),
			},
			dataValues: arrowtest.Row{"utf8.label.foo": "old", "utf8.label.bar": ""},
			labelFmts:  []log.LabelFmt{{Name: "foo", Value: "{{.bar}}", Rename: false}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.label.bar":                 "",
				"utf8.parsed.foo":                "",
			}},
		},
		{
			// `label_format foo="bar"` must NOT touch `foo_extracted` — it's
			// a different short name.
			name: "set target preserves the matching _extracted column",
			dataFields: []arrow.Field{
				semconv.FieldFromFQN("utf8.label.foo", false),
				semconv.FieldFromFQN("utf8.parsed.foo_extracted", false),
			},
			dataValues: arrowtest.Row{
				"utf8.label.foo":            "from-stream",
				"utf8.parsed.foo_extracted": "from-json",
			},
			labelFmts: []log.LabelFmt{{Name: "foo", Value: "bar", Rename: false}},
			expected: arrowtest.Rows{{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
				"utf8.parsed.foo":                "bar",
				"utf8.parsed.foo_extracted":      "from-json",
			}},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			schema := arrow.NewSchema(append([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromIdent(semconv.ColumnIdentTimestamp, false),
			}, tt.dataFields...), nil)

			row := arrowtest.Row{
				"utf8.builtin.message":           msg,
				"timestamp_ns.builtin.timestamp": ts,
			}
			for k, v := range tt.dataValues {
				row[k] = v
			}

			input := NewArrowtestPipeline(schema, arrowtest.Rows{row})
			parseExpr := &physical.VariadicExpr{
				Op: types.VariadicOpParseLabelfmt,
				Expressions: []physical.Expression{
					&physical.ColumnExpr{Ref: semconv.ColumnIdentMessage.ColumnRef()},
					physical.NewLiteral([]string{}),
					physical.NewLiteral(tt.labelFmts),
				},
			}

			proj := &physical.Projection{
				Expressions: []physical.Expression{parseExpr},
				All:         true,
				Expand:      true,
			}

			pipeline, err := NewProjectPipeline(input, proj, newExpressionEvaluator())
			require.NoError(t, err)
			record, err := pipeline.Read(t.Context())
			require.NoError(t, err)

			actualRows, err := arrowtest.RecordRows(record)
			require.NoError(t, err)
			require.Equal(t, tt.expected, actualRows)
		})
	}
}

// TestNewProjectPipeline_LineFmtReplacesMessageWithEmpty verifies that when
// `line_format` renders to "" the builtin `message` column is replaced with ""
// — matching v1, which always overwrites the line with the template output
// (including empty). Previously mergeColumns treated a new-column "" as
// "missing, keep old" and silently kept the original raw log line.
func TestNewProjectPipeline_LineFmtReplacesMessageWithEmpty(t *testing.T) {
	ts := time.Unix(1700000000, 0).UTC()

	tests := []struct {
		name     string
		template string
		// extraFields/extraValues add a parsed column whose value the template
		// may reference. Empty/nil means no extra column.
		extraFields []arrow.Field
		extraValues arrowtest.Row
		// expectedMessage is the value of the builtin.message column after the
		// pipeline runs.
		expectedMessage string
	}{
		{
			name:            "literal empty template renders to empty line",
			template:        "",
			expectedMessage: "",
		},
		{
			name:            "missing-key under missingkey=zero renders to empty line",
			template:        "{{.does_not_exist}}",
			expectedMessage: "",
		},
		{
			name:            "simple-key whose column does not exist in batch renders to empty line",
			template:        "{{.also_missing}}",
			expectedMessage: "",
		},
		{
			name:            "simple-key whose column has an empty value renders to empty line",
			template:        "{{.orgID}}",
			extraFields:     []arrow.Field{semconv.FieldFromFQN("utf8.parsed.orgID", true)},
			extraValues:     arrowtest.Row{"utf8.parsed.orgID": ""},
			expectedMessage: "",
		},
		{
			name:            "simple-key whose column has a non-empty value renders the value",
			template:        "{{.orgID}}",
			extraFields:     []arrow.Field{semconv.FieldFromFQN("utf8.parsed.orgID", true)},
			extraValues:     arrowtest.Row{"utf8.parsed.orgID": "tenant-7"},
			expectedMessage: "tenant-7",
		},
		{
			name:            "general template rendering empty still replaces the line",
			template:        "{{.orgID}}{{.also_missing}}",
			extraFields:     []arrow.Field{semconv.FieldFromFQN("utf8.parsed.orgID", true)},
			extraValues:     arrowtest.Row{"utf8.parsed.orgID": ""},
			expectedMessage: "",
		},
		{
			name:            "literal non-empty template replaces the line",
			template:        "CONSTANT",
			expectedMessage: "CONSTANT",
		},
	}

	originalMsg := "time=... orgID=\"\" status=401"

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			schema := arrow.NewSchema(append([]arrow.Field{
				semconv.FieldFromIdent(semconv.ColumnIdentMessage, false),
				semconv.FieldFromIdent(semconv.ColumnIdentTimestamp, false),
			}, tt.extraFields...), nil)

			row := arrowtest.Row{
				"utf8.builtin.message":           originalMsg,
				"timestamp_ns.builtin.timestamp": ts,
			}
			for k, v := range tt.extraValues {
				row[k] = v
			}

			input := NewArrowtestPipeline(schema, arrowtest.Rows{row})
			parseExpr := &physical.VariadicExpr{
				Op: types.VariadicOpParseLinefmt,
				Expressions: []physical.Expression{
					&physical.ColumnExpr{Ref: semconv.ColumnIdentMessage.ColumnRef()},
					physical.NewLiteral([]string{}),
					physical.NewLiteral(tt.template),
				},
			}
			proj := &physical.Projection{
				Expressions: []physical.Expression{parseExpr},
				All:         true,
				Expand:      true,
			}

			pipeline, err := NewProjectPipeline(input, proj, newExpressionEvaluator())
			require.NoError(t, err)
			record, err := pipeline.Read(t.Context())
			require.NoError(t, err)

			actualRows, err := arrowtest.RecordRows(record)
			require.NoError(t, err)
			require.Len(t, actualRows, 1)
			require.Equal(t, tt.expectedMessage, actualRows[0]["utf8.builtin.message"])
		})
	}
}
