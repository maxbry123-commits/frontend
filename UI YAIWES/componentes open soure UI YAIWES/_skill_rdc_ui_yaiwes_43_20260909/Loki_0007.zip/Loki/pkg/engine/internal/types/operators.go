package types //nolint:revive

import (
	"fmt"
)

// UnaryOp denotes the kind of [UnaryOp] operation to perform.
type UnaryOp uint32

// Recognized values of [UnaryOp].
const (
	// UnaryOpKindInvalid indicates an invalid unary operation.
	UnaryOpInvalid UnaryOp = iota

	UnaryOpNot          // Logical NOT operation (!).
	UnaryOpAbs          // Mathematical absolute operation (abs).
	UnaryOpCastFloat    // Cast string to float value operation (unwrap).
	UnaryOpCastBytes    // Cast string bytes to float value operation (unwrap).
	UnaryOpCastDuration // Cast string duration to float value operation (unwrap).
)

// String returns the string representation of the UnaryOp.
func (t UnaryOp) String() string {
	switch t {
	case UnaryOpNot:
		return "NOT"
	case UnaryOpAbs:
		return "ABS"
	case UnaryOpCastFloat:
		return "CAST_FLOAT"
	case UnaryOpCastBytes:
		return "CAST_BYTES"
	case UnaryOpCastDuration:
		return "CAST_DURATION"
	default:
		panic(fmt.Sprintf("unknown unary operator %d", t))
	}
}

// BinaryOp denotes the kind of [BinaryOp] operation to perform.
type BinaryOp uint32

// Recognized values of [BinaryOp].
const (
	// BinaryOpInvalid indicates an invalid binary operation.
	BinaryOpInvalid BinaryOp = iota

	BinaryOpEq  // Equality comparison (==).
	BinaryOpNeq // Inequality comparison (!=).
	BinaryOpGt  // Greater than comparison (>).
	BinaryOpGte // Greater than or equal comparison (>=).
	BinaryOpLt  // Less than comparison (<).
	BinaryOpLte // Less than or equal comparison (<=).

	BinaryOpAnd // Logical AND operation (&&).
	BinaryOpOr  // Logical OR operation (||).
	BinaryOpXor // Logical XOR operation (^).

	BinaryOpAdd // Addition operation (+).
	BinaryOpSub // Subtraction operation (-).
	BinaryOpMul // Multiplication operation (*).
	BinaryOpDiv // Division operation (/).
	BinaryOpMod // Modulo operation (%).
	BinaryOpPow // power/exponentiation operation (^).

	BinaryOpMatchSubstr     // Substring matching operation (|=). Used for string match filter.
	BinaryOpNotMatchSubstr  // Substring non-matching operation (!=). Used for string match filter.
	BinaryOpMatchRe         // Regular expression matching operation (|~). Used for regex match filter and label matcher.
	BinaryOpNotMatchRe      // Regular expression non-matching operation (!~). Used for regex match filter and label matcher.
	BinaryOpMatchPattern    // Pattern matching operation (|>). Used for pattern match filter.
	BinaryOpNotMatchPattern // Pattern non-matching operation (!>). Use for pattern match filter.

	BinaryOpEqCaseInsensitive             // Case-insensitive equality comparison.
	BinaryOpNotEqCaseInsensitive          // Case-insensitive inequality comparison.
	BinaryOpMatchSubstrCaseInsensitive    // Case-insensitive substring matching operation.
	BinaryOpNotMatchSubstrCaseInsensitive // Case-insensitive substring non-matching operation.
)

// String returns a human-readable representation of the binary operation kind.
func (t BinaryOp) String() string {
	switch t {
	case BinaryOpEq:
		return "EQ"
	case BinaryOpNeq:
		return "NEQ" // convenience for NOT(EQ(expr))
	case BinaryOpGt:
		return "GT"
	case BinaryOpGte:
		return "GTE"
	case BinaryOpLt:
		return "LT" // convenience for NOT(GTE(expr))
	case BinaryOpLte:
		return "LTE" // convenience for NOT(GT(expr))
	case BinaryOpAnd:
		return "AND"
	case BinaryOpOr:
		return "OR"
	case BinaryOpXor:
		return "XOR"
	case BinaryOpAdd:
		return "ADD"
	case BinaryOpSub:
		return "SUB"
	case BinaryOpMul:
		return "MUL"
	case BinaryOpDiv:
		return "DIV"
	case BinaryOpMod:
		return "MOD"
	case BinaryOpPow:
		return "POW"
	case BinaryOpMatchSubstr:
		return "MATCH_STR"
	case BinaryOpNotMatchSubstr:
		return "NOT_MATCH_STR" // convenience for NOT(MATCH_STR(...))
	case BinaryOpMatchRe:
		return "MATCH_RE"
	case BinaryOpNotMatchRe:
		return "NOT_MATCH_RE" // convenience for NOT(MATCH_RE(...))
	case BinaryOpMatchPattern:
		return "MATCH_PAT"
	case BinaryOpNotMatchPattern:
		return "NOT_MATCH_PAT" // convenience for NOT(MATCH_PAT(...))
	case BinaryOpEqCaseInsensitive:
		return "EQ_CASE_INSENSITIVE"
	case BinaryOpNotEqCaseInsensitive:
		return "NOT_EQ_CASE_INSENSITIVE" // convenience for NOT(EQ_CASE_INSENSITIVE(...))
	case BinaryOpMatchSubstrCaseInsensitive:
		return "MATCH_STR_CASE_INSENSITIVE"
	case BinaryOpNotMatchSubstrCaseInsensitive:
		return "NOT_MATCH_STR_CASE_INSENSITIVE" // convenience for NOT(MATCH_STR_CASE_INSENSITIVE(...))
	default:
		panic(fmt.Sprintf("unknown binary operator %d", t))
	}
}

// VariadicOp denotes the kind of [VariadicOp] operation to perform.
type VariadicOp uint32

// Recognized values of [VariadicOp].
const (
	// VariadicOpKindInvalid indicates an invalid unary operation.
	VariadicOpInvalid VariadicOp = iota

	VariadicOpParseLogfmt   // Parse logfmt line to set of columns operation (logfmt).
	VariadicOpParseJSON     // Parse JSON line to set of columns operation (json).
	VariadicOpParseRegexp   // Parse line with regex capture groups operation (regexp).
	VariadicOpParseLabelfmt // Parse labelfmt line to set of labels operation (labelfmt).
	VariadicOpParseLinefmt  // Parse linefmt line
)

// String returns the string representation of the UnaryOp.
func (t VariadicOp) String() string {
	switch t {
	case VariadicOpParseLogfmt:
		return "PARSE_LOGFMT"
	case VariadicOpParseJSON:
		return "PARSE_JSON"
	case VariadicOpParseRegexp:
		return "PARSE_REGEXP"
	case VariadicOpParseLinefmt:
		return "PARSE_LINEFMT"
	case VariadicOpParseLabelfmt:
		return "PARSE_LABELFMT"
	default:
		panic(fmt.Sprintf("unknown variadic operator %d", t))
	}
}
