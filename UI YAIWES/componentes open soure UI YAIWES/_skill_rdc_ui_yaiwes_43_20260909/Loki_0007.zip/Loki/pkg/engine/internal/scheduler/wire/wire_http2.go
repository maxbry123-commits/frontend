package wire

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"sync"
	"time"

	"github.com/go-kit/log"
	"github.com/go-kit/log/level"
	"go.uber.org/atomic"
	"golang.org/x/net/http2"

	"github.com/grafana/loki/v3/pkg/engine/internal/obslock"
)

// peerAddressHeader is the header used to advertise the address to connect back
// to a client.
const peerAddressHeader = "Loki-Peer-Address"

// HTTP2Listener implements Listener for HTTP/2-based connections.
type HTTP2Listener struct {
	logger log.Logger
	addr   net.Addr

	incoming  chan *http2Conn
	closeOnce sync.Once
	closed    chan struct{}
	codec     *protobufCodec
}

var (
	_ Listener     = (*HTTP2Listener)(nil)
	_ http.Handler = (*HTTP2Listener)(nil)
)

type http2ListenerOpts struct {
	// Logger is used for logging.
	Logger log.Logger
}

type HTTP2ListenerOptFunc func(*http2ListenerOpts)

func WithHTTP2ListenerLogger(logger log.Logger) HTTP2ListenerOptFunc {
	return func(o *http2ListenerOpts) {
		o.Logger = logger
	}
}

// NewHTTP2Listener creates a new HTTP/2 listener on the specified address.
func NewHTTP2Listener(addr net.Addr, optFuncs ...HTTP2ListenerOptFunc) *HTTP2Listener {
	opts := http2ListenerOpts{
		Logger: log.NewNopLogger(),
	}
	for _, optFunc := range optFuncs {
		optFunc(&opts)
	}

	l := &HTTP2Listener{
		addr:   addr,
		logger: opts.Logger,

		incoming: make(chan *http2Conn),
		closed:   make(chan struct{}),
		codec:    DefaultFrameCodec,
	}

	return l
}

// ServeHTTP handles incoming connections.
func (l *HTTP2Listener) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if r.ProtoMajor != 2 {
		http.Error(w, "codec not supported", http.StatusHTTPVersionNotSupported)
		return
	}

	peerAddress := r.Header.Get(peerAddressHeader)
	if peerAddress == "" {
		http.Error(w, "missing required Loki-Peer-Address header", http.StatusBadRequest)
		return
	}

	remoteAddr, err := addrPortStrToAddr(peerAddress)
	if err != nil {
		http.Error(w, "invalid remote addr", http.StatusBadRequest)
		return
	}

	rc := http.NewResponseController(w)
	err = rc.SetWriteDeadline(time.Time{})
	if err != nil {
		http.Error(w, "failed to set write deadline", http.StatusInternalServerError)
		return
	}

	err = rc.SetReadDeadline(time.Time{})
	if err != nil {
		http.Error(w, "failed to set read deadline", http.StatusInternalServerError)
		return
	}

	conn := newHTTP2Conn(r.Context(), l.Addr(), remoteAddr, r.Body, w, rc, l.codec)
	defer conn.Close()

	// Wait until connection is accepted by HTTP2Listener.Accept(ctx)
	select {
	case <-l.closed:
		err := conn.Close()
		if err != nil {
			level.Error(l.logger).Log("msg", "failed to close connection on listener close", "err", err.Error())
			http.Error(w, "failed to close connection", http.StatusInternalServerError)
			return
		}

		http.Error(w, "listener closed", http.StatusServiceUnavailable)

	case <-r.Context().Done():
		level.Debug(l.logger).Log("msg", "request context cancelled", err, r.Context().Err())
		return

	case l.incoming <- conn:
		// connection accepted
		w.WriteHeader(http.StatusOK)
		err := conn.responseController.Flush()
		if err != nil {
			level.Error(l.logger).Log("msg", "failed to flush response controller", "err", err.Error())
			return
		}
		conn.readLoop(r.Context())
	}
}

// Accept waits for and returns the next connection to the listener.
func (l *HTTP2Listener) Accept(ctx context.Context) (Conn, error) {
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-l.closed:
		return nil, net.ErrClosed
	case conn := <-l.incoming:
		return conn, nil
	}
}

// Close closes the listener.
func (l *HTTP2Listener) Close(_ context.Context) error {
	l.closeOnce.Do(func() {
		close(l.closed)
	})
	return nil
}

// Addr returns the listener's network address.
func (l *HTTP2Listener) Addr() net.Addr {
	return l.addr
}

// http2Conn implements Conn for HTTP/2-based connections.
type http2Conn struct {
	ctx context.Context

	localAddr  net.Addr
	remoteAddr net.Addr

	codec              *protobufCodec
	reader             io.ReadCloser
	writer             io.Writer
	responseController *http.ResponseController
	cleanup            func() // Optional cleanup function

	writeMu   obslock.Mutex
	closeOnce sync.Once
	closed    chan struct{}

	// scratch is the reusable encode buffer for this connection's sends. It is
	// only ever touched while holding writeMu, so it needs no further guarding.
	scratch []byte

	metrics atomic.Pointer[Metrics]

	incomingCh chan incomingFrame
}

type incomingFrame struct {
	frame      Frame
	err        error
	enqueuedAt time.Time
}

var _ Conn = (*http2Conn)(nil)

// newHTTP2Conn creates a new HTTP/2 connection tied to the lifetime of ctx.
func newHTTP2Conn(
	ctx context.Context,
	localAddr net.Addr,
	remoteAddr net.Addr,
	reader io.ReadCloser,
	writer io.Writer,
	responseController *http.ResponseController,
	codec *protobufCodec,
) *http2Conn {
	c := &http2Conn{
		ctx:                ctx,
		localAddr:          localAddr,
		remoteAddr:         remoteAddr,
		codec:              codec,
		reader:             reader,
		writer:             writer,
		responseController: responseController,
		closed:             make(chan struct{}),
		incomingCh:         make(chan incomingFrame),
	}
	return c
}

func (c *http2Conn) setMetrics(metrics *Metrics) {
	c.metrics.Store(metrics)
	if metrics != nil {
		c.writeMu.Init("conn_write", metrics.lock)
	}
}

func (c *http2Conn) transport() transport { return transportHTTP2 }

func (c *http2Conn) readLoop(ctx context.Context) {
	for {
		metrics := c.metrics.Load()
		frame, size, err := c.codec.decode(c.reader, metrics)
		if err == nil && metrics != nil {
			metrics.observeFrameBytes(directionIncoming, frame, sendModeInternal, size)
		}

		incoming := incomingFrame{frame: frame, err: err, enqueuedAt: time.Now()}
		if err := c.enqueueIncoming(ctx, incoming); err != nil {
			return
		}
	}
}

func (c *http2Conn) enqueueIncoming(ctx context.Context, incoming incomingFrame) error {
	metrics := c.metrics.Load()
	if incoming.err != nil || metrics == nil {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-c.closed:
			return ErrConnClosed
		case c.incomingCh <- incoming:
			return nil
		}
	}

	frame := incoming.frame
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-c.closed:
		return ErrConnClosed
	case c.incomingCh <- incoming:
		metrics.observeFrameQueueWait(queueConnDispatch, frame, sendModeInternal, time.Since(incoming.enqueuedAt))
		return nil
	default:
	}

	done := metrics.noteBlockedEnqueue(queueConnDispatch, frame, sendModeInternal)
	defer done()

	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-c.closed:
		return ErrConnClosed
	case c.incomingCh <- incoming:
		metrics.observeFrameQueueWait(queueConnDispatch, frame, sendModeInternal, time.Since(incoming.enqueuedAt))
		return nil
	}
}

// Send sends a frame over the connection.
func (c *http2Conn) Send(ctx context.Context, frame Frame) error {
	return c.sendFrame(ctx, frame, sendModeInternal)
}

func (c *http2Conn) sendFrame(ctx context.Context, frame Frame, sendMode sendMode) error {
	metrics := c.metrics.Load()
	timer := metrics.startFrameSend(transportHTTP2, frame, sendMode)
	defer timer.Done(outcomeNone)

	guard := c.writeMu.Lock("send_frame")
	defer guard.Unlock()

	select {
	case <-c.ctx.Done():
		return ErrConnClosed
	case <-ctx.Done():
		return ctx.Err()
	case <-c.closed:
		return ErrConnClosed
	default:
	}

	timer.Phase(phaseSerialize)
	c.scratch = c.codec.encode(frame, metrics, c.scratch)
	data := c.scratch

	timer.Phase(phaseWrite)
	written, err := c.writer.Write(data)
	if err != nil && isHTTP2Error(err) {
		return ErrConnClosed
	} else if err != nil {
		return fmt.Errorf("write frame: %w", err)
	}
	if written != len(data) {
		return fmt.Errorf("write frame: incomplete write: wrote %d bytes, expected %d", written, len(data))
	}
	metrics.observeFrameBytes(directionOutgoing, frame, sendMode, len(data))

	// Flush after each frame to ensure immediate delivery.
	timer.Phase(phaseFlush)
	if c.responseController != nil {
		err = c.responseController.Flush()
	}
	if err != nil && isHTTP2Error(err) {
		return ErrConnClosed
	} else if err != nil {
		return fmt.Errorf("flush response: %w", err)
	}

	return nil
}

// Recv receives a frame from the connection.
func (c *http2Conn) Recv(ctx context.Context) (Frame, error) {
	select {
	case <-c.ctx.Done():
		return nil, ErrConnClosed
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-c.closed:
		return nil, ErrConnClosed
	case f := <-c.incomingCh:
		return f.frame, f.err
	}
}

// Close closes the connection.
func (c *http2Conn) Close() error {
	guard := c.writeMu.Lock("close")
	defer guard.Unlock()

	var err error
	c.closeOnce.Do(func() {
		close(c.closed)

		err = c.reader.Close()
		if c.cleanup != nil {
			c.cleanup()
		}
	})
	return err
}

// LocalAddr returns the local network address.
func (c *http2Conn) LocalAddr() net.Addr {
	return c.localAddr
}

// RemoteAddr returns the remote network address.
func (c *http2Conn) RemoteAddr() net.Addr {
	return c.remoteAddr
}

// HTTP2Dialer holds an http client to pool the connections.
type HTTP2Dialer struct {
	client *http.Client
	codec  *protobufCodec
	path   string
}

var _ Dialer = (*HTTP2Dialer)(nil)

// NewHTTP2Dialer creates a [Dialer] that can open HTTP/2 connections to the
// specified address.
func NewHTTP2Dialer(path string) *HTTP2Dialer {
	return &HTTP2Dialer{
		client: &http.Client{
			Transport: &http2.Transport{
				// No TLS
				AllowHTTP: true,
				DialTLSContext: func(ctx context.Context, network, addr string, _ *tls.Config) (net.Conn, error) {
					return (&net.Dialer{}).DialContext(ctx, network, addr)
				},
			},
			// Context is used for cancellation, no timeout
			Timeout: 0,
		},
		codec: DefaultFrameCodec,
		path:  path,
	}
}

// Dial establishes an HTTP/2 connection to the specified address.
func (d *HTTP2Dialer) Dial(ctx context.Context, from, to net.Addr) (Conn, error) {
	pr, pw := io.Pipe()

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, fmt.Sprintf("http://%s%s", to.String(), d.path), pr)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}
	req.Header.Set(peerAddressHeader, from.String())

	resp, err := d.client.Do(req)
	if err != nil {
		_ = pw.Close()
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		// Drain and close response body to allow connection reuse
		_, _ = io.Copy(io.Discard, resp.Body)
		_ = resp.Body.Close()
		_ = pw.Close()
		return nil, fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	// Create connection
	conn := newHTTP2Conn(
		req.Context(),
		from,
		to,
		resp.Body,
		pw,
		nil, // client doesn't need responseController, it's handled by the pipe writer
		d.codec,
	)

	readLoopWg := sync.WaitGroup{}
	readLoopWg.Add(1)
	go func() {
		defer readLoopWg.Done()
		conn.readLoop(ctx)
	}()

	// when the connection is closed, close the pipe writer and wait until the reader loop exits
	conn.cleanup = func() {
		_ = pw.Close()
		readLoopWg.Wait()
	}

	return conn, nil
}

// https://github.com/golang/net/blob/master/http2/server.go#L68-L73
var http2Errors = map[string]struct{}{
	"http2: stream closed":                              {},
	"body closed by handler":                            {},
	"http2: request body closed due to handler exiting": {},
	"client disconnected":                               {},
}

// isHTTP2Error returns true if err represents one of the known http2 errors that leads to a
// broken connection.
func isHTTP2Error(err error) bool {
	// NOTE(rfratto): At the time of writing, the http2 package doesn't have a
	// guaranteed way to check its errors, so we look
	// at the error message instead.
	for {
		next := errors.Unwrap(err)
		if next == nil {
			break
		}
		err = next
	}
	_, res := http2Errors[err.Error()]
	return res
}
