// Package workflow defines how to represent physical plans as distributed
// workflows.
package workflow

import (
	"context"
	"fmt"
	gotrace "runtime/trace"
	"strconv"
	"sync"
	"time"

	"github.com/go-kit/log"
	"github.com/go-kit/log/level"
	"github.com/oklog/ulid/v2"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/trace"

	"github.com/grafana/loki/v3/pkg/engine/internal/executor"
	"github.com/grafana/loki/v3/pkg/engine/internal/planner/physical"
	"github.com/grafana/loki/v3/pkg/engine/internal/scheduler/schedulerstat"
	"github.com/grafana/loki/v3/pkg/engine/internal/util/dag"
	"github.com/grafana/loki/v3/pkg/xcap"
)

const (
	eliminationReasonEmpty    = "empty"
	eliminationReasonNonEmpty = "non_empty"
)

var (
	tracer = otel.Tracer("pkg/engine/internal/workflow")

	eliminatedCachedTasksTotal = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "loki_engine_v2_task_cached_eliminated_total",
		Help: "Total number of tasks eliminated before execution due to a cache hit.",
	}, []string{"reason"})
)

// Options configures a [Workflow].
type Options struct {
	ID     ulid.ULID // Optional ID for the workflow. One will be generated if not provided.
	Tenant string    // Tenant ID associated with the workflow.
	Actor  []string  // Optional path to the actor that is generating the workflow.

	// DebugTasks toggles debug messages for a task. This is very verbose and
	// should only be enabled for debugging purposes.
	//
	// Regardless of the value of DebugTasks, workers still log when
	// they start and finish assigned tasks.
	DebugTasks bool

	// DebugStreams toggles debug messages for data streams. This is very
	// verbose and should only be enabled for debugging purposes.
	DebugStreams bool

	// CacheEnabled controls whether task fragments and DataObjScan nodes are
	// wrapped with a Cache node during workflow planning.
	CacheEnabled bool

	// MaxTaskCacheSize is the maximum size in bytes of a task result that can be
	// stored in the cache. 0 means only empty responses are cached.
	MaxTaskCacheSize uint64

	// MaxDataObjScanCacheSize is the maximum encoded size in bytes of a DataObjScan
	// result that may be stored. 0 means only empty scan responses are cached.
	MaxDataObjScanCacheSize uint64

	// CacheCompression is the compression codec to use when encoding cache entries
	// (e.g. "snappy"). An empty string means no compression.
	CacheCompression string

	// PruneEmptyCachedTasks controls whether tasks with a known-empty cached
	// result are eliminated at plan time before any work is dispatched.
	PruneEmptyCachedTasks bool

	// NonEmptyCachedTasksMaxSize is the maximum total encoded size in bytes of
	// non-empty cached task buffers that may be embedded in task assignments.
	// Results that exceed the remaining budget are skipped; smaller results that
	// still fit continue to be included. 0 disables non-empty task pruning entirely.
	NonEmptyCachedTasksMaxSize uint64

	// TaskCacheRegistry is the registry of cache backends used at plan time to
	// prune tasks whose cached result is known to be empty.
	TaskCacheRegistry executor.TaskCacheRegistry

	// PruneCachedTasksFetchTimeout is the timeout applied to each cache Fetch
	// call during task pruning at plan time. 0 means no timeout.
	PruneCachedTasksFetchTimeout time.Duration
}

var _ fmt.Stringer = (*Workflow)(nil)

// Workflow represents a physical plan that has been partitioned into
// parallelizable tasks.
type Workflow struct {
	opts            Options
	logger          log.Logger
	runner          Runner
	graph           dag.Graph[*Task]
	resultsStream   *Stream
	resultsPipeline *streamPipe
	manifest        *Manifest

	captureMut sync.Mutex
	// used to merge and link task regions
	capture      *xcap.Capture
	parentRegion *xcap.Region

	span trace.Span

	tasksMut    sync.RWMutex
	taskResults map[*Task]pendingSummary // Holds terminal task results until Close.

	streamsMut          sync.RWMutex
	resultsStreamClosed bool
}

// New creates a new Workflow from a physical plan. New returns an error if the
// physical plan does not have exactly one root node, or if the physical plan
// cannot be partitioned into a Workflow.
//
// The provided Runner will be used for Workflow execution.
func New(ctx context.Context, opts Options, logger log.Logger, runner Runner, plan *physical.Plan) (*Workflow, error) {
	graph, err := planWorkflow(ctx, opts.Tenant, plan, cacheParams{
		enabled:                     opts.CacheEnabled,
		taskCacheMaxSizeBytes:       opts.MaxTaskCacheSize,
		dataObjScanMaxSizeBytes:     opts.MaxDataObjScanCacheSize,
		compression:                 opts.CacheCompression,
		registry:                    opts.TaskCacheRegistry,
		pruneEmptyCachedTasks:       opts.PruneEmptyCachedTasks,
		nonEmptyCachedTasksMaxBytes: opts.NonEmptyCachedTasksMaxSize,
		pruneFetchTimeout:           opts.PruneCachedTasksFetchTimeout,
	}, logger)
	if err != nil {
		return nil, err
	}

	// All tasks were eliminated at plan time — return an empty workflow whose
	// Run() immediately yields EOF without dispatching any work.
	if graph.Len() == 0 {
		level.Debug(logger).Log("msg", "workflow plan is empty")
		return &Workflow{
			opts:        opts,
			logger:      logger,
			runner:      runner,
			taskResults: make(map[*Task]pendingSummary),
		}, nil
	}

	// Inject a stream for final task results.
	results, err := injectResultsStream(&graph)
	if err != nil {
		return nil, err
	}

	wf := &Workflow{
		opts:            opts,
		logger:          logger,
		runner:          runner,
		graph:           graph,
		resultsStream:   results,
		resultsPipeline: newStreamPipe(),

		taskResults: make(map[*Task]pendingSummary),
	}
	// Detach cancellation from the caller's ctx so a cancellation of the
	// planning context does not abort the manifest registration, but keep
	// the xcap region attached for observation recording.
	if err := wf.init(context.WithoutCancel(ctx)); err != nil {
		wf.Close()
		return nil, err
	}
	return wf, nil
}

// Empty reports whether the workflow has no tasks to execute. This happens when
// all tasks were eliminated at plan time because their cached results were empty.
func (wf *Workflow) Empty() bool {
	return wf.graph.Len() == 0
}

// injectResultsStream injects a new stream into the sinks of the root task for
// the workflow to receive final results.
func injectResultsStream(graph *dag.Graph[*Task]) (*Stream, error) {
	results := &Stream{ULID: ulid.Make()}

	// Inject a stream for final task results.
	rootTask, err := graph.Root()
	if err != nil {
		return nil, err
	}

	rootNode, err := rootTask.Fragment.Root()
	if err != nil {
		return nil, err
	}

	rootTask.Sinks[rootNode] = append(rootTask.Sinks[rootNode], results)
	return results, nil
}

// init initializes the workflow.
func (wf *Workflow) init(ctx context.Context) error {
	id := wf.opts.ID
	if id.IsZero() {
		id = ulid.Make()
	}

	wf.manifest = &Manifest{
		ID:     id,
		Tenant: wf.opts.Tenant,
		Actor:  wf.opts.Actor,

		Streams: wf.allStreams(),
		Tasks:   wf.allTasks(),

		StreamClosedHandler: wf.onStreamClosed,
		TaskResultHandler:   wf.onTaskResult,
	}
	if err := wf.runner.RegisterManifest(ctx, wf.manifest); err != nil {
		return err
	}
	return wf.runner.Listen(ctx, wf.resultsPipeline, wf.resultsStream)
}

// String returns a string representation of the workflow. It is a convenience
// method for calling [Sprint].
func (wf *Workflow) String() string {
	return Sprint(wf)
}

// Opts returns options of the workflow (mostly for testing purposes).
func (wf *Workflow) Opts() Options { return wf.opts }

// Len returns the total number of tasks in the workflow.
func (wf *Workflow) Len() int {
	if wf.Empty() {
		return 0
	}
	return len(wf.manifest.Tasks)
}

// Close releases resources associated with the workflow.
func (wf *Workflow) Close() {
	if wf.span != nil {
		wf.span.End()
	}

	if wf.Empty() {
		return
	}

	if err := wf.runner.UnregisterManifest(context.Background(), wf.manifest); err != nil {
		level.Warn(wf.logger).Log("msg", "failed to unregister workflow manifest", "err", err)
	}

	// UnregisterManifest synchronously produces a result for every remaining
	// task, so by here the DAG and all per-task finish times are recorded and the
	// critical path is complete.
	wf.flushTaskSummaries()
}

// Run executes the workflow, returning a pipeline to read results from. The
// provided context is used for the lifetime of the workflow execution.
//
// The returned pipeline must be closed when the workflow is complete to release
// resources.
func (wf *Workflow) Run(ctx context.Context) (pipeline executor.Pipeline, err error) {
	if wf.Empty() {
		level.Debug(wf.logger).Log("msg", "workflow is empty. will return an empty pipeline.")
		return newEOFPipeline(), nil
	}

	wf.capture = xcap.CaptureFromContext(ctx)
	wf.parentRegion = xcap.RegionFromContext(ctx)

	// wf.Run tracks the lifetime of the workflow execution.
	ctx, wf.span = tracer.Start(ctx, "wf.Run")

	// Start dispatching in background goroutine
	gotrace.Log(ctx, "dispatch_tasks", "starting dispatch of "+strconv.Itoa(len(wf.manifest.Tasks))+" tasks")
	go func() {
		err := wf.dispatchTasks(ctx, wf.manifest.Tasks)
		if err != nil {
			wf.resultsPipeline.SetError(err)
			wf.resultsPipeline.Close()
		} else {
			gotrace.Log(ctx, "dispatch_tasks", "all tasks dispatched")
		}
	}()

	return wf.resultsPipeline, nil
}

// dispatchTasks dispatches tasks to the runner.
func (wf *Workflow) dispatchTasks(ctx context.Context, tasks []*Task) error {
	if err := wf.runner.Start(ctx, tasks...); err != nil {
		return fmt.Errorf("failed to start tasks: %w", err)
	}
	return nil
}

func (wf *Workflow) allStreams() []*Stream {
	var (
		result      []*Stream
		seenStreams = map[*Stream]struct{}{}
	)

	// We only iterate over sources below (for convenience), and since
	// wf.results is only used as a sink, we need to manually add it here.
	result = append(result, wf.resultsStream)
	seenStreams[wf.resultsStream] = struct{}{}

	for _, root := range wf.graph.Roots() {
		_ = wf.graph.Walk(root, func(t *Task) error {
			// Task construction guarantees that there is a sink for each source
			// (minus the results stream we generate), so there's no point in
			// iterating over Sources and Sinks.
			for _, streams := range t.Sources {
				for _, stream := range streams {
					if _, seen := seenStreams[stream]; seen {
						continue
					}
					seenStreams[stream] = struct{}{}
					result = append(result, stream)
				}
			}

			return nil
		}, dag.PreOrderWalk)
	}

	return result
}

func (wf *Workflow) allTasks() []*Task {
	var tasks []*Task

	for _, root := range wf.graph.Roots() {
		// [dag.Graph.Walk] guarantees that each node is only visited once, so
		// we can safely append the task to the list without checking if it's
		// already been seen.
		_ = wf.graph.Walk(root, func(t *Task) error {
			tasks = append(tasks, t)
			return nil
		}, dag.PreOrderWalk)
	}

	return tasks
}

func (wf *Workflow) onStreamClosed(_ context.Context, stream *Stream) {
	if wf.opts.DebugStreams {
		level.Debug(wf.logger).Log("msg", "stream closed", "stream_id", stream.ULID)
	}

	if stream.ULID != wf.resultsStream.ULID {
		return
	}

	wf.streamsMut.Lock()
	wf.resultsStreamClosed = true
	wf.streamsMut.Unlock()
	wf.maybeCloseResults()
}

// maybeCloseResults closes the results pipeline (signaling EOF) only once the
// results stream has closed AND every task is terminal, so any failed task's
// SetError happens-before the EOF. Idempotent; safe to call from any handler.
func (wf *Workflow) maybeCloseResults() {
	wf.streamsMut.RLock()
	streamClosed := wf.resultsStreamClosed
	wf.streamsMut.RUnlock()

	if !streamClosed {
		return
	}

	wf.tasksMut.RLock()
	allTasksFinished := len(wf.taskResults) == len(wf.manifest.Tasks)
	wf.tasksMut.RUnlock()
	if !allTasksFinished {
		return
	}

	wf.resultsPipeline.Close()
}

func (wf *Workflow) onTaskResult(ctx context.Context, task *Task, result TaskResult) {
	if wf.opts.DebugTasks {
		level.Debug(wf.logger).Log("msg", "task result", "task_id", task.ULID, "outcome", result.Outcome)
	}

	wf.tasksMut.Lock()
	if _, exists := wf.taskResults[task]; exists {
		wf.tasksMut.Unlock()
		return
	}
	wf.recordTaskResult(task, result)
	wf.tasksMut.Unlock()

	if result.Outcome == TaskOutcomeFailed {
		// Use the first failure from a task as the failure for the entire
		// workflow.
		wf.resultsPipeline.SetError(result.Error)
	}

	if result.Capture != nil {
		wf.mergeCapture(result.Capture)
	}

	// The task has finished. Detect whether its immediate children should be
	// cancelled. We only look at immediate unfinished children, since
	// cancelling them will invoke onTaskResult to process indirect children.
	var tasksToCancel []*Task

	wf.tasksMut.RLock()
	{
	NextChild:
		for _, child := range wf.graph.Children(task) {
			if _, finished := wf.taskResults[child]; finished {
				continue
			}

			// Cancel the child if and only if all of the child's parents (which
			// includes the task that just finished) have terminal results.
			for _, parent := range wf.graph.Parents(child) {
				if _, finished := wf.taskResults[parent]; !finished {
					continue NextChild
				}
			}

			tasksToCancel = append(tasksToCancel, child)
		}
	}
	wf.tasksMut.RUnlock()

	wf.cancelTasks(ctx, tasksToCancel)

	// Close the results pipeline if it was waiting on this task to finish.
	wf.maybeCloseResults()
}

// recordTaskResult stashes a task's result and finish time for Close to emit.
// Recording both under one lock lets flushTaskSummaries trust that observing a
// result for every task implies every summary and finish time is present.
// wf.tasksMut must be held.
func (wf *Workflow) recordTaskResult(task *Task, result TaskResult) {
	summary := pendingSummary{result: result}
	if result.Capture == nil {
		wf.taskResults[task] = summary
		return
	}

	if finish, ok := xcap.TryValue[int64](result.Capture, schedulerstat.TaskFinishTime); ok {
		summary.taskFinishNanos = finish
	}
	wf.taskResults[task] = summary
}

func (wf *Workflow) cancelTasks(ctx context.Context, tasks []*Task) {
	// Runners may re-invoke onTaskResult, so we don't want to hold the mutex
	// when calling this.
	if err := wf.runner.Cancel(ctx, tasks...); err != nil {
		level.Warn(wf.logger).Log("msg", "failed to cancel tasks", "err", err)
	}
}

func (wf *Workflow) mergeCapture(capture *xcap.Capture) {
	wf.captureMut.Lock()
	defer wf.captureMut.Unlock()

	wf.capture.Merge(wf.parentRegion, capture)
}
