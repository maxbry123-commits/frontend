package executor

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"math"
	"strings"
	"testing"
	"time"

	"github.com/apache/arrow-go/v18/arrow"
	"github.com/go-kit/log"
	"github.com/oklog/ulid/v2"
	"github.com/prometheus/prometheus/model/labels"
	"github.com/stretchr/testify/require"
	"github.com/thanos-io/objstore"

	"github.com/grafana/loki/v3/pkg/dataobj"
	v2 "github.com/grafana/loki/v3/pkg/dataobj/compaction/v2"
	compactionv2pb "github.com/grafana/loki/v3/pkg/dataobj/compaction/v2/proto"
	"github.com/grafana/loki/v3/pkg/dataobj/consumer/logsobj"
	"github.com/grafana/loki/v3/pkg/dataobj/index/indexobj"
	"github.com/grafana/loki/v3/pkg/dataobj/sections/postings"
	"github.com/grafana/loki/v3/pkg/dataobj/sections/stats"
	"github.com/grafana/loki/v3/pkg/dataobj/sections/streams"
	"github.com/grafana/loki/v3/pkg/engine/internal/planner/physical"
	"github.com/grafana/loki/v3/pkg/scratch"
	"github.com/grafana/loki/v3/pkg/util/loser"
)

// intRecord is a simple test record for the merge heap tests.
type intRecord struct {
	Key int
	Val string
}

// testSequence is a simple sequence[intRecord] for testing.
type testSequence struct {
	idx       int
	records   []intRecord
	index     int
	cur       intRecord
	err       error
	exhausted bool
}

func newTestSequence(records ...intRecord) *testSequence {
	return &testSequence{
		idx:     0,
		records: records,
		index:   0,
	}
}

func newTestSequenceWithIndex(idx int, records ...intRecord) *testSequence {
	return &testSequence{
		idx:     idx,
		records: records,
		index:   0,
	}
}

func (p *testSequence) Next() bool {
	if p.exhausted {
		return false
	}
	if p.index >= len(p.records) {
		p.exhausted = true
		return false
	}
	p.cur = p.records[p.index]
	p.index++
	return true
}

func (p *testSequence) At() intRecord {
	return p.cur
}

func (p *testSequence) Err() error {
	return p.err
}

func (p *testSequence) Index() int {
	return p.idx
}

func (p *testSequence) Close() error {
	return nil
}

var _ sequence[intRecord] = (*testSequence)(nil)

// trackingSequence wraps a sequence and tracks whether Close() was called.
type trackingSequence[R any] struct {
	underlying sequence[R]
	closed     bool
}

func newTrackingSequence[R any](underlying sequence[R]) *trackingSequence[R] {
	return &trackingSequence[R]{underlying: underlying, closed: false}
}

func (p *trackingSequence[R]) Next() bool {
	return p.underlying.Next()
}

func (p *trackingSequence[R]) At() R {
	return p.underlying.At()
}

func (p *trackingSequence[R]) Err() error {
	return p.underlying.Err()
}

func (p *trackingSequence[R]) Index() int {
	return p.underlying.Index()
}

func (p *trackingSequence[R]) Close() error {
	p.closed = true
	return p.underlying.Close()
}

func (p *trackingSequence[R]) wasClosed() bool {
	return p.closed
}

var _ sequence[intRecord] = (*trackingSequence[intRecord])(nil)

// drainMerge drives a K-way merge over the given sequences using the same
// loser-tree helpers as the production merge sites (heapAt, heapLess,
// closeSeq). It yields every record in sorted order to fn; iteration stops
// early when fn returns false. It mirrors the inlined loop in
// mergePostingsIntoBuilder / mergeStatsIntoBuilder so those helpers stay tested
// without a dedicated merge function.
func drainMerge[R any](ctx context.Context, groups []sequence[R], cmp func(a, b R) int, fn func(R) bool) error {
	tree := loser.New(groups, heapVal[R]{isMax: true}, heapAt[R], heapLess(cmp), closeSeq[R])
	defer tree.Close()

	for tree.Next() {
		if err := ctx.Err(); err != nil {
			return err
		}
		if !fn(tree.Winner().At()) {
			return nil
		}
	}

	for _, g := range groups {
		if err := g.Err(); err != nil {
			return err
		}
	}
	return nil
}

// TestMerge_DistinctKeys tests merging two sequences with distinct keys.
func TestMerge_DistinctKeys(t *testing.T) {
	ctx := context.Background()

	// Two sequences: {1,3,5} and {2,4,6}
	seq1 := newTestSequence(
		intRecord{Key: 1, Val: "a"},
		intRecord{Key: 3, Val: "c"},
		intRecord{Key: 5, Val: "e"},
	)
	seq2 := newTestSequence(
		intRecord{Key: 2, Val: "b"},
		intRecord{Key: 4, Val: "d"},
		intRecord{Key: 6, Val: "f"},
	)

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	expected := []intRecord{
		{Key: 1, Val: "a"},
		{Key: 2, Val: "b"},
		{Key: 3, Val: "c"},
		{Key: 4, Val: "d"},
		{Key: 5, Val: "e"},
		{Key: 6, Val: "f"},
	}

	var actual []intRecord
	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(rec intRecord) bool {
		actual = append(actual, rec)
		return true
	})
	require.NoError(t, err)
	require.Equal(t, expected, actual)
}

// TestMerge_EqualKeysStableOrder verifies that equal-key records are emitted
// in stable group-index order (the merge no longer reduces; collision handling
// lives in the consumers).
func TestMerge_EqualKeysStableOrder(t *testing.T) {
	ctx := context.Background()

	// Two sequences, each with {1, 3}
	seq1 := newTestSequenceWithIndex(0,
		intRecord{Key: 1, Val: "a1"},
		intRecord{Key: 3, Val: "a3"},
	)
	seq2 := newTestSequenceWithIndex(1,
		intRecord{Key: 1, Val: "b1"},
		intRecord{Key: 3, Val: "b3"},
	)

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	// Every record is yielded; equal keys come out lower-group-index first.
	expected := []intRecord{
		{Key: 1, Val: "a1"},
		{Key: 1, Val: "b1"},
		{Key: 3, Val: "a3"},
		{Key: 3, Val: "b3"},
	}

	var actual []intRecord
	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(rec intRecord) bool {
		actual = append(actual, rec)
		return true
	})
	require.NoError(t, err)
	require.Equal(t, expected, actual)
}

// TestMerge_EmptySequences tests merging empty sequences.
func TestMerge_EmptySequences(t *testing.T) {
	ctx := context.Background()

	seq1 := newTestSequence()
	seq2 := newTestSequence()

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	var actual []intRecord
	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(rec intRecord) bool {
		actual = append(actual, rec)
		return true
	})
	require.NoError(t, err)
	require.Len(t, actual, 0)
}

// TestMerge_ContextCancelled tests that context cancellation is honored.
func TestMerge_ContextCancelled(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	seq1 := newTestSequence(intRecord{Key: 1, Val: "a"})
	seq2 := newTestSequence(intRecord{Key: 2, Val: "b"})

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(_ intRecord) bool {
		return true
	})
	require.Equal(t, context.Canceled, err)
}

// TestMerge_ClosesAllSequencesOnEarlyStop tests that merge closes all sequences when the caller stops iteration early.
func TestMerge_ClosesAllSequencesOnEarlyStop(t *testing.T) {
	ctx := context.Background()

	// Create tracking sequences
	seq1 := newTrackingSequence(newTestSequence(
		intRecord{Key: 1, Val: "a"},
		intRecord{Key: 3, Val: "c"},
		intRecord{Key: 5, Val: "e"},
	))
	seq2 := newTrackingSequence(newTestSequence(
		intRecord{Key: 2, Val: "b"},
		intRecord{Key: 4, Val: "d"},
		intRecord{Key: 6, Val: "f"},
	))

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	// Iterate and stop after the 2nd record
	var count int
	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(_ intRecord) bool {
		count++
		return count < 2 // Stop after 2 records
	})
	require.NoError(t, err)
	require.Equal(t, 2, count)

	// Both sequences should be closed
	require.True(t, seq1.wasClosed(), "seq1 should be closed")
	require.True(t, seq2.wasClosed(), "seq2 should be closed")
}

// TestMerge_ClosesAllSequencesOnReadError tests that merge closes all sequences when a read error occurs.
func TestMerge_ClosesAllSequencesOnReadError(t *testing.T) {
	ctx := context.Background()

	// Create a sequence that returns an error
	errorSeq := &errorSequence[intRecord]{}
	trackingErrorSeq := newTrackingSequence(errorSeq)

	// Create a normal tracking sequence
	trackingNormalSeq := newTrackingSequence(newTestSequence(
		intRecord{Key: 1, Val: "a"},
	))

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	// Try to iterate; should get an error
	err := drainMerge(ctx, []sequence[intRecord]{trackingErrorSeq, trackingNormalSeq}, cmp, func(_ intRecord) bool {
		return true
	})
	require.Error(t, err)

	// Both sequences should be closed
	require.True(t, trackingErrorSeq.wasClosed(), "error sequence should be closed")
	require.True(t, trackingNormalSeq.wasClosed(), "normal sequence should be closed")
}

// TestMerge_ClosesAllSequencesOnContextCancel tests that merge closes all sequences when context is cancelled.
func TestMerge_ClosesAllSequencesOnContextCancel(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())

	// Create tracking sequences
	seq1 := newTrackingSequence(newTestSequence(
		intRecord{Key: 1, Val: "a"},
		intRecord{Key: 3, Val: "c"},
	))
	seq2 := newTrackingSequence(newTestSequence(
		intRecord{Key: 2, Val: "b"},
		intRecord{Key: 4, Val: "d"},
	))

	cmp := func(a, b intRecord) int {
		if a.Key < b.Key {
			return -1
		} else if a.Key > b.Key {
			return 1
		}
		return 0
	}

	// Start iteration and cancel after first record
	var count int
	err := drainMerge(ctx, []sequence[intRecord]{seq1, seq2}, cmp, func(_ intRecord) bool {
		count++
		if count == 1 {
			cancel()
		}
		return true
	})
	require.Equal(t, context.Canceled, err)

	// Both sequences should be closed
	require.True(t, seq1.wasClosed(), "seq1 should be closed")
	require.True(t, seq2.wasClosed(), "seq2 should be closed")
}

// errorSequence is a test sequence that always returns an error.
type errorSequence[R any] struct {
	exhausted bool
}

func (p *errorSequence[R]) Next() bool {
	if !p.exhausted {
		p.exhausted = true
	}
	return false
}

func (p *errorSequence[R]) At() R {
	var zero R
	return zero
}

func (p *errorSequence[R]) Err() error {
	return io.ErrUnexpectedEOF
}

func (p *errorSequence[R]) Index() int {
	return 0
}

func (p *errorSequence[R]) Close() error {
	return nil
}

func (p *errorSequence[R]) Exhausted() bool {
	return p.exhausted
}

// TestExecuteIndexMerge_Smoke_BothKinds smoke tests the full merge path: builds
// a source index object with both postings and stats sections, runs the merge
// executor, and verifies the output contains both section types with merged data.
func TestExecuteIndexMerge_Smoke_BothKinds(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// 1. Build and upload a source index object containing both postings and stats sections.
	srcPath := "source/index-0.dat"
	buildSourceIndexWithBothKinds(t, bucket, "tenant-1", srcPath)

	// 2. Construct an IndexMerge node with a single RunRef referencing the source object.
	//    The SectionIndex is a placeholder; the executor scans all sections.
	node := &physical.IndexMerge{
		NodeID:         ulid.Make(),
		Tenant:         "tenant-1",
		ToCWindowStart: 0,
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{
				{ObjectPath: srcPath, SectionIndex: 0}, // SectionIndex is a placeholder; executor scans all
			}},
		},
	}

	// 3. Create executor context and run the merger.
	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	// 4. Verify an artifact was produced and contains both section kinds.
	require.Len(t, artifacts, 1, "merge must produce exactly one artifact")
	outputPath := artifacts[0].Path

	exists, err := bucket.Exists(ctx, outputPath)
	require.NoError(t, err)
	require.True(t, exists, "output object must exist")

	outObj := openObjectFromBucket(ctx, t, bucket, outputPath)
	var sawPostings, sawStats bool
	for _, sec := range outObj.Sections() {
		if postings.CheckSection(sec) {
			sawPostings = true
		}
		if stats.CheckSection(sec) {
			sawStats = true
		}
	}
	require.True(t, sawPostings, "output must contain a postings section")
	require.True(t, sawStats, "output must contain a stats section")
}

func TestDoIndexMerge_CompactedIndexCloseErrorPropagates(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	srcPath := "source/index-0.dat"
	buildSourceIndexWithBothKinds(t, bucket, "tenant-1", srcPath)

	node := &physical.IndexMerge{
		NodeID:         ulid.Make(),
		Tenant:         "tenant-1",
		ToCWindowStart: 0,
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{{ObjectPath: srcPath, SectionIndex: 0}}},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	execCtx.scratchStore = removeFailingStore{execCtx.scratchStore}

	_, err := execCtx.doIndexMerge(ctx, node)
	require.Error(t, err, "a failing closer must surface as an error, not be dropped")
	require.ErrorContains(t, err, "scratch remove failed")
}

// [REDACTED] tests that the executor correctly
// skips legacy section types (streams, pointers) while processing a source object
// that contains all four section types: streams, pointers, stats, and postings.
func TestExecuteIndexMerge_SkipsLegacySections(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build a source object with all four section types: streams, pointers, stats, postings.
	srcPath := "source/index-legacy.dat"
	buildSourceWithLegacySections(t, bucket, "tenant-1", srcPath)

	// Construct an IndexMerge node with a single RunRef.
	node := &physical.IndexMerge{
		NodeID:         ulid.Make(),
		Tenant:         "tenant-1",
		ToCWindowStart: 0,
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{
				{ObjectPath: srcPath, SectionIndex: 0}, // SectionIndex is a placeholder
			}},
		},
	}

	// Run the executor.
	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err, "merge should succeed despite legacy sections")

	// Verify the output exists.
	require.Len(t, artifacts, 1, "merge must produce exactly one artifact")
	outputPath := artifacts[0].Path

	exists, err := bucket.Exists(ctx, outputPath)
	require.NoError(t, err)
	require.True(t, exists, "output object must exist")

	outObj := openObjectFromBucket(ctx, t, bucket, outputPath)

	// Check what sections are present in the output.
	var sawPostings, sawStats bool
	for _, sec := range outObj.Sections() {
		if postings.CheckSection(sec) {
			sawPostings = true
		}
		if stats.CheckSection(sec) {
			sawStats = true
		}
	}

	// Legacy sections (streams, pointers) are not passed through the merger.

	require.True(t, sawPostings, "output must contain a postings section")
	require.True(t, sawStats, "output must contain a stats section")

	// Verify content exists in both sections.
	postingsRows := readPostingsRowsFromBucket(ctx, t, bucket, outputPath)
	statsRows := readStatsRowsFromBucket(ctx, t, bucket, outputPath)

	require.NotEmpty(t, postingsRows, "output postings section should have rows")
	require.NotEmpty(t, statsRows, "output stats section should have rows")
}

// buildSourceWithLegacySections builds a dataobj containing streams, pointers,
// stats, and postings sections (all four section types), then uploads it.
// This simulates a first-generation index object from indexobj.Builder.
func buildSourceWithLegacySections(t *testing.T, bucket objstore.Bucket, tenant, path string) {
	t.Helper()
	ctx := context.Background()

	// Use the indexobj.Builder from the observation API to create a full object.
	// This produces objects with the full set of section types: streams, pointers,
	// pointers (index pointers), stats, postings.
	cfg := logsobj.BuilderBaseConfig{
		TargetPageSize:          2048,
		MaxPageRows:             10000,
		TargetObjectSize:        1 << 22, // 4 MiB
		TargetSectionSize:       1 << 21, // 2 MiB
		BufferSize:              2048 * 8,
		SectionStripeMergeLimit: 2,
	}

	builder, err := indexobj.NewBuilder(cfg, nil)
	require.NoError(t, err, "failed to create indexobj.Builder")

	// Append a stream to get a streams section.
	ts := time.Unix(0, 1_000_000)
	_, err = builder.AppendStream(tenant, streams.Stream{
		ID:               1,
		Labels:           labels.New(labels.Label{Name: "service", Value: "api"}),
		MinTimestamp:     ts,
		MaxTimestamp:     ts.Add(time.Second),
		Rows:             10,
		UncompressedSize: 1000,
	})
	require.NoError(t, err, "failed to append stream")

	// Observe a log line to get a pointers section.
	err = builder.ObserveLogLine(tenant, "log-A", 0, 1, 1, ts, 100)
	require.NoError(t, err, "failed to observe log line")

	// Append a stat to get a stats section.
	err = builder.AppendStat(tenant, "log-A", 0, 16, "label:service",
		map[string]string{"service": "api"},
		ts, ts.Add(time.Second), 10, 1000)
	require.NoError(t, err, "failed to append stat")

	// Observe a label posting to get a postings section.
	builder.ObserveLabelPosting(tenant, postings.LabelObservation{
		ObjectPath:       "log-A",
		SectionIndex:     0,
		ColumnName:       "service",
		LabelValue:       "api",
		StreamID:         1,
		Timestamp:        ts,
		UncompressedSize: 100,
		ShardBuckets:     16,
	})

	// Flush the builder to create the object.
	obj, closer, err := builder.Flush()
	require.NoError(t, err, "failed to flush builder")
	defer closer.Close()

	// Upload to bucket.
	require.NoError(t, uploadObjectToBucket(ctx, bucket, path, obj))
}

// buildSourceIndexWithBothKinds builds a dataobj containing one postings section
// (with 1-2 LabelObservations) and one stats section (with 1-2 Stat rows),
// then uploads it to the bucket at the given path.
func buildSourceIndexWithBothKinds(t *testing.T, bucket objstore.Bucket, tenant, path string) {
	t.Helper()
	ctx := context.Background()

	// Build postings section with one label entry
	postingsBuilder := postings.NewBuilder(nil, 0, 0, math.MaxInt)
	postingsBuilder.SetTenant(tenant)
	ts := time.Unix(0, 1_000_000)

	postingsBuilder.ObserveLabelPosting(postings.LabelObservation{
		ObjectPath:       "log-A",
		SectionIndex:     0,
		ColumnName:       "service",
		LabelValue:       "api",
		StreamID:         1,
		Timestamp:        ts,
		UncompressedSize: 100,
	})

	// Build stats section with one stat row
	statsBuilder := stats.NewBuilder(nil, stats.ColumnarSectionEncoder(2048, 1000))
	statsBuilder.SetTenant(tenant)
	statsBuilder.Append(stats.Stat{
		ObjectPath:       "log-A",
		SectionIndex:     0,
		SortSchema:       "label:service,label:namespace",
		Labels:           map[string]string{"service": "api", "namespace": "default"},
		MinTimestamp:     ts.UnixNano(),
		MaxTimestamp:     ts.UnixNano() + 1000,
		RowCount:         10,
		UncompressedSize: 1000,
	})

	// Build and flush the combined dataobj
	objBuilder := dataobj.NewBuilder(nil)
	require.NoError(t, objBuilder.Append(postingsBuilder))
	require.NoError(t, objBuilder.Append(statsBuilder))

	obj, closer, err := objBuilder.Flush()
	require.NoError(t, err)
	defer closer.Close()

	// Upload to bucket
	require.NoError(t, uploadObjectToBucket(ctx, bucket, path, obj))
}

// openObjectFromBucket downloads and opens a dataobj.Object from the bucket.
func openObjectFromBucket(ctx context.Context, t *testing.T, bucket objstore.Bucket, path string) *dataobj.Object {
	t.Helper()

	obj, err := dataobj.FromBucket(ctx, bucket, path, 0)
	require.NoError(t, err, "failed to open object from bucket at %s", path)

	return obj
}

// uploadObjectToBucket serializes a *dataobj.Object and uploads it to the bucket.
func uploadObjectToBucket(ctx context.Context, bucket objstore.Bucket, path string, obj *dataobj.Object) error {
	reader, err := obj.Reader(ctx)
	if err != nil {
		return fmt.Errorf("getting object reader: %w", err)
	}
	defer reader.Close()

	objBytes, err := io.ReadAll(reader)
	if err != nil {
		return fmt.Errorf("reading object: %w", err)
	}

	return bucket.Upload(ctx, path, io.NopCloser(bytes.NewReader(objBytes)))
}

// newTestExecutorContext constructs a minimal *Context wired with the bucket,
// an in-memory scratch store, a default indexobj BuilderBaseConfig, and a
// no-op logger.
func newTestExecutorContext(t *testing.T, bucket objstore.Bucket) *Context {
	t.Helper()

	testBuilderCfg := logsobj.BuilderBaseConfig{
		TargetPageSize:          2048,
		MaxPageRows:             10000,
		TargetObjectSize:        1 << 22, // 4 MiB
		TargetSectionSize:       1 << 21, // 2 MiB
		BufferSize:              2048 * 8,
		SectionStripeMergeLimit: 2,
	}

	return &Context{
		bucket:       bucket,
		scratchStore: scratch.NewMemory(),
		indexobjCfg:  testBuilderCfg,
		logsobjCfg:   testBuilderCfg,

		logger: log.NewNopLogger(),
	}
}

// buildSourcePostingsObject builds a dataobj containing a single postings section
// with the given label observations, then uploads it to the bucket.
func buildSourcePostingsObject(t *testing.T, bucket objstore.Bucket, tenant, path string, observations []postings.LabelObservation) {
	t.Helper()
	buildSourcePostingsObjectSized(t, bucket, tenant, path, math.MaxInt, observations)
}

// buildSourcePostingsObjectSized is buildSourcePostingsObject with a caller-chosen
// target section size. A small size splits the postings into multiple sections
// within the object, which exercises the per-object section concatenation in the
// merge readers.
func buildSourcePostingsObjectSized(t *testing.T, bucket objstore.Bucket, tenant, path string, targetSectionSize int, observations []postings.LabelObservation) {
	t.Helper()
	ctx := context.Background()

	postingsBuilder := postings.NewBuilder(nil, 0, 0, targetSectionSize)
	postingsBuilder.SetTenant(tenant)
	for _, obs := range observations {
		postingsBuilder.ObserveLabelPosting(obs)
	}

	objBuilder := dataobj.NewBuilder(nil)
	require.NoError(t, objBuilder.Append(postingsBuilder))

	obj, closer, err := objBuilder.Flush()
	require.NoError(t, err)
	defer closer.Close()

	require.NoError(t, uploadObjectToBucket(ctx, bucket, path, obj))
}

// buildSourceStatsObject builds a dataobj containing a single stats section
// with the given stats rows, then uploads it to the bucket.
func buildSourceStatsObject(t *testing.T, bucket objstore.Bucket, tenant, path string, statsRows []stats.Stat) {
	t.Helper()
	ctx := context.Background()

	statsBuilder := stats.NewBuilder(nil, stats.ColumnarSectionEncoder(2048, 1000))
	statsBuilder.SetTenant(tenant)
	for _, row := range statsRows {
		statsBuilder.Append(row)
	}

	objBuilder := dataobj.NewBuilder(nil)
	require.NoError(t, objBuilder.Append(statsBuilder))

	obj, closer, err := objBuilder.Flush()
	require.NoError(t, err)
	defer closer.Close()

	require.NoError(t, uploadObjectToBucket(ctx, bucket, path, obj))
}

// readPostingsRowsFromBucket downloads an object from the bucket, finds its
// postings section, and returns all decoded postings rows.
func readPostingsRowsFromBucket(ctx context.Context, t *testing.T, bucket objstore.Bucket, path string) []postings.Row {
	t.Helper()

	obj := openObjectFromBucket(ctx, t, bucket, path)

	var sec *postings.Section
	for _, s := range obj.Sections() {
		if !postings.CheckSection(s) {
			continue
		}
		var err error
		sec, err = postings.Open(ctx, s)
		require.NoError(t, err)
		break
	}

	require.NotNil(t, sec, "expected postings section in output object")

	inner := postings.NewReader(postings.ReaderOptions{Columns: sec.Columns()})
	require.NoError(t, inner.Open(ctx))
	reader := postings.NewRowReader(ctx, inner)
	defer reader.Close()

	var rows []postings.Row
	for reader.Next() {
		rows = append(rows, reader.At())
	}
	if reader.Err() != nil {
		require.NoError(t, reader.Err())
	}

	return rows
}

// readAllPostingsRowsFromBucket reads rows from ALL postings sections of the
// object, in section order (unlike readPostingsRowsFromBucket, which reads only
// the first section). Merge output can span multiple postings sections.
func readAllPostingsRowsFromBucket(ctx context.Context, t *testing.T, bucket objstore.Bucket, path string) []postings.Row {
	t.Helper()

	obj := openObjectFromBucket(ctx, t, bucket, path)

	var rows []postings.Row
	for _, s := range obj.Sections() {
		if !postings.CheckSection(s) {
			continue
		}
		sec, err := postings.Open(ctx, s)
		require.NoError(t, err)
		inner := postings.NewReader(postings.ReaderOptions{Columns: sec.Columns()})
		require.NoError(t, inner.Open(ctx))
		reader := postings.NewRowReader(ctx, inner)
		for reader.Next() {
			rows = append(rows, reader.At())
		}
		require.NoError(t, reader.Err())
		require.NoError(t, reader.Close())
	}
	return rows
}

// TestExecuteIndexMerge_StorageOrderConcat verifies that the postings merge
// orders rows by physical storage order (ColumnName-primary), not by the
// identity-key order (ObjectPath-primary), and that per-object section
// concatenation is correct.
func TestExecuteIndexMerge_StorageOrderConcat(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()
	ts := time.Unix(0, 100)

	buildSourcePostingsObjectSized(t, bucket, "tenant", "src/a", 1, []postings.LabelObservation{
		{ObjectPath: "log-B", SectionIndex: 0, ColumnName: "svc", LabelValue: "api", StreamID: 1, Timestamp: ts, UncompressedSize: 10},
		{ObjectPath: "log-A", SectionIndex: 0, ColumnName: "zone", LabelValue: "us", StreamID: 2, Timestamp: ts, UncompressedSize: 20},
	})
	buildSourcePostingsObjectSized(t, bucket, "tenant", "src/b", 1, []postings.LabelObservation{
		// (log-B, 0, svc, api) duplicates src/a's first row exactly (same ts).
		{ObjectPath: "log-B", SectionIndex: 0, ColumnName: "svc", LabelValue: "api", StreamID: 1, Timestamp: ts, UncompressedSize: 10},
		{ObjectPath: "log-A", SectionIndex: 0, ColumnName: "zone", LabelValue: "eu", StreamID: 3, Timestamp: ts, UncompressedSize: 30},
	})

	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{{ObjectPath: "src/a", SectionIndex: 0}}},
			{Sections: []*compactionv2pb.SectionRef{{ObjectPath: "src/b", SectionIndex: 0}}},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	rows := readAllPostingsRowsFromBucket(ctx, t, bucket, outputPath)

	// Three unique identity keys; the (log-B, svc, api) duplicate collapsed.
	require.Len(t, rows, 3)

	// Output is in physical storage order (ColumnName-primary).
	for i := range len(rows) - 1 {
		require.Negative(t, comparePostingsRow(rows[i], rows[i+1]),
			"rows not in storage order at %d: %+v vs %+v", i, rows[i], rows[i+1])
	}

	// Every expected identity key is present exactly once.
	type key struct{ obj, col, val string }
	got := map[key]int{}
	for _, r := range rows {
		got[key{r.ObjectPath, r.ColumnName, r.LabelValue}]++
	}
	require.Equal(t, map[key]int{
		{"log-B", "svc", "api"}: 1,
		{"log-A", "zone", "us"}: 1,
		{"log-A", "zone", "eu"}: 1,
	}, got)
}

// readStatsRowsFromBucket downloads an object from the bucket, finds its
// stats section, and returns all decoded stats rows.
func readStatsRowsFromBucket(ctx context.Context, t *testing.T, bucket objstore.Bucket, path string) []stats.Stat {
	t.Helper()

	obj := openObjectFromBucket(ctx, t, bucket, path)

	var sec *stats.Section
	for _, s := range obj.Sections() {
		if !stats.CheckSection(s) {
			continue
		}
		var err error
		sec, err = stats.Open(ctx, s)
		require.NoError(t, err)
		break
	}

	require.NotNil(t, sec, "expected stats section in output object")

	reader := stats.NewRowReader(ctx, sec)
	defer reader.Close()

	var rows []stats.Stat
	for reader.Next() {
		rows = append(rows, reader.At())
	}
	if reader.Err() != nil {
		require.NoError(t, reader.Err())
	}

	return rows
}

// TestExecuteIndexMerge_PostingsUnion tests the union operation on overlapping postings.
func TestExecuteIndexMerge_PostingsUnion(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build two source objects with overlapping postings rows.
	// Source A has rows for (log-A, 0, service, api, sid=1) and (log-A, 0, service, auth, sid=2).
	sourceAPath := "source/index-a.dat"
	buildSourcePostingsObject(t, bucket, "tenant", sourceAPath, []postings.LabelObservation{
		{
			ObjectPath:       "log-A",
			SectionIndex:     0,
			ColumnName:       "service",
			LabelValue:       "api",
			StreamID:         1,
			Timestamp:        time.Unix(0, 100),
			UncompressedSize: 100,
		},
		{
			ObjectPath:       "log-A",
			SectionIndex:     0,
			ColumnName:       "service",
			LabelValue:       "auth",
			StreamID:         2,
			Timestamp:        time.Unix(0, 200),
			UncompressedSize: 200,
		},
	})

	// Source B has row for (log-A, 0, service, api, sid=99) - overlaps with A's first row.
	sourceBPath := "source/index-b.dat"
	buildSourcePostingsObject(t, bucket, "tenant", sourceBPath, []postings.LabelObservation{
		{
			ObjectPath:       "log-A",
			SectionIndex:     0,
			ColumnName:       "service",
			LabelValue:       "api",
			StreamID:         99,
			Timestamp:        time.Unix(0, 150),
			UncompressedSize: 300,
		},
	})

	// Build IndexMerge node with two source objects.
	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: sourceAPath, SectionIndex: 0},
					{ObjectPath: sourceBPath, SectionIndex: 0},
				},
			},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	// Read and verify output.
	rows := readPostingsRowsFromBucket(ctx, t, bucket, outputPath)

	// Should have 2 unique full keys (overlap collapsed).
	require.Len(t, rows, 2)

	// Rows must be in sort order (Kind, ObjectPath, SectionIndex, ColumnName, LabelValue).
	for i := 0; i < len(rows)-1; i++ {
		assert := comparePostingsRow(rows[i], rows[i+1]) < 0
		require.True(t, assert, "rows not in sort order at index %d", i)
	}

	// The overlapping key (log-A, 0, service, api) should have the winner from Source A
	// (first-wins).
	var apiRow postings.Row
	for _, r := range rows {
		if r.ObjectPath == "log-A" && r.SectionIndex == 0 &&
			r.ColumnName == "service" && r.LabelValue == "api" {
			apiRow = r
			break
		}
	}

	require.NotZero(t, apiRow, "expected to find overlapping key in output")
	// The kept row carries Source A's bitmap.
	// This is a simplified check; a full check would decode the bitmap.
	require.NotEmpty(t, apiRow.StreamIDBitmap)

	// Source A's UncompressedSize is 100; Source B's is 300. The heap's stable
	// tiebreak pops the lower sequence index (Source A) first, and first-wins
	// keeps that row, dropping the later duplicate from Source B.
	// Therefore the merged row's UncompressedSize must be 100.
	require.Equal(t, int64(100), apiRow.UncompressedSize,
		"first-wins merger should keep Source A's UncompressedSize")
}

// TestExecuteIndexMerge_StatsDuplicateFirstWins verifies that stats rows
// which collide on the full merge key — (Labels, MinTimestamp,
// MaxTimestamp, ObjectPath, SectionIndex) — collapse to a single row,
// keeping the first row (first-wins).
func TestExecuteIndexMerge_StatsDuplicateFirstWins(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build two source objects whose stats rows agree on every component of
	// the new merge key, including (ObjectPath, SectionIndex). This is the
	// only scenario in which equal-key collisions are now possible.
	ts1, ts2 := int64(100), int64(200)

	sourceAPath := "source/index-a.dat"
	buildSourceStatsObject(t, bucket, "tenant", sourceAPath, []stats.Stat{
		{
			ObjectPath:       "log-X",
			SectionIndex:     0,
			SortSchema:       "label:service",
			Labels:           map[string]string{"service": "api"},
			MinTimestamp:     ts1, // identical to source B
			MaxTimestamp:     ts2, // identical to source B
			RowCount:         10,
			UncompressedSize: 1000,
		},
	})

	sourceBPath := "source/index-b.dat"
	buildSourceStatsObject(t, bucket, "tenant", sourceBPath, []stats.Stat{
		{
			ObjectPath:       "log-X",
			SectionIndex:     0,
			SortSchema:       "label:service",
			Labels:           map[string]string{"service": "api"},
			MinTimestamp:     ts1, // identical to source A
			MaxTimestamp:     ts2, // identical to source A
			RowCount:         20,
			UncompressedSize: 2000,
		},
	})

	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: sourceAPath, SectionIndex: 0},
					{ObjectPath: sourceBPath, SectionIndex: 0},
				},
			},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	rows := readStatsRowsFromBucket(ctx, t, bucket, outputPath)

	// Should have exactly one stats row (duplicate collapsed by first-wins).
	require.Len(t, rows, 1)

	row := rows[0]
	require.Equal(t, "log-X", row.ObjectPath)
	require.Equal(t, int64(0), row.SectionIndex)
	require.Equal(t, "label:service", row.SortSchema)
	require.Equal(t, map[string]string{"service": "api"}, row.Labels)

	// Timestamps unchanged (both inputs match).
	require.Equal(t, ts1, row.MinTimestamp)
	require.Equal(t, ts2, row.MaxTimestamp)

	require.Equal(t, int64(10), row.RowCount,
		"first-wins must keep Source A's RowCount, not aggregate")
	require.Equal(t, int64(1000), row.UncompressedSize,
		"first-wins must keep Source A's UncompressedSize, not aggregate")
}

// TestExecuteIndexMerge_MixedKinds tests merging both postings and stats sections.
func TestExecuteIndexMerge_MixedKinds(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build one source with postings only.
	postingsPath := "source/index-postings.dat"
	buildSourcePostingsObject(t, bucket, "tenant", postingsPath, []postings.LabelObservation{
		{
			ObjectPath:       "log-A",
			SectionIndex:     0,
			ColumnName:       "service",
			LabelValue:       "api",
			StreamID:         1,
			Timestamp:        time.Unix(0, 100),
			UncompressedSize: 100,
		},
	})

	// Build one source with stats only.
	statsPath := "source/index-stats.dat"
	buildSourceStatsObject(t, bucket, "tenant", statsPath, []stats.Stat{
		{
			ObjectPath:       "log-A",
			SectionIndex:     0,
			SortSchema:       "label:service",
			Labels:           map[string]string{"service": "api"},
			MinTimestamp:     100,
			MaxTimestamp:     200,
			RowCount:         10,
			UncompressedSize: 1000,
		},
	})

	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: postingsPath, SectionIndex: 0},
				},
			},
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: statsPath, SectionIndex: 0},
				},
			},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	// Verify output contains both kinds.
	exists, err := bucket.Exists(ctx, outputPath)
	require.NoError(t, err)
	require.True(t, exists)

	outObj := openObjectFromBucket(ctx, t, bucket, outputPath)
	var sawPostings, sawStats bool
	for _, sec := range outObj.Sections() {
		if postings.CheckSection(sec) {
			sawPostings = true
		}
		if stats.CheckSection(sec) {
			sawStats = true
		}
	}

	require.True(t, sawPostings, "output must contain postings section")
	require.True(t, sawStats, "output must contain stats section")

	// Verify content from both sections.
	postingsRows := readPostingsRowsFromBucket(ctx, t, bucket, outputPath)
	statRows := readStatsRowsFromBucket(ctx, t, bucket, outputPath)

	require.Len(t, postingsRows, 1)
	require.Len(t, statRows, 1)
}

// TestExecuteIndexMerge_StatsDuplicateFirstWinsMultiSource verifies
// first-wins behavior across more than two duplicate sources. With four
// sequences colliding on the same (Labels, MinTimestamp, MaxTimestamp,
// ObjectPath, SectionIndex), the merge emits a single row carrying the
// values from the lowest sequence index (sequence 0 here).
func TestExecuteIndexMerge_StatsDuplicateFirstWinsMultiSource(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build 4 source objects whose stats rows collide on every component of
	// the new merge key. They differ only in their counts, so we can prove
	// which sequence row survives.
	const sourceCount = 4
	rowCounts := []int64{10, 20, 30, 40}
	uncompressedSizes := []int64{1000, 2000, 3000, 4000}
	ts1, ts2 := int64(100), int64(200) // identical for all sources

	for i := 0; i < sourceCount; i++ {
		path := fmt.Sprintf("source/index-%d.dat", i)
		buildSourceStatsObject(t, bucket, "tenant", path, []stats.Stat{
			{
				ObjectPath:       "log-X",
				SectionIndex:     0,
				SortSchema:       "label:service",
				Labels:           map[string]string{"service": "api"},
				MinTimestamp:     ts1, // identical across all sources
				MaxTimestamp:     ts2, // identical across all sources
				RowCount:         rowCounts[i],
				UncompressedSize: uncompressedSizes[i],
			},
		})
	}

	// Build IndexMerge node with all 4 sources.
	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{},
			},
		},
	}

	for i := 0; i < sourceCount; i++ {
		path := fmt.Sprintf("source/index-%d.dat", i)
		node.Runs[0].Sections = append(node.Runs[0].Sections,
			&compactionv2pb.SectionRef{ObjectPath: path, SectionIndex: 0})
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	rows := readStatsRowsFromBucket(ctx, t, bucket, outputPath)

	// Should have exactly one row (all duplicates collapsed by first-wins).
	require.Len(t, rows, 1)

	row := rows[0]
	require.Equal(t, int64(10), row.RowCount,
		"first-wins must keep the lowest sequence index's RowCount")
	require.Equal(t, int64(1000), row.UncompressedSize,
		"first-wins must keep the lowest sequence index's UncompressedSize")
	// Timestamps unchanged (all inputs identical).
	require.Equal(t, ts1, row.MinTimestamp)
	require.Equal(t, ts2, row.MaxTimestamp)
}

// TestExecuteIndexMerge_EmptyInputs tests behavior when no sections are provided.
func TestExecuteIndexMerge_EmptyInputs(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	node := &physical.IndexMerge{
		NodeID:         ulid.Make(),
		Tenant:         "tenant",
		ToCWindowStart: 0,
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: nil, // Empty input
			},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	// Empty input produces no artifact.
	require.Len(t, artifacts, 0, "empty input should produce no artifact")
}

// TestStatsRowReader_DottedLabelNames tests that label names containing dots
// are correctly decoded (not truncated by split).
func TestStatsRowReader_DottedLabelNames(t *testing.T) {
	ctx := context.Background()

	// Build a stats section with a label name containing a dot, e.g., "my.svc"
	b := stats.NewBuilder(nil, stats.ColumnarSectionEncoder(1024*1024, 10000))

	b.Append(stats.Stat{
		ObjectPath:       "/obj1",
		SectionIndex:     0,
		SortSchema:       "label:my.svc",
		Labels:           map[string]string{"my.svc": "api"},
		MinTimestamp:     100,
		MaxTimestamp:     200,
		RowCount:         5,
		UncompressedSize: 50,
	})

	// Flush to a dataobj
	objBuilder := dataobj.NewBuilder(nil)
	require.NoError(t, objBuilder.Append(b))
	obj, closer, err := objBuilder.Flush()
	require.NoError(t, err)
	defer closer.Close()

	// Find and open the stats section
	var sec *stats.Section
	for _, s := range obj.Sections() {
		if !stats.CheckSection(s) {
			continue
		}
		sec, err = stats.Open(ctx, s)
		require.NoError(t, err)
		break
	}
	require.NotNil(t, sec)

	// Create a reader and read the row
	reader := stats.NewRowReader(ctx, sec)
	defer reader.Close()

	if !reader.Next() {
		require.Fail(t, "expected to read a row")
	}
	row := reader.At()
	if reader.Err() != nil {
		require.NoError(t, reader.Err())
	}

	// Verify the label name is NOT truncated: should be "my.svc", not "my"
	require.Equal(t, "label:my.svc", row.SortSchema)
	require.Equal(t, map[string]string{"my.svc": "api"}, row.Labels)
	require.Equal(t, "api", row.Labels["my.svc"])

	// Verify we don't have a truncated label
	_, hasTruncated := row.Labels["my"]
	require.False(t, hasTruncated, "label should not be truncated to 'my'")
}

// TestExecuteIndexMerge_StatsSortSchemaMismatch_FailsLoudly tests that merging
// stats sections with different SortSchema values fails with a clear error
// before any data is written.
func TestExecuteIndexMerge_StatsSortSchemaMismatch_FailsLoudly(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build two source objects with DIFFERENT SortSchema values
	sourceAPath := "source/index-a.dat"
	buildSourceStatsObject(t, bucket, "tenant", sourceAPath, []stats.Stat{
		{
			ObjectPath:       "log-X",
			SectionIndex:     0,
			SortSchema:       "label:service,label:job",
			Labels:           map[string]string{"service": "api", "job": "j1"},
			MinTimestamp:     100,
			MaxTimestamp:     200,
			RowCount:         10,
			UncompressedSize: 1000,
		},
	})

	sourceBPath := "source/index-b.dat"
	buildSourceStatsObject(t, bucket, "tenant", sourceBPath, []stats.Stat{
		{
			ObjectPath:       "log-X",
			SectionIndex:     0,
			SortSchema:       "label:job,label:service", // Different SortSchema
			Labels:           map[string]string{"job": "j1", "service": "api"},
			MinTimestamp:     100,
			MaxTimestamp:     200,
			RowCount:         20,
			UncompressedSize: 2000,
		},
	})

	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: "tenant",
		Runs: []*compactionv2pb.RunRef{
			{
				Sections: []*compactionv2pb.SectionRef{
					{ObjectPath: sourceAPath, SectionIndex: 0},
					{ObjectPath: sourceBPath, SectionIndex: 0},
				},
			},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	_, err := execCtx.doIndexMerge(ctx, node)
	require.Error(t, err, "merge should fail with SortSchema mismatch")
	require.Contains(t, err.Error(), "SortSchema", "error should mention SortSchema mismatch")
}

// tenantRows describes how many postings and stats rows to seed for a tenant
// in a multi-tenant source object.
type tenantRows struct {
	tenant   string
	rowCount int
}

// buildMultiTenantSourceObject builds a single index object holding postings
// and stats sections for multiple tenants. Every row references an
// object_path that embeds the tenant name, so foreign rows are identifiable in
// the merged output.
func buildMultiTenantSourceObject(t *testing.T, bucket objstore.Bucket, path string, tenants []tenantRows) {
	t.Helper()
	ctx := context.Background()

	objBuilder := dataobj.NewBuilder(nil)

	for _, tr := range tenants {
		// Tiny targetSectionSizeBytes so postings spill into multiple sections.
		postingsBuilder := postings.NewBuilder(nil, 0, 0, 64)
		postingsBuilder.SetTenant(tr.tenant)

		statsBuilder := stats.NewBuilder(nil, stats.ColumnarSectionEncoder(2048, 1000))
		statsBuilder.SetTenant(tr.tenant)

		for i := 0; i < tr.rowCount; i++ {
			// Embed the source object path so rows from different source objects
			// are distinct and do not collapse during the merge dedup.
			objectPath := fmt.Sprintf("logs/%s/%s/obj-%d.dat", tr.tenant, path, i)
			ts := time.Unix(0, int64(1_000_000+i))

			postingsBuilder.ObserveLabelPosting(postings.LabelObservation{
				ObjectPath:       objectPath,
				SectionIndex:     int64(i),
				ColumnName:       "service_name",
				LabelValue:       fmt.Sprintf("svc-%s-%s-%d", tr.tenant, path, i),
				StreamID:         int64(i + 1),
				Timestamp:        ts,
				UncompressedSize: 100,
			})

			statsBuilder.Append(stats.Stat{
				ObjectPath:       objectPath,
				SectionIndex:     int64(i),
				SortSchema:       "label:service_name",
				Labels:           map[string]string{"service_name": fmt.Sprintf("svc-%s-%s-%d", tr.tenant, path, i)},
				MinTimestamp:     ts.UnixNano(),
				MaxTimestamp:     ts.UnixNano() + 1000,
				RowCount:         int64(10),
				UncompressedSize: int64(1000),
			})

			// Flush stats mid-stream every 2 rows to produce multiple stats
			// sections per tenant. Builder.Flush resets after each flush.
			if (i+1)%2 == 0 {
				require.NoError(t, objBuilder.Append(statsBuilder))
			}
		}

		// Final flush of any remaining stats rows and all postings.
		require.NoError(t, objBuilder.Append(statsBuilder))
		require.NoError(t, objBuilder.Append(postingsBuilder))
	}

	obj, closer, err := objBuilder.Flush()
	require.NoError(t, err)
	defer closer.Close()

	require.NoError(t, uploadObjectToBucket(ctx, bucket, path, obj))
}

// TestExecuteIndexMerge_CrossTenantSectionsExcluded verifies that an IndexMerge
// for one tenant only merges sections belonging to that tenant.
func TestExecuteIndexMerge_CrossTenantSectionsExcluded(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	const targetTenant = "tenant-A"

	// Intentionally mirroring a case where one tenant's small slice is buried under
	// everyone else's.
	layout := []tenantRows{
		{tenant: targetTenant, rowCount: 3},
		{tenant: "tenant-B", rowCount: 20},
		{tenant: "tenant-C", rowCount: 25},
	}

	source0 := "source/index-0.dat"
	source1 := "source/index-1.dat"
	buildMultiTenantSourceObject(t, bucket, source0, layout)
	buildMultiTenantSourceObject(t, bucket, source1, layout)

	node := &physical.IndexMerge{
		NodeID: ulid.Make(),
		Tenant: targetTenant,
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{
				{ObjectPath: source0, SectionIndex: 0},
			}},
			{Sections: []*compactionv2pb.SectionRef{
				{ObjectPath: source1, SectionIndex: 0},
			}},
		},
	}

	execCtx := newTestExecutorContext(t, bucket)
	artifacts, err := execCtx.doIndexMerge(ctx, node)
	require.NoError(t, err)

	require.Len(t, artifacts, 1)
	outputPath := artifacts[0].Path

	// Only the target tenant's rows must appear: 2 sources × 3 rows = 6.
	statsRows := readStatsRowsFromBucket(ctx, t, bucket, outputPath)
	require.Len(t, statsRows, 6,
		"output must contain only the target tenant's stats rows, not every tenant's")
	for _, row := range statsRows {
		require.Contains(t, row.ObjectPath, targetTenant,
			"foreign-tenant stats row leaked into output: %q", row.ObjectPath)
	}

	postingsRows := readPostingsRowsFromBucket(ctx, t, bucket, outputPath)
	require.Len(t, postingsRows, 6,
		"output must contain only the target tenant's postings rows, not every tenant's")
	for _, row := range postingsRows {
		require.Contains(t, row.ObjectPath, targetTenant,
			"foreign-tenant postings row leaked into output: %q", row.ObjectPath)
	}
}

// TestExecuteIndexMerge_ContentHashAndRecord verifies that executeIndexMerge
// reports a content-hash-based path via a result record.
func TestExecuteIndexMerge_ContentHashAndRecord(t *testing.T) {
	ctx := context.Background()
	bucket := objstore.NewInMemBucket()

	// Build and upload a source index object containing both postings and stats.
	srcPath := "source/index-0.dat"
	tenant := "tenant-1"
	buildSourceIndexWithBothKinds(t, bucket, tenant, srcPath)

	// Construct an IndexMerge node.
	node := &physical.IndexMerge{
		NodeID:         ulid.Make(),
		Tenant:         tenant,
		ToCWindowStart: 0,
		Runs: []*compactionv2pb.RunRef{
			{Sections: []*compactionv2pb.SectionRef{
				{ObjectPath: srcPath, SectionIndex: 0},
			}},
		},
	}

	// Create executor context and run executeIndexMerge.
	execCtx := newTestExecutorContext(t, bucket)
	pipeline := execCtx.executeIndexMerge(ctx, node)

	// Drain the pipeline and collect records.
	reader := TranslateEOF(pipeline)
	defer reader.Close()
	require.NoError(t, reader.Open(ctx))

	var records []arrow.RecordBatch
	for {
		rec, err := reader.Read(ctx)
		if err == io.EOF {
			break
		}
		require.NoError(t, err)
		records = append(records, rec)
	}

	// Verify exactly one record was emitted.
	require.Len(t, records, 1, "executeIndexMerge must emit exactly one result record")
	resultRec := records[0]
	require.NotNil(t, resultRec, "result record must not be nil")

	// Read the artifacts from the record.
	artifacts, err := v2.ReadResultRecord(resultRec)
	require.NoError(t, err)
	require.Len(t, artifacts, 1, "result record must contain exactly one artifact")

	// Verify the artifact path matches the content-hash naming scheme.
	path := artifacts[0].Path
	require.True(t, strings.HasPrefix(path, "indexes/tenants/"+tenant+"/"),
		"artifact path must start with indexes/tenants/<tenant>/, got %q", path)

	// Verify the object exists at the reported path in the bucket.
	exists, err := bucket.Exists(ctx, path)
	require.NoError(t, err)
	require.True(t, exists, "output object must exist at path %q", path)

	// Verify the content can be read and is a valid index object.
	outObj := openObjectFromBucket(ctx, t, bucket, path)
	var sawPostings, sawStats bool
	for _, sec := range outObj.Sections() {
		if postings.CheckSection(sec) {
			sawPostings = true
		}
		if stats.CheckSection(sec) {
			sawStats = true
		}
	}
	require.True(t, sawPostings, "output must contain a postings section")
	require.True(t, sawStats, "output must contain a stats section")
}
