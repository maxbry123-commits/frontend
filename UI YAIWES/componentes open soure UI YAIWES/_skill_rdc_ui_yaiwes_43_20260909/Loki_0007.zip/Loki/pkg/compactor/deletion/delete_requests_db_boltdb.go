package deletion

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/go-kit/log/level"
	"go.etcd.io/bbolt"

	"github.com/grafana/loki/v3/pkg/compression"
	boltdbcommon "github.com/grafana/loki/v3/pkg/storage/common/boltdb"
	"github.com/grafana/loki/v3/pkg/storage/stores/shipper/indexshipper/storage"
	util_log "github.com/grafana/loki/v3/pkg/util/log"
)

type deleteRequestsTable struct {
	indexStorageClient storage.Client
	dbPath             string
	updatedAt          time.Time
	uploadedAt         time.Time

	boltdbIndexClient *boltdbcommon.BoltIndexClient
	db                *bbolt.DB
	done              chan struct{}
	wg                sync.WaitGroup
}

const deleteRequestsDBBoltDBFileName = DeleteRequestsTableName + ".gz"

func newDeleteRequestsTable(workingDirectory string, indexStorageClient storage.Client) (boltdbcommon.Client, error) {
	dbPath := filepath.Join(workingDirectory, DeleteRequestsTableName)
	boltdbIndexClient, err := boltdbcommon.NewBoltDBIndexClient(boltdbcommon.Config{Directory: filepath.Dir(dbPath)})
	if err != nil {
		return nil, err
	}

	table := &deleteRequestsTable{
		indexStorageClient: indexStorageClient,
		dbPath:             dbPath,
		boltdbIndexClient:  boltdbIndexClient,
		done:               make(chan struct{}),
	}

	err = table.init()
	if err != nil {
		return nil, err
	}

	table.wg.Add(1)
	go table.loop()
	return table, nil
}

func (t *deleteRequestsTable) init() error {
	tempFilePath := fmt.Sprintf("%s%s", t.dbPath, tempFileSuffix)

	if err := os.Remove(tempFilePath); err != nil && !os.IsNotExist(err) {
		level.Error(util_log.Logger).Log("msg", fmt.Sprintf("failed to remove temp file %s", tempFilePath), "err", err)
	}

	_, err := os.Stat(t.dbPath)
	if err != nil {
		err = storage.DownloadFileFromStorage(t.dbPath, true,
			true, storage.LoggerWithFilename(util_log.Logger, deleteRequestsDBBoltDBFileName), func() (io.ReadCloser, error) {
				return t.indexStorageClient.GetFile(context.Background(), DeleteRequestsTableName, deleteRequestsDBBoltDBFileName)
			})
		if err != nil && !t.indexStorageClient.IsFileNotFoundErr(err) {
			return err
		}
	}

	t.db, err = boltdbcommon.SafeOpenBoltdbFile(t.dbPath)
	return err
}

func (t *deleteRequestsTable) loop() {
	uploadTicker := time.NewTicker(5 * time.Minute)
	defer uploadTicker.Stop()

	defer t.wg.Done()

	for {
		select {
		case <-uploadTicker.C:
			if err := t.uploadFile(); err != nil {
				level.Error(util_log.Logger).Log("msg", "failed to upload delete requests file", "err", err)
			}
		case <-t.done:
			return
		}
	}
}

func (t *deleteRequestsTable) uploadFile() error {
	if t.uploadedAt.After(t.updatedAt) {
		level.Debug(util_log.Logger).Log("msg", "skipping uploading delete requests db since there have been no updates to the table since last upload")
		return nil
	}
	level.Debug(util_log.Logger).Log("msg", "uploading delete requests db")

	tempFilePath := fmt.Sprintf("%s.%s", t.dbPath, tempFileSuffix)
	f, err := os.Create(tempFilePath)
	if err != nil {
		return err
	}

	defer func() {
		if err := f.Close(); err != nil {
			level.Error(util_log.Logger).Log("msg", "failed to close temp file", "path", tempFilePath, "err", err)
		}

		if err := os.Remove(tempFilePath); err != nil {
			level.Error(util_log.Logger).Log("msg", "failed to remove temp file", "path", tempFilePath, "err", err)
		}
	}()

	err = t.db.View(func(tx *bbolt.Tx) (err error) {
		gzipPool := compression.GetWriterPool(compression.GZIP)
		compressedWriter := gzipPool.GetWriter(f)
		defer gzipPool.PutWriter(compressedWriter)

		defer func() {
			cerr := compressedWriter.Close()
			if err == nil {
				err = cerr
			}
		}()

		_, err = tx.WriteTo(compressedWriter)
		return
	})
	if err != nil {
		return err
	}

	// flush the file to disk and seek the file to the beginning.
	if err := f.Sync(); err != nil {
		return err
	}

	if _, err := f.Seek(0, 0); err != nil {
		return err
	}

	if err := t.indexStorageClient.PutFile(context.Background(), DeleteRequestsTableName, deleteRequestsDBBoltDBFileName, f); err != nil {
		return err
	}

	t.uploadedAt = time.Now()
	return nil
}

func (t *deleteRequestsTable) Stop() {
	close(t.done)
	t.wg.Wait()

	if err := t.uploadFile(); err != nil {
		level.Error(util_log.Logger).Log("msg", "failed to upload delete requests file during shutdown", "err", err)
	}

	if err := t.db.Close(); err != nil {
		level.Error(util_log.Logger).Log("msg", "failed to close delete requests db", "err", err)
	}

	t.boltdbIndexClient.Stop()
}

func (t *deleteRequestsTable) NewWriteBatch() boltdbcommon.WriteBatch {
	return t.boltdbIndexClient.NewWriteBatch()
}

func (t *deleteRequestsTable) BatchWrite(ctx context.Context, batch boltdbcommon.WriteBatch) error {
	boltWriteBatch, ok := batch.(*boltdbcommon.BoltWriteBatch)
	if !ok {
		return errors.New("invalid write batch")
	}

	for _, tableWrites := range boltWriteBatch.Writes {
		if err := boltdbcommon.WriteToDB(ctx, t.db, boltdbcommon.IndexBucketName, tableWrites); err != nil {
			return err
		}
	}

	t.updatedAt = time.Now()
	return nil
}

func (t *deleteRequestsTable) QueryPages(ctx context.Context, queries []boltdbcommon.Query, callback boltdbcommon.QueryPagesCallback) error {
	for _, query := range queries {
		if err := boltdbcommon.QueryDB(ctx, t.db, boltdbcommon.IndexBucketName, query, callback); err != nil {
			return err
		}
	}

	return nil
}
