// Copyright (c) 2025 OpenBao a Series of LF Projects, LLC
// SPDX-License-Identifier: MPL-2.0

package http

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"testing"

	"github.com/hashicorp/go-secure-stdlib/parseutil"
	"github.com/openbao/openbao/v2/internal/helper/configutil"
	"github.com/openbao/openbao/v2/internal/vault"
	"github.com/stretchr/testify/require"
	"github.com/tsaarni/certyaml"
)

func getCertTestHandler(listenerConfig *configutil.Listener) func(props *vault.HandlerProperties) http.Handler {
	return func(props *vault.HandlerProperties) http.Handler {
		origHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Write out what we internally processed.
			w.Header().Set("X-Processed-Tls-Client-Certificate-Resp", r.Header.Get(ProcessedForwardedClientCertHeader))
			w.WriteHeader(http.StatusOK)
		})
		// This mirrors how the handlers would be set in server.go
		return wrapClientCertificateHandler(origHandler, &vault.HandlerProperties{
			ListenerConfig: listenerConfig,
		})
	}
}

func getCertTestHandlerWithForwardedFor(listenerConfig *configutil.Listener) func(props *vault.HandlerProperties) http.Handler {
	return func(props *vault.HandlerProperties) http.Handler {
		origHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Write out what we internally processed.
			w.Header().Set("X-Processed-Tls-Client-Certificate-Resp", r.Header.Get(ProcessedForwardedClientCertHeader))
			w.WriteHeader(http.StatusOK)
		})
		// This mirrors how the handlers would be set in server.go
		return WrapHttpServerHandler(wrapClientCertificateHandler(origHandler, &vault.HandlerProperties{
			ListenerConfig: listenerConfig,
		}), listenerConfig)
	}
}

func getDefaultListenerConfigForClientCerts(decoders []string) *configutil.Listener {
	return &configutil.Listener{
		XForwardedForClientCertHeader:   "X-Forwarded-For-Client-Cert",
		XForwardedForClientCertDecoders: decoders,
	}
}

func TestHandler_XForwardedForClientCert(t *testing.T) {
	t.Parallel()

	testCert := &certyaml.Certificate{
		Subject:         "cn=cert.example.com",
		SubjectAltNames: []string{"DNS:cert.example.com", "IP:127.0.0.1"},
	}
	require.NoError(t, testCert.Generate())

	clientCertBase64 := base64.StdEncoding.EncodeToString(testCert.GeneratedCert.Certificate[0])
	clientCertPemText := string(testCert.CertPEM())

	otherCert := &certyaml.Certificate{
		Subject: "cn=other.example.com",
	}
	require.NoError(t, otherCert.Generate())

	otherCertPemText := string(otherCert.CertPEM())

	invalidBase64Values := []struct {
		name  string
		value string
	}{
		{"invalid_length", "invalid"},
		{"invalid_character", "::" + clientCertBase64},
	}
	for _, testItem := range invalidBase64Values {
		testName := fmt.Sprintf("invalid_base64_%s", testItem.name)
		t.Run(testName, func(t *testing.T) {
			t.Parallel()
			testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{}))
			cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
				HandlerFunc: HandlerFunc(testHandler),
			})
			cluster.Start()
			defer cluster.Cleanup()

			client := cluster.Cores[0].Client
			req := client.NewRequest("GET", "/")
			req.Headers = make(http.Header)
			req.Headers.Add("X-Forwarded-For-Client-Cert", "invalid")
			resp, err := client.RawRequest(req)
			if err == nil {
				t.Fatal("expected error")
			}
			defer func(Body io.ReadCloser) {
				err := Body.Close()
				if err != nil {
					t.Fatal("failed to close response body")
				}
			}(resp.Body)
			buf := bytes.NewBuffer(nil)
			_, err = buf.ReadFrom(resp.Body)
			if err != nil {
				t.Fatal("failed to read response body")
			}
			if !strings.Contains(buf.String(), "error decoding client certificate header as base64") {
				t.Fatalf("bad body: %s", buf.String())
			}
			if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
				t.Fatal("client certificate header should not have been set")
			}
		})
	}

	t.Run("valid_base64", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatal("mismatched client certificate response")
		}
	})

	t.Run("valid_rfc9440", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"RFC9440"}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", ":"+clientCertBase64+":")
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatal("mismatched client certificate response")
		}
	})

	invalidRfc9440Values := []struct {
		name  string
		value string
	}{
		{"no_first_colon", clientCertBase64 + ":"},
		{"no_last_colon", ":" + clientCertBase64},
		{"no_colons", clientCertBase64},
	}

	for _, testItem := range invalidRfc9440Values {
		testName := fmt.Sprintf("invalid_rfc9440_%s", testItem.name)
		t.Run(testName, func(t *testing.T) {
			t.Parallel()
			testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"RFC9440"}))
			cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
				HandlerFunc: HandlerFunc(testHandler),
			})
			cluster.Start()
			defer cluster.Cleanup()
			client := cluster.Cores[0].Client
			req := client.NewRequest("GET", "/")
			req.Headers = make(http.Header)
			req.Headers.Add("X-Forwarded-For-Client-Cert", testItem.value)
			resp, err := client.RawRequest(req)
			if err == nil {
				t.Fatal("expected error")
			}
			defer func(Body io.ReadCloser) {
				err := Body.Close()
				if err != nil {
					t.Fatal("failed to close response body")
				}
			}(resp.Body)
			buf := bytes.NewBuffer(nil)
			_, err = buf.ReadFrom(resp.Body)
			if err != nil {
				t.Fatal("failed to read response body")
			}
			if !strings.Contains(buf.String(), "error decoding RFC9440 client certificate header") {
				t.Fatalf("bad body: %s", buf.String())
			}
			if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
				t.Fatal("client certificate header should not have been set")
			}
		})
	}

	// This will not work due to https://www.rfc-editor.org/rfc/rfc9110.html#section-5.5-5
	t.Run("nginx_ssl_client_cert_multiline", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"PEM"}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		// NGINX Prepends a tab before every line except the first
		// https://nginx.org/en/docs/http/ngx_http_ssl_module.html#var_ssl_client_cert
		// This is deprecated
		clientCertPemTextHeader := strings.ReplaceAll(clientCertPemText, "\n", "\r\n\t")
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertPemTextHeader)
		_, err := client.RawRequest(req)
		if err == nil {
			t.Fatal("expected error")
		}
		if !strings.Contains(err.Error(), "net/http: invalid header field value for \"X-Forwarded-For-Client-Cert\"") {
			t.Fatalf("bad error: %s", err)
		}
	})

	// https://nginx.org/en/docs/http/ngx_http_ssl_module.html#var_ssl_client_escaped_cert
	t.Run("nginx_ssl_client_escaped_cert", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"URL", "PEM"}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)

		// NGINX urlencodes the certificate
		req.Headers.Add("X-Forwarded-For-Client-Cert", url.QueryEscape(clientCertPemText))
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatal("mismatched client certificate response")
		}
	})

	t.Run("invalid_pem_header", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"URL", "PEM"}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		invalidPem := strings.ReplaceAll(clientCertPemText, "CERTIFICATE", "INVALID")
		req.Headers.Add("X-Forwarded-For-Client-Cert", url.QueryEscape(invalidPem))
		resp, err := client.RawRequest(req)
		if err == nil {
			t.Fatal("expected error")
		}
		defer func(Body io.ReadCloser) {
			err := Body.Close()
			if err != nil {
				t.Fatal("failed to close response body")
			}
		}(resp.Body)
		buf := bytes.NewBuffer(nil)
		_, err = buf.ReadFrom(resp.Body)
		if err != nil {
			t.Fatal("failed to read response body")
		}
		if !strings.Contains(buf.String(), "failed to decode PEM certificate") {
			t.Fatalf("bad body: %s", buf.String())
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatal("client certificate header should not have been set")
		}
	})

	t.Run("invalid_escaped_cert", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"URL", "PEM"}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		urlencodedCert := url.QueryEscape(clientCertPemText)
		// Encode with invalid hex
		urlencodedCert += "%GG"
		req.Headers.Add("X-Forwarded-For-Client-Cert", urlencodedCert)
		resp, err := client.RawRequest(req)
		if err == nil {
			t.Fatal("expected error")
		}
		defer func(Body io.ReadCloser) {
			err := Body.Close()
			if err != nil {
				t.Fatal("failed to close response body")
			}
		}(resp.Body)
		buf := bytes.NewBuffer(nil)
		_, err = buf.ReadFrom(resp.Body)
		if err != nil {
			t.Fatal("failed to read response body")
		}
		if !strings.Contains(buf.String(), "error url decoding client certificate header") {
			t.Fatalf("bad body: %s", buf.String())
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatal("client certificate header should not have been set")
		}
	})

	t.Run("no_header", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatal("client certificate header should not have been set")
		}
	})

	t.Run("inject_processed_header", func(t *testing.T) {
		t.Parallel()
		testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{}))
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		// Intentionally use the wrong canonical name.
		req.Headers.Add("X-Processed-TLS-Client-Certificate", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		defer func(Body io.ReadCloser) {
			err := Body.Close()
			if err != nil {
				t.Fatal("failed to close response body")
			}
		}(resp.Body)
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatal("client certificate header should not have been set")
		}
	})

	t.Run("inject_processed_header_no_handler", func(t *testing.T) {
		testHandler := getCertTestHandler(&configutil.Listener{})
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		// Intentionally use the wrong canonical name.
		req.Headers.Add("X-Processed-TLS-Client-Certificate", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		defer func(Body io.ReadCloser) {
			err := Body.Close()
			if err != nil {
				t.Fatal("failed to close response body")
			}
		}(resp.Body)
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatal("client certificate header should not have been set")
		}
	})

	t.Run("non_canonical_header_name", func(t *testing.T) {
		// Test to make sure everything works even if the user provides a non-canonical header format.
		t.Parallel()
		listener := getDefaultListenerConfigForClientCerts([]string{})
		// Notice that TLS is in all caps.
		listener.XForwardedForClientCertHeader = "X-TLS-Client-Certificate"
		testHandler := getCertTestHandler(listener)
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-TLS-Client-Certificate", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatal("mismatched client certificate response")
		}
	})

	t.Run("unauthorized_source_addr_remove", func(t *testing.T) {
		t.Parallel()

		// Requests to our test server should never come from Google.
		onlyGoogleDNS, err := parseutil.ParseAddrs("8.8.8.8")
		require.NoError(t, err)

		testHandler := getCertTestHandlerWithForwardedFor(&configutil.Listener{
			XForwardedForClientCertHeader:   "X-Forwarded-For-Client-Cert",
			XForwardedForClientCertDecoders: []string{},
			XForwardedForAuthorizedAddrs:    onlyGoogleDNS,
		})
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertBase64)
		req.Headers.Add("X-Forwarded-For", "1.2.3.4")
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatalf("mismatched client certificate response: got %q; expected empty", resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"))
		}
	})

	t.Run("unauthorized_source_addr_keep", func(t *testing.T) {
		t.Parallel()

		// Requests to our test server should never come from Google.
		onlyGoogleDNS, err := parseutil.ParseAddrs("8.8.8.8")
		require.NoError(t, err)

		testHandler := getCertTestHandlerWithForwardedFor(&configutil.Listener{
			XForwardedForClientCertHeader:           "X-Forwarded-For-Client-Cert",
			XForwardedForClientCertDecoders:         []string{},
			XForwardedForAuthorizedAddrs:            onlyGoogleDNS,
			XForwardedForClientCertKeepUnauthorized: true,
		})
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertBase64)
		req.Headers.Add("X-Forwarded-For", "1.2.3.4")
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatalf("mismatched client certificate response: got %q; expected %q", resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"), clientCertBase64)
		}
	})

	t.Run("not_forwarded_remove", func(t *testing.T) {
		t.Parallel()

		// Requests to our test server should never come from Google.
		onlyGoogleDNS, err := parseutil.ParseAddrs("8.8.8.8")
		require.NoError(t, err)

		testHandler := getCertTestHandlerWithForwardedFor(&configutil.Listener{
			XForwardedForClientCertHeader:   "X-Forwarded-For-Client-Cert",
			XForwardedForClientCertDecoders: []string{},
			XForwardedForAuthorizedAddrs:    onlyGoogleDNS,
		})
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != "" {
			t.Fatalf("mismatched client certificate response: got %q; expected empty", resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"))
		}
	})

	t.Run("not_forwarded_keep", func(t *testing.T) {
		t.Parallel()

		// Requests to our test server should never come from Google.
		onlyGoogleDNS, err := parseutil.ParseAddrs("8.8.8.8")
		require.NoError(t, err)

		testHandler := getCertTestHandlerWithForwardedFor(&configutil.Listener{
			XForwardedForClientCertHeader:           "X-Forwarded-For-Client-Cert",
			XForwardedForClientCertDecoders:         []string{},
			XForwardedForAuthorizedAddrs:            onlyGoogleDNS,
			XForwardedForClientCertKeepNotForwarded: true,
		})
		cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
			HandlerFunc: HandlerFunc(testHandler),
		})
		cluster.Start()
		defer cluster.Cleanup()
		client := cluster.Cores[0].Client
		req := client.NewRequest("GET", "/")
		req.Headers = make(http.Header)
		req.Headers.Add("X-Forwarded-For-Client-Cert", clientCertBase64)
		resp, err := client.RawRequest(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("bad status: %d", resp.StatusCode)
		}
		if resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp") != clientCertBase64 {
			t.Fatalf("mismatched client certificate response: got %q; expected %q", resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"), clientCertBase64)
		}
	})

	validXfccValues := []struct {
		testName    string
		headerValue string
	}{
		{"valid_envoy_xfcc_cert", "Hash=abc123;Cert=\"" + url.QueryEscape(clientCertPemText) + "\""},
		{"valid_envoy_xfcc_chain", "Hash=abc123;Chain=\"" + url.QueryEscape(clientCertPemText+"\n"+clientCertPemText) + "\";URI=http://example.com/client"},
		{"valid_envoy_xfcc_multiple_elements", "Hash=abc123;Cert=\"" + url.QueryEscape(clientCertPemText) + "\",Hash=def456;Cert=\"" + url.QueryEscape(clientCertPemText) + "\""},
		{"valid_envoy_xfcc_subject_with_quoted_delimiters", "Subject=\"CN=client,O=example\";Cert=\"" + url.QueryEscape(clientCertPemText) + "\""},
		{"valid_envoy_xfcc_subject_with_escaped_quote", "Subject=\"CN=John \\\"Jack\\\" Doe\";Cert=\"" + url.QueryEscape(clientCertPemText) + "\""},
		{"valid_envoy_xfcc_cert_and_chain", "Hash=abc123;Cert=\"" + url.QueryEscape(otherCertPemText) + "\";Chain=\"" + url.QueryEscape(clientCertPemText+"\n"+clientCertPemText) + "\""}, // Test that Chain is preferred over Cert when both are present.
	}

	for _, testItem := range validXfccValues {
		t.Run(testItem.testName, func(t *testing.T) {
			t.Parallel()
			testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"Envoy", "PEM"}))
			cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
				HandlerFunc: HandlerFunc(testHandler),
			})
			cluster.Start()
			defer cluster.Cleanup()
			client := cluster.Cores[0].Client
			req := client.NewRequest("GET", "/")
			req.Headers = make(http.Header)
			req.Headers.Add("X-Forwarded-For-Client-Cert", testItem.headerValue)
			resp, err := client.RawRequest(req)
			require.NoError(t, err)
			defer resp.Body.Close() //nolint:errcheck
			require.Equal(t, http.StatusOK, resp.StatusCode, "bad status %d", resp.StatusCode)
			require.Equal(t, clientCertBase64, resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"), "mismatched client certificate response")
		})
	}

	invalidXfccValues := []struct {
		testName    string
		headerValue string
		errorBody   string
	}{
		{"invalid_envoy_xfcc_element", "InvalidElement", "neither Cert nor Chain key found in XFCC header"},
		{"invalid_envoy_xfcc_escaping", "Hash=abc123;Cert=\"%invalid\"", "invalid URL escape"},
		{"invalid_envoy_xfcc_unbalanced_quotes", "Hash=abc123;Cert=\"unbalanced", "neither Cert nor Chain key found in XFCC header"},
	}

	for _, testItem := range invalidXfccValues {
		t.Run(testItem.testName, func(t *testing.T) {
			t.Parallel()
			testHandler := getCertTestHandler(getDefaultListenerConfigForClientCerts([]string{"Envoy", "PEM"}))
			cluster := vault.NewTestCluster(t, nil, &vault.TestClusterOptions{
				HandlerFunc: HandlerFunc(testHandler),
			})
			cluster.Start()
			defer cluster.Cleanup()
			client := cluster.Cores[0].Client
			req := client.NewRequest("GET", "/")
			req.Headers = make(http.Header)
			req.Headers.Add("X-Forwarded-For-Client-Cert", testItem.headerValue)
			resp, err := client.RawRequest(req)
			require.Error(t, err)
			defer resp.Body.Close() //nolint:errcheck
			buf := bytes.NewBuffer(nil)
			_, err = buf.ReadFrom(resp.Body)
			require.NoError(t, err, "failed to read response body")
			require.Equal(t, http.StatusBadRequest, resp.StatusCode, "bad status %d", resp.StatusCode)
			require.Contains(t, buf.String(), testItem.errorBody, "bad body: %s", buf.String())
			require.Empty(t, resp.Header.Get("X-Processed-Tls-Client-Certificate-Resp"), "client certificate header should not have been set")
		})
	}
}
