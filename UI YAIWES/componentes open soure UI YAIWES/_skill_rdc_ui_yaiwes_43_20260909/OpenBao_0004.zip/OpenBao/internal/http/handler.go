// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package http

import (
	"bytes"
	"context"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"maps"
	"mime"
	"net"
	"net/http"
	"net/http/pprof"
	"net/textproto"
	"net/url"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/hashicorp/errwrap"
	"github.com/hashicorp/go-cleanhttp"
	"github.com/hashicorp/go-secure-stdlib/parseutil"
	"github.com/hashicorp/go-sockaddr"
	"github.com/hashicorp/go-uuid"
	gziphandler "github.com/klauspost/compress/gzhttp"
	"github.com/openbao/openbao/sdk/v2/helper/consts"
	"github.com/openbao/openbao/sdk/v2/helper/jsonutil"
	"github.com/openbao/openbao/sdk/v2/helper/pathmanager"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/v2/internal/helper/configutil"
	"github.com/openbao/openbao/v2/internal/helper/listenerutil"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
	"github.com/openbao/openbao/v2/internal/vault"
)

const (
	// DefaultMaxRequestSize is the default maximum accepted request size. This
	// is to prevent a denial of service attack where no Content-Length is
	// provided and the server is fed ever more data until it exhausts memory.
	// Can be overridden per listener.
	DefaultMaxRequestSize = 32 * 1024 * 1024

	// ProcessedForwardedClientCertHeader is an internal-only header used for
	// passing the leaf certificate to the logical layer from the http handler
	// layer, when forwarded by a client.
	ProcessedForwardedClientCertHeader = "X-Processed-Tls-Client-Certificate"

	// RFC 9440 standardizes proposed headers for use with proxies. We trim
	// these to avoid a confusion attack.
	RFC9440ClientCertHeader  = "Client-Cert"
	RFC9440ClientChainHeader = "Client-Chain"
)

var (
	// Set to false by stub_asset if the ui build tag isn't enabled
	uiBuiltIn = true

	alwaysRedirectPaths = pathmanager.New()

	// restrictedSysAPIsNonLogical is the set of `sys/` APIs available only in the root namespace
	// that may not pass through logical request handling but are handled in HTTP using specialized
	// calls to core. This is a subset of `vault.restrictedSysAPIs`.
	restrictedSysAPIsNonLogical = pathmanager.New()

	injectDataIntoTopRoutes = []string{
		"/v1/sys/audit",
		"/v1/sys/audit/",
		"/v1/sys/audit-hash/",
		"/v1/sys/auth",
		"/v1/sys/auth/",
		"/v1/sys/config/cors",
		"/v1/sys/config/auditing/request-headers/",
		"/v1/sys/config/auditing/request-headers",
		"/v1/sys/capabilities",
		"/v1/sys/capabilities-accessor",
		"/v1/sys/capabilities-self",
		"/v1/sys/ha-status",
		"/v1/sys/key-status",
		"/v1/sys/mounts",
		"/v1/sys/mounts/",
		"/v1/sys/policy",
		"/v1/sys/policy/",
		"/v1/sys/rekey/backup",
		"/v1/sys/rekey/recovery-key-backup",
		"/v1/sys/rotate/root/backup",
		"/v1/sys/rotate/recovery/backup",
		"/v1/sys/remount",
		"/v1/sys/rotate",
		"/v1/sys/rotate/keyring",
		"/v1/sys/wrapping/wrap",
	}

	oidcProtectedPathRegex = regexp.MustCompile(`^identity/oidc/provider/\w(([\w-.]+)?\w)?/userinfo$`)
)

func init() {
	alwaysRedirectPaths.AddPaths([]string{
		"sys/storage/raft/snapshot",
		"sys/storage/raft/snapshot-force",
	})

	restrictedSysAPIsNonLogical.AddPaths([]string{
		"raw",
		"generate-recovery-token",
		"init",
		"seal",
		"step-down",
		"unseal",
		"health",
		"rekey-recovery-key",
		"rekey",
		"storage",
		"generate-root",
		"metrics",
		"pprof",
		"in-flight-req",
	})
}

type HandlerAnchor struct{}

func (h HandlerAnchor) Handler(props *vault.HandlerProperties) http.Handler {
	return handler(props)
}

var Handler vault.HandlerHandler = HandlerAnchor{}

type HandlerFunc func(props *vault.HandlerProperties) http.Handler

func (h HandlerFunc) Handler(props *vault.HandlerProperties) http.Handler {
	return h(props)
}

var _ vault.HandlerHandler = HandlerFunc(func(props *vault.HandlerProperties) http.Handler { return nil })

// handler returns an http.Handler for the API. This can be used on
// its own to mount the Vault API within another web server.
func handler(props *vault.HandlerProperties) http.Handler {
	core := props.Core

	// Create the muxer to handle the actual endpoints
	mux := http.NewServeMux()

	switch {
	case props.RecoveryMode:
		raw := vault.NewRawBackend(core)
		strategy := vault.GenerateRecoveryTokenStrategy(props.RecoveryToken)
		mux.Handle("/v1/sys/raw/", handleLogicalRecovery(raw, props.RecoveryToken))
		mux.Handle("/v1/sys/generate-recovery-token/attempt", handleSysGenerateRootAttempt(core, strategy))
		mux.Handle("/v1/sys/generate-recovery-token/update", handleSysGenerateRootUpdate(core, strategy))
	default:
		// Handle non-forwarded paths
		mux.Handle("/v1/sys/config/state/", handleLogicalNoForward(core))
		mux.Handle("/v1/sys/host-info", handleLogicalNoForward(core))

		mux.Handle("/v1/sys/init", handleSysInit(core))
		mux.Handle("/v1/sys/seal-status", handleSysSealStatus(core))
		mux.Handle("/v1/sys/seal", handleSysSeal(core))
		mux.Handle("/v1/sys/step-down", handleForwardIfStandby(core, handleSysStepDown(core)))
		mux.Handle("/v1/sys/unseal", handleSysUnseal(core))
		mux.Handle("/v1/sys/leader", handleSysLeader(core))
		mux.Handle("/v1/sys/health", handleSysHealth(core))
		mux.Handle("/v1/sys/monitor", handleLogicalNoForward(core))

		// Register without unauthenticated generate root, if necessary.
		if props.ListenerConfig != nil && props.ListenerConfig.DisableUnauthedGenerateRootEndpoints != nil && !*props.ListenerConfig.DisableUnauthedGenerateRootEndpoints {
			mux.Handle("/v1/sys/generate-root/attempt",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysGenerateRootAttempt(core, vault.GenerateStandardRootTokenStrategy))))
			mux.Handle("/v1/sys/generate-root/update",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysGenerateRootUpdate(core, vault.GenerateStandardRootTokenStrategy))))
		}

		// Register without unauthenticated rekey, if necessary.
		if props.ListenerConfig != nil && props.ListenerConfig.DisableUnauthedRekeyEndpoints != nil && !*props.ListenerConfig.DisableUnauthedRekeyEndpoints {
			mux.Handle("/v1/sys/rekey/init",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyInit(core, false))))
			mux.Handle("/v1/sys/rekey/update",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyUpdate(core, false))))
			mux.Handle("/v1/sys/rekey/verify",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyVerify(core, false))))
			mux.Handle("/v1/sys/rekey-recovery-key/init",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyInit(core, true))))
			mux.Handle("/v1/sys/rekey-recovery-key/update",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyUpdate(core, true))))
			mux.Handle("/v1/sys/rekey-recovery-key/verify",
				handleForwardIfStandby(core, handleAuditNonLogical(core, handleSysRekeyVerify(core, true))))
		}

		mux.Handle("/v1/sys/storage/raft/bootstrap", handleSysRaftBootstrap(core))
		mux.Handle("/v1/sys/storage/raft/join", handleSysRaftJoin(core))

		for _, path := range injectDataIntoTopRoutes {
			mux.Handle(path, handleLogicalWithInjector(core))
		}
		mux.Handle("/v1/sys/", handleLogical(core))
		mux.Handle("/v1/", handleLogical(core))
		if core.UIEnabled() {
			if uiBuiltIn {
				mux.Handle("/ui/", http.StripPrefix("/ui/", gziphandler.GzipHandler(handleUIHeaders(core, handleUI(http.FileServer(&UIAssetWrapper{FileSystem: assetFS()}))))))
				mux.Handle("/robots.txt", gziphandler.GzipHandler(handleUIHeaders(core, handleUI(http.FileServer(&UIAssetWrapper{FileSystem: assetFS()})))))
			} else {
				mux.Handle("/ui/", handleUIHeaders(core, handleUIStub()))
			}
			mux.Handle("/ui", handleUIRedirect())
			mux.Handle("/", handleUIRedirect())

		}

		// Register metrics path without authentication if enabled
		if props.ListenerConfig != nil && props.ListenerConfig.Telemetry.UnauthenticatedMetricsAccess {
			mux.Handle("/v1/sys/metrics", handleMetricsUnauthenticated(core))
		} else {
			mux.Handle("/v1/sys/metrics", handleLogicalNoForward(core))
		}

		if props.ListenerConfig != nil && props.ListenerConfig.Profiling.UnauthenticatedPProfAccess {
			for _, name := range []string{"goroutine", "threadcreate", "heap", "allocs", "block", "mutex"} {
				mux.Handle("/v1/sys/pprof/"+name, pprof.Handler(name))
			}
			mux.Handle("/v1/sys/pprof/", http.HandlerFunc(pprof.Index))
			mux.Handle("/v1/sys/pprof/cmdline", http.HandlerFunc(pprof.Cmdline))
			mux.Handle("/v1/sys/pprof/profile", http.HandlerFunc(pprof.Profile))
			mux.Handle("/v1/sys/pprof/symbol", http.HandlerFunc(pprof.Symbol))
			mux.Handle("/v1/sys/pprof/trace", http.HandlerFunc(pprof.Trace))
		} else {
			mux.Handle("/v1/sys/pprof/", handleLogicalNoForward(core))
		}

		if props.ListenerConfig != nil && props.ListenerConfig.InFlightRequestLogging.UnauthenticatedInFlightAccess {
			mux.Handle("/v1/sys/in-flight-req", handleUnAuthenticatedInFlightRequest(core))
		} else {
			mux.Handle("/v1/sys/in-flight-req", handleLogicalNoForward(core))
		}
		additionalRoutes(mux, core)
	}

	// Wrap the handler in another handler to trigger all help paths.
	indexForwardHandler := wrapIndexForwardHandler(mux, core, props)
	helpWrappedHandler := wrapHelpHandler(indexForwardHandler, core)
	clientCertHandler := wrapClientCertificateHandler(helpWrappedHandler, props)
	corsWrappedHandler := wrapCORSHandler(clientCertHandler, core)
	quotaWrappedHandler := rateLimitQuotaWrapping(corsWrappedHandler, core)
	genericWrappedHandler := genericWrapping(core, quotaWrappedHandler, props)
	metricsWrappedHandler := wrapMetricsListenerHandler(genericWrappedHandler, props)
	wrappedHandler := wrapMaxRequestSizeHandler(metricsWrappedHandler, props)
	// Wrap the handler with PrintablePathCheckHandler to check for non-printable
	// characters in the request path.
	printablePathCheckHandler := wrappedHandler
	if !props.DisablePrintableCheck {
		printablePathCheckHandler = cleanhttp.PrintablePathCheckHandler(wrappedHandler, nil)
	}

	return printablePathCheckHandler
}

type copyResponseWriter struct {
	wrapped    http.ResponseWriter
	statusCode int
	body       *bytes.Buffer
}

// newCopyResponseWriter returns an initialized newCopyResponseWriter
func newCopyResponseWriter(wrapped http.ResponseWriter) *copyResponseWriter {
	w := &copyResponseWriter{
		wrapped:    wrapped,
		body:       new(bytes.Buffer),
		statusCode: 200,
	}
	return w
}

func (w *copyResponseWriter) Header() http.Header {
	return w.wrapped.Header()
}

func (w *copyResponseWriter) Write(buf []byte) (int, error) {
	w.body.Write(buf)
	return w.wrapped.Write(buf)
}

func (w *copyResponseWriter) WriteHeader(code int) {
	w.statusCode = code
	w.wrapped.WriteHeader(code)
}

func handleAuditNonLogical(core *vault.Core, h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		req, status, err := buildLogicalRequestNoAuth(w, r)
		if err != nil || status != 0 {
			respondError(w, status, err)
			return
		}
		input := &logical.LogInput{
			Request: req,
		}
		ctx := namespace.RootContext(r.Context())
		err = core.AuditLogger().AuditRequest(ctx, input)
		if err != nil {
			respondError(w, status, err)
			return
		}
		cw := newCopyResponseWriter(w)
		h.ServeHTTP(cw, r)
		data := make(map[string]any)
		// best effort, ignore error
		_ = jsonutil.DecodeJSON(cw.body.Bytes(), &data)
		httpResp := &logical.HTTPResponse{Data: data, Headers: cw.Header()}
		input.Response = logical.HTTPResponseToLogicalResponse(httpResp)
		err = core.AuditLogger().AuditResponse(ctx, input)
		if err != nil {
			respondError(w, status, err)
		}
	})
}

// wrapGenericHandler wraps the handler with an extra layer of handler where
// tasks that should be commonly handled for all the requests and/or responses
// are performed.
func wrapGenericHandler(core *vault.Core, h http.Handler, props *vault.HandlerProperties) http.Handler {
	var maxRequestDuration time.Duration
	var maxRequestJsonMemory int64
	var maxRequestJsonStrings int64
	if props.ListenerConfig != nil {
		maxRequestDuration = props.ListenerConfig.MaxRequestDuration
		maxRequestJsonMemory = props.ListenerConfig.MaxRequestJsonMemory
		maxRequestJsonStrings = props.ListenerConfig.MaxRequestJsonStrings
	}
	if maxRequestDuration == 0 {
		maxRequestDuration = vault.DefaultMaxRequestDuration
	}
	if maxRequestJsonMemory == 0 {
		maxRequestJsonMemory = vault.DefaultMaxJsonMemory
	}
	if maxRequestJsonStrings == 0 {
		maxRequestJsonStrings = vault.DefaultMaxJsonStrings
	}

	// Swallow this error since we don't want to pollute the logs and we also don't want to
	// return an HTTP error here. This information is best effort.
	hostname, _ := os.Hostname()

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// This block needs to be here so that upon sending SIGHUP, custom response
		// headers are also reloaded into the handlers.
		var customHeaders map[string][]*logical.CustomHeader
		if props.ListenerConfig != nil {
			la := props.ListenerConfig.Address
			listenerCustomHeaders := core.GetListenerCustomResponseHeaders(la)
			if listenerCustomHeaders != nil {
				customHeaders = listenerCustomHeaders.StatusCodeHeaderMap
			}
		}
		// saving start time for the in-flight requests
		inFlightReqStartTime := time.Now()

		nw := logical.NewStatusHeaderResponseWriter(w, customHeaders)

		// Set the Cache-Control header for all the responses returned
		// by Vault
		nw.Header().Set("Cache-Control", "no-store")

		// Start with the request context
		ctx := r.Context()
		var cancelFunc context.CancelFunc
		// Add our timeout, but not for the monitor or events endpoints, as they are streaming
		if strings.HasSuffix(r.URL.Path, "sys/monitor") || strings.Contains(r.URL.Path, "sys/events") {
			ctx, cancelFunc = context.WithCancel(ctx)
		} else {
			ctx, cancelFunc = context.WithTimeout(ctx, maxRequestDuration)
		}
		ctx = vault.ContextWithOriginalRequestPath(ctx, r.URL.Path)

		nsHeader := r.Header.Get(consts.NamespaceHeaderName)
		if nsHeader != "" {
			// Setting the namespace in the header to be included in the response
			nw.Header().Set(consts.NamespaceHeaderName, nsHeader)
		}

		// Safely limit our input JSON
		ctx = addMaximumJsonMemoryToContext(ctx, maxRequestJsonMemory)
		ctx = addMaximumJsonStringsToContext(ctx, maxRequestJsonStrings)

		ctx = namespace.ContextWithNamespaceHeader(ctx, nsHeader)
		r = r.WithContext(ctx)

		// Set some response headers with raft node id (if applicable) and hostname, if available
		if core.RaftNodeIDHeaderEnabled() {
			nodeID := core.GetRaftNodeID()
			if nodeID != "" {
				nw.Header().Set(consts.RaftNodeIDHeaderName, nodeID)
			}
		}

		if core.HostnameHeaderEnabled() && hostname != "" {
			nw.Header().Set(consts.HostnameHeaderName, hostname)
		}

		isRestrictedSysAPI := nsHeader != "" && strings.HasPrefix(r.URL.Path, "/v1/sys/") &&
			restrictedSysAPIsNonLogical.HasPathSegments(r.URL.Path[len("/v1/sys/"):])

		switch {
		case isRestrictedSysAPI:
			respondError(nw, http.StatusBadRequest, fmt.Errorf("operation unavailable in namespaces"))
			cancelFunc()
			return

		case strings.HasPrefix(r.URL.Path, "/v1/"), strings.HasPrefix(r.URL.Path, "/ui"), r.URL.Path == "/robots.txt", r.URL.Path == "/":
		case strings.HasPrefix(r.URL.Path, "/.well-known/acme-challenge/"):
			for _, ln := range props.AllListeners {
				if ln.Config == nil || ln.Config.TLSDisable {
					continue
				}

				if acg, ok := ln.Config.TLSCertGetter.(*listenerutil.ACMECertGetter); ok {
					if acg.HandleHTTPChallenge(w, r) {
						cancelFunc()
						return
					}
				}
			}
		default:
			respondError(nw, http.StatusNotFound, nil)
			cancelFunc()
			return
		}

		// The uuid for the request is going to be generated when a logical
		// request is generated. But, here we generate one to be able to track
		// in-flight requests, and use that to update the req data with clientID
		inFlightReqID, err := uuid.GenerateUUID()
		if err != nil {
			respondError(nw, http.StatusInternalServerError, errors.New("failed to generate an identifier for the in-flight request"))
		}
		// adding an entry to the context to enable updating in-flight
		// data with ClientID in the logical layer
		r = r.WithContext(context.WithValue(r.Context(), logical.CtxKeyInFlightRequestID{}, inFlightReqID))

		// extracting the client address to be included in the in-flight request
		var clientAddr string
		headers := r.Header[textproto.CanonicalMIMEHeaderKey("X-Forwarded-For")]
		if len(headers) == 0 {
			clientAddr = r.RemoteAddr
		} else {
			clientAddr = headers[0]
		}

		// getting the request method
		requestMethod := r.Method

		// Storing the in-flight requests. Path should include namespace as well
		core.StoreInFlightReqData(
			inFlightReqID,
			vault.InFlightReqData{
				StartTime:        inFlightReqStartTime,
				ReqPath:          r.URL.Path,
				ClientRemoteAddr: clientAddr,
				Method:           requestMethod,
			},
		)
		defer func() {
			// Not expecting this fail, so skipping the assertion check
			core.FinalizeInFlightReqData(inFlightReqID, nw.StatusCode)
		}()

		h.ServeHTTP(nw, r)

		cancelFunc()
	})
}

func WrapHttpServerHandler(h http.Handler, l *configutil.Listener) http.Handler {
	if l == nil {
		return h
	}

	if len(l.XForwardedForAuthorizedAddrs) > 0 {
		h = wrapForwardedForHandler(h, l)
	}

	return h
}

func wrapForwardedForHandler(h http.Handler, l *configutil.Listener) http.Handler {
	rejectNotPresent := l.XForwardedForRejectNotPresent
	hopSkips := l.XForwardedForHopSkips
	authorizedAddrs := l.XForwardedForAuthorizedAddrs
	rejectNotAuthz := l.XForwardedForRejectNotAuthorized
	keepUnauthorizedCertHeaders := l.XForwardedForClientCertKeepUnauthorized
	keepNotForwardedCertHeaders := l.XForwardedForClientCertKeepNotForwarded
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		headers, headersOK := r.Header[textproto.CanonicalMIMEHeaderKey("X-Forwarded-For")]
		if !headersOK || len(headers) == 0 {
			if !rejectNotPresent {
				if !keepNotForwardedCertHeaders {
					// This request is not from a forwarding system, so we should
					// remove any forwarded leaf certificate headers. Even Unix
					// sockets should attach this information for us.
					if len(l.XForwardedForClientCertHeader) > 0 {
						r.Header.Del(l.XForwardedForClientCertHeader)
					}
					r.Header.Del(RFC9440ClientCertHeader)
					r.Header.Del(RFC9440ClientChainHeader)
				}
				h.ServeHTTP(w, r)
				return
			}
			respondError(w, http.StatusBadRequest, errors.New("missing x-forwarded-for header and configured to reject when not present"))
			return
		}

		host, port, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil {
			// If not rejecting treat it like we just don't have a valid
			// header because we can't do a comparison against an address we
			// can't understand
			if !rejectNotPresent {
				h.ServeHTTP(w, r)
				return
			}
			respondError(w, http.StatusBadRequest, fmt.Errorf("error parsing client hostport: %w", err))
			return
		}

		addr, err := sockaddr.NewIPAddr(host)
		if err != nil {
			// We treat this the same as the case above
			if !rejectNotPresent {
				h.ServeHTTP(w, r)
				return
			}
			respondError(w, http.StatusBadRequest, fmt.Errorf("error parsing client address: %w", err))
			return
		}

		var found bool
		for _, authz := range authorizedAddrs {
			if authz.Contains(addr) {
				found = true
				break
			}
		}
		if !found {
			// If we didn't find it and aren't configured to reject, simply
			// don't trust it
			if !rejectNotAuthz {
				// We need to delete the X-Forwarded-For header before
				// passing it along, otherwise downstream systems will not
				// know whether or not to trust it.
				//
				// This is true of the forwarded certificate headers as well.
				r.Header.Del(textproto.CanonicalMIMEHeaderKey("X-Forwarded-For"))

				if !keepUnauthorizedCertHeaders {
					if len(l.XForwardedForClientCertHeader) > 0 {
						r.Header.Del(l.XForwardedForClientCertHeader)
					}
					r.Header.Del(RFC9440ClientCertHeader)
					r.Header.Del(RFC9440ClientChainHeader)
				}

				// Now serve the request, having rejected the header.
				h.ServeHTTP(w, r)
				return
			}

			respondError(w, http.StatusBadRequest, errors.New("client address not authorized for x-forwarded-for and configured to reject connection"))
			return
		}

		// At this point we have at least one value and it's authorized

		// Split comma separated ones, which are common. This brings it in line
		// to the multiple-header case.
		var acc []string
		for _, header := range headers {
			vals := strings.SplitSeq(header, ",")
			for v := range vals {
				acc = append(acc, strings.TrimSpace(v))
			}
		}

		indexToUse := int64(len(acc)) - 1 - hopSkips
		if indexToUse < 0 {
			// This is likely an error in either configuration or other
			// infrastructure. We could either deny the request, or we
			// could simply not trust the value. Denying the request is
			// "safer" since if this logic is configured at all there may
			// be an assumption it can always be trusted. Given that we can
			// deny accepting the request at all if it's not from an
			// authorized address, if we're at this point the address is
			// authorized (or we've turned off explicit rejection) and we
			// should assume that what comes in should be properly
			// formatted.
			respondError(w, http.StatusBadRequest, fmt.Errorf("malformed x-forwarded-for configuration or request, hops to skip (%d) would skip before earliest chain link (chain length %d)", hopSkips, len(headers)))
			return
		}

		r.RemoteAddr = net.JoinHostPort(acc[indexToUse], port)
		h.ServeHTTP(w, r)
	})
}

func wrapClientCertificateHandler(h http.Handler, props *vault.HandlerProperties) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Strip any X-Processed-Tls-Client-Certificate headers before
		// processing.
		r.Header.Del(ProcessedForwardedClientCertHeader)

		var clientCertificateHeaderName string
		var decoders []string
		if props != nil && props.ListenerConfig != nil {
			clientCertificateHeaderName = props.ListenerConfig.XForwardedForClientCertHeader
			decoders = props.ListenerConfig.XForwardedForClientCertDecoders
		}

		if len(clientCertificateHeaderName) == 0 {
			// Nothing to do; listener configuration does not set the
			// x_forwarded_for_client_cert_header option so we should
			// continue on.
			//
			// Remove the standardized client cert headers for safety,
			// even though we don't explicitly process them; they'd be
			// untrusted.
			r.Header.Del(RFC9440ClientCertHeader)
			r.Header.Del(RFC9440ClientChainHeader)

			h.ServeHTTP(w, r)
			return
		}

		// Short circuit if no client cert header value.
		clientCertHeaderValues := r.Header.Values(clientCertificateHeaderName)
		if len(clientCertHeaderValues) == 0 || len(clientCertHeaderValues[0]) == 0 {
			h.ServeHTTP(w, r)
			return
		}

		// Do not handle multiple certs. If there are multiple certificates,
		// throw an error for non-compliant behavior.
		//
		// This is out of scope and if a proxy is following RFC 9440, the chain
		// excluding the end entity would be a separate header.
		//
		// For now, we ignore the chain and assume the cert auth operator can
		// configure their auth mount with additional intermediates if
		// required.
		if len(clientCertHeaderValues) > 1 {
			respondError(w, http.StatusBadRequest, errors.New("too many values for client certificate header; check RFC 9440 and do not send chain"))
			return
		}

		// Different servers have different ways of encoding the certificate.
		headerValue := clientCertHeaderValues[0]
		for _, decoder := range decoders {
			var err error

			// This list must be kept in sync with the listener
			// configuration parser.
			switch decoder {
			case "RFC9440":
				headerValue, err = rfc9440DecodeHeader(headerValue)
			case "URL":
				headerValue, err = urlDecodeHeader(headerValue)
			case "PEM":
				headerValue, err = pemDecodeHeader(headerValue)
			case "Envoy":
				headerValue, err = envoyDecodeHeader(headerValue)
			default:
				respondError(w, http.StatusInternalServerError, errors.New("bad server configuration for forwarded certificate parsing; unknown parser"))
				return
			}

			if err != nil {
				respondError(w, http.StatusBadRequest, err)
				return
			}
		}

		// Validate that the processed cert is valid StdEncoding base64
		certDer, err := base64.StdEncoding.DecodeString(headerValue)
		if err != nil {
			respondError(w, http.StatusBadRequest, errors.New("error decoding client certificate header as base64"))
			return
		}

		// Validate that the processed certificate is a valid certificate.
		_, err = x509.ParseCertificate(certDer)
		if err != nil {
			respondError(w, http.StatusBadRequest, errors.New("error decoding client certificate header as x509.Certificate"))
			return
		}

		// Add the client cert header.
		r.Header.Add(ProcessedForwardedClientCertHeader, headerValue)

		// Delete the unprocessed header.
		r.Header.Del(clientCertificateHeaderName)

		// Remove the standardized client cert headers for safety,
		// even though we don't explicitly process them; they'd be
		// untrusted.
		r.Header.Del(RFC9440ClientCertHeader)
		r.Header.Del(RFC9440ClientChainHeader)

		// Call our next handler.
		h.ServeHTTP(w, r)
	})
}

func handleUIHeaders(core *vault.Core, h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		header := w.Header()

		userHeaders, err := core.UIHeaders()
		if err != nil {
			respondError(w, http.StatusInternalServerError, err)
			return
		}
		for k := range userHeaders {
			v := userHeaders.Get(k)
			header.Set(k, v)
		}
		h.ServeHTTP(w, req)
	})
}

func handleUI(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		// The fileserver handler strips trailing slashes and does a redirect.
		// We don't want the redirect to happen so we preemptively trim the slash
		// here.
		req.URL.Path = strings.TrimSuffix(req.URL.Path, "/")
		h.ServeHTTP(w, req)
	})
}

func handleUIStub() http.Handler {
	stubHTML := `
	<!DOCTYPE html>
	<html>
	<style>
	body {
	color: #1F2124;
	font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
	}

	.wrapper {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 500px;
	}

	.content ul {
	line-height: 1.5;
	}

	a {
	color: #1563ff;
	text-decoration: none;
	}

	.header {
	display: flex;
	color: #6a7786;
	align-items: center;
	}

	.header svg {
	padding-right: 12px;
	}

	.alert {
	transform: scale(0.07);
	fill: #6a7786;
	}

	h1 {
	font-weight: 500;
	}

	p {
	margin-top: 0px;
	}
	</style>
	<div class="wrapper">
	<div class="content">
	<div class="header">
	<svg width="36px" height="36px" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
	<path class="alert" d="M476.7 422.2L270.1 72.7c-2.9-5-8.3-8.7-14.1-8.7-5.9 0-11.3 3.7-14.1 8.7L35.3 422.2c-2.8 5-4.8 13-1.9 17.9 2.9 4.9 8.2 7.9 14 7.9h417.1c5.8 0 11.1-3 14-7.9 3-4.9 1-13-1.8-17.9zM288 400h-64v-48h64v48zm0-80h-64V176h64v144z"/>
	</svg>
	<h1>OpenBao UI is not available in this binary.</h1>
	</div>
	<p>To get the beta OpenBao UI do the following:</p>
	<ul>
	<li>Run <code>make dev-ui</code> to create a development binary with the UI.
	</ul>
	<p>Contributions to help improve the <a href="https://openbao.org/">OpenBao</a> UI are welcome!</p>
	</div>
	</div>
	</html>
	`
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		w.Write([]byte(stubHTML))
	})
}

func handleUIRedirect() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		http.Redirect(w, req, "/ui/", http.StatusTemporaryRedirect)
	})
}

type UIAssetWrapper struct {
	FileSystem http.FileSystem
}

func (fsw *UIAssetWrapper) Open(name string) (http.File, error) {
	file, err := fsw.FileSystem.Open(name)
	if err == nil {
		return file, nil
	}
	// serve index.html instead of 404ing
	if errors.Is(err, fs.ErrNotExist) {
		file, err := fsw.FileSystem.Open("index.html")
		return file, err
	}
	return nil, err
}

func parseQuery(values url.Values) map[string]any {
	data := map[string]any{}
	for k, v := range values {
		// Skip the help key as this is a reserved parameter
		if k == "help" {
			continue
		}

		switch {
		case len(v) == 0:
		case len(v) == 1:
			data[k] = v[0]
		default:
			data[k] = v
		}
	}

	if len(data) > 0 {
		return data
	}
	return nil
}

// parseFormRequest parses values from a form POST.
//
// A nil map will be returned if the format is empty or invalid.
func parseFormRequest(r *http.Request) (map[string]any, error) {
	if err := r.ParseForm(); err != nil {
		return nil, err
	}

	var data map[string]any

	if len(r.PostForm) != 0 {
		data = make(map[string]any, len(r.PostForm))
		for k, v := range r.PostForm {
			switch len(v) {
			case 0:
			case 1:
				data[k] = v[0]
			default:
				// Almost anywhere taking in a string list can take in comma
				// separated values, and really this is super niche anyways
				data[k] = strings.Join(v, ",")
			}
		}
	}

	return data, nil
}

func forwardRequest(core *vault.Core, w http.ResponseWriter, r *http.Request) {
	// Reset our body before forwarding to ensure an accurate location.
	if err := resetBody(r); err != nil {
		respondStandby(core, w, r.URL)
		return
	}

	if r.Header.Get(vault.IntNoForwardingHeaderName) != "" {
		respondStandby(core, w, r.URL)
		return
	}

	_, leaderAddr, _, err := core.Leader()
	if err != nil {
		// Some internal error occurred
		respondError(w, http.StatusInternalServerError, err)
		return
	}
	if leaderAddr == "" {
		respondError(w, http.StatusInternalServerError, errors.New("local node not active but active cluster node not found"))
		return
	}

	if r.Header.Get(consts.NoRequestForwardingHeaderName) != "" {
		// Forwarding explicitly disabled, fall back to previous behavior
		core.Logger().Debug("forwardRequest: forwarding disabled by client request")
		respondStandby(core, w, r.URL)
		return
	}

	if alwaysRedirectPaths.HasPath(r.URL.Path[len("/v1/"):]) {
		respondStandby(core, w, r.URL)
		return
	}

	// Attempt forwarding the request. If we cannot forward -- perhaps it's
	// been disabled on the active node -- this will return with an
	// ErrCannotForward and we simply fall back
	statusCode, header, retBytes, err := core.ForwardRequest(r)
	if err != nil {
		if err == vault.ErrCannotForward {
			core.Logger().Debug("cannot forward request (possibly disabled on active node), falling back")
		} else {
			core.Logger().Error("forward request error", "error", err)
		}

		// Fall back to redirection
		respondStandby(core, w, r.URL)
		return
	}

	maps.Copy(w.Header(), header)

	w.WriteHeader(statusCode)
	w.Write(retBytes)
}

// request is a helper to perform a request and properly exit in the
// case of an error.
func request(core *vault.Core, w http.ResponseWriter, rawReq *http.Request, r *logical.Request) (*logical.Response, bool, bool) {
	resp, err := core.HandleRequest(rawReq.Context(), r)

	if logical.ShouldForward(err) || (resp != nil && logical.ShouldForward(resp.Error())) {
		return nil, false, true
	}

	if resp != nil && len(resp.Headers) > 0 {
		// Set this here so it will take effect regardless of any other type of
		// response processing
		header := w.Header()
		for k, v := range resp.Headers {
			for _, h := range v {
				header.Add(k, h)
			}
		}

		switch {
		case resp.Secret != nil,
			resp.Auth != nil,
			len(resp.Data) > 0,
			resp.Redirect != "",
			len(resp.Warnings) > 0,
			resp.WrapInfo != nil:
			// Nothing, resp has data

		default:
			// We have an otherwise totally empty response except for headers,
			// so nil out the response now that the headers are written out
			resp = nil
		}
	}

	// If vault's core has already written to the response writer do not add any
	// additional output. Headers have already been sent. If the response writer
	// is set but has not been written to it likely means there was some kind of
	// error
	if r.ResponseWriter != nil && r.ResponseWriter.Written() {
		return nil, true, false
	}

	if respondErrorCommon(w, r, resp, err) {
		return resp, false, false
	}

	return resp, true, false
}

// respondStandby is used to trigger a redirect in the case that this Vault is currently a hot standby
func respondStandby(core *vault.Core, w http.ResponseWriter, reqURL *url.URL) {
	// Request the leader address
	_, redirectAddr, _, err := core.Leader()
	if err != nil {
		if err == vault.ErrHANotEnabled {
			// Standalone node, serve 503
			err = errors.New("node is not active")
			respondError(w, http.StatusServiceUnavailable, err)
			return
		}

		respondError(w, http.StatusInternalServerError, err)
		return
	}

	// If there is no leader, generate a 503 error
	if redirectAddr == "" {
		err = errors.New("no active Vault instance found")
		respondError(w, http.StatusServiceUnavailable, err)
		return
	}

	// Parse the redirect location
	redirectURL, err := url.Parse(redirectAddr)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err)
		return
	}

	// Generate a redirect URL
	finalURL := url.URL{
		Scheme:   redirectURL.Scheme,
		Host:     redirectURL.Host,
		Path:     reqURL.Path,
		RawQuery: reqURL.RawQuery,
	}

	// Ensure there is a scheme, default to https
	if finalURL.Scheme == "" {
		finalURL.Scheme = "https"
	}

	// If we have an address, redirect! We use a 307 code
	// because we don't actually know if its permanent and
	// the request method should be preserved.
	w.Header().Set("Location", finalURL.String())
	w.WriteHeader(http.StatusTemporaryRedirect)
}

// getTokenFromReq parse headers of the incoming request to extract token if
// present it accepts Authorization Bearer (RFC6750) and X-Vault-Token header.
// Returns true if the token was sourced from a Bearer header.
func getTokenFromReq(r *http.Request) (string, bool) {
	if token := r.Header.Get(consts.AuthHeaderName); token != "" {
		return token, false
	}
	if headers, ok := r.Header["Authorization"]; ok {
		// Reference for Authorization header format: https://tools.ietf.org/html/rfc7236#section-3

		// If string does not start by 'Bearer ', it is not one we would use,
		// but might be used by plugins
		for _, v := range headers {
			if !strings.HasPrefix(v, "Bearer ") {
				continue
			}
			return strings.TrimSpace(v[7:]), true
		}
	}
	return "", false
}

// requestAuth adds the token to the logical.Request if it exists.
func requestAuth(r *http.Request, req *logical.Request) {
	// Attach the header value if we have it
	token, fromAuthzHeader := getTokenFromReq(r)
	if token != "" {
		req.ClientToken = token
		req.ClientTokenSource = logical.ClientTokenFromVaultHeader
		if fromAuthzHeader {
			req.ClientTokenSource = logical.ClientTokenFromAuthzHeader
		}

	}
}

// requestWrapInfo adds the WrapInfo value to the logical.Request if wrap info exists
func requestWrapInfo(r *http.Request, req *logical.Request) (*logical.Request, error) {
	// First try for the header value
	wrapTTL := r.Header.Get(consts.WrapTTLHeaderName)
	if wrapTTL == "" {
		return req, nil
	}

	// If it has an allowed suffix parse as a duration string
	dur, err := parseutil.ParseDurationSecond(wrapTTL)
	if err != nil {
		return req, err
	}
	if int64(dur) < 0 {
		return req, errors.New("requested wrap ttl cannot be negative")
	}

	req.WrapInfo = &logical.RequestWrapInfo{
		TTL: dur,
	}

	wrapFormat := r.Header.Get(consts.WrapFormatHeaderName)
	switch wrapFormat {
	case "jwt":
		req.WrapInfo.Format = "jwt"
	}

	return req, nil
}

// isForm tries to determine whether the request should be
// processed as a form or as JSON.
//
// Virtually all existing use cases have assumed processing as JSON,
// and there has not been a Content-Type requirement in the API. In order to
// maintain backwards compatibility, this will err on the side of JSON.
// The request will be considered a form only if:
//
//  1. The content type is "application/x-www-form-urlencoded"
//  2. The start of the request doesn't look like JSON. For this test we
//     we expect the body to begin with { or [, ignoring leading whitespace.
func isForm(head []byte, contentType string) bool {
	contentType, _, err := mime.ParseMediaType(contentType)

	if err != nil || contentType != "application/x-www-form-urlencoded" {
		return false
	}

	// Look for the start of JSON or not-JSON, skipping any insignificant
	// whitespace (per https://tools.ietf.org/html/rfc7159#section-2).
	for _, c := range head {
		switch c {
		case ' ', '\t', '\n', '\r':
			continue
		case '[', '{': // JSON
			return false
		default: // not JSON
			return true
		}
	}

	return true
}

func respondError(w http.ResponseWriter, status int, err error) {
	logical.RespondError(w, status, err)
}

func respondErrorAndData(w http.ResponseWriter, status int, data any, err error) {
	logical.RespondErrorAndData(w, status, data, err)
}

func respondErrorCommon(w http.ResponseWriter, req *logical.Request, resp *logical.Response, err error) bool {
	statusCode, newErr := logical.RespondErrorCommon(req, resp, err)
	if newErr == nil && statusCode == 0 {
		return false
	}

	// If ErrPermissionDenied occurs for OIDC protected resources (e.g., userinfo),
	// then respond with a JSON error format that complies with the specification.
	// This prevents the JSON error format from changing to a Vault-y format (i.e.,
	// the format that results from respondError) after an OIDC access token expires.
	if oidcPermissionDenied(req.Path, err) {
		respondOIDCPermissionDenied(w)
		return true
	}

	if resp != nil {
		if data := resp.Data["data"]; data != nil {
			respondErrorAndData(w, statusCode, data, newErr)
			return true
		}
	}
	respondError(w, statusCode, newErr)
	return true
}

func respondOk(w http.ResponseWriter, body any) {
	w.Header().Set("Content-Type", "application/json")

	if body == nil {
		w.WriteHeader(http.StatusNoContent)
	} else {
		w.WriteHeader(http.StatusOK)
		enc := json.NewEncoder(w)
		enc.Encode(body)
	}
}

// oidcPermissionDenied returns true if the given path matches the
// UserInfo Endpoint published by Vault OIDC providers and the given
// error is a logical.ErrPermissionDenied.
func oidcPermissionDenied(path string, err error) bool {
	return errwrap.Contains(err, logical.ErrPermissionDenied.Error()) &&
		oidcProtectedPathRegex.MatchString(path)
}

// respondOIDCPermissionDenied writes a response to the given w for
// permission denied errors (expired token) on resources protected
// by OIDC access tokens. Currently, the UserInfo Endpoint is the only
// protected resource. See the following specifications for details:
//   - https://openid.net/specs/openid-connect-core-1_0.html#UserInfoError
//   - https://datatracker.ietf.org/doc/html/rfc6750#section-3.1
func respondOIDCPermissionDenied(w http.ResponseWriter) {
	errorCode := "invalid_token"
	errorDescription := logical.ErrPermissionDenied.Error()

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("WWW-Authenticate", fmt.Sprintf("Bearer error=%q,error_description=%q",
		errorCode, errorDescription))
	w.WriteHeader(http.StatusUnauthorized)

	var oidcResponse struct {
		Error            string `json:"error"`
		ErrorDescription string `json:"error_description"`
	}
	oidcResponse.Error = errorCode
	oidcResponse.ErrorDescription = errorDescription

	enc := json.NewEncoder(w)
	enc.Encode(oidcResponse)
}

func handleForwardIfStandby(core *vault.Core, handler http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if core.HAEnabled() && core.Standby() {
			forwardRequest(core, w, r)
		} else {
			handler.ServeHTTP(w, r)
		}
	})
}
