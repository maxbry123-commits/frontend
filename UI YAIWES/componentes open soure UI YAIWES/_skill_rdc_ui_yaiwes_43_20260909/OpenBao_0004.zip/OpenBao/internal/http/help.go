// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package http

import (
	"errors"
	"fmt"
	"net/http"
	"strings"

	"github.com/hashicorp/go-uuid"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/v2/internal/vault"
)

func wrapHelpHandler(h http.Handler, core *vault.Core) http.Handler {
	return http.HandlerFunc(func(writer http.ResponseWriter, req *http.Request) {
		// If the help parameter is not blank, then show the help.
		if v := req.URL.Query().Get("help"); v != "" || req.Method == "HELP" {
			http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				handleHelp(core, w, r)
			}).ServeHTTP(writer, req)
			return
		}

		h.ServeHTTP(writer, req)
	})
}

func handleHelp(core *vault.Core, w http.ResponseWriter, r *http.Request) {
	if !strings.HasPrefix(r.URL.Path, "/v1/") {
		//nolint:staticcheck // User facing error
		respondError(w, http.StatusNotFound, errors.New("Missing /v1/ prefix in path. Use the bao path-help command to retrieve API help for paths"))
		return
	}

	if core.HAEnabled() && core.Standby() && !core.StandbyReadsEnabled() {
		forwardRequest(core, w, r)
		return
	}

	requestId, err := uuid.GenerateUUID()
	if err != nil {
		respondError(w, http.StatusInternalServerError, fmt.Errorf("failed to generate identifier for the request: %w", err))
		return
	}

	req := &logical.Request{
		ID:         requestId,
		Operation:  logical.HelpOperation,
		Path:       r.URL.Path[len("/v1/"):],
		Connection: getConnection(r),
	}
	requestAuth(r, req)

	resp, err := core.HandleRequest(r.Context(), req)
	if err != nil {
		respondErrorCommon(w, req, resp, err)
		return
	}

	respondOk(w, resp.Data)
}
