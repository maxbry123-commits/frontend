// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package http

import (
	"encoding/json"
	"reflect"
	"testing"

	"github.com/go-test/deep"
	"github.com/openbao/openbao/v2/internal/vault"
)

func TestSysPolicies(t *testing.T) {
	core, _, token := vault.TestCoreUnsealed(t)
	ln, addr := TestServer(t, core)
	defer ln.Close()
	TestServerAuth(t, addr, token)

	resp := testHttpGet(t, token, addr+"/v1/sys/policy")

	var actual map[string]any
	expected := map[string]any{
		"lease_id":       "",
		"renewable":      false,
		"lease_duration": json.Number("0"),
		"wrap_info":      nil,
		"warnings":       nil,
		"auth":           nil,
		"data": map[string]any{
			"policies": []any{"default", "root"},
			"keys":     []any{"default", "root"},
		},
		"policies": []any{"default", "root"},
		"keys":     []any{"default", "root"},
	}
	testResponseStatus(t, resp, 200)
	testResponseBody(t, resp, &actual)
	expected["request_id"] = actual["request_id"]
	if !reflect.DeepEqual(actual, expected) {
		t.Fatalf("bad: got\n%#v\nexpected\n%#v\n", actual, expected)
	}
}

func TestSysReadPolicy(t *testing.T) {
	core, _, token := vault.TestCoreUnsealed(t)
	ln, addr := TestServer(t, core)
	defer ln.Close()
	TestServerAuth(t, addr, token)

	resp := testHttpGet(t, token, addr+"/v1/sys/policy/root")

	var actual map[string]any
	expected := map[string]any{
		"lease_id":       "",
		"renewable":      false,
		"lease_duration": json.Number("0"),
		"wrap_info":      nil,
		"warnings":       nil,
		"auth":           nil,
		"data": map[string]any{
			"name":                                  "root",
			"rules":                                 "",
			"cas_required":                          false,
			"version":                               json.Number("0"),
			"allow_slashes_in_identity_templates":   false,
			"allow_wildcards_in_identity_templates": false,
		},
		"name":                                  "root",
		"rules":                                 "",
		"cas_required":                          false,
		"version":                               json.Number("0"),
		"allow_slashes_in_identity_templates":   false,
		"allow_wildcards_in_identity_templates": false,
	}
	testResponseStatus(t, resp, 200)
	testResponseBody(t, resp, &actual)
	expected["request_id"] = actual["request_id"]
	if diff := deep.Equal(actual, expected); diff != nil {
		t.Fatalf("bad: got\n%#v\nexpected\n%#v\ndiff: %v\n", actual, expected, diff)
	}
}

func TestSysWritePolicy(t *testing.T) {
	core, _, token := vault.TestCoreUnsealed(t)
	ln, addr := TestServer(t, core)
	defer ln.Close()
	TestServerAuth(t, addr, token)

	resp := testHttpPost(t, token, addr+"/v1/sys/policy/foo", map[string]any{
		"rules": `path "*" { capabilities = ["read"] }`,
	})
	testResponseStatus(t, resp, 200)

	resp = testHttpGet(t, token, addr+"/v1/sys/policy")

	var actual map[string]any
	expected := map[string]any{
		"lease_id":       "",
		"renewable":      false,
		"lease_duration": json.Number("0"),
		"wrap_info":      nil,
		"warnings":       nil,
		"auth":           nil,
		"data": map[string]any{
			"policies": []any{"default", "foo", "root"},
			"keys":     []any{"default", "foo", "root"},
		},
		"policies": []any{"default", "foo", "root"},
		"keys":     []any{"default", "foo", "root"},
	}
	testResponseStatus(t, resp, 200)
	testResponseBody(t, resp, &actual)
	expected["request_id"] = actual["request_id"]
	if !reflect.DeepEqual(actual, expected) {
		t.Fatalf("bad: got\n%#v\nexpected\n%#v\n", actual, expected)
	}

	resp = testHttpPost(t, token, addr+"/v1/sys/policy/response-wrapping", map[string]any{
		"rules": ``,
	})
	testResponseStatus(t, resp, 400)
}

func TestSysDeletePolicy(t *testing.T) {
	core, _, token := vault.TestCoreUnsealed(t)
	ln, addr := TestServer(t, core)
	defer ln.Close()
	TestServerAuth(t, addr, token)

	resp := testHttpPost(t, token, addr+"/v1/sys/policy/foo", map[string]any{
		"rules": `path "*" { capabilities = ["read"] }`,
	})
	testResponseStatus(t, resp, 200)

	resp = testHttpDelete(t, token, addr+"/v1/sys/policy/foo")
	testResponseStatus(t, resp, 204)

	// Also attempt to delete these since they should not be allowed (ignore
	// responses, if they exist later that's sufficient)
	testHttpDelete(t, token, addr+"/v1/sys/policy/default")
	testHttpDelete(t, token, addr+"/v1/sys/policy/response-wrapping")

	resp = testHttpGet(t, token, addr+"/v1/sys/policy")

	var actual map[string]any
	expected := map[string]any{
		"lease_id":       "",
		"renewable":      false,
		"lease_duration": json.Number("0"),
		"wrap_info":      nil,
		"warnings":       nil,
		"auth":           nil,
		"data": map[string]any{
			"policies": []any{"default", "root"},
			"keys":     []any{"default", "root"},
		},
		"policies": []any{"default", "root"},
		"keys":     []any{"default", "root"},
	}
	testResponseStatus(t, resp, 200)
	testResponseBody(t, resp, &actual)
	expected["request_id"] = actual["request_id"]
	if !reflect.DeepEqual(actual, expected) {
		t.Fatalf("bad: got\n%#v\nexpected\n%#v\n", actual, expected)
	}
}
