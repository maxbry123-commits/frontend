// Copyright (c) 2025 OpenBao a Series of LF Projects, LLC
// SPDX-License-Identifier: MPL-2.0

package vault

import (
	"context"
	"fmt"
	"maps"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	log "github.com/hashicorp/go-hclog"
	metrics "github.com/hashicorp/go-metrics/compat"
	"github.com/openbao/openbao/sdk/v2/physical"
	"github.com/openbao/openbao/v2/internal/helper/fairshare"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
	"github.com/openbao/openbao/v2/internal/vault/barrier"
	ek "github.com/openbao/openbao/v2/internal/vault/external_keys"
	"github.com/openbao/openbao/v2/internal/vault/policy"
	"github.com/openbao/openbao/v2/internal/vault/quotas"
)

const (
	dispatcherName          = "invalidate-dispatch"
	refresherName           = "invalidate-cache-refresh"
	maxLockTime             = 2 * time.Second
	maxInvalidateTime       = 30 * time.Second
	maxPluginInvalidateTime = 2 * time.Second
	maxDispatchers          = 128
)

func (c *Core) Invalidate(index string, key ...string) {
	c.invalidations.Add(index, key...)
}

func (c *Core) invalidateSynchronous(key string) error {
	job, _ := c.invalidations.buildInvalidateJobForKey(make(chan struct{}), context.Background(), "", key)

	if err := job.Execute(); err != nil {
		job.OnFailure(err)
		return err
	}

	return nil
}

type pendingEntry struct {
	index string
	key   string
}

// invalidationManager is a long-lived subset of Core which is used to handle
// storage-level invalidations.
type invalidationManager struct {
	core *Core

	// Invalidate stages pending invalidations into this queue.
	pendingLock   sync.Mutex
	accepting     atomic.Bool
	pending       []pendingEntry
	outstanding   map[string]map[string]struct{}
	pendingNotify chan struct{}

	// quitCh notifies that we should stop actively processing invalidations.
	//
	// We'll still keep appending to pending, though, assuming accepting=true
	quitCh      chan struct{}
	quitContext context.Context
	doneCh      chan struct{}

	// dispatcher handles processing events from the invalidation queue to
	// subsystems. This is handled separately so that the storage layer
	// doesn't need to make asynchronous calls to the hook, while allowing
	// actual invalidation processing to take longer.
	dispacherLogger log.Logger
	dispatcher      *fairshare.JobManager
}

func (core *Core) NewInvalidationManager() {
	core.invalidations = &invalidationManager{
		core:            core,
		dispacherLogger: core.logger.Named(dispatcherName),

		pendingNotify: make(chan struct{}),
		outstanding:   map[string]map[string]struct{}{},
	}
}

func (im *invalidationManager) Track() {
	if im.accepting.Load() {
		return
	}

	// Clear any leftover remaining items if we're changing state.
	im.pendingLock.Lock()
	defer im.pendingLock.Unlock()

	// Revalidate that we should clear the queue, holding the lock.
	if im.accepting.Load() {
		return
	}

	im.pending = nil
	im.outstanding = map[string]map[string]struct{}{}
	im.accepting.Store(true)
}

func (im *invalidationManager) Start(ctx context.Context) {
	im.dispatcher = fairshare.NewJobManager(dispatcherName, maxDispatchers, im.dispacherLogger, im.core.metricSink)
	im.dispatcher.Start()

	im.quitCh = make(chan struct{})
	im.quitContext = ctx
	im.doneCh = make(chan struct{})

	// Now that we've started, start processing pending invalidations until
	// told to stop.
	go im.processPendingQueue(im.quitCh, im.quitContext, im.doneCh)
}

func (im *invalidationManager) Stop() {
	im.dispacherLogger.Debug("stop triggered")
	defer im.dispacherLogger.Debug("finished stopping")

	// Prevent enqueuing more items.
	im.accepting.Store(false)

	// Close the quit channel to cancel any yet-to-be-dispatched.
	if im.quitCh != nil {
		close(im.quitCh)
	}

	// Stop processing the ones we have.
	if im.dispatcher != nil {
		im.dispatcher.Stop()
	}

	// Wait for the processing queue to finish.
	if im.doneCh != nil {
		timeout := time.NewTimer(maxInvalidateTime)
		select {
		case <-timeout.C:
			im.dispacherLogger.Warn("failed to stop processing queue")
		case <-im.doneCh:
		}

		if !timeout.Stop() {
			<-timeout.C
		}
	}

	// Clear any remaining items.
	im.pendingLock.Lock()
	im.pending = nil
	im.outstanding = map[string]map[string]struct{}{}
	im.pendingLock.Unlock()

	// Clear any start-specific state.
	im.quitCh = nil
	im.quitContext = nil
	im.dispatcher = nil
	im.doneCh = nil
}

func (im *invalidationManager) processPendingQueue(quitCh chan struct{}, quitContext context.Context, doneCh chan struct{}) {
	go func() {
		defer close(doneCh)
		for {
			select {
			case <-quitCh:
				im.dispacherLogger.Debug("shutting down; skipping pending queue processing")
				return
			case <-quitContext.Done():
				im.dispacherLogger.Debug("core context canceled, skipping pending queue processing")
				return
			case <-im.pendingNotify:
			}

			func() {
				defer metrics.MeasureSince([]string{dispatcherName, "enqueue-pending"}, time.Now())

				im.pendingLock.Lock()
				pending := im.pending
				im.pending = nil
				im.pendingLock.Unlock()

				im.core.metricSink.SetGauge([]string{dispatcherName, "pending-dequeue-size"}, float32(len(pending)))

				for _, item := range pending {
					job, queue := im.buildInvalidateJobForKey(quitCh, quitContext, item.index, item.key)
					im.dispatcher.AddJob(job, queue)
				}
			}()
		}
	}()
}

func (im *invalidationManager) buildInvalidateJobForKey(quitCh chan struct{}, quitContext context.Context, index string, key string) (fairshare.Job, string) {
	// Fairshare ensures we don't starve other queues too long. We need to
	// balance some things here:
	//
	// 1. Total memory consumption.
	// 2. Not starving any one namespace based on the work of others.
	// 3. Prioritizing Core tasks over others.
	//
	// Thus if a change comes into the root namespace's core/, it'll be
	// dispatched on its own queue by key, but all other work in the root
	// namespace or child namespaces will be in their own queues (minus,
	// again, a namespace's core, which will now share a queue).
	//
	// This balances the total number of queues (in most _reasonable_ systems),
	// while allowing prioritization of core updates and prioritizing root
	// updates most of all.
	ns, subkey := im.splitNamespaceFromKey(key)

	queue := ns

	isCore := strings.HasPrefix(subkey, "core/")
	isNamespaceStore := isCore && strings.HasPrefix(subkey, namespaceStoreSubPath)

	switch {
	case isNamespaceStore:
		// Namespaces are laid out in a dense tree, so ordering is important.
		// Send all namespace store updates to the same queue.
		queue = "namespaces"
	case queue == namespace.RootNamespaceUUID && isCore:
		queue = key
	case isCore:
		queue += "-core"
	}

	return &invalidationJob{
		quitCh:      quitCh,
		quitContext: quitContext,
		im:          im,
		index:       index,
		key:         key,
		nsUUID:      ns,
		nsKey:       subkey,
	}, queue
}

type invalidationJob struct {
	quitCh      chan struct{}
	quitContext context.Context

	im *invalidationManager

	index string

	// key is the full path of the entry being updated, including
	// `namespace/<uuid>/` prefix if applicable.
	key    string
	nsUUID string

	// nsKey is the path within the namespace.
	nsKey string

	fatal bool
}

func isLegacyMountPath(key string) bool {
	return key == coreMountConfigPath ||
		key == coreLocalMountConfigPath ||
		key == coreAuthConfigPath ||
		key == coreLocalAuthConfigPath
}

func isTransactionalMountPath(key string) bool {
	return strings.HasPrefix(key, coreMountConfigPath+"/") ||
		strings.HasPrefix(key, coreLocalMountConfigPath+"/") ||
		strings.HasPrefix(key, coreAuthConfigPath+"/") ||
		strings.HasPrefix(key, coreLocalAuthConfigPath+"/")
}

func isCoreKeyPath(key string) bool {
	return key == barrierSealConfigPath ||
		key == barrier.KeyringPath ||
		key == barrier.LegacyRootKeyPath ||
		key == recoverySealConfigPath ||
		key == recoveryKeyPath ||
		key == barrier.RootKeyPath ||
		key == barrier.ShamirKekPath ||
		key == StoredBarrierKeysPath ||
		key == raftTLSStoragePath
}

func isMissedMountKey(key string) bool {
	return strings.HasPrefix(key, barrier.CredentialBarrierPrefix) ||
		strings.HasPrefix(key, backendBarrierPrefix) ||
		strings.HasPrefix(key, auditBarrierPrefix)
}

func isLoginMFA(key string) bool {
	return strings.HasPrefix(key, barrier.SystemBarrierPrefix+loginMFAConfigPrefix) ||
		strings.HasPrefix(key, barrier.SystemBarrierPrefix+mfaLoginEnforcementPrefix)
}

func (ij *invalidationJob) Execute() error {
	ij.im.dispacherLogger.Trace("processing invalidation", "key", ij.key, "index", ij.index)
	defer ij.im.dispacherLogger.Trace("concluding processing of invalidation", "key", ij.key, "index", ij.index)

	defer metrics.MeasureSince([]string{dispatcherName, "execute-invalidate"}, time.Now())
	ij.im.core.metricSink.IncrCounterWithLabels([]string{dispatcherName, "pending-dequeue-size"}, 1.0, nil)

	// Exit early if we're shut down before we get a chance to execute.
	select {
	case <-ij.quitCh:
		ij.im.dispacherLogger.Debug("shutting down; skipping job", "key", ij.key)
		return nil
	case <-ij.quitContext.Done():
		ij.im.dispacherLogger.Debug("core context canceled, skipping job", "key", ij.key)
		return nil
	default:
	}

	// Remove this job from the outstanding list.
	if ij.index != "" {
		defer func() {
			go func() {
				ij.im.pendingLock.Lock()
				defer ij.im.pendingLock.Unlock()

				indexMap, ok := ij.im.outstanding[ij.index]
				if !ok {
					return
				}

				if _, present := indexMap[ij.key]; !present {
					return
				}

				delete(indexMap, ij.key)
				if len(indexMap) == 0 {
					delete(ij.im.outstanding, ij.index)
				}
			}()
		}()
	}

	if ij.im.core.Sealed() {
		ij.im.dispacherLogger.Trace("refusing to process event when core is sealed", "key", ij.key)
		return nil
	}

	// State lock acquisition is usually very fast: we have many potential
	// readers of it and it only gets exclusively locked when HA status
	// changes, in which case, we're likely to restart our own state anyways.
	lockCtx, lockCancel := context.WithTimeout(ij.quitContext, maxLockTime)
	defer lockCancel()

	// Acquire state lock. We're running in a goroutine; while active context
	// should be sufficient to prevent races here, we want to ensure no core
	// state changes during processing of the request. We bind this to our
	// time-limited channel to ensure it processes in a reasonable amount of
	// time.
	l := newLockGrabber(ij.im.core.stateLock.RLock, ij.im.core.stateLock.RUnlock, lockCtx.Done())
	go l.grab()

	if stopped := l.lockOrStop(); stopped {
		// Failure to grab a lock is never fatal: HA state change will mean
		// that we'll restart the invalidation manager anyways.
		ij.im.dispacherLogger.Trace("unable to acquire read statelock", "key", ij.key, "context", ij.quitContext.Err())
		return nil
	}

	defer ij.im.core.stateLock.RUnlock()

	// Any storage operations we dispatch here should be time-bounded and
	// context refreshed.
	ctx, cancel := context.WithTimeout(ij.quitContext, maxInvalidateTime)
	defer cancel()

	// Always refresh physical cache for operations performed during
	// invalidation.
	ctx = physical.CacheRefreshContext(ctx, true)

	// Notify physical cache that our entry is stale if it is cached. This
	// ensures parallel reads see up-to-date data now that we're processing
	// invalidations.
	ij.im.core.physicalCache.Invalidate(ctx, ij.key)

	// Get a full namespace entry; it may be out of date since when the job
	// started and we need it for routing.
	//
	// Note that we never need to invalidate the namespace store here, before
	// we fetch this: namespace invalidation happens when the entry for the
	// child namespace is updated in the parent namespace, invalidating the
	// child. But the namespace UUID we have here is of the parent, which
	// (while it might be stale), cannot yet be invalidated as a separate
	// invalidation would occur for that. The exception of course is the root
	// namespace which is a virtual, storage-less namespace.
	ns, err := ij.im.core.namespaceStore.GetNamespace(ctx, ij.nsUUID)
	if err != nil {
		ij.fatal = true
		return fmt.Errorf("failed to load namespace %q from store: %w", ij.nsUUID, err)
	}
	if ns == nil || ns.Tainted {
		// Namespace was deleted or created (or is in process of being
		// deleted/created); this is safe to ignore, because it occurs in one of
		// two scenarios:
		//
		// 1. The namespace was deleted already (invalidation on
		//    core/namespaces/<uuid> was processed first) and we're getting an
		//    invalidation for a child entry.
		// 2. The namespace has just been created (and the
		//    core/namespaces/<uuid> key was not yet invalidated) and we're
		//    getting an invalidation for the child entry.
		//
		// We will also receive a subsequent invalidation request for the
		// core/namespaces/<uuid> key in both cases, so we are fine to exit
		// silently.
		return nil
	}

	nsBarrier := ij.im.core.sealManager.NamespaceBarrierByLongestPrefix(ns.Path)
	if nsBarrier.Namespace().UUID != namespace.RootNamespaceUUID && nsBarrier.Sealed() {
		// When the parent namespace is sealed, ignore the request: this
		// means we're unable to process the invalidation regardless of
		// what the actual invalidated entry is. Only when this parent
		// namespace becomes unsealed can we process changes to data within
		// it. Notably, the namespace entry for a sealed namespace sits in
		// the namespace above it, so it is not its own parent and thus will
		// be correctly invalidated.
		return nil
	}

	ctx = namespace.ContextWithNamespace(ctx, ns)

	// Lastly, create a short version of the context for plugin invalidations.
	shortCtx, shortCancel := context.WithTimeout(ctx, maxPluginInvalidateTime)
	defer shortCancel()

	// Now handle the actual event.
	switch {
	case strings.HasPrefix(ij.nsKey, namespaceStoreSubPath):
		ij.fatal = true
		return ij.namespaceInvalidation(ctx)
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+policy.ACLSubPath):
		// Policy invalidation is not fatal as it contains a LRU cache: we
		// know removal is strict and it is only potentially preloading an
		// entry which may err.
		return ij.policyInvalidation(ctx)
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+quotas.StoragePrefix):
		ij.fatal = true
		return ij.quotaInvalidation(ctx)
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+ek.KeyStoragePrefix):
		// Nothing to do.
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+ek.ConfigStoragePrefix):
		ij.fatal = true
		return ij.externalKeyInvalidation(ctx)
	case ij.nsKey == coreAuditConfigPath || ij.nsKey == coreLocalAuditConfigPath:
		ij.fatal = true
		return ij.auditInvalidation(ctx)
	case isLegacyMountPath(ij.nsKey):
		ij.fatal = true
		return ij.legacyMountInvalidation(ctx)
	case isTransactionalMountPath(ij.nsKey):
		ij.fatal = true
		return ij.transactionalMountInvalidation(ctx)
	case strings.HasPrefix(ij.nsKey, barrier.KeyringUpgradePrefix):
		ij.fatal = true
		// this is handled via periodicCheckKeyringUpgrades(...)
		// for root namespace while run by read-disabled standby nodes.
		return ij.keyringTermInvalidation(ctx, ns.Path)
	case isCoreKeyPath(ij.nsKey):
		// No need to invalidate these entries.
	case strings.HasPrefix(ij.key, coreLeaderPrefix):
		// The HA subsystem handles leadership changes.
	case strings.HasPrefix(ij.key, pluginCatalogPath):
		// There is nothing to do to invalidate a plugin catalog write.
	case ij.key == CoreLockPath:
		// The lock path isn't really a key that we invalidate; it is a lock
		// file written by some backends which lack an out-of-storage locking
		// mechanism. It is also handled by the HA mechanism and so is safe
		// to ignore.
	case ij.key == coreLocalClusterInfoPath:
		ij.fatal = true
		_, err := ij.im.core.Cluster(ctx)
		return err
	case strings.HasPrefix(ij.key, "autopilot/") || ij.key == raftAutopilotConfigurationStoragePath:
		// Raft context is reloaded when a standby becomes active, so it is
		// safe to ignore changes to autopilot state.
	case isLoginMFA(ij.nsKey):
		ij.fatal = true
		return ij.loginMFAInvalidation(ctx, ns)
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+expirationSubPath):
		// Expiration manager on standby nodes does not cache entries.
	case strings.HasPrefix(ij.nsKey, barrier.SystemBarrierPrefix+tokenSubPath):
		// Token store has salt invalidation, but assumes we're relative to
		// sys/.
		subpath := strings.TrimPrefix(ij.nsKey, barrier.SystemBarrierPrefix)
		ij.im.core.tokenStore.Invalidate(ctx, subpath)
	case strings.HasPrefix(ij.nsKey, mfaTOTPKeysPrefix):
		// MFA TOTP entries are not cached.
	case strings.HasPrefix(ij.nsKey, passwordPolicySubPath):
		// Password policies are not cached.
	case strings.HasPrefix(ij.nsKey, "sys/"):
		// System keys need to be invalidated explicitly because it has no
		// global invalidation router. If we have not handled such a key
		// before it gets to the invalidation trigger below, treat it as
		// fatal and restart.
		ij.im.dispacherLogger.Error("no mechanism to invalidate system cache for specified key", "key", ij.nsKey, "full_key", ij.key)
	case ij.im.core.router.Invalidate(shortCtx, ij.key):
		// if router.Invalidate returns true, a matching plugin was found and
		// the invalidation is therefore dispatched.
	case isMissedMountKey(ij.key):
		// router.Invalidate(...) may return false when a matching plugin was
		// not yet loaded, even though this was under a path we'd expect to
		// be a mount key (auth/, audit/, or logical/) prefix. Ignoring it is
		// fine: a later change to a subsequent entry will actually load the
		// mount, loading any data this entry would've contained for the first
		// time.
		//
		// This is true in reverse for deletions.
	default:
		ij.im.dispacherLogger.Warn("no mechanism to invalidate cache for specified key", "key", ij.nsKey, "full_key", ij.key)
	}

	return nil
}

func (ij *invalidationJob) namespaceInvalidation(ctx context.Context) error {
	// The namespace UUID is the final path segment; ij.nsUUID contains the
	// parent namespace UUID.
	childUUID := strings.TrimPrefix(ij.nsKey, namespaceStoreSubPath)

	// Reload the namespace entry:
	child, deleted, err := ij.im.core.namespaceStore.Invalidate(ctx, ij.nsUUID, childUUID)
	switch {
	case err != nil:
		return err
	case child == nil, ij.im.core.NamespaceSealed(child):
		// Nothing to do.
		return nil
	}

	ctx = namespace.ContextWithNamespace(ctx, child)

	// Invalidate all policies within the namespace.
	ij.im.core.policyStore.InvalidateNamespace(ctx, childUUID)

	// Now reload all mounts within the namespace.
	if err := ij.im.core.reloadNamespaceMounts(ctx, childUUID, deleted); err != nil {
		return fmt.Errorf("unable to invalidate mounts in namespace %q: %w", ij.nsUUID, err)
	}

	return nil
}

func (ij *invalidationJob) policyInvalidation(ctx context.Context) error {
	policyPath := strings.TrimPrefix(ij.nsKey, barrier.SystemBarrierPrefix+policy.ACLSubPath)
	return ij.im.core.policyStore.Invalidate(ctx, policyPath, policy.TypeACL)
}

func (ij *invalidationJob) quotaInvalidation(ctx context.Context) error {
	quotaPath := strings.TrimPrefix(ij.nsKey, barrier.SystemBarrierPrefix+quotas.StoragePrefix)
	return ij.im.core.quotaManager.Invalidate(ctx, quotaPath)
}

func (ij *invalidationJob) externalKeyInvalidation(ctx context.Context) error {
	name := strings.TrimPrefix(ij.nsKey, barrier.SystemBarrierPrefix+ek.ConfigStoragePrefix)
	return ij.im.core.externalKeys.InvalidateConfig(ctx, name)
}

func (ij *invalidationJob) auditInvalidation(ctx context.Context) error {
	if ij.nsUUID != namespace.RootNamespaceUUID {
		ij.im.dispacherLogger.Warn("skipping invalidating audit table in non-root namespace", "ns", ij.nsUUID, "key", ij.nsKey)
		return nil
	}

	return ij.im.core.invalidateAudits(ctx)
}

func (ij *invalidationJob) legacyMountInvalidation(ctx context.Context) error {
	if err := ij.im.core.reloadLegacyMounts(ctx, ij.nsKey); err != nil {
		return fmt.Errorf("unable to invalidate legacy mount for key %q in namespace %q: %w", ij.nsKey, ij.nsUUID, err)
	}

	return nil
}

func (ij *invalidationJob) transactionalMountInvalidation(ctx context.Context) error {
	if err := ij.im.core.reloadMount(ctx, ij.nsKey); err != nil {
		return fmt.Errorf("unable to invalidate mount for key %q in namespace %q: %w", ij.nsKey, ij.nsUUID, err)
	}

	return nil
}

func (ij *invalidationJob) keyringTermInvalidation(ctx context.Context, nsPath string) error {
	b := ij.im.core.sealManager.NamespaceBarrier(nsPath)
	if b == nil {
		return fmt.Errorf("couldn't retrieve barrier for a namespace: %q", nsPath)
	}

	if err := ij.im.core.checkKeyringUpgrade(ctx, b); err != nil {
		return fmt.Errorf("unable to invalidate keyring upgrade entry for key %q in namespace %q: %w", ij.nsKey, ij.nsUUID, err)
	}

	return nil
}

func (ij *invalidationJob) loginMFAInvalidation(ctx context.Context, ns *namespace.Namespace) error {
	if err := ij.im.core.loginMFABackend.invalidate(ctx, ns, ij.nsKey); err != nil {
		return fmt.Errorf("unable to invalidate login MFA config for key %q in namespace %q: %w", ij.nsKey, ij.nsUUID, err)
	}

	return nil
}

func (ij *invalidationJob) OnFailure(err error) {
	// Decide if we need to restart the core.
	if ij.quitContext.Err() != nil {
		return
	}

	if !ij.fatal {
		return
	}

	// This was a fatal failure; dispatch a restart.
	ij.im.dispacherLogger.Error("fatal failure dispatching invalidation; restarting core", "key", ij.key, "err", err)
	ij.im.core.Restart()
}

func (im *invalidationManager) Add(index string, keys ...string) {
	// Skip invalidations if we're not accepting invalidations yet.
	if !im.accepting.Load() {
		return
	}

	// Skip invalidations if we're not the standby. The InmemHA backend in
	// particular dispatches invalidations on every node which isn't
	// necessary as the active is expected to invalidate itself in the course
	// of writing the data.
	if !im.core.standby.Load() {
		return
	}

	// Likewise if we're sealed, ignore the invalidation.
	if im.core.Sealed() {
		return
	}

	// Add the keys.
	im.pendingLock.Lock()
	im.pending = slices.Grow(im.pending, len(keys))
	for _, key := range keys {
		im.pending = append(im.pending, pendingEntry{
			index: index,
			key:   key,
		})

		if index != "" {
			indexMap, ok := im.outstanding[index]
			if !ok {
				indexMap = make(map[string]struct{}, len(keys))
				im.outstanding[index] = indexMap
			}
			indexMap[key] = struct{}{}
		}
	}
	im.pendingLock.Unlock()

	// Notify the processor.
	select {
	case im.pendingNotify <- struct{}{}:
	default:
	}
}

func (im *invalidationManager) splitNamespaceFromKey(key string) (string, string) {
	namespaceUUID := namespace.RootNamespaceUUID
	namespacedKey := key

	if keySuffix, ok := strings.CutPrefix(key, barrier.NamespacePrefix); ok {
		namespaceUUID, namespacedKey, _ = strings.Cut(keySuffix, "/")
	}

	return namespaceUUID, namespacedKey
}

// hasOutstandingInvalidations returns the list of outstanding invalidations.
func (im *invalidationManager) OutstandingInvalidationIndices() []string {
	im.pendingLock.Lock()

	// Create a clone of all outstanding, not-yet-invalidated index values
	// we know about.
	iter := maps.Keys(im.outstanding)
	indices := make([]string, 0, len(im.outstanding))
	for item := range iter {
		indices = append(indices, item)
	}

	im.pendingLock.Unlock()

	return indices
}
