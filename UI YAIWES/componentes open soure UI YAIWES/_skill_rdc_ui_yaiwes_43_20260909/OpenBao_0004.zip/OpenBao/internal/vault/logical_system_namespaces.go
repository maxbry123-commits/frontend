// Copyright (c) 2025 OpenBao a Series of LF Projects, LLC
// SPDX-License-Identifier: MPL-2.0

package vault

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"

	jsonpatch "github.com/evanphx/json-patch/v5"
	"github.com/hashicorp/go-secure-stdlib/parseutil"
	"github.com/openbao/openbao/sdk/v2/framework"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/v2/internal/helper/configutil"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
)

var namespacePathSchema = &framework.FieldSchema{
	Type:        framework.TypeString,
	Required:    false,
	Description: "Path of the namespace.",
}

func (b *SystemBackend) namespacePaths() []*framework.Path {
	namespaceListSchema := map[string]*framework.FieldSchema{
		"keys": {
			Type:        framework.TypeStringSlice,
			Description: "List of namespace paths.",
		},
		"key_info": {
			Type:        framework.TypeMap,
			Description: "Map of namespace details by path.",
		},
	}

	namespaceSchema := map[string]*framework.FieldSchema{
		"uuid": {
			Type:        framework.TypeString,
			Required:    true,
			Description: "Internal UUID of the namespace.",
		},
		"id": {
			Type:        framework.TypeString,
			Required:    true,
			Description: "Accessor ID of the namespace.",
		},
		"path": {
			Type:        framework.TypeString,
			Required:    true,
			Description: "Path of the namespace.",
		},
		"tainted": {
			Type:        framework.TypeBool,
			Required:    true,
			Description: "Flag representing the taint status of the namespace.",
		},
		"locked": {
			Type:        framework.TypeBool,
			Required:    true,
			Description: "Flag representing the lock status of the namespace.",
		},
		"custom_metadata": {
			Type:        framework.TypeMap,
			Required:    true,
			Description: "User provided key-value pairs.",
		},
		"key_shares": {
			Type:        framework.TypeMap,
			Required:    false,
			Description: "Key shares used to combine into unseal/recovery key of the namespace.",
		},
		"key_threshold": {
			Type:        framework.TypeInt,
			Required:    false,
			Description: "Number of keys required to reconstruct unseal/recovery key of the namespace.",
		},
	}

	return []*framework.Path{
		{
			Pattern: "namespaces/?$",

			DisplayAttrs: &framework.DisplayAttributes{
				OperationPrefix: "namespaces",
			},

			Operations: map[logical.Operation]framework.OperationHandler{
				logical.ListOperation: &framework.PathOperation{
					Callback: b.handleNamespacesList(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: namespaceListSchema}},
					},
					Summary: "List namespaces.",
				},
				logical.ScanOperation: &framework.PathOperation{
					Callback: b.handleNamespacesScan(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: namespaceListSchema}},
					},
					Summary: "Scan (recursively list) namespaces.",
				},
			},

			HelpSynopsis:    strings.TrimSpace(sysNamespacesHelp["list-namespaces"][0]),
			HelpDescription: strings.TrimSpace(sysNamespacesHelp["list-namespaces"][1]),
		},

		{
			// should match
			// .../lock
			// .../lock/<path_to_namespace> capturing the "path_to_namespace"
			// but should not match
			// .../lockkk or any malformation of "lock" string
			Pattern: "namespaces/api-lock/lock(?:$|/(?P<path>.+))",

			DisplayAttrs: &framework.DisplayAttributes{
				OperationPrefix: "namespaces",
			},

			Fields: map[string]*framework.FieldSchema{
				"path": namespacePathSchema,
			},

			Operations: map[logical.Operation]framework.OperationHandler{
				logical.UpdateOperation: &framework.PathOperation{
					Callback: b.handleNamespacesLock(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: map[string]*framework.FieldSchema{
							"unlock_key": {
								Type:        framework.TypeString,
								Required:    true,
								Description: "Unlock key required for unlocking the namespace.",
							},
						}}},
					},
					Summary: "Lock a namespace.",
				},
			},

			HelpSynopsis:    strings.TrimSpace(sysNamespacesHelp["namespaces-lock"][0]),
			HelpDescription: strings.TrimSpace(sysNamespacesHelp["namespaces-lock"][1]),
		},

		{
			// should match
			// .../unlock
			// .../unlock/<path_to_namespace> capturing the "path_to_namespace"
			// but should not match
			// .../unlockkk or any malformation of "unlock" string
			Pattern: "namespaces/api-lock/unlock(?:$|/(?P<path>.+))",

			DisplayAttrs: &framework.DisplayAttributes{
				OperationPrefix: "namespaces",
			},

			Fields: map[string]*framework.FieldSchema{
				"path": namespacePathSchema,
				"unlock_key": {
					Type:        framework.TypeString,
					Required:    true,
					Description: "Unlock key required for unlocking the namespace",
				},
			},

			Operations: map[logical.Operation]framework.OperationHandler{
				logical.UpdateOperation: &framework.PathOperation{
					Callback: b.handleNamespacesUnlock(),
					Responses: map[int][]framework.Response{
						http.StatusNoContent: {{Description: "No Content"}},
					},
					Summary: "Unlock a namespace.",
				},
			},

			HelpSynopsis:    strings.TrimSpace(sysNamespacesHelp["namespaces-unlock"][0]),
			HelpDescription: strings.TrimSpace(sysNamespacesHelp["namespaces-unlock"][1]),
		},

		{
			Pattern: "namespaces/(?P<path>.+)",

			DisplayAttrs: &framework.DisplayAttributes{
				OperationPrefix: "namespaces",
			},

			Fields: map[string]*framework.FieldSchema{
				"path": namespacePathSchema,
				"custom_metadata": {
					Type:        framework.TypeMap,
					Description: "User provided key-value pairs.",
				},
				"seal": {
					Type:        framework.TypeString,
					Description: "User provided seal config.",
				},
				"pgp_keys": {
					Type:        framework.TypeStringSlice,
					Description: "Specifies an array of PGP public keys used to encrypt the output unseal keys.",
				},
			},

			Operations: map[logical.Operation]framework.OperationHandler{
				logical.ReadOperation: &framework.PathOperation{
					Callback: b.handleNamespacesRead(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: namespaceSchema}},
					},
					Summary: "Retrieve a namespace.",
				},
				logical.UpdateOperation: &framework.PathOperation{
					Callback: b.handleNamespacesSet(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: namespaceSchema}},
					},
					Summary: "Create or update a namespace.",
				},
				logical.PatchOperation: &framework.PathOperation{
					Callback: b.handleNamespacesPatch(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {{Description: "OK", Fields: namespaceSchema}},
					},
					Summary: "Update a namespace's custom metadata.",
				},
				logical.DeleteOperation: &framework.PathOperation{
					Callback: b.handleNamespacesDelete(),
					Responses: map[int][]framework.Response{
						http.StatusOK: {
							{
								Description: "OK",
								Fields: map[string]*framework.FieldSchema{
									"status": {
										Type:        framework.TypeString,
										Description: "Status of the deletion operation.",
									},
								},
							},
						},
						http.StatusNoContent: {{Description: "No Content"}},
					},
					Summary: "Delete a namespace.",
				},
			},

			HelpSynopsis:    strings.TrimSpace(sysNamespacesHelp["namespaces"][0]),
			HelpDescription: strings.TrimSpace(sysNamespacesHelp["namespaces"][1]),
		},
	}
}

// createNamespaceDataResponse is the standard response object
// for any operations concerning a namespace
func createNamespaceDataResponse(ns *namespace.Namespace) map[string]any {
	return map[string]any{
		"uuid":            ns.UUID,
		"path":            ns.Path,
		"id":              ns.ID,
		"tainted":         ns.Tainted,
		"locked":          ns.Locked,
		"custom_metadata": ns.CustomMetadata,
	}
}

// handleNamespacesList handles "/sys/namespaces" endpoint to list the enabled namespaces.
func (b *SystemBackend) handleNamespacesList() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		parent, err := namespace.FromContext(ctx)
		if err != nil {
			return nil, err
		}
		entries, err := b.Core.namespaceStore.ListNamespaces(ctx, ListNamespaceOpts{
			IncludeSealed: true,
		})
		if err != nil {
			return nil, err
		}

		var keys []string
		keyInfo := make(map[string]any)
		for _, entry := range entries {
			p := parent.TrimmedPath(entry.Path)
			keys = append(keys, p)
			keyInfo[p] = createNamespaceDataResponse(entry)
		}

		return logical.ListResponseWithInfo(keys, keyInfo), nil
	}
}

// handleNamespacesScan handles "/sys/namespaces" endpoint to scan the enabled namespaces.
func (b *SystemBackend) handleNamespacesScan() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		parent, err := namespace.FromContext(ctx)
		if err != nil {
			return nil, err
		}
		entries, err := b.Core.namespaceStore.ListNamespaces(ctx, ListNamespaceOpts{
			Recursive:     true,
			IncludeSealed: true,
		})
		if err != nil {
			return nil, err
		}

		var keys []string
		keyInfo := make(map[string]any)
		for _, entry := range entries {
			p := parent.TrimmedPath(entry.Path)
			keys = append(keys, p)
			keyInfo[p] = createNamespaceDataResponse(entry)
		}

		return logical.ListResponseWithInfo(keys, keyInfo), nil
	}
}

// handleNamespacesRead handles the "/sys/namespaces/<path>" endpoints to read a namespace.
func (b *SystemBackend) handleNamespacesRead() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path, err := namespace.ParseName(data.Get("path").(string))
		if err != nil {
			return handleError(err)
		}

		ns, err := b.Core.namespaceStore.GetNamespaceByPath(ctx, path)
		if err != nil {
			return nil, err
		}

		if ns == nil {
			return nil, nil
		}

		return &logical.Response{Data: createNamespaceDataResponse(ns)}, nil
	}
}

// handleNamespaceSet handles the "/sys/namespaces/<path>" endpoint to set a namespace.
func (b *SystemBackend) handleNamespacesSet() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path, err := namespace.ParseName(data.Get("path").(string))
		if err != nil {
			return handleError(err)
		}

		imetadata, ok := data.GetOk("custom_metadata")
		var metadata map[string]string
		if ok {
			metadata = make(map[string]string)
			for k, v := range imetadata.(map[string]any) {
				if metadata[k], ok = v.(string); !ok {
					return logical.ErrorResponse("custom_metadata values must be strings"), logical.ErrInvalidRequest
				}
			}
		}

		sealRaw, ok := data.GetOk("seal")
		var sealConfig *SealConfig
		if ok {
			var err error
			sealString, ok := sealRaw.(string)
			if !ok {
				return nil, errors.New("seal config must be a HCL or JSON string")
			}
			kmses, err := configutil.ParseKMSes(sealString)
			if err != nil {
				return nil, fmt.Errorf("unable to parse seal config: %w", err)
			}
			if len(kmses) != 1 {
				return nil, errors.New("seal config must contain exactly one seal stanza")
			}
			kms := kmses[0]
			if kms.Type != "shamir" {
				return nil, errors.New("namespaces currently only support shamir seals")
			}

			sealConfig = &SealConfig{
				Type: kms.Type,
			}

			if val, ok := kms.Config["shares"]; ok {
				shares, err := parseutil.ParseInt(val)
				if err != nil {
					return nil, errors.New("value of shares parameter must be integer")
				}
				sealConfig.SecretShares = int(shares)
			}
			if val, ok := kms.Config["threshold"]; ok {
				threshold, err := parseutil.ParseInt(val)
				if err != nil {
					return nil, errors.New("value of shares parameter must be integer")
				}
				sealConfig.SecretThreshold = int(threshold)
			}
			if pgpkeys, ok := data.GetOk("pgp_keys"); ok {
				sealConfig.PGPKeys = pgpkeys.([]string)
			}

			if err := sealConfig.Validate(); err != nil {
				return logical.ErrorResponse("invalid seal config: %v", err), err
			}
		}

		entry, keyShares, err := b.Core.namespaceStore.ModifyNamespaceByPath(ctx, path, sealConfig,
			func(ctx context.Context, ns *namespace.Namespace) (*namespace.Namespace, error) {
				ns.CustomMetadata = metadata
				return ns, nil
			})
		if err != nil {
			return handleError(err)
		}

		resp := &logical.Response{Data: createNamespaceDataResponse(entry)}
		if len(keyShares) != 0 {
			encoded := make([]string, 0, len(keyShares))
			for _, share := range keyShares {
				encoded = append(encoded, hex.EncodeToString(share))
			}
			resp.Data["key_shares"] = encoded
			resp.Data["key_threshold"] = sealConfig.SecretThreshold
		}

		return resp, nil
	}
}

// handleNamespacesPatch handles the "/sys/namespace/<path>" endpoints to update a namespace's custom metadata.
func (b *SystemBackend) handleNamespacesPatch() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path, err := namespace.ParseName(data.Get("path").(string))
		if err != nil {
			return handleError(err)
		}

		patch, ok := data.Get("custom_metadata").(map[string]any)
		if !ok {
			return handleError(errors.New(`missing required field "custom_metadata"`))
		}

		for _, v := range patch {
			switch v.(type) {
			case string, nil:
			default:
				// This is also enforced by finally unmarshaling into a
				// map[string]string post-patch, but we can validate earlier.
				return handleError(fmt.Errorf("metadata patch can only have string or null values, got %T", v))
			}
		}

		ns, _, err := b.Core.namespaceStore.ModifyNamespaceByPath(ctx, path, nil, func(ctx context.Context, ns *namespace.Namespace) (*namespace.Namespace, error) {
			if ns.UUID == "" {
				return nil, logical.CodedError(http.StatusNotFound, "namespace not found")
			}

			// Special case: An explicit nil/null patch clears metadata
			// entirely. The jsonpatch library doesn't handle this because we're
			// not calling it on the entire namespace object, but from the API
			// caller's perspective this is valid RFC7396 behavior.
			if patch == nil {
				ns.CustomMetadata = nil
				return ns, nil
			}

			// Do the merge patch.
			docBytes, err := json.Marshal(ns.CustomMetadata)
			if err != nil {
				return nil, err
			}
			patchBytes, err := json.Marshal(patch)
			if err != nil {
				return nil, err
			}
			resultBytes, err := jsonpatch.MergePatch(docBytes, patchBytes)
			if err != nil {
				return nil, err
			}

			// Write back to the namespace.
			var result map[string]string
			if err := json.Unmarshal(resultBytes, &result); err != nil {
				return nil, err
			}
			ns.CustomMetadata = result

			return ns, nil
		})
		if err != nil {
			return handleError(err)
		}

		return &logical.Response{Data: createNamespaceDataResponse(ns)}, nil
	}
}

// handleNamespacesLock handles the "/sys/namespaces/api-lock/lock/<path>" endpoint to lock a namespace.
func (b *SystemBackend) handleNamespacesLock() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path := namespace.Canonicalize(data.Get("path").(string))
		unlockKey, err := b.Core.namespaceStore.LockNamespace(ctx, path)
		if err != nil {
			return handleError(err)
		}

		if unlockKey != "" {
			return &logical.Response{Data: map[string]any{
				"unlock_key": unlockKey,
			}}, nil
		}

		return nil, nil
	}
}

// handleNamespacesUnlock handles the "/sys/namespaces/api-lock/unlock/<path>" endpoint to unlock a namespace.
func (b *SystemBackend) handleNamespacesUnlock() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path := namespace.Canonicalize(data.Get("path").(string))
		unlockKey := data.Get("unlock_key").(string)

		// sudo check
		isSudo := b.System().(extendedSystemView).SudoPrivilege(ctx, req.MountPoint+req.Path, req.ClientToken)
		if unlockKey == "" && !isSudo {
			return nil, errors.New("provided empty key")
		}

		// unlockKey can only be empty if the request was made with token having sudo capability
		err := b.Core.namespaceStore.UnlockNamespace(ctx, unlockKey, path)
		if err != nil {
			return handleError(err)
		}

		if unlockKey == "" {
			return &logical.Response{Warnings: []string{"Namespace unlocked using sudo capabilities"}}, nil
		}

		return nil, nil
	}
}

// handleNamespacesDelete handles the "/sys/namespaces/<path>" endpoint to delete a namespace.
func (b *SystemBackend) handleNamespacesDelete() framework.OperationFunc {
	return func(ctx context.Context, req *logical.Request, data *framework.FieldData) (*logical.Response, error) {
		path, err := namespace.ParseName(data.Get("path").(string))
		if err != nil {
			return handleError(err)
		}

		status, err := b.Core.namespaceStore.DeleteNamespace(ctx, path)
		if err != nil {
			return handleError(err)
		}

		if status == "" {
			resp := &logical.Response{}
			resp.AddWarning("requested namespace does not exist")
			return resp, nil
		}

		return &logical.Response{
			Data: map[string]any{
				"status": status,
			},
		}, nil
	}
}

var sysNamespacesHelp = map[string][2]string{
	"list-namespaces": {
		"List namespaces.",
		`
This path responds to the following HTTP methods.
	LIST /
		List namespaces.
	SCAN /
		Scan (recursively list) namespaces.
		`,
	},
	"namespaces": {
		"Create, read, update and delete namespaces.",
		`
This path responds to the following HTTP methods.
	GET /<name>
		Retrieve a namespace.
	PUT /<name>
		Create or update a namespace.
	PATCH /<name>
		Update a namespace's custom metadata.
	DELETE /<name>
		Delete a namespace.
		`,
	},
	"namespaces-lock": {
		"Lock a namespace.",
		`
This path responds to the following HTTP methods.
	PUT /<name>
		Lock the API for a namespace.
		`,
	},
	"namespaces-unlock": {
		"Unlock a namespace.",
		`
This path responds to the following HTTP methods.
	PUT /<name>
		Unlock the API for a namespace.
		`,
	},
}
