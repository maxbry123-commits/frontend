package vault

import (
	"errors"
	"fmt"
	"strings"

	"github.com/openbao/openbao/v2/internal/helper/namespace"
)

// namespaceTree represents a tree structure for efficient namespace path lookups.
// IMPORTANT: This structure is NOT thread-safe on its own and must be protected
// by the NamespaceStore's lock when being accessed or modified.
type namespaceTree struct {
	root *namespaceNode
	size int
}

type namespaceNode struct {
	children map[string]*namespaceNode
	entry    *namespace.Namespace
}

// newNamespaceTree creates a new namespaceTree with the given Namespace as
// root namespace
func newNamespaceTree(root *namespace.Namespace) *namespaceTree {
	node := &namespaceNode{
		entry:    root,
		children: make(map[string]*namespaceNode),
	}
	return &namespaceTree{
		root: node,
		size: 1,
	}
}

func (nt *namespaceTree) nodeAt(path string) *namespaceNode {
	path = namespace.Canonicalize(path)
	var segments []string
	if path != "" {
		segments = strings.SplitAfter(path, "/")
		segments = segments[:len(segments)-1]
	}
	node := nt.root
	for _, segment := range segments {
		n, ok := node.children[segment]
		if !ok {
			return nil
		}

		node = n
	}
	return node
}

// Get returns the namespace at a given path.
func (nt *namespaceTree) Get(path string) *namespace.Namespace {
	node := nt.nodeAt(path)
	if node == nil {
		return nil
	}

	return node.entry
}

// IsLeaf returns true if the given path represents a leaf node, i.e., a
// namespace with no children.
func (nt *namespaceTree) IsLeaf(path string) bool {
	node := nt.nodeAt(path)
	if node == nil {
		return false
	}

	return len(node.children) == 0
}

// LongestPrefix finds the longest prefix of path that leads to a namespace. It
// returns the path to the namespace, the namespace and the remaining part of
// the input path.
func (nt *namespaceTree) LongestPrefix(path string) (string, *namespace.Namespace, string) {
	cpath := namespace.Canonicalize(path)
	var segments []string
	if path != "" {
		segments = strings.SplitAfter(cpath, "/")
		segments = segments[:len(segments)-1]
	}
	node := nt.root
	for i := range segments {
		n, ok := node.children[segments[i]]
		if !ok {
			break
		}

		node = n
	}

	namespacePrefix := node.entry.Path
	pathSuffix := strings.TrimPrefix(path, namespacePrefix)
	return namespacePrefix, node.entry.Clone(false), pathSuffix
}

func (nt *namespaceTree) PostOrderTraversal(path string, op func(namespace *namespace.Namespace)) {
	node := nt.nodeAt(path)
	if node == nil {
		return
	}

	nodes := []*namespaceNode{node}
	ordNodes := []*namespaceNode{}

	for len(nodes) > 0 {
		node := nodes[len(nodes)-1]
		nodes = nodes[:len(nodes)-1]
		ordNodes = append(ordNodes, node)

		for _, childNode := range node.children {
			nodes = append(nodes, childNode)
		}
	}

	for i := len(ordNodes) - 1; i >= 0; i-- {
		op(ordNodes[i].entry)
	}
}

// WalkPath calls predicate by walking towards the given namespace, starting
// from the root, until the predicate returns true or the namespace was reached
// or not found.
func (nt *namespaceTree) WalkPath(path string, predicate func(namespace *namespace.Namespace) bool) {
	path = namespace.Canonicalize(path)
	var segments []string
	if path != "" {
		segments = strings.SplitAfter(path, "/")
		segments = segments[:len(segments)-1]
	}

	// intentionally not calling the predicate on the root
	node := nt.root
	for _, segment := range segments {
		n, ok := node.children[segment]
		if !ok || predicate(n.entry) {
			return
		}

		node = n
	}
}

// Walk walks the tree starting at path and calls callback on each encountered
// child namespace. An error is returned if the initial path does not exist.
func (nt *namespaceTree) Walk(
	path string,
	recursive bool,
	callback func(*namespace.Namespace),
) error {
	node := nt.nodeAt(path)
	if node == nil {
		return fmt.Errorf("unknown path: %s", namespace.Canonicalize(path))
	}

	queue := make([]*namespaceNode, 0, len(node.children))
	for _, child := range node.children {
		queue = append(queue, child)
	}

	for len(queue) > 0 {
		node, queue = queue[0], queue[1:]
		callback(node.entry)
		if recursive {
			for _, child := range node.children {
				queue = append(queue, child)
			}
		}
	}

	return nil
}

// Insert adds or updates the namespace with the given entry. It refuses to add
// the namespace if the parent namespace does not exist in the tree.
func (nt *namespaceTree) Insert(entry *namespace.Namespace) error {
	path := namespace.Canonicalize(entry.Path)
	if path == "" {
		return errors.New("can't insert root namespace")
	}
	segments := strings.SplitAfter(path, "/")
	segments = segments[:len(segments)-1]
	l := len(segments)
	node := nt.root
	for i, segment := range segments {
		n, ok := node.children[segment]
		if !ok {
			if i != l-1 {
				return errors.New("can't insert namespace with missing parent")
			}
			node.children[segment] = &namespaceNode{
				children: make(map[string]*namespaceNode),
				entry:    entry,
			}
			nt.size += 1
			return nil
		}

		node = n
	}

	node.entry = entry

	return nil
}

// Delete removes a namespace from the tree using the path. The delete is not
// cascading and refuses to remove namespaces with existing children.
func (nt *namespaceTree) Delete(path string) error {
	path = namespace.Canonicalize(path)
	if path == "" {
		return errors.New("can't delete root namespace")
	}

	segments := strings.SplitAfter(path, "/")
	segments = segments[:len(segments)-1]

	node := nt.root
	var parent *namespaceNode

	for _, segment := range segments {
		n, ok := node.children[segment]
		if !ok {
			return nil
		}

		node, parent = n, node
	}

	if len(node.children) > 0 {
		return errors.New("can't delete namespace with children")
	}

	delete(parent.children, segments[len(segments)-1])
	nt.size -= 1

	return nil
}

// validate validates that all nodes in the tree have entry set
func (nt *namespaceTree) validate() error {
	nodes := make([]*namespaceNode, 0, nt.size)
	nodes = append(nodes, nt.root)

	var errs []error

	for idx := 0; idx < len(nodes); idx++ {
		node := nodes[idx]
		for _, child := range node.children {
			if node.entry == nil {
				errs = append(errs, fmt.Errorf("orphan namespace found: %s", child.entry.Path))
			}
			nodes = append(nodes, child)
		}
	}

	return errors.Join(errs...)
}
