// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package diagnose

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/hashicorp/go-secure-stdlib/tlsutil"
	"github.com/openbao/openbao/v2/internal/helper/configutil"
)

const (
	minVersionError = "'tls_min_version' value %q not supported, please specify one of [tls10,tls11,tls12,tls13]"
	maxVersionError = "'tls_max_version' value %q not supported, please specify one of [tls10,tls11,tls12,tls13]"
)

// ListenerChecks diagnoses warnings and the first encountered error for the listener
// configuration stanzas.
func ListenerChecks(ctx context.Context, listeners []*configutil.Listener) ([]string, []error) {
	testName := "Check Listener TLS"
	ctx, span := StartSpan(ctx, testName)
	defer span.End()

	// These aggregated warnings and errors are returned purely for testing purposes.
	// The errors and warnings will report in this function itself.
	var listenerWarnings []string
	var listenerErrors []error

	for _, l := range listeners {
		listenerID := l.Address

		if strings.ToLower(l.Type) == "unix" {
			Warn(ctx, fmt.Sprintf("Listener at address %s: Unix socket being used in a listener config stanza.", listenerID))
			continue
		}

		if l.TLSDisable {
			Warn(ctx, fmt.Sprintf("Listener at address %s: TLS is disabled in a listener config stanza.", listenerID))
			continue
		}
		if l.TLSDisableClientCerts {
			Warn(ctx, fmt.Sprintf("Listener at address %s: TLS for a listener is turned on without requiring client certificates.", listenerID))
		}
		status, warning := TLSMutualExclusionCertCheck(l)
		if status == 1 {
			Warn(ctx, warning)
		}

		// Perform the TLS version check for listeners.
		if l.TLSMinVersion == "" {
			l.TLSMinVersion = "tls12"
		}
		if l.TLSMaxVersion == "" {
			l.TLSMaxVersion = "tls13"
		}
		_, ok := tlsutil.TLSLookup[l.TLSMinVersion]
		if !ok {
			//nolint:staticcheck // user-facing error
			err := fmt.Errorf("Listener at address %s: %s.", listenerID, fmt.Sprintf(minVersionError, l.TLSMinVersion))
			listenerErrors = append(listenerErrors, err)
			Fail(ctx, err.Error())
		}
		_, ok = tlsutil.TLSLookup[l.TLSMaxVersion]
		if !ok {
			//nolint:staticcheck // user-facing error
			err := fmt.Errorf("Listener at address %s: %s.", listenerID, fmt.Sprintf(maxVersionError, l.TLSMaxVersion))
			listenerErrors = append(listenerErrors, err)
			Fail(ctx, err.Error())
		}

		// Perform checks on the TLS Cryptographic Information.
		warnings, err := TLSFileChecks(l.TLSCertFile, l.TLSKeyFile)
		listenerWarnings, listenerErrors = outputError(ctx, warnings, listenerWarnings, err, listenerErrors, listenerID)

		// Perform checks on the Client CA Cert
		warnings, err = TLSClientCAFileCheck(l)
		listenerWarnings, listenerErrors = outputError(ctx, warnings, listenerWarnings, err, listenerErrors, listenerID)
		// TODO: Use listenerutil.TLSConfig to warn on incorrect protocol specified
		// Alternatively, use tlsutil.SetupTLSConfig.
	}
	return listenerWarnings, listenerErrors
}

func outputError(ctx context.Context, newWarnings, listenerWarnings []string, newErr error, listenerErrors []error, listenerID string) ([]string, []error) {
	for _, warning := range newWarnings {
		warning = listenerID + ": " + warning
		listenerWarnings = append(listenerWarnings, warning)
		Warn(ctx, warning)
	}
	if newErr != nil {
		errMsg := listenerID + ": " + newErr.Error()
		listenerErrors = append(listenerErrors, errors.New(errMsg))
		Fail(ctx, errMsg)
	}
	return listenerWarnings, listenerErrors
}

// TLSFileChecks returns an error and warnings after checking TLS information
func TLSFileChecks(certpath, keypath string) ([]string, error) {
	warnings, err := TLSCertCheck(certpath)
	if err != nil {
		return warnings, err
	}

	// Utilize the native TLS Loading mechanism to ensure we have missed no errors
	_, err = tls.LoadX509KeyPair(certpath, keypath)
	return warnings, err
}

// TLSCertCheck returns an error and warning after checking TLS information on the given cert
func TLSCertCheck(certpath string) ([]string, error) {
	// Parse TLS Certs from the certpath
	leafCerts, interCerts, rootCerts, err := ParseTLSInformation(certpath)
	if err != nil {
		return nil, err
	}

	// Check for TLS Warnings
	warnings, err := TLSFileWarningChecks(leafCerts, interCerts, rootCerts)
	if err != nil {
		return warnings, err
	}

	// Check for TLS Errors
	if err = TLSErrorChecks(leafCerts, interCerts, rootCerts); err != nil {
		return warnings, err
	}
	return warnings, err
}

// ParseTLSInformation parses certficate information and returns it from a cert path.
func ParseTLSInformation(certFilePath string) ([]*x509.Certificate, []*x509.Certificate, []*x509.Certificate, error) {
	leafCerts := []*x509.Certificate{}
	interCerts := []*x509.Certificate{}
	rootCerts := []*x509.Certificate{}
	data, err := os.ReadFile(certFilePath)
	if err != nil {
		//nolint:staticcheck // user-facing error
		return leafCerts, interCerts, rootCerts, fmt.Errorf("Failed to read certificate file: %w.", err)
	}

	certBlocks := []*pem.Block{}
	rest := data
	for {
		var block *pem.Block
		block, rest = pem.Decode(rest)
		if block == nil {
			break
		}
		certBlocks = append(certBlocks, block)
	}

	if len(certBlocks) == 0 {
		//nolint:staticcheck // user-facing error
		return leafCerts, interCerts, rootCerts, errors.New("No certificates found in certificate file.")
	}

	for _, certBlock := range certBlocks {
		cert, err := x509.ParseCertificate(certBlock.Bytes)
		if err != nil {
			//nolint:staticcheck // user-facing error
			return leafCerts, interCerts, rootCerts, fmt.Errorf("A PEM block does not parse to a certificate: %w.", err)
		}

		// Detect if the certificate is a root, leaf, or intermediate
		if cert.IsCA && bytes.Equal(cert.RawIssuer, cert.RawSubject) {
			// It's a root
			rootCerts = append(rootCerts, cert)
		} else if cert.IsCA {
			// It's not a root but it's a CA, so it's an inter
			interCerts = append(interCerts, cert)
		} else {
			// It's gotta be a leaf
			leafCerts = append(leafCerts, cert)
		}
	}

	return leafCerts, interCerts, rootCerts, nil
}

// TLSErrorChecks contains manual error checks against the TLS configuration
func TLSErrorChecks(leafCerts, interCerts, rootCerts []*x509.Certificate) error {
	// Make sure there's the proper number of leafCerts. If there are multiple, it's a bad pem file.
	if len(leafCerts) == 0 {
		//nolint:staticcheck // user-facing error
		return errors.New("No leaf certificates detected.")
	}

	// First, create root pools and interPools from the root and inter certs lists
	rootPool := x509.NewCertPool()
	interPool := x509.NewCertPool()

	for _, root := range rootCerts {
		rootPool.AddCert(root)
	}
	for _, inter := range interCerts {
		interPool.AddCert(inter)
	}

	var err error
	// Verify checks that certificate isn't expired, is of correct usage type, and has an appropriate
	// chain. We start with Root
	for _, root := range rootCerts {
		_, err = root.Verify(x509.VerifyOptions{
			Roots:     rootPool,
			KeyUsages: []x509.ExtKeyUsage{x509.ExtKeyUsageAny},
		})
		if err != nil {
			//nolint:staticcheck // user-facing error
			return fmt.Errorf("Failed to verify root certificate: %w.", err)
		}
	}

	if len(rootCerts) == 0 {
		// No root is provided, so:
		switch {
		case len(interCerts) > 0:
			// ... we'll treat the highest intermediate cert in the chain as a
			// root certificate.
			rootPool.AddCert(interCerts[len(interCerts)-1])
		default:
			// ... we'll treat the leaf itself as a root certificate if there
			// are no intermediates.
			rootPool.AddCert(leafCerts[0])
		}
	}

	// Verifying intermediate certs
	for _, inter := range interCerts {
		_, err = inter.Verify(x509.VerifyOptions{
			Roots:         rootPool,
			Intermediates: interPool,
			KeyUsages:     []x509.ExtKeyUsage{x509.ExtKeyUsageAny},
		})
		if err != nil {
			//nolint:staticcheck // user-facing error
			return fmt.Errorf("Failed to verify intermediate certificate: %w.", err)
		}
	}

	// Verifying leaf cert
	for _, leaf := range leafCerts {
		_, err = leaf.Verify(x509.VerifyOptions{
			Roots:         rootPool,
			Intermediates: interPool,
			KeyUsages:     []x509.ExtKeyUsage{x509.ExtKeyUsageAny},
		})
		if err != nil {
			//nolint:staticcheck // user-facing error
			return fmt.Errorf("Failed to verify primary provided leaf certificate: %w.", err)
		}
	}

	return nil
}

// TLSFileWarningChecks returns warnings based on the leaf certificates, intermediate certificates,
// and root certificates provided.
func TLSFileWarningChecks(leafCerts, interCerts, rootCerts []*x509.Certificate) ([]string, error) {
	var warnings []string
	// add a warning for when there are more than one leaf certs
	if len(leafCerts) > 1 {
		warnings = append(warnings, "More than one leaf certificate detected. Please ensure that there is one unique leaf certificate being supplied to OpenBao in the OpenBao server configuration file.")
	}

	for _, c := range leafCerts {
		if willExpire, timeToExpiry := NearExpiration(c); willExpire {
			warnings = append(warnings, fmt.Sprintf("Leaf certificate (serial %x) is expired or near expiry. Time to expire is: %s.", c.SerialNumber, timeToExpiry))
		}
	}
	for _, c := range interCerts {
		if willExpire, timeToExpiry := NearExpiration(c); willExpire {
			warnings = append(warnings, fmt.Sprintf("Intermediate certificate (serial %x) is expired or near expiry. Time to expire is: %s.", c.SerialNumber, timeToExpiry))
		}
	}
	for _, c := range rootCerts {
		if willExpire, timeToExpiry := NearExpiration(c); willExpire {
			warnings = append(warnings, fmt.Sprintf("Root certificate (serial %x) is expired or near expiry. Time to expire is: %s.", c.SerialNumber, timeToExpiry))
		}
	}

	return warnings, nil
}

// NearExpiration returns (true, time to expiration) if less than 15% of c's
// validity period remains.
//
// For   7-day certs, that's     ~1 day.
// For  30-day certs, that's   ~4.5 days.
// For  90-day certs, that's  ~13.5 days.
// For 365-day certs, that's ~54.75 days.
func NearExpiration(c *x509.Certificate) (bool, time.Duration) {
	now := time.Now()
	lifetime := c.NotAfter.Sub(c.NotBefore)
	if now.Add(lifetime * 15 / 100).After(c.NotAfter) {
		return true, c.NotAfter.Sub(now).Round(time.Second)
	}
	return false, 0
}

// TLSMutualExclusionCertCheck returns error if both TLSDisableClientCerts and TLSRequireAndVerifyClientCert are set
func TLSMutualExclusionCertCheck(l *configutil.Listener) (int, string) {
	if l.TLSDisableClientCerts {
		if l.TLSRequireAndVerifyClientCert {
			return 1, "The tls_disable_client_certs and tls_require_and_verify_client_cert fields in the listener stanza of the OpenBao server configuration are mutually exclusive fields. Please ensure they are not both set to true."
		}
	}
	return 0, ""
}

// TLSClientCAFileCheck Checks the validity of a client CA file
func TLSClientCAFileCheck(l *configutil.Listener) ([]string, error) {
	if l.TLSDisableClientCerts {
		return nil, nil
	} else if !l.TLSRequireAndVerifyClientCert {
		return nil, nil
	}
	return TLSCAFileCheck(l.TLSClientCAFile)
}

// TLSCAFileCheck checks the validity of a TLS CA file
func TLSCAFileCheck(CAFilePath string) ([]string, error) {
	var warningsSlc []string

	// Parse TLS Certs from the tls config
	leafCerts, interCerts, rootCerts, err := ParseTLSInformation(CAFilePath)
	if err != nil {
		return nil, err
	}

	if len(rootCerts) == 0 {
		//nolint:staticcheck // user-facing error
		return nil, errors.New("No root certificate found in CA certificate file.")
	}
	if len(rootCerts) > 1 {
		warningsSlc = append(warningsSlc, "Found multiple root certificates in CA Certificate file instead of just one.")
	}

	// Checking for Self-Signed cert and return an explicit error about it.
	// Self-Signed certs are placed in the leafCerts slice when parsed.
	if len(leafCerts) > 0 && !leafCerts[0].IsCA && bytes.Equal(leafCerts[0].RawIssuer, leafCerts[0].RawSubject) {
		warningsSlc = append(warningsSlc, "Found a self-signed certificate in the CA certificate file.")
	}

	if len(interCerts) > 0 {
		warningsSlc = append(warningsSlc, "Found at least one intermediate certificate in the CA certificate file.")
	}

	if len(leafCerts) > 0 {
		warningsSlc = append(warningsSlc, "Found at least one leaf certificate in the CA certificate file.")
	}

	var warnings []string
	// Check for TLS Warnings
	warnings, err = TLSFileWarningChecks(leafCerts, interCerts, rootCerts)
	for i, warning := range warnings {
		warnings[i] = strings.ReplaceAll(warning, "leaf", "root")
	}
	warningsSlc = append(warningsSlc, warnings...)
	if err != nil {
		return warningsSlc, err
	}

	// Adding rootCerts to leafCert to perform verification in TLSErrorChecks
	leafCerts = append(leafCerts, rootCerts[0])

	// Check for TLS Errors
	if err = TLSErrorChecks(leafCerts, interCerts, rootCerts); err != nil {
		return warningsSlc, errors.New(strings.ReplaceAll(err.Error(), "leaf", "root"))
	}

	return warningsSlc, err
}
