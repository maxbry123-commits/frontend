// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package barrier

import (
	"cmp"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/subtle"
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"path"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	metrics "github.com/hashicorp/go-metrics/compat"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/sdk/v2/physical"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
)

const (
	// initialKeyTerm is the hard coded initial key term. This is
	// used only for values that are not encrypted with the keyring.
	initialKeyTerm = 1

	// termSize the number of bytes used for the key term.
	termSize = 4

	// AutoRotateCheckInterval is used as a timestep between
	// automatic barrier key rotation checks.
	AutoRotateCheckInterval = 5 * time.Minute
	legacyRotateReason      = "legacy rotation"

	// The keyring is persisted before the root key.
	keyringTimeout = 1 * time.Second

	// oneYear is the duration after which we deem keyring term 'legacy'.
	oneYear = 24 * 365 * time.Hour
)

// Versions of the AESGCM storage methodology
const (
	AESGCMVersion1 = 0x1
	AESGCMVersion2 = 0x2
)

// Validate AESGCMBarrier satisfies SecurityBarrier interface
var (
	_ SecurityBarrier              = &AESGCMBarrier{}
	_ TransactionalSecurityBarrier = &TransactionalAESGCMBarrier{}
	_ SecurityBarrierTransaction   = &AESGCMBarrierTransaction{}
)

// Barrier operation metrics.
var (
	barrierEncryptsMetric  = []string{"barrier", "estimated_encryptions"}
	BarrierRotationsMetric = []string{"barrier", "auto_rotation"}
)

// AESGCMBarrier is a SecurityBarrier implementation that uses the AES
// cipher core and the Galois Counter Mode block mode. It defaults to
// the golang NONCE default value of 12 and a key size of 256 bit.
// AES-GCM is high performance, and provides both confidentiality
// and integrity.
type AESGCMBarrier struct {
	backend    physical.Backend
	namespace  *namespace.Namespace
	metaPrefix string

	l        sync.RWMutex
	sealed   bool
	readOnly atomic.Bool

	// keyring is used to maintain all of the encryption keys, including
	// the active key used for encryption, but also prior keys to allow
	// decryption of keys encrypted under previous terms.
	keyring *Keyring

	// cache is used to reduce the number of AEAD constructions we do
	cache     map[uint32]cipher.AEAD
	cacheLock sync.RWMutex

	// currentAESGCMVersionByte is prefixed to a message to allow for
	// future versioning of barrier implementations. It's var instead
	// of const to allow for testing
	currentAESGCMVersionByte byte

	initialized atomic.Bool

	UnaccountedEncryptions *atomic.Int64
	// Used only for testing
	RemoteEncryptions     *atomic.Int64
	totalLocalEncryptions *atomic.Int64
}

type TransactionalAESGCMBarrier struct {
	*AESGCMBarrier
}

// We do not support transactional modification to the barrier itself within
// the AESGCMBarrierTransaction. Further, we don't want to use the
// transaction's view of key material or other underlying values, only for
// decrypting requests into the barrier, and want only a single instance of
// the barrier for bookkeeping about number of operations. Thus we deviate
// from the standard pattern for this struct.
type AESGCMBarrierTransaction struct {
	aes *TransactionalAESGCMBarrier
	txn physical.Transaction
}

func (b *AESGCMBarrier) RotationConfig() (kc KeyRotationConfig, err error) {
	b.l.RLock()
	defer b.l.RUnlock()
	if b.keyring == nil {
		return kc, errors.New("keyring not yet present")
	}
	return b.keyring.rotationConfig.Clone(), nil
}

func (b *AESGCMBarrier) SetRotationConfig(ctx context.Context, rotConfig KeyRotationConfig) error {
	b.l.Lock()
	defer b.l.Unlock()
	rotConfig.Sanitize()
	if !rotConfig.Equals(b.keyring.rotationConfig) {
		b.keyring.rotationConfig = rotConfig
		return b.persistKeyring(ctx, b.keyring)
	}
	return nil
}

// NewAESGCMBarrier is used to construct a new barrier that uses
// the provided physical backend for storage.
func NewAESGCMBarrier(storage physical.Backend, ns *namespace.Namespace) SecurityBarrier {
	b := &AESGCMBarrier{
		backend:                  storage,
		namespace:                cmp.Or(ns, namespace.RootNamespace),
		sealed:                   true,
		cache:                    make(map[uint32]cipher.AEAD),
		currentAESGCMVersionByte: byte(AESGCMVersion2),
		UnaccountedEncryptions:   &atomic.Int64{},
		RemoteEncryptions:        &atomic.Int64{},
		totalLocalEncryptions:    &atomic.Int64{},
	}

	if ns != nil && ns.UUID != namespace.RootNamespaceUUID {
		b.metaPrefix = path.Join(NamespacePrefix, ns.UUID) + "/"
	}

	if _, ok := storage.(physical.TransactionalBackend); ok {
		return &TransactionalAESGCMBarrier{
			b,
		}
	}

	return b
}

// Initialized checks if the barrier has been initialized
// and has a root key set.
func (b *AESGCMBarrier) Initialized(ctx context.Context) (bool, error) {
	if b.initialized.Load() {
		return true, nil
	}

	// Read the keyring file
	entry, err := b.backend.Get(ctx, b.metaPrefix+KeyringPath)
	if err != nil {
		return false, fmt.Errorf("failed to check for initialization: %w", err)
	}

	initialized := entry != nil
	b.initialized.Store(initialized)
	return initialized, nil
}

// Initialize works only if the barrier has not been initialized
// and makes use of the given root key.
func (b *AESGCMBarrier) Initialize(ctx context.Context, key, sealKey []byte) error {
	// Verify the key size
	min, max := b.KeyLength()
	if len(key) < min || len(key) > max {
		return fmt.Errorf("key size must be %d or %d", min, max)
	}

	// Check if already initialized
	if alreadyInit, err := b.Initialized(ctx); err != nil {
		return err
	} else if alreadyInit {
		return ErrBarrierAlreadyInit
	}

	// Generate encryption key
	encrypt, err := b.GenerateKey()
	if err != nil {
		return fmt.Errorf("failed to generate encryption key: %w", err)
	}

	// Create a new keyring, install the keys
	keyring := NewKeyring()
	keyring = keyring.SetRootKey(key)
	keyring, err = keyring.AddKey(&Key{
		Term:    1,
		Version: 1,
		Value:   encrypt,
	})
	if err != nil {
		return fmt.Errorf("failed to create keyring: %w", err)
	}

	err = b.persistKeyring(ctx, keyring)
	if err != nil {
		return err
	}

	if len(sealKey) > 0 {
		primary, err := b.aeadFromKey(encrypt)
		if err != nil {
			return err
		}

		if err = b.putInternal(ctx, b.backend, 1, primary, &logical.StorageEntry{
			Key:   b.metaPrefix + ShamirKekPath,
			Value: sealKey,
		}); err != nil {
			return fmt.Errorf("failed to store new seal key: %w", err)
		}
	}

	return nil
}

// persistKeyring is used to write out the keyring using the
// root key to encrypt it.
func (b *AESGCMBarrier) persistKeyring(ctx context.Context, keyring *Keyring) error {
	return b.persistKeyringInternal(ctx, keyring, false)
}

// persistKeyringBestEffort is like persistKeyring but 'best effort', ie times out early
// for non critical keyring writes (encryption/rotation tracking)
func (b *AESGCMBarrier) persistKeyringBestEffort(ctx context.Context, keyring *Keyring) error {
	return b.persistKeyringInternal(ctx, keyring, true)
}

// persistKeyring is used to write out the keyring using the
// root key to encrypt it.
func (b *AESGCMBarrier) persistKeyringInternal(ctx context.Context, keyring *Keyring, bestEffort bool) error {
	// Create the keyring entry
	keyringBuf, err := keyring.Serialize()
	defer clear(keyringBuf)
	if err != nil {
		return fmt.Errorf("failed to serialize keyring: %w", err)
	}

	// Create the AES-GCM
	gcm, err := b.aeadFromKey(keyring.RootKey())
	if err != nil {
		return fmt.Errorf("failed to retrieve AES-GCM AEAD from root key: %w", err)
	}

	// Encrypt the barrier init value
	value, err := b.encrypt(b.metaPrefix+KeyringPath, initialKeyTerm, gcm, keyringBuf)
	if err != nil {
		return fmt.Errorf("failed to encrypt barrier initial value: %w", err)
	}

	ctxKeyring := ctx

	if bestEffort {
		// We reduce the timeout on the initial 'put' but if this succeeds we will
		// allow longer later on when we try to persist the root key.
		var cancelKeyring func()
		ctxKeyring, cancelKeyring = context.WithTimeout(ctx, keyringTimeout)
		defer cancelKeyring()
	}

	// Create the keyring physical entry
	pe := &physical.Entry{
		Key:   b.metaPrefix + KeyringPath,
		Value: value,
	}

	if err := b.backend.Put(ctxKeyring, pe); err != nil {
		return fmt.Errorf("failed to persist keyring: %w", err)
	}

	// Serialize the root key value
	key := &Key{
		Term:    1,
		Version: 1,
		Value:   keyring.RootKey(),
	}
	keyBuf, err := key.Serialize()
	defer clear(keyBuf)
	if err != nil {
		return fmt.Errorf("failed to serialize root key: %w", err)
	}

	// Encrypt the root key
	activeKey := keyring.ActiveKey()
	aead, err := b.aeadFromKey(activeKey.Value)
	if err != nil {
		return fmt.Errorf("failed to retrieve AES-GCM AEAD from active key: %w", err)
	}
	value, err = b.encryptTracked(b.metaPrefix+RootKeyPath, activeKey.Term, aead, keyBuf)
	if err != nil {
		return fmt.Errorf("failed to encrypt and track active key value: %w", err)
	}

	// Update the rootKeyPath for standby instances
	pe = &physical.Entry{
		Key:   b.metaPrefix + RootKeyPath,
		Value: value,
	}

	// Use the longer timeout from the original context, for the follow-up write
	// to persist the root key, as the initial storage of the keyring was successful.
	if err := b.backend.Put(ctx, pe); err != nil {
		return fmt.Errorf("failed to persist root key: %w", err)
	}

	// Delete the legacy value if it exists.
	if err := b.backend.Delete(ctx, LegacyRootKeyPath); err != nil {
		return fmt.Errorf("failed to remove legacy root key path: %w", err)
	}

	return nil
}

// GenerateKey is used to generate a new key
func (b *AESGCMBarrier) GenerateKey() ([]byte, error) {
	// Generate a 256bit key
	buf := make([]byte, 2*aes.BlockSize)
	_, err := rand.Read(buf)

	return buf, err
}

// KeyLength is used to sanity check a key
func (b *AESGCMBarrier) KeyLength() (int, int) {
	return aes.BlockSize, 2 * aes.BlockSize
}

// Sealed checks if the barrier has been unlocked yet. The Barrier
// is not expected to be able to perform any CRUD until it is unsealed.
func (b *AESGCMBarrier) Sealed() bool {
	b.l.RLock()
	defer b.l.RUnlock()
	return b.sealed
}

// VerifyRoot is used to check if the given key matches the root key
func (b *AESGCMBarrier) VerifyRoot(key []byte) error {
	b.l.RLock()
	defer b.l.RUnlock()
	if b.sealed {
		switch b.metaPrefix {
		case "":
			return ErrBarrierSealed
		default:
			return ErrNamespaceSealed
		}
	}
	if subtle.ConstantTimeCompare(key, b.keyring.RootKey()) != 1 {
		return ErrBarrierInvalidKey
	}
	return nil
}

// ReloadKeyring is used to re-read the underlying keyring.
// This is used for HA deployments to ensure the latest keyring
// is present in the leader.
func (b *AESGCMBarrier) ReloadKeyring(ctx context.Context) error {
	b.l.Lock()
	defer b.l.Unlock()

	// Create the AES-GCM
	gcm, err := b.aeadFromKey(b.keyring.RootKey())
	if err != nil {
		return err
	}

	// Read in the keyring
	out, err := b.backend.Get(ctx, b.metaPrefix+KeyringPath)
	if err != nil {
		return fmt.Errorf("failed to check for keyring: %w", err)
	}

	// Ensure that the keyring exists. This should never happen,
	// and indicates something really bad has happened.
	if out == nil {
		return errors.New("keyring unexpectedly missing")
	}

	// Verify the term is always just one
	term := binary.BigEndian.Uint32(out.Value[:4])
	if term != initialKeyTerm {
		return errors.New("term mis-match")
	}

	// Decrypt the barrier init key
	plain, err := b.decrypt(b.metaPrefix+KeyringPath, gcm, out.Value)
	defer clear(plain)
	if err != nil {
		if strings.Contains(err.Error(), "message authentication failed") {
			return ErrBarrierInvalidKey
		}
		return err
	}

	// Reset enc. counters, this may be a leadership change
	b.totalLocalEncryptions.Store(0)
	b.totalLocalEncryptions.Store(0)
	b.UnaccountedEncryptions.Store(0)
	b.RemoteEncryptions.Store(0)

	return b.recoverKeyring(plain)
}

func (b *AESGCMBarrier) recoverKeyring(plaintext []byte) error {
	keyring, err := DeserializeKeyring(plaintext)
	if err != nil {
		return fmt.Errorf("keyring deserialization failed: %w", err)
	}

	// Setup the keyring and finish
	b.cache = make(map[uint32]cipher.AEAD)
	b.keyring = keyring
	return nil
}

// ReloadRootKey is used to re-read the underlying root key.
// This is used for HA deployments to ensure the latest root key
// is available for keyring reloading.
func (b *AESGCMBarrier) ReloadRootKey(ctx context.Context) error {
	// Read the rootKeyPath upgrade
	out, err := b.Get(ctx, b.metaPrefix+RootKeyPath)
	if err != nil {
		return fmt.Errorf("failed to read root key path: %w", err)
	}

	// The rootKeyPath could be missing (backwards incompatible),
	// we can ignore this and attempt to make progress with the current
	// root key. First check the legacy root key path first, though.
	if out == nil {
		out, err = b.Get(ctx, LegacyRootKeyPath)
		if err != nil {
			return fmt.Errorf("failed to read legacy root key path: %w", err)
		}

		if out == nil {
			return nil
		}
	}

	// Grab write lock and refetch
	b.l.Lock()
	defer b.l.Unlock()

	out, err = b.lockSwitchedGet(ctx, b.backend, b.metaPrefix+RootKeyPath, false)
	if err != nil {
		return fmt.Errorf("failed to read root key path: %w", err)
	}

	if out == nil {
		out, err = b.lockSwitchedGet(ctx, b.backend, LegacyRootKeyPath, false)
		if err != nil {
			return fmt.Errorf("failed to read legacy root key path: %w", err)
		}

		if out == nil {
			return nil
		}
	}

	// Deserialize the root key
	key, err := DeserializeKey(out.Value)
	clear(out.Value)
	if err != nil {
		return fmt.Errorf("failed to deserialize key: %w", err)
	}

	// Check if the root key is the same
	if subtle.ConstantTimeCompare(b.keyring.RootKey(), key.Value) == 1 {
		return nil
	}

	// Update the root key
	oldKeyring := b.keyring
	b.keyring = b.keyring.SetRootKey(key.Value)
	oldKeyring.Zeroize(false)
	return nil
}

// Unseal is used to provide the root key which permits the barrier
// to be unsealed. If the key is not correct, the barrier remains sealed.
func (b *AESGCMBarrier) Unseal(ctx context.Context, key []byte) error {
	b.l.Lock()
	defer b.l.Unlock()

	// Do nothing if already unsealed
	if !b.sealed {
		return nil
	}

	// Create the AES-GCM
	gcm, err := b.aeadFromKey(key)
	if err != nil {
		return err
	}

	// Read in the keyring
	out, err := b.backend.Get(ctx, b.metaPrefix+KeyringPath)
	if err != nil {
		return fmt.Errorf("failed to check for keyring: %w", err)
	}
	if out == nil {
		return ErrBarrierNotInit
	}

	// Verify the term is always just one
	term := binary.BigEndian.Uint32(out.Value[:4])
	if term != initialKeyTerm {
		return errors.New("term mis-match")
	}

	// Decrypt the barrier init key
	plain, err := b.decrypt(b.metaPrefix+KeyringPath, gcm, out.Value)
	defer clear(plain)
	if err != nil {
		if strings.Contains(err.Error(), "message authentication failed") {
			return ErrBarrierInvalidKey
		}
		return err
	}

	// Recover the keyring
	if err = b.recoverKeyring(plain); err != nil {
		return fmt.Errorf("keyring deserialization failed: %w", err)
	}

	b.sealed = false

	return nil
}

// Seal is used to re-seal the barrier. This requires the barrier to
// be unsealed again to perform any further operations.
func (b *AESGCMBarrier) Seal() error {
	b.l.Lock()
	defer b.l.Unlock()

	// Clear cache, remove primary key, and set sealed to true.
	b.cache = make(map[uint32]cipher.AEAD)
	b.keyring.Zeroize(true)
	b.keyring = nil
	b.sealed = true
	return nil
}

// Rotate is used to create a new encryption key. All future writes
// should use the new key, while old values should still be decryptable.
func (b *AESGCMBarrier) Rotate(ctx context.Context) (uint32, error) {
	b.l.Lock()
	defer b.l.Unlock()
	if b.sealed {
		return 0, ErrBarrierSealed
	}

	// Generate a new key
	encrypt, err := b.GenerateKey()
	if err != nil {
		return 0, fmt.Errorf("failed to generate encryption key: %w", err)
	}

	// Get the next term
	term := b.keyring.ActiveTerm()
	newTerm := term + 1

	// Add a new encryption key
	newKeyring, err := b.keyring.AddKey(&Key{
		Term:    newTerm,
		Version: 1,
		Value:   encrypt,
	})
	if err != nil {
		return 0, fmt.Errorf("failed to add new encryption key: %w", err)
	}

	// Persist the new keyring
	if err := b.persistKeyring(ctx, newKeyring); err != nil {
		return 0, err
	}

	// Clear encryption tracking
	b.RemoteEncryptions.Store(0)
	b.totalLocalEncryptions.Store(0)
	b.UnaccountedEncryptions.Store(0)

	// Swap the keyrings
	b.keyring = newKeyring

	return newTerm, nil
}

// CreateUpgrade creates an upgrade path key to the given term from the previous term
func (b *AESGCMBarrier) CreateUpgrade(ctx context.Context, term uint32) error {
	b.l.RLock()
	if b.sealed {
		b.l.RUnlock()
		return ErrBarrierSealed
	}

	// Get the key for this term
	termKey := b.keyring.TermKey(term)
	buf, err := termKey.Serialize()
	defer clear(buf)
	if err != nil {
		b.l.RUnlock()
		return err
	}

	// Get the AEAD for the previous term
	prevTerm := term - 1
	primary, err := b.aeadForTerm(prevTerm)
	if err != nil {
		b.l.RUnlock()
		return err
	}

	key := fmt.Sprintf("%s%d", b.metaPrefix+KeyringUpgradePrefix, prevTerm)
	value, err := b.encryptTracked(key, prevTerm, primary, buf)
	b.l.RUnlock()
	if err != nil {
		return err
	}
	// Create upgrade key
	pe := &physical.Entry{
		Key:   key,
		Value: value,
	}
	return b.backend.Put(ctx, pe)
}

// DestroyUpgrade destroys the upgrade path key to the given term
func (b *AESGCMBarrier) DestroyUpgrade(ctx context.Context, term uint32) error {
	path := fmt.Sprintf("%s%d", b.metaPrefix+KeyringUpgradePrefix, term-1)
	return b.Delete(ctx, path)
}

// CheckUpgrade looks for an upgrade to the current term and installs it
func (b *AESGCMBarrier) CheckUpgrade(ctx context.Context) (bool, uint32, error) {
	b.l.RLock()
	if b.sealed {
		b.l.RUnlock()
		return false, 0, ErrBarrierSealed
	}

	// Get the current term
	activeTerm := b.keyring.ActiveTerm()

	// Check for an upgrade key
	upgrade := fmt.Sprintf("%s%d", b.metaPrefix+KeyringUpgradePrefix, activeTerm)
	entry, err := b.lockSwitchedGet(ctx, b.backend, upgrade, false)
	if err != nil {
		b.l.RUnlock()
		return false, 0, err
	}

	// Nothing to do if no upgrade
	if entry == nil {
		b.l.RUnlock()
		return false, 0, nil
	}

	// Upgrade from read lock to write lock
	b.l.RUnlock()
	b.l.Lock()
	defer b.l.Unlock()

	// Validate base cases and refetch values again
	if b.sealed {
		return false, 0, ErrBarrierSealed
	}

	activeTerm = b.keyring.ActiveTerm()

	upgrade = fmt.Sprintf("%s%d", b.metaPrefix+KeyringUpgradePrefix, activeTerm)
	entry, err = b.lockSwitchedGet(ctx, b.backend, upgrade, false)
	if err != nil {
		return false, 0, err
	}

	if entry == nil {
		return false, 0, nil
	}

	// Deserialize the key
	key, err := DeserializeKey(entry.Value)
	clear(entry.Value)
	if err != nil {
		return false, 0, err
	}

	// Update the keyring
	newKeyring, err := b.keyring.AddKey(key)
	if err != nil {
		return false, 0, fmt.Errorf("failed to add new encryption key: %w", err)
	}
	b.keyring = newKeyring

	// Done!
	return true, key.Term, nil
}

// ActiveKeyInfo is used to inform details about the active key
func (b *AESGCMBarrier) ActiveKeyInfo() (*KeyInfo, error) {
	b.l.RLock()
	defer b.l.RUnlock()
	if b.sealed {
		return nil, ErrBarrierSealed
	}

	// Determine the key install time
	term := b.keyring.ActiveTerm()
	key := b.keyring.TermKey(term)

	// Return the key info
	info := &KeyInfo{
		Term:        int(term),
		InstallTime: key.InstallTime,
		Encryptions: b.encryptions(),
	}
	return info, nil
}

// RotateRootKey is used to change the root key used to protect the keyring
func (b *AESGCMBarrier) RotateRootKey(ctx context.Context, key []byte) error {
	b.l.Lock()
	defer b.l.Unlock()

	newKeyring, err := b.updateRootKeyCommon(key)
	if err != nil {
		return err
	}

	// Persist the new keyring
	if err := b.persistKeyring(ctx, newKeyring); err != nil {
		return err
	}

	// Swap the keyrings
	oldKeyring := b.keyring
	b.keyring = newKeyring
	oldKeyring.Zeroize(false)
	return nil
}

// SetRootKey updates the keyring's in-memory root key but does not persist
// anything to storage
func (b *AESGCMBarrier) SetRootKey(key []byte) error {
	b.l.Lock()
	defer b.l.Unlock()

	newKeyring, err := b.updateRootKeyCommon(key)
	if err != nil {
		return err
	}

	// Swap the keyrings
	oldKeyring := b.keyring
	b.keyring = newKeyring
	oldKeyring.Zeroize(false)
	return nil
}

// Performs common tasks related to updating the root key; note that the lock
// must be held before calling this function
func (b *AESGCMBarrier) updateRootKeyCommon(key []byte) (*Keyring, error) {
	if b.sealed {
		return nil, ErrBarrierSealed
	}

	// Verify the key size
	min, max := b.KeyLength()
	if len(key) < min || len(key) > max {
		return nil, fmt.Errorf("key size must be %d or %d", min, max)
	}

	return b.keyring.SetRootKey(key), nil
}

// Put is used to insert or update an entry
func (b *AESGCMBarrier) Put(ctx context.Context, entry *logical.StorageEntry) error {
	return b.putWithBackend(ctx, b.backend, entry)
}

func (b *AESGCMBarrier) putWithBackend(ctx context.Context, backend physical.Backend, entry *logical.StorageEntry) error {
	defer metrics.MeasureSince([]string{"barrier", "put"}, time.Now())

	if b.readOnly.Load() {
		return logical.ErrReadOnly
	}

	b.l.RLock()
	if b.sealed {
		b.l.RUnlock()
		return ErrBarrierSealed
	}

	term := b.keyring.ActiveTerm()
	primary, err := b.aeadForTerm(term)
	b.l.RUnlock()
	if err != nil {
		return err
	}

	return b.putInternal(ctx, backend, term, primary, entry)
}

func (b *AESGCMBarrier) putInternal(ctx context.Context, backend physical.Backend, term uint32, primary cipher.AEAD, entry *logical.StorageEntry) error {
	value, err := b.encryptTracked(entry.Key, term, primary, entry.Value)
	if err != nil {
		return err
	}
	pe := &physical.Entry{
		Key:      entry.Key,
		Value:    value,
		SealWrap: entry.SealWrap,
	}
	return backend.Put(ctx, pe)
}

// Get is used to fetch an entry
func (b *AESGCMBarrier) Get(ctx context.Context, key string) (*logical.StorageEntry, error) {
	return b.lockSwitchedGet(ctx, b.backend, key, true)
}

func (b *AESGCMBarrier) lockSwitchedGet(ctx context.Context, backend physical.Backend, key string, getLock bool) (*logical.StorageEntry, error) {
	defer metrics.MeasureSince([]string{"barrier", "get"}, time.Now())
	if getLock {
		b.l.RLock()
	}

	unlock := true
	defer func() {
		if getLock && unlock {
			b.l.RUnlock()
		}
	}()

	if b.sealed {
		return nil, ErrBarrierSealed
	}

	// Read the key from the backend
	pe, err := backend.Get(ctx, key)
	if err != nil {
		return nil, err
	} else if pe == nil {
		return nil, nil
	}

	if len(pe.Value) < 4 {
		return nil, errors.New("invalid value")
	}

	// Verify the term
	term := binary.BigEndian.Uint32(pe.Value[:4])

	// Get the GCM by term
	// It is expensive to do this first but it is not a
	// normal case that this won't match
	gcm, err := b.aeadForTerm(term)
	if err != nil {
		return nil, err
	}
	if gcm == nil {
		return nil, fmt.Errorf("no decryption key available for term %d", term)
	}

	unlock = false
	if getLock {
		b.l.RUnlock()
	}

	// Decrypt the ciphertext
	plain, err := b.decrypt(key, gcm, pe.Value)
	if err != nil {
		return nil, fmt.Errorf("decryption failed: %w", err)
	}

	// Wrap in a logical entry
	entry := &logical.StorageEntry{
		Key:      key,
		Value:    plain,
		SealWrap: pe.SealWrap,
	}
	return entry, nil
}

// Delete is used to permanently delete an entry
func (b *AESGCMBarrier) Delete(ctx context.Context, key string) error {
	return b.deleteWithBackend(ctx, b.backend, key)
}

func (b *AESGCMBarrier) deleteWithBackend(ctx context.Context, backend physical.Backend, key string) error {
	defer metrics.MeasureSince([]string{"barrier", "delete"}, time.Now())

	if b.readOnly.Load() {
		return logical.ErrReadOnly
	}

	b.l.RLock()
	sealed := b.sealed
	b.l.RUnlock()
	if sealed {
		return ErrBarrierSealed
	}

	return backend.Delete(ctx, key)
}

// List is used to list all the keys under a given
// prefix, up to the next prefix.
func (b *AESGCMBarrier) List(ctx context.Context, prefix string) ([]string, error) {
	defer metrics.MeasureSince([]string{"barrier", "list"}, time.Now())
	b.l.RLock()
	sealed := b.sealed
	b.l.RUnlock()
	if sealed {
		return nil, ErrBarrierSealed
	}

	return b.backend.List(ctx, prefix)
}

// ListPage is used to list a subset of the keys under a given
// prefix, up to the next prefix.
func (b *AESGCMBarrier) ListPage(ctx context.Context, prefix string, after string, limit int) ([]string, error) {
	return b.listPageWithBackend(ctx, b.backend, prefix, after, limit)
}

func (b *AESGCMBarrier) listPageWithBackend(ctx context.Context, backend physical.Backend, prefix string, after string, limit int) ([]string, error) {
	defer metrics.MeasureSince([]string{"barrier", "list-page"}, time.Now())
	b.l.RLock()
	sealed := b.sealed
	b.l.RUnlock()
	if sealed {
		return nil, ErrBarrierSealed
	}

	return backend.ListPage(ctx, prefix, after, limit)
}

// aeadForTerm returns the AES-GCM AEAD for the given term
func (b *AESGCMBarrier) aeadForTerm(term uint32) (cipher.AEAD, error) {
	// Check for the keyring
	keyring := b.keyring
	if keyring == nil {
		return nil, nil
	}

	// Check the cache for the aead
	b.cacheLock.RLock()
	aead, ok := b.cache[term]
	b.cacheLock.RUnlock()
	if ok {
		return aead, nil
	}

	// Read the underlying key
	key := keyring.TermKey(term)
	if key == nil {
		return nil, nil
	}

	// Create a new aead
	aead, err := b.aeadFromKey(key.Value)
	if err != nil {
		return nil, err
	}

	// Update the cache
	b.cacheLock.Lock()
	b.cache[term] = aead
	b.cacheLock.Unlock()
	return aead, nil
}

// aeadFromKey returns an AES-GCM AEAD using the given key.
func (b *AESGCMBarrier) aeadFromKey(key []byte) (cipher.AEAD, error) {
	// Create the AES cipher
	aesCipher, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("failed to create cipher: %w", err)
	}

	// Create the GCM mode AEAD
	gcm, err := cipher.NewGCMWithRandomNonce(aesCipher)
	if err != nil {
		return nil, errors.New("failed to initialize GCM mode")
	}
	return gcm, nil
}

// encrypt is used to encrypt a value
func (b *AESGCMBarrier) encrypt(path string, term uint32, gcm cipher.AEAD, plain []byte) ([]byte, error) {
	// Allocate the output buffer with room for term, version byte,
	// nonce, GCM tag and the plaintext

	extra := termSize + 1 + gcm.Overhead()
	if len(plain) > math.MaxInt-extra {
		return nil, ErrPlaintextTooLarge
	}

	capacity := len(plain) + extra
	size := termSize + 1
	out := make([]byte, size, capacity)

	// Set the key term
	binary.BigEndian.PutUint32(out[:4], term)

	// Set the version byte
	out[4] = b.currentAESGCMVersionByte

	// Seal the output
	switch b.currentAESGCMVersionByte {
	case AESGCMVersion1:
		out = gcm.Seal(out, nil, plain, nil)
	case AESGCMVersion2:
		aad := []byte(nil)
		if path != "" {
			aad = []byte(path)
		}
		out = gcm.Seal(out, nil, plain, aad)
	default:
		panic("Unknown AESGCM version")
	}

	return out, nil
}

func termLabel(term uint32) []metrics.Label {
	return []metrics.Label{
		{
			Name:  "term",
			Value: strconv.FormatUint(uint64(term), 10),
		},
	}
}

// decrypt is used to decrypt a value using the keyring
func (b *AESGCMBarrier) decrypt(path string, gcm cipher.AEAD, cipher []byte) ([]byte, error) {
	if len(cipher) <= 5 {
		return nil, errors.New("invalid cipher length")
	}

	raw := cipher[5:]

	// Pass a zero-length slice to gcm.Open to ensure that empty data decrypts
	// to an empty slice opposed to a nil slice, which is consistent with other
	// implementations of logical.Storage.
	out := []byte{}

	// Attempt to open
	switch cipher[4] {
	case AESGCMVersion1:
		return gcm.Open(out, nil, raw, nil)
	case AESGCMVersion2:
		aad := []byte(nil)
		if path != "" {
			aad = []byte(path)
		}
		return gcm.Open(out, nil, raw, aad)
	default:
		return nil, errors.New("version bytes mis-match")
	}
}

// Encrypt is used to encrypt in-memory for the BarrierEncryptor interface
func (b *AESGCMBarrier) Encrypt(ctx context.Context, key string, plaintext []byte) ([]byte, error) {
	b.l.RLock()
	if b.sealed {
		b.l.RUnlock()
		return nil, ErrBarrierSealed
	}

	term := b.keyring.ActiveTerm()
	primary, err := b.aeadForTerm(term)
	b.l.RUnlock()
	if err != nil {
		return nil, err
	}

	ciphertext, err := b.encryptTracked(key, term, primary, plaintext)
	if err != nil {
		return nil, err
	}

	return ciphertext, nil
}

// Decrypt is used to decrypt in-memory for the BarrierEncryptor interface
func (b *AESGCMBarrier) Decrypt(_ context.Context, key string, ciphertext []byte) ([]byte, error) {
	b.l.RLock()
	if b.sealed {
		b.l.RUnlock()
		return nil, ErrBarrierSealed
	}

	if len(ciphertext) == 0 {
		b.l.RUnlock()
		return nil, errors.New("empty ciphertext")
	}

	// Verify the term
	if len(ciphertext) < 4 {
		b.l.RUnlock()
		return nil, errors.New("invalid ciphertext term")
	}
	term := binary.BigEndian.Uint32(ciphertext[:4])

	// Get the GCM by term
	// It is expensive to do this first but it is not a
	// normal case that this won't match
	gcm, err := b.aeadForTerm(term)
	b.l.RUnlock()
	if err != nil {
		return nil, err
	}
	if gcm == nil {
		return nil, fmt.Errorf("no decryption key available for term %d", term)
	}

	// Decrypt the ciphertext
	plain, err := b.decrypt(key, gcm, ciphertext)
	if err != nil {
		return nil, fmt.Errorf("decryption failed: %w", err)
	}

	return plain, nil
}

func (b *AESGCMBarrier) Keyring() (*Keyring, error) {
	b.l.RLock()
	defer b.l.RUnlock()
	if b.sealed {
		return nil, ErrBarrierSealed
	}

	return b.keyring.Clone(), nil
}

func (b *AESGCMBarrier) ConsumeEncryptionCount(consumer func(int64) error) error {
	if b.keyring != nil {
		// Lock to prevent replacement of the key while we consume the encryptions
		b.l.RLock()
		defer b.l.RUnlock()

		c := b.UnaccountedEncryptions.Load()
		err := consumer(c)
		if err == nil && c > 0 {
			// Consumer succeeded, remove those from local encryptions
			b.UnaccountedEncryptions.Add(-c)
		}
		return err
	}
	return nil
}

func (b *AESGCMBarrier) AddRemoteEncryptions(encryptions int64) {
	// For rollup and persistence
	b.UnaccountedEncryptions.Add(encryptions)
	// For testing
	b.RemoteEncryptions.Add(encryptions)
}

func (b *AESGCMBarrier) encryptTracked(path string, term uint32, gcm cipher.AEAD, buf []byte) ([]byte, error) {
	ct, err := b.encrypt(path, term, gcm, buf)
	if err != nil {
		return nil, err
	}
	// Increment the local encryption count, and track metrics
	b.UnaccountedEncryptions.Add(1)
	b.totalLocalEncryptions.Add(1)
	metrics.IncrCounterWithLabels(barrierEncryptsMetric, 1, termLabel(term))

	return ct, nil
}

// UnaccountedEncryptions returns the number of encryptions made on the local instance only for the current key term
func (b *AESGCMBarrier) TotalLocalEncryptions() int64 {
	return b.totalLocalEncryptions.Load()
}

func (b *AESGCMBarrier) CheckBarrierAutoRotate(ctx context.Context) (string, error) {
	reason, err := func() (string, error) {
		b.l.RLock()
		defer b.l.RUnlock()

		if b.keyring == nil {
			return "", nil
		}

		rc := b.keyring.rotationConfig.Clone()
		if rc.Disabled {
			return "", nil
		}

		activeKey := b.keyring.ActiveKey()
		switch {
		case activeKey.Encryptions == 0 && !activeKey.InstallTime.IsZero() && time.Since(activeKey.InstallTime) > oneYear:
			return legacyRotateReason, nil
		case b.encryptions() > rc.MaxOperations:
			return "reached max operations", nil
		case rc.Interval > 0 && time.Since(activeKey.InstallTime) > rc.Interval:
			return "rotation interval reached", nil
		default:
			return "", nil
		}
	}()
	if err != nil {
		return "", err
	}
	if reason != "" {
		return reason, nil
	}

	// either rotation is disabled or we do not fulfill
	// any of the rotation conditions.
	b.l.Lock()
	defer b.l.Unlock()
	if b.keyring != nil {
		return "", b.persistEncryptions(ctx)
	}

	return reason, nil
}

// Must be called with lock held
func (b *AESGCMBarrier) persistEncryptions(ctx context.Context) error {
	if !b.sealed {
		// Encryption count persistence
		upe := b.UnaccountedEncryptions.Load()
		if upe > 0 {
			activeKey := b.keyring.ActiveKey()
			// Move local (unpersisted) encryptions to the key and persist.
			// This prevents us from needing to persist if there has been no activity.
			// Since persistence performs an encryption, perversely we zero out after
			// persistence and add 1 to the count to avoid this operation guaranteeing
			// we need another autoRotateCheckInterval later.
			newEncs := upe + 1
			activeKey.Encryptions += uint64(newEncs)
			newKeyring := b.keyring.Clone()
			err := b.persistKeyringBestEffort(ctx, newKeyring)
			if err != nil {
				return err
			}
			b.UnaccountedEncryptions.Add(-newEncs)
		}
	}
	return nil
}

// Mostly for testing, returns the total number of encryption operations performed on the active term
func (b *AESGCMBarrier) encryptions() int64 {
	if b.keyring != nil {
		activeKey := b.keyring.ActiveKey()
		if activeKey != nil {
			return b.UnaccountedEncryptions.Load() + int64(activeKey.Encryptions)
		}
	}
	return 0
}

func (b *AESGCMBarrier) SetReadOnly(readOnly bool) {
	b.readOnly.Store(readOnly)
}

func (b *AESGCMBarrier) Namespace() *namespace.Namespace {
	return b.namespace
}

func (b *TransactionalAESGCMBarrier) BeginReadOnlyTx(ctx context.Context) (logical.Transaction, error) {
	txn, err := b.AESGCMBarrier.backend.(physical.TransactionalBackend).BeginReadOnlyTx(ctx)
	if err != nil {
		return nil, err
	}

	return &AESGCMBarrierTransaction{
		aes: b,
		txn: txn,
	}, nil
}

func (b *TransactionalAESGCMBarrier) BeginTx(ctx context.Context) (logical.Transaction, error) {
	txn, err := b.AESGCMBarrier.backend.(physical.TransactionalBackend).BeginTx(ctx)
	if err != nil {
		return nil, err
	}

	return &AESGCMBarrierTransaction{
		aes: b,
		txn: txn,
	}, nil
}

func (t *AESGCMBarrierTransaction) List(ctx context.Context, prefix string) ([]string, error) {
	return t.ListPage(ctx, prefix, "", -1)
}

func (t *AESGCMBarrierTransaction) ListPage(ctx context.Context, prefix string, after string, limit int) ([]string, error) {
	return t.aes.listPageWithBackend(ctx, t.txn, prefix, after, limit)
}

func (t *AESGCMBarrierTransaction) Put(ctx context.Context, entry *logical.StorageEntry) error {
	return t.aes.putWithBackend(ctx, t.txn, entry)
}

func (t *AESGCMBarrierTransaction) Get(ctx context.Context, key string) (*logical.StorageEntry, error) {
	return t.aes.lockSwitchedGet(ctx, t.txn, key, true)
}

func (t *AESGCMBarrierTransaction) Delete(ctx context.Context, key string) error {
	return t.aes.deleteWithBackend(ctx, t.txn, key)
}

func (t *AESGCMBarrierTransaction) Commit(ctx context.Context) error {
	return t.txn.Commit(ctx)
}

func (t *AESGCMBarrierTransaction) Rollback(ctx context.Context) error {
	return t.txn.Rollback(ctx)
}
