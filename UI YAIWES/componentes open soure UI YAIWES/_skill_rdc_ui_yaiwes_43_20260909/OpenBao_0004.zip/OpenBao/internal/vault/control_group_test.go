// Copyright (c) 2026 OpenBao a Series of LF Projects, LLC
// SPDX-License-Identifier: MPL-2.0

package vault

import (
	"context"
	"testing"
	"time"

	"github.com/hashicorp/go-uuid"
	"github.com/openbao/openbao/sdk/v2/helper/jsonutil"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/v2/internal/helper/identity"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
	"github.com/openbao/openbao/v2/internal/vault/policy"
	"github.com/stretchr/testify/require"
)

func TestControlGroup_makeLogicalControlGroup(t *testing.T) {
	input := &policy.ControlGroup{
		TTL: 14440,
		Factors: []policy.ControlGroupFactor{
			{
				Name:                   "tester",
				ControlledCapabilities: []logical.Operation{logical.CreateOperation},
				Identity: policy.ControlGroupIdentity{
					GroupNames: []string{"admin"},
					Approvals:  2,
				},
			},
		},
	}
	output := makeLogicalControlGroup(input)
	require.IsType(t, logical.ControlGroup{}, *output)
	require.Equal(t, time.Duration(14440), output.TTL)
	require.Equal(t, "tester", output.Factors[0].Name)
	require.Equal(t, []logical.Operation{logical.CreateOperation}, output.Factors[0].ControlledCapabilities)
	require.Equal(t, []string{"admin"}, output.Factors[0].Identity.GroupNames)

	output = makeLogicalControlGroup(nil)
	require.Empty(t, output)
}

func TestControlGroup_getControlGroup(t *testing.T) {
	c, _, _ := TestCoreUnsealed(t)

	ctx := namespace.RootContext(context.Background())
	originalCG := logical.ControlGroup{
		TTL: time.Duration(14440),
		Factors: []logical.ControlGroupFactor{
			{
				Name: "test-cg",
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"secops"},
					Approvals:  2,
				},
			},
		},
	}

	cg, err := jsonutil.EncodeJSON(originalCG)
	require.Nil(t, err)

	creationTime := time.Now()
	te := logical.TokenEntry{
		Path:           "token/create",
		Policies:       []string{"response-wrapping"},
		CreationTime:   creationTime.Unix(),
		TTL:            time.Hour,
		NumUses:        3,
		ExplicitMaxTTL: time.Hour,
		NamespaceID:    "root",
		InternalMeta: map[string]string{
			"control_group": string(cg),
		},
		Meta: map[string]string{
			"ttl": "600s",
		},
	}

	testMakeTokenDirectly(t, ctx, c.tokenStore, &te)
	require.NotEmpty(t, te.ID)

	// Extract control group from token entry
	fetchedCG, err := c.getControlGroupFromTokenEntry(ctx, &te)
	require.Nil(t, err)
	require.Equal(t, &originalCG, fetchedCG)
}

func TestControlGroup_setControlGroup(t *testing.T) {
	c, _, _ := TestCoreUnsealed(t)

	creationTime := time.Now()
	te := &logical.TokenEntry{
		Path:           "token/create",
		Policies:       []string{"response-wrapping"},
		CreationTime:   creationTime.Unix(),
		TTL:            time.Hour,
		NumUses:        3,
		ExplicitMaxTTL: time.Hour,
		NamespaceID:    "root",
		Meta: map[string]string{
			"ttl": "600s",
		},
	}

	ctx := namespace.RootContext(context.Background())
	testMakeTokenDirectly(t, ctx, c.tokenStore, te)
	require.NotEmpty(t, te.ID)                         // id has been created
	require.Empty(t, te.InternalMeta["control_group"]) // no control group

	cg := logical.ControlGroup{
		TTL: time.Duration(14440),
		Factors: []logical.ControlGroupFactor{
			{
				Name: "test-cg",
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"secops"},
					Approvals:  2,
				},
			},
		},
	}

	// Set control group via token
	err := c.setControlGroupInTokenEntry(ctx, te, &cg)
	require.Nil(t, err)

	// Token entry should now have control group
	te, err = c.tokenStore.Lookup(ctx, te.ID)
	require.Nil(t, err)

	require.NotEmpty(t, te)
	require.NotEmpty(t, te.InternalMeta["control_group"])
}

func TestControlGroup_addAuthorization(t *testing.T) {
	c, _, _ := TestCoreUnsealed(t)
	i := c.identityStore

	creationTime := time.Now()
	wrappingTokenEntry := &logical.TokenEntry{
		Path:           "token/create",
		Policies:       []string{"response-wrapping"},
		CreationTime:   creationTime.Unix(),
		TTL:            time.Hour,
		NumUses:        3,
		ExplicitMaxTTL: time.Hour,
		NamespaceID:    "root",
		Meta: map[string]string{
			"ttl": "600s",
		},
	}

	ctx := namespace.RootContext(context.Background())
	testMakeTokenDirectly(t, ctx, c.tokenStore, wrappingTokenEntry)
	require.NotEmpty(t, wrappingTokenEntry.ID)                          // id has been created
	require.Empty(t, wrappingTokenEntry.InternalMeta["control_group"])  // no control group
	require.Empty(t, wrappingTokenEntry.InternalMeta["request_entity"]) // no request data

	// Create group for approver membership
	secOpsGroup := identity.Group{
		ID:          "secops-id",
		Name:        "secops",
		NamespaceID: namespace.RootNamespaceID,
		BucketKey:   i.EntityPacker(ctx).BucketKey("secops-id"),
	}

	txn := i.Txn(ctx, true)
	err := i.MemDBUpsertGroupInTxn(txn, &secOpsGroup)
	require.NoError(t, err)
	txn.Commit()

	cg := logical.ControlGroup{
		TTL: time.Duration(14440),
		Factors: []logical.ControlGroupFactor{
			{
				Name: "test-secops",
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"secops"},
					Approvals:  2,
				},
			},
			{
				Name: "test-admin",
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"admin"},
					Approvals:  2,
				},
			},
			{
				Name: "test-both",
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"admin", "secops"},
					Approvals:  2,
				},
			},
		},
	}

	requestEntity := logical.Entity{
		ID:   "requesting-entity",
		Name: "Joe User",
	}

	// Set control group in token
	err = c.setControlGroupInTokenEntry(ctx, wrappingTokenEntry, &cg)
	require.Nil(t, err)

	// Set request entity in token
	err = c.setEntityInTokenEntry(ctx, wrappingTokenEntry, &requestEntity)
	require.Nil(t, err)

	// addAuthorzation
	var groups []*logical.Alias
	groups = append(groups, &logical.Alias{
		ID: "secops-id",
	})
	auth := logical.Auth{
		EntityID:     "approving-user-id",
		DisplayName:  "user@example.com",
		GroupAliases: groups,
	}
	// addAuthorization converts the control group factor identity group names to IDs.
	err = c.addAuthorization(ctx, wrappingTokenEntry.ID, &auth)
	require.Nil(t, err)

	// Token entry should now have the authorization
	wrappingTokenEntry, err = c.tokenStore.lookupInternal(ctx, wrappingTokenEntry.ID, false, false)
	require.Nil(t, err)
	cgFetched, err := c.getControlGroupFromTokenEntry(ctx, wrappingTokenEntry)
	require.Nil(t, err)

	// expect all matching factors to receive an authorization
	require.NotEmpty(t, cgFetched)
	require.Len(t, cgFetched.Factors[0].Authorizations, 1)
	require.Len(t, cgFetched.Factors[1].Authorizations, 0)
	require.Len(t, cgFetched.Factors[2].Authorizations, 1)

	// Second authorization by same user will result in error
	err = c.addAuthorization(ctx, wrappingTokenEntry.ID, &auth)
	require.NotNil(t, err)

	// Authorization by the original request entity will result in error
	auth.EntityID = requestEntity.ID
	err = c.addAuthorization(ctx, wrappingTokenEntry.ID, &auth)
	require.NotNil(t, err)

	// Authorization by the token owner will NOT result in error
	// if policy permits self authorization
	cg.SelfAuthorizationAllowed = true
	err = c.setControlGroupInTokenEntry(ctx, wrappingTokenEntry, &cg)
	require.Nil(t, err)

	// Self-authorize, no error
	auth.EntityID = requestEntity.ID
	err = c.addAuthorization(ctx, wrappingTokenEntry.ID, &auth)
	require.Nil(t, err)
}

func TestControlGroup_validateControlGroup(t *testing.T) {
	c, _, _ := TestCoreUnsealed(t)
	i := c.identityStore

	creationTime := time.Now()
	te := &logical.TokenEntry{
		Path:           "token/create",
		Policies:       []string{"response-wrapping"},
		CreationTime:   creationTime.Unix(),
		TTL:            time.Hour,
		NumUses:        3,
		ExplicitMaxTTL: time.Hour,
		NamespaceID:    "root",
		Meta: map[string]string{
			"ttl": "600s",
		},
	}

	ctx := namespace.RootContext(context.Background())
	testMakeTokenDirectly(t, ctx, c.tokenStore, te)
	require.NotEmpty(t, te.ID)                 // id has been created
	require.Empty(t, te.Meta["control_group"]) // no control group

	cg := logical.ControlGroup{
		TTL: time.Duration(1 * time.Second),
		Factors: []logical.ControlGroupFactor{
			{
				Name:                   "test-secops",
				ControlledCapabilities: []logical.Operation{logical.ReadOperation},
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"secops"},
					Approvals:  2,
				},
			},
			{
				Name:                   "test-admin",
				ControlledCapabilities: []logical.Operation{logical.PatchOperation},
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"admin"},
					Approvals:  2,
				},
			},
			{
				Name:                   "test-both",
				ControlledCapabilities: []logical.Operation{logical.ReadOperation},
				Identity: logical.ControlGroupIdentity{
					GroupNames: []string{"admin", "secops"},
					Approvals:  2,
				},
			},
		},
	}

	requestEntity := logical.Entity{
		ID:   "requesting-entity",
		Name: "Joe User",
	}

	// Set control group in token
	err := c.setControlGroupInTokenEntry(ctx, te, &cg)
	require.Nil(t, err)

	// Set request entity in token
	err = c.setEntityInTokenEntry(ctx, te, &requestEntity)
	require.Nil(t, err)

	// Create group for approver membership
	secOpsGroup := identity.Group{
		ID:          "secops-id",
		Name:        "secops",
		NamespaceID: namespace.RootNamespaceID,
		BucketKey:   i.EntityPacker(ctx).BucketKey("secops-id"),
	}

	txn := i.Txn(ctx, true)
	err = i.MemDBUpsertGroupInTxn(txn, &secOpsGroup)
	require.NoError(t, err)
	txn.Commit()

	// addAuthorzation
	var groups []*logical.Alias
	groups = append(groups, &logical.Alias{
		ID: "secops-id",
	})

	entityID, err := uuid.GenerateUUID()
	require.Nil(t, err)
	auth := logical.Auth{
		DisplayName:  "user@example.com",
		GroupAliases: groups,
		EntityID:     entityID,
	}
	err = c.addAuthorization(ctx, te.ID, &auth)
	require.Nil(t, err)

	// Should not yet validate for Read
	validates, err := c.validateControlGroup(ctx, te, logical.ReadOperation)
	require.Nil(t, err)
	require.False(t, validates)

	// but should validate for unprotected operation
	validates, err = c.validateControlGroup(ctx, te, logical.ListOperation)
	require.Nil(t, err)
	require.True(t, validates)

	// Second auth by different user should authorize
	auth.EntityID = auth.EntityID + "_new"
	err = c.addAuthorization(ctx, te.ID, &auth)
	require.Nil(t, err)

	// now validates for Read
	te, err = c.tokenStore.lookupInternal(ctx, te.ID, false, false)
	require.Nil(t, err)
	validates, err = c.validateControlGroup(ctx, te, logical.ReadOperation)
	require.Nil(t, err)
	require.True(t, validates)

	// After TTL, authorizations should expire
	time.Sleep(1 * time.Second)
	te, err = c.tokenStore.lookupInternal(ctx, te.ID, false, false)
	require.Nil(t, err)
	validates, err = c.validateControlGroup(ctx, te, logical.ReadOperation)
	require.Nil(t, err)
	require.False(t, validates)
}
