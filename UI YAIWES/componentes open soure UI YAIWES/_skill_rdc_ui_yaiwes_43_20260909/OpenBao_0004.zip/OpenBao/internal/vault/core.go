// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package vault

import (
	"context"
	"crypto/ecdsa"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"maps"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/hashicorp/errwrap"
	log "github.com/hashicorp/go-hclog"
	metrics "github.com/hashicorp/go-metrics/compat"
	"github.com/hashicorp/go-multierror"
	"github.com/hashicorp/go-secure-stdlib/reloadutil"
	"github.com/hashicorp/go-secure-stdlib/tlsutil"
	"github.com/hashicorp/go-uuid"
	wrapping "github.com/openbao/go-kms-wrapping/v2"
	"github.com/openbao/openbao/api/v2"
	"github.com/openbao/openbao/sdk/v2/helper/certutil"
	"github.com/openbao/openbao/sdk/v2/helper/consts"
	"github.com/openbao/openbao/sdk/v2/helper/jsonutil"
	"github.com/openbao/openbao/sdk/v2/helper/logging"
	"github.com/openbao/openbao/sdk/v2/helper/pathmanager"
	"github.com/openbao/openbao/sdk/v2/helper/shamir"
	"github.com/openbao/openbao/sdk/v2/logical"
	"github.com/openbao/openbao/sdk/v2/physical"
	"github.com/openbao/openbao/v2/internal/audit"
	"github.com/openbao/openbao/v2/internal/command/server"
	fwd "github.com/openbao/openbao/v2/internal/helper/forwarding"
	"github.com/openbao/openbao/v2/internal/helper/identity"
	"github.com/openbao/openbao/v2/internal/helper/kmsplugin"
	"github.com/openbao/openbao/v2/internal/helper/locking"
	"github.com/openbao/openbao/v2/internal/helper/metricsutil"
	"github.com/openbao/openbao/v2/internal/helper/namespace"
	"github.com/openbao/openbao/v2/internal/helper/osutil"
	"github.com/openbao/openbao/v2/internal/physical/raft"
	sr "github.com/openbao/openbao/v2/internal/serviceregistration"
	"github.com/openbao/openbao/v2/internal/vault/barrier"
	"github.com/openbao/openbao/v2/internal/vault/cluster"
	ek "github.com/openbao/openbao/v2/internal/vault/external_keys"
	"github.com/openbao/openbao/v2/internal/vault/forwarding"
	ident "github.com/openbao/openbao/v2/internal/vault/identity"
	"github.com/openbao/openbao/v2/internal/vault/policy"
	"github.com/openbao/openbao/v2/internal/vault/quotas"
	"github.com/openbao/openbao/v2/internal/vault/routing"
	vaultseal "github.com/openbao/openbao/v2/internal/vault/seal"
	"github.com/openbao/openbao/v2/internal/version"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/keepalive"
	"zgo.at/zcache/v2"
)

const (
	// CoreLockPath is the path used to acquire a coordinating lock
	// for a highly-available deploy.
	CoreLockPath = "core/lock"

	// CoreInitLockPath is the path used to acquire a coordinating lock
	// for a highly-available deployment which is undergoing initialization.
	CoreInitLockPath = "core/initialize-lock"

	// coreLeaderPrefix is the prefix used for the UUID that contains
	// the currently elected leader.
	coreLeaderPrefix = "core/leader/"

	// coreGroupPolicyApplicationPath is used to store the behaviour for
	// how policies should be applied
	coreGroupPolicyApplicationPath = "core/group-policy-application-mode"

	// groupPolicyApplicationModeWithinNamespaceHierarchy is a configuration option for group
	// policy application modes, which allows only in-namespace-hierarchy policy application
	groupPolicyApplicationModeWithinNamespaceHierarchy = "within_namespace_hierarchy"

	indexHeaderHMACKeyPath = "core/index-header-hmac-key"

	// defaultMFAAuthResponseTTL is the default duration that Vault caches the
	// MfaAuthResponse when the value is not specified in the server config
	defaultMFAAuthResponseTTL = 300 * time.Second

	// ForwardSSCTokenToActive is the value that must be set in the
	// forwardToActive to trigger forwarding if a perf standby encounters
	// an SSC Token that it does not have the WAL state for.
	ForwardSSCTokenToActive = "new_token"

	WrapperTypeHsmAutoDeprecated = wrapping.WrapperType("hsm-auto")
)

var (
	// ErrAlreadyInit is returned if the core is already
	// initialized. This prevents a re-initialization.
	//nolint:staticcheck // Vault is a proper name
	ErrAlreadyInit = errors.New("Vault is already initialized")

	// ErrParallelInit is returned if the core is undergoing
	// initialization on another node. This prevents a re-initialization.
	//nolint:staticcheck // Vault is a proper name
	ErrParallelInit = errors.New("Vault is being initialized on another node")

	// ErrNotInit is returned if a non-initialized barrier
	// is attempted to be unsealed.
	//nolint:staticcheck // Vault is a proper name
	ErrNotInit = errors.New("Vault is not initialized")

	// ErrInternalError is returned when we don't want to leak
	// any information about an internal error
	ErrInternalError = errors.New("internal error")

	// ErrHANotEnabled is returned if the operation only makes sense
	// in an HA setting
	//nolint:staticcheck // Vault is a proper name
	ErrHANotEnabled = errors.New("Vault is not configured for highly-available mode")

	// ErrIntrospectionNotEnabled is returned if "introspection_endpoint" is not
	// enabled in the configuration file
	ErrIntrospectionNotEnabled = errors.New("the Vault configuration must set \"introspection_endpoint\" to true to enable this endpoint")

	// errNoMatchingMount is returned if the mount is not found
	errNoMatchingMount = errors.New("no matching mount")

	// manualStepDownSleepPeriod is how long to sleep after a user-initiated
	// step down of the active node, to prevent instantly regrabbing the lock.
	// It's var not const so that tests can manipulate it.
	manualStepDownSleepPeriod = 10 * time.Second
)

var logger = logging.NewVaultLogger(log.Trace)

// NonFatalError is an error that can be returned during NewCore that should be
// displayed but not cause a program exit
type NonFatalError struct {
	Err error
}

func (e *NonFatalError) Unwrap() error {
	return e.Err
}

func (e *NonFatalError) WrappedErrors() []error {
	return []error{e.Err}
}

func (e *NonFatalError) Error() string {
	return e.Err.Error()
}

// NewNonFatalError returns a new non-fatal error.
func NewNonFatalError(err error) *NonFatalError {
	return &NonFatalError{Err: err}
}

// IsFatalError returns true if the given error is a fatal error.
func IsFatalError(err error) bool {
	return !errwrap.ContainsType(err, new(NonFatalError))
}

type RegisterAuthFunc func(context.Context, time.Duration, string, *logical.Auth, string) error

type activeAdvertisement struct {
	RedirectAddr     string                     `json:"redirect_addr"`
	ClusterAddr      string                     `json:"cluster_addr,omitempty"`
	ClusterCert      []byte                     `json:"cluster_cert,omitempty"`
	ClusterKeyParams *certutil.ClusterKeyParams `json:"cluster_key_params,omitempty"`
}

type raftInformation struct {
	challenge           *wrapping.BlobInfo
	leaderClient        *api.Client
	leaderBarrierConfig *SealConfig
	nonVoter            bool
	joinInProgress      bool
}

type migrationInformation struct {
	// seal to use during a migration operation. It is the
	// seal we're migrating *from*.
	seal Seal

	// unsealKey was the unseal key provided for the migration seal.
	// This will be set as the recovery key when migrating from shamir to auto-seal.
	// We don't need to do anything with it when migrating auto->shamir because
	// we don't store the shamir combined key for shamir seals, nor when
	// migrating auto->auto because then the recovery key doesn't change.
	unsealKey []byte
}

// Core is used as the central manager of Vault activity. It is the primary point of
// interface for API handlers and is responsible for managing the logical and physical
// backends, router, security barrier, and audit trails.
type Core struct {
	// The registry of builtin plugins is passed in here as an interface because
	// if it's used directly, it results in import cycles.
	builtinRegistry BuiltinRegistry

	// N.B.: This is used to populate a dev token down replication, as
	// otherwise, after replication is started, a dev would have to go through
	// the generate-root process simply to talk to the new follower cluster.
	devToken string

	// HABackend may be available depending on the physical backend
	ha physical.HABackend

	// storageType is the the storage type set in the storage configuration
	storageType string

	// redirectAddr is the address we advertise as leader if held
	redirectAddr string

	// clusterAddr is the address we use for clustering
	clusterAddr atomic.Value

	// physical backend is the un-trusted backend with durable data
	physical physical.Backend

	// serviceRegistration is the ServiceRegistration network
	serviceRegistration sr.ServiceRegistration

	// underlyingPhysical will always point to the underlying backend
	// implementation. This is an un-trusted backend with durable data
	underlyingPhysical physical.Backend

	// seal is our seal, for seal configuration information
	seal Seal

	// raftJoinDoneCh is used by the raft retry join routine to inform unseal process
	// that the join is complete
	raftJoinDoneCh chan struct{}

	// postUnsealStarted informs the raft retry join routine that unseal key
	// validation is completed and post unseal has started so that it can complete
	// the join process when Shamir seal is in use
	postUnsealStarted atomic.Bool

	// raftInfo will contain information required for this node to join as a
	// peer to an existing raft cluster. This is marked atomic to prevent data
	// races and casted to raftInformation wherever it is used.
	raftInfo atomic.Pointer[raftInformation]

	// migrationInfo is used during (and possibly after) a seal migration.
	// This contains information about the seal we are migrating *from*. Even
	// post seal migration, provided the old seal is still in configuration
	// migrationInfo will be populated, which may be necessary for seal rewrap.
	migrationInfo     *migrationInformation
	sealMigrationDone atomic.Bool

	// barrier is the security barrier wrapping the physical backend
	barrier barrier.SecurityBarrier

	// router is responsible for managing the mount points for logical backends.
	router *routing.Router

	// logicalBackends is the mapping of backends to use for this core
	logicalBackends map[string]logical.Factory

	// credentialBackends is the mapping of backends to use for this core
	credentialBackends map[string]logical.Factory

	// auditBackends is the mapping of backends to use for this core
	auditBackends map[string]audit.Factory

	// stateLock protects mutable state
	stateLock locking.RWMutex
	sealed    atomic.Bool

	standby          atomic.Bool
	haLoopDoneCh     chan struct{}
	haLoopStopCh     atomic.Value
	haLoopRestartCh  atomic.Value
	manualStepDownCh chan struct{}
	heldHALock       physical.Lock

	// shutdownDoneCh is used to notify when core.Shutdown() completes.
	// core.Shutdown() is typically issued in a goroutine to allow Vault to
	// release the stateLock. This channel is marked atomic to prevent race
	// conditions.
	shutdownDoneCh *atomic.Value

	// namespaceRootGens holds the shares for each namespace
	// until we reach enough to verify the root key.
	namespaceRootGens    map[string]*rootTokenGeneration
	namespaceRootGenLock sync.RWMutex

	// These variables holds the config and shares we have until we reach
	// enough to verify the appropriate root key. Note that the same lock is
	// used; this isn't time-critical so this shouldn't be a problem.
	rootRotationConfig     *SealConfig
	recoveryRotationConfig *SealConfig
	rotationLock           sync.RWMutex

	// mounts is loaded after unseal since it is a protected
	// configuration
	mounts *routing.MountTable

	// mountsLock is used to ensure that the mounts table does not
	// change underneath a calling function
	mountsLock locking.DeadlockRWMutex

	// mountMigrationTracker tracks past and ongoing remount operations
	// against their migration ids
	mountMigrationTracker *sync.Map

	// auth is loaded after unseal since it is a protected
	// configuration
	auth *routing.MountTable

	// authLock is used to ensure that the auth table does not
	// change underneath a calling function
	authLock locking.DeadlockRWMutex

	// audit is loaded after unseal since it is a protected
	// configuration
	audit *routing.MountTable

	// auditLock is used to ensure that the audit table does not
	// change underneath a calling function
	auditLock sync.RWMutex

	// auditBroker is used to ingest the audit events and fan
	// out into the configured audit backends
	auditBroker *AuditBroker

	// auditedHeaders is used to configure which http headers
	// can be output in the audit logs
	auditedHeaders *AuditedHeadersConfig

	// systemBackend is the backend which is used to manage internal operations
	systemBackend   *SystemBackend
	loginMFABackend *LoginMFABackend

	// cubbyholeBackend is the backend which manages the per-token storage
	cubbyholeBackend *CubbyholeBackend

	// systemBarrierView is the barrier view for the system backend
	systemBarrierView barrier.View

	// expiration manager is used for managing LeaseIDs,
	// renewal, expiration and revocation
	expiration *ExpirationManager

	// rollback manager is used to run rollbacks periodically
	rollback *RollbackManager

	// policy store is used to manage named ACL policies
	policyStore *policy.Store

	// token store is used to manage authentication tokens
	tokenStore *TokenStore

	// namespace Store is used to manage namespaces
	namespaceStore *NamespaceStore

	// sealManager is used to manage seals per namespace
	sealManager *SealManager

	// identityStore is used to manage client entities
	identityStore *ident.IdentityStore

	// metricsCh is used to stop the metrics streaming
	metricsCh chan struct{}

	// metricsMutex is used to prevent a race condition between
	// metrics emission and sealing leading to a nil pointer
	metricsMutex sync.Mutex

	// inFlightReqMap is used to store info about in-flight requests
	inFlightReqData *InFlightRequests

	// mfaResponseAuthQueue is used to cache the auth response per request ID
	mfaResponseAuthQueue     *LoginMFAPriorityQueue
	mfaResponseAuthQueueLock sync.Mutex

	// metricSink is the destination for all metrics that have
	// a cluster label.
	metricSink *metricsutil.ClusterMetricSink

	defaultLeaseTTL time.Duration
	maxLeaseTTL     time.Duration

	// baseLogger is used to avoid ResetNamed as it strips useful prefixes in
	// e.g. testing
	baseLogger log.Logger
	logger     log.Logger

	// log level provided by config, CLI flag, or env
	logLevel string

	// Disables the trace display for Sentinel checks
	sentinelTraceDisabled bool

	// cachingDisabled indicates whether caches are disabled
	cachingDisabled bool
	// Cache stores the actual cache; we always have this but may bypass it if
	// disabled
	physicalCache physical.ToggleablePurgemonster

	// logRequestsLevel indicates at which level requests should be logged
	logRequestsLevel atomic.Int32

	// reloadFuncs is a map containing reload functions
	reloadFuncs map[string][]reloadutil.ReloadFunc

	// reloadFuncsLock controls access to the funcs
	reloadFuncsLock sync.RWMutex

	// wrappingJWTKey is the key used for generating JWTs containing response
	// wrapping information
	wrappingJWTKey *ecdsa.PrivateKey

	//
	// Cluster information
	//
	// Name
	clusterName string
	// ID
	clusterID atomic.Value
	// Specific cipher suites to use for clustering, if any
	clusterCipherSuites []uint16
	// Used to modify cluster parameters
	clusterParamsLock sync.RWMutex
	// The private key stored in the barrier used for establishing
	// mutually-authenticated connections between Vault cluster members
	localClusterPrivateKey atomic.Pointer[ecdsa.PrivateKey]
	// The local cluster cert
	localClusterCert atomic.Pointer[[]byte]
	// The parsed form of the local cluster cert
	localClusterParsedCert atomic.Pointer[x509.Certificate]
	// The TCP addresses we should use for clustering
	clusterListenerAddrs []*net.TCPAddr
	// The handler to use for request forwarding
	clusterHandler http.Handler
	// Lock for the leader values, ensuring we don't run the parts of Leader()
	// that change things concurrently
	leaderParamsLock sync.RWMutex
	// Current cluster leader values
	clusterLeaderParams atomic.Pointer[ClusterLeaderParams]
	// Info on cluster members
	clusterPeerClusterAddrsCache *zcache.Cache[string, forwarding.NodeHAConnectionInfo]
	// The UUID used to hold the leader lock. Only set on active node
	leaderUUID string
	// When the first time a GRPC invalidation node discovered it did not have
	// any active leader.
	firstMissingLeader time.Time

	// Request forwarding information
	// The context for the client
	rpcClientConnContext atomic.Pointer[atomicContext]
	// The grpc forwarding client
	rpcForwardingClient atomic.Pointer[forwarding.Client]

	// CORS Information
	corsConfig *CORSConfig

	// replicationState keeps the current replication state cached for quick
	// lookup; activeNodeReplicationState stores the active value on standbys
	replicationState           atomic.Uint32
	activeNodeReplicationState atomic.Uint32

	// uiConfig contains UI configuration
	uiConfig *UIConfig

	// rawEnabled indicates whether the Raw endpoint is enabled
	rawEnabled bool

	// inspectableEnabled indicates whether the Inspect endpoint is enabled
	introspectionEnabled     bool
	introspectionEnabledLock sync.Mutex

	// pluginDirectory is the location vault will look for plugin binaries
	pluginDirectory string

	// pluginFileUid is the uid of the plugin files and directory
	pluginFileUid int

	// pluginFilePermissions is the permissions of the plugin files and directory
	pluginFilePermissions int

	// pluginCatalog is used to manage plugin configurations
	pluginCatalog *PluginCatalog

	// kmsPluginCatalog provides KMS plugin functionality.
	kmsPluginCatalog *kmsplugin.Catalog

	// externalKeys manages external key storage & caches.
	externalKeys *ek.Registry

	// The userFailedLoginInfo map has user failed login information.
	// It has user information (alias-name and mount accessor) as a key
	// and login counter, last failed login time as value
	userFailedLoginInfo map[FailedLoginUser]*FailedLoginInfo

	// userFailedLoginInfoLock controls access to the userFailedLoginInfoMap
	userFailedLoginInfoLock sync.RWMutex

	// This can be used to trigger operations to stop running when Vault is
	// going to be shut down, stepped down, or sealed
	activeContext atomic.Pointer[atomicContext]

	// unsealwithStoredKeysLock is a mutex that prevents multiple processes from
	// unsealing with stored keys are the same time.
	unsealWithStoredKeysLock sync.Mutex

	// Stores any funcs that should be run on successful postUnseal
	postUnsealFuncs []func()

	// Stores any funcs that should be run on successful barrier unseal in
	// recovery mode
	postRecoveryUnsealFuncs []func() error

	// Stores loggers so we can reset the level
	allLoggers     []log.Logger
	allLoggersLock sync.RWMutex

	// clusterListener starts up and manages connections on the cluster ports
	clusterListener atomic.Pointer[cluster.Listener]

	// customListenerHeader holds custom response headers for a listener
	customListenerHeader atomic.Pointer[[]*ListenerCustomHeaders]

	// Telemetry objects
	metricsHelper *metricsutil.MetricsHelper

	// raftFollowerStates tracks information about all the raft follower nodes.
	raftFollowerStates *raft.FollowerStates
	// Stop channel for raft TLS rotations
	raftTLSRotationStopCh chan struct{}

	// Stores the root key for generating challenges for pending peers we are
	// waiting to give answers. This is constant size unlike the earlier
	// sync.Map implementation.
	pendingRaftPeerChallengeKey []byte

	// rawConfig stores the config as-is from the provided server configuration.
	rawConfig atomic.Pointer[server.Config]

	coreNumber int

	recoveryMode bool

	clusterNetworkLayer cluster.NetworkLayer

	quotaManager *quotas.Manager

	clusterHeartbeatInterval     time.Duration
	clusterNamespaceSyncInterval time.Duration

	// activeTime is set on active nodes indicating the time at which this node
	// became active.
	activeTime time.Time

	// keyRotateGracePeriod is how long we allow an upgrade path
	// for standby instances before we delete the upgrade keys
	keyRotateGracePeriod atomic.Int64

	autoRotateCancel context.CancelFunc

	updateLockedUserEntriesCancel context.CancelFunc

	// number of workers to use for lease revocation in the expiration manager
	numExpirationWorkers int

	IndexHeaderHMACKey atomic.Value

	// disableAutopilot is used to disable the autopilot subsystem in raft storage
	disableAutopilot bool

	// enable/disable identifying response headers
	enableResponseHeaderHostname   bool
	enableResponseHeaderRaftNodeID bool

	// disableSSCTokens is used to disable server side consistent token creation/usage
	disableSSCTokens bool

	// versionHistory is a map of vault versions to VaultVersion. The
	// VaultVersion.TimestampInstalled when the version will denote when the version
	// was first run. Note that because perf standbys should be upgraded first, and
	// only the active node will actually write the new version timestamp, a perf
	// standby shouldn't rely on the stored version timestamps being present.
	versionHistory map[string]VaultVersion

	// effectiveSDKVersion contains the SDK version that standby nodes should use when
	// heartbeating with the active node. Default to the current SDK version.
	effectiveSDKVersion string

	numRollbackWorkers int
	rollbackPeriod     time.Duration

	pendingRemovalMountsAllowed bool
	expirationRevokeRetryBase   time.Duration

	// writeForwardedPaths are a set of storage paths which are GRPC forwarded
	// to the active node of the primary cluster, when present. This PathManager
	// contains absolute paths that we intend to forward (and template) when
	// we're on a secondary cluster.
	writeForwardedPaths *pathmanager.PathManager

	// if populated, the callback is called for every request
	// for testing purposes
	requestResponseCallback func(logical.Backend, *logical.Request, *logical.Response)

	// If any role based quota (LCQ or RLQ) is enabled, don't track lease counts by role
	impreciseLeaseRoleTracking bool

	// Config value for "detect_deadlocks".
	detectDeadlocks []string

	// Whether we use a single global memdb instance for identity; see
	// commentary below.
	unsafeCrossNamespaceIdentity bool

	// Core invalidation tracker handles dispatching invalidations and
	// refreshing the Core-adjacent caches afterwards.
	invalidations *invalidationManager

	// When awaitInvalidateHook is set early on startup, this maintains a list
	// of connected invalidation peers. When connections blip, we maintain an
	// invalidation state.
	connectedInvalidationPeers *invalidationPeers

	// indexManager allows caching of indices from a physical.ReplicationIndexBackend,
	// reducing the number of calls to the underlying database.
	indexManager *indexManager

	// Whether unauthenticated workflows are allowed by this OpenBao
	// instance.
	allowUnauthedWorkflows bool
	workflowStore          *WorkflowStore

	unsafeRelativePaths bool
}

// c.stateLock needs to be held in read mode before calling this function.
func (c *Core) HAState() consts.HAState {
	switch {
	case c.standby.Load():
		if !c.activeContext.Load().IsNil() {
			return consts.PerfStandby
		}

		return consts.Standby
	default:
		return consts.Active
	}
}

func (c *Core) HAStateWithLock() consts.HAState {
	c.stateLock.RLock()
	defer c.stateLock.RUnlock()

	return c.HAState()
}

// CoreConfig is used to parameterize a core
type CoreConfig struct {
	DevToken string

	BuiltinRegistry BuiltinRegistry

	LogicalBackends map[string]logical.Factory

	CredentialBackends map[string]logical.Factory

	AuditBackends map[string]audit.Factory

	Physical physical.Backend

	StorageType string

	// May be nil, which disables HA operations
	HAPhysical physical.HABackend

	ServiceRegistration sr.ServiceRegistration

	// Seal is the configured seal, or if none is configured explicitly, a
	// shamir seal.  In migration scenarios this is the new seal.
	Seal Seal

	// Unwrap seal is the optional seal marked "disabled"; this is the old
	// seal in migration scenarios.
	UnwrapSeal Seal

	// KMSPluginCatalog is used to create any root-level seals and is then
	// passed on to Core to power External Keys and per-namespace Auto Seals.
	KMSPluginCatalog *kmsplugin.Catalog

	LogLevel string

	Logger log.Logger

	// Use the deadlocks library to detect deadlocks
	DetectDeadlocks string

	// If any role based quota (LCQ or RLQ) is enabled, don't track lease counts by role
	ImpreciseLeaseRoleTracking bool

	// Disables the trace display for Sentinel checks
	DisableSentinelTrace bool

	// Disables the LRU cache on the physical backend
	DisableCache bool

	// Custom cache size for the LRU cache on the physical backend, or zero for default
	CacheSize int

	// Set as the leader address for HA
	RedirectAddr string

	// Set as the cluster address for HA
	ClusterAddr string

	DefaultLeaseTTL time.Duration

	MaxLeaseTTL time.Duration

	ClusterName string

	ClusterCipherSuites string

	EnableUI bool

	// Enable the raw endpoint
	EnableRaw bool

	// Enable the introspection endpoint
	EnableIntrospection bool

	PluginDirectory string

	PluginFileUid int

	PluginFilePermissions int

	DisableSealWrap bool

	RawConfig *server.Config

	ReloadFuncs     *map[string][]reloadutil.ReloadFunc
	ReloadFuncsLock *sync.RWMutex

	DisablePerformanceStandby bool
	DisableIndexing           bool
	DisableKeyEncodingChecks  bool

	AllLoggers []log.Logger

	// Telemetry objects
	MetricsHelper *metricsutil.MetricsHelper
	MetricSink    *metricsutil.ClusterMetricSink

	RecoveryMode bool

	ClusterNetworkLayer cluster.NetworkLayer

	ClusterHeartbeatInterval     time.Duration
	ClusterNamespaceSyncInterval time.Duration

	// number of workers to use for lease revocation in the expiration manager
	NumExpirationWorkers int

	// DisableAutopilot is used to disable autopilot subsystem in raft storage
	DisableAutopilot bool

	// Whether to send headers in the HTTP response showing hostname or raft node ID
	EnableResponseHeaderHostname   bool
	EnableResponseHeaderRaftNodeID bool

	// DisableSSCTokens is used to disable the use of server side consistent tokens
	DisableSSCTokens bool

	EffectiveSDKVersion string

	RollbackPeriod time.Duration

	PendingRemovalMountsAllowed bool

	ExpirationRevokeRetryBase time.Duration

	NumRollbackWorkers int

	// UnsafeCrossNamespaceIdentity is used to comply with Vault Enterprise's
	// loose tenancy separation afforded by their namespace implementation.
	// They allow cross-namespace group association.
	//
	// See also: https://github.com/openbao/openbao/issues/1110
	UnsafeCrossNamespaceIdentity bool

	AllowUnauthenticatedWorkflows bool

	UnsafeRelativePaths bool
}

// GetServiceRegistration returns the config's ServiceRegistration, or nil if it does
// not exist.
func (c *CoreConfig) GetServiceRegistration() sr.ServiceRegistration {
	// Check whether there is a ServiceRegistration explicitly configured
	if c.ServiceRegistration != nil {
		return c.ServiceRegistration
	}

	// Check if HAPhysical is configured and implements ServiceRegistration
	if c.HAPhysical != nil && c.HAPhysical.HAEnabled() {
		if disc, ok := c.HAPhysical.(sr.ServiceRegistration); ok {
			return disc
		}
	}

	// No service discovery is available.
	return nil
}

// CreateCore conducts static validations on the Core Config
// and returns an uninitialized core.
func CreateCore(conf *CoreConfig) (*Core, error) {
	if conf.HAPhysical != nil && conf.HAPhysical.HAEnabled() {
		if conf.RedirectAddr == "" {
			return nil, errors.New("missing API address, please set in configuration or via environment")
		}
	}

	if conf.DefaultLeaseTTL == 0 {
		conf.DefaultLeaseTTL = defaultLeaseTTL
	}
	if conf.MaxLeaseTTL == 0 {
		conf.MaxLeaseTTL = maxLeaseTTL
	}
	if conf.DefaultLeaseTTL > conf.MaxLeaseTTL {
		return nil, errors.New("cannot have DefaultLeaseTTL larger than MaxLeaseTTL")
	}

	// Validate the advertise addr if its given to us
	if conf.RedirectAddr != "" {
		u, err := url.Parse(conf.RedirectAddr)
		if err != nil {
			return nil, fmt.Errorf("redirect address is not valid url: %w", err)
		}

		if u.Scheme == "" {
			return nil, errors.New("redirect address must include scheme (ex. 'http')")
		}
	}

	// Make a default logger if not provided
	if conf.Logger == nil {
		conf.Logger = logging.NewVaultLogger(log.Trace)
	}

	// Make a default metric sink if not provided
	if conf.MetricSink == nil {
		conf.MetricSink = metricsutil.BlackholeSink()
	}

	// Instantiate a non-nil raw config if none is provided
	if conf.RawConfig == nil {
		conf.RawConfig = new(server.Config)
	}

	// Instantiate a KMS plugin catalog if none is provided. This is primarily a
	// fallback for tests that don't run command/server.go startup code.
	if conf.KMSPluginCatalog == nil {
		catalog, err := kmsplugin.NewCatalog(conf.Logger, conf.RawConfig)
		if err != nil {
			return nil, err
		}
		conf.KMSPluginCatalog = catalog
	}

	clusterHeartbeatInterval := conf.ClusterHeartbeatInterval
	if clusterHeartbeatInterval == 0 {
		clusterHeartbeatInterval = 5 * time.Second
	}

	clusterNamespaceSyncInterval := conf.ClusterNamespaceSyncInterval
	if clusterNamespaceSyncInterval == 0 {
		// We don't want namespaces to take forever to unseal, but we also
		// want to avoid spamming the leader. This seems like a reasonable
		// middle ground. By tying it to clusterHeartbeatInterval, tests
		// can run faster automatically.
		clusterNamespaceSyncInterval = 3 * clusterHeartbeatInterval
	}

	if conf.NumExpirationWorkers == 0 {
		conf.NumExpirationWorkers = numExpirationWorkersDefault
	}

	if conf.NumRollbackWorkers == 0 {
		conf.NumRollbackWorkers = RollbackDefaultNumWorkers
	}

	effectiveSDKVersion := conf.EffectiveSDKVersion
	if effectiveSDKVersion == "" {
		effectiveSDKVersion = version.GetVersion().Version
	}

	var detectDeadlocks []string
	if conf.DetectDeadlocks != "" {
		detectDeadlocks = strings.Split(conf.DetectDeadlocks, ",")
		for k, v := range detectDeadlocks {
			detectDeadlocks[k] = strings.ToLower(strings.TrimSpace(v))
		}
	}

	// Use imported logging deadlock if requested
	var stateLock locking.RWMutex
	stateLock = &locking.SyncRWMutex{}

	for _, v := range detectDeadlocks {
		if v == "statelock" {
			stateLock = &locking.DeadlockRWMutex{}
		}
	}

	coreLogger := conf.Logger.Named("core")
	routerLogger := coreLogger.Named("router")

	// Setup the core
	c := &Core{
		devToken:            conf.DevToken,
		physical:            conf.Physical,
		serviceRegistration: conf.GetServiceRegistration(),
		underlyingPhysical:  conf.Physical,
		storageType:         conf.StorageType,
		redirectAddr:        conf.RedirectAddr,
		seal:                conf.Seal,
		stateLock:           stateLock,
		router:              routing.NewRouter(routerLogger),
		baseLogger:          conf.Logger,
		logger:              coreLogger,
		logLevel:            conf.LogLevel,

		defaultLeaseTTL:                conf.DefaultLeaseTTL,
		maxLeaseTTL:                    conf.MaxLeaseTTL,
		sentinelTraceDisabled:          conf.DisableSentinelTrace,
		cachingDisabled:                conf.DisableCache,
		clusterName:                    conf.ClusterName,
		clusterNetworkLayer:            conf.ClusterNetworkLayer,
		clusterPeerClusterAddrsCache:   zcache.New[string, forwarding.NodeHAConnectionInfo](3*clusterHeartbeatInterval, time.Second),
		rawEnabled:                     conf.EnableRaw,
		introspectionEnabled:           conf.EnableIntrospection,
		shutdownDoneCh:                 new(atomic.Value),
		allLoggers:                     conf.AllLoggers,
		builtinRegistry:                conf.BuiltinRegistry,
		kmsPluginCatalog:               conf.KMSPluginCatalog,
		metricsHelper:                  conf.MetricsHelper,
		metricSink:                     conf.MetricSink,
		recoveryMode:                   conf.RecoveryMode,
		raftJoinDoneCh:                 make(chan struct{}),
		pendingRaftPeerChallengeKey:    make([]byte, 32),
		clusterHeartbeatInterval:       clusterHeartbeatInterval,
		clusterNamespaceSyncInterval:   clusterNamespaceSyncInterval,
		numExpirationWorkers:           conf.NumExpirationWorkers,
		raftFollowerStates:             raft.NewFollowerStates(),
		disableAutopilot:               conf.DisableAutopilot,
		enableResponseHeaderHostname:   conf.EnableResponseHeaderHostname,
		enableResponseHeaderRaftNodeID: conf.EnableResponseHeaderRaftNodeID,
		mountMigrationTracker:          &sync.Map{},
		disableSSCTokens:               conf.DisableSSCTokens,
		effectiveSDKVersion:            effectiveSDKVersion,
		userFailedLoginInfo:            make(map[FailedLoginUser]*FailedLoginInfo),
		pendingRemovalMountsAllowed:    conf.PendingRemovalMountsAllowed,
		expirationRevokeRetryBase:      conf.ExpirationRevokeRetryBase,
		numRollbackWorkers:             conf.NumRollbackWorkers,
		impreciseLeaseRoleTracking:     conf.ImpreciseLeaseRoleTracking,
		detectDeadlocks:                detectDeadlocks,
		unsafeCrossNamespaceIdentity:   conf.UnsafeCrossNamespaceIdentity,
		allowUnauthedWorkflows:         conf.AllowUnauthenticatedWorkflows,
		unsafeRelativePaths:            conf.UnsafeRelativePaths,
		namespaceRootGens:              make(map[string]*rootTokenGeneration),
	}

	c.standby.Store(true)
	c.haLoopStopCh.Store(make(chan struct{}, 1))
	c.haLoopRestartCh.Store(make(chan struct{}, 1))
	c.sealed.Store(true)
	c.metricSink.SetGaugeWithLabels([]string{"core", "unsealed"}, 0, nil)

	c.shutdownDoneCh.Store(make(chan struct{}))
	go c.emitUnsealedStatusMetric(c.shutdownDoneCh.Load().(chan struct{}))

	c.allLoggers = append(c.allLoggers, c.logger, routerLogger)

	c.inFlightReqData = &InFlightRequests{
		InFlightReqMap:   &sync.Map{},
		InFlightReqCount: &atomic.Uint64{},
	}

	c.SetConfig(conf.RawConfig)

	c.replicationState.Store(uint32(consts.ReplicationDRDisabled | consts.ReplicationPerformanceDisabled))
	c.clusterAddr.Store(conf.ClusterAddr)
	c.SetKeyRotateGracePeriod(2 * time.Minute)

	// Create a random key for raft peer challenges.
	_, err := io.ReadFull(rand.Reader, c.pendingRaftPeerChallengeKey)
	if err != nil {
		return nil, fmt.Errorf("error initializing pending raft peer challenge key: %w", err)
	}

	switch conf.ClusterCipherSuites {
	case "tls13", "tls12":
		// Do nothing, let Go use the default

	case "":
		// Add in forward compatible TLS 1.3 suites, followed by handpicked 1.2 suites
		c.clusterCipherSuites = []uint16{
			// 1.3
			tls.TLS_AES_128_GCM_SHA256,
			tls.TLS_AES_256_GCM_SHA384,
			tls.TLS_CHACHA20_POLY1305_SHA256,
			// 1.2
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
		}

	default:
		suites, err := tlsutil.ParseCiphers(conf.ClusterCipherSuites)
		if err != nil {
			return nil, fmt.Errorf("error parsing cluster cipher suites: %w", err)
		}
		c.clusterCipherSuites = suites
	}

	// Load CORS config and provide a value for the core field.
	c.corsConfig = &CORSConfig{
		core:    c,
		Enabled: new(uint32),
	}

	// Load write-forwarded path manager.
	c.writeForwardedPaths = pathmanager.New()

	// Load seal information.
	if c.seal == nil {
		c.seal = NewDefaultSeal(vaultseal.NewAccess(vaultseal.NewShamirWrapper()))
	}
	c.seal.SetCore(c)

	// Create the invalidation manager and track connected peers for GRPC.
	c.NewInvalidationManager()
	c.NewInvalidationPeers()

	if replicated, ok := c.underlyingPhysical.(physical.ReplicationIndexBackend); ok {
		c.indexManager = NewIndexManager(replicated, c.invalidations, 0)
	}

	return c, nil
}

func coreInit(c *Core, conf *CoreConfig) error {
	phys := conf.Physical
	hookLayer := c.underlyingPhysical

	haEnabled := conf.HAPhysical != nil && conf.HAPhysical.HAEnabled()

	// Wrap the physical backend in a cache layer if enabled
	cacheLogger := c.baseLogger.Named("storage.cache")

	// Wrap physical for invalidation.
	if haEnabled && shouldUseGRPCInvalidation(phys) {
		c.logger.Info("enabling grpc-based invalidation on HA backend which doesn't natively support invalidation notifications")

		grpcLogger := c.baseLogger.Named("storage.grpcinv")
		c.allLoggers = append(c.allLoggers, grpcLogger)

		phys = physical.NewWriteNotifier(phys, grpcLogger, c.SendInvalidationNotice)
		hookLayer = phys
	}

	c.allLoggers = append(c.allLoggers, cacheLogger)
	c.physical = physical.NewCache(phys, conf.CacheSize, cacheLogger, c.MetricSink().Sink)
	c.physicalCache = c.physical.(physical.ToggleablePurgemonster)

	// Wrap in encoding checks
	if !conf.DisableKeyEncodingChecks {
		c.physical = physical.NewStorageEncoding(c.physical)
	}

	if haEnabled && c.shouldHookInvalidate(hookLayer) {
		hookLayer.(physical.CacheInvalidationBackend).HookInvalidate(c.Invalidate)
	}

	return nil
}

// NewCore creates, initializes and configures a Vault node (core).
func NewCore(conf *CoreConfig) (*Core, error) {
	// NOTE: The order of configuration of the core has some importance, as we can
	// make use of an early return if we are running this new core in recovery mode.
	c, err := CreateCore(conf)
	if err != nil {
		return nil, err
	}

	err = coreInit(c, conf)
	if err != nil {
		return nil, err
	}

	if c.recoveryMode {
		// When in recovery mode, assign a default context during startup.
		ctx, cancel := context.WithCancel(context.Background())
		c.activeContext.Store(NewAtomicContext(ctx, cancel))
	}

	// Construct a new AES-GCM barrier
	c.barrier = barrier.NewAESGCMBarrier(c.physical, nil)
	c.SetupSealManager()

	// We create the funcs here, then populate the given config with it so that
	// the caller can share state
	conf.ReloadFuncsLock = &c.reloadFuncsLock
	c.reloadFuncsLock.Lock()
	c.reloadFuncs = make(map[string][]reloadutil.ReloadFunc)
	c.reloadFuncsLock.Unlock()
	conf.ReloadFuncs = &c.reloadFuncs

	c.rollbackPeriod = conf.RollbackPeriod
	if c.rollbackPeriod == 0 {
		// Default to 1 minute
		c.rollbackPeriod = 1 * time.Minute
	}

	// For recovery mode we've now configured enough to return early.
	if c.recoveryMode {
		return c, nil
	}

	if conf.PluginDirectory != "" {
		c.pluginDirectory, err = filepath.Abs(conf.PluginDirectory)
		if err != nil {
			return nil, fmt.Errorf("core setup failed, could not verify plugin directory: %w", err)
		}
	}

	if conf.PluginFileUid != 0 {
		c.pluginFileUid = conf.PluginFileUid
	}
	if conf.PluginFilePermissions != 0 {
		c.pluginFilePermissions = conf.PluginFilePermissions
	}

	if conf.HAPhysical != nil && conf.HAPhysical.HAEnabled() {
		c.ha = conf.HAPhysical
	}

	// MFA method
	c.loginMFABackend, err = NewLoginMFABackend(c, conf.Logger)
	if err != nil {
		return nil, err
	}

	// Logical backends
	c.configureLogicalBackends(conf.LogicalBackends, conf.Logger)

	// Credentials backends
	c.configureCredentialsBackends(conf.CredentialBackends, conf.Logger)

	// Audit backends
	c.configureAuditBackends(conf.AuditBackends)

	// UI
	uiStoragePrefix := barrier.SystemBarrierPrefix + "ui"
	c.uiConfig = NewUIConfig(conf.EnableUI, physical.NewView(c.physical, uiStoragePrefix), barrier.NewView(c.barrier, uiStoragePrefix))

	// Listeners
	err = c.configureListeners(conf)
	if err != nil {
		return nil, err
	}

	// Log requests level
	c.configureLogRequestsLevel(conf.RawConfig.LogRequestsLevel)

	// Quotas
	quotasLogger := conf.Logger.Named("quotas")
	c.allLoggers = append(c.allLoggers, quotasLogger)

	detectDeadlocks := false
	for _, v := range c.detectDeadlocks {
		if v == "quotas" {
			detectDeadlocks = true
		}
	}

	c.quotaManager, err = quotas.NewManager(quotasLogger, c.metricSink, detectDeadlocks)
	if err != nil {
		return nil, err
	}

	err = c.adjustForSealMigration(conf.UnwrapSeal)
	if err != nil {
		return nil, err
	}

	// Version history
	if c.versionHistory == nil {
		c.logger.Info("Initializing version history cache for core")
		c.versionHistory = make(map[string]VaultVersion)
	}

	return c, nil
}

// configureListeners configures the Core with the listeners from the CoreConfig.
func (c *Core) configureListeners(conf *CoreConfig) error {
	c.clusterListener.Store(nil)

	if conf.RawConfig.Listeners == nil {
		c.customListenerHeader.Store(nil)
		return nil
	}

	uiHeaders, err := c.UIHeaders()
	if err != nil {
		return err
	}

	c.customListenerHeader.Store(NewListenerCustomHeader(conf.RawConfig.Listeners, c.logger, uiHeaders))

	return nil
}

// configureLogRequestsLevel configures the Core with the supplied log requests level.
func (c *Core) configureLogRequestsLevel(level string) {
	lvl := log.LevelFromString(level)

	switch {
	case lvl > log.NoLevel && lvl < log.Off:
		c.logRequestsLevel.Store(int32(lvl))
	case level != "":
		c.logger.Warn("invalid log_requests_level", "level", level)
	}
}

// configureAuditBackends configures the Core with the ability to create audit
// backends for various types.
func (c *Core) configureAuditBackends(backends map[string]audit.Factory) {
	auditBackends := make(map[string]audit.Factory, len(backends))

	maps.Copy(auditBackends, backends)

	c.auditBackends = auditBackends
}

// configureCredentialsBackends configures the Core with the ability to create
// credential backends for various types.
func (c *Core) configureCredentialsBackends(backends map[string]logical.Factory, logger log.Logger) {
	credentialBackends := make(map[string]logical.Factory, len(backends))

	maps.Copy(credentialBackends, backends)

	credentialBackends[routing.MountTypeToken] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		tsLogger := logger.Named("token")
		c.AddLogger(tsLogger)
		return NewTokenStore(ctx, tsLogger, c, config)
	}
	credentialBackends[routing.MountTypeNSToken] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		if c.tokenStore != nil {
			return c.tokenStore, nil
		}
		return nil, errors.New("token store does not exist")
	}

	c.credentialBackends = credentialBackends
}

// configureLogicalBackends configures the Core with the ability to create
// logical backends for various types.
func (c *Core) configureLogicalBackends(backends map[string]logical.Factory, logger log.Logger) {
	logicalBackends := make(map[string]logical.Factory, len(backends))

	maps.Copy(logicalBackends, backends)

	// KV
	_, ok := logicalBackends[routing.MountTypeKV]
	if !ok {
		logicalBackends[routing.MountTypeKV] = PassthroughBackendFactory
	}

	// Cubbyhole
	logicalBackends[routing.MountTypeCubbyhole] = CubbyholeBackendFactory
	logicalBackends[routing.MountTypeNSCubbyhole] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		if c.cubbyholeBackend != nil {
			return c.cubbyholeBackend, nil
		}
		return nil, errors.New("cubbyhole backend does not exist")
	}

	// System
	logicalBackends[routing.MountTypeSystem] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		sysBackendLogger := logger.Named("system")
		c.AddLogger(sysBackendLogger)
		b := NewSystemBackend(c, sysBackendLogger)
		return b, b.Setup(ctx, config)
	}
	logicalBackends[routing.MountTypeNSSystem] = func(ctx context.Context, bc *logical.BackendConfig) (logical.Backend, error) {
		if c.systemBackend != nil {
			return c.systemBackend, nil
		}
		return nil, errors.New("system backend does not exist")
	}

	// Identity
	logicalBackends[routing.MountTypeIdentity] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		identityLogger := logger.Named("identity")
		c.AddLogger(identityLogger)
		identityStoreConfig := &ident.IdentityStoreConfig{
			Logger:        c.Logger(),
			Router:        c.router,
			RedirectAddr:  c.redirectAddr,
			LocalNode:     c,
			Namespacer:    c,
			MetricsSink:   c.metricSink,
			TOTPPersister: c,
			TokenStorer:   c,
			MFABackend:    c.loginMFABackend,
			LoggerAdder:   c,
		}
		return ident.NewIdentityStore(ctx, identityStoreConfig, config, identityLogger)
	}
	logicalBackends[routing.MountTypeNSIdentity] = func(ctx context.Context, config *logical.BackendConfig) (logical.Backend, error) {
		if c.identityStore != nil {
			ns, err := namespace.FromContext(ctx)
			if err != nil {
				return nil, err
			}

			if err := c.identityStore.AddNamespaceView(c, ns, config.StorageView); err != nil {
				return nil, fmt.Errorf("failed to register namespace to identity store: %w", err)
			}
			return c.identityStore, nil
		}
		return nil, errors.New("identity store does not exist")
	}

	c.logicalBackends = logicalBackends
}

// handleVersionTimeStamps stores the current version at the current time to
// storage, and then loads all versions and upgrade timestamps out from storage.
func (c *Core) handleVersionTimeStamps(ctx context.Context) error {
	currentTime := time.Now().UTC()

	vaultVersion := &VaultVersion{
		TimestampInstalled: currentTime,
		Version:            version.Version,
		CommitDate:         version.CommitDate,
	}

	isUpdated, err := c.storeVersionEntry(ctx, vaultVersion, false)
	if err != nil {
		return fmt.Errorf("error storing vault version: %w", err)
	}
	if isUpdated {
		c.logger.Info("Recorded vault version", "vault version", version.Version, "upgrade time", currentTime, "commit date", version.CommitDate)
	}

	// Finally, repopulate the version history cache
	err = c.loadVersionHistory(ctx)
	if err != nil {
		return err
	}
	return nil
}

// HostnameHeaderEnabled determines whether to add the X-Vault-Hostname header
// to HTTP responses.
func (c *Core) HostnameHeaderEnabled() bool {
	return c.enableResponseHeaderHostname
}

// RaftNodeIDHeaderEnabled determines whether to add the X-Vault-Raft-Node-ID header
// to HTTP responses.
func (c *Core) RaftNodeIDHeaderEnabled() bool {
	return c.enableResponseHeaderRaftNodeID
}

// DisableSSCTokens determines whether to use server side consistent tokens or not.
func (c *Core) DisableSSCTokens() bool {
	return c.disableSSCTokens
}

// ShutdownCoreError logs a shutdown error and shuts down the Vault core.
func (c *Core) ShutdownCoreError(err error) {
	c.Logger().Error("shutting down core", "error", err)
	if shutdownErr := c.ShutdownWait(); shutdownErr != nil {
		c.Logger().Error("failed to shutdown core", "error", shutdownErr)
	}
}

// Shutdown is invoked when the Vault instance is about to be terminated. It
// should not be accessible as part of an API call as it will cause an availability
// problem. It is only used to gracefully quit in the case of HA so that failover
// happens as quickly as possible.
func (c *Core) Shutdown() error {
	c.logger.Debug("shutdown called")
	err := c.sealInternal()

	c.stateLock.Lock()
	defer c.stateLock.Unlock()

	doneCh := c.shutdownDoneCh.Load().(chan struct{})
	if doneCh != nil {
		close(doneCh)
		c.shutdownDoneCh.Store((chan struct{})(nil))
	}

	return err
}

func (c *Core) ShutdownWait() error {
	donech := c.ShutdownDone()
	err := c.Shutdown()
	if donech != nil {
		<-donech
	}
	return err
}

// ShutdownDone returns a channel that will be closed after Shutdown completes
func (c *Core) ShutdownDone() <-chan struct{} {
	return c.shutdownDoneCh.Load().(chan struct{})
}

// CORSConfig returns the current CORS configuration
func (c *Core) CORSConfig() *CORSConfig {
	return c.corsConfig
}

func (c *Core) GetContext() (context.Context, context.CancelFunc) {
	c.stateLock.RLock()
	defer c.stateLock.RUnlock()

	return context.WithCancel(namespace.RootContext(c.activeContext.Load()))
}

// Sealed checks if the Vault is currently sealed
func (c *Core) Sealed() bool {
	return c.sealed.Load()
}

// NamespaceSealed checks if there's a namespace
// (in direct ancestry line) that is currently sealed.
func (c *Core) NamespaceSealed(ns *namespace.Namespace) bool {
	return c.sealManager.NamespaceBarrierByLongestPrefix(ns.Path).Sealed()
}

// ResetUnsealProcess removes the current unlock parts from memory, to reset
// the unsealing process
func (c *Core) ResetUnsealProcess() {
	c.sealManager.ResetUnsealProcess(namespace.RootNamespaceUUID)
}

func (c *Core) UnsealMigrate(key []byte) (bool, error) {
	err := c.unsealFragment(key, true)
	return !c.Sealed(), err
}

// Unseal is used to provide one of the key parts to unseal the Vault.
func (c *Core) Unseal(key []byte) (bool, error) {
	err := c.unsealFragment(key, false)
	return !c.Sealed(), err
}

// unseal takes a key fragment and attempts to use it to unseal Vault.
// Vault may remain sealed afterwards even when no error is returned,
// depending on whether enough key fragments were provided to meet the
// target threshold.
//
// The provided key should be a recovery key fragment if the seal
// is an autoseal, or a regular seal key fragment for shamir. In
// migration scenarios "seal" in the preceding sentence refers to
// the migration seal in c.migrationInfo.seal.
//
// We use getUnsealKey to work out if we have enough fragments,
// and if we don't have enough we return early. Otherwise we get
// back the combined key.
//
// For shamir the combined key is used to decrypt the root key
// read from storage. For autoseal the combined key isn't used
// except to verify that the stored recovery key matches.
//
// In migration scenarios a side-effect of unsealing is that
// the members of c.migrationInfo are populated (excluding
// .seal, which must already be populated before unseal is called).
func (c *Core) unsealFragment(key []byte, migrate bool) error {
	defer metrics.MeasureSince([]string{"core", "unseal"}, time.Now())

	c.stateLock.Lock()
	defer c.stateLock.Unlock()

	ctx := namespace.RootContext(context.Background())
	if migrate && c.migrationInfo == nil {
		return errors.New("can't perform a seal migration, no migration seal found")
	}
	if migrate && c.isRaftUnseal() {
		return errors.New("can't perform a seal migration while joining a raft cluster")
	}
	if !migrate && c.migrationInfo != nil {
		done, err := c.sealMigrated(ctx)
		if err != nil {
			return fmt.Errorf("error checking to see if seal is migrated: %w", err)
		}
		if !done {
			return errors.New("migrate option not provided and seal migration is pending")
		}
	}

	c.logger.Debug("unseal key supplied", "migrate", migrate)

	// Explicitly check for init status. This also checks if the seal
	// configuration is valid (i.e. non-nil).
	init, err := c.Initialized(ctx)
	if err != nil {
		return err
	}
	if !init && !c.isRaftUnseal() {
		return ErrNotInit
	}

	// Check if already unsealed
	if !c.Sealed() {
		return nil
	}

	sealToUse := c.seal
	if migrate {
		c.logger.Info("unsealing using migration seal")
		sealToUse = c.migrationInfo.seal
	}

	combinedKey, err := c.sealManager.unsealFragment(ctx, namespace.RootNamespace, sealToUse, c.barrier, key)
	if err != nil || combinedKey == nil {
		return err
	}

	if migrate {
		c.migrationInfo.unsealKey = combinedKey
	}

	if c.isRaftUnseal() {
		return c.unsealWithRaft(combinedKey)
	}

	rootKey, err := c.sealManager.unsealKeyToRootKey(ctx, sealToUse, combinedKey, false, true)
	if err != nil {
		return err
	}

	return c.unsealInternal(ctx, rootKey)
}

func (c *Core) unsealWithRaft(combinedKey []byte) error {
	ctx := context.Background()

	if c.seal.BarrierType() == vaultseal.WrapperTypeShamir {
		shamirWrapper, err := c.seal.GetShamirWrapper()
		if err == nil {
			if err = shamirWrapper.SetAesGcmKeyBytes(combinedKey); err != nil {
				return err
			}
		}
	}

	raftInfo := c.raftInfo.Load()
	if raftInfo == nil {
		return errors.New("raft information missing")
	}

	if raftInfo.joinInProgress {
		// JoinRaftCluster is already trying to perform a join based on retry_join configuration.
		// Inform that routine that unseal key validation is complete so that it can continue to
		// try and join possible leader nodes, and wait for it to complete.

		c.postUnsealStarted.Store(true)
		c.logger.Info("waiting for raft retry join process to complete")
		<-c.raftJoinDoneCh
	} else {
		// This is the case for manual raft join. Send the answer to the leader node and
		// wait for data to start streaming in.
		if err := c.joinRaftSendAnswer(ctx, c.seal.GetAccess(), raftInfo); err != nil {
			return err
		}
		// Reset the state
		c.raftInfo.Store(nil)
	}

	go func() {
		var rootKey []byte
		keyringFound := false

		// Wait until we at least have the keyring before we attempt to
		// unseal the node.
		for {
			if !keyringFound {
				entry, err := c.underlyingPhysical.Get(ctx, barrier.KeyringPath)
				if err != nil {
					c.logger.Error("failed to list physical keys", "error", err)
					return
				}
				if entry != nil {
					keyringFound = true
				}
			}
			if keyringFound && len(rootKey) == 0 {
				var err error
				rootKey, err = c.sealManager.unsealKeyToRootKey(ctx, c.seal, combinedKey, false, true)
				if err != nil {
					c.logger.Error("failed to read root key", "error", err)
					return
				}
			}
			if keyringFound && len(rootKey) > 0 {
				err := c.unsealInternal(ctx, rootKey)
				if err != nil {
					c.logger.Error("failed to unseal", "error", err)
				}
				return
			}
			time.Sleep(1 * time.Second)
		}
	}()

	return nil
}

// sealMigrated must be called with the stateLock held. It returns true if
// the seal configured in HCL and the seal configured in storage match.
// For the auto->auto same seal migration scenario, it will return false even
// if the preceding conditions are true but we cannot decrypt the root key
// in storage using the configured seal.
func (c *Core) sealMigrated(ctx context.Context) (bool, error) {
	if c.sealMigrationDone.Load() {
		return true, nil
	}

	existBarrierSealConfig, existRecoverySealConfig, err := c.PhysicalSealConfigs(ctx)
	if err != nil {
		return false, err
	}

	if existBarrierSealConfig.Type != c.seal.BarrierType().String() {
		return false, nil
	}
	if c.seal.RecoveryKeySupported() && existRecoverySealConfig.Type != c.seal.RecoveryType() {
		return false, nil
	}

	if c.seal.BarrierType() != c.migrationInfo.seal.BarrierType() {
		return true, nil
	}

	// The above checks can handle the auto->shamir and shamir->auto
	// and auto1->auto2 cases.  For auto1->auto1, we need to actually try
	// to read and decrypt the keys.

	keysMig, errMig := c.migrationInfo.seal.GetStoredKeys(ctx)
	keys, err := c.seal.GetStoredKeys(ctx)

	switch {
	case len(keys) > 0 && err == nil:
		return true, nil
	case len(keysMig) > 0 && errMig == nil:
		return false, nil
	case errors.Is(err, &ErrDecrypt{}) && errors.Is(errMig, &ErrDecrypt{}):
		return false, fmt.Errorf("decrypt error, neither the old nor new seal can read stored keys: old seal err=%v, new seal err=%v", errMig, err)
	default:
		return false, fmt.Errorf("neither the old nor new seal can read stored keys: old seal err=%v, new seal err=%v", errMig, err)
	}
}

// migrateSeal must be called with the stateLock held.
func (c *Core) migrateSeal(ctx context.Context) error {
	if c.migrationInfo == nil {
		return nil
	}

	ok, err := c.sealMigrated(ctx)
	if err != nil {
		return fmt.Errorf("error checking if seal is migrated or not: %w", err)
	}

	if ok {
		c.logger.Info("migration is already performed")
		return nil
	}

	c.logger.Info("seal migration initiated")

	switch {
	case c.migrationInfo.seal.RecoveryKeySupported() && c.seal.RecoveryKeySupported():
		c.logger.Info("migrating from one auto-unseal to another", "from",
			c.migrationInfo.seal.BarrierType(), "to", c.seal.BarrierType())

		// Set the recovery and barrier keys to be the same.
		recoveryKey, err := c.migrationInfo.seal.RecoveryKey(ctx)
		if err != nil {
			return fmt.Errorf("error getting recovery key to set on new seal: %w", err)
		}

		if err := c.seal.SetRecoveryKey(ctx, recoveryKey); err != nil {
			return fmt.Errorf("error setting new recovery key information during migrate: %w", err)
		}

		barrierKeys, err := c.migrationInfo.seal.GetStoredKeys(ctx)
		if err != nil {
			return fmt.Errorf("error getting stored keys to set on new seal: %w", err)
		}

		if err := c.seal.SetStoredKeys(ctx, barrierKeys); err != nil {
			return fmt.Errorf("error setting new barrier key information during migrate: %w", err)
		}

	case c.migrationInfo.seal.RecoveryKeySupported():
		c.logger.Info("migrating from one auto-unseal to shamir", "from", c.migrationInfo.seal.BarrierType())
		// Auto to Shamir, since recovery key isn't supported on new seal

		recoveryKey, err := c.migrationInfo.seal.RecoveryKey(ctx)
		if err != nil {
			return fmt.Errorf("error getting recovery key to set on new seal: %w", err)
		}

		// We have recovery keys; we're going to use them as the new shamir KeK.
		shamirWrapper, err := c.seal.GetShamirWrapper()
		if err != nil {
			return err
		}
		err = shamirWrapper.SetAesGcmKeyBytes(recoveryKey)
		if err != nil {
			return fmt.Errorf("failed to set root key in seal: %w", err)
		}

		barrierKeys, err := c.migrationInfo.seal.GetStoredKeys(ctx)
		if err != nil {
			return fmt.Errorf("error getting stored keys to set on new seal: %w", err)
		}

		if err := c.seal.SetStoredKeys(ctx, barrierKeys); err != nil {
			return fmt.Errorf("error setting new barrier key information during migrate: %w", err)
		}

	case c.seal.RecoveryKeySupported():
		c.logger.Info("migrating from shamir to auto-unseal", "to", c.seal.BarrierType())
		// Migration is happening from shamir -> auto. In this case use the shamir
		// combined key that was used to store the root key as the new recovery key.
		if err := c.seal.SetRecoveryKey(ctx, c.migrationInfo.unsealKey); err != nil {
			return fmt.Errorf("error setting new recovery key information: %w", err)
		}

		// Generate a new root key
		newRootKey, err := c.barrier.GenerateKey()
		if err != nil {
			return fmt.Errorf("error generating new root key: %w", err)
		}

		// Rotate the root key
		if err := c.barrier.RotateRootKey(ctx, newRootKey); err != nil {
			return fmt.Errorf("error rotating root key during migration: %w", err)
		}

		// Store the new root key
		if err := c.seal.SetStoredKeys(ctx, [][]byte{newRootKey}); err != nil {
			return fmt.Errorf("error storing new root key: %w", err)
		}

	default:
		return errors.New("unhandled migration case (shamir to shamir)")
	}

	err = c.migrateSealConfig(ctx)
	if err != nil {
		return fmt.Errorf("error storing new seal configs: %w", err)
	}

	// Flag migration performed for seal-rewrap later
	c.sealMigrationDone.Store(true)

	c.logger.Info("seal migration complete")
	return nil
}

// unsealInternal takes in the root key and attempts to unseal the barrier.
// N.B.: This must be called with the state write lock held.
func (c *Core) unsealInternal(ctx context.Context, rootKey []byte) error {
	// Attempt to unlock
	if err := c.barrier.Unseal(ctx, rootKey); err != nil {
		return err
	}

	if err := c.checkSelfInit(ctx); err != nil {
		return err
	}

	if err := c.startClusterListener(ctx); err != nil {
		return err
	}

	if err := c.startRaftBackend(ctx); err != nil {
		return err
	}

	// Do post-unseal setup if HA is not enabled
	if c.ha == nil {
		runPostUnseal := func(context.Context) error {
			// We still need to set up cluster info even if it's not part of a
			// cluster right now. This also populates the cached cluster object.
			if err := c.setupCluster(ctx); err != nil {
				c.logger.Error("cluster setup failed", "error", err)
				return err
			}

			if err := c.migrateSeal(ctx); err != nil {
				c.logger.Error("seal migration error", "error", err)
				return err
			}

			ctx, ctxCancel := context.WithCancel(namespace.RootContext(context.Background()))
			if err := c.postUnseal(ctx, ctxCancel, standardUnsealStrategy{}); err != nil {
				c.logger.Error("post-unseal setup failed", "error", err)
				return err
			}
			return nil
		}

		if err := runPostUnseal(ctx); err != nil {
			err = errors.Join(err, c.sealManager.sealAll())
			c.logger.Warn("OpenBao is sealed")
			return err
		}

		// Force a cache bust here, which will also run migration code
		if c.seal.RecoveryKeySupported() {
			c.seal.SetRecoveryConfig(ctx, nil)
		}

		c.standby.Store(false)
	} else {
		// Go to standby mode, wait until we are active to unseal
		c.haLoopDoneCh = make(chan struct{})
		c.manualStepDownCh = make(chan struct{}, 1)
		c.haLoopStopCh.Store(make(chan struct{}, 1))
		c.haLoopRestartCh.Store(make(chan struct{}, 1))
		go c.runHALoop(c.haLoopDoneCh, c.manualStepDownCh, c.haLoopStopCh.Load().(chan struct{}), c.haLoopRestartCh.Load().(chan struct{}))
	}

	// Success!
	c.sealed.Store(false)
	c.metricSink.SetGaugeWithLabels([]string{"core", "unsealed"}, 1, nil)

	c.logger.Info("vault is unsealed")

	if c.serviceRegistration != nil {
		if err := c.serviceRegistration.NotifySealedStateChange(false); err != nil {
			c.logger.Warn("failed to notify unsealed status", "error", err)
		}
		if err := c.serviceRegistration.NotifyInitializedStateChange(true); err != nil {
			c.logger.Warn("failed to notify initialized status", "error", err)
		}
	}
	return nil
}

// SealWithRequest takes in a logical.Request, acquires the lock, and passes
// through to sealInternal
func (c *Core) SealWithRequest(httpCtx context.Context, req *logical.Request) error {
	defer metrics.MeasureSince([]string{"core", "seal-with-request"}, time.Now())

	if c.Sealed() {
		return nil
	}

	c.stateLock.RLock()

	// This will unlock the read lock
	// We use background context since we may not be active
	ctx, cancel := context.WithCancel(namespace.RootContext(context.TODO()))
	defer cancel()

	go func() {
		select {
		case <-ctx.Done():
		case <-httpCtx.Done():
			cancel()
		}
	}()

	// This will unlock the read lock
	return c.sealInitCommon(ctx, req)
}

// Seal takes in a token and creates a logical.Request, acquires the lock, and
// passes through to sealInternal
func (c *Core) Seal(token string) error {
	defer metrics.MeasureSince([]string{"core", "seal"}, time.Now())

	if c.Sealed() {
		return nil
	}

	c.stateLock.RLock()

	req := &logical.Request{
		Operation:   logical.UpdateOperation,
		Path:        "sys/seal",
		ClientToken: token,
	}

	// This will unlock the read lock
	// We use background context since we may not be active
	return c.sealInitCommon(namespace.RootContext(context.TODO()), req)
}

// sealInitCommon is common logic for Seal and SealWithRequest and is used to
// re-seal the Vault. This requires the Vault to be unsealed again to perform
// any further operations. Note: this function will read-unlock the state lock.
func (c *Core) sealInitCommon(ctx context.Context, req *logical.Request) (retErr error) {
	defer metrics.MeasureSince([]string{"core", "seal-internal"}, time.Now())

	var unlocked bool
	defer func() {
		if !unlocked {
			c.stateLock.RUnlock()
		}
	}()

	if req == nil {
		return errors.New("nil request to seal")
	}

	// Since there is no token store in true standby nodes, sealing cannot
	// be done. Ideally, the request has to be forwarded to leader node for
	// validation and the operation should be performed. But for now, just
	// returning with an error and recommending a vault restart, which
	// essentially does the same thing.
	if c.standby.Load() && c.activeContext.Load().IsNil() {
		c.logger.Error("vault cannot seal when in standby mode; please restart instead")
		return errors.New("vault cannot seal when in standby mode; please restart instead")
	}

	err := c.PopulateTokenEntry(ctx, req)
	if err != nil {
		if errwrap.Contains(err, logical.ErrPermissionDenied.Error()) {
			return logical.ErrPermissionDenied
		}
		return logical.ErrInvalidRequest
	}
	acl, te, entity, identityPolicies, err := c.fetchACLTokenEntryAndEntity(ctx, req)
	if err != nil {
		return err
	}

	// Audit-log the request before going any further
	auth := &logical.Auth{
		ClientToken: req.ClientToken,
		Accessor:    req.ClientTokenAccessor,
	}
	if te != nil {
		auth.IdentityPolicies = identityPolicies[te.NamespaceID]
		delete(identityPolicies, te.NamespaceID)
		auth.ExternalNamespacePolicies = identityPolicies
		auth.TokenPolicies = te.Policies
		auth.Policies = append(te.Policies, identityPolicies[te.NamespaceID]...)
		auth.Metadata = te.Meta
		auth.DisplayName = te.DisplayName
		auth.EntityID = te.EntityID
		auth.TokenType = te.Type
	}

	logInput := &logical.LogInput{
		Auth:    auth,
		Request: req,
	}
	if err := c.auditBroker.LogRequest(ctx, logInput, c.auditedHeaders); err != nil {
		c.logger.Error("failed to audit request", "request_path", req.Path, "error", err)
		return errors.New("failed to audit request, cannot continue")
	}

	if entity != nil && entity.Disabled {
		c.logger.Warn("permission denied as the entity on the token is disabled")
		return logical.ErrPermissionDenied
	}
	if te != nil && te.EntityID != "" && entity == nil {
		c.logger.Warn("permission denied as the entity on the token is invalid")
		return logical.ErrPermissionDenied
	}

	// Attempt to use the token (decrement num_uses)
	// On error bail out; if the token has been revoked, bail out too
	if te != nil {
		te, err = c.tokenStore.UseToken(ctx, te)
		if err != nil {
			c.logger.Error("failed to use token", "error", err)
			return ErrInternalError
		}
		if te == nil {
			// Token is no longer valid
			return logical.ErrPermissionDenied
		}
	}

	// Verify that this operation is allowed
	authResults := c.performPolicyChecks(ctx, acl, te, req, entity, &policy.CheckOpts{
		RootPrivsRequired: true,
	})
	if !authResults.Allowed {
		retErr = multierror.Append(retErr, authResults.Error)
		if authResults.Error.ErrorOrNil() == nil || authResults.DeniedError {
			retErr = multierror.Append(retErr, logical.ErrPermissionDenied)
		}
		return retErr
	}

	if te != nil && te.NumUses == tokenRevocationPending {
		// Token needs to be revoked. We do this immediately here because
		// we won't have a token store after sealing.
		leaseID, err := c.expiration.CreateOrFetchRevocationLeaseByToken(c.activeContext.Load(), te)
		if err == nil {
			err = c.expiration.Revoke(c.activeContext.Load(), leaseID)
		}
		if err != nil {
			c.logger.Error("token needed revocation before seal but failed to revoke", "error", err)
			retErr = multierror.Append(retErr, ErrInternalError)
		}
	}

	// Unlock; sealing will grab the lock when needed
	unlocked = true
	c.stateLock.RUnlock()

	sealErr := c.sealInternal()

	if sealErr != nil {
		retErr = multierror.Append(retErr, sealErr)
	}

	return retErr
}

// UIEnabled returns if the UI is enabled
func (c *Core) UIEnabled() bool {
	return c.uiConfig.Enabled()
}

// UIHeaders returns configured UI headers
func (c *Core) UIHeaders() (http.Header, error) {
	return c.uiConfig.Headers(context.Background())
}

// sealInternal is an internal method used to seal the vault.  It does not do
// any authorization checking.
func (c *Core) sealInternal() error {
	return c.sealInternalWithOptions(true)
}

func (c *Core) sealInternalWithOptions(grabStateLock bool) error {
	// Mark sealed, and if already marked return
	if swapped := c.sealed.CompareAndSwap(false, true); !swapped {
		return nil
	}
	c.metricSink.SetGaugeWithLabels([]string{"core", "unsealed"}, 0, nil)

	c.logger.Info("marked as sealed")

	// Clear forwarding clients
	c.clearForwardingClients()

	activeCtxCancel := c.activeContext.Load().Canceler()
	cancelCtxAndLock := func() {
		doneCh := make(chan struct{})
		go func() {
			select {
			case <-doneCh:
			// Attempt to drain any inflight requests
			case <-time.After(DefaultMaxRequestDuration):
				activeCtxCancel()
			}
		}()

		// Stop the HA loop before attempting to acquire the state lock. This
		// will prevent a race condition between runHALoop and this method.
		c.stopHALoop()

		// Acquire the state lock.
		c.stateLock.Lock()
		close(doneCh)

		// Stop requests from processing
		activeCtxCancel()
	}

	// Do pre-seal teardown if HA is not enabled
	if c.ha == nil {
		if grabStateLock {
			cancelCtxAndLock()
			defer c.stateLock.Unlock()
		}
		// Even in a non-HA context we key off of this for some things
		c.standby.Store(true)

		// Stop requests from processing
		activeCtxCancel()
	} else {
		// If we are keeping the lock we already have the state write lock
		// held. Otherwise grab it here so that when stopCh is triggered we are
		// locked.
		if grabStateLock {
			cancelCtxAndLock()
			defer c.stateLock.Unlock()
		}

		// If we are trying to acquire the lock, force it to return with nil so
		// runHALoop will exit. If we are active, signal the standby goroutine
		// to shut down and wait for completion. We have the state lock here so
		// nothing else should be toggling standby status.
		close(c.haLoopStopCh.Load().(chan struct{}))
		c.logger.Debug("finished triggering haLoopCh for runHALoop")

		// Wait for runHALoop to stop.
		<-c.haLoopDoneCh
		c.logger.Debug("runHALoop done")

		// Stop requests from processing.
		activeCtxCancel()
	}

	// Stop all running subsystems.
	if err := c.preSeal(); err != nil {
		c.logger.Error("pre-seal teardown failed", "error", err)
		return errors.New("internal error")
	}

	// Perform additional cleanup upon sealing.
	if raftBackend := c.GetRaftBackend(); raftBackend != nil {
		if err := raftBackend.TeardownCluster(c.getClusterListener()); err != nil {
			c.logger.Error("error stopping storage cluster", "error", err)
			return err
		}
	}

	// Stop the cluster listener
	c.stopClusterListener()

	c.logger.Debug("sealing all barriers")
	if err := c.sealManager.sealAll(); err != nil {
		c.logger.Error("error sealing barriers", "error", err)
		return err
	}

	if c.serviceRegistration != nil {
		if err := c.serviceRegistration.NotifySealedStateChange(true); err != nil {
			c.logger.Warn("failed to notify sealed status", "error", err)
		}
	}

	if c.quotaManager != nil {
		if err := c.quotaManager.Reset(); err != nil {
			c.logger.Error("error resetting quota manager", "error", err)
		}
	}

	c.logger.Info("vault is sealed")

	return nil
}

type UnsealStrategy interface {
	unseal(context.Context, log.Logger, *Core) error
}

type standardUnsealStrategy struct {
	// Inherit read-only unseal methods
	readonlyUnsealStrategy
}

func (s standardUnsealStrategy) unseal(ctx context.Context, logger log.Logger, c *Core) error {
	c.logger.Debug("standard unseal starting")

	// Clear forwarding clients; we're active
	c.clearForwardingClients()

	if shouldUseGRPCInvalidation(c.underlyingPhysical) {
		c.SetupInvalidationPeers()
	}

	// Mark the active time. We do this first so it can be correlated to the logs
	// for the active startup.
	c.activeTime = time.Now().UTC()

	if c.autoRotateCancel == nil {
		var autoRotateCtx context.Context
		autoRotateCtx, c.autoRotateCancel = context.WithCancel(c.activeContext.Load())
		go c.autoRotateBarrierLoop(autoRotateCtx)
	}

	if err := c.ensureWrappingKey(ctx); err != nil {
		return err
	}

	if err := s.unsealShared(ctx, c, false /* active */); err != nil {
		return err
	}

	if c.getClusterListener() != nil {
		if err := c.setupRaftActiveNode(ctx); err != nil {
			return err
		}
		if err := c.startForwarding(ctx); err != nil {
			return err
		}
	}

	c.clusterParamsLock.Lock()
	defer c.clusterParamsLock.Unlock()

	c.metricsCh = make(chan struct{})
	go c.emitMetricsActiveNode(c.metricsCh)

	// Establish version timestamps at the end of unseal on active nodes only.
	return c.handleVersionTimeStamps(ctx)
}

// readonlyUnsealStrategy is called directly on standby nodes and indirectly
// (via standardUnsealStrategy) on active nodes to handle the core shared
// unseal work: startup of various internal subsystems, mounts, &c.
type readonlyUnsealStrategy struct{}

func (s readonlyUnsealStrategy) unseal(ctx context.Context, logger log.Logger, c *Core) error {
	// Start tracking invalidations.
	c.invalidations.Track()

	if err := s.unsealShared(ctx, c, true /* standby */); err != nil {
		return err
	}

	// Finally, start processing invalidations. We'll have cleared the queue
	// when we started this, but any invalidations that occurred during
	// startup will now be processed.
	c.invalidations.Start(ctx)

	return nil
}

func (readonlyUnsealStrategy) unsealShared(ctx context.Context, c *Core, standby bool) error {
	if err := c.setupPluginCatalog(ctx); err != nil {
		return err
	}
	if err := c.registerDeclarativePlugins(ctx, standby); err != nil {
		return err
	}
	if err := c.setupNamespaceStore(ctx); err != nil {
		return err
	}

	{
		logger := c.baseLogger.Named("external-keys")
		c.AddLogger(logger)
		c.externalKeys = ek.NewRegistry(c.kmsPluginCatalog, logger)
	}

	if err := c.loadMounts(ctx, standby); err != nil {
		return err
	}
	if err := c.setupMounts(ctx); err != nil {
		return err
	}
	if err := c.setupPolicyStore(ctx, standby); err != nil {
		return err
	}
	if err := c.loadCORSConfig(ctx); err != nil {
		return err
	}
	if err := c.loadCredentials(ctx, standby); err != nil {
		return err
	}
	if err := c.setupCredentials(ctx); err != nil {
		return err
	}
	if err := c.setupQuotas(ctx); err != nil {
		return err
	}
	if err := c.setupHeaderHMACKey(ctx); err != nil {
		return err
	}

	c.updateLockedUserEntries()

	if err := c.startRollback(); err != nil {
		return err
	}
	if err := c.setupExpiration(expireLeaseStrategyFairsharing, standby); err != nil {
		return err
	}
	if err := c.setupAudits(ctx); err != nil {
		return err
	}
	// Adding new audit devices only occurs on the active node. Standby nodes
	// will consume audit devices from storage only, but we want to run this
	// from startup anyways to report any discrepancies.
	if err := c.handleAuditLogSetup(ctx, standby); err != nil {
		return err
	}
	if err := c.loadIdentityStoreArtifacts(ctx, standby); err != nil {
		return err
	}

	c.setupCachedMFAResponseAuth()
	if err := c.loadLoginMFAConfigs(ctx); err != nil {
		return err
	}

	if err := c.setupAuditedHeadersConfig(ctx); err != nil {
		return err
	}

	c.setupWorkflowStore()

	return nil
}

// postUnseal is invoked on the active node, and performance standby nodes,
// after the barrier is unsealed, but before
// allowing any user operations. This allows us to setup any state that
// requires the Vault to be unsealed such as mount tables, logical backends,
// credential stores, etc.
func (c *Core) postUnseal(ctx context.Context, ctxCancelFunc context.CancelFunc, unsealer UnsealStrategy) (retErr error) {
	defer metrics.MeasureSince([]string{"core", "post_unseal"}, time.Now())

	// Clear any out
	c.postUnsealFuncs = nil

	// Create a new request context
	c.activeContext.Store(NewAtomicContext(ctx, ctxCancelFunc))

	defer func() {
		if retErr != nil {
			ctxCancelFunc()
			_ = c.preSeal()
		}
	}()
	c.logger.Info("post-unseal setup starting")

	// Enable the cache
	c.physicalCache.Purge(ctx)
	if !c.cachingDisabled {
		c.physicalCache.SetEnabled(true)
	}

	// Purge these for safety in case of a rotation
	_ = c.seal.SetBarrierConfig(ctx, nil)
	if c.seal.RecoveryKeySupported() {
		_ = c.seal.SetRecoveryConfig(ctx, nil)
	}

	// Load prior un-updated store into version history cache to compare
	// previous state.
	if err := c.loadVersionHistory(ctx); err != nil {
		return err
	}

	if err := unsealer.unseal(ctx, c.logger, c); err != nil {
		return err
	}

	// Automatically re-encrypt the keys used for auto unsealing when the
	// seal's encryption key changes. The regular rotation of cryptographic
	// keys is a NIST recommendation. Access to prior keys for decryption
	// is normally supported for a configurable time period. Re-encrypting
	// the keys used for auto unsealing ensures Vault and its data will
	// continue to be accessible even after prior seal keys are destroyed.
	if seal, ok := c.seal.(*autoSeal); ok {
		if err := seal.UpgradeKeys(c.activeContext.Load()); err != nil {
			c.logger.Warn("post-unseal upgrade seal keys failed", "error", err)
		}

		// Start a periodic but infrequent heartbeat to detect auto-seal backend
		// outages at runtime rather than being surprised by this at the next
		// need to unseal.
		seal.StartHealthCheck()
	}

	// This is intentionally (almost) the last block in this function. We want
	// to allow writes just before allowing client requests, to ensure
	// everything has been set up properly before any writes happen.
	c.runPostUnsealFuncs(c.postUnsealFuncs)

	if api.ReadBaoVariable(EnvVaultDisableLocalAuthMountEntities) != "" {
		c.logger.Warn("disabling entities for local auth mounts through env var", "env", EnvVaultDisableLocalAuthMountEntities)
	}

	c.loginMFABackend.usedCodes = zcache.New[string, struct{}](0, 30*time.Second)
	c.loginMFABackend.rateLimits = zcache.New[string, uint32](0, 30*time.Second)

	c.logger.Info("post-unseal setup complete")
	return nil
}

// runPostUnsealFuncs uses a small temporary worker pool to run postUnsealFuncs in parallel.
func (c *Core) runPostUnsealFuncs(postUnsealFuncs []func()) {
	postUnsealFuncConcurrency := runtime.NumCPU() * 2
	if v := api.ReadBaoVariable("BAO_POSTUNSEAL_FUNC_CONCURRENCY"); v != "" {
		pv, err := strconv.Atoi(v)
		if err != nil || pv < 1 {
			c.logger.Warn("invalid value for BAO_POSTUNSEAL_FUNC_CURRENCY, must be a positive integer", "error", err, "value", pv)
		} else {
			postUnsealFuncConcurrency = pv
		}
	}
	if postUnsealFuncConcurrency <= 1 {
		// Out of paranoia, keep the old logic for parallism=1
		for _, v := range postUnsealFuncs {
			v()
		}
	} else {
		jobs := make(chan func())
		var wg sync.WaitGroup
		for i := 0; i < postUnsealFuncConcurrency; i++ {
			go func() {
				for v := range jobs {
					v()
					wg.Done()
				}
			}()
		}
		for _, v := range postUnsealFuncs {
			wg.Add(1)
			jobs <- v
		}
		wg.Wait()
		close(jobs)
	}
}

// preSeal is invoked before the barrier is sealed, allowing
// for any state teardown required.
func (c *Core) preSeal() error {
	defer metrics.MeasureSince([]string{"core", "pre_seal"}, time.Now())
	c.logger.Info("pre-seal teardown starting")

	if seal, ok := c.seal.(*autoSeal); ok {
		seal.StopHealthCheck()
	}
	// Clear any pending funcs
	c.postUnsealFuncs = nil
	c.activeTime = time.Time{}

	// Clear any rotation progress
	c.rootRotationConfig = nil
	c.recoveryRotationConfig = nil

	if c.metricsCh != nil {
		close(c.metricsCh)
		c.metricsCh = nil
	}
	var result error

	c.stopForwarding()
	c.stopRaftActiveNode()
	c.cancelNamespaceDeletion()
	c.CleanupInvalidationPeers()
	c.invalidations.Stop()

	if err := c.teardownAudits(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error tearing down audits: %w", err))
	}
	if err := c.stopExpiration(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error stopping expiration: %w", err))
	}
	if err := c.teardownCredentials(context.Background()); err != nil {
		result = multierror.Append(result, fmt.Errorf("error tearing down credentials: %w", err))
	}
	if err := c.teardownPolicyStore(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error tearing down policy store: %w", err))
	}
	if err := c.stopRollback(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error stopping rollback: %w", err))
	}
	if err := c.unloadMounts(context.Background()); err != nil {
		result = multierror.Append(result, fmt.Errorf("error unloading mounts: %w", err))
	}
	if err := c.teardownLoginMFA(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error tearing down login MFA: %w", err))
	}
	if err := c.teardownNamespaceStore(); err != nil {
		result = multierror.Append(result, fmt.Errorf("error tearing down namespace store: %w", err))
	}

	if c.externalKeys != nil {
		c.externalKeys.Stop(context.Background())
		c.externalKeys = nil
	}

	if c.autoRotateCancel != nil {
		c.autoRotateCancel()
		c.autoRotateCancel = nil
	}

	if c.updateLockedUserEntriesCancel != nil {
		c.updateLockedUserEntriesCancel()
		c.updateLockedUserEntriesCancel = nil
	}

	if seal, ok := c.seal.(*autoSeal); ok {
		seal.StopHealthCheck()
	}

	c.physicalCache.SetEnabled(false)
	c.physicalCache.Purge(context.Background())

	c.logger.Info("pre-seal teardown complete")
	return result
}

func (c *Core) ReplicationState() consts.ReplicationState {
	return consts.ReplicationState(c.replicationState.Load())
}

func (c *Core) ActiveNodeReplicationState() consts.ReplicationState {
	return consts.ReplicationState(c.activeNodeReplicationState.Load())
}

func (c *Core) SetActiveNodeReplicationState(val consts.ReplicationState) {
	c.activeNodeReplicationState.Store(uint32(val))
}

func (c *Core) SealAccess() *SealAccess {
	return NewSealAccess(c.seal)
}

// StorageType returns a string equal to the storage configuration's type.
func (c *Core) StorageType() string {
	return c.storageType
}

func (c *Core) Logger() log.Logger {
	return c.logger
}

func (c *Core) BarrierKeyLength() (min, max int) {
	min, max = c.barrier.KeyLength()
	max += shamir.ShareOverhead
	return min, max
}

func (c *Core) AuditedHeadersConfig() *AuditedHeadersConfig {
	return c.auditedHeaders
}

func (c *Core) PhysicalSealConfigs(ctx context.Context) (*SealConfig, *SealConfig, error) {
	pe, err := c.physical.Get(ctx, barrierSealConfigPath)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to fetch barrier seal configuration at migration check time: %w", err)
	}
	if pe == nil {
		return nil, nil, nil
	}

	barrierConf := new(SealConfig)

	if err := jsonutil.DecodeJSON(pe.Value, barrierConf); err != nil {
		return nil, nil, fmt.Errorf("failed to decode barrier seal configuration at migration check time: %w", err)
	}
	err = barrierConf.Validate()
	if err != nil {
		return nil, nil, fmt.Errorf("failed to validate barrier seal configuration at migration check time: %w", err)
	}
	// In older versions of vault the default seal would not store a type. This
	// is here to offer backwards compatibility for older seal configs.
	if barrierConf.Type == "" {
		barrierConf.Type = vaultseal.WrapperTypeShamir.String()
	}

	var recoveryConf *SealConfig
	pe, err = c.physical.Get(ctx, recoverySealConfigPath)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to fetch seal configuration at migration check time: %w", err)
	}
	if pe != nil {
		recoveryConf = &SealConfig{}
		if err := jsonutil.DecodeJSON(pe.Value, recoveryConf); err != nil {
			return nil, nil, fmt.Errorf("failed to decode seal configuration at migration check time: %w", err)
		}
		err = recoveryConf.ValidateRecovery()
		if err != nil {
			return nil, nil, fmt.Errorf("failed to validate seal configuration at migration check time: %w", err)
		}
		// In older versions of vault the default seal would not store a type. This
		// is here to offer backwards compatibility for older seal configs.
		if recoveryConf.Type == "" {
			recoveryConf.Type = vaultseal.WrapperTypeShamir.String()
		}
	}

	return barrierConf, recoveryConf, nil
}

// adjustForSealMigration takes the unwrapSeal, which is nil if (a) we're not
// configured for seal migration or (b) we might be doing a seal migration away
// from shamir.  It will only be non-nil if there is a configured seal with
// the config key disabled=true, which implies a migration away from autoseal.
//
// For case (a), the common case, we expect that the stored barrier
// config matches the seal type, in which case we simply return nil.  If they
// don't match, and the stored seal config is of type Shamir but the configured
// seal is not Shamir, that is case (b) and we make an unwrapSeal of type Shamir.
// Any other unwrapSeal=nil scenario is treated as an error.
//
// Given a non-nil unwrapSeal or case (b), we setup c.migrationInfo to prepare
// for a migration upon receiving a valid migration unseal request.  We cannot
// check at this time for already performed (or incomplete) migrations because
// we haven't yet been unsealed, so we have no way of checking whether a
// shamir seal works to read stored seal-encrypted data.
//
// The assumption throughout is that the very last step of seal migration is
// to write the new barrier/recovery stored seal config.
func (c *Core) adjustForSealMigration(unwrapSeal Seal) error {
	ctx := context.Background()
	existBarrierSealConfig, existRecoverySealConfig, err := c.PhysicalSealConfigs(ctx)
	if err != nil {
		return fmt.Errorf("Error checking for existing seal: %s", err)
	}

	// If we don't have an existing config or if it's the deprecated auto seal
	// which needs an upgrade, skip out
	if existBarrierSealConfig == nil || existBarrierSealConfig.Type == WrapperTypeHsmAutoDeprecated.String() {
		return nil
	}

	if unwrapSeal == nil {
		// With unwrapSeal==nil, either we're not migrating, or we're migrating
		// from shamir.

		switch {
		case existBarrierSealConfig.Type == c.seal.BarrierType().String():
			// We have the same barrier type and the unwrap seal is nil so we're not
			// migrating from same to same, IOW we assume it's not a migration.
			return nil
		case c.seal.BarrierType() == vaultseal.WrapperTypeShamir:
			// The stored barrier config is not shamir, there is no disabled seal
			// in config, and either no configured seal (which equates to Shamir)
			// or an explicitly configured Shamir seal.
			return fmt.Errorf("cannot seal migrate from %q to Shamir, no disabled seal in configuration",
				existBarrierSealConfig.Type)
		case existBarrierSealConfig.Type == vaultseal.WrapperTypeShamir.String():
			// The configured seal is not Shamir, the stored seal config is Shamir.
			// This is a migration away from Shamir.
			unwrapSeal = NewDefaultSeal(vaultseal.NewAccess(vaultseal.NewShamirWrapper()))
		default:
			// We know at this point that there is a configured non-Shamir seal,
			// that it does not match the stored non-Shamir seal config, and that
			// there is no explicit disabled seal stanza.
			return fmt.Errorf("cannot seal migrate from %q to %q, no disabled seal in configuration",
				existBarrierSealConfig.Type, c.seal.BarrierType())
		}
	} else {
		// If we're not coming from Shamir we expect the previous seal to be
		// in the config and disabled.

		if unwrapSeal.BarrierType() == vaultseal.WrapperTypeShamir {
			//nolint:staticcheck // Shamir is a proper noun
			return errors.New("Shamir seals cannot be set disabled (they should simply not be set)")
		}
	}

	// If we've reached this point it's a migration attempt and we should have both
	// c.migrationInfo.seal (old seal) and c.seal (new seal) populated.
	unwrapSeal.SetCore(c)

	if existBarrierSealConfig.Type != vaultseal.WrapperTypeShamir.String() && existRecoverySealConfig == nil {
		return errors.New("recovery seal configuration not found for existing seal")
	}

	c.migrationInfo = &migrationInformation{
		seal: unwrapSeal,
	}
	if existBarrierSealConfig.Type != c.seal.BarrierType().String() {
		// It's unnecessary to call this when doing an auto->auto
		// same-seal-type migration, since they'll have the same configs before
		// and after migration.
		c.adjustSealConfigDuringMigration(existBarrierSealConfig, existRecoverySealConfig)
	}
	c.logger.Warn("entering seal migration mode; Vault will not automatically unseal even if using an autoseal", "from_barrier_type", c.migrationInfo.seal.BarrierType(), "to_barrier_type", c.seal.BarrierType())

	return nil
}

func (c *Core) migrateSealConfig(ctx context.Context) error {
	existBarrierSealConfig, existRecoverySealConfig, err := c.PhysicalSealConfigs(ctx)
	if err != nil {
		return fmt.Errorf("failed to read existing seal configuration during migration: %v", err)
	}

	var bc, rc *SealConfig

	switch {
	case c.migrationInfo.seal.RecoveryKeySupported() && c.seal.RecoveryKeySupported():
		// Migrating from auto->auto, copy the configs over.
		bc, rc = existBarrierSealConfig, existRecoverySealConfig
	case c.migrationInfo.seal.RecoveryKeySupported():
		// Migrating from auto->shamir, clone auto's recovery config.
		bc = existRecoverySealConfig.Clone()
	case c.seal.RecoveryKeySupported():
		// Migrating from shamir->auto, set a new barrier config and set
		// recovery config to a clone of shamir's barrier config.
		bc = &SealConfig{
			Type:            c.seal.BarrierType().String(),
			SecretShares:    1,
			SecretThreshold: 1,
		}

		rc = existBarrierSealConfig.Clone()
	}

	if err := c.seal.SetBarrierConfig(ctx, bc); err != nil {
		return fmt.Errorf("error storing barrier config after migration: %w", err)
	}

	if c.seal.RecoveryKeySupported() {
		if err := c.seal.SetRecoveryConfig(ctx, rc); err != nil {
			return fmt.Errorf("error storing recovery config after migration: %w", err)
		}
	} else if err := c.physical.Delete(ctx, recoverySealConfigPath); err != nil {
		return fmt.Errorf("failed to delete old recovery seal configuration during migration: %w", err)
	}

	return nil
}

func (c *Core) adjustSealConfigDuringMigration(existBarrierSealConfig, existRecoverySealConfig *SealConfig) {
	switch {
	case c.migrationInfo.seal.RecoveryKeySupported() && existRecoverySealConfig != nil:
		// Migrating from auto->shamir, clone auto's recovery config;
		// unless the recover config doesn't exist, in which
		// case the migration is assumed to already have been performed.
		newSealConfig := existRecoverySealConfig.Clone()
		c.seal.SetCachedBarrierConfig(newSealConfig)
	case !c.migrationInfo.seal.RecoveryKeySupported() && c.seal.RecoveryKeySupported():
		// Migrating from shamir->auto, set a new barrier config and set
		// recovery config to a clone of shamir's barrier config.
		newBarrierSealConfig := &SealConfig{
			Type:            c.seal.BarrierType().String(),
			SecretShares:    1,
			SecretThreshold: 1,
		}
		c.seal.SetCachedBarrierConfig(newBarrierSealConfig)

		newRecoveryConfig := existBarrierSealConfig.Clone()
		c.seal.SetCachedRecoveryConfig(newRecoveryConfig)
	}
}

// IsInSealMigrationMode returns true if we're configured to perform a seal migration,
// meaning either that we have a disabled seal in HCL configuration or the seal
// configuration in storage is Shamir but the seal in HCL is not.  In this
// mode we should not auto-unseal (even if the migration is done) and we will
// accept unseal requests with and without the `migrate` option, though the migrate
// option is required if we haven't yet performed the seal migration. Lock
// should only be false if the caller is already holding the read
// statelock (such as calls originating from switchedLockHandleRequest).
func (c *Core) IsInSealMigrationMode(lock bool) bool {
	if lock {
		c.stateLock.RLock()
		defer c.stateLock.RUnlock()
	}
	return c.migrationInfo != nil
}

// IsSealMigrated returns true if we're in seal migration mode but migration
// has already been performed (possibly by another node, or prior to this node's
// current invocation). Lock should only be false if the caller is already
// holding the read statelock (such as calls originating from switchedLockHandleRequest).
func (c *Core) IsSealMigrated(lock bool) bool {
	if !c.IsInSealMigrationMode(lock) {
		return false
	}

	if lock {
		c.stateLock.RLock()
		defer c.stateLock.RUnlock()
	}
	done, _ := c.sealMigrated(context.Background())
	return done
}

func (c *Core) PhysicalAccess() *physical.PhysicalAccess {
	return physical.NewPhysicalAccess(c.physical)
}

func (c *Core) AddLogger(logger log.Logger) {
	c.allLoggersLock.Lock()
	defer c.allLoggersLock.Unlock()
	c.allLoggers = append(c.allLoggers, logger)
}

// SetLogLevel sets logging level for all tracked loggers to the level provided
func (c *Core) SetLogLevel(level log.Level) {
	c.allLoggersLock.RLock()
	defer c.allLoggersLock.RUnlock()
	for _, logger := range c.allLoggers {
		logger.SetLevel(level)
	}
}

// SetLogLevelByName sets the logging level of named logger to level provided
// if it exists. Core.allLoggers is a slice and as such it is entirely possible
// that multiple entries exist for the same name. Each instance will be modified.
func (c *Core) SetLogLevelByName(name string, level log.Level) bool {
	c.allLoggersLock.RLock()
	defer c.allLoggersLock.RUnlock()

	found := false
	for _, logger := range c.allLoggers {
		if logger.Name() == name {
			logger.SetLevel(level)
			found = true
		}
	}

	return found
}

// SetConfig sets core's config object to the newly provided config.
func (c *Core) SetConfig(conf *server.Config) {
	c.rawConfig.Store(conf)
	bz, err := json.Marshal(c.SanitizedConfig())
	if err != nil {
		c.logger.Error("error serializing sanitized config", "error", err)
		return
	}

	c.logger.Debug("set config", "sanitized config", string(bz))
}

func (c *Core) GetListenerCustomResponseHeaders(listenerAdd string) *ListenerCustomHeaders {
	customHeadersList := c.customListenerHeader.Load()
	if customHeadersList == nil {
		return nil
	}

	for _, l := range *customHeadersList {
		if l.Address == listenerAdd {
			return l
		}
	}
	return nil
}

// ExistCustomResponseHeader checks if a custom header is configured in any
// listener's stanza
func (c *Core) ExistCustomResponseHeader(header string) bool {
	customHeadersList := c.customListenerHeader.Load()
	if customHeadersList == nil {
		return false
	}

	for _, l := range *customHeadersList {
		exist := l.ExistCustomResponseHeader(header)
		if exist {
			return true
		}
	}

	return false
}

func (c *Core) ReloadCustomResponseHeaders() error {
	conf := c.rawConfig.Load()
	if conf == nil {
		return errors.New("failed to load core raw config")
	}
	lns := conf.Listeners
	if lns == nil {
		return errors.New("no listener configured")
	}

	uiHeaders, err := c.UIHeaders()
	if err != nil {
		return err
	}
	c.customListenerHeader.Store(NewListenerCustomHeader(lns, c.logger, uiHeaders))

	return nil
}

func (c *Core) setupHeaderHMACKey(ctx context.Context) error {
	ent, err := c.barrier.Get(ctx, indexHeaderHMACKeyPath)
	if err != nil {
		return err
	}

	if ent != nil {
		c.IndexHeaderHMACKey.Store(ent.Value)
		return nil
	}

	key, err := uuid.GenerateUUID()
	if err != nil {
		return err
	}
	err = c.barrier.Put(ctx, &logical.StorageEntry{
		Key:   indexHeaderHMACKeyPath,
		Value: []byte(key),
	})
	if err != nil {
		return err
	}
	c.IndexHeaderHMACKey.Store([]byte(key))
	return nil
}

// SanitizedConfig returns a sanitized version of the current config.
// See server.Config.Sanitized for specific values omitted.
func (c *Core) SanitizedConfig() map[string]any {
	conf := c.rawConfig.Load()
	if conf == nil {
		return nil
	}
	return conf.Sanitized()
}

// LogFormat returns the log format current in use.
func (c *Core) LogFormat() string {
	conf := c.rawConfig.Load()
	return conf.LogFormat
}

// LogLevel returns the log level provided by level provided by config, CLI flag, or env
func (c *Core) LogLevel() string {
	return c.logLevel
}

// MetricsHelper returns the global metrics helper which allows external
// packages to access Vault's internal metrics.
func (c *Core) MetricsHelper() *metricsutil.MetricsHelper {
	return c.metricsHelper
}

// MetricSink returns the metrics wrapper with which Core has been configured.
func (c *Core) MetricSink() *metricsutil.ClusterMetricSink {
	return c.metricSink
}

// BuiltinRegistry is an interface that allows the "vault" package to use
// the registry of builtin plugins without getting an import cycle. It
// also allows for mocking the registry easily.
type BuiltinRegistry interface {
	Contains(name string, pluginType consts.PluginType) bool
	Get(name string, pluginType consts.PluginType) (func() (any, error), bool)
	Keys(pluginType consts.PluginType) []string
	DeprecationStatus(name string, pluginType consts.PluginType) (consts.DeprecationStatus, bool)
}

func (c *Core) AuditLogger() AuditLogger {
	return &basicAuditor{c: c}
}

// isMountable tells us whether or not we can continue mounting a plugin-based
// mount entry after failing to instantiate a backend. We do this to preserve
// the storage and path when a plugin is missing or has otherwise been
// misconfigured. This allows users to recover from errors when starting Vault
// with misconfigured plugins. It should not be possible for existing builtins
// to be misconfigured, so that is a fatal error.
func (c *Core) isMountable(ctx context.Context, entry *routing.MountEntry, pluginType consts.PluginType) bool {
	return !c.isMountEntryBuiltin(ctx, entry, pluginType)
}

// isMountEntryBuiltin determines whether a mount entry is associated with a
// builtin of the specified plugin type.
func (c *Core) isMountEntryBuiltin(ctx context.Context, entry *routing.MountEntry, pluginType consts.PluginType) bool {
	// Prevent a panic early on
	if entry == nil || c.pluginCatalog == nil {
		return false
	}

	// Allow type to be determined from mount entry when not otherwise specified
	if pluginType == consts.PluginTypeUnknown {
		pluginType = c.builtinTypeFromMountEntry(ctx, entry)
	}

	// Handle aliases
	pluginName := entry.Type
	if alias, ok := mountAliases[pluginName]; ok {
		pluginName = alias
	}

	plug, err := c.pluginCatalog.Get(ctx, pluginName, pluginType, entry.Version)
	if err != nil || plug == nil {
		return false
	}

	return plug.Builtin
}

// MatchingMount returns the path of the mount that will be responsible for
// handling the given request path.
func (c *Core) MatchingMount(ctx context.Context, reqPath string) string {
	return c.router.MatchingMount(ctx, reqPath)
}

// ResolveNamespaceFromRequest resolves a namespace from the 'X-Vault-Namespace'
// header combined with the request path, returning the namespace and the
// "trimmed" request path devoid of any namespace components.
func (c *Core) ResolveNamespaceFromRequest(nsHeader, reqPath string) (*namespace.Namespace, string) {
	c.stateLock.RLock()
	defer c.stateLock.RUnlock()

	if c.Sealed() || c.namespaceStore == nil {
		return nil, ""
	}

	return c.namespaceStore.ResolveNamespaceFromRequest(nsHeader, reqPath)
}

func (c *Core) setupQuotas(ctx context.Context) error {
	if c.quotaManager == nil {
		return nil
	}

	return c.quotaManager.Setup(ctx, c.systemBarrierView)
}

// ApplyRateLimitQuota checks the request against all the applicable quota rules.
// If the given request's path is exempt, no rate limiting will be applied.
func (c *Core) ApplyRateLimitQuota(ctx context.Context, req *quotas.Request) (quotas.Response, error) {
	req.Type = quotas.TypeRateLimit

	resp := quotas.Response{
		Allowed: true,
		Headers: make(map[string]string),
	}

	if c.quotaManager != nil {
		// skip rate limit checks for paths that are exempt from rate limiting
		if c.quotaManager.RateLimitPathExempt(req.Path) {
			return resp, nil
		}

		return c.quotaManager.ApplyQuota(ctx, req)
	}

	return resp, nil
}

// RateLimitAuditLoggingEnabled returns if the quota configuration allows audit
// logging of request rejections due to rate limiting quota rule violations.
func (c *Core) RateLimitAuditLoggingEnabled() bool {
	if c.quotaManager != nil {
		return c.quotaManager.RateLimitAuditLoggingEnabled()
	}

	return false
}

// RateLimitResponseHeadersEnabled returns if the quota configuration allows for
// rate limit quota HTTP headers to be added to responses.
func (c *Core) RateLimitResponseHeadersEnabled() bool {
	if c.quotaManager != nil {
		return c.quotaManager.RateLimitResponseHeadersEnabled()
	}

	return false
}

func (c *Core) KeyRotateGracePeriod() time.Duration {
	return time.Duration(c.keyRotateGracePeriod.Load())
}

func (c *Core) SetKeyRotateGracePeriod(t time.Duration) {
	c.keyRotateGracePeriod.Store(int64(t))
}

// autoRotateBarrierLoop checks whether to automatically rotate the barrier key.
func (c *Core) autoRotateBarrierLoop(ctx context.Context) {
	t := time.NewTicker(barrier.AutoRotateCheckInterval)
	for {
		select {
		case <-t.C:
			c.checkBarrierAutoRotate(ctx)
		case <-ctx.Done():
			t.Stop()
			return
		}
	}
}

func (c *Core) checkBarrierAutoRotate(ctx context.Context) {
	c.stateLock.RLock()
	defer c.stateLock.RUnlock()

	reason, err := c.barrier.CheckBarrierAutoRotate(ctx)
	if err != nil {
		lf := c.logger.Error
		if strings.HasSuffix(err.Error(), "context canceled") {
			lf = c.logger.Debug
		}
		lf("error in barrier auto rotation", "error", err)
		return
	}

	if reason != "" {
		c.logger.Info("automatic barrier key rotation triggered", "reason", reason)
		if err := c.sealManager.RotateBarrierKey(ctx, namespace.RootNamespace); err != nil {
			c.logger.Error("error automatically rotating barrier key", "error", err)
		} else {
			metrics.IncrCounter(barrier.BarrierRotationsMetric, 1)
		}
	}
}

func (c *Core) loadLoginMFAConfigs(ctx context.Context) error {
	namespaces, err := c.ListNamespaces(ctx)
	if err != nil {
		return err
	}

	for _, ns := range namespaces {
		if err := c.loadLoginMFAConfigsForNamespace(ctx, ns); err != nil {
			return err
		}
	}

	return nil
}

func (c *Core) loadLoginMFAConfigsForNamespace(ctx context.Context, ns *namespace.Namespace) error {
	err := c.loginMFABackend.loadMFAMethodConfigs(ctx, ns)
	if err != nil {
		return fmt.Errorf("error loading MFA method Config, namespace %s, error: %w", ns.Path, err)
	}

	loadedConfigs, err := c.loginMFABackend.loadMFAEnforcementConfigs(ctx, ns)
	if err != nil {
		return fmt.Errorf("error loading MFA enforcement Config, namespace %s, error: %w", ns.Path, err)
	}

	for _, conf := range loadedConfigs {
		if err := c.loginMFABackend.loginMFAMethodExistenceCheck(conf); err != nil {
			c.loginMFABackend.mfaLogger.Error("failed to find all MFA methods that exist in MFA enforcement configs", "configID", conf.ID, "namespaceID", conf.NamespaceID, "error", err.Error())
		}
	}
	return nil
}

type MFACachedAuthResponse struct {
	CachedAuth            *logical.Auth
	CachedUserLockout     *FailedLoginUser
	RequestPath           string
	RequestNSID           string
	RequestNSPath         string
	RequestConnRemoteAddr string
	TimeOfStorage         time.Time
	RequestID             string
}

func (c *Core) setupCachedMFAResponseAuth() {
	c.mfaResponseAuthQueueLock.Lock()
	c.mfaResponseAuthQueue = NewLoginMFAPriorityQueue()
	mfaQueue := c.mfaResponseAuthQueue
	c.mfaResponseAuthQueueLock.Unlock()

	ctx := c.activeContext.Load()

	go func() {
		ticker := time.Tick(5 * time.Second)
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker:
				err := mfaQueue.RemoveExpiredMfaAuthResponse(defaultMFAAuthResponseTTL, time.Now())
				if err != nil {
					c.Logger().Error("failed to remove stale MFA auth response", "error", err)
				}
			}
		}
	}()
}

// updateLockedUserEntries runs every 15 mins to remove stale user entries from storage
// it also updates the userFailedLoginInfo map with correct information for locked users if incorrect
func (c *Core) updateLockedUserEntries() {
	if c.updateLockedUserEntriesCancel != nil {
		return
	}

	var updateLockedUserEntriesCtx context.Context
	updateLockedUserEntriesCtx, c.updateLockedUserEntriesCancel = context.WithCancel(c.activeContext.Load())

	if err := c.runLockedUserEntryUpdates(updateLockedUserEntriesCtx); err != nil {
		c.Logger().Error("failed to run locked user entry updates", "error", err)
	}

	go func() {
		ticker := time.NewTicker(15 * time.Minute)
		for {
			select {
			case <-updateLockedUserEntriesCtx.Done():
				ticker.Stop()
				return
			case <-ticker.C:
				if err := c.runLockedUserEntryUpdates(updateLockedUserEntriesCtx); err != nil {
					c.Logger().Error("failed to run locked user entry updates", "error", err)
				}
			}
		}
	}()
}

// runLockedUserEntryUpdates runs updates for locked user storage entries and userFailedLoginInfo map
func (c *Core) runLockedUserEntryUpdates(ctx context.Context) error {
	// check environment variable to see if user lockout workflow is disabled
	var disableUserLockout bool
	if disableUserLockoutEnv := api.ReadBaoVariable(consts.VaultDisableUserLockout); disableUserLockoutEnv != "" {
		var err error
		disableUserLockout, err = strconv.ParseBool(disableUserLockoutEnv)
		if err != nil {
			c.Logger().Error("Error parsing the environment variable VAULT_DISABLE_USER_LOCKOUT", "error", err)
		}
	}
	if disableUserLockout {
		return nil
	}

	// get all namespaces
	nsList, err := c.ListNamespaces(ctx)
	if err != nil {
		return err
	}

	totalLockedUsersCount := 0
	for _, ns := range nsList {
		nsLockedUsers, err := c.runLockedUserEntryUpdatesForNamespace(ctx, ns, false)
		if err != nil {
			return err
		}
		totalLockedUsersCount += nsLockedUsers
	}

	// emit locked user count metrics
	metrics.SetGaugeWithLabels([]string{"core", "locked_users"}, float32(totalLockedUsersCount), nil)
	return nil
}

// runLockedUserEntryUpdatesForNamespace runs updates for locked users storage entries
// for a single namespace. If a forceDelete flag is passed all login entries are deleted.
func (c *Core) runLockedUserEntryUpdatesForNamespace(ctx context.Context, ns *namespace.Namespace, forceDelete bool) (int, error) {
	// get the list of mount accessors of locked users of a namespace
	view := c.NamespaceView(ns).SubView(coreLockedUsersPath)
	mountAccessors, err := view.List(ctx, "")
	if err != nil {
		return 0, err
	}

	namespaceLockedUsers := 0
	// update the entries for locked users for each mount accessor
	// if storage entry is stale i.e; the lockout duration has
	// passed or namespace was deleted then remove this entry
	// from storage and userFailedLoginInfo map else check if
	// the userFailedLoginInfo map has correct failed login information
	// if incorrect, update the entry in userFailedLoginInfo map
	for _, mountAccessorPath := range mountAccessors {
		lockedAliasesCount, err := c.runLockedUserEntryUpdatesForMountAccessor(ctx, view.SubView(mountAccessorPath), mountAccessorPath, forceDelete)
		if err != nil {
			return namespaceLockedUsers, err
		}
		namespaceLockedUsers += lockedAliasesCount
	}

	return namespaceLockedUsers, nil
}

// runLockedUserEntryUpdatesForMountAccessor updates the storage entry
// for each locked user (alias name). Removes stale entries or entries
// belonging to deleted namespace from storage and userFailedLoginInfo map.
// For valid entries userFailedLoginInfo map gets updated with correct
// values for entry if they were incorrect before.
func (c *Core) runLockedUserEntryUpdatesForMountAccessor(ctx context.Context, view logical.Storage, mountAccessor string, forceDelete bool) (int, error) {
	// get mount entry for mountAccessor
	mountAccessor = strings.TrimSuffix(mountAccessor, "/")
	mountEntry := c.router.MatchingMountByAccessor(mountAccessor)
	if mountEntry == nil {
		mountEntry = &routing.MountEntry{}
	}
	// get configuration for mount entry
	userLockoutConfiguration := c.getUserLockoutConfiguration(mountEntry)

	// get the list of aliases for mount accessor
	aliases, err := view.List(ctx, "")
	if err != nil {
		return 0, err
	}

	lockedAliasesCount := len(aliases)

	// check storage entry for each alias to update
	for _, alias := range aliases {
		loginUserInfoKey := FailedLoginUser{
			aliasName:     alias,
			mountAccessor: mountAccessor,
		}
		// get the entry for the locked user from userFailedLoginInfo map
		failedLoginInfoFromMap := c.LocalGetUserFailedLoginInfo(ctx, loginUserInfoKey)

		var staleEntry bool
		// if not forcing the delete, check if the entry is stale
		if !forceDelete {
			existingEntry, err := view.Get(ctx, alias)
			if err != nil {
				return 0, err
			}

			if existingEntry == nil {
				continue
			}

			var lastLoginTime int
			err = jsonutil.DecodeJSON(existingEntry.Value, &lastLoginTime)
			if err != nil {
				return 0, err
			}

			lastFailedLoginTimeFromStorageEntry := time.Unix(int64(lastLoginTime), 0)
			lockoutDurationFromConfiguration := userLockoutConfiguration.LockoutDuration
			staleEntry = time.Now().After(lastFailedLoginTimeFromStorageEntry.Add(lockoutDurationFromConfiguration))
			if !staleEntry {
				// not a stale entry
				// update the map with actual failed login information
				actualFailedLoginInfo := FailedLoginInfo{
					lastFailedLoginTime: lastLoginTime,
					count:               uint(userLockoutConfiguration.LockoutThreshold),
				}

				if failedLoginInfoFromMap != &actualFailedLoginInfo {
					// outdated entry, updating the entry in userFailedLoginMap
					// with correct information
					if err = c.LocalUpdateUserFailedLoginInfo(ctx, loginUserInfoKey, &actualFailedLoginInfo, false); err != nil {
						return 0, err
					}
				}
			}
		}

		// delete if the storage entry for locked user is stale
		// or force delete if the namespace is being deleted
		if staleEntry || forceDelete {
			// stale entry, remove from storage
			// leaving this as it is as this happens on the active node
			// also handles case where entry is force deleted
			if err := view.Delete(ctx, alias); err != nil {
				return 0, err
			}
			// remove entry for this user from userFailedLoginInfo map
			// as the user is not locked (if not present, this is no-op)
			if err = c.LocalUpdateUserFailedLoginInfo(ctx, loginUserInfoKey, failedLoginInfoFromMap, true); err != nil {
				return 0, err
			}

			lockedAliasesCount -= 1
		}
	}
	return lockedAliasesCount, nil
}

// PopMFAResponseAuthByID pops an item from the mfaResponseAuthQueue by ID
// it returns the cached auth response or an error
func (c *Core) PopMFAResponseAuthByID(reqID string) (*MFACachedAuthResponse, error) {
	if c.standby.Load() {
		return nil, logical.ErrReadOnly
	}
	c.mfaResponseAuthQueueLock.Lock()
	defer c.mfaResponseAuthQueueLock.Unlock()
	return c.mfaResponseAuthQueue.PopByKey(reqID)
}

// SaveMFAResponseAuth pushes an MFACachedAuthResponse to the mfaResponseAuthQueue.
// it returns an error in case of failure
func (c *Core) SaveMFAResponseAuth(respAuth *MFACachedAuthResponse) error {
	if c.standby.Load() {
		return logical.ErrReadOnly
	}
	c.mfaResponseAuthQueueLock.Lock()
	defer c.mfaResponseAuthQueueLock.Unlock()
	return c.mfaResponseAuthQueue.Push(respAuth)
}

type InFlightRequests struct {
	InFlightReqMap   *sync.Map
	InFlightReqCount *atomic.Uint64
}

type InFlightReqData struct {
	StartTime        time.Time `json:"start_time"`
	ClientRemoteAddr string    `json:"client_remote_address"`
	ReqPath          string    `json:"request_path"`
	Method           string    `json:"request_method"`
	ClientID         string    `json:"client_id"`
}

func (c *Core) StoreInFlightReqData(reqID string, data InFlightReqData) {
	c.inFlightReqData.InFlightReqMap.Store(reqID, data)
	c.inFlightReqData.InFlightReqCount.Add(1)
}

// FinalizeInFlightReqData is going log the completed request if the
// corresponding server config option is enabled. It also removes the
// request from the inFlightReqMap and decrement the number of in-flight
// requests by one.
func (c *Core) FinalizeInFlightReqData(reqID string, statusCode int) {
	if c.logRequestsLevel.Load() != 0 {
		c.LogCompletedRequests(reqID, statusCode)
	}

	c.inFlightReqData.InFlightReqMap.Delete(reqID)
	c.inFlightReqData.InFlightReqCount.Add(^uint64(0)) // equivalent of decrementing by 1
}

// LoadInFlightReqData creates a snapshot map of the current
// in-flight requests
func (c *Core) LoadInFlightReqData() map[string]InFlightReqData {
	currentInFlightReqMap := make(map[string]InFlightReqData)
	c.inFlightReqData.InFlightReqMap.Range(func(key, value any) bool {
		// there is only one writer to this map, so skip checking for errors
		v := value.(InFlightReqData)
		currentInFlightReqMap[key.(string)] = v
		return true
	})

	return currentInFlightReqMap
}

// UpdateInFlightReqData updates the data for a specific reqID with
// the clientID
func (c *Core) UpdateInFlightReqData(reqID, clientID string) {
	v, ok := c.inFlightReqData.InFlightReqMap.Load(reqID)
	if !ok {
		c.Logger().Trace("failed to retrieve request with ID", "request_id", reqID)
		return
	}

	// there is only one writer to this map, so skip checking for errors
	reqData := v.(InFlightReqData)
	reqData.ClientID = clientID
	c.inFlightReqData.InFlightReqMap.Store(reqID, reqData)
}

// LogCompletedRequests Logs the completed request to the server logs
func (c *Core) LogCompletedRequests(reqID string, statusCode int) {
	logLevel := log.Level(c.logRequestsLevel.Load())
	v, ok := c.inFlightReqData.InFlightReqMap.Load(reqID)
	if !ok {
		c.logger.Log(logLevel, fmt.Sprintf("failed to retrieve request with ID %v", reqID))
		return
	}

	// there is only one writer to this map, so skip checking for errors
	reqData := v.(InFlightReqData)
	c.logger.Log(logLevel, "completed_request",
		"start_time", reqData.StartTime.Format(time.RFC3339),
		"duration", fmt.Sprintf("%dms", time.Since(reqData.StartTime).Milliseconds()),
		"client_id", reqData.ClientID,
		"client_address", reqData.ClientRemoteAddr, "status_code", statusCode, "request_path", reqData.ReqPath,
		"request_method", reqData.Method)
}

func (c *Core) ReloadLogRequestsLevel() {
	conf := c.rawConfig.Load()
	if conf == nil {
		return
	}

	infoLevel := conf.LogRequestsLevel
	switch {
	case log.LevelFromString(infoLevel) > log.NoLevel && log.LevelFromString(infoLevel) < log.Off:
		c.logRequestsLevel.Store(int32(log.LevelFromString(infoLevel)))
	case infoLevel != "":
		c.logger.Warn("invalid log_requests_level", "level", infoLevel)
	}
}

func (c *Core) ReloadIntrospectionEndpointEnabled() {
	conf := c.rawConfig.Load()
	if conf == nil {
		return
	}
	c.introspectionEnabledLock.Lock()
	defer c.introspectionEnabledLock.Unlock()
	c.introspectionEnabled = conf.EnableIntrospectionEndpoint
}

type PeerNode struct {
	Hostname       string    `json:"hostname"`
	APIAddress     string    `json:"api_address"`
	ClusterAddress string    `json:"cluster_address"`
	Version        string    `json:"version"`
	LastEcho       time.Time `json:"last_echo"`
	UpgradeVersion string    `json:"upgrade_version,omitempty"`
}

// GetHAPeerNodesCached returns the nodes that've sent us Echo requests recently.
func (c *Core) GetHAPeerNodesCached() []PeerNode {
	var nodes []PeerNode
	for itemClusterAddr, item := range c.clusterPeerClusterAddrsCache.Items() {
		info := item.Object
		nodes = append(nodes, PeerNode{
			Hostname:       info.NodeInfo.Hostname,
			APIAddress:     info.NodeInfo.ApiAddr,
			ClusterAddress: itemClusterAddr,
			LastEcho:       info.LastHeartbeat,
			Version:        info.Version,
			UpgradeVersion: info.UpgradeVersion,
		})
	}
	return nodes
}

func (c *Core) CheckPluginPerms(pluginName string) (err error) {
	var enableFilePermissionsCheck bool
	if enableFilePermissionsCheckEnv := api.ReadBaoVariable(consts.VaultEnableFilePermissionsCheckEnv); enableFilePermissionsCheckEnv != "" {
		var err error
		enableFilePermissionsCheck, err = strconv.ParseBool(enableFilePermissionsCheckEnv)
		if err != nil {
			return fmt.Errorf("failed to parse environment variable %s", consts.VaultEnableFilePermissionsCheckEnv)
		}
	}

	if c.pluginDirectory != "" && enableFilePermissionsCheck {
		err = osutil.OwnerPermissionsMatch(c.pluginDirectory, c.pluginFileUid, c.pluginFilePermissions)
		if err != nil {
			return err
		}
		fullPath := filepath.Join(c.pluginDirectory, pluginName)
		err = osutil.OwnerPermissionsMatch(fullPath, c.pluginFileUid, c.pluginFilePermissions)
		if err != nil {
			return err
		}
	}
	return err
}

func (c *Core) LoadNodeID() (string, error) {
	raftNodeID := c.GetRaftNodeID()
	if raftNodeID != "" {
		return raftNodeID, nil
	}
	hostname, err := os.Hostname()
	if err != nil {
		return "", err
	}
	return hostname, nil
}

// DetermineRoleFromLoginRequest will determine the role that should be applied to a quota for a given
// login request
func (c *Core) DetermineRoleFromLoginRequest(ctx context.Context, mountPoint string, data map[string]any) string {
	c.authLock.RLock()
	defer c.authLock.RUnlock()
	matchingBackend := c.router.MatchingBackend(ctx, mountPoint)
	if matchingBackend == nil || matchingBackend.Type() != logical.TypeCredential {
		// Role based quotas do not apply to this request
		return ""
	}
	return c.doResolveRoleLocked(ctx, mountPoint, matchingBackend, data)
}

// DetermineRoleFromLoginRequestFromReader will determine the role that should
// be applied to a quota for a given login request. The reader will only be
// consumed if the matching backend for the mount point exists and is a secret
// backend
func (c *Core) DetermineRoleFromLoginRequestFromReader(ctx context.Context, mountPoint string, reader io.Reader) string {
	c.authLock.RLock()
	defer c.authLock.RUnlock()
	matchingBackend := c.router.MatchingBackend(ctx, mountPoint)
	if matchingBackend == nil || matchingBackend.Type() != logical.TypeCredential {
		// Role based quotas do not apply to this request
		return ""
	}

	data := make(map[string]any)
	err := jsonutil.DecodeJSONFromReader(reader, &data)
	if err != nil {
		return ""
	}
	return c.doResolveRoleLocked(ctx, mountPoint, matchingBackend, data)
}

// doResolveRoleLocked does a login and resolve role request on the matching
// backend. Callers should have a read lock on c.authLock
func (c *Core) doResolveRoleLocked(ctx context.Context, mountPoint string, matchingBackend logical.Backend, data map[string]any) string {
	resp, err := matchingBackend.HandleRequest(ctx, &logical.Request{
		MountPoint: mountPoint,
		Path:       "login",
		Operation:  logical.ResolveRoleOperation,
		Data:       data,
		Storage:    c.router.MatchingStorageByAPIPath(ctx, mountPoint+"login"),
	})
	if err != nil || resp == nil || resp.Data == nil || resp.Data["role"] == nil {
		return ""
	}

	return resp.Data["role"].(string)
}

// ResolveRoleForQuotas looks for any quotas requiring a role for early
// computation in the RateLimitQuotaWrapping handler.
func (c *Core) ResolveRoleForQuotas(req *quotas.Request) (bool, error) {
	if c.quotaManager == nil {
		return false, nil
	}
	return c.quotaManager.QueryResolveRoleQuotas(req)
}

// aliasNameFromLoginRequest will determine the aliasName from the login Request
func (c *Core) aliasNameFromLoginRequest(ctx context.Context, req *logical.Request) (string, error) {
	c.authLock.RLock()
	defer c.authLock.RUnlock()
	ns, err := namespace.FromContext(ctx)
	if err != nil {
		return "", err
	}

	// ns path is added while checking matching backend
	mountPath := strings.TrimPrefix(req.MountPoint, ns.Path)

	matchingBackend := c.router.MatchingBackend(ctx, mountPath)
	if matchingBackend == nil || matchingBackend.Type() != logical.TypeCredential {
		// pathLoginAliasLookAhead operation does not apply to this request
		return "", nil
	}

	path := strings.ReplaceAll(req.Path, mountPath, "")

	resp, err := matchingBackend.HandleRequest(ctx, &logical.Request{
		MountPoint: req.MountPoint,
		Path:       path,
		Operation:  logical.AliasLookaheadOperation,
		Data:       req.Data,
		Storage:    c.router.MatchingStorageByAPIPath(ctx, req.Path),
	})

	// Certain errors (like field validation errors) are returned as
	// logical.ErrorResponse(...)s, which means Auth will not be set,
	// only resp.Data["error"]. Surface the errors appropriately.
	if err != nil || resp == nil {
		return "", err
	}
	if resp.Data != nil && len(resp.Data["error"].(string)) > 0 {
		return "", errors.New(resp.Data["error"].(string))
	}
	if resp.Auth == nil || resp.Auth.Alias == nil {
		return "", nil
	}

	return resp.Auth.Alias.Name, nil
}

// ListMounts will provide a slice containing a deep copy each mount entry
func (c *Core) ListMounts() ([]*routing.MountEntry, error) {
	if c.Sealed() {
		return nil, errors.New("vault is sealed")
	}

	c.mountsLock.RLock()
	defer c.mountsLock.RUnlock()

	var entries []*routing.MountEntry

	for _, entry := range c.mounts.Entries {
		clone, err := entry.Clone()
		if err != nil {
			return nil, err
		}

		entries = append(entries, clone)
	}

	return entries, nil
}

// ListAuths will provide a slice containing a deep copy each auth entry
func (c *Core) ListAuths() ([]*routing.MountEntry, error) {
	if c.Sealed() {
		return nil, errors.New("vault is sealed")
	}

	c.authLock.RLock()
	defer c.authLock.RUnlock()

	var entries []*routing.MountEntry

	for _, entry := range c.auth.Entries {
		clone, err := entry.Clone()
		if err != nil {
			return nil, err
		}

		entries = append(entries, clone)
	}

	return entries, nil
}

type GroupPolicyApplicationMode struct {
	GroupPolicyApplicationMode string `json:"group_policy_application_mode"`
}

func (c *Core) GetGroupPolicyApplicationMode(ctx context.Context) (string, error) {
	se, err := c.barrier.Get(ctx, coreGroupPolicyApplicationPath)
	if err != nil {
		return "", err
	}
	if se == nil {
		return groupPolicyApplicationModeWithinNamespaceHierarchy, nil
	}

	var modeStruct GroupPolicyApplicationMode

	err = jsonutil.DecodeJSON(se.Value, &modeStruct)
	if err != nil {
		return "", err
	}
	mode := modeStruct.GroupPolicyApplicationMode
	if mode == "" {
		mode = groupPolicyApplicationModeWithinNamespaceHierarchy
	}

	return mode, nil
}

func (c *Core) SetGroupPolicyApplicationMode(ctx context.Context, mode string) error {
	json, err := jsonutil.EncodeJSON(&GroupPolicyApplicationMode{GroupPolicyApplicationMode: mode})
	if err != nil {
		return err
	}
	return c.barrier.Put(ctx, &logical.StorageEntry{
		Key:   coreGroupPolicyApplicationPath,
		Value: json,
	})
}

// ListenerAddresses provides a slice of configured listener addresses
func (c *Core) ListenerAddresses() ([]string, error) {
	addresses := make([]string, 0)

	conf := c.rawConfig.Load()
	if conf == nil {
		return nil, errors.New("failed to load core raw config")
	}

	listeners := conf.Listeners
	if listeners == nil {
		return nil, errors.New("no listener configured")
	}

	for _, listener := range listeners {
		addresses = append(addresses, listener.Address)
	}

	return addresses, nil
}

// IsRaftVoter specifies whether the node is a raft voter which is
// always false if raft storage is not in use.
func (c *Core) IsRaftVoter() bool {
	raftInfo := c.raftInfo.Load()

	if raftInfo == nil {
		return false
	}

	return !raftInfo.nonVoter
}

func (c *Core) HAEnabled() bool {
	return c.ha != nil && c.ha.HAEnabled()
}

func (c *Core) GetRaftConfiguration(ctx context.Context) (*raft.RaftConfigurationResponse, error) {
	raftBackend := c.GetRaftBackend()

	if raftBackend == nil {
		return nil, nil
	}

	return raftBackend.GetConfiguration(ctx)
}

func (c *Core) GetRaftAutopilotState(ctx context.Context) (*raft.AutopilotState, error) {
	raftBackend := c.GetRaftBackend()
	if raftBackend == nil {
		return nil, nil
	}

	return raftBackend.GetAutopilotServerState(ctx)
}

func (c *Core) DetectStateLockDeadlocks() bool {
	if _, ok := c.stateLock.(*locking.DeadlockRWMutex); ok {
		return true
	}
	return false
}

// Starts the listeners and servers necessary to handle forwarded requests
func (c *Core) startForwarding(ctx context.Context) error {
	c.logger.Debug("request forwarding setup function")
	defer c.logger.Debug("leaving request forwarding setup function")

	// Clean up in case we have transitioned from a client to a server
	c.clearForwardingClients()

	clusterListener := c.getClusterListener()
	if c.ha == nil || clusterListener == nil {
		c.logger.Debug("request forwarding not setup")
		return nil
	}

	fwdCfg := forwarding.ForwardingConfig{
		HA:                           c.ha,
		ClusterHandler:               c.clusterHandler,
		ClusterHeartbeatInterval:     c.clusterHeartbeatInterval,
		RaftFollowerStates:           c.raftFollowerStates,
		ClusterPeerClusterAddrsCache: c.clusterPeerClusterAddrsCache,
	}

	handler, err := forwarding.NewRequestForwardingHandler(c, fwdCfg, clusterListener.Server())
	if err != nil {
		return err
	}

	clusterListener.AddHandler(consts.RequestForwardingALPN, handler)

	return nil
}

func (c *Core) stopForwarding() {
	clusterListener := c.getClusterListener()
	if clusterListener != nil {
		clusterListener.StopHandler(consts.RequestForwardingALPN)
	}
}

// refreshRequestForwardingConnection ensures that the client/transport are
// alive and that the current active address value matches the most
// recently-known address.
func (c *Core) refreshRequestForwardingConnection(ctx context.Context, clusterAddr string) error {
	c.logger.Debug("refreshing forwarding connection", "clusterAddr", clusterAddr)
	defer c.logger.Debug("done refreshing forwarding connection", "clusterAddr", clusterAddr)

	// Clean things up first
	c.clearForwardingClients()

	// If we don't have anything to connect to, just return
	if clusterAddr == "" {
		return nil
	}

	clusterURL, err := url.Parse(clusterAddr)
	if err != nil {
		c.logger.Error("error parsing cluster address attempting to refresh forwarding connection", "error", err)
		return err
	}

	parsedCert := c.localClusterParsedCert.Load()
	if parsedCert == nil {
		c.logger.Error("no request forwarding cluster certificate found")
		return errors.New("no request forwarding cluster certificate found")
	}

	clusterListener := c.getClusterListener()
	if clusterListener == nil {
		c.logger.Error("no cluster listener configured")
		return nil
	}

	clusterListener.AddClient(consts.RequestForwardingALPN, forwarding.NewRequestForwardingClusterClient(c))

	// Set up grpc forwarding handling
	// It's not really insecure, but we have to dial manually to get the
	// ALPN header right. It's just "insecure" because GRPC isn't managing
	// the TLS state.
	dctx, cancelFunc := context.WithCancel(ctx)
	rpcClientConn, err := grpc.NewClient(fmt.Sprintf("passthrough:///%s", clusterURL.Host),
		grpc.WithContextDialer(clusterListener.GetContextDialerFunc(ctx, consts.RequestForwardingALPN)),
		grpc.WithTransportCredentials(
			insecure.NewCredentials(), // it's not, we handle it in the dialer
		),
		grpc.WithKeepaliveParams(keepalive.ClientParameters{
			Time: 2 * c.clusterHeartbeatInterval,
		}),
		grpc.WithDefaultCallOptions(
			grpc.MaxCallRecvMsgSize(math.MaxInt32),
			grpc.MaxCallSendMsgSize(math.MaxInt32),
		),
		grpc.WithUnaryInterceptor(forwarding.LegacyPackageFallback),
	)
	if err != nil {
		cancelFunc()
		c.logger.Error("err setting up forwarding rpc client", "error", err)
		return err
	}

	client := forwarding.NewClient(
		c,
		rpcClientConn,
		dctx,
		time.NewTicker(c.clusterHeartbeatInterval),
		time.NewTicker(c.clusterNamespaceSyncInterval),
	)
	client.Start()

	oldCtx := c.rpcClientConnContext.Swap(NewAtomicContext(dctx, cancelFunc))
	oldCtx.Cancel()

	c.rpcForwardingClient.Store(client)

	if _, ok := c.underlyingPhysical.(physical.CacheInvalidationBackend); !ok {
		c.logger.Info("restarting standby as active node has changed; may enable grpc invalidation")
		c.Restart()
	}

	return nil
}

func (c *Core) clearForwardingClients() {
	c.logger.Debug("clearing forwarding clients")
	defer c.logger.Debug("done clearing forwarding clients")

	c.rpcClientConnContext.Load().Cancel()

	client := c.rpcForwardingClient.Swap(nil)
	if client != nil {
		if err := client.Stop(); err != nil {
			c.logger.Warn("error closing rpc client connection", "error", err)
		}
	}

	clusterListener := c.getClusterListener()
	if clusterListener != nil {
		clusterListener.RemoveClient(consts.RequestForwardingALPN)
	}
	c.clusterLeaderParams.Store(nil)
}

// ForwardRequest forwards a given request to the active node and returns the
// response.
func (c *Core) ForwardRequest(req *http.Request) (int, http.Header, []byte, error) {
	client := c.rpcForwardingClient.Load()
	if client == nil {
		return 0, nil, nil, ErrCannotForward
	}

	defer metrics.MeasureSince([]string{"ha", "rpc", "client", "forward"}, time.Now())

	origPath := req.URL.Path
	defer func() {
		req.URL.Path = origPath
	}()

	var ok bool
	req.URL.Path, ok = OriginalRequestPathFromContext(req.Context())
	if !ok {
		return 0, nil, nil, errors.New("no original request path from context")
	}

	freq, err := fwd.GenerateForwardedRequest(req)
	if err != nil {
		c.logger.Error("error creating forwarding RPC request", "error", err)
		return 0, nil, nil, errors.New("error creating forwarding RPC request")
	}
	if freq == nil {
		c.logger.Error("got nil forwarding RPC request")
		return 0, nil, nil, errors.New("got nil forwarding RPC request")
	}

	resp, err := client.ForwardRequest(req.Context(), freq)
	if err != nil {
		metrics.IncrCounter([]string{"ha", "rpc", "client", "forward", "errors"}, 1)
		c.logger.Error("error during forwarded RPC request", "error", err)
		return 0, nil, nil, errors.New("error during forwarding RPC request")
	}

	var header http.Header
	if resp.HeaderEntries != nil {
		header = make(http.Header)
		for k, v := range resp.HeaderEntries {
			header[k] = v.Values
		}
	}

	return int(resp.StatusCode), header, resp.Body, nil
}

func (c *Core) EffectiveSDKVersion() string {
	return c.effectiveSDKVersion
}

func (c *Core) LocalClusterCert() *[]byte {
	return c.localClusterCert.Load()
}

func (c *Core) LocalClusterPrivateKey() *ecdsa.PrivateKey {
	return c.localClusterPrivateKey.Load()
}

func (c *Core) LocalClusterParsedCert() *x509.Certificate {
	return c.localClusterParsedCert.Load()
}

func (c *Core) RedirectAddr() string {
	return c.redirectAddr
}

func (c *Core) UnsafeCrossNamespaceIdentity() bool {
	return c.unsafeCrossNamespaceIdentity
}

func (c *Core) performPolicyChecks(ctx context.Context, acl *policy.ACL, te *logical.TokenEntry, req *logical.Request, inEntity *identity.Entity, opts *policy.CheckOpts) *policy.AuthResults {
	ret := new(policy.AuthResults)

	// First, perform normal ACL checks if requested. The only time no ACL
	// should be applied is if we are only processing EGPs against a login
	// path in which case opts.Unauth will be set.
	if acl != nil && !opts.Unauth {
		ret.ACLResults = acl.AllowOperation(ctx, req, false)
		ret.RootPrivs = ret.ACLResults.RootPrivs
		// Root is always allowed; skip Sentinel/MFA checks
		if ret.ACLResults.IsRoot {
			ret.Allowed = true
			return ret
		}
		if !ret.ACLResults.Allowed {
			return ret
		}
		// Since HelpOperation was fast-pathed inside AllowOperation, RootPrivs will not have been populated in this
		// case, so we need to special-case that here as well, or we'll block HelpOperation on all sudo-protected paths.
		if !ret.RootPrivs && opts.RootPrivsRequired && req.Operation != logical.HelpOperation {
			return ret
		}
	}

	ret.Allowed = true

	return ret
}

// setupPolicyStore is used to initialize the policy store
// when the vault is being unsealed.
func (c *Core) setupPolicyStore(ctx context.Context, standby bool) error {
	// Create the policy store
	var err error
	sysView := &dynamicSystemView{core: c}
	psLogger := c.baseLogger.Named("policy")
	c.AddLogger(psLogger)
	c.policyStore, err = policy.NewStore(ctx, c, c.systemBarrierView, sysView, psLogger)
	if err != nil {
		return err
	}

	if standby {
		return nil
	}

	// Ensure that the default policy exists, and if not, create it. Do not do
	// this on standby nodes as it writes to storage.
	return c.policyStore.LoadDefaultPolicies(ctx)
}

// teardownPolicyStore is used to reverse setupPolicyStore
// when the vault is being sealed.
func (c *Core) teardownPolicyStore() error {
	c.policyStore = nil
	return nil
}
