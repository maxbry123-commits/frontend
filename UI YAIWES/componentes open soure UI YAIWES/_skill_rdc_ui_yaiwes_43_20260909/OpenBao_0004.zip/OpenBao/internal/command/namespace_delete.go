// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package command

import (
	"fmt"
	"strings"

	"github.com/hashicorp/cli"
	"github.com/posener/complete"
)

var (
	_ cli.Command             = (*NamespaceDeleteCommand)(nil)
	_ cli.CommandAutocomplete = (*NamespaceDeleteCommand)(nil)
)

type NamespaceDeleteCommand struct {
	*BaseCommand
}

func (c *NamespaceDeleteCommand) Synopsis() string {
	return "Delete an existing namespace"
}

func (c *NamespaceDeleteCommand) Help() string {
	helpText := `
Usage: bao namespace delete [options] PATH

  Delete a namespace.

  The namespace deleted will be relative to the namespace provided in either the
  BAO_NAMESPACE environment variable or -namespace CLI flag.

  Delete a namespace (e.g. ns1/):

      $ bao namespace delete ns1

  Delete a namespace from a parent namespace (e.g. ns1/ns2/):

      $ bao namespace delete -namespace=ns1 ns2

  To delete a sealed namespace, use the delete-sealed subcommand instead:

      $ bao namespace delete-sealed ns1

  Note that this requires the sudo capability, and will not clean up external
  resources via lease deletion like standard namespace deletion does.

` + c.Flags().Help()

	return strings.TrimSpace(helpText)
}

func (c *NamespaceDeleteCommand) Flags() *FlagSets {
	return c.flagSet(FlagSetHTTP)
}

func (c *NamespaceDeleteCommand) AutocompleteArgs() complete.Predictor {
	return c.PredictVaultNamespaces()
}

func (c *NamespaceDeleteCommand) AutocompleteFlags() complete.Flags {
	return c.Flags().Completions()
}

func (c *NamespaceDeleteCommand) Run(args []string) int {
	f := c.Flags()

	if err := f.Parse(args); err != nil {
		c.UI.Error(err.Error())
		return 1
	}

	args = f.Args()
	switch {
	case len(args) < 1:
		c.UI.Error(fmt.Sprintf("Not enough arguments (expected 1, got %d)", len(args)))
		return 1
	case len(args) > 1:
		c.UI.Error(fmt.Sprintf("Too many arguments (expected 1, got %d)", len(args)))
		return 1
	}

	namespacePath := strings.TrimSpace(args[0])

	client, err := c.Client()
	if err != nil {
		c.UI.Error(err.Error())
		return 2
	}

	resp, err := client.Sys().DeleteNamespace(namespacePath)
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error deleting namespace: %s", err))
		return 2
	}

	if resp == nil || resp.Status == "" {
		c.UI.Warn("Requested namespace does not exist")
		return 0
	}

	if !strings.HasSuffix(namespacePath, "/") {
		namespacePath = namespacePath + "/"
	}

	c.UI.Output(fmt.Sprintf("Success! Namespace deletion scheduled: %s", namespacePath))
	return 0
}
