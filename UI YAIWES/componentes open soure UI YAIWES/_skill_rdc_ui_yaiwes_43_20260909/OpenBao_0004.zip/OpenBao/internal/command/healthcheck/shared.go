// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package healthcheck

import (
	"fmt"

	"github.com/openbao/openbao/sdk/v2/logical"
)

func StringList(source any) ([]string, error) {
	if source == nil {
		return nil, nil
	}

	if value, ok := source.([]string); ok {
		return value, nil
	}

	if rValues, ok := source.([]any); ok {
		var result []string
		for index, rValue := range rValues {
			value, ok := rValue.(string)
			if !ok {
				return nil, fmt.Errorf("unknown source type for []string coercion at index %v: %T", index, rValue)
			}

			result = append(result, value)
		}

		return result, nil
	}

	return nil, fmt.Errorf("unknown source type for []string coercion: %T", source)
}

func fetchMountTune(e *Executor, versionError func()) (bool, *PathFetch, map[string]any, error) {
	tuneRet, err := e.FetchIfNotFetched(logical.ReadOperation, "/sys/mounts/{{mount}}/tune")
	if err != nil {
		return true, nil, nil, fmt.Errorf("failed to fetch mount tune information: %w", err)
	}

	if !tuneRet.IsSecretOK() {
		if tuneRet.IsUnsupportedPathError() {
			versionError()
		}

		return true, tuneRet, nil, nil
	}

	var data map[string]any = nil
	if len(tuneRet.Secret.Data) > 0 {
		data = tuneRet.Secret.Data
	}

	return false, tuneRet, data, nil
}
