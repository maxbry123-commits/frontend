// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package command

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"strings"

	"github.com/hashicorp/cli"
	"github.com/hashicorp/go-secure-stdlib/password"
	"github.com/openbao/openbao/api/v2"
	"github.com/openbao/openbao/sdk/v2/helper/structtomap"
	"github.com/openbao/openbao/v2/internal/helper/pgpkeys"
	"github.com/posener/complete"
)

var (
	_ cli.Command             = (*OperatorRekeyCommand)(nil)
	_ cli.CommandAutocomplete = (*OperatorRekeyCommand)(nil)
)

type OperatorRekeyCommand struct {
	*BaseCommand

	flagCancel       bool
	flagInit         bool
	flagKeyShares    int
	flagKeyThreshold int
	flagNonce        string
	flagPGPKeys      []string
	flagStatus       bool
	flagTarget       string
	flagVerify       bool

	// Backup options
	flagBackup         bool
	flagBackupDelete   bool
	flagBackupRetrieve bool

	testStdin io.Reader // for tests
}

func (c *OperatorRekeyCommand) Synopsis() string {
	return "Generates new unseal keys"
}

func (c *OperatorRekeyCommand) Help() string {
	helpText := `
Usage: bao operator rekey [options] [KEY]

  WARNING: this method is deprecated, please use:
    $ bao operator rotate-keys
  instead.

  Generates a new set of unseal keys. This can optionally change the total
  number of key shares or the required threshold of those key shares to
  reconstruct the root key. This operation is zero downtime, but it requires
  that the OpenBao instance is unsealed and a quorum of existing unseal keys
  are provided.

  An unseal key may be provided directly on the command line as an argument to
  the command. If key is specified as "-", the command will read from stdin. If
  a TTY is available, the command will prompt for text.

  If the flag -target=recovery is supplied, then this operation will require a
  quorum of recovery keys in order to generate a new set of recovery keys.

  Initialize a rekey:

      $ bao operator rekey \
          -init \
          -key-shares=15 \
          -key-threshold=9

  Rekey and encrypt the resulting unseal keys with PGP:

      $ bao operator rekey \
          -init \
          -key-shares=3 \
          -key-threshold=2 \
          -pgp-keys="keybase:hashicorp,keybase:jefferai,keybase:sethvargo"

  Store encrypted PGP keys in OpenBao's core:

      $ bao operator rekey \
          -init \
          -pgp-keys="..." \
          -backup

  Retrieve backed-up unseal keys:

      $ bao operator rekey -backup-retrieve

  Delete backed-up unseal keys:

      $ bao operator rekey -backup-delete

` + c.Flags().Help()
	return strings.TrimSpace(helpText)
}

func (c *OperatorRekeyCommand) Flags() *FlagSets {
	set := c.flagSet(FlagSetHTTP | FlagSetOutputFormat)
	f := set.NewFlagSet("Common Options")

	f.BoolVar(&BoolVar{
		Name:    "init",
		Target:  &c.flagInit,
		Default: false,
		Usage: "Initialize the rekeying operation. This can only be done if no " +
			"rekeying operation is in progress. Customize the new number of key " +
			"shares and key threshold using the -key-shares and -key-threshold " +
			"flags.",
	})

	f.BoolVar(&BoolVar{
		Name:    "cancel",
		Target:  &c.flagCancel,
		Default: false,
		Usage: "Reset the rekeying progress. This will discard any submitted " +
			"unseal keys, recovery keys, or configuration.",
	})

	f.BoolVar(&BoolVar{
		Name:    "status",
		Target:  &c.flagStatus,
		Default: false,
		Usage: "Print the status of the current attempt without providing an " +
			"unseal or recovery key.",
	})

	f.IntVar(&IntVar{
		Name:       "key-shares",
		Aliases:    []string{"n"},
		Target:     &c.flagKeyShares,
		Default:    5,
		Completion: complete.PredictAnything,
		Usage: "Number of key shares to split the generated root key into. " +
			"This is the number of \"unseal keys\" or \"recovery keys\" to generate.",
	})

	f.IntVar(&IntVar{
		Name:       "key-threshold",
		Aliases:    []string{"t"},
		Target:     &c.flagKeyThreshold,
		Default:    3,
		Completion: complete.PredictAnything,
		Usage: "Number of key shares required to reconstruct the root key. " +
			"This must be less than or equal to -key-shares.",
	})

	f.StringVar(&StringVar{
		Name:       "nonce",
		Target:     &c.flagNonce,
		Default:    "",
		EnvVar:     "",
		Completion: complete.PredictAnything,
		Usage: "Nonce value provided at initialization. The same nonce value " +
			"must be provided with each unseal or recovery key.",
	})

	f.StringVar(&StringVar{
		Name:       "target",
		Target:     &c.flagTarget,
		Default:    "barrier",
		EnvVar:     "",
		Completion: complete.PredictSet("barrier", "recovery"),
		Usage:      "Target for rekeying. \"recovery\" only applies for auto-seals.",
	})

	f.BoolVar(&BoolVar{
		Name:    "verify",
		Target:  &c.flagVerify,
		Default: false,
		Usage: "Indicates that the action (-status, -cancel, or providing a key " +
			"share) will be affecting verification for the current rekey " +
			"attempt.",
	})

	f.VarFlag(&VarFlag{
		Name:       "pgp-keys",
		Value:      (*pgpkeys.PubKeyFilesFlag)(&c.flagPGPKeys),
		Completion: complete.PredictAnything,
		Usage: "Comma-separated list of paths to files on disk containing " +
			"public PGP keys OR a comma-separated list of Keybase usernames using " +
			"the format \"keybase:<username>\". When supplied, the generated " +
			"unseal or recovery keys will be encrypted and base64-encoded in the order " +
			"specified in this list.",
	})

	f = set.NewFlagSet("Backup Options")

	f.BoolVar(&BoolVar{
		Name:    "backup",
		Target:  &c.flagBackup,
		Default: false,
		Usage: "Store a backup of the current PGP encrypted unseal or recovery keys in " +
			"OpenBao's core. The encrypted values can be recovered in the event of " +
			"failure or discarded after success. See the -backup-delete and " +
			"-backup-retrieve options for more information. This option only " +
			"applies when the existing unseal or recovery keys were PGP encrypted.",
	})

	f.BoolVar(&BoolVar{
		Name:    "backup-delete",
		Target:  &c.flagBackupDelete,
		Default: false,
		Usage:   "Delete any stored backup unseal or recovery keys.",
	})

	f.BoolVar(&BoolVar{
		Name:    "backup-retrieve",
		Target:  &c.flagBackupRetrieve,
		Default: false,
		Usage: "Retrieve the backed-up unseal or recovery keys. This option is only available " +
			"if the PGP keys were provided and the backup has not been deleted.",
	})

	return set
}

func (c *OperatorRekeyCommand) AutocompleteArgs() complete.Predictor {
	return complete.PredictAnything
}

func (c *OperatorRekeyCommand) AutocompleteFlags() complete.Flags {
	return c.Flags().Completions()
}

func (c *OperatorRekeyCommand) Run(args []string) int {
	f := c.Flags()

	if err := f.Parse(args); err != nil {
		c.UI.Error(err.Error())
		return 1
	}

	args = f.Args()
	if len(args) > 1 {
		c.UI.Error(fmt.Sprintf("Too many arguments (expected 0-1, got %d)", len(args)))
		return 1
	}

	// Create the client
	client, err := c.Client()
	if err != nil {
		c.UI.Error(err.Error())
		return 2
	}

	switch {
	case c.flagBackupDelete:
		return c.backupDelete(client)
	case c.flagBackupRetrieve:
		return c.backupRetrieve(client)
	case c.flagCancel:
		return c.cancel(client)
	case c.flagInit:
		return c.init(client)
	case c.flagStatus:
		return c.status(client)
	default:
		// If there are no other flags, prompt for an unseal key.
		key := ""
		if len(args) > 0 {
			key = strings.TrimSpace(args[0])
		}
		return c.provide(client, key)
	}
}

// init starts the rekey process.
func (c *OperatorRekeyCommand) init(client *api.Client) int {
	// Handle the different API requests
	var fn func(*api.RotateInitRequest) (*api.RotateStatusResponse, error)
	keyTypeRequired := keyTypeUnseal
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyInit
	case "recovery", "hsm":
		keyTypeRequired = keyTypeRecovery
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyRecoveryKeyInit
	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	// Make the request
	status, err := fn(&api.RotateInitRequest{
		SecretShares:        c.flagKeyShares,
		SecretThreshold:     c.flagKeyThreshold,
		PGPKeys:             c.flagPGPKeys,
		Backup:              c.flagBackup,
		RequireVerification: c.flagVerify,
	})
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error initializing rekey: %s", err))
		return 2
	}

	if Format(c.UI) == "table" {
		// special case when we rotate root key while running auto seal
		// meaning we do not rotate unseal/recovery shares.
		if status.T == 0 && status.N == 0 {
			c.UI.Output("")
			c.UI.Info("Rotating barrier root key using recovery shares.")
			c.UI.Output("")
			return printRotationStatus(c.UI, status)
		}

		// Print warnings about recovery, etc.
		if len(c.flagPGPKeys) == 0 {
			c.UI.Warn(wrapAtLength(
				fmt.Sprintf("WARNING! If you lose the keys after they are "+
					"returned, there is no recovery. Consider canceling this "+
					"operation and re-initializing with the -pgp-keys flag to protect "+
					"the returned %s keys along with -backup to allow recovery of the "+
					"encrypted keys in case of emergency. You can delete the stored "+
					"keys later using the -delete flag.",
					strings.ToLower(keyTypeRequired)),
			))
			c.UI.Output("")
		}
		if len(c.flagPGPKeys) > 0 && !c.flagBackup {
			c.UI.Warn(wrapAtLength(
				fmt.Sprintf("WARNING! You are using PGP keys for encryption "+
					"of resulting %s keys, but you did not enable the option to backup "+
					"the keys to OpenBao's core. If you lose the encrypted keys after "+
					"they are returned, you will not be able to recover them. Consider "+
					"canceling this operation and re-running with -backup to allow "+
					"recovery of the encrypted unseal keys in case of emergency. You "+
					"can delete the backed up keys later using the -delete flag.",
					strings.ToLower(keyTypeRequired)),
			))
			c.UI.Output("")
		}
	}

	// Provide current status.
	return printRotationStatus(c.UI, status)
}

// cancel is used to abort the rekey process.
func (c *OperatorRekeyCommand) cancel(client *api.Client) int {
	// Handle the different API requests
	var fn func() error
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyCancel
		if c.flagVerify {
			//nolint:staticcheck // endpoint already marked as deprecated
			fn = client.Sys().RekeyVerificationCancel
		}
	case "recovery", "hsm":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyRecoveryKeyCancel
		if c.flagVerify {
			//nolint:staticcheck // endpoint already marked as deprecated
			fn = client.Sys().RekeyRecoveryKeyVerificationCancel
		}

	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	// Make the request
	if err := fn(); err != nil {
		c.UI.Error(fmt.Sprintf("Error canceling rekey: %s", err))
		return 2
	}

	c.UI.Output("Success! Canceled rekeying (if it was started)")
	return 0
}

// provide prompts the user for the seal key and posts it to the update root
// endpoint. If this is the last unseal, this function outputs it.
func (c *OperatorRekeyCommand) provide(client *api.Client, key string) int {
	var statusFn func() (any, error)
	var updateFn func(string, string) (any, error)
	keyTypeRequired := keyTypeUnseal
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		statusFn = func() (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyStatus()
		}
		updateFn = func(s1 string, s2 string) (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyUpdate(s1, s2)
		}
		if c.flagVerify {
			statusFn = func() (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyVerificationStatus()
			}
			updateFn = func(s1 string, s2 string) (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyVerificationUpdate(s1, s2)
			}
		}
	case "recovery", "hsm":
		keyTypeRequired = keyTypeRecovery
		statusFn = func() (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyRecoveryKeyStatus()
		}
		updateFn = func(s1 string, s2 string) (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyRecoveryKeyUpdate(s1, s2)
		}
		if c.flagVerify {
			statusFn = func() (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyRecoveryKeyVerificationStatus()
			}
			updateFn = func(s1 string, s2 string) (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyRecoveryKeyVerificationUpdate(s1, s2)
			}
		}
	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	status, err := statusFn()
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error getting rekey status: %s", err))
		return 2
	}

	var started bool
	var nonce string

	switch status := status.(type) {
	case *api.RotateStatusResponse:
		stat := status
		started = stat.Started
		nonce = stat.Nonce
	case *api.RotateVerificationStatusResponse:
		stat := status
		started = stat.Started
		nonce = stat.Nonce
	default:
		c.UI.Error("Unknown status type")
		return 1
	}

	// Verify a root token generation is in progress. If there is not one in
	// progress, return an error instructing the user to start one.
	if !started {
		c.UI.Error(wrapAtLength(
			"No rekey is in progress. Start a rekey process by running " +
				"\"bao operator rekey -init\".",
		))
		return 1
	}

	switch key {
	case "-": // Read from stdin
		nonce = c.flagNonce

		// Pull our fake stdin if needed
		stdin := io.Reader(os.Stdin)
		if c.testStdin != nil {
			stdin = c.testStdin
		}
		if c.flagNonInteractive {
			stdin = bytes.NewReader(nil)
		}

		var buf bytes.Buffer
		if _, err := io.Copy(&buf, stdin); err != nil {
			c.UI.Error(fmt.Sprintf("Failed to read from stdin: %s", err))
			return 1
		}

		key = buf.String()
	case "": // Prompt using the tty
		// Nonce value is not required if we are prompting via the terminal
		if c.flagNonInteractive {
			c.UI.Error(wrapAtLength("Refusing to read from stdin with -non-interactive specified; specify nonce via the -nonce flag"))
			return 1
		}

		w := getWriterFromUI(c.UI)
		_, _ = fmt.Fprintf(w, "Rekey operation nonce: %s\n", nonce)
		_, _ = fmt.Fprintf(w, "%s Key (will be hidden): ", keyTypeRequired)
		key, err = password.Read(os.Stdin)
		_, _ = fmt.Fprintf(w, "\n")
		if err != nil {
			if err == password.ErrInterrupted {
				c.UI.Error("user canceled")
				return 1
			}

			c.UI.Error(wrapAtLength(fmt.Sprintf("An error occurred attempting to "+
				"ask for the %s key. The raw error message is shown below, but "+
				"usually this is because you attempted to pipe a value into the "+
				"command or you are executing outside of a terminal (tty). If you "+
				"want to pipe the value, pass \"-\" as the argument to read from "+
				"stdin. The raw error was: %s", strings.ToLower(keyTypeRequired), err)))
			return 1
		}
	default: // Supplied directly as an arg
		nonce = c.flagNonce
	}

	// Trim any whitespace from they key, especially since we might have
	// prompted the user for it.
	key = strings.TrimSpace(key)

	// Verify we have a nonce value
	if nonce == "" {
		c.UI.Error("Missing nonce value: specify it via the -nonce flag")
		return 1
	}

	// Provide the key, this may potentially complete the update
	resp, err := updateFn(key, nonce)
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error posting unseal key: %s", err))
		return 2
	}

	var complete bool
	var mightContainUnsealKeys bool

	switch resp := resp.(type) {
	case *api.RotateUpdateResponse:
		complete = resp.Complete
		mightContainUnsealKeys = true
	case *api.RotateVerificationUpdateResponse:
		complete = resp.Complete
	default:
		c.UI.Error("Unknown update response type")
		return 1
	}

	if !complete {
		return c.status(client)
	}

	if mightContainUnsealKeys {
		if Format(c.UI) != "table" {
			return OutputData(c.UI, resp)
		}
		c.UI.Output("")
		printUnsealKeys(c.UI, resp.(*api.RotateUpdateResponse))
		return c.printWarnings(client, status.(*api.RotateStatusResponse), resp.(*api.RotateUpdateResponse))
	}

	c.UI.Output(wrapAtLength("Rekey verification successful. The rekey operation is complete and the new keys are now active."))
	return 0
}

// status is used just to fetch and dump the status.
func (c *OperatorRekeyCommand) status(client *api.Client) int {
	// Handle the different API requests
	var fn func() (any, error)
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		fn = func() (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyStatus()
		}
		if c.flagVerify {
			fn = func() (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyVerificationStatus()
			}
		}
	case "recovery", "hsm":
		fn = func() (any, error) {
			//nolint:staticcheck // endpoint already marked as deprecated
			return client.Sys().RekeyRecoveryKeyStatus()
		}
		if c.flagVerify {
			fn = func() (any, error) {
				//nolint:staticcheck // endpoint already marked as deprecated
				return client.Sys().RekeyRecoveryKeyVerificationStatus()
			}
		}
	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	// Make the request
	status, err := fn()
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error reading rekey status: %s", err))
		return 2
	}

	return printRotationStatus(c.UI, status)
}

// backupRetrieve retrieves the stored backup keys.
func (c *OperatorRekeyCommand) backupRetrieve(client *api.Client) int {
	// Handle the different API requests
	var fn func() (*api.RotateRetrieveResponse, error)
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyRetrieveBackup
	case "recovery", "hsm":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyRetrieveRecoveryBackup
	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	// Make the request
	storedKeys, err := fn()
	if err != nil {
		c.UI.Error(fmt.Sprintf("Error retrieving rekey backed up keys: %s", err))
		return 2
	}

	secret := &api.Secret{
		Data: structtomap.Map(storedKeys),
	}

	return OutputSecret(c.UI, secret)
}

// backupDelete deletes the stored backup keys.
func (c *OperatorRekeyCommand) backupDelete(client *api.Client) int {
	// Handle the different API requests
	var fn func() error
	switch strings.ToLower(strings.TrimSpace(c.flagTarget)) {
	case "barrier":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyDeleteBackup
	case "recovery", "hsm":
		//nolint:staticcheck // endpoint already marked as deprecated
		fn = client.Sys().RekeyDeleteRecoveryBackup
	default:
		c.UI.Error(fmt.Sprintf("Unknown target: %s", c.flagTarget))
		return 1
	}

	// Make the request
	if err := fn(); err != nil {
		c.UI.Error(fmt.Sprintf("Error deleting rekey backed up keys: %s", err))
		return 2
	}

	c.UI.Output("Success! Deleted backed up keys (if they existed)")
	return 0
}

func (c *OperatorRekeyCommand) printWarnings(client *api.Client, status *api.RotateStatusResponse, resp *api.RotateUpdateResponse) int {
	// barrier root key rotation while running auto seal case.
	if len(resp.Keys) == 0 {
		c.UI.Output("")
		c.UI.Output("Barrier root key rotated using recovery keys.")
		return 0
	}

	if resp.Nonce != "" {
		c.UI.Output("")
		c.UI.Output(fmt.Sprintf("Operation nonce: %s", resp.Nonce))
	}

	target := strings.ToLower(strings.TrimSpace(c.flagTarget))
	if len(resp.PGPFingerprints) > 0 && resp.Backup {
		c.UI.Output("")
		switch target {
		case "barrier":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"The encrypted unseal keys are backed up to \"core/unseal-keys-backup\" " +
					"in the storage backend. Remove these keys at any time using " +
					"\"bao operator rekey -backup-delete\". OpenBao does not automatically " +
					"remove these keys.",
			)))
		case "recovery", "hsm":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"The encrypted recovery keys are backed up to \"core/recovery-keys-backup\" " +
					"in the storage backend. Remove these keys at any time using " +
					"\"bao operator rekey -backup-delete -target=recovery\". OpenBao does not automatically " +
					"remove these keys.",
			)))
		}
	}

	if status.VerificationRequired {
		c.UI.Output("")
		var warningText string
		switch target {
		case "barrier":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"OpenBao has created a new unseal key, split into %d key shares and a "+
					"key threshold of %d. These will not be active until after verification is "+
					"complete. Please securely distribute the key shares printed above. When "+
					" OpenBao is re-sealed, restarted, or stopped, you must supply at least %d "+
					"of these keys to unseal it before it can start servicing requests.",
				status.N,
				status.T,
				status.T,
			)))
			warningText = "unseal"
		case "recovery", "hsm":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"OpenBao has created a new recovery key, split into %d key shares and a "+
					"key threshold of %d. These will not be active until after verification is "+
					"complete. Please securely distribute the key shares printed above.",
				status.N,
				status.T,
			)))
			warningText = "authenticate with"
		}

		c.UI.Output("")
		c.UI.Warn(wrapAtLength(fmt.Sprintf(
			"Again, these key shares are _not_ valid until verification is performed. "+
				"Do not lose or discard your current key shares until after verification "+
				"is complete or you will be unable to %s OpenBao. If you cancel the "+
				"rekey process or seal OpenBao before verification is complete the new "+
				"shares will be discarded and the current shares will remain valid.", warningText,
		)))
		c.UI.Output("")
		c.UI.Warn(wrapAtLength(
			"The current verification status, including initial nonce, is shown below.",
		))
		c.UI.Output("")

		c.flagVerify = true
		return c.status(client)
	} else {
		c.UI.Output("")
		switch target {
		case "barrier":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"OpenBao unseal keys rekeyed to %d key shares and a key threshold of %d. "+
					"Please securely distribute the key shares printed above. When OpenBao is "+
					"re-sealed, restarted, or stopped, you must supply at least %d of "+
					"these keys to unseal it before it can start servicing requests.",
				status.N,
				status.T,
				status.T,
			)))
		case "recovery", "hsm":
			c.UI.Output(wrapAtLength(fmt.Sprintf(
				"OpenBao recovery keys rekeyed to %d key shares and a key threshold of %d. "+
					"Please securely distribute the key shares printed above.",
				status.N,
				status.T,
			)))
		}
	}

	return 0
}
