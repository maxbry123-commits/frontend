// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package server

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"maps"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/go-viper/mapstructure/v2"
	"github.com/google/go-containerregistry/pkg/name"
	"github.com/hashicorp/go-multierror"
	"github.com/hashicorp/go-secure-stdlib/parseutil"
	"github.com/hashicorp/hcl"
	"github.com/hashicorp/hcl/hcl/ast"
	"github.com/openbao/openbao/api/v2"
	"github.com/openbao/openbao/sdk/v2/helper/consts"
	"github.com/openbao/openbao/sdk/v2/helper/hclutil"
	"github.com/openbao/openbao/sdk/v2/helper/testcluster"
	"github.com/openbao/openbao/v2/internal/helper/configutil"
	"github.com/openbao/openbao/v2/internal/helper/osutil"
	"github.com/openbao/openbao/v2/internal/helper/profiles"
)

const (
	VaultDevCAFilename   = "vault-ca.pem"
	VaultDevCertFilename = "vault-cert.pem"
	VaultDevKeyFilename  = "vault-key.pem"

	PluginDownloadFail     = "fail"
	PluginDownloadContinue = "continue"
)

// Config is the configuration for the vault server.
type Config struct {
	UnusedKeys configutil.UnusedKeyMap `hcl:",unusedKeyPositions"`
	FoundKeys  []string                `hcl:",decodedFields"`

	*configutil.SharedConfig `hcl:"-"`

	Storage   *Storage `hcl:"-"`
	HAStorage *Storage `hcl:"-"`

	ServiceRegistration *ServiceRegistration `hcl:"-"`

	CacheSize                int  `hcl:"cache_size"`
	DisableCache             bool `hcl:"-"`
	DisableCacheRaw          any  `hcl:"disable_cache"`
	DisablePrintableCheck    bool `hcl:"-"`
	DisablePrintableCheckRaw any  `hcl:"disable_printable_check"`

	EnableUI    bool `hcl:"-"`
	EnableUIRaw any  `hcl:"ui"`

	MaxLeaseTTL        time.Duration `hcl:"-"`
	MaxLeaseTTLRaw     any           `hcl:"max_lease_ttl,alias:MaxLeaseTTL"`
	DefaultLeaseTTL    time.Duration `hcl:"-"`
	DefaultLeaseTTLRaw any           `hcl:"default_lease_ttl,alias:DefaultLeaseTTL"`

	ClusterCipherSuites string `hcl:"cluster_cipher_suites"`

	PluginDirectory string `hcl:"plugin_directory"`

	PluginFileUid int `hcl:"plugin_file_uid"`

	PluginFilePermissions    int `hcl:"-"`
	PluginFilePermissionsRaw any `hcl:"plugin_file_permissions,alias:PluginFilePermissions"`

	// Plugins specifies declaratively defined external plugins
	Plugins                []*PluginConfig `hcl:"-"`
	PluginDownloadBehavior string          `hcl:"plugin_download_behavior"`
	PluginAutoDownload     bool            `hcl:"-"`
	PluginAutoDownloadRaw  any             `hcl:"plugin_auto_download"`
	PluginAutoRegister     bool            `hcl:"-"`
	PluginAutoRegisterRaw  any             `hcl:"plugin_auto_register"`

	PluginDownloadMaxSize    int64 `hcl:"-"`
	PluginDownloadMaxSizeRaw any   `hcl:"plugin_download_max_size"`

	EnableIntrospectionEndpoint    bool `hcl:"-"`
	EnableIntrospectionEndpointRaw any  `hcl:"introspection_endpoint,alias:EnableIntrospectionEndpoint"`

	EnableRawEndpoint    bool `hcl:"-"`
	EnableRawEndpointRaw any  `hcl:"raw_storage_endpoint,alias:EnableRawEndpoint"`

	APIAddr              string `hcl:"api_addr"`
	ClusterAddr          string `hcl:"cluster_addr"`
	DisableClustering    bool   `hcl:"-"`
	DisableClusteringRaw any    `hcl:"disable_clustering,alias:DisableClustering"`

	DisablePerformanceStandby    bool `hcl:"-"`
	DisablePerformanceStandbyRaw any  `hcl:"disable_performance_standby,alias:DisablePerformanceStandby"`

	DisableSealWrap    bool `hcl:"-"`
	DisableSealWrapRaw any  `hcl:"disable_sealwrap,alias:DisableSealWrap"`

	DisableIndexing    bool `hcl:"-"`
	DisableIndexingRaw any  `hcl:"disable_indexing,alias:DisableIndexing"`

	DisableSentinelTrace    bool `hcl:"-"`
	DisableSentinelTraceRaw any  `hcl:"disable_sentinel_trace,alias:DisableSentinelTrace"`

	EnableResponseHeaderHostname    bool `hcl:"-"`
	EnableResponseHeaderHostnameRaw any  `hcl:"enable_response_header_hostname"`

	LogRequestsLevel    string `hcl:"-"`
	LogRequestsLevelRaw any    `hcl:"log_requests_level"`

	DetectDeadlocks string `hcl:"detect_deadlocks"`

	ImpreciseLeaseRoleTracking bool `hcl:"imprecise_lease_role_tracking"`

	EnableResponseHeaderRaftNodeID    bool `hcl:"-"`
	EnableResponseHeaderRaftNodeIDRaw any  `hcl:"enable_response_header_raft_node_id"`

	DisableSSCTokens    *bool `hcl:"-"`
	DisableSSCTokensRaw any   `hcl:"disable_ssct_tokens"`

	UnsafeCrossNamespaceIdentity bool `hcl:"unsafe_cross_namespace_identity"`

	UnsafeAllowAPIAuditCreation bool `hcl:"unsafe_allow_api_audit_creation"`
	AllowAuditLogPrefixing      bool `hcl:"allow_audit_log_prefixing"`

	// Initialization is a configuration object that helps to initialize
	// OpenBao. It can be specified multiple times and each instance can
	// contain one or more `request` objects. This is used by the
	// declarative self-initialization subsystem on non-dev-mode instances
	// and is part of the profile system.
	Initialization []*profiles.OuterConfig `hcl:"-"`

	// Audit specifies declaratively defined audit devices; these are created
	// on the active node. Updates cannot occur, only additions or deletions,
	// but can be modified through SIGHUP on a running server.
	Audits []*AuditDevice `hcl:"-"`

	// Whether read requests are disabled on standby nodes.
	DisableStandbyReads bool `hcl:"disable_standby_reads"`

	// Whether to allow unauthenticated workflows. While not inherently unsafe,
	// as requests created by workflows still require authentication and a
	// workflow author would have to embed a token, these still should be used
	// with care.
	AllowUnauthenticatedWorkflows bool `hcl:"allow_unauthenticated_workflows"`

	// Whether to allow unsafe (usually URL encoded) relative request paths
	// (containing `..`).
	UnsafeRelativePaths bool `hcl:"unsafe_relative_paths"`
}

func (c *Config) Validate(sourceFilePath string) []configutil.ConfigError {
	results := configutil.ValidateUnusedFields(c.UnusedKeys, sourceFilePath)
	if c.Telemetry != nil {
		results = append(results, c.Telemetry.Validate(sourceFilePath)...)
	}
	if c.ServiceRegistration != nil {
		results = append(results, c.ServiceRegistration.Validate(sourceFilePath)...)
	}
	for _, l := range c.Listeners {
		results = append(results, l.Validate(sourceFilePath)...)
	}
	for _, a := range c.Audits {
		results = append(results, a.Validate(sourceFilePath)...)
	}
	for _, p := range c.Plugins {
		results = append(results, p.Validate(sourceFilePath)...)
	}
	for _, o := range c.Initialization {
		results = append(results, o.ValidateUnused(sourceFilePath)...)
	}

	// Validate plugin_download_behavior
	if c.PluginDownloadBehavior != "" {
		if c.PluginDownloadBehavior != PluginDownloadFail && c.PluginDownloadBehavior != PluginDownloadContinue {
			results = append(results, configutil.ConfigError{
				Problem: fmt.Sprintf("plugin_download_behavior must be either %q or %q, got %q", PluginDownloadFail, PluginDownloadContinue, c.PluginDownloadBehavior),
			})
		}
	}

	return results
}

// DevConfig is a Config that is used for dev mode of OpenBao.
func DevConfig(storageType string) (*Config, error) {
	hclStr := `
listener "tcp" {
	address = "127.0.0.1:8200"
	tls_disable = true
	proxy_protocol_behavior = "allow_authorized"
	proxy_protocol_authorized_addrs = "127.0.0.1:8200"
}

telemetry {
	prometheus_retention_time = "24h"
	disable_hostname = true
}
enable_raw_endpoint = true

storage "%s" {
}

ui = true
`

	hclStr = fmt.Sprintf(hclStr, storageType)
	parsed, err := ParseConfig(hclStr, "")
	if err != nil {
		return nil, fmt.Errorf("error parsing dev config: %w", err)
	}
	return parsed, nil
}

// DevTLSConfig is a Config that is used for dev tls mode of Vault.
func DevTLSConfig(storageType, certDir string) (*Config, error) {
	ca, err := GenerateCA()
	if err != nil {
		return nil, err
	}

	cert, key, err := GenerateCert(ca.Template, ca.Signer)
	if err != nil {
		return nil, err
	}

	if err := os.WriteFile(fmt.Sprintf("%s/%s", certDir, VaultDevCAFilename), []byte(ca.PEM), 0o444); err != nil {
		return nil, err
	}

	if err := os.WriteFile(fmt.Sprintf("%s/%s", certDir, VaultDevCertFilename), []byte(cert), 0o400); err != nil {
		return nil, err
	}

	if err := os.WriteFile(fmt.Sprintf("%s/%s", certDir, VaultDevKeyFilename), []byte(key), 0o400); err != nil {
		return nil, err
	}
	return parseDevTLSConfig(storageType, certDir)
}

func parseDevTLSConfig(storageType, certDir string) (*Config, error) {
	hclStr := `
listener "tcp" {
	address = "[::]:8200"
	tls_cert_file = "%s/vault-cert.pem"
	tls_key_file = "%s/vault-key.pem"
	proxy_protocol_behavior = "allow_authorized"
	proxy_protocol_authorized_addrs = "[::]:8200"
}

telemetry {
	prometheus_retention_time = "24h"
	disable_hostname = true
}
enable_raw_endpoint = true

storage "%s" {
}

ui = true
`
	certDirEscaped := strings.ReplaceAll(certDir, "\\", "\\\\")
	hclStr = fmt.Sprintf(hclStr, certDirEscaped, certDirEscaped, storageType)
	parsed, err := ParseConfig(hclStr, "")
	if err != nil {
		return nil, err
	}

	return parsed, nil
}

// Storage is the underlying storage configuration for the server.
type Storage struct {
	Type              string
	RedirectAddr      string
	ClusterAddr       string
	DisableClustering bool
	Config            map[string]string
}

func (b *Storage) GoString() string {
	return fmt.Sprintf("*%#v", *b)
}

// ServiceRegistration is the optional service discovery for the server.
type ServiceRegistration struct {
	UnusedKeys configutil.UnusedKeyMap `hcl:",unusedKeyPositions"`
	Type       string
	Config     map[string]string
}

func (b *ServiceRegistration) Validate(source string) []configutil.ConfigError {
	return configutil.ValidateUnusedFields(b.UnusedKeys, source)
}

func (b *ServiceRegistration) GoString() string {
	return fmt.Sprintf("*%#v", *b)
}

// PluginConfig represents the configuration for a single OCI-based plugin
type PluginConfig struct {
	UnusedKeys configutil.UnusedKeyMap `hcl:",unusedKeyPositions"`

	Type       string
	Name       string
	Image      name.Reference `hcl:"-"`
	RawImage   string         `hcl:"image"`
	Version    string         `hcl:"version"`
	BinaryName string         `hcl:"binary_name"`
	SHA256Sum  string         `hcl:"sha256sum"`
	Command    string         `hcl:"command"`
	Args       []string       `hcl:"args"`
	Env        []string       `hcl:"env"`
}

func (p *PluginConfig) Slug() string {
	return fmt.Sprintf("%s-%s", p.Type, p.Name)
}

func (p *PluginConfig) FullName() string {
	return fmt.Sprintf("%s-%s-%s", p.Type, p.Name, p.Version)
}

func (p *PluginConfig) CommandPath() string {
	if p.Image != nil {
		return p.FullName()
	}

	return p.Command
}

// Validate validates a PluginConfig
func (p *PluginConfig) Validate(sourceFilePath string) []configutil.ConfigError {
	var results []configutil.ConfigError

	// Validate unused keys
	results = append(results, configutil.ValidateUnusedFields(p.UnusedKeys, sourceFilePath)...)

	// Validate Name is not empty
	if p.Name == "" {
		results = append(results, configutil.ConfigError{
			Problem: "plugin name cannot be empty",
		})
	}

	// Validate Type is not empty
	if p.Type == "" {
		results = append(results, configutil.ConfigError{
			Problem: fmt.Sprintf("plugin %q: type cannot be empty", p.Name),
		})
	}

	// Validate Type is valid
	typ, err := consts.ParsePluginType(p.Type)
	if err != nil {
		results = append(results, configutil.ConfigError{
			Problem: fmt.Sprintf("plugin %q: %s", p.Name, err.Error()),
		})
	}

	// Validate Image is not empty
	if p.Image == nil && p.Command == "" {
		results = append(results, configutil.ConfigError{
			Problem: fmt.Sprintf("plugin %q: image and command cannot both be empty", p.Slug()),
		})
	} else if p.Image != nil && p.Command != "" {
		results = append(results, configutil.ConfigError{
			Problem: fmt.Sprintf("plugin %q: command must be empty if image is specified", p.Slug()),
		})
	}

	if p.Image != nil || typ != consts.PluginTypeKMS {
		// Validate version is not empty. KMS plugins do not require or enforce
		// that a version is set. OCI-based plugins however require a version be
		// set at all times.
		if p.Version == "" {
			results = append(results, configutil.ConfigError{
				Problem: fmt.Sprintf("plugin %q: version cannot be empty", p.Slug()),
			})
		}
	}

	switch {
	case len(p.SHA256Sum) == 0 && p.Image != nil:
		// SHA256Sum may be omitted in OCI image mode if the image reference is
		// a digest reference.
		if _, ok := p.Image.(name.Digest); !ok {
			results = append(results, configutil.ConfigError{
				Problem: fmt.Sprintf("plugin %q: sha256sum must be set if image is not pinned by digest, prefer pinning the image directly", p.Slug()),
			})
		}
	case len(p.SHA256Sum) == 0:
		// SHA256Sum may generally be omitted outside of OCI image mode.
	case len(p.SHA256Sum) != 64:
		// Unless omitted, validate sha256sum is exactly 64 hex characters.
		results = append(results, configutil.ConfigError{
			Problem: fmt.Sprintf("plugin %q: sha256sum must be exactly 64 characters, got %d", p.Slug(), len(p.SHA256Sum)),
		})
	default:
		// Check if it's valid hex
		_, err := hex.DecodeString(p.SHA256Sum)
		if err != nil {
			results = append(results, configutil.ConfigError{
				Problem: fmt.Sprintf("plugin %q: sha256sum is not valid hex encoded", p.Slug()),
			})
		}
	}

	for index, envVar := range p.Env {
		if !strings.Contains(envVar, "=") {
			results = append(results, configutil.ConfigError{
				Problem: fmt.Sprintf("plugin %q: env %d: environment variable must contain '=' to separate variable name from value", p.Slug(), index),
			})
		}
	}

	return results
}

func parsePlugins(block string, list *ast.ObjectList) ([]*PluginConfig, error) {
	result := make([]*PluginConfig, 0, len(list.Items))
	for index, item := range list.Items {
		var p PluginConfig
		if err := hcl.DecodeObject(&p, item.Val); err != nil {
			return result, fmt.Errorf("%v.%d: %w", block, index, err)
		}

		switch {
		case p.Type != "":
		case len(item.Keys) == 2:
			p.Type = item.Keys[0].Token.Value().(string)
		default:
			return result, fmt.Errorf("%v.%d: %v type must be specified: %#v", block, index, block, item)
		}

		switch {
		case p.Name != "":
		case len(item.Keys) == 2:
			p.Name = item.Keys[1].Token.Value().(string)
		default:
			return result, fmt.Errorf("%v.%d: %v name must be specified: %#v", block, index, block, item)
		}

		if p.RawImage != "" {
			// Figure out if this is a digest-based or tag-based reference. We
			// need to know this ahead of passing over to go-containerregistry's
			// parsing as it discards the tag component on digest references,
			// but we'd like to substitute any empty version fields with that.
			parts := strings.SplitN(p.RawImage, "@", 2)

			// Begin by parsing a tag reference.
			tag, err := name.NewTag(parts[0], name.WithDefaultTag(p.Version))
			if err != nil {
				return result, fmt.Errorf("%v.%d: invalid image reference: %w", block, index, err)
			}

			if len(parts) > 1 {
				// If the image reference has an '@', also parse and a digest
				// reference and use that instead.
				p.Image, err = name.NewDigest(p.RawImage)
			} else {
				// Otherwise, just use the tag reference.
				p.Image = tag
			}

			if err != nil {
				return result, fmt.Errorf("%v.%d: invalid image reference: %w", block, index, err)
			}

			if p.Version == "" {
				// Regardless of the reference we ultimately used above, try to
				// replace an unset Version field with the tag reference's tag.
				p.Version = tag.Identifier()
			}
		}

		result = append(result, &p)
	}

	return result, nil
}

func NewConfig() *Config {
	return &Config{
		SharedConfig: new(configutil.SharedConfig),
	}
}

// Merge merges two configurations.
func (c *Config) Merge(c2 *Config) *Config {
	if c2 == nil {
		return c
	}

	result := NewConfig()

	result.SharedConfig = c.SharedConfig
	if c2.SharedConfig != nil {
		result.SharedConfig = c.SharedConfig.Merge(c2.SharedConfig)
	}

	result.Storage = c.Storage
	if c2.Storage != nil {
		result.Storage = c2.Storage
	}

	result.HAStorage = c.HAStorage
	if c2.HAStorage != nil {
		result.HAStorage = c2.HAStorage
	}

	result.ServiceRegistration = c.ServiceRegistration
	if c2.ServiceRegistration != nil {
		result.ServiceRegistration = c2.ServiceRegistration
	}

	result.CacheSize = c.CacheSize
	if c2.CacheSize != 0 {
		result.CacheSize = c2.CacheSize
	}

	// merging these booleans via an OR operation
	result.DisableCache = c.DisableCache
	if c2.DisableCache {
		result.DisableCache = c2.DisableCache
	}

	result.DisableSentinelTrace = c.DisableSentinelTrace
	if c2.DisableSentinelTrace {
		result.DisableSentinelTrace = c2.DisableSentinelTrace
	}

	result.DisablePrintableCheck = c.DisablePrintableCheck
	if c2.DisablePrintableCheckRaw != nil {
		result.DisablePrintableCheck = c2.DisablePrintableCheck
	}

	// merge these integers via a MAX operation
	result.MaxLeaseTTL = max(c2.MaxLeaseTTL, c.MaxLeaseTTL)

	result.DefaultLeaseTTL = max(c2.DefaultLeaseTTL, c.DefaultLeaseTTL)

	result.ClusterCipherSuites = c.ClusterCipherSuites
	if c2.ClusterCipherSuites != "" {
		result.ClusterCipherSuites = c2.ClusterCipherSuites
	}

	result.EnableUI = c.EnableUI
	if c2.EnableUI {
		result.EnableUI = c2.EnableUI
	}

	result.EnableRawEndpoint = c.EnableRawEndpoint
	if c2.EnableRawEndpoint {
		result.EnableRawEndpoint = c2.EnableRawEndpoint
	}

	result.EnableIntrospectionEndpoint = c.EnableIntrospectionEndpoint
	if c2.EnableIntrospectionEndpoint {
		result.EnableIntrospectionEndpoint = c2.EnableIntrospectionEndpoint
	}

	result.APIAddr = c.APIAddr
	if c2.APIAddr != "" {
		result.APIAddr = c2.APIAddr
	}

	result.ClusterAddr = c.ClusterAddr
	if c2.ClusterAddr != "" {
		result.ClusterAddr = c2.ClusterAddr
	}

	// Retain raw value so that it can be assigned to storage objects
	result.DisableClustering = c.DisableClustering
	result.DisableClusteringRaw = c.DisableClusteringRaw
	if c2.DisableClusteringRaw != nil {
		result.DisableClustering = c2.DisableClustering
		result.DisableClusteringRaw = c2.DisableClusteringRaw
	}

	result.PluginDirectory = c.PluginDirectory
	if c2.PluginDirectory != "" {
		result.PluginDirectory = c2.PluginDirectory
	}

	result.PluginFileUid = c.PluginFileUid
	if c2.PluginFileUid != 0 {
		result.PluginFileUid = c2.PluginFileUid
	}

	result.PluginFilePermissions = c.PluginFilePermissions
	if c2.PluginFilePermissionsRaw != nil {
		result.PluginFilePermissions = c2.PluginFilePermissions
		result.PluginFilePermissionsRaw = c2.PluginFilePermissionsRaw
	}

	result.DisablePerformanceStandby = c.DisablePerformanceStandby
	if c2.DisablePerformanceStandby {
		result.DisablePerformanceStandby = c2.DisablePerformanceStandby
	}

	result.DisableSealWrap = c.DisableSealWrap
	if c2.DisableSealWrap {
		result.DisableSealWrap = c2.DisableSealWrap
	}

	result.DisableIndexing = c.DisableIndexing
	if c2.DisableIndexing {
		result.DisableIndexing = c2.DisableIndexing
	}

	result.EnableResponseHeaderHostname = c.EnableResponseHeaderHostname
	if c2.EnableResponseHeaderHostname {
		result.EnableResponseHeaderHostname = c2.EnableResponseHeaderHostname
	}

	result.LogRequestsLevel = c.LogRequestsLevel
	if c2.LogRequestsLevel != "" {
		result.LogRequestsLevel = c2.LogRequestsLevel
	}

	result.DetectDeadlocks = c.DetectDeadlocks
	if c2.DetectDeadlocks != "" {
		result.DetectDeadlocks = c2.DetectDeadlocks
	}

	result.ImpreciseLeaseRoleTracking = c.ImpreciseLeaseRoleTracking
	if c2.ImpreciseLeaseRoleTracking {
		result.ImpreciseLeaseRoleTracking = c2.ImpreciseLeaseRoleTracking
	}

	result.EnableResponseHeaderRaftNodeID = c.EnableResponseHeaderRaftNodeID
	if c2.EnableResponseHeaderRaftNodeID {
		result.EnableResponseHeaderRaftNodeID = c2.EnableResponseHeaderRaftNodeID
	}

	result.UnsafeCrossNamespaceIdentity = c.UnsafeCrossNamespaceIdentity
	if c2.UnsafeCrossNamespaceIdentity {
		result.UnsafeCrossNamespaceIdentity = c2.UnsafeCrossNamespaceIdentity
	}

	result.UnsafeAllowAPIAuditCreation = c.UnsafeAllowAPIAuditCreation
	if c2.UnsafeAllowAPIAuditCreation {
		result.UnsafeAllowAPIAuditCreation = c2.UnsafeAllowAPIAuditCreation
	}

	result.AllowAuditLogPrefixing = c.AllowAuditLogPrefixing
	if c2.AllowAuditLogPrefixing {
		result.AllowAuditLogPrefixing = c2.AllowAuditLogPrefixing
	}

	result.DisableStandbyReads = c.DisableStandbyReads
	if c2.DisableStandbyReads {
		result.DisableStandbyReads = c2.DisableStandbyReads
	}

	result.AllowUnauthenticatedWorkflows = c.AllowUnauthenticatedWorkflows
	if c2.AllowUnauthenticatedWorkflows {
		result.AllowUnauthenticatedWorkflows = c2.AllowUnauthenticatedWorkflows
	}

	result.UnsafeRelativePaths = c.UnsafeRelativePaths
	if c2.UnsafeRelativePaths {
		result.UnsafeRelativePaths = c2.UnsafeRelativePaths
	}

	// Use values from top-level configuration for storage if set
	if storage := result.Storage; storage != nil {
		if result.APIAddr != "" {
			storage.RedirectAddr = result.APIAddr
		}
		if result.ClusterAddr != "" {
			storage.ClusterAddr = result.ClusterAddr
		}
		if result.DisableClusteringRaw != nil {
			storage.DisableClustering = result.DisableClustering
		}
	}

	if haStorage := result.HAStorage; haStorage != nil {
		if result.APIAddr != "" {
			haStorage.RedirectAddr = result.APIAddr
		}
		if result.ClusterAddr != "" {
			haStorage.ClusterAddr = result.ClusterAddr
		}
		if result.DisableClusteringRaw != nil {
			haStorage.DisableClustering = result.DisableClustering
		}
	}

	if len(c.Initialization) > 0 || len(c2.Initialization) > 0 {
		result.Initialization = make([]*profiles.OuterConfig, len(c.Initialization)+len(c2.Initialization))
		copy(result.Initialization[0:len(c.Initialization)], c.Initialization)
		copy(result.Initialization[len(c.Initialization):], c2.Initialization)
	}

	if len(c.Audits) > 0 || len(c2.Audits) > 0 {
		result.Audits = make([]*AuditDevice, len(c.Audits)+len(c2.Audits))
		copy(result.Audits[0:len(c.Audits)], c.Audits)
		copy(result.Audits[len(c.Audits):], c2.Audits)
	}

	if len(c.Plugins) > 0 || len(c2.Plugins) > 0 {
		result.Plugins = make([]*PluginConfig, len(c.Plugins)+len(c2.Plugins))
		copy(result.Plugins[0:len(c.Plugins)], c.Plugins)
		copy(result.Plugins[len(c.Plugins):], c2.Plugins)
	}

	result.PluginDownloadBehavior = c.PluginDownloadBehavior
	if c2.PluginDownloadBehavior != "" {
		result.PluginDownloadBehavior = c2.PluginDownloadBehavior
	}

	result.PluginAutoDownload = c.PluginAutoDownload
	if c2.PluginAutoDownloadRaw != nil {
		result.PluginAutoDownload = c2.PluginAutoDownload
		result.PluginAutoDownloadRaw = c2.PluginAutoDownloadRaw
	}

	result.PluginAutoRegister = c.PluginAutoRegister
	if c2.PluginAutoRegisterRaw != nil {
		result.PluginAutoRegister = c2.PluginAutoRegister
		result.PluginAutoRegisterRaw = c2.PluginAutoRegisterRaw
	}

	result.PluginDownloadMaxSize = c.PluginDownloadMaxSize
	if c2.PluginDownloadMaxSizeRaw != nil {
		result.PluginDownloadMaxSize = c2.PluginDownloadMaxSize
		result.PluginDownloadMaxSizeRaw = c2.PluginDownloadMaxSizeRaw
	}

	result.DisableSSCTokens = c.DisableSSCTokens
	if c2.DisableSSCTokensRaw != nil {
		result.DisableSSCTokens = c2.DisableSSCTokens
		result.DisableSSCTokensRaw = c2.DisableSSCTokensRaw
	}

	return result
}

// LoadConfig loads the configuration at the given path, regardless if
// its a file or directory.
func LoadConfig(path string, allPaths []string) (cfg *Config, err error) {
	fi, err := os.Stat(path)
	if err != nil {
		return nil, err
	}

	if fi.IsDir() {
		// check permissions on the config directory
		var enableFilePermissionsCheck bool
		if enableFilePermissionsCheckEnv := api.ReadBaoVariable(consts.VaultEnableFilePermissionsCheckEnv); enableFilePermissionsCheckEnv != "" {
			var err error
			enableFilePermissionsCheck, err = strconv.ParseBool(enableFilePermissionsCheckEnv)
			if err != nil {
				return nil, fmt.Errorf("failed to parse environment variable %s", consts.VaultEnableFilePermissionsCheckEnv)
			}
		}
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer func() {
			err = errors.Join(err, f.Close())
		}()

		if enableFilePermissionsCheck {
			err = osutil.OwnerPermissionsMatchFile(f, 0, 0)
			if err != nil {
				return nil, err
			}
		}
		return CheckConfig(LoadConfigDir(path))
	}
	return CheckConfig(LoadConfigFile(path, allPaths))
}

func CheckConfig(c *Config, e error) (*Config, error) {
	if e != nil || c == nil {
		return c, e
	}

	if len(c.Seals) == 2 {
		switch {
		case c.Seals[0].Disabled && c.Seals[1].Disabled:
			return nil, errors.New("seals: two seals provided but both are disabled")
		case !c.Seals[0].Disabled && !c.Seals[1].Disabled:
			return nil, errors.New("seals: two seals provided but neither is disabled")
		}
	}

	return c, nil
}

// LoadConfigFile loads the configuration from the given file.
func LoadConfigFile(path string, allPaths []string) (cfg *Config, err error) {
	// Before we read the configuration, check if we would've loaded it from
	// a configuration directory at some point in time. If so, ignore the
	// duplicate load.
	skip, err := checkSkipPaths(path, allPaths)
	if err != nil {
		return nil, err
	} else if skip {
		return nil, nil
	}

	// Open the file
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer func() {
		err = errors.Join(err, f.Close())
	}()
	// Read the file
	d, err := io.ReadAll(f)
	if err != nil {
		return nil, err
	}

	conf, err := ParseConfig(string(d), path)
	if err != nil {
		return nil, err
	}

	var enableFilePermissionsCheck bool
	if enableFilePermissionsCheckEnv := api.ReadBaoVariable(consts.VaultEnableFilePermissionsCheckEnv); enableFilePermissionsCheckEnv != "" {
		var err error
		enableFilePermissionsCheck, err = strconv.ParseBool(enableFilePermissionsCheckEnv)
		if err != nil {
			return nil, fmt.Errorf("failed to parse environment variable %s", consts.VaultEnableFilePermissionsCheckEnv)
		}
	}

	if enableFilePermissionsCheck {
		// check permissions of the config file
		err = osutil.OwnerPermissionsMatchFile(f, 0, 0)
		if err != nil {
			return nil, err
		}
		// check permissions of the plugin directory
		if conf.PluginDirectory != "" {
			err = osutil.OwnerPermissionsMatch(conf.PluginDirectory, conf.PluginFileUid, conf.PluginFilePermissions)
			if err != nil {
				return nil, err
			}
		}
	}
	return conf, nil
}

func ParseConfig(d, source string) (*Config, error) {
	// Parse using the helper function that handles both HCL and JSON
	obj, err := hclutil.ParseConfig([]byte(d))
	if err != nil {
		return nil, err
	}

	// Start building the result
	result := NewConfig()
	if err := hcl.DecodeObject(result, obj); err != nil {
		return nil, err
	}

	if rendered, err := configutil.ParseSingleIPTemplate(result.APIAddr); err != nil {
		return nil, err
	} else {
		result.APIAddr = rendered
	}
	if rendered, err := configutil.ParseSingleIPTemplate(result.ClusterAddr); err != nil {
		return nil, err
	} else {
		result.ClusterAddr = rendered
	}

	sharedConfig, err := configutil.ParseConfig(d)
	if err != nil {
		return nil, err
	}
	result.SharedConfig = sharedConfig

	if result.MaxLeaseTTLRaw != nil {
		if result.MaxLeaseTTL, err = parseutil.ParseDurationSecond(result.MaxLeaseTTLRaw); err != nil {
			return nil, err
		}
	}
	if result.DefaultLeaseTTLRaw != nil {
		if result.DefaultLeaseTTL, err = parseutil.ParseDurationSecond(result.DefaultLeaseTTLRaw); err != nil {
			return nil, err
		}
	}

	if result.EnableUIRaw != nil {
		if result.EnableUI, err = parseutil.ParseBool(result.EnableUIRaw); err != nil {
			return nil, err
		}
	}

	if result.DisableCacheRaw != nil {
		if result.DisableCache, err = parseutil.ParseBool(result.DisableCacheRaw); err != nil {
			return nil, err
		}
	}

	if result.DisablePrintableCheckRaw != nil {
		if result.DisablePrintableCheck, err = parseutil.ParseBool(result.DisablePrintableCheckRaw); err != nil {
			return nil, err
		}
	}

	if result.EnableRawEndpointRaw != nil {
		if result.EnableRawEndpoint, err = parseutil.ParseBool(result.EnableRawEndpointRaw); err != nil {
			return nil, err
		}
	}

	if result.EnableIntrospectionEndpointRaw != nil {
		if result.EnableIntrospectionEndpoint, err = parseutil.ParseBool(result.EnableIntrospectionEndpointRaw); err != nil {
			return nil, err
		}
	}

	if result.DisableClusteringRaw != nil {
		if result.DisableClustering, err = parseutil.ParseBool(result.DisableClusteringRaw); err != nil {
			return nil, err
		}
	}

	if result.PluginFilePermissionsRaw != nil {
		octalPermissionsString, err := parseutil.ParseString(result.PluginFilePermissionsRaw)
		if err != nil {
			return nil, err
		}
		pluginFilePermissions, err := strconv.ParseInt(octalPermissionsString, 8, 64)
		if err != nil {
			return nil, err
		}
		if pluginFilePermissions < math.MinInt || pluginFilePermissions > math.MaxInt {
			return nil, fmt.Errorf("file permission value %v cannot be safely cast to int: exceeds bounds (%v, %v)", pluginFilePermissions, math.MinInt, math.MaxInt)
		}
		result.PluginFilePermissions = int(pluginFilePermissions)
	}

	if result.DisableSentinelTraceRaw != nil {
		if result.DisableSentinelTrace, err = parseutil.ParseBool(result.DisableSentinelTraceRaw); err != nil {
			return nil, err
		}
	}

	if result.DisablePerformanceStandbyRaw != nil {
		if result.DisablePerformanceStandby, err = parseutil.ParseBool(result.DisablePerformanceStandbyRaw); err != nil {
			return nil, err
		}
	}

	if result.DisableSealWrapRaw != nil {
		if result.DisableSealWrap, err = parseutil.ParseBool(result.DisableSealWrapRaw); err != nil {
			return nil, err
		}
	}

	if result.DisableIndexingRaw != nil {
		if result.DisableIndexing, err = parseutil.ParseBool(result.DisableIndexingRaw); err != nil {
			return nil, err
		}
	}

	if result.EnableResponseHeaderHostnameRaw != nil {
		if result.EnableResponseHeaderHostname, err = parseutil.ParseBool(result.EnableResponseHeaderHostnameRaw); err != nil {
			return nil, err
		}
	}

	if result.LogRequestsLevelRaw != nil {
		result.LogRequestsLevel = strings.ToLower(strings.TrimSpace(result.LogRequestsLevelRaw.(string)))
		result.LogRequestsLevelRaw = ""
	}

	if result.EnableResponseHeaderRaftNodeIDRaw != nil {
		if result.EnableResponseHeaderRaftNodeID, err = parseutil.ParseBool(result.EnableResponseHeaderRaftNodeIDRaw); err != nil {
			return nil, err
		}
	}

	if result.DisableSSCTokensRaw != nil {
		disabled, err := parseutil.ParseBool(result.DisableSSCTokensRaw)
		if err != nil {
			return nil, err
		}
		result.DisableSSCTokens = &disabled
	}

	// We default to disabling SSCTs if it is not enabled in the
	// configuration explicitly.
	if result.DisableSSCTokens == nil {
		disableSSCTokens := true
		result.DisableSSCTokens = &disableSSCTokens
	}

	list, ok := obj.Node.(*ast.ObjectList)
	if !ok {
		return nil, errors.New("error parsing: file doesn't contain a root object")
	}

	// Look for storage but still support old backend
	if o := list.Filter("storage"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "storage")
		if err := ParseStorage(result, o, "storage"); err != nil {
			return nil, fmt.Errorf("error parsing 'storage': %w", err)
		}
		result.found(result.Storage.Type, result.Storage.Type)
	} else {
		delete(result.UnusedKeys, "backend")
		if o := list.Filter("backend"); len(o.Items) > 0 {
			if err := ParseStorage(result, o, "backend"); err != nil {
				return nil, fmt.Errorf("error parsing 'backend': %w", err)
			}
		}
	}

	if o := list.Filter("ha_storage"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "ha_storage")
		if err := parseHAStorage(result, o, "ha_storage"); err != nil {
			return nil, fmt.Errorf("error parsing 'ha_storage': %w", err)
		}
	} else {
		if o := list.Filter("ha_backend"); len(o.Items) > 0 {
			delete(result.UnusedKeys, "ha_backend")
			if err := parseHAStorage(result, o, "ha_backend"); err != nil {
				return nil, fmt.Errorf("error parsing 'ha_backend': %w", err)
			}
		}
	}

	// Parse service discovery
	if o := list.Filter("service_registration"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "service_registration")
		if err := parseServiceRegistration(result, o, "service_registration"); err != nil {
			return nil, fmt.Errorf("error parsing 'service_registration': %w", err)
		}
	}

	// Parse self-initialization stanzas.
	if o := list.Filter("initialize"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "initialize")
		init, err := profiles.ParseOuterConfig("initialize", o)
		if err != nil {
			return nil, fmt.Errorf("error parsing 'initialize': %w", err)
		}

		result.Initialization = init
	}

	// Parse audit device stanzas.
	if o := list.Filter("audit"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "audit")
		audits, err := parseAuditDevices("audit", o)
		if err != nil {
			return nil, fmt.Errorf("error parsing 'audit': %w", err)
		}

		result.Audits = audits
	}

	// Parse plugin stanzas.
	if o := list.Filter("plugin"); len(o.Items) > 0 {
		delete(result.UnusedKeys, "plugin")
		plugins, err := parsePlugins("plugin", o)
		if err != nil {
			return nil, fmt.Errorf("error parsing 'plugin': %w", err)
		}

		result.Plugins = plugins
	}

	if result.PluginAutoDownloadRaw != nil {
		autoDownload, err := parseutil.ParseBool(result.PluginAutoDownloadRaw)
		if err != nil {
			return nil, err
		}
		result.PluginAutoDownload = autoDownload
	}

	if result.PluginAutoRegisterRaw != nil {
		autoRegister, err := parseutil.ParseBool(result.PluginAutoRegisterRaw)
		if err != nil {
			return nil, err
		}
		result.PluginAutoRegister = autoRegister
	} else {
		result.PluginAutoRegister = true
	}

	if result.PluginDownloadMaxSizeRaw != nil {
		maxSize, err := parseutil.ParseInt(result.PluginDownloadMaxSizeRaw)
		if err != nil {
			return nil, err
		}
		result.PluginDownloadMaxSize = maxSize
	}

	// Remove all unused keys from Config that were satisfied by SharedConfig.
	result.UnusedKeys = configutil.UnusedFieldDifference(result.UnusedKeys, nil, append(result.FoundKeys, sharedConfig.FoundKeys...))
	// Assign file info
	for _, v := range result.UnusedKeys {
		for i := range v {
			v[i].Filename = source
		}
	}

	return result, nil
}

// LoadConfigDir loads all the configurations in the given directory
// in alphabetical order.
func LoadConfigDir(dir string) (cfg *Config, err error) {
	f, err := os.Open(dir)
	if err != nil {
		return nil, err
	}
	defer func() {
		err = errors.Join(err, f.Close())
	}()

	fi, err := f.Stat()
	if err != nil {
		return nil, err
	}
	if !fi.IsDir() {
		return nil, fmt.Errorf("configuration path must be a directory: %q", dir)
	}

	var files []string
	err = nil
	for err != io.EOF {
		var fis []os.FileInfo
		fis, err = f.Readdir(128)
		if err != nil && err != io.EOF {
			return nil, err
		}

		for _, fi := range fis {
			// Ignore directories
			if fi.IsDir() {
				continue
			}

			// Only care about files that are valid to load.
			name := fi.Name()
			skip := true
			if strings.HasSuffix(name, ".hcl") {
				skip = false
			} else if strings.HasSuffix(name, ".json") {
				skip = false
			}
			if skip || isTemporaryFile(name) {
				continue
			}

			path := filepath.Join(dir, name)
			files = append(files, path)
		}
	}

	result := NewConfig()
	for _, f := range files {
		config, err := LoadConfigFile(f, nil /* every file should be loaded */)
		if err != nil {
			return nil, fmt.Errorf("error loading %q: %w", f, err)
		}

		if result == nil {
			result = config
		} else {
			result = result.Merge(config)
		}
	}

	return result, nil
}

// isTemporaryFile returns true or false depending on whether the
// provided file name is a temporary file for the following editors:
// emacs or vim.
func isTemporaryFile(name string) bool {
	return strings.HasSuffix(name, "~") || // vim
		strings.HasPrefix(name, ".#") || // emacs
		(strings.HasPrefix(name, "#") && strings.HasSuffix(name, "#")) // emacs
}

func ParseStorage(result *Config, list *ast.ObjectList, name string) error {
	if len(list.Items) > 1 {
		return fmt.Errorf("only one %q block is permitted", name)
	}

	// Get our item
	item := list.Items[0]

	key := name
	if len(item.Keys) > 0 {
		key = item.Keys[0].Token.Value().(string)
	}

	var config map[string]any
	if err := hcl.DecodeObject(&config, item.Val); err != nil {
		return multierror.Prefix(err, fmt.Sprintf("%s.%s:", name, key))
	}

	m := make(map[string]string)
	for key, val := range config {
		valStr, ok := val.(string)
		if ok {
			m[key] = valStr
			continue
		}
		valBytes, err := json.Marshal(val)
		if err != nil {
			return err
		}
		m[key] = string(valBytes)
	}

	// Pull out the redirect address since it's common to all backends
	var redirectAddr string
	if v, ok := m["redirect_addr"]; ok {
		redirectAddr = v
		delete(m, "redirect_addr")
	} else if v, ok := m["advertise_addr"]; ok {
		redirectAddr = v
		delete(m, "advertise_addr")
	}

	// Pull out the cluster address since it's common to all backends
	var clusterAddr string
	if v, ok := m["cluster_addr"]; ok {
		clusterAddr = v
		delete(m, "cluster_addr")
	}

	var disableClustering bool
	var err error
	if v, ok := m["disable_clustering"]; ok {
		disableClustering, err = strconv.ParseBool(v)
		if err != nil {
			return multierror.Prefix(err, fmt.Sprintf("%s.%s:", name, key))
		}
		delete(m, "disable_clustering")
	}

	// Override with top-level values if they are set
	if result.APIAddr != "" {
		redirectAddr = result.APIAddr
	}

	if result.ClusterAddr != "" {
		clusterAddr = result.ClusterAddr
	}

	if result.DisableClusteringRaw != nil {
		disableClustering = result.DisableClustering
	}

	result.Storage = &Storage{
		RedirectAddr:      redirectAddr,
		ClusterAddr:       clusterAddr,
		DisableClustering: disableClustering,
		Type:              strings.ToLower(key),
		Config:            m,
	}
	return nil
}

func parseHAStorage(result *Config, list *ast.ObjectList, name string) error {
	if len(list.Items) > 1 {
		return fmt.Errorf("only one %q block is permitted", name)
	}

	// Get our item
	item := list.Items[0]

	key := name
	if len(item.Keys) > 0 {
		key = item.Keys[0].Token.Value().(string)
	}

	var config map[string]any
	if err := hcl.DecodeObject(&config, item.Val); err != nil {
		return multierror.Prefix(err, fmt.Sprintf("%s.%s:", name, key))
	}

	m := make(map[string]string)
	for key, val := range config {
		valStr, ok := val.(string)
		if ok {
			m[key] = valStr
			continue
		}
		valBytes, err := json.Marshal(val)
		if err != nil {
			return err
		}
		m[key] = string(valBytes)
	}

	// Pull out the redirect address since it's common to all backends
	var redirectAddr string
	if v, ok := m["redirect_addr"]; ok {
		redirectAddr = v
		delete(m, "redirect_addr")
	} else if v, ok := m["advertise_addr"]; ok {
		redirectAddr = v
		delete(m, "advertise_addr")
	}

	// Pull out the cluster address since it's common to all backends
	var clusterAddr string
	if v, ok := m["cluster_addr"]; ok {
		clusterAddr = v
		delete(m, "cluster_addr")
	}

	var disableClustering bool
	var err error
	if v, ok := m["disable_clustering"]; ok {
		disableClustering, err = strconv.ParseBool(v)
		if err != nil {
			return multierror.Prefix(err, fmt.Sprintf("%s.%s:", name, key))
		}
		delete(m, "disable_clustering")
	}

	// Override with top-level values if they are set
	if result.APIAddr != "" {
		redirectAddr = result.APIAddr
	}

	if result.ClusterAddr != "" {
		clusterAddr = result.ClusterAddr
	}

	if result.DisableClusteringRaw != nil {
		disableClustering = result.DisableClustering
	}

	result.HAStorage = &Storage{
		RedirectAddr:      redirectAddr,
		ClusterAddr:       clusterAddr,
		DisableClustering: disableClustering,
		Type:              strings.ToLower(key),
		Config:            m,
	}
	return nil
}

func parseServiceRegistration(result *Config, list *ast.ObjectList, name string) error {
	if len(list.Items) > 1 {
		return fmt.Errorf("only one %q block is permitted", name)
	}

	// Get our item
	item := list.Items[0]
	key := name
	if len(item.Keys) > 0 {
		key = item.Keys[0].Token.Value().(string)
	}

	var m map[string]string
	if err := hcl.DecodeObject(&m, item.Val); err != nil {
		return multierror.Prefix(err, fmt.Sprintf("%s.%s:", name, key))
	}

	result.ServiceRegistration = &ServiceRegistration{
		Type:   strings.ToLower(key),
		Config: m,
	}
	return nil
}

// Sanitized returns a copy of the config with all values that are considered
// sensitive stripped. It also strips all `*Raw` values that are mainly
// used for parsing.
//
// Specifically, the fields that this method strips are:
// - Storage.Config
// - HAStorage.Config
// - Seals.Config
// - Telemetry.CirconusAPIToken
func (c *Config) Sanitized() map[string]any {
	// Create shared config if it doesn't exist (e.g. in tests) so that map
	// keys are actually populated
	if c.SharedConfig == nil {
		c.SharedConfig = new(configutil.SharedConfig)
	}
	sharedResult := c.SharedConfig.Sanitized()
	result := map[string]any{
		"cache_size":              c.CacheSize,
		"disable_sentinel_trace":  c.DisableSentinelTrace,
		"disable_cache":           c.DisableCache,
		"disable_printable_check": c.DisablePrintableCheck,

		"enable_ui": c.EnableUI,

		"max_lease_ttl":     c.MaxLeaseTTL / time.Second,
		"default_lease_ttl": c.DefaultLeaseTTL / time.Second,

		"cluster_cipher_suites": c.ClusterCipherSuites,

		"plugin_directory": c.PluginDirectory,

		"plugin_file_uid": c.PluginFileUid,

		"plugin_file_permissions": c.PluginFilePermissions,

		"raw_storage_endpoint": c.EnableRawEndpoint,

		"introspection_endpoint": c.EnableIntrospectionEndpoint,

		"api_addr":           c.APIAddr,
		"cluster_addr":       c.ClusterAddr,
		"disable_clustering": c.DisableClustering,

		"disable_performance_standby": c.DisablePerformanceStandby,

		"disable_sealwrap": c.DisableSealWrap,

		"disable_indexing": c.DisableIndexing,

		"enable_response_header_hostname": c.EnableResponseHeaderHostname,

		"enable_response_header_raft_node_id": c.EnableResponseHeaderRaftNodeID,

		"log_requests_level": c.LogRequestsLevel,

		"detect_deadlocks": c.DetectDeadlocks,

		"imprecise_lease_role_tracking": c.ImpreciseLeaseRoleTracking,

		"unsafe_cross_namespace_identity": c.UnsafeCrossNamespaceIdentity,

		"unsafe_allow_api_audit_creation": c.UnsafeAllowAPIAuditCreation,
		"allow_audit_log_prefixing":       c.AllowAuditLogPrefixing,

		"disable_standby_reads":           c.DisableStandbyReads,
		"allow_unauthenticated_workflows": c.AllowUnauthenticatedWorkflows,
		"unsafe_relative_paths":           c.UnsafeRelativePaths,

		"disable_ssct_tokens": c.DisableSSCTokens,
	}
	if c.DisableSSCTokens == nil {
		result["disable_ssct_tokens"] = true
	}

	maps.Copy(result, sharedResult)

	// Sanitize storage stanza
	if c.Storage != nil {
		storageType := c.Storage.Type
		sanitizedStorage := map[string]any{
			"type":               storageType,
			"redirect_addr":      c.Storage.RedirectAddr,
			"cluster_addr":       c.Storage.ClusterAddr,
			"disable_clustering": c.Storage.DisableClustering,
		}

		if storageType == "raft" {
			sanitizedStorage["raft"] = map[string]any{
				"max_entry_size": c.Storage.Config["max_entry_size"],
			}
		}

		result["storage"] = sanitizedStorage
	}

	// Sanitize HA storage stanza
	if c.HAStorage != nil {
		haStorageType := c.HAStorage.Type
		sanitizedHAStorage := map[string]any{
			"type":               haStorageType,
			"redirect_addr":      c.HAStorage.RedirectAddr,
			"cluster_addr":       c.HAStorage.ClusterAddr,
			"disable_clustering": c.HAStorage.DisableClustering,
		}

		if haStorageType == "raft" {
			sanitizedHAStorage["raft"] = map[string]any{
				"max_entry_size": c.HAStorage.Config["max_entry_size"],
			}
		}

		result["ha_storage"] = sanitizedHAStorage
	}

	// Sanitize service_registration stanza
	if c.ServiceRegistration != nil {
		sanitizedServiceRegistration := map[string]any{
			"type": c.ServiceRegistration.Type,
		}
		result["service_registration"] = sanitizedServiceRegistration
	}

	if len(c.Audits) > 0 {
		var sanitizedAudits []map[string]any
		for _, a := range c.Audits {
			cfg := map[string]any{
				"path":        a.Path,
				"type":        a.Type,
				"description": a.Description,
			}
			sanitizedAudits = append(sanitizedAudits, cfg)
		}
		result["audits"] = sanitizedAudits
	}

	return result
}

func (c *Config) Prune() {
	for _, l := range c.Listeners {
		l.RawConfig = nil
		l.UnusedKeys = nil
	}
	c.FoundKeys = nil
	c.UnusedKeys = nil
	c.SharedConfig.FoundKeys = nil
	c.SharedConfig.UnusedKeys = nil
	if c.Telemetry != nil {
		c.Telemetry.FoundKeys = nil
		c.Telemetry.UnusedKeys = nil
	}
}

func (c *Config) found(s, k string) {
	delete(c.UnusedKeys, s)
	c.FoundKeys = append(c.FoundKeys, k)
}

func (c *Config) ToVaultNodeConfig() (*testcluster.VaultNodeConfig, error) {
	var vnc testcluster.VaultNodeConfig
	err := mapstructure.Decode(c, &vnc)
	if err != nil {
		return nil, err
	}
	return &vnc, nil
}

func checkSkipPaths(path string, allPaths []string) (bool, error) {
	curPath, err := filepath.Abs(path)
	if err != nil {
		return true, err
	}

	curPathDir := filepath.Dir(curPath)

	for _, dir := range allPaths {
		if dir == path {
			continue
		}

		absDir, err := filepath.Abs(dir)
		if err != nil {
			return true, err
		}

		// If the given file lives in the directory and has the appropriate
		// configuration file suffixes, exclude it because directory parsing
		// would've already included this.
		if absDir == curPathDir && (strings.HasSuffix(path, ".hcl") || strings.HasSuffix(path, ".json")) {
			return true, nil
		}
	}

	return false, nil
}

// AuditDevice is a config-defined audit device for the server.
type AuditDevice struct {
	UnusedKeys configutil.UnusedKeyMap `hcl:",unusedKeyPositions"`
	RawConfig  map[string]any

	Type        string
	Path        string
	Description string            `hcl:"description"`
	Options     map[string]string `hcl:"options"`
	Local       bool              `hcl:"local"`
}

func (a *AuditDevice) Validate(source string) []configutil.ConfigError {
	return configutil.ValidateUnusedFields(a.UnusedKeys, source)
}

func (a *AuditDevice) GoString() string {
	return fmt.Sprintf("*%#v", *a)
}

func parseAuditDevices(name string, list *ast.ObjectList) ([]*AuditDevice, error) {
	result := make([]*AuditDevice, 0, len(list.Items))
	for index, item := range list.Items {
		var i AuditDevice
		if err := hcl.DecodeObject(&i, item.Val); err != nil {
			return result, fmt.Errorf("%v.%d: %w", name, index, err)
		}

		var m map[string]any
		if err := hcl.DecodeObject(&m, item.Val); err != nil {
			return result, fmt.Errorf("%v.%d: %w", name, index, err)
		}
		i.RawConfig = m

		switch {
		case i.Type != "":
		case len(item.Keys) == 2:
			i.Type = item.Keys[0].Token.Value().(string)
		default:
			return result, fmt.Errorf("%v.%d: %v type must be specified: %#v", name, index, name, item)
		}

		switch {
		case i.Path != "":
		case len(item.Keys) == 2:
			i.Path = item.Keys[1].Token.Value().(string)
		default:
			return result, fmt.Errorf("%v.%d: %v path must be specified: %#v", name, index, name, item)
		}

		result = append(result, &i)
	}

	return result, nil
}
