describe('axe.utils.assert', () => {
  it('does nothing when passed a truthy value', () => {
    assert.doesNotThrow(() => {
      axe.utils.assert(true);
      axe.utils.assert('foo');
      axe.utils.assert(123);
      axe.utils.assert([]);
      axe.utils.assert({});
    });
  });

  it('throws an error when passed a falsey value', () => {
    assert.throws(() => {
      axe.utils.assert(false);
    });
    assert.throws(() => {
      axe.utils.assert(0);
    });
    assert.throws(() => {
      axe.utils.assert(null);
    });
    assert.throws(() => {
      axe.utils.assert(undefined);
    });
  });

  it('sets second argument as the error message', () => {
    const message = 'Something went wrong';
    try {
      axe.utils.assert(false, message);
    } catch (e) {
      assert.instanceOf(e, Error);
      assert.equal(e.message, message);
    }
  });
});
