package util //nolint:revive

import (
	"crypto/md5"
	"encoding/binary"
)

// Sharding strategies & algorithms.
const (
	// ShardingStrategyDefault shards rule groups across available rulers in the ring.
	ShardingStrategyDefault = "default"
	// ShardingStrategyShuffle shards tenants' rule groups across available rulers in the ring using a
	// shuffle-sharding algorithm.
	ShardingStrategyShuffle = "shuffle-sharding"

	// ShardingAlgoByGroup is an alias of ShardingStrategyDefault.
	ShardingAlgoByGroup = "by-group"
	// ShardingAlgoByRule shards all rules evenly across available rules in the ring, regardless of group.
	// This can be achieved because currently Loki recording/alerting rules cannot not any inter-dependency, unlike
	// Prometheus rules, so there's really no need to shard by group. This will eventually become the new default strategy.
	ShardingAlgoByRule = "by-rule" // this will eventually become the new default strategy.
)

var (
	seedSeparator = []byte{0}
)

// ShuffleShardSeed returns seed for random number generator, computed from provided identifier.
func ShuffleShardSeed(identifier, zone string) int64 {
	// Use the identifier to compute an hash we'll use to seed the random.
	hasher := md5.New()               //#nosec G401 -- This does not require collision resistance, this is an intentionally predictable value -- nosemgrep: use-of-md5
	hasher.Write(YoloBuf(identifier)) // nolint:errcheck
	if zone != "" {
		hasher.Write(seedSeparator) // nolint:errcheck
		hasher.Write(YoloBuf(zone)) // nolint:errcheck
	}
	checksum := hasher.Sum(nil)

	// Generate the seed based on the first 64 bits of the checksum.
	return int64(binary.BigEndian.Uint64(checksum))
}
