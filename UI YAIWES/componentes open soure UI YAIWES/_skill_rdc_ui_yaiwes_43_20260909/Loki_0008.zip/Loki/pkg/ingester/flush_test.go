package ingester

import (
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"sort"
	"sync"
	"syscall"
	"testing"
	"time"

	"context"

	gokitlog "github.com/go-kit/log"
	"github.com/grafana/dskit/flagext"
	"github.com/grafana/dskit/kv"
	"github.com/grafana/dskit/ring"
	"github.com/grafana/dskit/services"
	"github.com/grafana/dskit/user"
	"github.com/prometheus/common/model"
	"github.com/prometheus/prometheus/model/labels"
	"github.com/stretchr/testify/require"
	"go.uber.org/atomic"

	"github.com/grafana/dskit/tenant"

	"github.com/grafana/loki/v3/pkg/chunkenc"
	"github.com/grafana/loki/v3/pkg/compression"
	"github.com/grafana/loki/v3/pkg/distributor/writefailures"
	"github.com/grafana/loki/v3/pkg/ingester/client"
	"github.com/grafana/loki/v3/pkg/ingester/wal"
	"github.com/grafana/loki/v3/pkg/iter"
	"github.com/grafana/loki/v3/pkg/logproto"
	"github.com/grafana/loki/v3/pkg/logql"
	"github.com/grafana/loki/v3/pkg/logql/log"
	"github.com/grafana/loki/v3/pkg/runtime"
	"github.com/grafana/loki/v3/pkg/storage/chunk"
	"github.com/grafana/loki/v3/pkg/storage/chunk/fetcher"
	"github.com/grafana/loki/v3/pkg/storage/config"
	"github.com/grafana/loki/v3/pkg/storage/stores/index/stats"
	"github.com/grafana/loki/v3/pkg/storage/stores/shipper/indexshipper/tsdb/sharding"
	storagetypes "github.com/grafana/loki/v3/pkg/storage/types"
	"github.com/grafana/loki/v3/pkg/util"
	"github.com/grafana/loki/v3/pkg/util/constants"
	"github.com/grafana/loki/v3/pkg/validation"
)

const (
	numSeries        = 10
	samplesPerSeries = 100
)

func TestChunkFlushingIdle(t *testing.T) {
	cfg := defaultIngesterTestConfig(t)
	cfg.FlushCheckPeriod = 20 * time.Millisecond
	cfg.MaxChunkIdle = 100 * time.Millisecond
	cfg.RetainPeriod = 500 * time.Millisecond

	store, ing := newTestStore(t, cfg, nil)
	defer services.StopAndAwaitTerminated(context.Background(), ing) //nolint:errcheck
	testData := pushTestSamples(t, ing)

	// wait beyond idle time so samples flush
	time.Sleep(cfg.MaxChunkIdle * 2)
	store.checkData(t, testData)
}

func TestChunkFlushingShutdown(t *testing.T) {
	store, ing := newTestStore(t, defaultIngesterTestConfig(t), nil)
	testData := pushTestSamples(t, ing)
	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))
	store.checkData(t, testData)
}

type fullWAL struct{}

func (fullWAL) Log(_ *wal.Record) error { return &os.PathError{Err: syscall.ENOSPC} }
func (fullWAL) Start()                  {}
func (fullWAL) Stop() error             { return nil }
func (fullWAL) IsDiskThrottled() bool   { return false }

func Benchmark_FlushLoop(b *testing.B) {
	var (
		size   = 5
		descs  [][]*chunkDesc
		lbs    = makeRandomLabels()
		ctx    = user.InjectOrgID(context.Background(), "foo")
		_, ing = newTestStore(b, defaultIngesterTestConfig(b), nil)
	)

	for i := 0; i < size; i++ {
		descs = append(descs, buildChunkDecs(b))
	}

	b.ResetTimer()
	b.ReportAllocs()

	for n := 0; n < b.N; n++ {
		var wg sync.WaitGroup
		for i := 0; i < size; i++ {
			wg.Add(1)
			go func(loop int) {
				defer wg.Done()
				require.NoError(b, ing.flushChunks(ctx, 0, lbs, descs[loop], &sync.RWMutex{}))
			}(i)
		}
		wg.Wait()
	}
}

// Benchmark_EncodeChunk reports the cost of encoding one full closed chunk — an upper
// bound on how long encode would hold stream.chunkMtx after locking around encodeChunk.
func Benchmark_EncodeChunk(b *testing.B) {
	ctx := user.InjectOrgID(context.Background(), "foo")
	ing := &Ingester{
		cfg:     *dummyConf(),
		logger:  gokitlog.NewNopLogger(),
		metrics: NilMetrics,
	}
	desc := buildChunkDesc(b)
	lbs := labels.FromStrings("app", "bench")
	labelsBuilder := labels.NewBuilder(lbs)
	labelsBuilder.Set(nameLabel, logsValue)
	metric := labelsBuilder.Labels()

	b.ReportAllocs()
	b.ResetTimer()
	for n := 0; n < b.N; n++ {
		firstTime, lastTime := util.RoundToMilliseconds(desc.chunk.Bounds())
		ch := chunk.NewChunk(
			"foo", 0, metric,
			chunkenc.NewFacade(desc.chunk, ing.cfg.BlockSize, ing.cfg.TargetChunkSize),
			firstTime,
			lastTime,
		)
		require.NoError(b, ing.encodeChunk(ctx, &ch, desc))
	}
}

// Benchmark_PushDuringEncode measures Push on a stream while another goroutine
// repeatedly encodes a closed filled chunk. unlocked_encode matches today's
// racey flush (encode without chunkMtx); locked_encode is the post-fix shape.
func Benchmark_PushDuringEncode(b *testing.B) {
	for _, tc := range []struct {
		name   string
		locked bool
	}{
		{name: "unlocked_encode", locked: false},
		{name: "locked_encode", locked: true},
	} {
		b.Run(tc.name, func(b *testing.B) {
			benchmarkPushDuringEncode(b, tc.locked)
		})
	}
}

func benchmarkPushDuringEncode(b *testing.B, lockDuringEncode bool) {
	ls := labels.FromStrings(
		"namespace", "loki-dev",
		"cluster", "dev-us-central1",
		"job", "loki-dev/ingester",
		"container", "ingester",
	)

	limits, err := validation.NewOverrides(defaultLimitsTestConfig(), nil)
	require.NoError(b, err)
	limiter := NewLimiter(limits, NilMetrics, newIngesterRingLimiterStrategy(&ringCountMock{count: 1}, 1), &TenantBasedStrategy{limits: limits})
	chunkfmt, headfmt := defaultChunkFormat(b)
	retentionHours := util.RetentionHours(limiter.limits.RetentionPeriod("fake"))
	s := newStream(chunkfmt, headfmt, &Config{MaxChunkAge: 24 * time.Hour}, limiter.rateLimitStrategy, "fake", model.Fingerprint(0), ls, NewStreamRateCalculator(), NilMetrics, nil, nil, retentionHours, noPolicy)

	ing := &Ingester{
		cfg:     *dummyConf(),
		logger:  gokitlog.NewNopLogger(),
		metrics: NilMetrics,
	}
	desc := buildChunkDesc(b)
	labelsBuilder := labels.NewBuilder(ls)
	labelsBuilder.Set(nameLabel, logsValue)
	metric := labelsBuilder.Labels()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var encodes atomic.Int64
	var encodeErr atomic.Error
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			select {
			case <-ctx.Done():
				return
			default:
			}

			firstTime, lastTime := util.RoundToMilliseconds(desc.chunk.Bounds())
			ch := chunk.NewChunk(
				"fake", s.fp, metric,
				chunkenc.NewFacade(desc.chunk, ing.cfg.BlockSize, ing.cfg.TargetChunkSize),
				firstTime,
				lastTime,
			)

			if lockDuringEncode {
				s.chunkMtx.Lock()
			}
			err := ing.encodeChunk(ctx, &ch, desc)
			if lockDuringEncode {
				s.chunkMtx.Unlock()
			}
			if err != nil {
				if ctx.Err() != nil {
					return
				}
				encodeErr.Store(err)
				cancel()
				return
			}
			encodes.Add(1)
		}
	}()

	pushCtx := context.Background()
	e := entries(10, time.Now())
	b.ReportAllocs()
	b.ResetTimer()

	for n := 0; n < b.N; n++ {
		rec := recordPool.GetRecord()
		_, err := s.Push(pushCtx, e, rec, 0, true, false, nil, "loki")
		recordPool.PutRecord(rec)
		if err != nil {
			b.Fatal(err)
		}
		// Advance timestamps so subsequent pushes are not duplicates.
		for i := range e {
			e[i].Timestamp = e[i].Timestamp.Add(time.Millisecond)
		}
	}

	b.StopTimer()
	cancel()
	wg.Wait()
	require.NoError(b, encodeErr.Load())
	b.ReportMetric(float64(encodes.Load())/float64(b.N), "encodes/op")
}

func Test_FlushOp(t *testing.T) {
	t.Run("no error", func(t *testing.T) {
		cfg := defaultIngesterTestConfig(t)
		cfg.FlushOpBackoff.MinBackoff = time.Second
		cfg.FlushOpBackoff.MaxBackoff = 10 * time.Second
		cfg.FlushOpBackoff.MaxRetries = 1
		cfg.FlushCheckPeriod = 100 * time.Millisecond

		_, ing := newTestStore(t, cfg, nil)

		ctx := user.InjectOrgID(context.Background(), "foo")
		ins, err := ing.GetOrCreateInstance("foo")
		require.NoError(t, err)

		lbs := makeRandomLabels()
		req := &logproto.PushRequest{Streams: []logproto.Stream{{
			Labels:  lbs.String(),
			Entries: entries(5, time.Now()),
		}}}
		require.NoError(t, ins.Push(ctx, req))

		time.Sleep(cfg.FlushCheckPeriod)
		require.NoError(t, ing.flushOp(gokitlog.NewNopLogger(), &flushOp{
			immediate: true,
			userID:    "foo",
			fp:        ins.getHashForLabels(lbs),
		}))
	})

	t.Run("max retries exceeded", func(t *testing.T) {
		cfg := defaultIngesterTestConfig(t)
		cfg.FlushOpBackoff.MinBackoff = time.Second
		cfg.FlushOpBackoff.MaxBackoff = 10 * time.Second
		cfg.FlushOpBackoff.MaxRetries = 1
		cfg.FlushCheckPeriod = 100 * time.Millisecond

		store, ing := newTestStore(t, cfg, nil)
		store.onPut = func(_ context.Context, _ []chunk.Chunk) error {
			return errors.New("failed to write chunks")
		}

		ctx := user.InjectOrgID(context.Background(), "foo")
		ins, err := ing.GetOrCreateInstance("foo")
		require.NoError(t, err)

		lbs := makeRandomLabels()
		req := &logproto.PushRequest{Streams: []logproto.Stream{{
			Labels:  lbs.String(),
			Entries: entries(5, time.Now()),
		}}}
		require.NoError(t, ins.Push(ctx, req))

		time.Sleep(cfg.FlushCheckPeriod)
		require.EqualError(t, ing.flushOp(gokitlog.NewNopLogger(), &flushOp{
			immediate: true,
			userID:    "foo",
			fp:        ins.getHashForLabels(lbs),
		}), "terminated after 1 retries")
	})
}

func Test_Flush(t *testing.T) {
	var (
		store, ing = newTestStore(t, defaultIngesterTestConfig(t), nil)
		lbs        = makeRandomLabels()
		ctx        = user.InjectOrgID(context.Background(), "foo")
	)
	store.onPut = func(_ context.Context, chunks []chunk.Chunk) error {
		for _, c := range chunks {
			buf, err := c.Encoded()
			require.Nil(t, err)
			if err := c.Decode(chunk.NewDecodeContext(), buf); err != nil {
				return err
			}
		}
		return nil
	}
	require.NoError(t, ing.flushChunks(ctx, 0, lbs, buildChunkDecs(t), &sync.RWMutex{}))
}

func buildChunkDecs(t testing.TB) []*chunkDesc {
	res := make([]*chunkDesc, 10)
	for i := range res {
		res[i] = buildChunkDesc(t)
	}
	return res
}

func buildChunkDesc(t testing.TB) *chunkDesc {
	t.Helper()
	desc := &chunkDesc{
		closed: true,
		chunk:  chunkenc.NewMemChunk(chunkenc.ChunkFormatV4, compression.Snappy, chunkenc.UnorderedWithStructuredMetadataHeadBlockFmt, dummyConf().BlockSize, dummyConf().TargetChunkSize),
	}
	fillChunk(t, desc.chunk)
	require.NoError(t, desc.chunk.Close())
	return desc
}

func TestMaybeSetIngestedAt(t *testing.T) {
	v14 := []config.PeriodConfig{{From: config.DayTime{Time: 0}, IndexType: storagetypes.IndexTypeTSDB, Schema: "v14"}}
	v13 := []config.PeriodConfig{{From: config.DayTime{Time: 0}, IndexType: storagetypes.IndexTypeTSDB, Schema: "v13"}}

	backfill := labels.FromStrings("app", "foo", constants.BackfillLabel, "true")
	live := labels.FromStrings("app", "foo")

	for _, tc := range []struct {
		name    string
		periods []config.PeriodConfig
		metric  labels.Labels
		wantSet bool
	}{
		{"backfill stream under v14 records ingestion time", v14, backfill, true},
		{"live stream under v14 stays zero", v14, live, false},
		{"backfill stream under v13 stays zero", v13, backfill, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			i := &Ingester{periodicConfigs: tc.periods}
			ch := chunk.Chunk{Metric: tc.metric}

			before := model.Now()
			i.maybeSetIngestedAt(&ch, model.Now())

			if tc.wantSet {
				require.NotEqual(t, model.Time(0), ch.IngestedAt)
				require.GreaterOrEqual(t, int64(ch.IngestedAt), int64(before))
			} else {
				require.Equal(t, model.Time(0), ch.IngestedAt)
			}
		})
	}
}

func TestFlushChunksSetsIngestedAtForBackfill(t *testing.T) {
	for _, tc := range []struct {
		name    string
		labels  labels.Labels
		wantSet bool
	}{
		{"backfill stream", labels.FromStrings("app", "foo", constants.BackfillLabel, "true"), true},
		{"live stream", labels.FromStrings("app", "foo"), false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			store, ing := newTestStore(t, defaultIngesterTestConfig(t), nil)
			// Use a v14 period so the chunk's index would persist IngestedAt.
			ing.periodicConfigs = []config.PeriodConfig{{From: config.DayTime{Time: 0}, IndexType: storagetypes.IndexTypeTSDB, Schema: "v14"}}
			ctx := user.InjectOrgID(context.Background(), "foo")

			var captured []chunk.Chunk
			store.onPut = func(_ context.Context, chunks []chunk.Chunk) error {
				captured = append(captured, chunks...)
				return nil
			}

			before := model.Now()
			require.NoError(t, ing.flushChunks(ctx, 0, tc.labels, buildChunkDecs(t), &sync.RWMutex{}))

			require.NotEmpty(t, captured)
			for _, c := range captured {
				if tc.wantSet {
					require.NotEqual(t, model.Time(0), c.IngestedAt)
					require.GreaterOrEqual(t, int64(c.IngestedAt), int64(before))
				} else {
					require.Equal(t, model.Time(0), c.IngestedAt)
				}
			}
		})
	}
}

func TestWALFullFlush(t *testing.T) {
	// technically replaced with a fake wal, but the ingester New() function creates a regular wal first,
	// so we enable creation/cleanup even though it remains unused.
	walDir := t.TempDir()

	store, ing := newTestStore(t, defaultIngesterTestConfigWithWAL(t, walDir), fullWAL{})
	testData := pushTestSamples(t, ing)
	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))
	store.checkData(t, testData)
}

func TestFlushingCollidingLabels(t *testing.T) {
	cfg := defaultIngesterTestConfig(t)
	cfg.FlushCheckPeriod = 20 * time.Millisecond
	cfg.MaxChunkIdle = 100 * time.Millisecond
	cfg.RetainPeriod = 500 * time.Millisecond

	store, ing := newTestStore(t, cfg, nil)
	defer store.Stop()

	const userID = "testUser"
	ctx := user.InjectOrgID(context.Background(), userID)

	// checkData only iterates between unix seconds 0 and 1000
	now := time.Unix(0, 0)

	req := &logproto.PushRequest{Streams: []logproto.Stream{
		// some colliding label sets
		{Labels: model.LabelSet{"app": "l", "uniq0": "0", "uniq1": "1"}.String(), Entries: entries(5, now.Add(time.Minute))},
		{Labels: model.LabelSet{"app": "m", "uniq0": "1", "uniq1": "1"}.String(), Entries: entries(5, now)},
		{Labels: model.LabelSet{"app": "l", "uniq0": "1", "uniq1": "0"}.String(), Entries: entries(5, now.Add(time.Minute))},
		{Labels: model.LabelSet{"app": "m", "uniq0": "0", "uniq1": "0"}.String(), Entries: entries(5, now)},
		{Labels: model.LabelSet{"app": "l", "uniq0": "0", "uniq1": "0"}.String(), Entries: entries(5, now.Add(time.Minute))},
		{Labels: model.LabelSet{"app": "m", "uniq0": "1", "uniq1": "0"}.String(), Entries: entries(5, now)},
	}}

	sort.Slice(req.Streams, func(i, j int) bool {
		return req.Streams[i].Labels < req.Streams[j].Labels
	})

	_, err := ing.Push(ctx, req)
	require.NoError(t, err)

	// force flush
	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))

	// verify that we get all the data back
	store.checkData(t, map[string][]logproto.Stream{userID: req.Streams})

	// make sure all chunks have different fingerprint, even colliding ones.
	chunkFingerprints := map[model.Fingerprint]bool{}
	for _, c := range store.getChunksForUser(userID) {
		require.False(t, chunkFingerprints[c.FingerprintModel()])
		chunkFingerprints[c.FingerprintModel()] = true
	}
}

func Test_flush_not_owned_stream(t *testing.T) {
	cfg := defaultIngesterTestConfig(t)
	cfg.FlushCheckPeriod = time.Millisecond * 100
	cfg.MaxChunkAge = time.Minute
	cfg.MaxChunkIdle = time.Hour

	store, ing := newTestStore(t, cfg, nil)
	defer store.Stop()

	now := time.Unix(0, 0)

	entries := []logproto.Entry{
		{Timestamp: now.Add(time.Nanosecond), Line: "1"},
		{Timestamp: now.Add(time.Minute), Line: "2"},
	}

	labelSet := model.LabelSet{"app": "l"}
	req := &logproto.PushRequest{Streams: []logproto.Stream{
		{Labels: labelSet.String(), Entries: entries},
	}}

	const userID = "testUser"
	ctx := user.InjectOrgID(context.Background(), userID)

	_, err := ing.Push(ctx, req)
	require.NoError(t, err)

	time.Sleep(2 * cfg.FlushCheckPeriod)

	// ensure chunk is not flushed after flush period elapses
	store.checkData(t, map[string][]logproto.Stream{})

	instance, found := ing.getInstanceByID(userID)
	require.True(t, found)
	fingerprint := instance.getHashForLabels(labels.FromStrings("app", "l"))
	require.Equal(t, model.Fingerprint(16794418009594958), fingerprint)
	instance.ownedStreamsSvc.trackStreamOwnership(fingerprint, false, noPolicy)

	time.Sleep(2 * cfg.FlushCheckPeriod)

	// assert stream is now both batches
	store.checkData(t, map[string][]logproto.Stream{
		userID: {
			{Labels: labelSet.String(), Entries: entries},
		},
	})

	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))
}

func TestFlushMaxAge(t *testing.T) {
	cfg := defaultIngesterTestConfig(t)
	cfg.FlushCheckPeriod = time.Millisecond * 100
	cfg.MaxChunkAge = time.Minute
	cfg.MaxChunkIdle = time.Hour

	store, ing := newTestStore(t, cfg, nil)
	defer store.Stop()

	now := time.Unix(0, 0)

	firstEntries := []logproto.Entry{
		{Timestamp: now.Add(time.Nanosecond), Line: "1"},
		{Timestamp: now.Add(time.Minute), Line: "2"},
	}

	secondEntries := []logproto.Entry{
		{Timestamp: now.Add(time.Second * 61), Line: "3"},
	}

	req := &logproto.PushRequest{Streams: []logproto.Stream{
		{Labels: model.LabelSet{"app": "l"}.String(), Entries: firstEntries},
	}}

	const userID = "testUser"
	ctx := user.InjectOrgID(context.Background(), userID)

	_, err := ing.Push(ctx, req)
	require.NoError(t, err)

	time.Sleep(2 * cfg.FlushCheckPeriod)

	// ensure chunk is not flushed after flush period elapses
	store.checkData(t, map[string][]logproto.Stream{})

	req2 := &logproto.PushRequest{Streams: []logproto.Stream{
		{Labels: model.LabelSet{"app": "l"}.String(), Entries: secondEntries},
	}}

	_, err = ing.Push(ctx, req2)
	require.NoError(t, err)

	time.Sleep(2 * cfg.FlushCheckPeriod)

	// assert stream is now both batches
	store.checkData(t, map[string][]logproto.Stream{
		userID: {
			{Labels: model.LabelSet{"app": "l"}.String(), Entries: append(firstEntries, secondEntries...)},
		},
	})

	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))
}

func TestFlushLoopCanExitDuringInitialWait(t *testing.T) {
	cfg := defaultIngesterTestConfig(t)
	// This gives us an initial delay of max 48s
	// 60s * 0.8 = 48s
	cfg.FlushCheckPeriod = time.Minute

	start := time.Now()
	store, ing := newTestStore(t, cfg, nil)
	defer store.Stop()
	// immediately stop
	require.NoError(t, services.StopAndAwaitTerminated(context.Background(), ing))
	duration := time.Since(start)
	require.True(t, duration < 5*time.Second, "ingester could not shut down while waiting for initial delay")
}

func TestFlushTenantHandler(t *testing.T) {
	const userID = "testUser"

	for _, tc := range []struct {
		name string
		// pushStreams are pushed for userID before the request (built with makeStream).
		pushStreams []logproto.Stream
		// orgID is injected into the request context; an empty value means no tenant is set.
		orgID string
		// flushStreamsSelector is the LogQL selector sent as the "streams" param;
		// an empty value means no selector (flush the whole tenant).
		flushStreamsSelector string

		expectedFlushStatusCode int
		// expectedStreams are the label sets expected to have been flushed to the store.
		expectedStreams []string
		// expectedFlushes is the number of forced index ships (FlushIndexes calls).
		expectedFlushes int32
	}{
		{
			name:                    "matcher scopes flush to matching streams",
			pushStreams:             []logproto.Stream{makeStream(`{app="a"}`, 1), makeStream(`{app="b"}`, 1)},
			orgID:                   userID,
			flushStreamsSelector:    `{app="a"}`,
			expectedFlushStatusCode: http.StatusNoContent,
			expectedStreams:         []string{`{app="a"}`},
			expectedFlushes:         1,
		},
		{
			name:                    "empty selector flushes the whole tenant",
			pushStreams:             []logproto.Stream{makeStream(`{app="a"}`, 1), makeStream(`{app="b"}`, 1)},
			orgID:                   userID,
			expectedFlushStatusCode: http.StatusNoContent,
			expectedStreams:         []string{`{app="a"}`, `{app="b"}`},
			expectedFlushes:         1,
		},
		{
			name:                    "missing tenant is a bad request",
			expectedFlushStatusCode: http.StatusBadRequest,
		},
		{
			name:                    "invalid matcher is a bad request",
			orgID:                   userID,
			flushStreamsSelector:    "not-a-matcher",
			expectedFlushStatusCode: http.StatusBadRequest,
		},
		{
			name:                    "unknown tenant is a no-op",
			orgID:                   "no-such-tenant",
			expectedFlushStatusCode: http.StatusNoContent,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			store, ing := newTestStore(t, defaultIngesterTestConfig(t), nil)
			defer func() { _ = services.StopAndAwaitTerminated(context.Background(), ing) }()

			if len(tc.pushStreams) > 0 {
				_, err := ing.Push(user.InjectOrgID(context.Background(), userID), &logproto.PushRequest{Streams: tc.pushStreams})
				require.NoError(t, err)
			}

			target := "/flush/tenant"
			if tc.flushStreamsSelector != "" {
				target += "?streams=" + url.QueryEscape(tc.flushStreamsSelector)
			}
			w := httptest.NewRecorder()
			r := httptest.NewRequest(http.MethodPost, target, nil)
			if tc.orgID != "" {
				r = r.WithContext(user.InjectOrgID(r.Context(), tc.orgID))
			}

			ing.FlushTenantHandler(w, r)

			require.Equal(t, tc.expectedFlushStatusCode, w.Code)

			var flushedStreams []string
			for _, c := range store.getChunksForUser(userID) {
				flushedStreams = append(flushedStreams, c.Metric.String())
			}
			require.ElementsMatch(t, tc.expectedStreams, flushedStreams)

			require.Equal(t, tc.expectedFlushes, store.flushIndexCalls.Load())
		})
	}
}

// makeStream builds a stream with the given labels and numLogs log lines.
func makeStream(labels string, numLogs int) logproto.Stream {
	now := time.Now()
	entries := make([]logproto.Entry, 0, numLogs)
	for i := 0; i < numLogs; i++ {
		entries = append(entries, logproto.Entry{Timestamp: now, Line: fmt.Sprintf("line-%d", i)})
	}
	return logproto.Stream{Labels: labels, Entries: entries}
}

type testStore struct {
	mtx sync.Mutex
	// Chunks keyed by userID.
	chunks map[string][]chunk.Chunk
	onPut  func(ctx context.Context, chunks []chunk.Chunk) error

	// flushIndexCalls counts how many times FlushIndexes was invoked, so tests can
	// assert the handler forces the index ship after flushing chunks.
	flushIndexCalls atomic.Int32
}

func (s *testStore) FlushIndexes(_ context.Context) error {
	s.flushIndexCalls.Add(1)
	return nil
}

// Note: the ingester New() function creates it's own WAL first which we then override if specified.
// Because of this, ensure any WAL directories exist/are cleaned up even when overriding the wal.
// This is an ugly hook for testing :(
func newTestStore(t require.TestingT, cfg Config, walOverride WAL) (*testStore, *Ingester) {
	store := &testStore{
		chunks: map[string][]chunk.Chunk{},
	}

	readRingMock := mockReadRingWithOneActiveIngester()

	limits, err := validation.NewOverrides(defaultLimitsTestConfig(), nil)
	require.NoError(t, err)

	ing, err := New(cfg, client.Config{}, store, limits, runtime.DefaultTenantConfigs(), nil, writefailures.Cfg{}, constants.Loki, gokitlog.NewNopLogger(), nil, readRingMock, nil)
	require.NoError(t, err)
	require.NoError(t, services.StartAndAwaitRunning(context.Background(), ing))

	if walOverride != nil {
		_ = ing.wal.Stop()
		ing.wal = walOverride
	}

	return store, ing
}

// nolint
func defaultIngesterTestConfig(t testing.TB) Config {
	kvClient, err := kv.NewClient(kv.Config{Store: "inmemory"}, ring.GetCodec(), nil, gokitlog.NewNopLogger())
	require.NoError(t, err)

	cfg := Config{}
	flagext.DefaultValues(&cfg)
	cfg.FlushOpBackoff.MinBackoff = 100 * time.Millisecond
	cfg.FlushOpBackoff.MaxBackoff = 10 * time.Second
	cfg.FlushOpBackoff.MaxRetries = 1
	cfg.FlushOpTimeout = 15 * time.Second
	cfg.FlushCheckPeriod = 99999 * time.Hour
	cfg.MaxChunkIdle = 99999 * time.Hour
	cfg.ConcurrentFlushes = 1
	cfg.LifecyclerConfig.RingConfig.KVStore.Mock = kvClient
	cfg.LifecyclerConfig.NumTokens = 1
	cfg.LifecyclerConfig.ListenPort = 0
	cfg.LifecyclerConfig.Addr = "localhost"
	cfg.LifecyclerConfig.ID = "localhost"
	cfg.LifecyclerConfig.FinalSleep = 0
	cfg.LifecyclerConfig.MinReadyDuration = 0
	cfg.BlockSize = 256 * 1024
	cfg.TargetChunkSize = 1500 * 1024
	cfg.WAL.Enabled = false
	cfg.OwnedStreamsCheckInterval = 1 * time.Second
	return cfg
}

func (s *testStore) Put(ctx context.Context, chunks []chunk.Chunk) error {
	s.mtx.Lock()
	defer s.mtx.Unlock()
	if s.onPut != nil {
		return s.onPut(ctx, chunks)
	}
	userID, err := tenant.TenantID(ctx)
	if err != nil {
		return err
	}
	for ix, chunk := range chunks {
		var err error
		chunk.Metric.Range(func(l labels.Label) {
			if err != nil {
				return
			}
			if l.Value == "" {
				err = fmt.Errorf("Chunk has blank label %q", l.Name)
			}
		})
		if err != nil {
			return err
		}

		// remove __name__ label
		if chunk.Metric.Has("__name__") {
			labelsBuilder := labels.NewBuilder(chunk.Metric)
			labelsBuilder.Del("__name__")
			chunks[ix].Metric = labelsBuilder.Labels()
		}
	}
	s.chunks[userID] = append(s.chunks[userID], chunks...)
	return nil
}

func (s *testStore) PutOne(_ context.Context, _, _ model.Time, _ chunk.Chunk) error {
	return nil
}

func (s *testStore) IsLocal() bool {
	return false
}

func (s *testStore) SelectLogs(_ context.Context, _ logql.SelectLogParams) (iter.EntryIterator, error) {
	return nil, nil
}

func (s *testStore) SelectSamples(_ context.Context, _ logql.SelectSampleParams) (iter.SampleIterator, error) {
	return nil, nil
}

func (s *testStore) SelectSeries(_ context.Context, _ logql.SelectLogParams) ([]logproto.SeriesIdentifier, error) {
	return nil, nil
}

func (s *testStore) GetChunks(_ context.Context, _ string, _, _ model.Time, _ chunk.Predicate, _ *logproto.ChunkRefGroup) ([][]chunk.Chunk, []*fetcher.Fetcher, error) {
	return nil, nil, nil
}

func (s *testStore) GetShards(_ context.Context, _ string, _, _ model.Time, _ uint64, _ chunk.Predicate) (*logproto.ShardsResponse, error) {
	return nil, nil
}

func (s *testStore) HasForSeries(_, _ model.Time) (sharding.ForSeries, bool) {
	return nil, false
}

func (s *testStore) HasChunkSizingInfo(_, _ model.Time) bool {
	return false
}

func (s *testStore) GetChunkRefsWithSizingInfo(_ context.Context, _ string, _, _ model.Time, _ chunk.Predicate) ([]logproto.ChunkRefWithSizingInfo, error) {
	return nil, nil
}

func (s *testStore) GetSchemaConfigs() []config.PeriodConfig {
	return defaultPeriodConfigs
}

func (s *testStore) Stop() {}

func (s *testStore) SetChunkFilterer(_ chunk.RequestChunkFilterer) {}

func (s *testStore) Stats(_ context.Context, _ string, _, _ model.Time, _ ...*labels.Matcher) (*stats.Stats, error) {
	return &stats.Stats{}, nil
}

func (s *testStore) Volume(_ context.Context, _ string, _, _ model.Time, _ int32, _ []string, _ string, _ ...*labels.Matcher) (*logproto.VolumeResponse, error) {
	return &logproto.VolumeResponse{}, nil
}

func (s *testStore) Series(_ context.Context, _ logql.SelectLogParams) ([]logproto.SeriesIdentifier, error) {
	return nil, nil
}

func pushTestSamples(t *testing.T, ing logproto.PusherServer) map[string][]logproto.Stream {
	userIDs := []string{"1", "2", "3"}

	// Create test samples.
	testData := map[string][]logproto.Stream{}
	for i, userID := range userIDs {
		testData[userID] = buildTestStreams(i)
	}

	// Append samples.
	for _, userID := range userIDs {
		ctx := user.InjectOrgID(context.Background(), userID)
		_, err := ing.Push(ctx, &logproto.PushRequest{
			Streams: testData[userID],
		})
		require.NoError(t, err)
	}
	return testData
}

func buildTestStreams(offset int) []logproto.Stream {
	var m []logproto.Stream
	for i := 0; i < numSeries; i++ {
		ss := logproto.Stream{
			Labels: model.Metric{
				"name":         model.LabelValue(fmt.Sprintf("testmetric_%d", i)),
				model.JobLabel: "testjob",
			}.String(),
		}
		for j := 0; j < samplesPerSeries; j++ {
			ss.Entries = append(ss.Entries, logproto.Entry{
				Timestamp: time.Unix(int64(i+j+offset), 0),
				Line:      "line",
			})
		}
		m = append(m, ss)
	}

	sort.Slice(m, func(i, j int) bool {
		return m[i].Labels < m[j].Labels
	})

	return m
}

// check that the store is holding data equivalent to what we expect
func (s *testStore) checkData(t *testing.T, testData map[string][]logproto.Stream) {
	for userID, expected := range testData {
		// Ensure all empty label sets use an empty set of adapters, rather than a nil slice, to make the assertion below easier.
		for _, stream := range expected {
			for i := range stream.Entries {
				if len(stream.Entries[i].Parsed) == 0 {
					stream.Entries[i].Parsed = logproto.EmptyLabelAdapters()
				}

				if len(stream.Entries[i].StructuredMetadata) == 0 {
					stream.Entries[i].StructuredMetadata = logproto.EmptyLabelAdapters()
				}
			}
		}

		streams := s.getStreamsForUser(t, userID)
		require.Equal(t, expected, streams)
	}
}

func (s *testStore) getStreamsForUser(t *testing.T, userID string) []logproto.Stream {
	var streams []logproto.Stream
	for _, c := range s.getChunksForUser(userID) {
		lokiChunk := c.Data.(*chunkenc.Facade).LokiChunk()
		streams = append(streams, buildStreamsFromChunk(t, c.Metric.String(), lokiChunk))
	}
	sort.Slice(streams, func(i, j int) bool {
		return streams[i].Labels < streams[j].Labels
	})
	return streams
}

func (s *testStore) getChunksForUser(userID string) []chunk.Chunk {
	s.mtx.Lock()
	defer s.mtx.Unlock()

	return s.chunks[userID]
}

func buildStreamsFromChunk(t *testing.T, lbs string, chk chunkenc.Chunk) logproto.Stream {
	it, err := chk.Iterator(context.TODO(), time.Unix(0, 0), time.Unix(1000, 0), logproto.FORWARD, log.NewNoopPipeline().ForStream(labels.Labels{}))
	require.NoError(t, err)

	stream := logproto.Stream{
		Labels: lbs,
	}
	for it.Next() {
		stream.Entries = append(stream.Entries, it.At())
	}
	require.NoError(t, it.Err())
	return stream
}
