package client

import (
	"context"
	"strings"
	"testing"
	"time"

	"github.com/go-kit/log"
	"github.com/grafana/dskit/flagext"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/stretchr/testify/require"
	"github.com/twmb/franz-go/pkg/kfake"
	"github.com/twmb/franz-go/pkg/kgo"

	"github.com/grafana/loki/v3/pkg/kafka"
	"github.com/grafana/loki/v3/pkg/kafka/testkafka"
	"github.com/grafana/loki/v3/pkg/validation"
)

func TestNewWriterClient(t *testing.T) {
	_, addr := testkafka.CreateClusterWithoutCustomConsumerGroupsSupport(t, 1, "test", kfake.EnableSASL(), kfake.Superuser("PLAIN", "user", "password"))

	tests := []struct {
		name    string
		config  kafka.Config
		wantErr bool
	}{
		{
			name: "valid config",
			config: kafka.Config{
				Topic:        "abcd",
				SASLUsername: "user",
				SASLPassword: flagext.SecretWithValue("password"),
				WriterConfig: kafka.ClientConfig{
					Address:  addr,
					ClientID: "writer",
				},
				WriteTimeout:                         time.Second,
				ProducerMaxInflightRequestsPerBroker: 20,
				ProducerLinger:                       50 * time.Millisecond,
			},
			wantErr: false,
		},
		{
			name: "wrong password",
			config: kafka.Config{
				WriterConfig: kafka.ClientConfig{
					Address:  addr,
					ClientID: "writer",
				},
				Topic:                                "abcd",
				WriteTimeout:                         time.Second,
				SASLUsername:                         "user",
				SASLPassword:                         flagext.SecretWithValue("wrong wrong wrong"),
				ProducerMaxInflightRequestsPerBroker: 20,
				ProducerLinger:                       50 * time.Millisecond,
			},
			wantErr: true,
		},
		{
			name: "wrong username",
			config: kafka.Config{
				WriterConfig: kafka.ClientConfig{
					Address:  addr,
					ClientID: "writer",
				},
				Topic:                                "abcd",
				WriteTimeout:                         time.Second,
				SASLUsername:                         "wrong wrong wrong",
				SASLPassword:                         flagext.SecretWithValue("password"),
				ProducerMaxInflightRequestsPerBroker: 20,
				ProducerLinger:                       50 * time.Millisecond,
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client, err := NewWriterClient("test-client", tt.config, log.NewNopLogger(), prometheus.NewRegistry())
			require.NoError(t, err)

			err = client.Ping(context.Background())
			if tt.wantErr {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestProducer(t *testing.T) {
	t.Run("no records", func(t *testing.T) {
		_, kafkaCfg := testkafka.CreateCluster(t, 1, "test-topic")
		client, err := NewWriterClient("test-client", kafkaCfg, log.NewNopLogger(), prometheus.NewRegistry())
		require.NoError(t, err)

		producer := NewProducer("test-producer", client, 1024*1024, prometheus.NewRegistry())

		results := producer.ProduceSync(t.Context(), []*kgo.Record{})
		require.Len(t, results, 0)
	})

	t.Run("on context canceled", func(t *testing.T) {
		_, kafkaCfg := testkafka.CreateCluster(t, 1, "test-topic")
		client, err := NewWriterClient("test-client", kafkaCfg, log.NewNopLogger(), prometheus.NewRegistry())
		require.NoError(t, err)

		producer := NewProducer("test-producer", client, 1024*1024, prometheus.NewRegistry())

		// Force a canceled context.
		cancelCtx, cancel := context.WithCancel(t.Context())
		cancel()
		rec1 := &kgo.Record{Key: []byte("key1"), Value: []byte("value1")}
		rec2 := &kgo.Record{Key: []byte("key2"), Value: []byte("value2")}
		results := producer.ProduceSync(cancelCtx, []*kgo.Record{rec1, rec2})
		require.Len(t, results, 2)

		// Each result should contain a "context canceled" error.
		require.Equal(t, rec1, results[0].Record)
		require.EqualError(t, results[0].Err, "context canceled")
		require.Equal(t, rec2, results[1].Record)
		require.EqualError(t, results[1].Err, "context canceled")
	})

	t.Run("records are failed if total exceeds buffer size", func(t *testing.T) {
		_, kafkaCfg := testkafka.CreateCluster(t, 1, "test-topic")
		client, err := NewWriterClient("test-client", kafkaCfg, log.NewNopLogger(), prometheus.NewRegistry())
		require.NoError(t, err)

		// Set a 1KB limit on buffered records.
		producer := NewProducer("test-producer", client, 1024, prometheus.NewRegistry())

		rec1 := &kgo.Record{Key: []byte("key1"), Value: []byte(strings.Repeat("a", 1024))}
		rec2 := &kgo.Record{Key: []byte("key2"), Value: []byte("b")}
		results := producer.ProduceSync(t.Context(), []*kgo.Record{rec1, rec2})
		require.Len(t, results, 2)

		// All records should fail.
		require.Equal(t, rec1, results[0].Record)
		require.EqualError(t, results[0].Err, "the maximum amount of records are buffered, cannot buffer more")
		require.Equal(t, rec2, results[1].Record)
		require.EqualError(t, results[1].Err, "the maximum amount of records are buffered, cannot buffer more")

		// Should be able to produce either record individually.
		results = producer.ProduceSync(t.Context(), []*kgo.Record{rec1})
		require.Len(t, results, 1)
		require.Equal(t, rec1, results[0].Record)
		require.NoError(t, results[0].Err)

		results = producer.ProduceSync(t.Context(), []*kgo.Record{rec2})
		require.Len(t, results, 1)
		require.Equal(t, rec2, results[0].Record)
		require.NoError(t, results[0].Err)
	})
}

func TestProducerWithInterceptor(t *testing.T) {
	_, kafkaCfg := testkafka.CreateCluster(t, 1, "test-topic")

	client, err := NewWriterClient("test-client", kafkaCfg, log.NewNopLogger(), prometheus.NewRegistry())
	require.NoError(t, err)

	producer := NewProducer("test-producer", client, 1024*1024, prometheus.NewRegistry(),
		WithRecordsInterceptor(validation.IngestionPoliciesKafkaProducerInterceptor))

	t.Run("with policy in context", func(t *testing.T) {
		// Create context with ingestion policy
		ctx := validation.InjectIngestionPolicyContext(t.Context(), "test-policy")

		// Create test records
		records := []*kgo.Record{
			{Value: []byte("test-value-1"), Partition: 0},
			{Value: []byte("test-value-2"), Partition: 0},
		}

		results := producer.ProduceSync(ctx, records)
		require.NoError(t, results.FirstErr())

		// Verify interceptor added the ingestion policy header to all records
		for _, record := range records {
			require.Len(t, record.Headers, 1)
			require.Equal(t, "x-loki-ingestion-policy", record.Headers[0].Key)
			require.Equal(t, []byte("test-policy"), record.Headers[0].Value)
		}
	})

	t.Run("without policy in context", func(t *testing.T) {
		records := []*kgo.Record{
			{Value: []byte("test-value-1"), Partition: 0},
		}

		results := producer.ProduceSync(t.Context(), records)
		require.NoError(t, results.FirstErr())

		// Verify no headers were added
		require.Len(t, records[0].Headers, 0)
	})
}
