// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package mysql

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"database/sql"
	"errors"
	"fmt"
	"net"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/go-sql-driver/mysql"
	"github.com/go-viper/mapstructure/v2"
	"github.com/hashicorp/go-multierror"
	"github.com/hashicorp/go-secure-stdlib/parseutil"
	"github.com/hashicorp/go-uuid"
	"github.com/openbao/openbao/sdk/v2/database/helper/connutil"
	"github.com/openbao/openbao/sdk/v2/database/helper/dbutil"
)

// mySQLConnectionProducer implements ConnectionProducer and provides a generic producer for most sql databases
type mySQLConnectionProducer struct {
	ConnectionURL            string `json:"connection_url" mapstructure:"connection_url"`
	MaxOpenConnections       int    `json:"max_open_connections" mapstructure:"max_open_connections"`
	MaxIdleConnections       int    `json:"max_idle_connections" mapstructure:"max_idle_connections"`
	MaxConnectionLifetimeRaw any    `json:"max_connection_lifetime" mapstructure:"max_connection_lifetime"`
	Username                 string `json:"username" mapstructure:"username"`
	Password                 string `json:"password" mapstructure:"password"`

	TLSCertificateKeyData []byte `json:"tls_certificate_key" mapstructure:"tls_certificate_key"`
	TLSCAData             []byte `json:"tls_ca" mapstructure:"tls_ca"`
	TLSServerName         string `json:"tls_server_name" mapstructure:"tls_server_name"`
	TLSSkipVerify         bool   `json:"tls_skip_verify" mapstructure:"tls_skip_verify"`

	// tlsConfigName is a globally unique name that references the TLS config for this instance in the mysql driver
	tlsConfigName string

	// hosts holds parsed host:port pairs for multi-host failover
	hosts []string

	RawConfig             map[string]any
	maxConnectionLifetime time.Duration
	Initialized           bool
	db                    *sql.DB
	sync.Mutex
}

func (c *mySQLConnectionProducer) Initialize(ctx context.Context, conf map[string]any, verifyConnection bool) error {
	_, err := c.Init(ctx, conf, verifyConnection)
	return err
}

func (c *mySQLConnectionProducer) Init(ctx context.Context, conf map[string]any, verifyConnection bool) (map[string]any, error) {
	c.Lock()
	defer c.Unlock()

	c.RawConfig = conf

	err := mapstructure.WeakDecode(conf, &c)
	if err != nil {
		return nil, err
	}

	if len(c.ConnectionURL) == 0 {
		return nil, errors.New("connection_url cannot be empty")
	}

	// Don't escape special characters for MySQL password
	password := c.Password

	// QueryHelper doesn't do any SQL escaping, but if it starts to do so
	// then maybe we won't be able to use it to do URL substitution any more.
	c.ConnectionURL = dbutil.QueryHelper(c.ConnectionURL, map[string]string{
		"username": url.PathEscape(c.Username),
		"password": password,
	})

	// Parse multi-host DSN for failover support
	if err := c.parseMultiHostDSN(); err != nil {
		return nil, fmt.Errorf("error parsing multi-host DSN: %w", err)
	}

	if c.MaxOpenConnections == 0 {
		c.MaxOpenConnections = 4
	}

	if c.MaxIdleConnections == 0 {
		c.MaxIdleConnections = c.MaxOpenConnections
	}
	if c.MaxIdleConnections > c.MaxOpenConnections {
		c.MaxIdleConnections = c.MaxOpenConnections
	}
	if c.MaxConnectionLifetimeRaw == nil {
		c.MaxConnectionLifetimeRaw = "0s"
	}

	c.maxConnectionLifetime, err = parseutil.ParseDurationSecond(c.MaxConnectionLifetimeRaw)
	if err != nil {
		return nil, fmt.Errorf("invalid max_connection_lifetime: %w", err)
	}

	tlsConfig, err := c.getTLSAuth()
	if err != nil {
		return nil, err
	}

	if tlsConfig != nil {
		if c.tlsConfigName == "" {
			c.tlsConfigName, err = uuid.GenerateUUID()
			if err != nil {
				return nil, fmt.Errorf("unable to generate UUID for TLS configuration: %w", err)
			}
		}

		mysql.RegisterTLSConfig(c.tlsConfigName, tlsConfig)
	}

	// Set initialized to true at this point since all fields are set,
	// and the connection can be established at a later time.
	c.Initialized = true

	if verifyConnection {
		if _, err = c.Connection(ctx); err != nil {
			return nil, fmt.Errorf("error verifying - connection: %w", err)
		}

		if err := c.db.PingContext(ctx); err != nil {
			return nil, fmt.Errorf("error verifying - ping: %w", err)
		}
	}

	return c.RawConfig, nil
}

func (c *mySQLConnectionProducer) Connection(ctx context.Context) (any, error) {
	if !c.Initialized {
		return nil, connutil.ErrNotInitialized
	}

	// If we already have a DB, test it and return
	if c.db != nil {
		if err := c.db.PingContext(ctx); err == nil {
			return c.db, nil
		}
		// If the ping was unsuccessful, close it and ignore errors as we'll be
		// reestablishing anyways
		c.db.Close()
	}

	// Parse the DSN into a Config struct
	config, err := mysql.ParseDSN(c.ConnectionURL)
	if err != nil {
		return nil, fmt.Errorf("unable to parse connectionURL: %w", err)
	}

	// Set TLS config if configured
	if c.tlsConfigName != "" {
		config.TLSConfig = c.tlsConfigName
	}

	// Enable multi-host failover if multiple hosts are configured
	if len(c.hosts) > 1 {
		config.DialFunc = c.dialWithFailover
	}

	// Create connector and open DB using the connector-based approach
	connector, err := mysql.NewConnector(config)
	if err != nil {
		return nil, fmt.Errorf("unable to create mysql connector: %w", err)
	}

	c.db = sql.OpenDB(connector)

	// Set some connection pool settings. We don't need much of this,
	// since the request rate shouldn't be high.
	c.db.SetMaxOpenConns(c.MaxOpenConnections)
	c.db.SetMaxIdleConns(c.MaxIdleConnections)
	c.db.SetConnMaxLifetime(c.maxConnectionLifetime)

	return c.db, nil
}

func (c *mySQLConnectionProducer) SecretValues() map[string]string {
	return map[string]string{
		c.Password: "[password]",
	}
}

// Close attempts to close the connection
func (c *mySQLConnectionProducer) Close() error {
	// Grab the write lock
	c.Lock()
	defer c.Unlock()

	if c.db != nil {
		c.db.Close()
	}

	c.db = nil

	return nil
}

func (c *mySQLConnectionProducer) getTLSAuth() (tlsConfig *tls.Config, err error) {
	if len(c.TLSCAData) == 0 &&
		len(c.TLSCertificateKeyData) == 0 {
		return nil, nil
	}

	rootCertPool := x509.NewCertPool()
	if len(c.TLSCAData) > 0 {
		ok := rootCertPool.AppendCertsFromPEM(c.TLSCAData)
		if !ok {
			return nil, errors.New("failed to append CA to client options")
		}
	}

	clientCert := make([]tls.Certificate, 0, 1)

	if len(c.TLSCertificateKeyData) > 0 {
		certificate, err := tls.X509KeyPair(c.TLSCertificateKeyData, c.TLSCertificateKeyData)
		if err != nil {
			return nil, fmt.Errorf("unable to load tls_certificate_key_data: %w", err)
		}

		clientCert = append(clientCert, certificate)
	}

	tlsConfig = &tls.Config{
		RootCAs:            rootCertPool,
		Certificates:       clientCert,
		ServerName:         c.TLSServerName,
		InsecureSkipVerify: c.TLSSkipVerify,
	}

	return tlsConfig, nil
}

// parseMultiHostDSN extracts multiple hosts from connection URL for failover.
func (c *mySQLConnectionProducer) parseMultiHostDSN() error {
	// Match tcp(...) in the connection URL
	re := regexp.MustCompile(`tcp\(([^)]+)\)`)
	match := re.FindStringSubmatch(c.ConnectionURL)

	if match == nil {
		// No tcp() found - could be unix socket or other format
		// Leave hosts empty, single-host behavior will be used
		return nil
	}

	hostsPart := match[1]

	// Check if there are multiple hosts (comma-separated)
	if !strings.Contains(hostsPart, ",") {
		// Single host - ensure it has a port, store it, and return
		host := strings.TrimSpace(hostsPart)
		if _, _, err := net.SplitHostPort(host); err != nil {
			host += ":3306"
		}
		c.hosts = []string{host}
		return nil
	}

	// Multiple hosts found - parse each one
	hostList := strings.Split(hostsPart, ",")
	c.hosts = make([]string, 0, len(hostList))

	for _, h := range hostList {
		h = strings.TrimSpace(h)
		if h == "" {
			continue
		}
		// Ensure each host has a port
		if _, _, err := net.SplitHostPort(h); err != nil {
			h += ":3306"
		}
		c.hosts = append(c.hosts, h)
	}

	if len(c.hosts) == 0 {
		return errors.New("no valid hosts found in connection URL")
	}

	// Normalize the ConnectionURL to use only the first host
	// This is required because mysql.ParseDSN() doesn't support multiple hosts
	c.ConnectionURL = re.ReplaceAllString(c.ConnectionURL, fmt.Sprintf("tcp(%s)", c.hosts[0]))

	return nil
}

// dialWithFailover tries each host in sequence until one succeeds.
func (c *mySQLConnectionProducer) dialWithFailover(ctx context.Context, network, _ string) (conn net.Conn, err error) {
	var merr *multierror.Error

	for _, host := range c.hosts {
		var d net.Dialer

		conn, err = d.DialContext(ctx, network, host)
		if err == nil {
			return conn, nil
		}
		merr = multierror.Append(merr, fmt.Errorf("failed to connect to %s: %w", host, err))
	}

	return nil, merr.ErrorOrNil()
}
