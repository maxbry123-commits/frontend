package v0alpha1

TeamSpec: {
	title:       string
	email:       string
	provisioned: bool
	externalUID: string
	members: [...TeamMember]
	externalGroups?: [...string]
}
