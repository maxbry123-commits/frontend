package v0alpha1

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/grafana/grafana-app-sdk/resource"
)

type TeamClient struct {
	client *resource.TypedClient[*Team, *TeamList]
}

func NewTeamClient(client resource.Client) *TeamClient {
	return &TeamClient{
		client: resource.NewTypedClient[*Team, *TeamList](client, TeamKind()),
	}
}

func NewTeamClientFromGenerator(generator resource.ClientGenerator) (*TeamClient, error) {
	c, err := generator.ClientFor(TeamKind())
	if err != nil {
		return nil, err
	}
	return NewTeamClient(c), nil
}

func (c *TeamClient) Get(ctx context.Context, identifier resource.Identifier) (*Team, error) {
	return c.client.Get(ctx, identifier)
}

func (c *TeamClient) List(ctx context.Context, namespace string, opts resource.ListOptions) (*TeamList, error) {
	return c.client.List(ctx, namespace, opts)
}

func (c *TeamClient) ListAll(ctx context.Context, namespace string, opts resource.ListOptions) (*TeamList, error) {
	resp, err := c.client.List(ctx, namespace, resource.ListOptions{
		ResourceVersion: opts.ResourceVersion,
		Limit:           opts.Limit,
		LabelFilters:    opts.LabelFilters,
		FieldSelectors:  opts.FieldSelectors,
	})
	if err != nil {
		return nil, err
	}
	for resp.GetContinue() != "" {
		page, err := c.client.List(ctx, namespace, resource.ListOptions{
			Continue:        resp.GetContinue(),
			ResourceVersion: opts.ResourceVersion,
			Limit:           opts.Limit,
			LabelFilters:    opts.LabelFilters,
			FieldSelectors:  opts.FieldSelectors,
		})
		if err != nil {
			return nil, err
		}
		resp.SetContinue(page.GetContinue())
		resp.SetResourceVersion(page.GetResourceVersion())
		resp.SetItems(append(resp.GetItems(), page.GetItems()...))
	}
	return resp, nil
}

func (c *TeamClient) Create(ctx context.Context, obj *Team, opts resource.CreateOptions) (*Team, error) {
	// Make sure apiVersion and kind are set
	obj.APIVersion = GroupVersion.Identifier()
	obj.Kind = TeamKind().Kind()
	return c.client.Create(ctx, obj, opts)
}

func (c *TeamClient) Update(ctx context.Context, obj *Team, opts resource.UpdateOptions) (*Team, error) {
	return c.client.Update(ctx, obj, opts)
}

func (c *TeamClient) Patch(ctx context.Context, identifier resource.Identifier, req resource.PatchRequest, opts resource.PatchOptions) (*Team, error) {
	return c.client.Patch(ctx, identifier, req, opts)
}

func (c *TeamClient) Delete(ctx context.Context, identifier resource.Identifier, opts resource.DeleteOptions) error {
	return c.client.Delete(ctx, identifier, opts)
}

type CreateTeamMemberRequest struct {
	Body    CreateTeamMemberRequestBody
	Headers http.Header
}

func (c *TeamClient) CreateTeamMember(ctx context.Context, identifier resource.Identifier, request CreateTeamMemberRequest) (*CreateTeamMemberResponse, error) {
	body, err := json.Marshal(request.Body)
	if err != nil {
		return nil, fmt.Errorf("unable to marshal body to JSON: %w", err)
	}
	resp, err := c.client.SubresourceRequest(ctx, identifier, resource.CustomRouteRequestOptions{
		Path:    "/addmember",
		Verb:    "POST",
		Body:    io.NopCloser(bytes.NewReader(body)),
		Headers: request.Headers,
	})
	if err != nil {
		return nil, err
	}
	cast := CreateTeamMemberResponse{}
	err = json.Unmarshal(resp, &cast)
	if err != nil {
		return nil, fmt.Errorf("unable to unmarshal response bytes into CreateTeamMemberResponse: %w", err)
	}
	return &cast, nil
}

type GetTeamGroupsRequest struct {
	Headers http.Header
}

func (c *TeamClient) GetTeamGroups(ctx context.Context, identifier resource.Identifier, request GetTeamGroupsRequest) (*GetTeamGroupsResponse, error) {
	resp, err := c.client.SubresourceRequest(ctx, identifier, resource.CustomRouteRequestOptions{
		Path:    "/groups",
		Verb:    "GET",
		Headers: request.Headers,
	})
	if err != nil {
		return nil, err
	}
	cast := GetTeamGroupsResponse{}
	err = json.Unmarshal(resp, &cast)
	if err != nil {
		return nil, fmt.Errorf("unable to unmarshal response bytes into GetTeamGroupsResponse: %w", err)
	}
	return &cast, nil
}

type GetTeamMembersRequest struct {
	Headers http.Header
}

func (c *TeamClient) GetTeamMembers(ctx context.Context, identifier resource.Identifier, request GetTeamMembersRequest) (*GetTeamMembersResponse, error) {
	resp, err := c.client.SubresourceRequest(ctx, identifier, resource.CustomRouteRequestOptions{
		Path:    "/members",
		Verb:    "GET",
		Headers: request.Headers,
	})
	if err != nil {
		return nil, err
	}
	cast := GetTeamMembersResponse{}
	err = json.Unmarshal(resp, &cast)
	if err != nil {
		return nil, fmt.Errorf("unable to unmarshal response bytes into GetTeamMembersResponse: %w", err)
	}
	return &cast, nil
}

type DeleteTeamMemberRequest struct {
	Body    DeleteTeamMemberRequestBody
	Headers http.Header
}

func (c *TeamClient) DeleteTeamMember(ctx context.Context, identifier resource.Identifier, request DeleteTeamMemberRequest) (*DeleteTeamMemberResponse, error) {
	body, err := json.Marshal(request.Body)
	if err != nil {
		return nil, fmt.Errorf("unable to marshal body to JSON: %w", err)
	}
	resp, err := c.client.SubresourceRequest(ctx, identifier, resource.CustomRouteRequestOptions{
		Path:    "/removemember",
		Verb:    "POST",
		Body:    io.NopCloser(bytes.NewReader(body)),
		Headers: request.Headers,
	})
	if err != nil {
		return nil, err
	}
	cast := DeleteTeamMemberResponse{}
	err = json.Unmarshal(resp, &cast)
	if err != nil {
		return nil, fmt.Errorf("unable to unmarshal response bytes into DeleteTeamMemberResponse: %w", err)
	}
	return &cast, nil
}
