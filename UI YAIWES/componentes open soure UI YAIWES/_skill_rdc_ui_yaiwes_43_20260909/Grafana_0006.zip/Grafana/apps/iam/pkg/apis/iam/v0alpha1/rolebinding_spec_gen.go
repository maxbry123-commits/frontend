// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v0alpha1

// +k8s:openapi-gen=true
type RoleBindingspecSubject struct {
	// kind of the identity getting the permission
	Kind RoleBindingSpecSubjectKind `json:"kind"`
	// uid of the identity
	Name string `json:"name"`
}

// NewRoleBindingspecSubject creates a new RoleBindingspecSubject object.
func NewRoleBindingspecSubject() *RoleBindingspecSubject {
	return &RoleBindingspecSubject{}
}

// OpenAPIModelName returns the OpenAPI model name for RoleBindingspecSubject.
func (RoleBindingspecSubject) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.iam.pkg.apis.iam.v0alpha1.RoleBindingspecSubject"
}

// +k8s:openapi-gen=true
type RoleBindingspecRoleRef struct {
	// kind of role
	Kind RoleBindingSpecRoleRefKind `json:"kind"`
	// uid of the role
	Name string `json:"name"`
}

// NewRoleBindingspecRoleRef creates a new RoleBindingspecRoleRef object.
func NewRoleBindingspecRoleRef() *RoleBindingspecRoleRef {
	return &RoleBindingspecRoleRef{}
}

// OpenAPIModelName returns the OpenAPI model name for RoleBindingspecRoleRef.
func (RoleBindingspecRoleRef) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.iam.pkg.apis.iam.v0alpha1.RoleBindingspecRoleRef"
}

// +k8s:openapi-gen=true
type RoleBindingSpec struct {
	Subject  RoleBindingspecSubject   `json:"subject"`
	RoleRefs []RoleBindingspecRoleRef `json:"roleRefs"`
}

// NewRoleBindingSpec creates a new RoleBindingSpec object.
func NewRoleBindingSpec() *RoleBindingSpec {
	return &RoleBindingSpec{
		Subject:  *NewRoleBindingspecSubject(),
		RoleRefs: []RoleBindingspecRoleRef{},
	}
}

// OpenAPIModelName returns the OpenAPI model name for RoleBindingSpec.
func (RoleBindingSpec) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.iam.pkg.apis.iam.v0alpha1.RoleBindingSpec"
}

// +k8s:openapi-gen=true
type RoleBindingSpecSubjectKind string

const (
	RoleBindingSpecSubjectKindUser           RoleBindingSpecSubjectKind = "User"
	RoleBindingSpecSubjectKindServiceAccount RoleBindingSpecSubjectKind = "ServiceAccount"
	RoleBindingSpecSubjectKindTeam           RoleBindingSpecSubjectKind = "Team"
)

// OpenAPIModelName returns the OpenAPI model name for RoleBindingSpecSubjectKind.
func (RoleBindingSpecSubjectKind) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.iam.pkg.apis.iam.v0alpha1.RoleBindingSpecSubjectKind"
}

// +k8s:openapi-gen=true
type RoleBindingSpecRoleRefKind string

const (
	RoleBindingSpecRoleRefKindRole       RoleBindingSpecRoleRefKind = "Role"
	RoleBindingSpecRoleRefKindGlobalRole RoleBindingSpecRoleRefKind = "GlobalRole"
)

// OpenAPIModelName returns the OpenAPI model name for RoleBindingSpecRoleRefKind.
func (RoleBindingSpecRoleRefKind) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.iam.pkg.apis.iam.v0alpha1.RoleBindingSpecRoleRefKind"
}
