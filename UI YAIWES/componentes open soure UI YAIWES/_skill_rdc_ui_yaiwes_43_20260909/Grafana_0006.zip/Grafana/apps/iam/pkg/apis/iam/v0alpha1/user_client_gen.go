package v0alpha1

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"

	"github.com/grafana/grafana-app-sdk/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

type UserClient struct {
	client *resource.TypedClient[*User, *UserList]
}

func NewUserClient(client resource.Client) *UserClient {
	return &UserClient{
		client: resource.NewTypedClient[*User, *UserList](client, UserKind()),
	}
}

func NewUserClientFromGenerator(generator resource.ClientGenerator) (*UserClient, error) {
	c, err := generator.ClientFor(UserKind())
	if err != nil {
		return nil, err
	}
	return NewUserClient(c), nil
}

func (c *UserClient) Get(ctx context.Context, identifier resource.Identifier) (*User, error) {
	return c.client.Get(ctx, identifier)
}

func (c *UserClient) List(ctx context.Context, namespace string, opts resource.ListOptions) (*UserList, error) {
	return c.client.List(ctx, namespace, opts)
}

func (c *UserClient) ListAll(ctx context.Context, namespace string, opts resource.ListOptions) (*UserList, error) {
	resp, err := c.client.List(ctx, namespace, resource.ListOptions{
		ResourceVersion: opts.ResourceVersion,
		Limit:           opts.Limit,
		LabelFilters:    opts.LabelFilters,
		FieldSelectors:  opts.FieldSelectors,
	})
	if err != nil {
		return nil, err
	}
	for resp.GetContinue() != "" {
		page, err := c.client.List(ctx, namespace, resource.ListOptions{
			Continue:        resp.GetContinue(),
			ResourceVersion: opts.ResourceVersion,
			Limit:           opts.Limit,
			LabelFilters:    opts.LabelFilters,
			FieldSelectors:  opts.FieldSelectors,
		})
		if err != nil {
			return nil, err
		}
		resp.SetContinue(page.GetContinue())
		resp.SetResourceVersion(page.GetResourceVersion())
		resp.SetItems(append(resp.GetItems(), page.GetItems()...))
	}
	return resp, nil
}

func (c *UserClient) Create(ctx context.Context, obj *User, opts resource.CreateOptions) (*User, error) {
	// Make sure apiVersion and kind are set
	obj.APIVersion = GroupVersion.Identifier()
	obj.Kind = UserKind().Kind()
	return c.client.Create(ctx, obj, opts)
}

func (c *UserClient) Update(ctx context.Context, obj *User, opts resource.UpdateOptions) (*User, error) {
	return c.client.Update(ctx, obj, opts)
}

func (c *UserClient) Patch(ctx context.Context, identifier resource.Identifier, req resource.PatchRequest, opts resource.PatchOptions) (*User, error) {
	return c.client.Patch(ctx, identifier, req, opts)
}

func (c *UserClient) UpdateStatus(ctx context.Context, identifier resource.Identifier, newStatus UserStatus, opts resource.UpdateOptions) (*User, error) {
	return c.client.Update(ctx, &User{
		TypeMeta: metav1.TypeMeta{
			Kind:       UserKind().Kind(),
			APIVersion: GroupVersion.Identifier(),
		},
		ObjectMeta: metav1.ObjectMeta{
			ResourceVersion: opts.ResourceVersion,
			Namespace:       identifier.Namespace,
			Name:            identifier.Name,
		},
		Status: newStatus,
	}, resource.UpdateOptions{
		Subresource:     "status",
		ResourceVersion: opts.ResourceVersion,
	})
}

func (c *UserClient) Delete(ctx context.Context, identifier resource.Identifier, opts resource.DeleteOptions) error {
	return c.client.Delete(ctx, identifier, opts)
}

type GetUserTeamsRequest struct {
	Params  GetUserTeamsRequestParams
	Headers http.Header
}

func (c *UserClient) GetUserTeams(ctx context.Context, identifier resource.Identifier, request GetUserTeamsRequest) (*GetUserTeamsResponse, error) {
	params := url.Values{}
	params.Set("continue", fmt.Sprintf("%v", request.Params.Continue))
	params.Set("limit", fmt.Sprintf("%v", request.Params.Limit))
	resp, err := c.client.SubresourceRequest(ctx, identifier, resource.CustomRouteRequestOptions{
		Path:    "/teams",
		Verb:    "GET",
		Query:   params,
		Headers: request.Headers,
	})
	if err != nil {
		return nil, err
	}
	cast := GetUserTeamsResponse{}
	err = json.Unmarshal(resp, &cast)
	if err != nil {
		return nil, fmt.Errorf("unable to unmarshal response bytes into GetUserTeamsResponse: %w", err)
	}
	return &cast, nil
}
