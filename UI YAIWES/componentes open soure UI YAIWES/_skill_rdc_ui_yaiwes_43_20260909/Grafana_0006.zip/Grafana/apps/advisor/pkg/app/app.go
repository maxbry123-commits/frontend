package app

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/authorization/authorizer"
	"k8s.io/client-go/rest"

	"github.com/prometheus/client_golang/prometheus"

	"github.com/grafana/grafana-app-sdk/app"
	"github.com/grafana/grafana-app-sdk/k8s"
	appsdkapiserver "github.com/grafana/grafana-app-sdk/k8s/apiserver"
	"github.com/grafana/grafana-app-sdk/logging"
	"github.com/grafana/grafana-app-sdk/operator"
	"github.com/grafana/grafana-app-sdk/resource"
	"github.com/grafana/grafana-app-sdk/simple"
	advisorapi "github.com/grafana/grafana/apps/advisor/pkg/apis"
	advisorv0alpha1 "github.com/grafana/grafana/apps/advisor/pkg/apis/advisor/v0alpha1"
	"github.com/grafana/grafana/apps/advisor/pkg/app/checkregistry"
	"github.com/grafana/grafana/apps/advisor/pkg/app/checks"
	"github.com/grafana/grafana/apps/advisor/pkg/app/checkscheduler"
	"github.com/grafana/grafana/apps/advisor/pkg/app/checktyperegisterer"
	"github.com/grafana/grafana/apps/advisor/pkg/app/metrics"
	"github.com/grafana/grafana/apps/advisor/pkg/translations"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/services/org"
	"github.com/grafana/grafana/pkg/setting"
)

func New(cfg app.Config) (app.App, error) {
	// Needed until https://github.com/grafana/grafana-app-sdk/pull/1077
	if cfg.KubeConfig.APIPath == "" {
		cfg.KubeConfig.APIPath = "apis"
	}
	// Read config
	specificConfig, ok := cfg.SpecificConfig.(checkregistry.AdvisorAppConfig)
	if !ok {
		return nil, fmt.Errorf("invalid config type")
	}
	checkRegistry := specificConfig.CheckRegistry
	log := logging.DefaultLogger.With("app", "advisor.app")

	// Prepare storage client
	clientGenerator := k8s.NewClientRegistry(cfg.KubeConfig, k8s.ClientConfig{})
	client, err := clientGenerator.ClientFor(advisorv0alpha1.CheckKind())
	if err != nil {
		return nil, err
	}
	typesClient, err := clientGenerator.ClientFor(advisorv0alpha1.CheckTypeKind())
	if err != nil {
		return nil, err
	}

	// Initialize checks
	checkMap := map[string]checks.Check{}
	for _, c := range checkRegistry.Checks() {
		checkMap[c.ID()] = c
	}

	ctr, err := checktyperegisterer.New(cfg, log)
	if err != nil {
		return nil, err
	}

	csch, err := checkscheduler.New(cfg, log, ctr)
	if err != nil {
		return nil, err
	}

	simpleConfig := simple.AppConfig{
		Name:       "advisor",
		KubeConfig: cfg.KubeConfig,
		InformerConfig: simple.AppInformerConfig{
			InformerOptions: operator.InformerOptions{
				ErrorHandler: func(ctx context.Context, err error) {
					log.WithContext(ctx).Error("Informer processing error", "error", err)
				},
			},
		},
		ManagedKinds: []simple.AppManagedKind{
			{
				Kind: advisorv0alpha1.CheckKind(),
				Validator: &simple.Validator{
					ValidateFunc: func(ctx context.Context, req *app.AdmissionRequest) error {
						if req.Object != nil {
							check, err := getCheck(req.Object, checkMap)
							if err != nil {
								return err
							}
							if req.Action == resource.AdmissionActionCreate {
								go func() {
									logger := log.WithContext(ctx).With("check", check.ID())
									logger.Debug("Processing check", "namespace", req.Object.GetNamespace())
									start := time.Now()
									checkType := check.ID()
									orgID, err := getOrgIDFromNamespace(req.Object.GetNamespace())
									if err != nil {
										logger.Error("Error getting org ID from namespace", "error", err)
										metrics.OrgIDErrorsTotal.Inc()
										return
									}
									ctx = identity.WithServiceIdentityContext(context.WithoutCancel(ctx), orgID)
									err = processCheck(ctx, logger, client, typesClient, req.Object, check)
									if err != nil {
										logger.Error("Error processing check", "error", err)
										metrics.CheckProcessingTotal.WithLabelValues("process", "error", checkType).Inc()
									} else {
										metrics.CheckProcessingTotal.WithLabelValues("process", "success", checkType).Inc()
									}
									metrics.CheckProcessingDurationSeconds.WithLabelValues("process", checkType).Observe(time.Since(start).Seconds())
								}()
							}
							if req.Action == resource.AdmissionActionUpdate && retryAnnotationChanged(req.OldObject, req.Object) {
								go func() {
									logger := log.WithContext(ctx).With("check", check.ID())
									logger.Debug("Updating check", "namespace", req.Object.GetNamespace(), "name", req.Object.GetName())
									start := time.Now()
									checkType := check.ID()
									orgID, err := getOrgIDFromNamespace(req.Object.GetNamespace())
									if err != nil {
										logger.Error("Error getting org ID from namespace", "error", err)
										metrics.OrgIDErrorsTotal.Inc()
										return
									}
									ctx = identity.WithServiceIdentityContext(context.WithoutCancel(ctx), orgID)
									err = processCheckRetry(ctx, logger, client, typesClient, req.Object, check)
									if err != nil {
										logger.Error("Error processing check retry", "error", err)
										metrics.CheckProcessingTotal.WithLabelValues("retry", "error", checkType).Inc()
									} else {
										metrics.CheckProcessingTotal.WithLabelValues("retry", "success", checkType).Inc()
									}
									metrics.CheckProcessingDurationSeconds.WithLabelValues("retry", checkType).Observe(time.Since(start).Seconds())
								}()
							}
						}
						return nil
					},
				},
			},
			{
				Kind: advisorv0alpha1.CheckTypeKind(),
			},
		},
		VersionedCustomRoutes: map[string]simple.AppVersionRouteHandlers{
			"v0alpha1": {
				{
					Namespaced: true,
					Path:       "register",
					Method:     "POST",
				}: func(ctx context.Context, w app.CustomRouteResponseWriter, req *app.CustomRouteRequest) error {
					logger := log.WithContext(ctx)
					namespace := req.ResourceIdentifier.Namespace

					// Register check types for the namespace
					err := ctr.RegisterCheckTypesInNamespace(ctx, logger, namespace)
					if err != nil {
						logger.Error("Failed to register check types", "namespace", namespace, "error", err)
						metrics.CheckRegistrationTotal.WithLabelValues("error").Inc()
						w.WriteHeader(http.StatusInternalServerError)
						_ = json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
						return err
					}

					metrics.CheckRegistrationTotal.WithLabelValues("success").Inc()
					// Return typed response matching the manifest
					return json.NewEncoder(w).Encode(advisorv0alpha1.CreateRegisterResponse{
						TypeMeta: metav1.TypeMeta{
							APIVersion: fmt.Sprintf("%s/%s", advisorv0alpha1.APIGroup, advisorv0alpha1.APIVersion),
						},
						CreateRegisterBody: advisorv0alpha1.CreateRegisterBody{
							Message: "Check types registered successfully",
						},
					})
				},
				{
					Namespaced: true,
					Path:       "translations",
					Method:     "GET",
				}: func(ctx context.Context, w app.CustomRouteResponseWriter, req *app.CustomRouteRequest) error {
					logger := log.WithContext(ctx)
					lang := req.URL.Query().Get("lang")
					if lang == "" {
						lang = "en-US"
					}
					trans, err := translations.Get(lang)
					if err != nil {
						logger.Error("Failed to load translations", "lang", lang, "error", err)
						// A bad locale is the caller's fault; anything else (e.g. a
						// malformed embedded translation file) is ours.
						status := http.StatusInternalServerError
						if errors.Is(err, translations.ErrInvalidLocale) {
							status = http.StatusBadRequest
						}
						w.Header().Set("Content-Type", "application/json")
						w.WriteHeader(status)
						_ = json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
						return err
					}
					w.Header().Set("Content-Type", "application/json")
					return json.NewEncoder(w).Encode(advisorv0alpha1.GetTranslationsResponse{
						TypeMeta: metav1.TypeMeta{
							APIVersion: fmt.Sprintf("%s/%s", advisorv0alpha1.APIGroup, advisorv0alpha1.APIVersion),
						},
						GetTranslationsBody: advisorv0alpha1.GetTranslationsBody{
							Translations: trans,
						},
					})
				},
			},
		},
	}

	a, err := simple.NewApp(simpleConfig)
	if err != nil {
		return nil, err
	}

	err = a.ValidateManifest(cfg.ManifestData)
	if err != nil {
		return nil, err
	}

	// Save check types as resources
	a.AddRunnable(ctr)

	// Start scheduler
	a.AddRunnable(csch)

	return a, nil
}

func GetKinds() map[schema.GroupVersion][]resource.Kind {
	gv := schema.GroupVersion{
		// Group and version are the same for all checks
		Group:   advisorv0alpha1.CheckKind().Group(),
		Version: advisorv0alpha1.CheckKind().Version(),
	}
	return map[schema.GroupVersion][]resource.Kind{
		gv: {
			advisorv0alpha1.CheckKind(),
			advisorv0alpha1.CheckTypeKind(),
		},
	}
}

func ProvideAppInstaller(
	authorizer authorizer.Authorizer,
	checkRegistry checkregistry.CheckService,
	cfg *setting.Cfg,
	orgService org.Service,
	registerer prometheus.Registerer,
) (*AdvisorAppInstaller, error) {
	metrics.MustRegister(registerer)
	provider := simple.NewAppProvider(advisorapi.LocalManifest(), nil, New)
	pluginConfig := cfg.PluginSettings["grafana-advisor-app"]
	specificConfig := checkregistry.AdvisorAppConfig{
		CheckRegistry: checkRegistry,
		PluginConfig:  pluginConfig,
		StackID:       cfg.StackID,
		OrgService:    orgService,
	}
	appCfg := app.Config{
		KubeConfig:     rest.Config{},
		ManifestData:   *advisorapi.LocalManifest().ManifestData,
		SpecificConfig: specificConfig,
	}

	defaultInstaller, err := appsdkapiserver.NewDefaultAppInstaller(provider, appCfg, advisorapi.NewGoTypeAssociator())
	if err != nil {
		return nil, err
	}

	installer := &AdvisorAppInstaller{
		AppInstaller: defaultInstaller,
		authorizer:   authorizer,
	}

	return installer, nil
}

type AdvisorAppInstaller struct {
	appsdkapiserver.AppInstaller
	authorizer authorizer.Authorizer
}

func (a *AdvisorAppInstaller) GetAuthorizer() authorizer.Authorizer {
	return a.authorizer
}
