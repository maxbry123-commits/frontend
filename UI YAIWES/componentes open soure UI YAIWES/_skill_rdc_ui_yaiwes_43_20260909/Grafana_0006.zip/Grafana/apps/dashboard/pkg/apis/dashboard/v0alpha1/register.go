package v0alpha1

import (
	"fmt"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/grafana/grafana/pkg/apimachinery/utils"
)

const (
	GROUP      = "dashboard.grafana.app"
	VERSION    = "v0alpha1"
	APIVERSION = GROUP + "/" + VERSION

	// Resource constants
	DASHBOARD_RESOURCE     = "dashboards"
	LIBRARY_PANEL_RESOURCE = "librarypanels"
	SNAPSHOT_RESOURCE      = "snapshots"
)

var DashboardResourceInfo = utils.NewResourceInfo(GROUP, VERSION,
	"dashboards", "dashboard", "Dashboard",
	func() runtime.Object { return &Dashboard{} },
	func() runtime.Object { return &DashboardList{} },
	utils.TableColumns{
		Definition: []metav1.TableColumnDefinition{
			{Name: "Name", Type: "string", Format: "name"},
			{Name: "Title", Type: "string", Description: "The dashboard name"},
			{Name: "Tags", Type: "array", Format: "string", Description: "Dashboard tags"},
			{Name: "Created At", Type: "date"},
		},
		Reader: func(obj any) ([]any, error) {
			dash, ok := obj.(*Dashboard)
			if !ok || dash == nil {
				return nil, fmt.Errorf("expected dashboard")
			}
			tags, _, _ := unstructured.NestedStringSlice(dash.Spec.Object, "tags")
			return []any{
				dash.Name,
				dash.Spec.GetNestedString("title"),
				tags,
				dash.CreationTimestamp.UTC().Format(time.RFC3339),
			}, nil
		},
	},
)

var LibraryPanelResourceInfo = utils.NewResourceInfo(GROUP, VERSION,
	"librarypanels", "librarypanel", "LibraryPanel",
	func() runtime.Object { return &LibraryPanel{} },
	func() runtime.Object { return &LibraryPanelList{} },
	utils.TableColumns{
		Definition: []metav1.TableColumnDefinition{
			{Name: "Name", Type: "string", Format: "name"},
			{Name: "Title", Type: "string", Description: "The dashboard name"},
			{Name: "Type", Type: "string", Description: "the panel type"},
			{Name: "Created At", Type: "date"},
		},
		Reader: func(obj any) ([]interface{}, error) {
			dash, ok := obj.(*LibraryPanel)
			if ok {
				if dash != nil {
					return []interface{}{
						dash.Name,
						dash.Spec.Title,
						dash.Spec.Type,
						dash.CreationTimestamp.UTC().Format(time.RFC3339),
					}, nil
				}
			}
			return nil, fmt.Errorf("expected library panel")
		},
	},
)

var SnapshotResourceInfo = utils.NewResourceInfo(GROUP, VERSION,
	"snapshots", "snapshot", "Snapshot",
	func() runtime.Object { return &Snapshot{} },
	func() runtime.Object { return &SnapshotList{} },
	utils.TableColumns{
		Definition: []metav1.TableColumnDefinition{
			{Name: "Name", Type: "string", Format: "name"},
			{Name: "Title", Type: "string", Format: "string", Description: "The snapshot name"},
			{Name: "Created At", Type: "date"},
		},
		Reader: func(obj any) ([]interface{}, error) {
			m, ok := obj.(*Snapshot)
			if ok {
				return []interface{}{
					m.Name,
					m.Spec.Title,
					m.CreationTimestamp.UTC().Format(time.RFC3339),
				}, nil
			}
			return nil, fmt.Errorf("expected snapshot")
		},
	}, // default table converter
)

var (
	SchemeBuilder      runtime.SchemeBuilder
	localSchemeBuilder = &SchemeBuilder
	AddToScheme        = localSchemeBuilder.AddToScheme
	schemeGroupVersion = schema.GroupVersion{Group: GROUP, Version: VERSION}
)

func init() {
	localSchemeBuilder.Register(addKnownTypes, addDefaultingFuncs)
}

// Adds the list of known types to the given scheme.
func addKnownTypes(scheme *runtime.Scheme) error {
	scheme.AddKnownTypes(schemeGroupVersion,
		&Dashboard{},
		&DashboardList{},
		&DashboardWithAccessInfo{},
		&LibraryPanel{},
		&LibraryPanelList{},
		&Snapshot{},
		&SnapshotList{},
		&DashboardSnapshotWithDeleteKey{},
		&metav1.PartialObjectMetadata{},
		&metav1.PartialObjectMetadataList{},
		&metav1.Table{},
		&SearchResults{},
		&SortableFields{},
	)
	metav1.AddToGroupVersion(scheme, schemeGroupVersion)
	return nil
}

func addDefaultingFuncs(scheme *runtime.Scheme) error {
	return RegisterDefaults(scheme)
}
