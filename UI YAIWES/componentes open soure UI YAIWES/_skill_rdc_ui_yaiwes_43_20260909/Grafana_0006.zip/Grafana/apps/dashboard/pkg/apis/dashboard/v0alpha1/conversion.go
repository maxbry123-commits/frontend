package v0alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func (d *Dashboard) GetStoredVersion() string {
	if d.Status.Conversion != nil && d.Status.Conversion.StoredVersion != nil {
		return *d.Status.Conversion.StoredVersion
	}
	return ""
}

func (d *Dashboard) GetVersion() string {
	return VERSION
}

func (d *Dashboard) GetAPIVersion() string {
	return APIVERSION
}

func (d *Dashboard) SetConversionStatus(storedVersion string, failed bool, errMsg *string, source interface{}) {
	d.Status.Conversion = &DashboardConversionStatus{
		StoredVersion: new(storedVersion),
		Failed:        failed,
		Error:         errMsg,
		Source:        source,
	}
}

func (d *Dashboard) GetObjectMeta() interface{} {
	return d.ObjectMeta
}

func (d *Dashboard) SetObjectMeta(meta interface{}) {
	d.ObjectMeta = meta.(metav1.ObjectMeta)
}

func (d *Dashboard) GetKind() string {
	return d.Kind
}

func (d *Dashboard) SetKind(kind string) {
	d.Kind = kind
}

func (d *Dashboard) SetAPIVersion(version string) {
	d.APIVersion = version
}

func (d *Dashboard) EnsureDefaultSpec() {
	// v0alpha1 doesn't require default spec setup
}
