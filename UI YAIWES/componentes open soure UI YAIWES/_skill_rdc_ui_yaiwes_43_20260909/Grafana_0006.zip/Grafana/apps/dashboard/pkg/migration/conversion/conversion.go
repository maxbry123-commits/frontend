package conversion

import (
	"fmt"
	"strings"

	"k8s.io/apimachinery/pkg/conversion"
	"k8s.io/apimachinery/pkg/runtime"

	dashv0 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v0alpha1"
	dashv1 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v1"
	dashv1beta1 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v1beta1"
	dashv2 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v2"
	dashv2alpha1 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v2alpha1"
	dashv2beta1 "github.com/grafana/grafana/apps/dashboard/pkg/apis/dashboard/v2beta1"
	"github.com/grafana/grafana/apps/dashboard/pkg/migration/schemaversion"
)

// DashboardConversion provides methods for managing conversion consistently among dashboard conversions.
type DashboardConversion interface {
	// GetStoredVersion returns the stored version from status.conversion.storedVersion,
	// or empty string if not set.
	GetStoredVersion() string
	// GetVersion returns the short version string (e.g., "v2beta1").
	// Used for storedVersion in conversion status.
	GetVersion() string
	// GetAPIVersion returns the full API version (e.g., "dashboard.grafana.app/v2beta1").
	// Used for the apiVersion field on the dashboard TypeMeta.
	GetAPIVersion() string
	// SetConversionStatus sets the conversion status on the dashboard.
	SetConversionStatus(storedVersion string, failed bool, errMsg *string, source interface{})
	// GetObjectMeta returns the ObjectMeta of the dashboard for copying metadata.
	GetObjectMeta() interface{}
	// SetObjectMeta sets the ObjectMeta on the dashboard.
	SetObjectMeta(meta interface{})
	// GetKind returns the Kind of the dashboard.
	GetKind() string
	// SetKind sets the Kind on the dashboard.
	SetKind(kind string)
	// SetAPIVersion sets the APIVersion on the dashboard.
	SetAPIVersion(version string)
	// EnsureDefaultSpec ensures the dashboard spec has default/valid values.
	// This is called on error to ensure the output is in a valid state for JSON marshaling.
	EnsureDefaultSpec()
}

func getStoredVersion(in DashboardConversion) string {
	if sv := in.GetStoredVersion(); sv != "" {
		return sv
	}
	return in.GetVersion()
}

func setConversionStatus(in DashboardConversion, out DashboardConversion, err error, source interface{}) {
	storedVersion := getStoredVersion(in)
	var errMsg *string
	if err != nil {
		errMsg = new(err.Error())
	}
	out.SetConversionStatus(storedVersion, err != nil, errMsg, source)
}

// setMetadata copies ObjectMeta and Kind from input to output, and sets output's APIVersion.
func setMetadata(in, out DashboardConversion) {
	out.SetObjectMeta(in.GetObjectMeta())
	out.SetAPIVersion(out.GetAPIVersion())
	out.SetKind(in.GetKind())
}

// normalizeConversion wraps a conversion function with both metrics and status handling.
// It ensures:
// - Conversion status is always set (on success and failure)
// - Metadata (ObjectMeta, APIVersion, Kind) is always set
// - Default spec is ensured on error (to prevent JSON marshaling errors)
// - Metrics are tracked
func normalizeConversion(
	sourceVersion, targetVersion string,
	conversionFunc func(a, b interface{}, scope conversion.Scope) error,
) func(a, b interface{}, scope conversion.Scope) error {
	return withConversionMetrics(sourceVersion, targetVersion, func(a, b interface{}, scope conversion.Scope) error {
		inConv := a.(DashboardConversion)
		outConv := b.(DashboardConversion)

		err := conversionFunc(a, b, scope)

		setMetadata(inConv, outConv)

		if err != nil {
			outConv.EnsureDefaultSpec()
		}

		setConversionStatus(inConv, outConv, err, nil)
		return err
	})
}

func RegisterConversions(s *runtime.Scheme, dsIndexProvider schemaversion.DataSourceIndexProvider, leIndexProvider schemaversion.LibraryElementIndexProvider) error {
	// v0 conversions
	if err := s.AddConversionFunc((*dashv0.Dashboard)(nil), (*dashv1.Dashboard)(nil),
		normalizeConversion(dashv0.APIVERSION, dashv1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V0_to_V1(a.(*dashv0.Dashboard), b.(*dashv1.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv0.Dashboard)(nil), (*dashv2alpha1.Dashboard)(nil),
		normalizeConversion(dashv0.APIVERSION, dashv2alpha1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V0_to_V2alpha1(a.(*dashv0.Dashboard), b.(*dashv2alpha1.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv0.Dashboard)(nil), (*dashv2beta1.Dashboard)(nil),
		normalizeConversion(dashv0.APIVERSION, dashv2beta1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V0_to_V2beta1(a.(*dashv0.Dashboard), b.(*dashv2beta1.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv0.Dashboard)(nil), (*dashv2.Dashboard)(nil),
		normalizeConversion(dashv0.APIVERSION, dashv2.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V0_to_V2(a.(*dashv0.Dashboard), b.(*dashv2.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}

	// v1 conversions
	//
	// v1beta1 is a thin wrapper around v1 (type aliases, identical schema). Both versions map to
	// the same Go type (*dashv1.Dashboard), so a single AddConversionFunc registration covers
	// requests for either API version.
	if err := s.AddConversionFunc((*dashv1.Dashboard)(nil), (*dashv0.Dashboard)(nil),
		normalizeConversion(dashv1.APIVERSION, dashv0.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V1_to_V0(a.(*dashv1.Dashboard), b.(*dashv0.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv1.Dashboard)(nil), (*dashv2alpha1.Dashboard)(nil),
		normalizeConversion(dashv1.APIVERSION, dashv2alpha1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V1_to_V2alpha1(a.(*dashv1.Dashboard), b.(*dashv2alpha1.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv1.Dashboard)(nil), (*dashv2beta1.Dashboard)(nil),
		normalizeConversion(dashv1.APIVERSION, dashv2beta1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V1_to_V2beta1(a.(*dashv1.Dashboard), b.(*dashv2beta1.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv1.Dashboard)(nil), (*dashv2.Dashboard)(nil),
		normalizeConversion(dashv1.APIVERSION, dashv2.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V1beta1_to_V2(a.(*dashv1.Dashboard), b.(*dashv2.Dashboard), scope, dsIndexProvider, leIndexProvider)
		})); err != nil {
		return err
	}

	// v2alpha1 conversions
	if err := s.AddConversionFunc((*dashv2alpha1.Dashboard)(nil), (*dashv0.Dashboard)(nil),
		normalizeConversion(dashv2alpha1.APIVERSION, dashv0.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2alpha1_to_V0(a.(*dashv2alpha1.Dashboard), b.(*dashv0.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2alpha1.Dashboard)(nil), (*dashv1.Dashboard)(nil),
		normalizeConversion(dashv2alpha1.APIVERSION, dashv1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2alpha1_to_V1(a.(*dashv2alpha1.Dashboard), b.(*dashv1.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2alpha1.Dashboard)(nil), (*dashv2beta1.Dashboard)(nil),
		normalizeConversion(dashv2alpha1.APIVERSION, dashv2beta1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2alpha1_to_V2beta1(a.(*dashv2alpha1.Dashboard), b.(*dashv2beta1.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2alpha1.Dashboard)(nil), (*dashv2.Dashboard)(nil),
		normalizeConversion(dashv2alpha1.APIVERSION, dashv2.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2alpha1_to_V2(a.(*dashv2alpha1.Dashboard), b.(*dashv2.Dashboard), scope)
		})); err != nil {
		return err
	}

	// v2beta1 conversions
	if err := s.AddConversionFunc((*dashv2beta1.Dashboard)(nil), (*dashv0.Dashboard)(nil),
		normalizeConversion(dashv2beta1.APIVERSION, dashv0.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2beta1_to_V0(a.(*dashv2beta1.Dashboard), b.(*dashv0.Dashboard), scope, dsIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2beta1.Dashboard)(nil), (*dashv1.Dashboard)(nil),
		normalizeConversion(dashv2beta1.APIVERSION, dashv1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2beta1_to_V1(a.(*dashv2beta1.Dashboard), b.(*dashv1.Dashboard), scope, dsIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2beta1.Dashboard)(nil), (*dashv2alpha1.Dashboard)(nil),
		normalizeConversion(dashv2beta1.APIVERSION, dashv2alpha1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2beta1_to_V2alpha1(a.(*dashv2beta1.Dashboard), b.(*dashv2alpha1.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2beta1.Dashboard)(nil), (*dashv2.Dashboard)(nil),
		normalizeConversion(dashv2beta1.APIVERSION, dashv2.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2beta1_to_V2(a.(*dashv2beta1.Dashboard), b.(*dashv2.Dashboard), scope)
		})); err != nil {
		return err
	}

	// v2 conversions
	if err := s.AddConversionFunc((*dashv2.Dashboard)(nil), (*dashv0.Dashboard)(nil),
		normalizeConversion(dashv2.APIVERSION, dashv0.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2_to_V0(a.(*dashv2.Dashboard), b.(*dashv0.Dashboard), scope, dsIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2.Dashboard)(nil), (*dashv1.Dashboard)(nil),
		normalizeConversion(dashv2.APIVERSION, dashv1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2_to_V1beta1(a.(*dashv2.Dashboard), b.(*dashv1.Dashboard), scope, dsIndexProvider)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2.Dashboard)(nil), (*dashv2alpha1.Dashboard)(nil),
		normalizeConversion(dashv2.APIVERSION, dashv2alpha1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2_to_V2alpha1(a.(*dashv2.Dashboard), b.(*dashv2alpha1.Dashboard), scope)
		})); err != nil {
		return err
	}
	if err := s.AddConversionFunc((*dashv2.Dashboard)(nil), (*dashv2beta1.Dashboard)(nil),
		normalizeConversion(dashv2.APIVERSION, dashv2beta1.APIVERSION, func(a, b interface{}, scope conversion.Scope) error {
			return Convert_V2_to_V2beta1(a.(*dashv2.Dashboard), b.(*dashv2beta1.Dashboard), scope)
		})); err != nil {
		return err
	}

	return nil
}

func NewDashboardObject(version string) (runtime.Object, error) {
	idx := strings.Index(version, "/")
	if idx > 0 {
		if dashv0.GROUP != version[:idx] {
			return nil, fmt.Errorf("expected group: " + dashv0.GROUP)
		}
		version = version[idx+1:]
	}

	switch version {
	case dashv0.VERSION:
		return &dashv0.Dashboard{}, nil
	case dashv1beta1.VERSION:
		return &dashv1beta1.Dashboard{}, nil
	case dashv1.VERSION:
		return &dashv1.Dashboard{}, nil
	case dashv2alpha1.VERSION:
		return &dashv2alpha1.Dashboard{}, nil
	case dashv2beta1.VERSION:
		return &dashv2beta1.Dashboard{}, nil
	case dashv2.VERSION:
		return &dashv2.Dashboard{}, nil
	}
	return nil, fmt.Errorf("invalid version")
}

// Convert a dashboard from one version to another
func Convert(s *runtime.Scheme, src runtime.Object, version string) (runtime.Object, error) {
	out, err := NewDashboardObject(version)
	if err != nil {
		return nil, err
	}
	err = s.Convert(src, out, nil)
	return out, err
}
