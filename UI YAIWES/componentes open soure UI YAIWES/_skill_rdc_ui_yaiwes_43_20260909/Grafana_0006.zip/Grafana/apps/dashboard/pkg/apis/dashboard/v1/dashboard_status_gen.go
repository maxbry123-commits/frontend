// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v1

// ConversionStatus is the status of the conversion of the dashboard.
// +k8s:openapi-gen=true
type DashboardConversionStatus struct {
	// Whether from another version has failed.
	// If true, means that the dashboard is not valid,
	// and the caller should instead fetch the stored version.
	Failed bool `json:"failed"`
	// The error message from the conversion.
	// Empty if the conversion has not failed.
	Error *string `json:"error,omitempty"`
	// The version which was stored when the dashboard was created / updated.
	// Fetching this version should always succeed.
	StoredVersion *string `json:"storedVersion,omitempty"`
	// The original value map[string]any
	Source interface{} `json:"source,omitempty"`
}

// NewDashboardConversionStatus creates a new DashboardConversionStatus object.
func NewDashboardConversionStatus() *DashboardConversionStatus {
	return &DashboardConversionStatus{}
}

// OpenAPIModelName returns the OpenAPI model name for DashboardConversionStatus.
func (DashboardConversionStatus) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.dashboard.pkg.apis.dashboard.v1.DashboardConversionStatus"
}

// +k8s:openapi-gen=true
type DashboardStatus struct {
	// Optional conversion status.
	Conversion *DashboardConversionStatus `json:"conversion,omitempty"`
}

// NewDashboardStatus creates a new DashboardStatus object.
func NewDashboardStatus() *DashboardStatus {
	return &DashboardStatus{}
}

// OpenAPIModelName returns the OpenAPI model name for DashboardStatus.
func (DashboardStatus) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.dashboard.pkg.apis.dashboard.v1.DashboardStatus"
}
