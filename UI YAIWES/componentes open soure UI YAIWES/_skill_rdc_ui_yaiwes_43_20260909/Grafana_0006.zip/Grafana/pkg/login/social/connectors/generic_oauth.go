package connectors

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/mail"
	"slices"
	"strconv"

	"golang.org/x/oauth2"

	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/configprovider"
	"github.com/grafana/grafana/pkg/infra/log"
	"github.com/grafana/grafana/pkg/infra/remotecache"
	"github.com/grafana/grafana/pkg/login/social"
	"github.com/grafana/grafana/pkg/services/featuremgmt"
	"github.com/grafana/grafana/pkg/services/ssosettings"
	ssoModels "github.com/grafana/grafana/pkg/services/ssosettings/models"
	"github.com/grafana/grafana/pkg/services/ssosettings/validation"
	"github.com/grafana/grafana/pkg/util"
)

const (
	nameAttributePathKey    = "name_attribute_path"
	loginAttributePathKey   = "login_attribute_path"
	idTokenAttributeNameKey = "id_token_attribute_name" // #nosec G101 not a hardcoded credential
)

var ExtraGenericOAuthSettingKeys = map[string]ExtraKeyInfo{
	nameAttributePathKey:    {Type: String},
	loginAttributePathKey:   {Type: String},
	idTokenAttributeNameKey: {Type: String},
	teamIdsKey:              {Type: String},
	allowedOrganizationsKey: {Type: String},
}

var _ social.SocialConnector = (*SocialGenericOAuth)(nil)
var _ ssosettings.Reloadable = (*SocialGenericOAuth)(nil)

type SocialGenericOAuth struct {
	*SocialBase
	allowedOrganizations []string
	teamsUrl             string
	emailAttributeName   string
	emailAttributePath   string
	loginAttributePath   string
	nameAttributePath    string
	groupsAttributePath  string
	idTokenAttributeName string
	teamIdsAttributePath string
	teamIds              []string
}

func NewGenericOAuthProvider(ctx context.Context, info *social.OAuthInfo, cfgProvider configprovider.ConfigProvider, orgRoleMapper *OrgRoleMapper, ssoSettings ssosettings.Service, features featuremgmt.FeatureToggles, cache remotecache.CacheStorage) (*SocialGenericOAuth, error) {
	s, err := newSocialBaseWithCache(social.GenericOAuthProviderName, ctx, orgRoleMapper, info, features, cfgProvider, cache)
	if err != nil {
		return nil, err
	}

	teamIds, err := util.SplitStringWithError(info.Extra[teamIdsKey])
	if err != nil {
		s.log.Error("Invalid auth configuration setting", "config", teamIdsKey, "provider", social.GenericOAuthProviderName, "error", err)
	}

	allowedOrganizations, err := util.SplitStringWithError(info.Extra[allowedOrganizationsKey])
	if err != nil {
		s.log.Error("Invalid auth configuration setting", "config", allowedOrganizationsKey, "provider", social.GenericOAuthProviderName, "error", err)
	}

	provider := &SocialGenericOAuth{
		SocialBase:           s,
		teamsUrl:             info.TeamsUrl,
		emailAttributeName:   info.EmailAttributeName,
		emailAttributePath:   info.EmailAttributePath,
		nameAttributePath:    info.Extra[nameAttributePathKey],
		groupsAttributePath:  info.GroupsAttributePath,
		loginAttributePath:   info.Extra[loginAttributePathKey],
		idTokenAttributeName: info.Extra[idTokenAttributeNameKey],
		teamIdsAttributePath: info.TeamIdsAttributePath,
		teamIds:              teamIds,
		allowedOrganizations: allowedOrganizations,
	}

	if ssoSettings != nil {
		ssoSettings.RegisterReloadable(social.GenericOAuthProviderName, provider)
	}

	return provider, nil
}

func (s *SocialGenericOAuth) Validate(ctx context.Context, newSettings ssoModels.SSOSettings, oldSettings ssoModels.SSOSettings, requester identity.Requester) error {
	info, err := CreateOAuthInfoFromKeyValues(newSettings.Settings)
	if err != nil {
		return ssosettings.ErrInvalidSettings.Errorf("SSO settings map cannot be converted to OAuthInfo: %v", err)
	}

	oldInfo, err := CreateOAuthInfoFromKeyValues(oldSettings.Settings)
	if err != nil {
		oldInfo = &social.OAuthInfo{}
	}

	err = validateInfo(info, oldInfo, requester)
	if err != nil {
		return err
	}

	err = validation.Validate(info, requester,
		validation.UrlValidator(info.AuthUrl, "Auth URL"),
		validation.UrlValidator(info.TokenUrl, "Token URL"),
		validateTeamsUrlWhenNotEmpty,
		validation.ValidateIDTokenValidator)

	if err != nil {
		return err
	}

	teamIds := util.SplitString(info.Extra[teamIdsKey])
	if len(teamIds) > 0 && (info.TeamIdsAttributePath == "" || info.TeamsUrl == "") {
		return ssosettings.ErrInvalidOAuthConfig("If Team Ids are configured then Team Ids attribute path and Teams URL must be configured.")
	}

	if len(info.AllowedGroups) > 0 && info.GroupsAttributePath == "" {
		return ssosettings.ErrInvalidOAuthConfig("If Allowed groups is configured then Groups attribute path must be configured.")
	}

	return nil
}

func validateTeamsUrlWhenNotEmpty(info *social.OAuthInfo, requester identity.Requester) error {
	if info.TeamsUrl == "" {
		return nil
	}
	return validation.UrlValidator(info.TeamsUrl, "Teams URL")(info, requester)
}

func (s *SocialGenericOAuth) Reload(ctx context.Context, settings ssoModels.SSOSettings) error {
	newInfo, err := CreateOAuthInfoFromKeyValuesWithLogging(s.log, social.GenericOAuthProviderName, settings.Settings)
	if err != nil {
		return ssosettings.ErrInvalidSettings.Errorf("SSO settings map cannot be converted to OAuthInfo: %v", err)
	}

	s.reloadMutex.Lock()
	defer s.reloadMutex.Unlock()

	if err := s.updateInfo(ctx, social.GenericOAuthProviderName, newInfo); err != nil {
		return err
	}

	teamIds, err := util.SplitStringWithError(newInfo.Extra[teamIdsKey])
	if err != nil {
		s.log.Error("Invalid auth configuration setting", "config", teamIdsKey, "provider", social.GenericOAuthProviderName, "error", err)
	}
	allowedOrganizations, err := util.SplitStringWithError(newInfo.Extra[allowedOrganizationsKey])
	if err != nil {
		s.log.Error("Invalid auth configuration setting", "config", allowedOrganizationsKey, "provider", social.GenericOAuthProviderName, "error", err)
	}

	s.teamsUrl = newInfo.TeamsUrl
	s.emailAttributeName = newInfo.EmailAttributeName
	s.emailAttributePath = newInfo.EmailAttributePath
	s.nameAttributePath = newInfo.Extra[nameAttributePathKey]
	s.groupsAttributePath = newInfo.GroupsAttributePath
	s.loginAttributePath = newInfo.Extra[loginAttributePathKey]
	s.idTokenAttributeName = newInfo.Extra[idTokenAttributeNameKey]
	s.teamIdsAttributePath = newInfo.TeamIdsAttributePath
	s.teamIds = teamIds
	s.allowedOrganizations = allowedOrganizations

	return nil
}

func (s *SocialGenericOAuth) isTeamMember(ctx context.Context, client *http.Client) bool {
	if len(s.teamIds) == 0 {
		return true
	}

	teamMemberships, err := s.fetchTeamMemberships(ctx, client)
	if err != nil {
		return false
	}

	for _, teamId := range s.teamIds {
		if slices.Contains(teamMemberships, teamId) {
			return true
		}
	}

	return false
}

func (s *SocialGenericOAuth) isOrganizationMember(ctx context.Context, client *http.Client) bool {
	if len(s.allowedOrganizations) == 0 {
		return true
	}

	organizations, ok := s.fetchOrganizations(ctx, client)
	if !ok {
		return false
	}

	for _, allowedOrganization := range s.allowedOrganizations {
		if slices.Contains(organizations, allowedOrganization) {
			return true
		}
	}

	return false
}

type UserInfoJson struct {
	Sub         string              `json:"sub"`
	Name        string              `json:"name"`
	DisplayName string              `json:"display_name"`
	Login       string              `json:"login"`
	Username    string              `json:"username"`
	Email       string              `json:"email"`
	Upn         string              `json:"upn"`
	Attributes  map[string][]string `json:"attributes"`
	rawJSON     []byte
	source      string
}

func (info *UserInfoJson) String() string {
	return fmt.Sprintf(
		"Name: %s, Displayname: %s, Login: %s, Username: %s, Email: %s, Upn: %s, Attributes: %v",
		info.Name, info.DisplayName, info.Login, info.Username, info.Email, info.Upn, info.Attributes)
}

func (s *SocialGenericOAuth) UserInfo(ctx context.Context, client *http.Client, token *oauth2.Token) (*social.BasicUserInfo, error) {
	logger := s.log.FromContext(ctx)
	s.reloadMutex.RLock()
	defer s.reloadMutex.RUnlock()

	logger.Debug("Getting user info")

	// 1. Collect user info data from various sources
	dataSources, err := s.collectUserInfoData(ctx, client, token, logger)
	if err != nil {
		return nil, err
	}

	// 2. Build user info from collected data
	userInfo, externalOrgs, err := s.buildUserInfo(logger, dataSources)
	if err != nil {
		return nil, err
	}

	// 3. Post-process user info
	err = s.postProcessUserInfo(ctx, client, userInfo, externalOrgs)
	if err != nil {
		return nil, err
	}

	// 4. Validate user access
	err = s.validateUserAccess(ctx, client, userInfo)
	if err != nil {
		return nil, err
	}

	logger.Debug("User info result", "result", userInfo)
	return userInfo, nil
}

// collectUserInfoData gathers user information from ID token, API, and access token
func (s *SocialGenericOAuth) collectUserInfoData(ctx context.Context, client *http.Client, token *oauth2.Token, logger log.Logger) ([]*UserInfoJson, error) {
	dataSources := make([]*UserInfoJson, 0, 3)

	idTokenData, err := s.extractFromIDToken(ctx, token)
	if err != nil {
		return nil, err
	}
	if idTokenData != nil {
		dataSources = append(dataSources, idTokenData)
	}
	if apiData := s.extractFromAPI(ctx, client); apiData != nil {
		dataSources = append(dataSources, apiData)
	}
	if accessTokenData := s.extractFromAccessToken(logger, token); accessTokenData != nil {
		dataSources = append(dataSources, accessTokenData)
	}

	return dataSources, nil
}

// buildUserInfo constructs BasicUserInfo from collected data sources
func (s *SocialGenericOAuth) buildUserInfo(logger log.Logger, dataSources []*UserInfoJson) (*social.BasicUserInfo, []string, error) {
	userInfo := &social.BasicUserInfo{}
	var externalOrgs []string

	for _, data := range dataSources {
		logger.Debug("Processing external user info", "source", data.source, "data", data)

		s.extractBasicUserFields(logger, userInfo, data)

		if err := s.extractRoleAndOrgs(logger, userInfo, &externalOrgs, data); err != nil {
			return nil, nil, err
		}

		s.extractUserGroups(logger, userInfo, data)
	}

	return userInfo, externalOrgs, nil
}

// extractBasicUserFields extracts basic user fields (ID, Name, Login, Email) from data
func (s *SocialGenericOAuth) extractBasicUserFields(logger log.Logger, userInfo *social.BasicUserInfo, data *UserInfoJson) {
	if userInfo.Id == "" {
		userInfo.Id = data.Sub
	}

	if userInfo.Name == "" {
		userInfo.Name = s.extractUserName(logger, data)
	}

	if userInfo.Login == "" {
		userInfo.Login = s.extractLogin(logger, data)
	}

	if userInfo.Email == "" {
		userInfo.Email = s.extractEmail(logger, data)
		if userInfo.Email != "" {
			logger.Debug("Set user info email from extracted email", "email", userInfo.Email)
		}
	}
}

// extractRoleAndOrgs extracts role and organization information from data
func (s *SocialGenericOAuth) extractRoleAndOrgs(logger log.Logger, userInfo *social.BasicUserInfo, externalOrgs *[]string, data *UserInfoJson) error {
	if userInfo.Role == "" && !s.info.SkipOrgRoleSync {
		role, grafanaAdmin, err := s.extractRoleAndAdminOptional(data.rawJSON, []string{})
		if err != nil {
			logger.Warn("Failed to extract role", "err", err)
		} else {
			userInfo.Role = role
			if s.info.AllowAssignGrafanaAdmin {
				userInfo.IsGrafanaAdmin = &grafanaAdmin
			}
		}
	}

	if len(*externalOrgs) == 0 && !s.info.SkipOrgRoleSync {
		orgs, err := s.extractOrgs(data.rawJSON)
		if err != nil {
			logger.Warn("Failed to extract orgs", "err", err)
			return err
		}
		*externalOrgs = orgs
	}

	return nil
}

// extractUserGroups extracts group information from data
func (s *SocialGenericOAuth) extractUserGroups(logger log.Logger, userInfo *social.BasicUserInfo, data *UserInfoJson) {
	if len(userInfo.Groups) == 0 {
		groups, err := s.extractGroups(data)
		if err != nil {
			logger.Warn("Failed to extract groups", "err", err)
		} else if len(groups) > 0 {
			logger.Debug("Setting user info groups from extracted groups")
			userInfo.Groups = groups
		}
	}
}

// postProcessUserInfo handles post-processing of user info (org roles, private email, etc.)
func (s *SocialGenericOAuth) postProcessUserInfo(ctx context.Context, client *http.Client, userInfo *social.BasicUserInfo, externalOrgs []string) error {
	logger := s.log.FromContext(ctx)
	if !s.info.SkipOrgRoleSync {
		orgRoles, err := s.orgRoleMapper.MapOrgRolesContext(ctx, s.orgMappingCfg, externalOrgs, userInfo.Role)
		if err != nil {
			return fmt.Errorf("map organization roles: %w", err)
		}
		userInfo.OrgRoles = orgRoles
		if s.info.RoleAttributeStrict && len(userInfo.OrgRoles) == 0 {
			return errRoleAttributeStrictViolation.Errorf("could not evaluate any valid roles using IdP provided data")
		}
	}

	if s.info.AllowAssignGrafanaAdmin && s.info.SkipOrgRoleSync {
		logger.Debug("AllowAssignGrafanaAdmin and skipOrgRoleSync are both set, Grafana Admin role will not be synced, consider setting one or the other")
	}

	if s.canFetchPrivateEmail(userInfo) {
		email, err := s.fetchPrivateEmail(ctx, client)
		if err != nil {
			return err
		}
		userInfo.Email = email
		logger.Debug("Setting email from fetched private email", "email", userInfo.Email)
	}

	if userInfo.Login == "" {
		logger.Debug("Defaulting to using email for user info login", "email", userInfo.Email)
		userInfo.Login = userInfo.Email
	}

	return nil
}

// validateUserAccess validates user access based on team, organization, and group membership
func (s *SocialGenericOAuth) validateUserAccess(ctx context.Context, client *http.Client, userInfo *social.BasicUserInfo) error {
	if !s.isTeamMember(ctx, client) {
		return &SocialError{"User not a member of one of the required teams"}
	}

	if !s.isOrganizationMember(ctx, client) {
		return &SocialError{"User not a member of one of the required organizations"}
	}

	if !s.isGroupMember(userInfo.Groups) {
		return errMissingGroupMembership
	}

	return nil
}

func (s *SocialGenericOAuth) canFetchPrivateEmail(userinfo *social.BasicUserInfo) bool {
	return s.info.ApiUrl != "" && userinfo.Email == ""
}

func (s *SocialGenericOAuth) extractFromIDToken(ctx context.Context, token *oauth2.Token) (*UserInfoJson, error) {
	logger := s.log.FromContext(ctx)
	logger.Debug("Extracting user info from OAuth ID token")

	idTokenAttribute := "id_token"
	if s.idTokenAttributeName != "" {
		idTokenAttribute = s.idTokenAttributeName
		logger.Debug("Using custom id_token attribute name", "attribute_name", idTokenAttribute)
	}

	idToken := token.Extra(idTokenAttribute)
	if idToken == nil {
		logger.Debug("No id_token found", "token", fmt.Sprintf("%+v", token))
		return nil, nil
	}

	idTokenString, ok := idToken.(string)
	if !ok {
		logger.Warn("ID token is not a string", "token", fmt.Sprintf("%+v", token))
		return nil, nil
	}

	var rawJSON []byte
	var err error

	// If JWT validation is enabled, validate the signature
	if s.info.ValidateIDToken && s.info.JwkSetURL != "" {
		// create a dedicated client for the JWKS retrieval, without a token source
		rawJSON, err = s.validateIDTokenSignature(ctx, http.DefaultClient, idTokenString, s.info.JwkSetURL)
		if err != nil {
			logger.Warn("Error validating ID token signature", "error", err)
			return nil, err
		}
	} else {
		// Otherwise, just extract the payload without signature validation
		rawJSON, err = s.retrieveRawJWTPayload(idTokenString)
		if err != nil {
			logger.Warn("Error retrieving id_token payload", "error", err, "token", fmt.Sprintf("%+v", token))
			return nil, nil
		}
	}

	return s.parseUserInfoFromJSON(logger, rawJSON, "id_token"), nil
}

func (s *SocialGenericOAuth) extractFromAccessToken(logger log.Logger, token *oauth2.Token) *UserInfoJson {
	logger.Debug("Extracting user info from OAuth access token")

	accessToken := token.AccessToken
	if accessToken == "" {
		logger.Debug("No access token found")
		return nil
	}

	rawJSON, err := s.retrieveRawJWTPayload(accessToken)
	if err != nil {
		logger.Warn("Error retrieving access token payload", "error", err)
		return nil
	}

	return s.parseUserInfoFromJSON(logger, rawJSON, "access_token")
}

// parseUserInfoFromJSON is a helper method to parse UserInfoJson from raw JSON and source
func (s *SocialGenericOAuth) parseUserInfoFromJSON(logger log.Logger, rawJSON []byte, source string) *UserInfoJson {
	var data UserInfoJson
	if err := json.Unmarshal(rawJSON, &data); err != nil {
		logger.Error("Error decoding user info JSON", "raw_json", string(rawJSON), "error", err, "source", source)
		return nil
	}

	data.rawJSON = rawJSON
	data.source = source
	logger.Debug("Parsed user info from JSON", "raw_json", string(rawJSON), "data", data.String(), "source", source)
	return &data
}

func (s *SocialGenericOAuth) extractFromAPI(ctx context.Context, client *http.Client) *UserInfoJson {
	logger := s.log.FromContext(ctx)
	logger.Debug("Getting user info from API")
	if s.info.ApiUrl == "" {
		logger.Debug("No api url configured")
		return nil
	}

	rawUserInfoResponse, err := s.httpGet(ctx, client, s.info.ApiUrl)
	if err != nil {
		logger.Debug("Error getting user info from API", "url", s.info.ApiUrl, "error", err)
		return nil
	}

	return s.parseUserInfoFromJSON(logger, rawUserInfoResponse.Body, "API")
}

func (s *SocialGenericOAuth) extractEmail(logger log.Logger, data *UserInfoJson) string {
	if data.Email != "" {
		return data.Email
	}

	if s.emailAttributePath != "" {
		email, err := util.SearchJSONForStringAttr(s.emailAttributePath, data.rawJSON)
		if err != nil {
			logger.Error("Failed to search JSON for attribute", "error", err)
		} else if email != "" {
			return email
		}
	}

	emails, ok := data.Attributes[s.emailAttributeName]
	if ok && len(emails) != 0 {
		return emails[0]
	}

	if data.Upn != "" {
		emailAddr, emailErr := mail.ParseAddress(data.Upn)
		if emailErr == nil {
			return emailAddr.Address
		}
		logger.Debug("Failed to parse e-mail address", "error", emailErr.Error())
	}

	return ""
}

func (s *SocialGenericOAuth) extractLogin(logger log.Logger, data *UserInfoJson) string {
	if data.Login != "" {
		logger.Debug("Setting user info login from login field", "login", data.Login)
		return data.Login
	}

	if s.loginAttributePath != "" {
		logger.Debug("Searching for login among JSON", "loginAttributePath", s.loginAttributePath)
		login, err := util.SearchJSONForStringAttr(s.loginAttributePath, data.rawJSON)
		if err != nil {
			logger.Error("Failed to search JSON for login attribute", "error", err)
		}

		if login != "" {
			return login
		}
	}

	if data.Username != "" {
		logger.Debug("Setting user info login from username field", "username", data.Username)
		return data.Username
	}

	return ""
}

func (s *SocialGenericOAuth) extractUserName(logger log.Logger, data *UserInfoJson) string {
	if s.nameAttributePath != "" {
		name, err := util.SearchJSONForStringAttr(s.nameAttributePath, data.rawJSON)
		if err != nil {
			logger.Error("Failed to search JSON for attribute", "error", err)
		} else if name != "" {
			logger.Debug("Setting user info name from nameAttributePath", "nameAttributePath", s.nameAttributePath)
			return name
		}
	}

	if data.Name != "" {
		logger.Debug("Setting user info name from name field")
		return data.Name
	}

	if data.DisplayName != "" {
		logger.Debug("Setting user info name from display name field")
		return data.DisplayName
	}

	logger.Debug("Unable to find user info name")
	return ""
}

func (s *SocialGenericOAuth) extractGroups(data *UserInfoJson) ([]string, error) {
	if s.groupsAttributePath == "" {
		return []string{}, nil
	}

	return util.SearchJSONForStringSliceAttr(s.groupsAttributePath, data.rawJSON)
}

func (s *SocialGenericOAuth) fetchPrivateEmail(ctx context.Context, client *http.Client) (string, error) {
	logger := s.log.FromContext(ctx)
	type Record struct {
		Email       string `json:"email"`
		Primary     bool   `json:"primary"`
		IsPrimary   bool   `json:"is_primary"`
		Verified    bool   `json:"verified"`
		IsConfirmed bool   `json:"is_confirmed"`
	}

	response, err := s.httpGet(ctx, client, s.info.ApiUrl+"/emails")
	if err != nil {
		logger.Error("Error getting email address", "url", s.info.ApiUrl+"/emails", "error", err)
		return "", fmt.Errorf("%v: %w", "Error getting email address", err)
	}

	var records []Record

	err = json.Unmarshal(response.Body, &records)
	if err != nil {
		var data struct {
			Values []Record `json:"values"`
		}

		err = json.Unmarshal(response.Body, &data)
		if err != nil {
			logger.Error("Error decoding email addresses response", "raw_json", string(response.Body), "error", err)
			return "", fmt.Errorf("%v: %w", "Error decoding email addresses response", err)
		}

		records = data.Values
	}

	logger.Debug("Received email addresses", "emails", records)

	var email = ""
	for _, record := range records {
		if record.Primary || record.IsPrimary {
			email = record.Email
			break
		}
	}

	logger.Debug("Using email address", "email", email)

	return email, nil
}

func (s *SocialGenericOAuth) fetchTeamMemberships(ctx context.Context, client *http.Client) ([]string, error) {
	var err error
	var ids []string

	if s.teamsUrl == "" {
		ids, err = s.fetchTeamMembershipsFromDeprecatedTeamsUrl(ctx, client)
	} else {
		ids, err = s.fetchTeamMembershipsFromTeamsUrl(ctx, client)
	}

	if err == nil {
		s.log.FromContext(ctx).Debug("Received team memberships", "ids", ids)
	}

	return ids, err
}

func (s *SocialGenericOAuth) fetchTeamMembershipsFromDeprecatedTeamsUrl(ctx context.Context, client *http.Client) ([]string, error) {
	logger := s.log.FromContext(ctx)
	var ids []string

	type Record struct {
		Id int `json:"id"`
	}

	response, err := s.httpGet(ctx, client, s.info.ApiUrl+"/teams")
	if err != nil {
		logger.Error("Error getting team memberships", "url", s.info.ApiUrl+"/teams", "error", err)
		return []string{}, err
	}

	var records []Record

	err = json.Unmarshal(response.Body, &records)
	if err != nil {
		logger.Error("Error decoding team memberships response", "raw_json", string(response.Body), "error", err)
		return []string{}, err
	}

	ids = make([]string, len(records))
	for i, record := range records {
		ids[i] = strconv.Itoa(record.Id)
	}

	return ids, nil
}

func (s *SocialGenericOAuth) fetchTeamMembershipsFromTeamsUrl(ctx context.Context, client *http.Client) ([]string, error) {
	if s.teamIdsAttributePath == "" {
		return []string{}, nil
	}

	response, err := s.httpGet(ctx, client, s.teamsUrl)
	if err != nil {
		s.log.FromContext(ctx).Error("Error getting team memberships", "url", s.teamsUrl, "error", err)
		return nil, err
	}

	return util.SearchJSONForStringSliceAttr(s.teamIdsAttributePath, response.Body)
}

func (s *SocialGenericOAuth) fetchOrganizations(ctx context.Context, client *http.Client) ([]string, bool) {
	logger := s.log.FromContext(ctx)
	type Record struct {
		Login string `json:"login"`
	}

	response, err := s.httpGet(ctx, client, s.info.ApiUrl+"/orgs")
	if err != nil {
		logger.Error("Error getting organizations", "url", s.info.ApiUrl+"/orgs", "error", err)
		return nil, false
	}

	var records []Record

	err = json.Unmarshal(response.Body, &records)
	if err != nil {
		logger.Error("Error decoding organization response", "response", string(response.Body), "error", err)
		return nil, false
	}

	var logins = make([]string, len(records))
	for i, record := range records {
		logins[i] = record.Login
	}

	logger.Debug("Received organizations", "logins", logins)

	return logins, true
}

func (s *SocialGenericOAuth) SupportBundleContent(bf *bytes.Buffer) error {
	s.reloadMutex.RLock()
	defer s.reloadMutex.RUnlock()

	bf.WriteString("## GenericOAuth specific configuration\n\n")
	bf.WriteString("```ini\n")
	fmt.Fprintf(bf, "name_attribute_path = %s\n", s.nameAttributePath)
	fmt.Fprintf(bf, "login_attribute_path = %s\n", s.loginAttributePath)
	fmt.Fprintf(bf, "id_token_attribute_name = %s\n", s.idTokenAttributeName)
	fmt.Fprintf(bf, "team_ids_attribute_path = %s\n", s.teamIdsAttributePath)
	fmt.Fprintf(bf, "team_ids = %v\n", s.teamIds)
	fmt.Fprintf(bf, "allowed_organizations = %v\n", s.allowedOrganizations)
	fmt.Fprintf(bf, "validate_id_token = %v\n", s.info.ValidateIDToken)
	fmt.Fprintf(bf, "jwk_set_url = %s\n", s.info.JwkSetURL)
	bf.WriteString("```\n\n")

	return s.getBaseSupportBundleContent(bf)
}
