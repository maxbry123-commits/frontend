package preferences

import (
	"context"
	"fmt"
	"slices"

	k8serrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/apis/meta/internalversion"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/selection"
	requestK8s "k8s.io/apiserver/pkg/endpoints/request"
	"k8s.io/apiserver/pkg/registry/rest"

	authlib "github.com/grafana/authlib/types"
	preferences "github.com/grafana/grafana/apps/preferences/pkg/apis/preferences/v1"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	grafanarest "github.com/grafana/grafana/pkg/apiserver/rest"
	"github.com/grafana/grafana/pkg/registry/apis/preferences/utils"
	gapiutil "github.com/grafana/grafana/pkg/services/apiserver/utils"
)

// The maximum number of teams per user to use when listing preferences and for the merged endpoint. Teams beyond this limit
// will have their preferences ignored to keep the processing time bounded.
var PreferencesTeamLimit = 25

// preferencesStorage wraps a regular storage backend, replacing the default list behavior
// Rather than returning all preferences and filtering with the authz client (where there is not yet support for preferences)
// This converts the query into explicitly picking the preferences the caller should have access
type preferencesStorage struct {
	grafanarest.Storage
	gvk schema.GroupVersionKind
}

func (s *preferencesStorage) List(ctx context.Context, options *internalversion.ListOptions) (runtime.Object, error) {
	return s.ListPreferences(ctx, options)
}

// Update with upsert: an Update for an owner whose preferences don't
// exist yet creates them instead of returning 404. The update is attempted
// first; only a NotFound failure takes the create path. The legacy storage
// upserts on its own (see legacy.preferenceStorage.Update)
func (s *preferencesStorage) Update(ctx context.Context, name string, objInfo rest.UpdatedObjectInfo, createValidation rest.ValidateObjectFunc, updateValidation rest.ValidateObjectUpdateFunc, forceAllowCreate bool, options *metav1.UpdateOptions) (runtime.Object, bool, error) {
	updated, created, err := s.Storage.Update(ctx, name, objInfo, createValidation, updateValidation, forceAllowCreate, options)
	if err == nil || !k8serrors.IsNotFound(err) {
		return updated, created, err
	}

	// Nothing stored yet -- apply the update to an empty placeholder and create it
	placeholder, err := s.newEmptyPreferences(ctx, name)
	if err != nil {
		return nil, false, err
	}
	obj, err := objInfo.UpdatedObject(ctx, placeholder)
	if err != nil {
		return nil, false, err
	}

	createdObj, err := s.Create(ctx, obj, createValidation, createOptionsFrom(options))
	if err == nil {
		return createdObj, true, nil
	}
	// Lost a race with a concurrent create -- apply as a regular update
	if !k8serrors.IsAlreadyExists(err) {
		return nil, false, err
	}
	return s.Storage.Update(ctx, name, objInfo, createValidation, updateValidation, forceAllowCreate, options)
}

// newEmptyPreferences builds the object a patch/update is applied against
// when nothing is stored yet. It must carry a UID because the apiserver's
// patch handler refuses to merge-patch an object without one
func (s *preferencesStorage) newEmptyPreferences(ctx context.Context, name string) (runtime.Object, error) {
	obj := s.New()
	obj.GetObjectKind().SetGroupVersionKind(s.gvk)
	accessor, err := meta.Accessor(obj)
	if err != nil {
		return nil, err
	}
	accessor.SetName(name)
	accessor.SetNamespace(requestK8s.NamespaceValue(ctx))
	accessor.SetUID(gapiutil.CalculateClusterWideUID(obj))
	return obj, nil
}

func createOptionsFrom(options *metav1.UpdateOptions) *metav1.CreateOptions {
	opts := &metav1.CreateOptions{}
	if options != nil {
		opts.DryRun = options.DryRun
		opts.FieldManager = options.FieldManager
		opts.FieldValidation = options.FieldValidation
	}
	return opts
}

// ListPreferences wraps a regular storage object and populates the results with:
// 1. user preferences (if they exist)
// 2. team preferences (if they exist) for the first 25 groups sorted by UID
// 3. namespace (org) preferences (if they exist)
// The preferences/merged call will merge these all into a single object keeping the first property defined
func (s *preferencesStorage) ListPreferences(ctx context.Context, options *internalversion.ListOptions) (*preferences.PreferencesList, error) {
	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, err
	}
	// Non-user identities (e.g. the image renderer) may list preferences, but
	// they only receive the namespace (org) preferences -- never user or team ones.
	isUser := user.GetIdentityType() == authlib.TypeUser
	if isUser && user.GetIdentifier() == "" {
		return nil, fmt.Errorf("user identifier is required")
	}
	if options == nil {
		options = &internalversion.ListOptions{}
	}

	if options.Continue != "" {
		return nil, fmt.Errorf("continue token not supported")
	}
	if options.LabelSelector != nil && !options.LabelSelector.Empty() {
		return nil, fmt.Errorf("labelSelector not supported")
	}

	groups := user.GetGroups()

	result := &preferences.PreferencesList{
		Items: make([]preferences.Preferences, 0, len(groups)+2),
	}

	addPreferencesToResult := func(owner utils.OwnerReference) error {
		return s.appendOwnerPreferences(ctx, user, isUser, owner, result)
	}

	// Try getting an explicit preferences
	if options.FieldSelector != nil && !options.FieldSelector.Empty() {
		r := options.FieldSelector.Requirements()
		if len(r) != 1 {
			return nil, fmt.Errorf("only one fieldSelector is supported")
		}
		if r[0].Field != "metadata.name" {
			return nil, fmt.Errorf("only the metadata.name fieldSelector is supported")
		}
		if r[0].Operator != selection.Equals {
			return nil, fmt.Errorf("only the = operator is supported")
		}
		owner, ok := utils.ParseOwnerFromName(r[0].Value)
		if !ok {
			return result, nil
		}
		if err = addPreferencesToResult(owner); err != nil {
			return nil, err
		}
		return result, nil
	}

	if isUser {
		// Add the explicit user values
		if err = addPreferencesToResult(utils.UserOwner(user.GetIdentifier())); err != nil {
			return nil, err
		}

		// predictable order
		slices.Sort(groups)
		for i, group := range groups {
			if i >= PreferencesTeamLimit {
				break // only process the first PreferencesTeamLimit -- to keep it bounded
			}
			if err = addPreferencesToResult(utils.TeamOwner(group)); err != nil {
				return nil, err
			}
		}
	}

	// Add the org flavor
	if err = addPreferencesToResult(utils.NamespaceOwner()); err != nil {
		return nil, err
	}

	return result, nil
}

// appendOwnerPreferences fetches the preferences for a single owner and, if the
// caller is allowed to see them and they exist, appends them to result.
func (s *preferencesStorage) appendOwnerPreferences(ctx context.Context, user identity.Requester, isUser bool, owner utils.OwnerReference, result *preferences.PreferencesList) error {
	switch owner.Owner {
	case utils.NamespaceResourceOwner:
		// OK
	case utils.UserResourceOwner:
		if !isUser || user.GetIdentifier() != owner.Identifier {
			return nil
		}
	case utils.TeamResourceOwner:
		if !isUser || !slices.Contains(user.GetGroups(), owner.Identifier) {
			return nil
		}
	default:
		return nil // skip
	}

	rsp, err := s.Get(ctx, owner.AsName(), &metav1.GetOptions{})
	if k8serrors.IsNotFound(err) {
		return nil // don't add it to the list
	}
	if rsp != nil {
		obj, ok := rsp.(*preferences.Preferences)
		if !ok {
			return fmt.Errorf("expected preferences, found %T", rsp)
		}
		result.Items = append(result.Items, *obj)
	}
	return err
}
