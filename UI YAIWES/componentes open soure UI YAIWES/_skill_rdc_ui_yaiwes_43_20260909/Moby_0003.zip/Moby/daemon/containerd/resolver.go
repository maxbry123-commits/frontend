package containerd

import (
	"context"
	"net/http"
	"sync"

	"github.com/containerd/containerd/v2/core/remotes"
	"github.com/containerd/containerd/v2/core/remotes/docker"
	"github.com/containerd/containerd/v2/version"
	cerrdefs "github.com/containerd/errdefs"
	"github.com/containerd/log"
	"github.com/distribution/reference"
	registrytypes "github.com/moby/moby/api/types/registry"
	"github.com/moby/moby/v2/daemon/pkg/registry"
	"github.com/moby/moby/v2/dockerversion"
	"github.com/moby/moby/v2/pkg/useragent"
)

func (i *ImageService) newResolverFromAuthConfig(ctx context.Context, authConfig *registrytypes.AuthConfig, ref reference.Named, metaHeaders http.Header) (remotes.Resolver, docker.StatusTracker) {
	tracker := docker.NewInMemoryTracker()

	hosts := i.registryHosts
	if authConfig != nil {
		authConfig := *authConfig
		var mu sync.Mutex
		// Keep each host, client, and authorizer together so registry and token
		// requests use matching transport settings across resolver phases.
		hostsByName := map[string][]docker.RegistryHost{}
		hosts = func(name string) ([]docker.RegistryHost, error) {
			mu.Lock()
			defer mu.Unlock()

			if hosts, ok := hostsByName[name]; ok {
				return hosts, nil
			}
			hosts, err := hostsWrapper(i.registryHosts, authConfig, ref, name)
			if err != nil {
				return nil, err
			}
			hostsByName[name] = hosts
			return hosts, nil
		}
	}
	headers := http.Header{}
	if metaHeaders != nil {
		headers = metaHeaders.Clone()
	}
	headers.Set("User-Agent", dockerversion.DockerUserAgent(ctx, useragent.VersionInfo{Name: "containerd-client", Version: version.Version}, useragent.VersionInfo{Name: "storage-driver", Version: i.snapshotter}))

	return docker.NewResolver(docker.ResolverOptions{
		Hosts:   hosts,
		Tracker: tracker,
		Headers: headers,
	}), tracker
}

func hostsWrapper(hostsFn docker.RegistryHosts, authConfig registrytypes.AuthConfig, ref reference.Named, name string) ([]docker.RegistryHost, error) {
	hosts, err := hostsFn(name)
	if err != nil {
		return nil, err
	}
	for i := range hosts {
		hosts[i].Authorizer = authorizerFromAuthConfig(authConfig, ref, hosts[i].Client)
	}
	return hosts, nil
}

func authorizerFromAuthConfig(authConfig registrytypes.AuthConfig, ref reference.Named, client *http.Client) docker.Authorizer {
	cfgHost := registry.ConvertToHostname(authConfig.ServerAddress)
	if cfgHost == "" {
		cfgHost = reference.Domain(ref)
	}
	if cfgHost == registry.IndexHostname || cfgHost == registry.IndexName {
		cfgHost = registry.DefaultRegistryHost
	}

	if authConfig.RegistryToken != "" {
		return &bearerAuthorizer{
			host:   cfgHost,
			bearer: authConfig.RegistryToken,
		}
	}

	opts := []docker.AuthorizerOpt{
		docker.WithAuthCreds(func(host string) (string, string, error) {
			if cfgHost != host {
				log.G(context.TODO()).WithFields(log.Fields{
					"host":    host,
					"cfgHost": cfgHost,
				}).Warn("Host doesn't match")
				return "", "", nil
			}
			if authConfig.IdentityToken != "" {
				return "", authConfig.IdentityToken, nil
			}
			return authConfig.Username, authConfig.Password, nil
		}),
	}
	if client != nil {
		opts = append(opts, docker.WithAuthClient(client))
	}
	return docker.NewDockerAuthorizer(opts...)
}

type bearerAuthorizer struct {
	host   string
	bearer string
}

func (a *bearerAuthorizer) Authorize(ctx context.Context, req *http.Request) error {
	if req.Host != a.host {
		log.G(ctx).WithFields(log.Fields{
			"host":    req.Host,
			"cfgHost": a.host,
		}).Warn("Host doesn't match for bearer token")
		return nil
	}

	req.Header.Set("Authorization", "Bearer "+a.bearer)

	return nil
}

func (a *bearerAuthorizer) AddResponses(context.Context, []*http.Response) error {
	// Return not implemented to prevent retry of the request when bearer did not succeed
	return cerrdefs.ErrNotImplemented
}
