import { isMainThread } from 'node:worker_threads';
import type { Parameters } from 'fast-check';
import { assert } from '@fast-check/worker';
import { describe, it } from 'vitest';

// @ts-expect-error - Importing .mjs file without type definitions
import { buildUnregisteredProperty } from './__properties__/unregistered.mjs';
import { expectThrowWithCause } from './__test-helpers__/ThrowWithCause.js';

if (isMainThread) {
  describe('@fast-check/worker', () => {
    const testTimeout = 30000;
    const assertTimeout = 5000;
    const defaultOptions: Parameters<unknown> = { timeout: assertTimeout };

    it(
      'should fail to start when property has not been registered',
      async () => {
        // Arrange
        const unregisteredProperty = buildUnregisteredProperty();
        const expectedError = /Unregistered predicate/;

        // Act / Assert
        await expectThrowWithCause(assert(unregisteredProperty, defaultOptions), expectedError);
      },
      testTimeout,
    );
  });
}
