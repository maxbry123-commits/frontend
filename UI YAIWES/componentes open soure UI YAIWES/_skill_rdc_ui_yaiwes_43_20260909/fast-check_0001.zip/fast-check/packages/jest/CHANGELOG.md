# 2.2.0

_Add support for `@fast-check/worker` version 0.6.0_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv3.0.0)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.1.1...jest%2Fv3.0.0)]

## Fixes

- ([PR#6628](https://github.com/dubzzz/fast-check/pull/6628)) CI: Faster and lighter bundling
- ([PR#6616](https://github.com/dubzzz/fast-check/pull/6616)) Doc: Add support for worker 0.6.0
- ([PR#6654](https://github.com/dubzzz/fast-check/pull/6654)) Doc: Update Readme to point to npmx

---

# 2.1.1

_Support for most recent version of `@fast-check/worker`_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.1.1)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.1.0...jest%2Fv2.1.1)]

## Fixes

- ([PR#5866](https://github.com/dubzzz/fast-check/pull/5866)) Dependencies: Add support for `@fast-check/worker` 0.5.x

# 2.1.0

_Support fast-check v4_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.1.0)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.0.3...jest%2Fv2.1.0)]

## Features

- ([PR#5765](https://github.com/dubzzz/fast-check/pull/5765)) No intermediate var to declare our types

## Fixes

- ([PR#5680](https://github.com/dubzzz/fast-check/pull/5680)) Bug: Wrongly declared /worker
- ([PR#5813](https://github.com/dubzzz/fast-check/pull/5813)) CI: Update tsconfig to common config
- ([PR#5791](https://github.com/dubzzz/fast-check/pull/5791)) Dependencies: Add support for fast-check v4

---

# 2.0.3

_Rework our testing stack_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.0.3)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.0.2...jest%2Fv2.0.3)]

## Fixes

- ([PR#5364](https://github.com/dubzzz/fast-check/pull/5364)) CI: Move to Vitest
- ([PR#5375](https://github.com/dubzzz/fast-check/pull/5375)) Test: Better scoping of tests execution
- ([PR#5378](https://github.com/dubzzz/fast-check/pull/5378)) Test: Make tests run concurrently

# 2.0.2

_Export missing types_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.0.2)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.0.1...jest%2Fv2.0.2)]

## Fixes

- ([PR#5201](https://github.com/dubzzz/fast-check/pull/5201)) Refactor: Add missing types on exported

# 2.0.1

_Document minimum requirements of 2.x_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.0.1)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv2.0.0...jest%2Fv2.0.1)]

## Fixes

- ([PR#5171](https://github.com/dubzzz/fast-check/pull/5171)) Doc: Document minimum requirements of 2.x

# 2.0.0

_ES Module version by default_
[[Code](https://github.com/dubzzz/fast-check/tree/jest%2Fv2.0.0)][[Diff](https://github.com/dubzzz/fast-check/compare/jest%2Fv1.8.2...jest%2Fv2.0.0)]

## Breaking changes

- ([PR#5166](https://github.com/dubzzz/fast-check/pull/5166)) Drop deprecated `{it,test}Prop`
- ([PR#5165](https://github.com/dubzzz/fast-check/pull/5165)) CI: Move build chain to ESM

## Fixes

- ([PR#5167](https://github.com/dubzzz/fast-check/pull/5167)) CI: Migrate jest to esm
