import { describe, it, expect, vi } from 'vitest';
import { tuple } from '../../../src/arbitrary/tuple.js';
import { fakeArbitrary } from './__test-helpers__/ArbitraryHelpers.js';
import * as TupleArbitraryMock from '../../../src/arbitrary/_internals/TupleArbitrary.js';

describe('tuple', () => {
  it('should instantiate a TupleArbitrary based on mapped-to-next arbitraries', () => {
    // Arrange
    const { instance } = fakeArbitrary<unknown[]>();
    const TupleArbitrary = vi.spyOn(TupleArbitraryMock, 'TupleArbitrary');
    TupleArbitrary.mockImplementation(function () {
      return instance;
    });
    const { instance: arb1 } = fakeArbitrary();
    const { instance: arb2 } = fakeArbitrary();

    // Act
    const out = tuple(arb1, arb2);

    // Assert
    expect(out).toBe(instance);
    expect(TupleArbitrary).toHaveBeenCalledWith([arb1, arb2]);
  });
});
