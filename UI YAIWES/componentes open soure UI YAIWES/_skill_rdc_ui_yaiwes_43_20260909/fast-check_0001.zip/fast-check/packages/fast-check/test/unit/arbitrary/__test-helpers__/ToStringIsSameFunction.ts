import { expect } from 'vitest';
import { hash } from '../../../../src/utils/hash.js';
import { stringify } from '../../../../src/utils/stringify.js';

export function assertToStringIsSameFunction<T extends any[] | [any], TOut>(
  f: (...args: T) => TOut,
  inputs: T[],
): void {
  let assertionHasBeenExecuted = false;

  // oxlint-disable-next-line no-unused-vars
  (function (hash, stringify) {
    assertionHasBeenExecuted = true;
    try {
      // As the output of toString might be different if the function has been called
      // before or after toString, we assess both cases
      const dataFromToStringBefore = eval(`(function() { const f = ${f}; return inputs.map((ins) => f(...ins)); })()`);
      const data = inputs.map((ins) => f(...ins));
      const dataFromToString = eval(`(function() { const f = ${f}; return inputs.map((ins) => f(...ins)); })()`);

      expect(dataFromToStringBefore).toStrictEqual(data);
      expect(dataFromToString).toStrictEqual(data);
    } catch (err) {
      throw new Error(`Invalid toString representation encountered, got: ${f}\n\nFailed with: ${err}`, { cause: err });
    }
  })(hash, stringify);

  expect(assertionHasBeenExecuted).toBe(true);
}
