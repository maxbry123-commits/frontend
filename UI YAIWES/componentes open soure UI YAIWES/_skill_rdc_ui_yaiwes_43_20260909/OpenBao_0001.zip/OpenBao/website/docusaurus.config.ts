import { themes as prismThemes } from "prism-react-renderer";
import type { Config } from "@docusaurus/types";
import type { EditUrlFunction } from "@docusaurus/plugin-content-docs";
import type * as Preset from "@docusaurus/preset-classic";
import { includeMarkdown } from "@hashicorp/remark-plugins";
import * as path from "path";
import * as fs from "fs";
import pluginSidebarJson from "./src/docusaurus-plugin-sidebar-json";

function getDocVersions() {
  if (process.env.VERSIONED_DOCS == "true") {
    const filePath = path.join(__dirname, "doc-versions.json");
    const fileContent = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(fileContent);
  } else {
    return {
      current: { label: "Development" },
    };
  }
}

function getEditUrlFn(dir: string): EditUrlFunction {
  return (editUrlParams) => {
    let branch = editUrlParams.version === "current" ?
      `main` :
      `release/${editUrlParams.version}`;
    return `https://github.com/openbao/openbao/blob/${branch}/website/content/${dir}/${editUrlParams.docPath}`;
  }
}

const config: Config = {
  title: "OpenBao",
  tagline:
    "OpenBao is an open source, community-driven fork of HashiCorp Vault managed by the Linux Foundation to manage, store, and distribute sensitive data.",
  favicon: "img/favicon.svg",

  // Set the production url of your site here
  url: "https://openbao.org",
  // Set the /<baseUrl>/ pathname under which your site is served
  // For GitHub pages deployment, it is often '/<projectName>/'
  baseUrl: "/",
  trailingSlash: true,

  // GitHub pages deployment config.
  // If you aren't using GitHub pages, you don't need these.
  organizationName: "openbao", // Usually your GitHub org/user name.
  projectName: "openbao", // Usually your repo name.

  onBrokenLinks: "throw",
  // ignore broken anchors as most of them are false positives
  onBrokenAnchors: "ignore",

  // Even if you don't use internationalization, you can use this field to set
  // useful metadata like html lang. For example, if your site is Chinese, you
  // may want to replace "en" with "zh-Hans".
  i18n: {
    defaultLocale: "en",
    locales: ["en"],
  },
  staticDirectories: ["public"],

  future: {
    faster: true,
    v4: {
      removeLegacyPostBuildHeadAttribute: true, // needed by faster.
    },
  },

  markdown: {
    mermaid: true,
  },
  themes: [
    "@docusaurus/theme-mermaid",
    [
      require.resolve("@easyops-cn/docusaurus-search-local"),
      {
        hashed: true,
        indexDocs: true,
        indexBlog: true,
        indexPages: true,
        docsRouteBasePath: ["docs"],
        docsDir: ["content/docs"],
        blogDir: "content/blog",
        removeDefaultStemmer: true,
        removeDefaultStopWordFilter: true,
        explicitSearchResultPath: true,
        searchContextByPaths: [
          { label: "Docs", path: "docs" },
          { label: "Community", path: "community" },
          { label: "Blog", path: "blog" },
        ],
        useAllContextsWithNoSearchContext: true,
      },
    ],
  ],
  presets: [
    [
      "classic",
      {
        docs: {
          sidebarPath: "./sidebars.ts",
          // Please change this to your repo.
          // Remove this to remove the "edit this page" links.
          editUrl: getEditUrlFn("docs"),
          beforeDefaultRemarkPlugins: [
            [
              includeMarkdown,
              {
                resolveMdx: true,
                resolveFrom: path.join(process.cwd(), "content", "partials"),
              },
            ],
          ],
          path: "content/docs",
          versions: getDocVersions(),
        },
        sitemap: {
          lastmod: "datetime",
          changefreq: "hourly",
          priority: 0.5,
          filename: "sitemap.xml",
        },
        blog: {
          blogTitle: "OpenBao Blog",
          blogDescription:
            "Official blog of the Bao Evangelism Taskforce (BET)",
          blogSidebarCount: 'ALL',
          blogSidebarTitle: 'All posts',
          path: "content/blog",
        },
        theme: {
          customCss: "./src/css/custom.css",
        },
        gtag: {
          trackingID: "GTM-MWH2V47T",
          anonymizeIP: true,
        },
      } satisfies Preset.Options,
    ],
  ],
  plugins: [
    [
      "@docusaurus/plugin-content-docs",
      {
        id: "ecosystem",
        path: "content/ecosystem",
        routeBasePath: "ecosystem",
        editUrl: "https://github.com/openbao/openbao/tree/main/website/",
        beforeDefaultRemarkPlugins: [
          [
            includeMarkdown,
            {
              resolveMdx: true,
              resolveFrom: path.join(process.cwd(), "content", "partials"),
            },
          ],
        ],
      },
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        id: "community",
        path: "content/community",
        routeBasePath: "community",
        sidebarPath: "./sidebarsCommunity.ts",
        editUrl: "https://github.com/openbao/openbao/tree/main/website/",
        beforeDefaultRemarkPlugins: [
          [
            includeMarkdown,
            {
              resolveMdx: true,
              resolveFrom: path.join(process.cwd(), "content", "partials"),
            },
          ],
        ],
      },
    ],
    [
      "@docusaurus/plugin-client-redirects",
      {
        redirects: [
          {
            from: "/api-docs/system/rotate-config",
            to: "/docs/api/system/rotate/keyring-config",
          },
          // Add unversioned variants of these redirects once 2.7.0 is cut.
          {
            from: "/docs/next/upgrading/",
            to: "/docs/next/guides/upgrade/",
          },
          {
            from: "/docs/next/upgrading/ha-upgrade",
            to: "/docs/next/guides/upgrade/ha",
          },
          {
            from: "/docs/next/upgrading/plugins-upgrade",
            to: "/docs/next/guides/upgrade/plugins",
          },
        ],
        createRedirects(existingPath) {
          if (existingPath.includes('/community/') && existingPath !== '/community/') {
            return [
              existingPath.replace('/community/', '/docs/'),
              existingPath.replace('/community/', '/docs/next/'),
              existingPath.replace('/community/', '/docs/2.5.x/'),
              existingPath.replace('/community/', '/docs/2.4.x/'),
              existingPath.replace('/community/', '/docs/2.3.x/'),
            ];
          }

          if (existingPath.includes('/docs/api/')) {
            return [
              existingPath.replace('/docs/api/', '/api-docs/'),
              existingPath.replace('/docs/next/api/', '/api-docs/next/'),
              existingPath.replace('/docs/2.6.x/api/', '/api-docs/2.6.x/'),
              existingPath.replace('/docs/2.5.x/api/', '/api-docs/2.5.x/'),
              existingPath.replace('/docs/2.4.x/api/', '/api-docs/2.4.x/'),
            ];
          }

          if (existingPath.includes('/docs/api/secret/')) {
            return [
              existingPath.replace('/docs/api/secret/', '/docs/api/secrets/'),
              existingPath.replace('/docs/api/secret/', '/api-docs/secrets/'),
            ];
          }

          if (existingPath.includes('/docs/secrets/')) {
            return [
              existingPath.replace('/docs/secrets/', '/docs/secret/'),
            ];
          }

          return undefined;
        },
      },
    ],
    pluginSidebarJson,
  ],

  themeConfig: {
    colorMode: { respectPrefersColorScheme: true },
    navbar: {
      title: "OpenBao",
      logo: {
        alt: "OpenBao Logo",
        src: "img/logo-black.svg",
        srcDark: "img/logo-white.svg",
      },
      items: [
        {
          to: "/blog/",
          label: "Blog",
          position: "left",
        },
        {
          to: "/ecosystem/",
          label: "Ecosystem",
          position: "left",
        },
        {
          to: "/docs/",
          label: "Docs",
          position: "left",
        },
        { to: "/docs/api/", label: "API", position: "left" },
        {
          to: "/downloads",
          label: "Downloads",
          position: "left",
        },
        {
          to: "/community/",
          label: "Community",
          position: "left",
        },
        {
          type: "docsVersionDropdown",
          versions: getDocVersions(),
          position: "right",
        },
        {
          href: "https://github.com/openbao/openbao",
          label: "GitHub",
          position: "right",
        },
      ],
    },
    footer: {
      copyright: [
        `Copyright © ${new Date().getFullYear()} OpenBao a Series of LF Projects, LLC <br>`,
        `For web site terms of use, trademark policy and other project policies please see <a href="https://lfprojects.org">lfprojects.org</a>. <br>`,
        ` OpenBao is a <a href="https://openssf.org/projects/openbao/">Sandbox project</a> at`,
        `<a href="https://openssf.org/"><img src="/img/openssf-logo.svg" alt="OpenSSF Logo" width="90px"></a>.`,
        `<br><br>Follow us on social media:<br>`,
        `<a href="https://linkedin.com/company/openbao" target="_blank">LinkedIn</a> | <a href="https://bsky.app/profile/openbao-official.bsky.social" target="_blank">Bluesky</a> | <a href="https://www.youtube.com/@OpenBao" target="_blank">YouTube</a> | <a href="https://www.instagram.com/openbao.official/" target="_blank">Instagram</a> | <a href="https://www.threads.com/@openbao.official" target="_blank">Threads</a> | <a href="https://github.com/openbao/openbao" target="_blank">GitHub</a>`,
        `<br><br><a href="/sitemap.xml">Sitemap</a>`,
      ].join(" "),
    },
    prism: {
      theme: prismThemes.github,
      darkTheme: prismThemes.dracula,
      additionalLanguages: ["hcl"],
    },
    metadata: [
      {
        name: "keywords",
        content:
          "openbao, secrets management, open source, linux foundation, encryption as a service, key management system, pki, transit, ssh, secret vault, database passwords",
      },
      { name: "author", content: "OpenBao a Series of LF Projects, LLC" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    headTags: [
      {
        tagName: "link",
        attributes: {
          rel: "sitemap",
          type: "application/xml",
          title: "Sitemap",
          href: "/sitemap.xml",
        },
      },
    ],
  } satisfies Preset.ThemeConfig,
};

export default config;
