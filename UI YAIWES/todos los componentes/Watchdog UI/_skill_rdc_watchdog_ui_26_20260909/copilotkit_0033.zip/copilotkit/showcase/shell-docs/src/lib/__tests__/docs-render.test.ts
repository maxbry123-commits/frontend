import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import fs from "fs";
import path from "path";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";

vi.mock("../registry", async (importOriginal) => {
  const actual = await importOriginal<Record<string, unknown>>();
  return {
    ...actual,
    getDocsMode: () => "generated",
  };
});

import {
  buildFrameworkNav,
  buildFrameworkOnlyNav,
  buildRootSurfaceNav,
  CONTENT_DIR,
  inlineSnippets,
  loadDoc,
  navAncestorBreadcrumbsForSlug,
  readIcon,
  readTitle,
  SNIPPET_MAP,
  SNIPPETS_DIR,
} from "../docs-render";
import type { NavNode } from "../docs-render";
import { buildCookbookNavTree } from "../cookbook-nav";
import { navTreeToPageTree } from "../page-tree-bridge";
import { buildReferencePageTree } from "../reference-items";
import { getDocsFolder, getIntegrations } from "../registry";

let tempDir = "";

beforeEach(() => {
  tempDir = fs.mkdtempSync(path.join(SNIPPETS_DIR, "__pdx-208-"));
});

afterEach(() => {
  delete SNIPPET_MAP.Pdx208Parent;
  if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  tempDir = "";
  vi.restoreAllMocks();
});

function writeSnippet(filename: string, body: string): string {
  const filePath = path.join(tempDir, filename);
  fs.writeFileSync(filePath, body);
  return path.relative(SNIPPETS_DIR, filePath);
}

function hasSectionPage(navTree: NavNode[], section: string, page: string) {
  let inSection = false;
  for (const node of navTree) {
    if (node.type === "section") {
      inSection = node.title === section;
      continue;
    }
    if (inSection && node.type === "page" && node.title === page) return true;
    if (
      inSection &&
      node.type === "group" &&
      hasPageTitle(node.children, page)
    ) {
      return true;
    }
  }
  return false;
}

function hasPageTitle(navTree: NavNode[], page: string): boolean {
  return navTree.some((node) => {
    if (node.type === "page") return node.title === page;
    if (node.type === "group") return hasPageTitle(node.children, page);
    return false;
  });
}

function findPageByTitle(
  navTree: NavNode[],
  page: string,
): Extract<NavNode, { type: "page" }> | undefined {
  for (const node of navTree) {
    if (node.type === "page" && node.title === page) return node;
    if (node.type === "group") {
      const match = findPageByTitle(node.children, page);
      if (match) return match;
    }
  }
  return undefined;
}

type NavPageEntry = { title: string; slug: string };

function groupPageEntries(
  navTree: NavNode[],
  groupTitle: string,
): NavPageEntry[] {
  for (const node of navTree) {
    if (node.type !== "group") continue;
    if (node.title === groupTitle) {
      if (node.children.some((child) => child.type !== "page")) {
        throw new Error(`${groupTitle} must contain only direct page entries`);
      }
      return node.children.map((child) => {
        if (child.type !== "page") throw new Error("expected page entry");
        return { title: child.title, slug: child.slug };
      });
    }

    const nested = groupPageEntries(node.children, groupTitle);
    if (nested.length > 0) return nested;
  }

  return [];
}

function sectionTitles(navTree: NavNode[]): string[] {
  return navTree
    .filter(
      (node): node is Extract<NavNode, { type: "section" }> =>
        node.type === "section",
    )
    .map((node) => node.title);
}

function sectionNodes(navTree: NavNode[], section: string): NavNode[] {
  const sectionIndex = navTree.findIndex(
    (node) => node.type === "section" && node.title === section,
  );
  if (sectionIndex === -1) return [];

  const nextSectionIndex = navTree.findIndex(
    (node, index) => index > sectionIndex && node.type === "section",
  );
  return navTree.slice(
    sectionIndex + 1,
    nextSectionIndex === -1 ? undefined : nextSectionIndex,
  );
}

function collectMdxFiles(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const filePath = path.join(dir, entry.name);
    if (entry.isDirectory()) return collectMdxFiles(filePath);
    return entry.isFile() && entry.name.endsWith(".mdx") ? [filePath] : [];
  });
}

describe("inlineSnippets", () => {
  it("recursively inlines helper components imported from snippets", () => {
    const helperRel = writeSnippet("helper.mdx", "Helper body\n");
    const parentRel = writeSnippet(
      "parent.mdx",
      [
        `import Pdx208Helper from "@/snippets/${helperRel}";`,
        "",
        "Before",
        "<Pdx208Helper />",
        "After",
      ].join("\n"),
    );
    SNIPPET_MAP.Pdx208Parent = parentRel;
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const rendered = inlineSnippets("<Pdx208Parent />", "pdx-208");

    expect(rendered).toContain("Before");
    expect(rendered).toContain("Helper body");
    expect(rendered).toContain("After");
    expect(rendered).not.toContain("<Pdx208Helper />");
    expect(warnSpy).not.toHaveBeenCalledWith(
      "[docs-render] snippet missing for component",
      "Pdx208Helper",
      "from slug",
      "pdx-208",
    );
  });

  it("preserves non-snippet component imports as runtime components", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const rendered = inlineSnippets(
      [
        'import RuntimeCard from "@/components/runtime-card";',
        "",
        "<RuntimeCard />",
      ].join("\n"),
      "pdx-208-runtime",
    );

    expect(rendered).toContain("<RuntimeCard />");
    expect(warnSpy).not.toHaveBeenCalledWith(
      "[docs-render] snippet missing for component",
      "RuntimeCard",
      "from slug",
      "pdx-208-runtime",
    );
  });

  it("preserves multiline runtime component imports", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const rendered = inlineSnippets(
      [
        "import {",
        "  RuntimeCard,",
        '} from "@/components/runtime-card";',
        "",
        "<RuntimeCard />",
      ].join("\n"),
      "pdx-208-runtime-multiline",
    );

    expect(rendered).toContain("<RuntimeCard />");
    expect(warnSpy).not.toHaveBeenCalledWith(
      "[docs-render] snippet missing for component",
      "RuntimeCard",
      "from slug",
      "pdx-208-runtime-multiline",
    );
  });
});

describe("loadDoc", () => {
  it("resolves clean URLs to files stored under route-group folders", () => {
    const doc = loadDoc("integrations/aws-strands/telemetry");

    expect(doc?.filePath.split(path.sep).join("/")).toContain(
      "integrations/aws-strands/(other)/telemetry/index.mdx",
    );
  });

  it("keeps the Threads overview and headless implementation on separate routes", () => {
    expect(loadDoc("threads")?.fm.title).toBe("Rich Threads");
    expect(loadDoc("headless-threads")?.fm.title).toBe("Headless Threads");
    expect(loadDoc("integrations/mastra/threads")?.fm.title).toBe(
      "Rich Threads",
    );
    expect(loadDoc("integrations/mastra/headless-threads")?.fm.title).toBe(
      "Headless Threads",
    );
  });

  it("keeps the approved overview assets and activation journey in order", () => {
    const overview = fs.readFileSync(
      path.join(SNIPPETS_DIR, "shared/threads/overview.mdx"),
      "utf8",
    );

    const screenshot = overview.indexOf("support-desk-threads.png");
    const gettingStarted = overview.indexOf("## Get started");
    const why = overview.indexOf("## Why use CopilotKit Rich Threads?");
    const diagram = overview.indexOf("threads-diagram-light.png");

    expect(screenshot).toBeGreaterThan(-1);
    expect(screenshot).toBeLessThan(gettingStarted);
    expect(gettingStarted).toBeLessThan(why);
    expect(why).toBeLessThan(diagram);
    expect(overview).toContain("npx copilotkit@latest init");
    expect(overview).toContain("Build and verify this with a coding agent");
    expect(overview).toContain("Threads-capable CLI starters already include");
    expect(overview).toContain("Book time with a CopilotKit engineer");
    expect(overview).toContain("## Sync existing conversations");
    expect(overview).toContain("threads-diagram-dark.png");
  });

  it("links locked Inspector users to both Rich Threads Runtime route modes", () => {
    const runtimeEndpoints = loadDoc("backend/runtime-endpoints")?.source ?? "";
    const inspector = loadDoc("inspector")?.source ?? "";

    expect(runtimeEndpoints).toContain("## Enable Rich Threads routes");
    expect(runtimeEndpoints).toContain('mode: "single-route"');
    expect(runtimeEndpoints).toContain(
      'import { CopilotKitProvider } from "@copilotkit/react-core/v2";',
    );
    expect(runtimeEndpoints).toContain("`useSingleEndpoint={false}`");
    expect(runtimeEndpoints).toContain("`identifyUser`");
    expect(runtimeEndpoints).toContain("`GET`, `POST`, `PATCH`, and `DELETE`");
    expect(runtimeEndpoints).toContain('"resourceOperations": true');
    expect(runtimeEndpoints).toContain('"list": true');
    expect(runtimeEndpoints).toContain('"inspect": true');
    expect(inspector).toContain(
      "[Enable Rich Threads routes](/backend/runtime-endpoints#enable-rich-threads-routes)",
    );
  });
});

describe("readIcon", () => {
  it("only exposes page icons when frontmatter opts in with showIcon", () => {
    const hiddenIconFile = path.join(tempDir, "hidden-icon.mdx");
    const visibleIconFile = path.join(tempDir, "visible-icon.mdx");

    fs.writeFileSync(
      hiddenIconFile,
      [
        "---",
        'title: "Hidden icon"',
        'icon: "lucide/Bolt"',
        "---",
        "",
        "Body",
      ].join("\n"),
    );
    fs.writeFileSync(
      visibleIconFile,
      [
        "---",
        'title: "Visible icon"',
        'icon: "lucide/Bolt"',
        "showIcon: true",
        "---",
        "",
        "Body",
      ].join("\n"),
    );

    expect(readIcon(hiddenIconFile)).toBeNull();
    expect(readIcon(visibleIconFile)).toBe("lucide/Bolt");
  });
});

describe("readTitle", () => {
  it("uses nav_title for navigation without changing the page title", () => {
    const filePath = path.join(tempDir, "nav-title.mdx");
    fs.writeFileSync(
      filePath,
      [
        "---",
        'title: "Threads"',
        'nav_title: "Overview"',
        "---",
        "",
        "Body",
      ].join("\n"),
    );

    expect(readTitle(filePath)).toBe("Overview");
    expect(loadDoc("threads")?.fm.title).toBe("Rich Threads");
  });
});

describe("reference nav", () => {
  it("renders the Reference root entry with a book icon", () => {
    const tree = buildReferencePageTree("v2");
    const markup = renderToStaticMarkup(
      React.createElement(React.Fragment, null, tree.name),
    );

    expect(markup).toContain("lucide-book-open");
    expect(markup).toContain("Reference");
  });
});

describe("migration docs", () => {
  it("recommends CopilotKit from the v2 entrypoint instead of CopilotKitProvider", () => {
    const snippet = fs.readFileSync(
      path.join(SNIPPETS_DIR, "shared/troubleshooting/migrate-to-v2.mdx"),
      "utf8",
    );

    expect(snippet).toContain(
      "Keep the `<CopilotKit>` provider name, but import it from `@copilotkit/react-core/v2`.",
    );
    expect(snippet).toContain(
      'import { CopilotKit, useAgent } from "@copilotkit/react-core/v2";',
    );
    expect(snippet).toContain(
      'import { CopilotKit, CopilotPopup } from "@copilotkit/react-core/v2";',
    );
    expect(snippet).not.toContain("CopilotKitProvider");
  });

  it("keeps v2 reference pages aligned with the CopilotKit v2 entrypoint", () => {
    const referenceIndex = fs.readFileSync(
      path.join(CONTENT_DIR, "..", "reference/index.mdx"),
      "utf8",
    );
    const componentReference = fs.readFileSync(
      path.join(CONTENT_DIR, "..", "reference/components/CopilotKit.mdx"),
      "utf8",
    );

    expect(referenceIndex).toContain(
      'import { CopilotKit } from "@copilotkit/react-core/v2";',
    );
    expect(referenceIndex).not.toContain(
      "CopilotKit is imported from the root package",
    );
    expect(referenceIndex).not.toContain(
      "import `CopilotKit` from `@copilotkit/react-core`",
    );
    expect(componentReference).toContain("`@copilotkit/react-core/v2`");
    expect(componentReference).not.toContain("not from the v2 subpackage");
    expect(componentReference).toContain("createCopilotRuntimeHandler({");
    expect(componentReference).not.toContain(
      "copilotRuntimeNextJSAppRouterEndpoint",
    );
  });

  it("does not recommend stale v2 package paths in authored docs", () => {
    const authoredDocFiles = collectMdxFiles(CONTENT_DIR);
    const allowedRootProviderImports = new Set([
      path.join(CONTENT_DIR, "migrate/v2.mdx"),
    ]);

    const rootProviderImports = authoredDocFiles.filter((filePath) => {
      if (allowedRootProviderImports.has(filePath)) return false;
      return fs
        .readFileSync(filePath, "utf8")
        .includes('import { CopilotKit } from "@copilotkit/react-core";');
    });

    const oldV2StyleImports = [
      ...authoredDocFiles,
      ...collectMdxFiles(SNIPPETS_DIR),
    ].filter((filePath) =>
      fs
        .readFileSync(filePath, "utf8")
        .includes("@copilotkit/react-ui/v2/styles.css"),
    );

    expect(rootProviderImports).toEqual([]);
    expect(oldV2StyleImports).toEqual([]);
  });
});

describe("cookbook nav", () => {
  it("uses the real Claude mark instead of a text placeholder", () => {
    const claudeLogo = fs.readFileSync(
      path.resolve(CONTENT_DIR, "../../../public/logos/claude.svg"),
      "utf8",
    );

    expect(claudeLogo).toContain("<path");
    expect(claudeLogo).not.toContain("<text");
  });

  it("renders overview and recipes as top-level entries without changing slugs", () => {
    const navTree = buildCookbookNavTree();

    expect(navTree).toHaveLength(7);
    expect(navTree.map((node) => node.type)).toEqual([
      "page",
      "page",
      "page",
      "page",
      "page",
      "page",
      "page",
    ]);
    expect(
      navTree.map((node) =>
        node.type === "page" ? [node.title, node.slug] : null,
      ),
    ).toEqual([
      ["Overview", "cookbook/index"],
      ["Daytona", "cookbook/daytona"],
      ["Claude Managed Agents", "cookbook/claude-managed-agents"],
      ["Oracle Agent Memory", "cookbook/oracle-agent-spec-memory"],
      ["Arcade", "cookbook/arcade"],
      ["Angular + Google ADK", "cookbook/angular-adk-agentic-app"],
      ["OpenBox Governance", "cookbook/openbox-governed-copilotkit"],
    ]);

    const pageTree = navTreeToPageTree(navTree, "");
    expect(pageTree.children.map((node) => node.type)).toEqual([
      "page",
      "page",
      "page",
      "page",
      "page",
      "page",
      "page",
    ]);
    expect(
      pageTree.children.map((node) => (node.type === "page" ? node.url : null)),
    ).toEqual([
      "/cookbook",
      "/cookbook/daytona",
      "/cookbook/claude-managed-agents",
      "/cookbook/oracle-agent-spec-memory",
      "/cookbook/arcade",
      "/cookbook/angular-adk-agentic-app",
      "/cookbook/openbox-governed-copilotkit",
    ]);

    const overview = pageTree.children[0];
    if (overview?.type !== "page") throw new Error("expected Overview page");
    const overviewMarkup = renderToStaticMarkup(
      React.createElement(React.Fragment, null, overview.name),
    );
    expect(overviewMarkup).toContain("lucide-book-open");
    expect(overviewMarkup).toContain("Overview");
  });
});

describe("framework nav", () => {
  it("derives breadcrumbs from the complete sidebar hierarchy", () => {
    const navTree = buildRootSurfaceNav("built-in-agent");

    expect(navAncestorBreadcrumbsForSlug(navTree, "frontend-tools")).toEqual([
      { label: "Basics", href: null },
    ]);
    expect(navAncestorBreadcrumbsForSlug(navTree, "threads")).toEqual([
      { label: "Basics", href: null },
      { label: "Rich Threads", href: null },
    ]);
    expect(
      navAncestorBreadcrumbsForSlug(navTree, "prebuilt-components"),
    ).toEqual([
      { label: "Basics", href: null },
      { label: "Chat", href: null },
    ]);
    expect(
      navAncestorBreadcrumbsForSlug(navTree, "custom-look-and-feel/slots"),
    ).toEqual([
      { label: "Basics", href: null },
      { label: "Chat", href: null },
      { label: "Custom Look and Feel", href: null },
    ]);
  });

  it("uses the requested section flow on the root docs surface", () => {
    const navTree = buildRootSurfaceNav("built-in-agent");
    const titles = sectionTitles(navTree);
    const backend = sectionNodes(navTree, "Backend");
    const runtime = backend.find(
      (node) => node.type === "group" && node.title === "Runtime",
    );

    expect(titles).toEqual([
      "Basics",
      "Generative UI",
      "Interactivity",
      "Agent capabilities",
      "Intelligence",
      "Backend",
      "Learn",
      "Other",
    ]);
    expect(navTree.slice(0, 3)).toMatchObject([
      {
        type: "page",
        title: "Introduction",
        slug: "",
        icon: "lucide/Rocket",
      },
      {
        type: "page",
        title: "Quickstart",
        slug: "quickstart",
        icon: "lucide/Play",
      },
      {
        type: "page",
        title: "Intelligence",
        slug: "intelligence/overview",
        icon: "custom/intelligence-kite",
      },
    ]);
    expect(
      navTree.find(
        (node) => node.type === "section" && node.title === "Intelligence",
      ),
    ).toMatchObject({ icon: "custom/copilotkit-kite" });
    expect(
      navTree.find(
        (node) => node.type === "section" && node.title === "Basics",
      ),
    ).toMatchObject({ icon: "lucide/Sprout" });
    expect(
      navTree.find(
        (node) => node.type === "section" && node.title === "Generative UI",
      ),
    ).toMatchObject({ icon: "lucide/LayoutTemplate" });
    expect(
      navTree.find(
        (node) =>
          node.type === "section" && node.title === "Agent capabilities",
      ),
    ).toMatchObject({ icon: "lucide/Sparkles" });
    expect(
      navTree.find((node) => node.type === "section" && node.title === "Other"),
    ).toMatchObject({ icon: "lucide/Wrench" });
    expect(
      navTree
        .filter((node) => node.type === "section")
        .every((node) => Boolean(node.icon)),
    ).toBe(true);
    expect(sectionNodes(navTree, "Basics").map((node) => node.title)).toEqual([
      "Chat",
      "Rich threads",
      "Frontend-tools",
    ]);
    expect(
      sectionNodes(navTree, "Intelligence").map((node) => node.title),
    ).toEqual([
      "Overview",
      "Get started",
      "Rich Threads",
      "Automatic Learning",
      "User Memories",
      "Hosting",
    ]);
    expect(
      sectionNodes(navTree, "Interactivity").map((node) => node.title),
    ).toEqual(["Shared state", "Human-in-the-loop", "WebMCP"]);
    expect(
      sectionNodes(navTree, "Agent capabilities").map((node) => node.title),
    ).toEqual([
      "Built-in Agent",
      "Automatic Learning",
      "User Memories",
      "Sub-agents",
    ]);
    expect(groupPageEntries(navTree, "Get started")).toEqual([
      { title: "Quickstart", slug: "intelligence/quickstart" },
      { title: "Architecture", slug: "intelligence/intelligence-platform" },
      {
        title: "Connect your runtime",
        slug: "intelligence/connect-your-runtime",
      },
    ]);
    expect(
      sectionNodes(navTree, "Intelligence").filter(
        (node) => node.type === "page",
      ),
    ).toMatchObject([
      { type: "page", title: "Overview", slug: "intelligence/overview" },
      { type: "page", title: "Rich Threads", slug: "threads" },
      {
        type: "page",
        title: "Automatic Learning",
        slug: "learning",
      },
      {
        type: "page",
        title: "User Memories",
        slug: "intelligence/memories",
      },
    ]);
    expect(groupPageEntries(navTree, "Hosting")).toEqual([
      { title: "Cloud", slug: "intelligence/managed-intelligence-platform" },
      { title: "Self-hosted", slug: "intelligence/self-hosting" },
    ]);
    expect(findPageByTitle(navTree, "Automatic Learning")).toMatchObject({
      slug: "learning",
    });
    expect(findPageByTitle(navTree, "WebMCP")).toMatchObject({
      slug: "webmcp",
    });
    expect(
      hasSectionPage(navTree, "Agent capabilities", "Automatic Learning"),
    ).toBe(true);
    expect(hasSectionPage(navTree, "Agent capabilities", "User Memories")).toBe(
      true,
    );
    expect(sectionNodes(navTree, "Backend").map((node) => node.title)).toEqual([
      "Runtime",
      "Deployment",
      "Debugging",
    ]);
    expect(runtime).toMatchObject({ type: "group", title: "Runtime" });
    expect(
      runtime?.type === "group" &&
        hasPageTitle(runtime.children, "Copilot Runtime"),
    ).toBe(true);
    expect(sectionNodes(navTree, "Learn").map((node) => node.title)).toEqual([
      "Concepts",
      "Cookbook",
      "Reference",
    ]);
    expect(findPageByTitle(navTree, "Open-source telemetry")).toMatchObject({
      type: "page",
      slug: "telemetry",
    });
  });

  it("uses the same section flow for generated and authored frameworks", () => {
    const generatedNav = buildFrameworkNav(
      "langgraph",
      "LangGraph (Python)",
      "langgraph-python",
    );
    const authoredNav = buildFrameworkOnlyNav("ag2");

    expect(sectionTitles(generatedNav)).toEqual([
      "Basics",
      "Generative UI",
      "Interactivity",
      "Agent capabilities",
      "Intelligence",
      "Backend",
      "Learn",
      "Other",
    ]);
    expect(sectionTitles(authoredNav)).toEqual([
      "Basics",
      "Generative UI",
      "Interactivity",
      "Agent capabilities",
      "Intelligence",
      "Backend",
      "Learn",
      "Other",
    ]);
    expect(hasSectionPage(authoredNav, "Backend", "Copilot Runtime")).toBe(
      true,
    );
    expect(hasSectionPage(authoredNav, "Intelligence", "Overview")).toBe(true);
    expect(
      sectionNodes(generatedNav, "Agent capabilities").some(
        (node) => node.type === "group" && node.title === "LangGraph (Python)",
      ),
    ).toBe(true);
    expect(
      sectionNodes(authoredNav, "Agent capabilities").some(
        (node) => node.type === "group" && node.title === "AG2",
      ),
    ).toBe(true);
  });

  it("leaves Slack and Teams platform guides ungated", () => {
    const slack = loadDoc("frontends/slack");
    const teams = loadDoc("frontends/teams");

    expect(slack?.fm.earlyAccess).toBeUndefined();
    expect(slack?.source).toContain("doc_type: tutorial");
    expect(teams?.fm.earlyAccess).toBeUndefined();
    expect(teams?.source).toContain("doc_type: tutorial");
  });

  it("does not publish a selectable WhatsApp guide before launch", () => {
    expect(loadDoc("frontends/whatsapp")).toBeNull();
  });

  it("keeps frontend platform guides out of generated framework nav", () => {
    const navTree = buildFrameworkNav(
      "langgraph",
      "LangGraph (Python)",
      "langgraph-python",
    );

    expect(hasSectionPage(navTree, "Platforms", "React Native")).toBe(false);
    expect(hasSectionPage(navTree, "Platforms", "Vue")).toBe(false);
  });

  it("keeps frontend platform guides out of authored framework nav", () => {
    const navTree = buildFrameworkOnlyNav("built-in-agent");

    expect(hasSectionPage(navTree, "Platforms", "React Native")).toBe(false);
    expect(hasSectionPage(navTree, "Platforms", "Slack")).toBe(false);
  });

  it("keeps the compact start links in generated and authored framework nav", () => {
    const generatedNav = buildFrameworkNav(
      "langgraph",
      "LangGraph (Python)",
      "langgraph-python",
    );
    const authoredNav = buildFrameworkOnlyNav("mastra");
    const sharedFolderAuthoredNav = buildFrameworkOnlyNav("langgraph");

    for (const nav of [generatedNav, authoredNav, sharedFolderAuthoredNav]) {
      expect(nav.slice(0, 3)).toMatchObject([
        { type: "page", title: "Introduction", slug: "" },
        { type: "page", title: "Quickstart", slug: "quickstart" },
        {
          type: "page",
          title: "Intelligence",
          slug: "intelligence/overview",
          icon: "custom/intelligence-kite",
        },
      ]);
      expect(hasPageTitle(nav, "CopilotKit CLI")).toBe(false);
    }
  });

  it("orders the Threads job routes consistently across framework modes", () => {
    const generatedNav = buildFrameworkNav(
      "langgraph",
      "LangGraph (Python)",
      "langgraph-python",
    );
    const expected = [
      { title: "Overview", slug: "threads" },
      {
        title: "Threads Drawer",
        slug: "prebuilt-components/copilot-threads-drawer",
      },
      { title: "Headless Threads", slug: "headless-threads" },
      { title: "Thread & History Lifecycle", slug: "threads-lifecycle" },
      { title: "Synchronize Thread History", slug: "threads-import" },
      {
        title: "Self-Managed Persistence",
        slug: "threads-self-managed",
      },
      {
        title: "Threads & Persistence Architecture",
        slug: "intelligence/threads-explained",
      },
    ];
    const withoutDrawer = expected.filter(
      (entry) => entry.title !== "Threads Drawer",
    );

    expect(groupPageEntries(generatedNav, "Rich threads")).toEqual(expected);

    const authoredFolders = [
      ...new Set(
        getIntegrations()
          .filter((integration) => integration.docs_mode === "authored")
          .map((integration) => getDocsFolder(integration.slug)),
      ),
    ];

    for (const folder of authoredFolders) {
      expect(
        groupPageEntries(buildFrameworkOnlyNav(folder), "Rich threads"),
      ).toEqual(folder === "deepagents" ? withoutDrawer : expected);
    }
  });

  it("keeps the thread synchronization route while preserving source-specific guides", () => {
    const generic = loadDoc("threads-import");
    const adk = loadDoc("integrations/adk/threads-import");
    const langgraph = loadDoc("integrations/langgraph/threads-import");

    expect(generic?.fm.title).toBe("Import & Synchronize Thread History");
    expect(adk?.fm.title).toBe("Synchronize ADK Threads");
    expect(langgraph?.fm.title).toBe("Synchronize LangGraph Threads");
    expect(generic && readTitle(generic.filePath)).toBe(
      "Synchronize Thread History",
    );
    expect(adk && readTitle(adk.filePath)).toBe("Synchronize Thread History");
    expect(langgraph && readTitle(langgraph.filePath)).toBe(
      "Synchronize Thread History",
    );

    const generatedNav = buildFrameworkNav(
      "langgraph",
      "LangGraph (Python)",
      "langgraph-python",
    );
    expect(groupPageEntries(generatedNav, "Rich threads")).toContainEqual({
      title: "Synchronize Thread History",
      slug: "threads-import",
    });
  });

  it("documents destination credentials without claiming project metadata is imported", () => {
    const genericDoc = loadDoc("threads-import");
    const generic = genericDoc
      ? inlineSnippets(genericDoc.source, "threads-import")
      : "";
    const adk = loadDoc("integrations/adk/threads-import")?.source ?? "";
    const langgraph =
      loadDoc("integrations/langgraph/threads-import")?.source ?? "";

    for (const source of [generic, adk, langgraph]) {
      expect(source).toContain(
        "does not load `.env` or `.copilotkit/project.json` automatically",
      );
      expect(source).toContain('export INTELLIGENCE_API_URL="https://..."');
      expect(source).toContain('export CPK_INTELLIGENCE_API_KEY="cpk-..."');
      expect(source).not.toContain('export CPK_INTELLIGENCE_API_KEY="cpk_..."');
      expect(source).toContain(
        "does not need a CopilotKit Intelligence URL or API key",
      );
    }

    expect(generic).toContain("durable LangGraph checkpointer");
    expect(generic).toContain("durable ADK session service");
    expect(adk).toContain("ADK session storage and analytics");
    expect(langgraph).toContain("LangGraph or LangSmith storage and analytics");
  });

  it("keeps Drawer and Headless guidance applicable to starters and existing apps", () => {
    const drawer = fs.readFileSync(
      path.join(SNIPPETS_DIR, "shared/basics/copilot-threads-drawer.mdx"),
      "utf8",
    );
    const headless = fs.readFileSync(
      path.join(SNIPPETS_DIR, "shared/threads/headless-threads.mdx"),
      "utf8",
    );

    expect(drawer).toContain(
      "If your project was created from a CopilotKit CLI starter",
    );
    expect(drawer).toContain("add it to an existing CopilotKit application");
    expect(drawer).toContain("Get a free developer account");
    expect(drawer).toContain("## Set up the Threads Drawer");
    expect(drawer).not.toContain(
      "Start with the [Rich Threads overview](/threads)",
    );

    expect(headless).toContain(
      "If your app came from a CopilotKit CLI starter",
    );
    expect(headless).toContain("adding a custom thread UI to an existing app");
    expect(headless).toContain(
      "Your `CopilotRuntime` must be connected to CopilotKit Intelligence",
    );
    expect(headless).not.toContain("npx copilotkit@latest init");
  });

  it("documents conditional future native persistence without claiming replication", () => {
    const lifecycle = fs.readFileSync(
      path.join(SNIPPETS_DIR, "shared/threads/threads-lifecycle.mdx"),
      "utf8",
    );
    const architecture =
      loadDoc("intelligence/threads-explained")?.source ?? "";

    for (const source of [lifecycle, architecture]) {
      const normalized = source.replace(/\s+/g, " ");
      expect(normalized).toContain("durable session service");
      expect(normalized).toContain("rename");
      expect(normalized).toContain("archive");
      expect(normalized).toContain("delete");
    }
    expect(lifecycle).toContain("durable checkpointer");
    expect(architecture).toContain("durable LangGraph checkpointer");
    expect(lifecycle).toContain("general database replication");
    expect(architecture).toContain("general replication link");
  });

  it("links the hosted Intelligence guide to the Rich Threads journey", () => {
    const managed =
      loadDoc("intelligence/managed-intelligence-platform")?.source ?? "";

    expect(managed).toContain("[Rich Threads overview](/threads)");
    expect(managed).toContain("[CopilotKit CLI](/cli)");
    expect(managed).toContain("[Headless Threads](/headless-threads)");
  });

  it("uses the generated Intelligence topic for authored framework nav", () => {
    const navTree = buildFrameworkOnlyNav("ag2");

    expect(navTree.some((node) => node.title === "Premium Features")).toBe(
      false,
    );
    expect(navTree.some((node) => node.title === "Enterprise")).toBe(false);
    expect(hasSectionPage(navTree, "Basics", "Headless Threads")).toBe(true);
    expect(
      sectionNodes(navTree, "Intelligence").map((node) => node.title),
    ).toEqual([
      "Overview",
      "Get started",
      "Rich Threads",
      "Automatic Learning",
      "User Memories",
      "Hosting",
    ]);
    expect(groupPageEntries(navTree, "Get started")).toEqual([
      { title: "Quickstart", slug: "intelligence/quickstart" },
      {
        title: "Architecture",
        slug: "intelligence/intelligence-platform",
      },
      {
        title: "Connect your runtime",
        slug: "intelligence/connect-your-runtime",
      },
    ]);
    expect(
      sectionNodes(navTree, "Intelligence").filter(
        (node) => node.type === "page",
      ),
    ).toMatchObject([
      { type: "page", title: "Overview", slug: "intelligence/overview" },
      { type: "page", title: "Rich Threads", slug: "threads" },
      {
        type: "page",
        title: "Automatic Learning",
        slug: "learning",
      },
      {
        type: "page",
        title: "User Memories",
        slug: "intelligence/memories",
      },
    ]);
    expect(groupPageEntries(navTree, "Hosting")).toEqual([
      {
        title: "Cloud",
        slug: "intelligence/managed-intelligence-platform",
      },
      { title: "Self-hosted", slug: "intelligence/self-hosting" },
    ]);
  });
});
