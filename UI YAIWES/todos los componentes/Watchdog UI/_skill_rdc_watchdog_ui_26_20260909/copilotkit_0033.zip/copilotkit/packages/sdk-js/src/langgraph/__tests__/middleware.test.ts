/**
 * Behavior tests for the CopilotKit LangGraph middleware.
 *
 * The contract these tests pin down (independent of how the middleware is
 * implemented internally — we only assert on what the model handler
 * observes and what state updates the middleware emits):
 *
 * - Frontend tools listed in `state.copilotkit.actions` reach the model
 *   alongside the agent's own tools. Empty actions = no change.
 * - App context from `state.copilotkit.context` (or runtime.context) becomes
 *   a SystemMessage `"App Context:\n<json>"`. Idempotent across re-runs.
 * - `afterModel` peels frontend tool calls off the last AIMessage so the
 *   ToolNode does not execute them; `afterAgent` re-attaches them.
 * - The opt-in `exposeState` knob surfaces user state into
 *   `request.systemPrompt` as a "Current agent state:" note. Default off;
 *   reserved internal keys / `_`-prefixed keys / empty values are filtered;
 *   allowlist forces an explicit subset; existing systemPrompt is kept.
 */

import { describe, it, expect } from "vitest";
import * as z from "zod";
import {
  AIMessage,
  HumanMessage,
  SystemMessage,
} from "@langchain/core/messages";
import { FakeListChatModel } from "@langchain/core/utils/testing";
import { createAgent, createMiddleware } from "langchain";

import {
  copilotkitMiddleware,
  createCopilotkitMiddleware,
  zodState,
} from "../middleware";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeRequest(overrides: any = {}): any {
  return {
    model: { _modelType: () => "fake" },
    messages: [],
    systemPrompt: undefined,
    tools: [],
    state: { messages: [] },
    runtime: {},
    ...overrides,
  };
}

async function runWrap(middleware: any, request: any) {
  let received: any = null;
  const handler = async (req: any) => {
    received = req;
    return { content: "ok" } as any;
  };
  const result = await middleware.wrapModelCall(request, handler);
  expect(received).not.toBeNull();
  return { received, result };
}

function systemContents(messages: any[]): string[] {
  const out: string[] = [];
  for (const m of messages) {
    if (m._getType?.() === "system") {
      out.push(typeof m.content === "string" ? m.content : String(m.content));
    }
  }
  return out;
}

function systemPromptText(request: any): string {
  expect(typeof request.systemPrompt).toBe("string");
  return request.systemPrompt;
}

class CapturingFakeListChatModel extends FakeListChatModel {
  readonly receivedMessages: Array<
    Parameters<FakeListChatModel["_generate"]>[0]
  > = [];

  override async _generate(
    ...args: Parameters<FakeListChatModel["_generate"]>
  ) {
    this.receivedMessages.push(args[0]);
    return super._generate(...args);
  }

  override bindTools() {
    return this;
  }
}

// ---------------------------------------------------------------------------
// Frontend-tool injection
// ---------------------------------------------------------------------------

describe("frontend tool injection", () => {
  it("passes the request through unchanged when there are no frontend tools", async () => {
    const backendTool = { name: "backend" };
    const request = makeRequest({
      state: { messages: [] },
      tools: [backendTool],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    expect(received.tools).toEqual([backendTool]);
  });

  it("merges frontend tools from state.copilotkit.actions with the agent's own tools", async () => {
    const backend = { name: "backend" };
    const fe = [{ name: "fe_one" }, { name: "fe_two" }];
    const request = makeRequest({
      state: { messages: [], copilotkit: { actions: fe } },
      tools: [backend],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name).sort();
    expect(names).toEqual(["backend", "fe_one", "fe_two"]);
  });

  it("does not mutate the input request when merging frontend tools", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        copilotkit: { actions: [{ name: "fe" }] },
      },
      tools: [{ name: "backend" }],
    });

    await runWrap(copilotkitMiddleware, request);

    expect(request.tools.map((t: any) => t.name)).toEqual(["backend"]);
  });
});

// ---------------------------------------------------------------------------
// exposeState — opt-in state surfacing
// ---------------------------------------------------------------------------

describe("exposeState", () => {
  it("surfaces state owned by a sibling middleware during an agent run", async () => {
    const model = new CapturingFakeListChatModel({ responses: ["Hello"] });
    const originalSystemMessage = new SystemMessage({
      content: [
        {
          type: "text",
          text: "You are a helpful assistant.",
          cache_control: { type: "ephemeral" },
        },
      ],
      additional_kwargs: { provider: "anthropic" },
      response_metadata: { model: "claude" },
      id: "system-message-id",
      name: "deep-agent",
    });
    const agentNameMiddleware = createMiddleware({
      name: "AgentNameMiddleware",
      stateSchema: z.object({ agentName: z.string().optional() }),
    });
    const middleware = createCopilotkitMiddleware({
      exposeState: ["agentName"],
    });
    const agent = createAgent({
      model,
      tools: [],
      systemPrompt: originalSystemMessage,
      middleware: [agentNameMiddleware, middleware],
    });

    await agent.invoke({
      messages: [new HumanMessage("What is your name?")],
      agentName: "Mochi",
    });

    const systemMessage = model.receivedMessages[0].find(
      (message) => message._getType() === "system",
    );
    const systemContent = systemMessage?.content;
    expect(Array.isArray(systemContent)).toBe(true);
    if (!Array.isArray(systemContent)) {
      throw new Error("Expected system message content blocks");
    }
    const textBlocks = systemContent.filter(
      (block): block is { type: "text"; text: unknown } =>
        typeof block === "object" &&
        block !== null &&
        "type" in block &&
        block.type === "text",
    );
    expect(textBlocks.length).toBeGreaterThan(0);
    expect(textBlocks.every((block) => typeof block.text === "string")).toBe(
      true,
    );
    expect(textBlocks.map((block) => block.text).join("\n")).toContain(
      '"agentName": "Mochi"',
    );
    expect(systemContent[0]).toEqual(originalSystemMessage.content[0]);
    expect(systemMessage).toMatchObject({
      additional_kwargs: originalSystemMessage.additional_kwargs,
      response_metadata: originalSystemMessage.response_metadata,
      id: originalSystemMessage.id,
      name: originalSystemMessage.name,
    });
  });

  it("is off by default — user state never lands in the system prompt", async () => {
    const request = makeRequest({
      state: { messages: [], liked: ["a", "b"] },
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    expect(received.systemPrompt).toBeUndefined();
  });

  it("surfaces user state into the system prompt when set to true", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: { messages: [], liked: ["a", "b"] },
    });

    const { received } = await runWrap(middleware, request);

    const content = systemPromptText(received);
    expect(content).toContain("Current agent state:");
    expect(content).toContain('"liked"');
    expect(content).toContain('"a"');
    expect(content).toContain('"b"');
  });

  it("skips reserved internal keys when exposing state", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: {
        messages: [new HumanMessage("hi")],
        tools: [{ name: "x" }],
        copilotkit: { actions: [] },
        structured_response: { foo: "bar" },
        thread_id: "t-1",
        remaining_steps: 5,
        "ag-ui": { context: [] },
        liked: ["a"],
      },
    });

    const { received } = await runWrap(middleware, request);

    const body = systemPromptText(received);
    expect(body).toContain('"liked"');
    for (const reserved of [
      "messages",
      "tools",
      "copilotkit",
      "structured_response",
      "thread_id",
      "remaining_steps",
      "ag-ui",
    ]) {
      expect(body).not.toContain(`"${reserved}"`);
    }
  });

  it("skips underscore-prefixed keys when exposing state", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: { messages: [], _internal: { secret: 1 }, visible: "ok" },
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    expect(body).not.toContain('"_internal"');
    expect(body).toContain('"visible"');
  });

  it.each([null, undefined, "", [], {}])(
    "skips keys with empty value %p",
    async (emptyValue) => {
      const middleware = createCopilotkitMiddleware({ exposeState: true });
      const request = makeRequest({
        state: { messages: [], filled: ["x"], blank: emptyValue },
      });

      const { received } = await runWrap(middleware, request);
      if (received.systemPrompt == null) return; // acceptable: nothing left

      const body = systemPromptText(received);
      expect(body).toContain('"filled"');
      expect(body).not.toContain('"blank"');
    },
  );

  it("emits no system prompt when only reserved keys are present", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: { messages: [new HumanMessage("hi")], tools: [] },
    });

    const { received } = await runWrap(middleware, request);

    expect(received.systemPrompt).toBeUndefined();
  });

  it("only includes named keys when given an allowlist", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: ["liked"] });
    const request = makeRequest({
      state: {
        messages: [],
        liked: ["a"],
        todos: [{ id: 1 }],
        other: "x",
      },
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    expect(body).toContain('"liked"');
    expect(body).not.toContain('"todos"');
    expect(body).not.toContain('"other"');
  });

  it("honors an allowlist that explicitly names a normally-reserved key", async () => {
    const middleware = createCopilotkitMiddleware({
      exposeState: ["thread_id"],
    });
    const request = makeRequest({
      state: { messages: [], thread_id: "t-42" },
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    expect(body).toContain("t-42");
  });

  it("appends to an existing string systemPrompt without replacing it", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: { messages: [], liked: ["a"] },
      systemPrompt: "You are a helpful assistant.",
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    expect(body).toContain("You are a helpful assistant.");
    expect(body).toContain("Current agent state:");
    expect(body.indexOf("You are a helpful assistant.")).toBeLessThan(
      body.indexOf("Current agent state:"),
    );
  });

  it("appends to an existing SystemMessage systemPrompt without replacing it", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: { messages: [], liked: ["a"] },
      systemPrompt: new SystemMessage({ content: "base" }),
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    expect(body).toContain("base");
    expect(body).toContain("Current agent state:");
  });

  it("keeps state hidden when explicitly disabled", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: false });
    const request = makeRequest({
      state: { messages: [], liked: ["a"] },
      systemPrompt: "base",
    });

    const { received } = await runWrap(middleware, request);

    expect(received.systemPrompt).toBe("base");
  });

  it("emits a parseable JSON snapshot in the note", async () => {
    const middleware = createCopilotkitMiddleware({ exposeState: true });
    const request = makeRequest({
      state: {
        messages: [],
        liked: ["a", "b"],
        count: 3,
        nested: { k: "v" },
      },
    });

    const { received } = await runWrap(middleware, request);
    const body = systemPromptText(received);

    const jsonPart = body.split("Current agent state:\n")[1];
    expect(JSON.parse(jsonPart)).toEqual({
      liked: ["a", "b"],
      count: 3,
      nested: { k: "v" },
    });
  });
});

// ---------------------------------------------------------------------------
// beforeAgent — App Context injection
// ---------------------------------------------------------------------------

describe("beforeAgent", () => {
  it("returns no update when context is empty", () => {
    const state = {
      messages: [new HumanMessage("hi")],
      copilotkit: { context: [] },
    };
    const result = copilotkitMiddleware.beforeAgent(state, {} as any);
    expect(result).toBeUndefined();
  });

  it("injects an App Context SystemMessage into the message list", () => {
    const state = {
      messages: [new HumanMessage("hi")],
      copilotkit: {
        context: [{ description: "viewer role", value: "admin" }],
      },
    };

    const result = copilotkitMiddleware.beforeAgent(state, {} as any);

    expect(result).toBeDefined();
    const sys = systemContents(result!.messages);
    expect(sys.some((s) => s.startsWith("App Context:"))).toBe(true);
    expect(sys.some((s) => s.includes("admin"))).toBe(true);
  });

  it("uses runtime.context when state.copilotkit.context is missing", () => {
    const state = {
      messages: [new HumanMessage("hi")],
      copilotkit: {},
    };
    const runtime = { context: "route=/dashboard" };

    const result = copilotkitMiddleware.beforeAgent(state, runtime as any);

    const sys = systemContents(result!.messages);
    expect(sys.some((s) => s.includes("/dashboard"))).toBe(true);
  });

  it("does not duplicate the App Context message across re-runs", () => {
    const state = {
      messages: [new HumanMessage("hi")],
      copilotkit: { context: [{ description: "k", value: "v" }] },
    };

    const first = copilotkitMiddleware.beforeAgent(state, {} as any) ?? state;
    const second = copilotkitMiddleware.beforeAgent(first, {} as any) ?? first;

    const appContextMessages = systemContents(second.messages).filter((s) =>
      s.startsWith("App Context:"),
    );
    expect(appContextMessages).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// afterModel — frontend tool-call interception
// ---------------------------------------------------------------------------

describe("afterModel", () => {
  it("is a no-op when there are no frontend tools", () => {
    const state = {
      messages: [
        new HumanMessage("hi"),
        new AIMessage({
          content: "",
          tool_calls: [{ id: "1", name: "backend_only", args: {} }],
        }),
      ],
      copilotkit: { actions: [] },
    };

    expect(copilotkitMiddleware.afterModel(state, {} as any)).toBeUndefined();
  });

  it("peels frontend tool calls off the last AIMessage and stashes them", () => {
    const fe = { function: { name: "navigate" } };
    const ai = new AIMessage({
      content: "",
      tool_calls: [
        { id: "1", name: "backend_search", args: { q: "hi" } },
        { id: "2", name: "navigate", args: { path: "/x" } },
      ],
      id: "ai-1",
    });
    const state = {
      messages: [new HumanMessage("hi"), ai],
      copilotkit: { actions: [fe] },
    };

    const result = copilotkitMiddleware.afterModel(state, {} as any);

    expect(result).toBeDefined();
    const lastAI = result!.messages[result!.messages.length - 1] as AIMessage;
    expect(lastAI.tool_calls?.map((tc: any) => tc.name)).toEqual([
      "backend_search",
    ]);

    const intercepted = result!.copilotkit.interceptedToolCalls;
    expect(intercepted).toHaveLength(1);
    expect(intercepted[0].id).toBe("2");
    expect(intercepted[0].name).toBe("navigate");
    expect(result!.copilotkit.originalAIMessageId).toBe("ai-1");
  });
});

// ---------------------------------------------------------------------------
// afterAgent — frontend tool-call restoration
// ---------------------------------------------------------------------------

describe("afterAgent", () => {
  it("returns no update when there is nothing intercepted", () => {
    const state = {
      messages: [
        new HumanMessage("hi"),
        new AIMessage({ content: "ok", id: "ai-1" }),
      ],
      copilotkit: {},
    };

    expect(copilotkitMiddleware.afterAgent(state, {} as any)).toBeUndefined();
  });

  it("restores intercepted tool calls onto the original AIMessage", () => {
    const intercepted = [{ id: "2", name: "navigate", args: { path: "/x" } }];
    const state = {
      messages: [
        new HumanMessage("hi"),
        new AIMessage({ content: "", id: "ai-1" }),
      ],
      copilotkit: {
        interceptedToolCalls: intercepted,
        originalAIMessageId: "ai-1",
      },
    };

    const result = copilotkitMiddleware.afterAgent(state, {} as any);

    expect(result).toBeDefined();
    const restored = result!.messages.find(
      (m: any) => m.id === "ai-1" && m._getType?.() === "ai",
    ) as AIMessage;
    expect(restored.tool_calls?.map((tc: any) => tc.name)).toEqual([
      "navigate",
    ]);
    expect(result!.copilotkit.interceptedToolCalls).toBeUndefined();
    expect(result!.copilotkit.originalAIMessageId).toBeUndefined();
  });

  it("preserves v1 metadata and content blocks through interception and restoration", () => {
    const backendToolCall = {
      id: "backend-1",
      name: "search",
      args: { query: "CopilotKit" },
    };
    const frontendToolCall = {
      id: "frontend-1",
      name: "navigate",
      args: { path: "/results" },
    };
    const original = new AIMessage({
      content: [
        { type: "reasoning", reasoning: "Search, then open the result." },
        { type: "tool_call", ...backendToolCall },
        { type: "tool_call", ...frontendToolCall },
        {
          type: "tool_call_chunk",
          id: "stale-1",
          name: "stale",
          args: "{}",
        },
      ],
      tool_calls: [backendToolCall, frontendToolCall],
      additional_kwargs: { provider_request_id: "request-1" },
      response_metadata: {
        output_version: "v1",
        status: "completed",
      },
      usage_metadata: {
        input_tokens: 10,
        output_tokens: 5,
        total_tokens: 15,
      },
      invalid_tool_calls: [
        {
          id: "invalid-1",
          name: "broken_tool",
          args: "{",
          error: "Invalid JSON",
          type: "invalid_tool_call",
        },
      ],
      id: "ai-v1",
      name: "assistant-with-tools",
    });
    const state = {
      messages: [new HumanMessage("open the search result"), original],
      copilotkit: { actions: [{ name: "navigate" }] },
    };

    const intercepted = copilotkitMiddleware.afterModel(state, {} as any)!;
    const interceptedMessage = intercepted.messages.at(-1) as AIMessage;
    const interceptedContent = interceptedMessage.content as any[];

    expect(interceptedMessage).toMatchObject({
      additional_kwargs: original.additional_kwargs,
      response_metadata: original.response_metadata,
      usage_metadata: original.usage_metadata,
      invalid_tool_calls: original.invalid_tool_calls,
      id: original.id,
      name: original.name,
      tool_calls: [backendToolCall],
    });
    expect(
      interceptedContent
        .filter((block) => block.type === "tool_call")
        .map((block) => block.name),
    ).toEqual(["search"]);
    expect(
      interceptedContent.some((block) => block.type === "tool_call_chunk"),
    ).toBe(false);

    const restored = copilotkitMiddleware.afterAgent(intercepted, {} as any)!;
    const restoredMessage = restored.messages.at(-1) as AIMessage;
    const restoredContent = restoredMessage.content as any[];

    expect(restoredMessage).toMatchObject({
      additional_kwargs: original.additional_kwargs,
      response_metadata: original.response_metadata,
      usage_metadata: original.usage_metadata,
      invalid_tool_calls: original.invalid_tool_calls,
      id: original.id,
      name: original.name,
      tool_calls: [backendToolCall, frontendToolCall],
    });
    expect(
      restoredContent
        .filter((block) => block.type === "tool_call")
        .map((block) => block.name),
    ).toEqual(["search", "navigate"]);
    expect(restoredContent[0]).toEqual({
      type: "reasoning",
      reasoning: "Search, then open the result.",
    });
  });
});

// ---------------------------------------------------------------------------
// Auto-A2UI — middleware injects + executes generate_a2ui when the frontend
// registered a catalog (surfaced into state["ag-ui"].a2ui_schema)
// ---------------------------------------------------------------------------
//
// Contract: the developer passes nothing — using the middleware is enough.
// generate_a2ui is advertised to the model only when an A2UI catalog is
// present, is built from the agent's own (inferred) model, and is executed by
// the middleware itself (it is never in the agent's static tool registry).

async function runWrapTool(middleware: any, request: any) {
  let received: any = null;
  const handler = async (req: any) => {
    received = req;
    return { content: "tool-ok" } as any;
  };
  await middleware.wrapToolCall(request, handler);
  return received;
}

describe("auto-A2UI injection", () => {
  it("does NOT advertise generate_a2ui when the inject flag is absent", async () => {
    const request = makeRequest({
      state: { messages: [], thread_id: "a2ui-off" },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    expect(received.tools.map((t: any) => t.name)).toEqual(["backend"]);
  });

  it("does NOT advertise generate_a2ui when a catalog is present but the flag is absent (opt-in)", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-noflag",
        "ag-ui": { a2ui_schema: "<components/>" },
      },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name);
    expect(names).not.toContain("generate_a2ui");
    expect(names).toContain("backend");
  });

  it("advertises generate_a2ui (alongside existing tools) when the flag is on", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-on",
        "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
      },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name);
    expect(names).toContain("backend");
    expect(names).toContain("generate_a2ui");
  });

  it("binds to the catalog from copilotkit.context when the flag is on (runtime-proxy path)", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-ctx",
        "ag-ui": { inject_a2ui_tool: true },
        copilotkit: {
          context: [
            {
              description:
                "A2UI catalog capabilities: available catalog IDs and custom component definitions.",
              value:
                "Available A2UI catalog:\n- declarative-gen-ui-catalog\n  - Card: {...}\n  - Metric: {...}",
            },
          ],
        },
      },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name);
    expect(names).toContain("backend");
    expect(names).toContain("generate_a2ui");
  });

  it("executes generate_a2ui via wrapToolCall using the inferred model", async () => {
    const state = {
      messages: [],
      thread_id: "a2ui-exec",
      "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
    };
    // First the model call infers the model + stashes the built tool.
    await runWrap(copilotkitMiddleware, makeRequest({ state, tools: [] }));

    const received = await runWrapTool(copilotkitMiddleware, {
      toolCall: { name: "generate_a2ui", id: "1", args: {} },
      tool: undefined,
      state,
      runtime: {},
    });

    expect(received.tool).toBeDefined();
    expect(received.tool.name).toBe("generate_a2ui");
  });

  it("leaves non-A2UI tool calls untouched", async () => {
    const state = {
      messages: [],
      thread_id: "a2ui-other",
      "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
    };
    await runWrap(copilotkitMiddleware, makeRequest({ state, tools: [] }));

    const backendTool = { name: "backend" };
    const received = await runWrapTool(copilotkitMiddleware, {
      toolCall: { name: "backend", id: "1", args: {} },
      tool: backendTool,
      state,
      runtime: {},
    });

    expect(received.tool).toBe(backendTool);
  });

  it("stops executing generate_a2ui after the run ends (afterAgent clears the bridge)", async () => {
    const state = {
      messages: [],
      thread_id: "a2ui-clean",
      "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
    };
    await runWrap(copilotkitMiddleware, makeRequest({ state, tools: [] }));
    copilotkitMiddleware.afterAgent(state, {} as any);

    const received = await runWrapTool(copilotkitMiddleware, {
      toolCall: { name: "generate_a2ui", id: "1", args: {} },
      tool: undefined,
      state,
      runtime: {},
    });

    expect(received.tool).toBeUndefined();
  });

  // --- A2UI injectA2UITool flag (forwarded → ag-ui state) ------------------

  it("does NOT advertise generate_a2ui when inject_a2ui_tool is false", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-optout",
        "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: false },
      },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name);
    expect(names).not.toContain("generate_a2ui");
    expect(names).toContain("backend");
  });

  it("advertises generate_a2ui when inject_a2ui_tool is true", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-optin",
        "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
      },
      tools: [{ name: "backend" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    expect(received.tools.map((t: any) => t.name)).toContain("generate_a2ui");
  });

  it("drops the runtime's render_a2ui when injecting our generate_a2ui", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-drop",
        "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
        copilotkit: {
          actions: [{ name: "render_a2ui" }, { name: "fe_tool" }],
        },
      },
      tools: [],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const names = received.tools.map((t: any) => t.name);
    expect(names).toContain("generate_a2ui");
    expect(names).toContain("fe_tool");
    expect(names).not.toContain("render_a2ui");
  });

  it("does NOT double-inject when the agent already defines generate_a2ui", async () => {
    const request = makeRequest({
      state: {
        messages: [],
        thread_id: "a2ui-dup",
        "ag-ui": { a2ui_schema: "<components/>", inject_a2ui_tool: true },
      },
      tools: [{ name: "generate_a2ui" }],
    });

    const { received } = await runWrap(copilotkitMiddleware, request);

    const count = received.tools.filter(
      (t: any) => t.name === "generate_a2ui",
    ).length;
    expect(count).toBe(1);
  });
});

// ---------------------------------------------------------------------------
// zodState — Standard-Schema JSON-schema augmentation
// ---------------------------------------------------------------------------
//
// Contract: a Zod v4 schema only carries `~standard.validate` + `vendor`, so
// LangGraph's `isStandardJSONSchema()` returns false and the field is dropped
// from `output_schema`. `zodState` patches `~standard.jsonSchema.input` onto
// the schema so the field survives serialization and reaches the frontend
// via AG-UI `STATE_SNAPSHOT` events.

type JsonSchema = {
  type?: string;
  properties?: Record<string, unknown>;
};
type StdJson = { jsonSchema?: { input: () => JsonSchema } };
const standardOf = (s: object): StdJson | undefined =>
  (s as { "~standard"?: StdJson })["~standard"];
const hasZodV4ToJsonSchema = (): boolean =>
  typeof (z as { toJSONSchema?: unknown }).toJSONSchema === "function";

describe("zodState", () => {
  it("attaches a ~standard.jsonSchema.input hook to a Zod schema", () => {
    const schema = z.object({ name: z.string() });
    expect(standardOf(schema)?.jsonSchema).toBeUndefined();

    const wrapped = zodState(schema);

    const std = standardOf(wrapped);
    expect(std?.jsonSchema).toBeDefined();
    expect(typeof std?.jsonSchema?.input).toBe("function");
  });

  it("returns a plain object from input() (real JSON Schema when zod v4 is available, else `{}`)", () => {
    // The contract langgraph cares about is just "input() returns an
    // object" — `isStandardJSONSchema()` doesn't introspect the shape.
    // When zod v4's `toJSONSchema` is present we get the real schema;
    // otherwise we get `{}`, which is still enough for the field to
    // appear in `output_schema` (langgraph-api treats it as opaque).
    const schema = z.object({ todos: z.array(z.string()) });
    const wrapped = zodState(schema);

    const json = standardOf(wrapped)?.jsonSchema?.input();

    expect(json).toBeTypeOf("object");
    expect(json).not.toBeNull();
    if (hasZodV4ToJsonSchema()) {
      expect(json?.type).toBe("object");
      expect(json?.properties?.todos).toBeDefined();
    }
  });

  it("caches the JSON Schema across calls (input() returns the same object)", () => {
    const schema = z.object({ x: z.string() });
    const wrapped = zodState(schema);
    const std = standardOf(wrapped);

    const a = std?.jsonSchema?.input();
    const b = std?.jsonSchema?.input();

    expect(a).toBe(b);
  });

  it("does not overwrite an existing jsonSchema hook", () => {
    const schema = z.object({ x: z.string() });
    const preset: StdJson["jsonSchema"] = { input: () => ({}) };
    const std = standardOf(schema);
    expect(std).toBeDefined();
    std!.jsonSchema = preset;

    zodState(schema);

    expect(standardOf(schema)?.jsonSchema).toBe(preset);
  });

  it("returns the same reference (mutates rather than copies)", () => {
    const schema = z.object({ x: z.string() });
    expect(zodState(schema)).toBe(schema);
  });

  it("is a no-op for a value without ~standard metadata", () => {
    const plain = { foo: "bar" };
    expect(() => zodState(plain)).not.toThrow();
    expect(zodState(plain)).toBe(plain);
  });

  it("works on optional / array / default-wrapped schemas (state-field shapes)", () => {
    const todos = zodState(
      z.array(z.object({ id: z.string(), text: z.string() })).default(() => []),
    );

    const std = standardOf(todos);
    expect(std).toBeDefined();
    expect(std?.jsonSchema).toBeDefined();
    const json = std?.jsonSchema?.input();
    expect(json).toBeTypeOf("object");
    if (hasZodV4ToJsonSchema()) {
      expect(json?.type).toBe("array");
    }
  });

  it("makes the wrapped field pass a StandardJSONSchemaV1-style probe", () => {
    // Mirrors what LangGraph's isStandardJSONSchema() looks for: an `input`
    // function on `~standard.jsonSchema` that returns a plain object.
    const schema = zodState(z.object({ liked: z.array(z.string()) }));
    const std = standardOf(schema);

    expect(std?.jsonSchema).toBeDefined();
    expect(typeof std?.jsonSchema?.input).toBe("function");
    expect(typeof std?.jsonSchema?.input()).toBe("object");
  });
});
