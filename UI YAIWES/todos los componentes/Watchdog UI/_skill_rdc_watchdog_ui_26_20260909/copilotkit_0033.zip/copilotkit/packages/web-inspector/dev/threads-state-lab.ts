import type { CopilotKitCore, Memory } from "@copilotkit/core";
import type { InspectorMetadataV1, RuntimeInfo } from "@copilotkit/shared";
import type { WebInspectorElement } from "@copilotkit/web-inspector";

import {
  LEARNING_WORKBENCH_SCENARIOS,
  learningRuntimeInfo,
} from "./learning-state-fixtures.js";
import type {
  LearningScreenshotState,
  LearningWorkbenchScenarioKey,
} from "./learning-state-fixtures.js";

export const CORE_SCENARIO_KEYS = [
  "pro-enabled-zero",
  "pro-enabled-existing",
  "pro-disabled-zero",
  "pro-disabled-existing",
  "team-enabled-zero",
  "team-enabled-existing",
  "team-disabled-zero",
  "team-disabled-existing",
  "enterprise-enabled-zero",
  "enterprise-enabled-existing",
  "enterprise-disabled-zero",
  "enterprise-disabled-existing",
  "self-hosted-enabled-zero",
  "self-hosted-enabled-existing",
  "self-hosted-disabled-zero",
  "self-hosted-disabled-existing",
] as const;

export const EDGE_SCENARIO_KEYS = [
  "free-figma-148-of-200",
  "free-overage-241-of-200",
  "pro-warning-4500-of-5000",
  "pro-at-limit-5000-of-5000",
  "oss-no-metadata-enabled-zero",
  "capability-absent",
  "unknown-limit",
  "missing-expiry",
  "malformed-expiry",
  "usage-only",
  "action-only",
  "license-none",
  "license-expired",
  "agent-run-error",
  "thread-list-error",
  "video-error",
  "reduced-motion",
  "telemetry-disabled",
] as const;

export const LEARNING_SCENARIO_KEYS: readonly LearningWorkbenchScenarioKey[] =
  LEARNING_WORKBENCH_SCENARIOS.map(({ key }) => key);

export const ALL_SCENARIO_KEYS = [
  ...CORE_SCENARIO_KEYS,
  ...LEARNING_SCENARIO_KEYS,
  ...EDGE_SCENARIO_KEYS,
] as const;

export type ScenarioKey = (typeof ALL_SCENARIO_KEYS)[number];

export const THREAD_REQUEST_KINDS = [
  "list",
  "subscribe",
  "inspect",
  "messages",
  "events",
  "state",
] as const;

export type ThreadRequestKind = (typeof THREAD_REQUEST_KINDS)[number];

export type ThreadRequestCounters = Readonly<Record<ThreadRequestKind, number>>;

export type ThreadFixture = Readonly<{
  id: string;
  organizationId: string;
  agentId: string;
  createdById: string;
  name: string;
  archived: false;
  createdAt: string;
  updatedAt: string;
}>;

export type ThreadDetailsFixture = Readonly<{
  messages: readonly Readonly<Record<string, unknown>>[];
  events: readonly Readonly<Record<string, unknown>>[];
  state: Readonly<Record<string, unknown>>;
}>;

export interface ThreadsStateScenario {
  readonly key: ScenarioKey;
  readonly label: string;
  readonly description: string;
  readonly deployment: "managed" | "self_hosted" | "oss";
  readonly plan: "free" | "pro" | "team" | "enterprise" | "oss";
  readonly capability: "enabled" | "disabled" | "absent";
  readonly data: "zero" | "existing" | "error";
  readonly agentId: string;
  readonly runtimeInfo: Readonly<RuntimeInfo>;
  readonly inspectorMetadata?: Readonly<InspectorMetadataV1>;
  readonly inspectorMetadataBody?: unknown;
  readonly threads: readonly ThreadFixture[];
  readonly details: Readonly<Record<string, ThreadDetailsFixture>>;
  readonly expectedRequests: ThreadRequestCounters;
  readonly expectedNewestThreadId?: string;
  readonly joinCode: string;
  readonly joinToken: string;
  readonly listError?: Readonly<{ status: number; message: string }>;
  readonly initialMenu?: "home" | "threads" | "memories";
  readonly initialAgentEvents?: readonly Readonly<{
    type: "RUN_ERROR";
    runId: string;
    message: string;
    code: string;
  }>[];
  readonly media: "normal" | "video_error" | "reduced_motion";
  readonly learning: "enabled" | "disabled";
  readonly memories: readonly Memory[];
  readonly learningState?: LearningScreenshotState;
}

const INSPECTOR_STATE_STORAGE_KEY = "cpk:inspector:state";
const ANNOUNCEMENT_READ_STORAGE_KEY = "cpk:inspector:announcement_read";
const ANNOUNCEMENT_PULSED_SESSION_KEY = "cpk:inspector:pulsed";
const ANNOUNCEMENT_READ_COOKIE_NAME = "cpk_inspector_announcements";
const INSPECTOR_DISMISSAL_STORAGE_KEY = "cpk:inspector:dismissed_until";
const INSPECTOR_DISMISSAL_COOKIE_NAME = "cpk_inspector_dismissed_until";
const LEARNING_SETUP_STORAGE_KEY = "cpk:inspector:learning-setup:v1";
const REPLAY_NOTIFICATION_QUERY_KEY = "replay-notification";

export const LAB_RESET_STORAGE_KEYS = [
  INSPECTOR_STATE_STORAGE_KEY,
  "cpk:inspector:threads-example-tour:v1",
  INSPECTOR_DISMISSAL_STORAGE_KEY,
  LEARNING_SETUP_STORAGE_KEY,
] as const;

export const DEFAULT_SCENARIO_KEY: ScenarioKey = "free-figma-148-of-200";

const AGENT_ID = "threads-lab-agent";
const ORGANIZATION_ID = "threads-lab-organization";
const USER_ID = "threads-lab-user";
const MANAGE_PLAN_URL =
  "https://intelligence.copilotkit.ai/account/organization/org_demo_inspector/organization-billing";
const ENABLE_INTELLIGENCE_URL =
  "https://intelligence.copilotkit.ai/intelligence/enable";
const RENEW_URL = "https://intelligence.copilotkit.ai/settings/license";

const ZERO_COUNTERS: ThreadRequestCounters = {
  list: 0,
  subscribe: 0,
  inspect: 0,
  messages: 0,
  events: 0,
  state: 0,
};

const ENABLED_ENDPOINTS = {
  list: true,
  inspect: true,
  mutations: true,
  realtimeMetadata: true,
} as const;

const DISABLED_ENDPOINTS = {
  list: false,
  inspect: false,
  mutations: false,
  realtimeMetadata: false,
} as const;

const RECORDING_THREADS = [
  {
    name: "Plan onboarding follow-up",
    updatedAt: "2026-07-30T09:24:00.000Z",
  },
  {
    name: "Product recommendation review",
    updatedAt: "2026-07-31T18:55:00.000Z",
  },
  {
    name: "Account access troubleshooting",
    updatedAt: "2026-08-01T10:41:00.000Z",
  },
  {
    name: "Subscription renewal question",
    updatedAt: "2026-08-01T22:17:00.000Z",
  },
  {
    name: "Checkout support follow-up",
    updatedAt: "2026-08-02T13:22:00.000Z",
  },
  {
    name: "Billing escalation handoff",
    updatedAt: "2026-08-02T19:08:00.000Z",
  },
  {
    name: "AI Tooling Retrospective Report",
    updatedAt: "2026-08-03T09:45:00.000Z",
  },
  {
    name: "Data Centers and Water",
    updatedAt: "2026-08-03T17:12:00.000Z",
  },
  {
    name: "View Storage Naming Suggestions",
    updatedAt: "2026-08-03T21:30:00.000Z",
  },
  {
    name: "Catching a Throwed Roll in Every Lambert's Cafe",
    updatedAt: "2026-08-04T11:05:00.000Z",
  },
  {
    name: "Queue Management in k8s",
    updatedAt: "2026-08-04T14:18:00.000Z",
  },
  {
    name: "Flights from Chicago to Orlando",
    updatedAt: "2026-08-04T16:42:00.000Z",
  },
] as const;

const MINUTE_MS = 60 * 1_000;

/** Recursively freezes a fixture graph without changing its values. */
export function deepFreeze<T>(value: T): T {
  if (typeof value !== "object" || value === null || Object.isFrozen(value)) {
    return value;
  }
  for (const key of Reflect.ownKeys(value)) {
    deepFreeze(Reflect.get(value, key));
  }
  return Object.freeze(value);
}

function runtimeInfo(
  key: ScenarioKey,
  options: Readonly<{
    capability: ThreadsStateScenario["capability"];
    licenseStatus?: RuntimeInfo["licenseStatus"];
    metadata?: boolean;
    telemetryDisabled?: boolean;
  }>,
): RuntimeInfo {
  return {
    version: `threads-state-lab:${key}`,
    agents: {
      [AGENT_ID]: {
        name: AGENT_ID,
        className: "HttpAgent",
        description: "Deterministic local Inspector Threads lab agent",
      },
    },
    audioFileTranscriptionEnabled: false,
    mode: "intelligence",
    intelligence: {
      wsUrl: `ws://127.0.0.1:5177/inspector-lab-runtime/${key}/realtime`,
    },
    ...(options.capability === "absent"
      ? {}
      : {
          threadEndpoints:
            options.capability === "enabled"
              ? ENABLED_ENDPOINTS
              : DISABLED_ENDPOINTS,
        }),
    ...(options.metadata === false ? {} : { inspectorMetadata: true }),
    suggestions: false,
    a2uiEnabled: false,
    openGenerativeUIEnabled: false,
    licenseStatus: options.licenseStatus ?? "valid",
    telemetryDisabled: options.telemetryDisabled ?? false,
  };
}

function threadFixtures(prefix: string): readonly ThreadFixture[] {
  return [
    {
      id: `${prefix}-thread-earlier`,
      organizationId: ORGANIZATION_ID,
      agentId: AGENT_ID,
      createdById: USER_ID,
      name: "Plan onboarding follow-up",
      archived: false,
      createdAt: "2026-07-28T09:00:00.000Z",
      updatedAt: "2026-07-28T09:24:00.000Z",
    },
    {
      id: `${prefix}-thread-newest`,
      organizationId: ORGANIZATION_ID,
      agentId: AGENT_ID,
      createdById: USER_ID,
      name: "Inspector launch review",
      archived: false,
      createdAt: "2026-08-02T15:00:00.000Z",
      updatedAt: "2026-08-03T16:42:00.000Z",
    },
  ];
}

function recordingThreadFixtures(prefix: string): readonly ThreadFixture[] {
  return RECORDING_THREADS.map(({ name, updatedAt }, index) => {
    const updatedAtMs = Date.parse(updatedAt);
    const createdAtMs = updatedAtMs - (24 + (index % 5) * 9) * MINUTE_MS;

    return {
      id: `${prefix}-thread-${String(index + 1).padStart(2, "0")}`,
      organizationId: ORGANIZATION_ID,
      agentId: AGENT_ID,
      createdById: USER_ID,
      name,
      archived: false,
      createdAt: new Date(createdAtMs).toISOString(),
      updatedAt,
    };
  });
}

function threadDetails(
  threads: readonly ThreadFixture[],
): Readonly<Record<string, ThreadDetailsFixture>> {
  const readyThreadId = newestThreadId(threads);
  return Object.fromEntries(
    threads.map((thread) => {
      const eventStartMs = Date.parse(thread.updatedAt) - 2_000;

      return [
        thread.id,
        {
          messages: [
            {
              id: `${thread.id}-user-message`,
              role: "user",
              content: "Show the saved Inspector thread details.",
            },
            {
              id: `${thread.id}-assistant-message`,
              role: "assistant",
              content: "This response came from the local scenario lab.",
            },
          ],
          events: [
            {
              type: "RUN_STARTED",
              timestamp: new Date(eventStartMs).toISOString(),
              payload: { runId: `${thread.id}-run` },
            },
            {
              type: "TEXT_MESSAGE_CONTENT",
              timestamp: new Date(eventStartMs + 1_000).toISOString(),
              payload: {
                messageId: `${thread.id}-assistant-message`,
                delta: "Local scenario detail event",
              },
            },
            {
              type: "RUN_FINISHED",
              timestamp: new Date(eventStartMs + 2_000).toISOString(),
              payload: { runId: `${thread.id}-run` },
            },
          ],
          state: {
            source: "threads-state-lab",
            threadId: thread.id,
            reviewStatus: thread.id === readyThreadId ? "ready" : "draft",
          },
        },
      ];
    }),
  );
}

function newestThreadId(threads: readonly ThreadFixture[]): string | undefined {
  return threads.reduce<ThreadFixture | undefined>((newest, thread) => {
    if (!newest) return thread;
    return Date.parse(thread.updatedAt) > Date.parse(newest.updatedAt)
      ? thread
      : newest;
  }, undefined)?.id;
}

function expectedRequests(
  capability: ThreadsStateScenario["capability"],
  data: ThreadsStateScenario["data"],
): ThreadRequestCounters {
  if (capability !== "enabled") return { ...ZERO_COUNTERS };
  if (data === "error") return { ...ZERO_COUNTERS, list: 1 };
  if (data === "zero") {
    return { ...ZERO_COUNTERS, list: 1, subscribe: 1 };
  }
  return {
    ...ZERO_COUNTERS,
    list: 1,
    subscribe: 1,
    events: 1,
    messages: 1,
  };
}

function metadata(
  plan: ThreadsStateScenario["plan"],
  options: Readonly<{
    used: number;
    limit: NonNullable<InspectorMetadataV1["usage"]>["limit"];
    expiringSoonCount?: number;
    deployment?: ThreadsStateScenario["deployment"];
    action?: NonNullable<InspectorMetadataV1["action"]>;
  }>,
): InspectorMetadataV1 {
  const selfHosted = options.deployment === "self_hosted";
  const label =
    plan === "free"
      ? "Free"
      : plan === "pro"
        ? "Pro"
        : plan === "enterprise"
          ? "Enterprise"
          : "Team";
  return {
    schemaVersion: 1,
    identity: {
      organizationName:
        options.deployment === "self_hosted"
          ? "Local CopilotKit"
          : "Northstar Labs",
      projectName: "Inspector launch",
    },
    plan: selfHosted
      ? { code: "team_self_hosted", label: "Team Self-Hosted" }
      : { code: plan, label },
    license: { state: "valid" },
    ...(options.action ? { action: options.action } : {}),
    usage: {
      used: options.used,
      limit: options.limit,
      ...(options.expiringSoonCount === undefined
        ? {}
        : { expiringSoonCount: options.expiringSoonCount }),
    },
  };
}

function buildScenario(
  input: Omit<
    ThreadsStateScenario,
    | "agentId"
    | "details"
    | "expectedRequests"
    | "expectedNewestThreadId"
    | "joinCode"
    | "joinToken"
    | "learning"
    | "memories"
  > &
    Partial<Pick<ThreadsStateScenario, "learning" | "memories">>,
): ThreadsStateScenario {
  const expectedNewestThreadId = newestThreadId(input.threads);
  const initialExpectedRequests = expectedRequests(
    input.capability,
    input.data,
  );
  return {
    ...input,
    agentId: AGENT_ID,
    details: threadDetails(input.threads),
    expectedRequests:
      input.initialMenu === "memories"
        ? {
            ...initialExpectedRequests,
            inspect: 0,
            state: 0,
          }
        : initialExpectedRequests,
    ...(expectedNewestThreadId ? { expectedNewestThreadId } : {}),
    joinCode: `threads-lab-${input.key}`,
    joinToken: `threads-lab-token-${input.key}`,
    learning: input.learning ?? "disabled",
    memories: input.memories ?? [],
  };
}

function buildCoreScenario(key: (typeof CORE_SCENARIO_KEYS)[number]) {
  const selfHosted = key.startsWith("self-hosted-");
  const plan: ThreadsStateScenario["plan"] = selfHosted
    ? "team"
    : key.startsWith("pro-")
      ? "pro"
      : key.startsWith("team-")
        ? "team"
        : "enterprise";
  const capability: ThreadsStateScenario["capability"] = key.includes(
    "-enabled-",
  )
    ? "enabled"
    : "disabled";
  const data: ThreadsStateScenario["data"] = key.endsWith("-existing")
    ? "existing"
    : "zero";
  const threads = data === "existing" ? threadFixtures(key) : [];
  const limit =
    plan === "enterprise"
      ? ({ kind: "unlimited" } as const)
      : ({
          kind: "finite",
          value: plan === "pro" ? 5_000 : 25_000,
        } as const);
  const used =
    data === "zero"
      ? 0
      : plan === "pro"
        ? 122
        : plan === "enterprise"
          ? 1_204
          : 604;
  const action =
    !selfHosted && (plan === "pro" || plan === "team")
      ? ({ kind: "manage_plan", url: MANAGE_PLAN_URL } as const)
      : undefined;
  const inspectorMetadata = metadata(plan, {
    used,
    limit,
    expiringSoonCount:
      data === "zero" ? 0 : plan === "enterprise" ? 0 : plan === "pro" ? 7 : 18,
    deployment: selfHosted ? "self_hosted" : "managed",
    ...(action ? { action } : {}),
  });

  return buildScenario({
    key,
    label: `${selfHosted ? "Self-hosted Team" : inspectorMetadata.plan?.label} · ${capability} · ${data}`,
    description: `${data === "existing" ? "Two saved threads" : "No saved threads"}; Thread API ${capability}.`,
    deployment: selfHosted ? "self_hosted" : "managed",
    plan,
    capability,
    data,
    runtimeInfo: runtimeInfo(key, { capability }),
    inspectorMetadata,
    inspectorMetadataBody: inspectorMetadata,
    threads,
    media: "normal",
  });
}

function edgeScenario(
  key: (typeof EDGE_SCENARIO_KEYS)[number],
): ThreadsStateScenario {
  const existing = threadFixtures(key);
  const free148 = metadata("free", {
    used: 148,
    limit: { kind: "finite", value: 200 },
    expiringSoonCount: 37,
    action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
  });
  const defaultExisting = metadata("free", {
    used: 36,
    limit: { kind: "finite", value: 200 },
    expiringSoonCount: 4,
    action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
  });
  const zeroFree = metadata("free", {
    used: 0,
    limit: { kind: "finite", value: 200 },
    expiringSoonCount: 0,
    action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
  });
  const base = {
    key,
    deployment: "managed" as const,
    plan: "free" as const,
    capability: "enabled" as const,
    data: "existing" as const,
    runtimeInfo: runtimeInfo(key, { capability: "enabled" }),
    inspectorMetadata: defaultExisting,
    inspectorMetadataBody: defaultExisting,
    threads: existing,
    media: "normal" as const,
  };

  switch (key) {
    case "free-figma-148-of-200":
      return buildScenario({
        ...base,
        label: "Free · Figma 148 / 200",
        description:
          "Twelve saved rows for the fixed lab user and agent with organization-wide 148 / 200 usage and 37 expiring soon.",
        inspectorMetadata: free148,
        inspectorMetadataBody: free148,
        threads: recordingThreadFixtures(key),
      });
    case "free-overage-241-of-200": {
      const overage = metadata("free", {
        used: 241,
        limit: { kind: "finite", value: 200 },
        expiringSoonCount: 0,
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      return buildScenario({
        ...base,
        label: "Free · over limit",
        description: "Raw 241 / 200 renders as 200+ / 200 at 100%.",
        inspectorMetadata: overage,
        inspectorMetadataBody: overage,
      });
    }
    case "pro-warning-4500-of-5000": {
      const warning = metadata("pro", {
        used: 4_500,
        limit: { kind: "finite", value: 5_000 },
        expiringSoonCount: 12,
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      return buildScenario({
        ...base,
        label: "Pro · near limit 4500 / 5000",
        description:
          "Exactly 90% usage renders an orange bar and Upgrade Your Plan.",
        plan: "pro",
        inspectorMetadata: warning,
        inspectorMetadataBody: warning,
      });
    }
    case "pro-at-limit-5000-of-5000": {
      const atLimit = metadata("pro", {
        used: 5_000,
        limit: { kind: "finite", value: 5_000 },
        expiringSoonCount: 0,
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      return buildScenario({
        ...base,
        label: "Pro · at limit 5000 / 5000",
        description:
          "Exactly 100% usage renders a red bar and Upgrade Your Plan.",
        plan: "pro",
        inspectorMetadata: atLimit,
        inspectorMetadataBody: atLimit,
      });
    }
    case "oss-no-metadata-enabled-zero":
      return buildScenario({
        ...base,
        label: "OSS · no metadata · enabled · zero",
        description: "Explicit Threads capability with no metadata body.",
        deployment: "oss",
        plan: "oss",
        data: "zero",
        runtimeInfo: runtimeInfo(key, {
          capability: "enabled",
          metadata: false,
          licenseStatus: undefined,
        }),
        inspectorMetadata: undefined,
        inspectorMetadataBody: undefined,
        threads: [],
      });
    case "capability-absent":
      return buildScenario({
        ...base,
        label: "Capability absent",
        description: "Seeded rows stay unreachable without threadEndpoints.",
        capability: "absent",
        runtimeInfo: runtimeInfo(key, { capability: "absent" }),
      });
    case "unknown-limit": {
      const value = metadata("free", {
        used: 36,
        limit: { kind: "unknown" },
        expiringSoonCount: 4,
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      return buildScenario({
        ...base,
        label: "Unknown limit",
        description: "Usage count without a progress denominator.",
        inspectorMetadata: value,
        inspectorMetadataBody: value,
      });
    }
    case "missing-expiry": {
      const value = metadata("free", {
        used: 36,
        limit: { kind: "finite", value: 200 },
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      return buildScenario({
        ...base,
        label: "Missing expiry",
        description: "Valid usage omits the expiry leaf.",
        inspectorMetadata: value,
        inspectorMetadataBody: value,
      });
    }
    case "malformed-expiry": {
      const value = metadata("free", {
        used: 36,
        limit: { kind: "finite", value: 200 },
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      });
      const body = {
        ...value,
        usage: { ...value.usage, expiringSoonCount: "invalid" },
      };
      return buildScenario({
        ...base,
        label: "Malformed expiry",
        description: "Untrusted string expiry is ignored without losing usage.",
        inspectorMetadata: value,
        inspectorMetadataBody: body,
      });
    }
    case "usage-only": {
      const value: InspectorMetadataV1 = {
        schemaVersion: 1,
        usage: {
          used: 36,
          limit: { kind: "finite", value: 200 },
          expiringSoonCount: 4,
        },
      };
      return buildScenario({
        ...base,
        label: "Usage only",
        description:
          "Usage renders without identity, plan, license, or action.",
        inspectorMetadata: value,
        inspectorMetadataBody: value,
      });
    }
    case "action-only": {
      const value: InspectorMetadataV1 = {
        schemaVersion: 1,
        license: { state: "valid" },
        action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
      };
      return buildScenario({
        ...base,
        label: "Action only",
        description: "A valid plan action does not invent usage.",
        data: "zero",
        inspectorMetadata: value,
        inspectorMetadataBody: value,
        threads: [],
      });
    }
    case "license-none": {
      const value: InspectorMetadataV1 = {
        schemaVersion: 1,
        license: { state: "none" },
        action: {
          kind: "enable_intelligence",
          url: ENABLE_INTELLIGENCE_URL,
        },
      };
      return buildScenario({
        ...base,
        label: "License not enabled",
        description: "Locked Threads with a matching enable action.",
        capability: "disabled",
        runtimeInfo: runtimeInfo(key, {
          capability: "disabled",
          licenseStatus: "none",
        }),
        inspectorMetadata: value,
        inspectorMetadataBody: value,
      });
    }
    case "license-expired": {
      const value: InspectorMetadataV1 = {
        schemaVersion: 1,
        license: { state: "expired" },
        action: { kind: "renew", url: RENEW_URL },
      };
      return buildScenario({
        ...base,
        label: "License expired",
        description: "Locked Threads with a matching renewal action.",
        capability: "disabled",
        runtimeInfo: runtimeInfo(key, {
          capability: "disabled",
          licenseStatus: "expired",
        }),
        inspectorMetadata: value,
        inspectorMetadataBody: value,
      });
    }
    case "agent-run-error":
      return buildScenario({
        ...base,
        label: "Agent run error",
        description:
          "A CopilotKit agent emits RunError so System Health shows an actionable failure.",
        initialMenu: "home",
        initialAgentEvents: [
          {
            type: "RUN_ERROR",
            runId: "threads-lab-run-error",
            message: "The agent could not complete this run.",
            code: "AGENT_RUN_ERROR",
          },
        ],
      });
    case "thread-list-error":
      return buildScenario({
        ...base,
        label: "Thread list error",
        description: "The enabled list route fails without showing examples.",
        data: "error",
        threads: [],
        listError: {
          status: 503,
          message: "Thread list unavailable in this lab scenario.",
        },
      });
    case "video-error":
      return buildScenario({
        ...base,
        label: "Video error",
        description: "CSP blocks media while examples and tour stay usable.",
        data: "zero",
        inspectorMetadata: zeroFree,
        inspectorMetadataBody: zeroFree,
        threads: [],
        media: "video_error",
      });
    case "reduced-motion":
      return buildScenario({
        ...base,
        label: "Reduced motion",
        description: "The demo starts paused for reduced-motion users.",
        data: "zero",
        inspectorMetadata: zeroFree,
        inspectorMetadataBody: zeroFree,
        threads: [],
        media: "reduced_motion",
      });
    case "telemetry-disabled":
      return buildScenario({
        ...base,
        label: "Telemetry disabled",
        description: "The full Inspector works with telemetry opted out.",
        runtimeInfo: runtimeInfo(key, {
          capability: "enabled",
          telemetryDisabled: true,
        }),
      });
  }
}

function buildLearningScenario(
  descriptor: (typeof LEARNING_WORKBENCH_SCENARIOS)[number],
): ThreadsStateScenario {
  const { key, label, state } = descriptor;
  const inspectorMetadata = metadata("pro", {
    used: 0,
    limit: { kind: "finite", value: 5_000 },
    expiringSoonCount: 0,
    action: { kind: "manage_plan", url: MANAGE_PLAN_URL },
  });

  return buildScenario({
    key,
    label: `Automatic Learning · ${label}`,
    description: `Integrated Inspector fixture for the ${label.toLowerCase()} state.`,
    deployment: "managed",
    plan: "pro",
    capability: "absent",
    data: "zero",
    runtimeInfo: learningRuntimeInfo(state),
    inspectorMetadata,
    inspectorMetadataBody: inspectorMetadata,
    threads: [],
    media: "normal",
    initialMenu: "memories",
    learning: "disabled",
    memories: [],
    learningState: state,
  });
}

const scenarios = [
  ...CORE_SCENARIO_KEYS.map(buildCoreScenario),
  ...LEARNING_WORKBENCH_SCENARIOS.map(buildLearningScenario),
  ...EDGE_SCENARIO_KEYS.map(edgeScenario),
];

export const THREADS_STATE_SCENARIOS = deepFreeze(
  Object.fromEntries(
    scenarios.map((scenario) => [scenario.key, scenario]),
  ) as Record<ScenarioKey, ThreadsStateScenario>,
);

deepFreeze(CORE_SCENARIO_KEYS);
deepFreeze(LEARNING_SCENARIO_KEYS);
deepFreeze(EDGE_SCENARIO_KEYS);
deepFreeze(ALL_SCENARIO_KEYS);
deepFreeze(THREAD_REQUEST_KINDS);
deepFreeze(LAB_RESET_STORAGE_KEYS);

/** Returns one immutable fixture or throws for programmer input. */
export function getThreadsStateScenario(
  key: ScenarioKey,
): ThreadsStateScenario {
  return THREADS_STATE_SCENARIOS[key];
}

/**
 * Seeds the Inspector with deterministic agent events for a test-bench route.
 * This is intentionally scoped to the local lab: production events continue to
 * arrive through the agent subscription in the Inspector itself.
 */
export function seedThreadsStateLabAgentEvents(
  inspector: WebInspectorElement,
  scenario: ThreadsStateScenario,
): void {
  const recordAgentEvent = Reflect.get(inspector, "recordAgentEvent");
  if (typeof recordAgentEvent !== "function") {
    throw new Error("Inspector event recorder was unavailable in the lab.");
  }

  for (const event of scenario.initialAgentEvents ?? []) {
    Reflect.apply(recordAgentEvent, inspector, [
      scenario.agentId,
      event.type,
      {
        type: event.type,
        runId: event.runId,
        message: event.message,
        code: event.code,
      },
    ]);
  }
}

/** Parses an untrusted route key and reports an explicit fallback. */
export function parseScenarioKey(
  value: string | null,
): Readonly<{ scenarioKey: ScenarioKey; rejectedKey?: string }> {
  if (value === null || value.length === 0) {
    return { scenarioKey: DEFAULT_SCENARIO_KEY };
  }
  if ((ALL_SCENARIO_KEYS as readonly string[]).includes(value)) {
    return { scenarioKey: value as ScenarioKey };
  }
  return { scenarioKey: DEFAULT_SCENARIO_KEY, rejectedKey: value };
}

/** Builds the canonical loopback Runtime URL for a scenario. */
export function runtimeUrlFor(origin: string, key: ScenarioKey): string {
  return `${origin.replace(/\/+$/, "")}/inspector-lab-runtime/${key}`;
}

/** Builds the canonical recordable direct link. */
export function canonicalScenarioUrl(origin: string, key: ScenarioKey): string {
  const url = new URL("/", origin);
  url.searchParams.set("scenario", key);
  url.searchParams.set("reset", "1");
  return url.href;
}

/** Runs full fixture teardown before assigning one canonical scenario link. */
export async function navigateThreadsStateLabScenario(
  location: Readonly<{
    origin: string;
    assign(url: string): void;
  }>,
  key: ScenarioKey,
  teardown: () => Promise<void>,
): Promise<string> {
  await teardown();
  const directLink = canonicalScenarioUrl(location.origin, key);
  location.assign(directLink);
  return directLink;
}

/** Wires scenario selection and reset controls to one guarded navigation path. */
export function installThreadsStateLabNavigation(
  scenarioSelect: HTMLSelectElement,
  resetButton: HTMLButtonElement,
  currentScenarioKey: ScenarioKey,
  navigate: (key: ScenarioKey) => Promise<void>,
  reportError: (error: unknown) => void,
): () => void {
  const handleScenarioChange = (): void => {
    const next = parseScenarioKey(scenarioSelect.value).scenarioKey;
    navigate(next).catch(reportError);
  };
  const handleReset = (): void => {
    navigate(currentScenarioKey).catch(reportError);
  };
  scenarioSelect.addEventListener("change", handleScenarioChange);
  resetButton.addEventListener("click", handleReset);
  return () => {
    scenarioSelect.removeEventListener("change", handleScenarioChange);
    resetButton.removeEventListener("click", handleReset);
  };
}

/** Removes only the Inspector-owned persistence reset by the scenario lab. */
export function clearThreadsStateLabStorage(
  storage: Pick<Storage, "removeItem">,
  cookieTarget?: { cookie: string },
): void {
  for (const key of LAB_RESET_STORAGE_KEYS) storage.removeItem(key);
  if (cookieTarget) {
    cookieTarget.cookie = `${INSPECTOR_DISMISSAL_COOKIE_NAME}=; Path=/; Max-Age=0; SameSite=Lax`;
  }
}

/** Re-arms the notification while preserving the developer's Inspector setup. */
export function clearThreadsStateLabNotificationState(
  localStorage: Pick<Storage, "getItem" | "setItem" | "removeItem">,
  sessionStorage: Pick<Storage, "removeItem">,
  cookieTarget: { cookie: string },
): void {
  const rawInspectorState = localStorage.getItem(INSPECTOR_STATE_STORAGE_KEY);
  if (rawInspectorState) {
    try {
      const inspectorState = JSON.parse(rawInspectorState) as unknown;
      if (
        inspectorState &&
        typeof inspectorState === "object" &&
        !Array.isArray(inspectorState)
      ) {
        localStorage.setItem(
          INSPECTOR_STATE_STORAGE_KEY,
          JSON.stringify({ ...inspectorState, isOpen: false }),
        );
      }
    } catch {
      // Invalid persisted state already falls back to a closed Inspector.
    }
  }
  localStorage.removeItem(ANNOUNCEMENT_READ_STORAGE_KEY);
  localStorage.removeItem(INSPECTOR_DISMISSAL_STORAGE_KEY);
  sessionStorage.removeItem(ANNOUNCEMENT_PULSED_SESSION_KEY);
  cookieTarget.cookie = `${ANNOUNCEMENT_READ_COOKIE_NAME}=; Path=/; Max-Age=0; SameSite=Lax`;
  cookieTarget.cookie = `${INSPECTOR_DISMISSAL_COOKIE_NAME}=; Path=/; Max-Age=0; SameSite=Lax`;
}

/** Reload URL for a clean, closed launcher with the notification re-armed. */
export function notificationReplayUrl(href: string): string {
  const url = new URL(href);
  url.searchParams.delete("reset");
  url.searchParams.set(REPLAY_NOTIFICATION_QUERY_KEY, "1");
  return url.toString();
}

/** Removes the one-shot replay flag after it has been consumed. */
export function consumedNotificationReplayUrl(href: string): string {
  const url = new URL(href);
  url.searchParams.delete(REPLAY_NOTIFICATION_QUERY_KEY);
  return url.toString();
}

/** Copies and returns one canonical scenario URL without changing page state. */
export async function copyThreadsStateLabDirectLink(
  clipboard: Pick<Clipboard, "writeText">,
  origin: string,
  key: ScenarioKey,
): Promise<string> {
  const directLink = canonicalScenarioUrl(origin, key);
  await clipboard.writeText(directLink);
  return directLink;
}

/** Installs the exact reduced-motion response and returns its full restoration. */
export function installThreadsStateLabReducedMotion(
  targetWindow: Window,
): () => void {
  const ownDescriptor = Object.getOwnPropertyDescriptor(
    targetWindow,
    "matchMedia",
  );
  const originalMatchMedia = targetWindow.matchMedia.bind(targetWindow);
  const exactQuery = "(prefers-reduced-motion: reduce)";
  Object.defineProperty(targetWindow, "matchMedia", {
    configurable: true,
    writable: true,
    value: (mediaQuery: string): MediaQueryList => {
      if (mediaQuery !== exactQuery) return originalMatchMedia(mediaQuery);
      return {
        matches: true,
        media: mediaQuery,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => true,
      };
    },
  });
  return () => {
    if (ownDescriptor) {
      Object.defineProperty(targetWindow, "matchMedia", ownDescriptor);
    } else {
      Reflect.deleteProperty(targetWindow, "matchMedia");
    }
  };
}

/** Stops and unregisters every store owned by one lab Core and Inspector pair. */
export function stopThreadsStateLabClient(
  core: CopilotKitCore | null,
  inspector: WebInspectorElement | null,
): void {
  const priorStores = core ? Object.entries(core.getThreadStores()) : [];
  inspector?.remove();
  if (inspector) inspector.core = null;
  for (const [agentId, store] of priorStores) {
    if (core?.getThreadStore(agentId) !== store) continue;
    store.stop();
    core.unregisterThreadStore(agentId);
  }
  core?.setRuntimeUrl(undefined);
}
