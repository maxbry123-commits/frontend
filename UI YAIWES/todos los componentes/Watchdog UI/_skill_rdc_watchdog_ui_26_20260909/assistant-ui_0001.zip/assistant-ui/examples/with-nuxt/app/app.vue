<template>
  <Assistant />
</template>
