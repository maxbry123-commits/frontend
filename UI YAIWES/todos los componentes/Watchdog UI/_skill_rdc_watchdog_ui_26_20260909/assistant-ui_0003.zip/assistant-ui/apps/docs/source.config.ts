import {
  defineConfig,
  defineDocs,
  defineCollections,
  frontmatterSchema,
  metaSchema,
} from "fumadocs-mdx/config";
import { rehypeCodeDefaultOptions } from "fumadocs-core/mdx-plugins";
import { transformerMetaHighlight } from "@shikijs/transformers";
import { z } from "zod";
import lastModified from "fumadocs-mdx/plugins/last-modified";
import type { ShikiTransformer } from "shiki";
import { remarkMermaid } from "./lib/remark-mermaid";

function transformerLineNumbers(): ShikiTransformer {
  return {
    name: "line-numbers",
    pre(node) {
      node.properties["data-line-numbers"] = "";
    },
  };
}

// Platform a doc page or section applies to. Used by the docs sidebar to
// filter content based on the user's selected platform in the header dropdown.
// Pages / folders with no `platforms` field are universal.
// fumadocs-mdx forbids non-collection exports here, so this is local-only.
const platformSchema = z.enum(["react", "rn", "ink", "vue"]);

export const docs = defineDocs({
  docs: {
    schema: frontmatterSchema.extend({
      links: z
        .array(
          z.object({
            label: z.string(),
            url: z.string(),
          }),
        )
        .optional(),
      platforms: z.array(platformSchema).optional(),
    }),
    async: true,
  },
  meta: {
    schema: metaSchema.extend({
      description: z.string().optional(),
      overview: z.string().optional(),
      platforms: z.array(platformSchema).optional(),
    }),
  },
});

export const tapDocs = defineDocs({
  dir: "content/tap-docs",
  docs: {
    schema: frontmatterSchema,
    async: true,
  },
  meta: {
    schema: metaSchema.extend({
      description: z.string().optional(),
    }),
  },
});

export const examples = defineCollections({
  type: "doc",
  dir: "content/examples",
  schema: frontmatterSchema,
  async: true,
});

export const elements = defineCollections({
  type: "doc",
  dir: "content/elements",
  schema: frontmatterSchema,
  async: true,
});

export const design = defineCollections({
  type: "doc",
  dir: "content/design",
  schema: frontmatterSchema.extend({
    links: z
      .array(
        z.object({
          label: z.string(),
          url: z.string(),
        }),
      )
      .optional(),
  }),
  async: true,
});

export const blog = defineCollections({
  type: "doc",
  dir: "content/blog",
  schema: frontmatterSchema.extend({
    author: z.string(),
    date: z.coerce.date().optional(),
    externalUrl: z.string().url().optional(),
  }),
  postprocess: {
    includeProcessedMarkdown: true,
  },
});

export const careers = defineCollections({
  type: "doc",
  dir: "content/careers",
  schema: frontmatterSchema.extend({
    order: z.number().optional(),
    location: z.string(),
    type: z.string(),
    salary: z.string(),
    summary: z.string(),
  }),
});

export default defineConfig({
  plugins: [lastModified()],
  mdxOptions: {
    remarkPlugins: [remarkMermaid],
    rehypeCodeOptions: {
      lazy: true,
      langs: ["ts", "js", "html", "tsx", "mdx", "bash"],
      themes: {
        light: "catppuccin-latte",
        dark: "catppuccin-mocha",
      },
      transformers: [
        ...(rehypeCodeDefaultOptions.transformers ?? []),
        transformerLineNumbers(),
        transformerMetaHighlight(),
      ],
    },
  },
});
