/**
 * A2UI catalog DEFINITIONS — platform-agnostic.
 *
 * Each entry declares a custom component name + Zod props schema + a short
 * description. The runtime's A2UI middleware serialises this schema into
 * the agent's `copilotkit.context` at request time, so the LLM knows which
 * components it may emit and what each prop expects.
 *
 * The React implementations live next to these definitions in
 * `./renderers.tsx`, where they are wired through `createCatalog(...)` with
 * `includeBasicCatalog: true` so the built-in A2UI primitives (Text, Row,
 * Column, Image, Card, Button, …) come along for free.
 */
// @region[definitions-zod]
import { z } from "zod";
import type { CatalogDefinitions } from "@copilotkit/a2ui-renderer";

export const myDefinitions = {
  // NOTE: `Row`, `Column`, and `Text` are intentionally NOT declared here.
  // The catalog is assembled with `includeBasicCatalog: true` (see
  // ./catalog.ts), which supplies the built-in `Row`/`Column`/`Text`
  // renderers — declaring them here without a matching entry in
  // `./renderers.tsx` would make `createCatalog` produce a catalog whose
  // definition set is wider than its renderer set and crash the surface at
  // render time. The custom renderers below (`Metric`, `PieChart`,
  // `BarChart`, …) are written to lay out correctly inside the basic
  // gap-less Row/Column via `flex-1`/`min-w-*`, so composed dashboards
  // still read cleanly.
  Card: {
    description:
      "A titled card container with an optional subtitle and a single child slot. Use it to group related content (metrics, rows, buttons).",
    props: z.object({
      title: z.string(),
      subtitle: z.string().optional(),
      child: z.string().optional(),
    }),
  },

  StatusBadge: {
    description:
      "A small coloured pill communicating the state of something (healthy/degraded/at-risk, on-track/behind). Choose `variant` to match the intent.",
    props: z.object({
      text: z.string(),
      variant: z.enum(["success", "warning", "error", "info"]).optional(),
    }),
  },

  Metric: {
    description:
      "A key/value KPI tile with an optional trend indicator and trend delta. Ideal for dashboard KPI rows (e.g. 'Revenue • $4.2M • up 12%').",
    props: z.object({
      label: z.string(),
      value: z.string(),
      trend: z.enum(["up", "down", "neutral"]).optional(),
      trendValue: z.string().optional(),
    }),
  },

  InfoRow: {
    description:
      "A compact two-column 'label: value' row. Good for stacks of facts inside a Card (owner, region, ARR, renewal date, etc.).",
    props: z.object({
      label: z.string(),
      value: z.string(),
    }),
  },

  DataTable: {
    description:
      "A data table with column headers and rows. Ideal for rankings and per-person/per-item breakdowns (rep performance vs quota, deal lists). Each row's keys MUST appear in `columns[].key`; unknown row keys render as blank cells and indicate model/schema drift.",
    // NOTE on row-keys ⊆ columns[].key: we'd normally enforce this with
    // `z.object(...).refine(...)`, but the host catalog package's
    // `CatalogComponentDefinition` type requires `props: ZodObject<…>`
    // (it inspects `.shape` at runtime), and `.refine` returns a
    // `ZodEffects` that breaks both the `satisfies CatalogDefinitions`
    // type assertion and the runtime `.shape` access. Until the host type
    // is broadened, we encode the constraint in the description above so
    // the LLM sees the rule, and leave hard enforcement to the rendering
    // pipeline (which already shows the empty cell — detection is the gap,
    // not behaviour).
    props: z.object({
      columns: z.array(z.object({ key: z.string(), label: z.string() })),
      // Cells may be strings or numbers — the renderer stringifies at render
      // time, but accepting both lets the LLM emit raw numerics (e.g.
      // attainment 124) instead of being forced to stringify.
      rows: z.array(z.record(z.union([z.string(), z.number()]))),
    }),
  },

  PrimaryButton: {
    description:
      "A styled primary call-to-action button. Attach an optional `action` that will be dispatched back to the agent when the user clicks it.",
    props: z.object({
      label: z.string(),
      // The renderer hands `action` opaquely to the A2UI `dispatch` helper,
      // which forwards it back to the agent. We don't constrain the shape
      // (different demos use different action payloads), but `z.unknown()`
      // is strictly better than `z.any()` here because it forces any
      // consumer that touches the value to narrow it explicitly.
      action: z.unknown().optional(),
    }),
  },

  PieChart: {
    description:
      "A pie/donut chart with a brand-coloured legend. Provide `title`, `description`, and `data` as an array of `{ label, value }` objects. Great for part-of-whole breakdowns (sales by region, traffic sources, portfolio allocation).",
    props: z.object({
      title: z.string(),
      description: z.string(),
      data: z.array(
        z.object({
          label: z.string(),
          value: z.number(),
        }),
      ),
    }),
  },

  BarChart: {
    description:
      "A vertical bar chart built on Recharts. Provide `title`, `description`, and `data` as an array of `{ label, value }` objects. Great for comparing series across categories (quarterly revenue, headcount by team, signups per month).",
    props: z.object({
      title: z.string(),
      description: z.string(),
      data: z.array(
        z.object({
          label: z.string(),
          value: z.number(),
        }),
      ),
    }),
  },
} satisfies CatalogDefinitions;
// @endregion[definitions-zod]

export type MyDefinitions = typeof myDefinitions;
