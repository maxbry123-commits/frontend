import type { Logger } from "../types/index.js";
import { formatCvdiag } from "../probes/helpers/cv-diag.js";

/**
 * HF13-B1: Retry-exhausted 5xx/429 responses used to be returned to
 * callers with their body already drained (so the retry envelope could
 * free the socket). Callers that then did `await res.text()` /
 * `await res.json()` on `!res.ok` got empty strings, and the resulting
 * `pb create failed: 429 ` log had no server-side context.
 *
 * Fix: on the final-attempt 5xx/429 path, read the body text BEFORE
 * drain, then throw a typed `PbHttpError` carrying `statusCode` +
 * `bodyText`. Callers that previously matched on `!res.ok` now catch
 * this class and surface the rich body text. Non-retryable 4xx paths
 * are unchanged (callers read the body directly).
 */
export class PbHttpError extends Error {
  readonly statusCode: number;
  readonly bodyText: string;
  readonly path: string;
  constructor(opts: { statusCode: number; bodyText: string; path: string }) {
    super(`pb http ${opts.statusCode} on ${opts.path}: ${opts.bodyText}`);
    this.name = "PbHttpError";
    this.statusCode = opts.statusCode;
    this.bodyText = opts.bodyText;
    this.path = opts.path;
  }
}

export interface PbClientConfig {
  url: string;
  email?: string;
  password?: string;
  logger: Logger;
  fetchImpl?: typeof fetch;
}

export interface ListOpts {
  filter?: string;
  sort?: string;
  page?: number;
  perPage?: number;
  skipTotal?: boolean;
}

export interface ListResult<T> {
  page: number;
  perPage: number;
  totalPages: number;
  totalItems: number;
  items: T[];
}

export interface PbClient {
  getOne<T>(collection: string, id: string): Promise<T | null>;
  getFirst<T>(collection: string, filter: string): Promise<T | null>;
  list<T>(collection: string, opts?: ListOpts): Promise<ListResult<T>>;
  create<T>(collection: string, record: Record<string, unknown>): Promise<T>;
  update<T>(
    collection: string,
    id: string,
    record: Record<string, unknown>,
  ): Promise<T>;
  upsertByField<T>(
    collection: string,
    field: string,
    value: string,
    record: Record<string, unknown>,
  ): Promise<T>;
  delete(collection: string, id: string): Promise<void>;
  deleteByFilter(collection: string, filter: string): Promise<number>;
  health(): Promise<boolean>;
  /**
   * Trigger PocketBase's built-in backup endpoint
   * (`POST /api/backups`). PB takes a SQLite checkpoint + zips the
   * `pb_data` directory into `<pb_data>/backups/<name>`, producing a
   * consistent snapshot even while writes are in-flight. This replaces
   * reading `data.db` off the live filesystem, which risks corruption.
   */
  createBackup(name: string): Promise<void>;
  /** Fetch a previously-created backup's zip bytes. */
  downloadBackup(name: string): Promise<Uint8Array>;
  /** Delete a backup so we don't leak zips on the PB volume. */
  deleteBackup(name: string): Promise<void>;
}

// Cap deleteByFilter at 100 pages of 200 rows = 20k rows. Guards against
// unbounded loops if PB ever returns a full page indefinitely.
const DELETE_BY_FILTER_MAX_ITERATIONS = 100;

// Cap 401/403 re-auth retries at 1. A persistent 401 (bad token) or a 403
// that survives a fresh, successful re-auth (genuine permission denial)
// means the server will never accept the write; retrying forever just pins
// the CPU and, worse, could mask a real authz error as an endless re-auth
// loop.
const MAX_AUTH_RETRIES = 1;

// Floor for 429 Retry-After honoring — if header is absent or unparseable,
// fall back to exponential backoff.
const DEFAULT_RETRY_AFTER_MS = 500;

// Minimum floor applied when a caller-provided Retry-After parses to 0
// (`Retry-After: 0`). Historically the loop short-circuited `waitMs <= 0`
// which returned the 429 immediately without retrying. Intent is "retry
// right away, with a small floor so we don't spin." B1: apply
// MIN_RETRY_AFTER_MS instead of short-circuiting on a zero-valued header;
// the only legitimate short-circuit is when the outer retry budget is
// exhausted (`remainingBudgetMs() <= 0`).
const MIN_RETRY_AFTER_MS = 100;

// PB returns a 400 with a body containing "validation_not_unique" on unique-
// index violations. Shape of the error body varies across versions, so we
// match the string fragment rather than parsing JSON.
function isUniqueConstraintError(err: unknown): boolean {
  const msg = String(err);
  return (
    msg.includes("validation_not_unique") ||
    msg.includes("is not unique") ||
    /UNIQUE constraint failed/i.test(msg)
  );
}

// Cap on the total retry envelope (all attempts + sleeps) for a single
// request. Protects against stacking an exponential backoff on top of a
// Retry-After and exceeding the caller's handler timeout (GH Actions
// webhook delivery, cron-handler budgets, etc). 50s leaves operators
// ~10s of slack before external timeouts kick in. This is the OUTER
// bound — the per-retry Retry-After cap (RETRY_AFTER_MAX_MS) is the
// inner bound applied to a single 429 response.
const RETRY_BUDGET_MS = 50_000;

// Per-retry cap on an individual Retry-After header value. PocketBase
// behind Cloudflare (and other proxies) legitimately returns
// `Retry-After: 60` under sustained rate pressure; a lower cap silently
// clamps that to its own value and the client retries early into
// another 429, defeating the server-side backoff contract. 60s matches
// Cloudflare's documented Retry-After behaviour for rate-limited
// responses. Do NOT raise further: the outer RETRY_BUDGET_MS (50s) still
// caps total retry wall-clock, so stacking multiple 60s waits can't run
// away — but a single Retry-After honored at >60s would itself breach
// the caller's envelope.
const RETRY_AFTER_MAX_MS = 60_000;

// Rate-limit for the re-auth-failure warn path — a persistently broken
// credential set would otherwise fire one warn per request. One warn per
// minute is plenty to surface the outage without drowning the log.
const REAUTH_WARN_INTERVAL_MS = 60_000;

export function createPbClient(config: PbClientConfig): PbClient {
  const fetchImpl = config.fetchImpl ?? globalThis.fetch;
  const baseUrl = config.url.replace(/\/$/, "");
  const logger = config.logger;
  let authToken: string | null = null;
  // Only log the "missing creds" warning once per process lifetime.
  // Without this, every request when PB creds aren't configured would
  // spam the log — a single warn is plenty to flag the gap.
  let warnedMissingCreds = false;
  // Timestamp of the last "reauth-failed" warn — rate-limit so a broken
  // credential set doesn't fill the log.
  let lastReauthWarnAt = 0;
  // One-time warn flag for the PB-≤0.22 /api/admins fallback path.
  let warnedLegacyAdminAuth = false;

  async function ensureAuth(): Promise<void> {
    if (authToken) return;
    if (!config.email || !config.password) {
      if (!warnedMissingCreds) {
        warnedMissingCreds = true;
        logger.warn("pb-client.missing-credentials", {
          hint: "POCKETBASE_SUPERUSER_EMAIL / POCKETBASE_SUPERUSER_PASSWORD not set — writes will fail with 401/403",
        });
      }
      return;
    }
    // PB v0.23+ uses /api/collections/_superusers/auth-with-password;
    // v0.22 uses /api/admins/auth-with-password. Try v0.23 first, fall
    // back to v0.22 on 404 so the client works against both versions.
    const authBody = JSON.stringify({
      identity: config.email,
      password: config.password,
    });
    let res = await fetchImpl(
      `${baseUrl}/api/collections/_superusers/auth-with-password`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: authBody,
      },
    );
    if (res.status === 404) {
      // PB ≤0.22 fallback. Fires while still on PB ≤0.22; upgrading to
      // 0.23+ silences it. Log once so operators can correlate with the
      // version pin. If this warn starts firing AFTER a PB 0.23+ upgrade,
      // it means the /_superusers endpoint is broken on the target server
      // and we're silently falling through to a stale v0.22 endpoint —
      // which would hide real auth failures post-upgrade.
      if (!warnedLegacyAdminAuth) {
        warnedLegacyAdminAuth = true;
        logger.warn("pb-client.legacy-admin-auth-fallback", {
          hint: "/_superusers returned 404 — falling back to /api/admins (PB ≤0.22). Disable this warn after upgrading to PB 0.23+.",
        });
      }
      res = await fetchImpl(`${baseUrl}/api/admins/auth-with-password`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: authBody,
      });
    }
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`pb-auth failed: ${res.status} ${text}`);
    }
    // HF13-B3: PB restarts have been observed returning 200 with an
    // empty body. `await res.json()` on `""` throws a SyntaxError before
    // we reach the empty-token guard, erasing the underlying symptom.
    // Read as text first and parse defensively so empty-body restarts
    // route into the clearer "pb-auth returned empty" branch below.
    const text = await res.text();
    const body: { token?: unknown } = text
      ? (JSON.parse(text) as { token?: unknown })
      : {};
    // Validate the token shape before trusting it — PB has been observed
    // returning 200 with malformed bodies during restarts.
    if (typeof body.token !== "string" || body.token.length === 0) {
      throw new Error("pb-auth returned empty or non-string token");
    }
    authToken = body.token;
  }

  function parseRetryAfterMs(res: Response, attempt: number): number {
    const header = res.headers.get("retry-after");
    if (header) {
      const seconds = Number(header);
      if (Number.isFinite(seconds) && seconds >= 0) {
        // B1: `Retry-After: 0` is a valid directive from the server
        // ("retry immediately"). Before the floor, seconds=0 returned 0
        // and the retry loop short-circuited on `waitMs <= 0`, treating
        // the 429 as terminal. Apply MIN_RETRY_AFTER_MS so we retry
        // without spinning.
        const ms = Math.max(seconds * 1000, MIN_RETRY_AFTER_MS);
        return Math.min(ms, RETRY_AFTER_MAX_MS);
      }
      // B2: HTTP-date form (RFC 7231 §7.1.3) is legal but pb-client only
      // honors the seconds-only form. PB itself emits seconds, but a CDN
      // (Cloudflare, Fastly) in front of PB can rewrite to HTTP-date —
      // when that happens we can't parse the wall-clock offset here and
      // fall through to exponential backoff. Warn once-per-request so
      // operators notice the mismatch and can either drop the CDN
      // Retry-After rewrite or port this parser to RFC 7231.
      logger.warn("pb-client.retry-after-unparseable", {
        header,
        hint: "only Retry-After: <seconds> is honored; HTTP-date form falls back to exponential backoff",
      });
    }
    // Fall back to exponential backoff when no parseable header.
    return Math.max(DEFAULT_RETRY_AFTER_MS, 2 ** attempt * 100);
  }

  async function request(
    path: string,
    init: RequestInit = {},
  ): Promise<Response> {
    await ensureAuth();
    const headers = new Headers(init.headers ?? {});
    if (init.body && !headers.has("content-type")) {
      headers.set("content-type", "application/json");
    }
    if (authToken && !headers.has("authorization")) {
      headers.set("authorization", authToken);
    }
    let attempts = 0;
    let authRetries = 0;
    const maxAttempts = 3;
    // Retry loop covers three transient classes: 401 (re-auth once), 5xx
    // (exponential backoff), 429 (Retry-After), and thrown network
    // errors (DNS fail, AbortError, TypeError from fetchImpl).
    //
    // Hard cap on total time spent retrying. Without this, a 429 with
    // Retry-After: 30 stacked on a 5xx retry (+ network-retry sleep)
    // could exceed a caller's timeout envelope (GH Actions webhook
    // delivery, cron-handler budget). When we exceed the budget, we stop
    // retrying and return the most recent response — callers surface the
    // 5xx/429 to their error handler rather than hang past their own
    // deadline.
    const startedAt = Date.now();
    const remainingBudgetMs = () =>
      Math.max(0, RETRY_BUDGET_MS - (Date.now() - startedAt));
    while (true) {
      attempts += 1;
      let res: Response;
      try {
        res = await fetchImpl(`${baseUrl}${path}`, { ...init, headers });
      } catch (err) {
        // Thrown network error — treat as transient and retry with the
        // same backoff envelope as 5xx.
        if (attempts < maxAttempts) {
          const waitMs = Math.min(2 ** attempts * 100, remainingBudgetMs());
          if (waitMs <= 0) throw err;
          logger.debug("pb-client.network-retry", {
            path,
            attempt: attempts,
            err: String(err),
            waitMs,
          });
          await new Promise((r) => setTimeout(r, waitMs));
          continue;
        }
        throw err;
      }
      // Helper: drain the body so the underlying connection can be
      // reused by the runtime's HTTP agent — otherwise some fetch
      // implementations will leave the socket half-consumed and open a
      // fresh one on every retry. Log drain errors at debug so
      // ECONNRESET / ERR_STREAM_PREMATURE_CLOSE evidence isn't lost
      // (F2.3) — callers rarely need this, but it's invaluable when
      // diagnosing socket-level flakiness.
      const drainBody = async (): Promise<void> => {
        await res.text().catch((drainErr: unknown) => {
          logger.debug("pb-client.body-drain-failed", {
            path,
            status: res.status,
            err: String(drainErr),
          });
        });
      };
      // Re-auth trigger. PB returns 401 when the Authorization token is
      // malformed/absent — but a superuser/admin token whose ~14-day TTL
      // has EXPIRED is treated as an unauthenticated (guest) request, and a
      // guest write to a superuser-gated collection comes back as 403 "Only
      // admins can perform this action", NOT 401. Historically only 401
      // re-triggered auth, so an expired token was never refreshed and every
      // status write failed permanently until the process restarted — the
      // root cause of the 46h dashboard blackout. Treat a 403 as the same
      // stale-session signal, but ONLY when we actually sent a token
      // (`sentAuth`): a 403 on a request that carried no Authorization
      // header is a genuine guest-forbidden result that re-auth can't fix,
      // and re-authing it would just burn an attempt. The retry is bounded
      // by MAX_AUTH_RETRIES, so a 403 that PERSISTS after a fresh, successful
      // auth is a real permission error that falls through to the caller
      // (classified `pb_permission`), never an infinite re-auth loop.
      const sentAuth = headers.has("authorization");
      if (
        (res.status === 401 || (res.status === 403 && sentAuth)) &&
        authRetries < MAX_AUTH_RETRIES &&
        attempts < maxAttempts
      ) {
        // Bounded like the 429/5xx branches by `attempts < maxAttempts`:
        // the outer `attempts += 1` already fired for this attempt, so a
        // token that expires on the final attempt does NOT re-auth-and-
        // retry past the maxAttempts envelope — it falls through and the
        // 401/403 is returned to the caller. A single re-auth chain thus
        // consumes 2 of 3 attempts, leaving 1 slot for a subsequent
        // 5xx/429.
        const authFailStatus = res.status;
        authRetries += 1;
        authToken = null;
        try {
          await ensureAuth();
        } catch (err) {
          // Persistent re-auth failure is operationally significant: every
          // write silently fails as a 401 to the caller, which then treats
          // the probe as errored. Upgrade to warn (rate-limited) so
          // operators notice without log spam. Surface the underlying
          // cause in a thrown error rather than returning the bare 401 —
          // a 401 with no context obscures the real failure (wrong creds,
          // PB admin deleted, version mismatch at auth endpoint).
          const now = Date.now();
          if (now - lastReauthWarnAt > REAUTH_WARN_INTERVAL_MS) {
            lastReauthWarnAt = now;
            logger.warn("pb-client.reauth-failed", {
              path,
              err: String(err),
              hint: "credentials rejected on re-auth — check POCKETBASE_SUPERUSER_EMAIL/PASSWORD and PB version",
            });
          } else {
            logger.debug("pb-client.reauth-failed", {
              path,
              err: String(err),
            });
          }
          throw new Error(
            `pb-client: re-auth failed on ${path} (status ${authFailStatus}): ${String(err)}`,
            { cause: err },
          );
        }
        if (authToken) headers.set("authorization", authToken);
        // Drain the failed (401/403) response before retrying, same as the
        // 429/5xx branches, so the runtime's HTTP agent can reuse the
        // socket instead of leaving it half-consumed on every refresh (F2.3).
        await drainBody();
        continue;
      }
      // HF13-B1: read the body text once, returning "" on any error
      // (premature-close, already-drained, network blip). Used BEFORE
      // drain on the terminal-failure paths so we can surface the
      // server-side reason in a typed error.
      const readBodyTextSafe = async (): Promise<string> => {
        try {
          return await res.text();
        } catch (bodyErr: unknown) {
          logger.debug("pb-client.body-drain-failed", {
            path,
            status: res.status,
            err: String(bodyErr),
          });
          return "";
        }
      };
      if (res.status === 429 && attempts < maxAttempts) {
        const waitMs = Math.min(
          parseRetryAfterMs(res, attempts),
          remainingBudgetMs(),
        );
        if (waitMs <= 0) {
          // HF13-B1: budget exhausted → capture the body before the
          // socket close, then throw a typed error so callers get the
          // server-provided reason rather than an empty "pb ... failed: 429".
          const bodyText = await readBodyTextSafe();
          throw new PbHttpError({
            statusCode: res.status,
            bodyText,
            path,
          });
        }
        logger.debug("pb-client.rate-limited", {
          path,
          attempt: attempts,
          waitMs,
        });
        await drainBody();
        await new Promise((r) => setTimeout(r, waitMs));
        continue;
      }
      if (res.status >= 500 && attempts < maxAttempts) {
        const waitMs = Math.min(2 ** attempts * 100, remainingBudgetMs());
        if (waitMs <= 0) {
          // HF13-B1: same treatment as 429 budget-exhausted — carry the
          // body text through in a typed error so callers can log it.
          const bodyText = await readBodyTextSafe();
          throw new PbHttpError({
            statusCode: res.status,
            bodyText,
            path,
          });
        }
        // Same reasoning as the 429 branch: drain before backing off,
        // and surface drain errors at debug (F2.3).
        await drainBody();
        await new Promise((r) => setTimeout(r, waitMs));
        continue;
      }
      // HF13-B1: final-attempt 429/5xx (retry loop exhausted) — capture
      // the body text up-front and throw PbHttpError so callers don't
      // have to race a drained Response. Non-retryable responses
      // (including 2xx/3xx/4xx-other) are returned intact: callers read
      // 2xx bodies; 4xx callers typically do read the body to surface
      // the error; and we'd otherwise consume a body the caller still
      // needs.
      if (
        attempts >= maxAttempts &&
        (res.status === 429 || res.status >= 500)
      ) {
        const bodyText = await readBodyTextSafe();
        throw new PbHttpError({
          statusCode: res.status,
          bodyText,
          path,
        });
      }
      return res;
    }
  }

  // Internal delete helper that distinguishes a real delete from a 404
  // idempotent-miss. `deleteByFilter` uses this so retention-run
  // counters only increment on actual removals (F2.6). The public
  // `delete()` method stays `Promise<void>` to keep the PbClient
  // interface simple for callers that don't care.
  async function deleteReturningBool(
    collection: string,
    id: string,
  ): Promise<boolean> {
    const res = await request(
      `/api/collections/${encodeURIComponent(collection)}/records/${encodeURIComponent(id)}`,
      { method: "DELETE" },
    );
    if (res.status === 404) {
      // Delete-of-missing is idempotent but we want to surface the gap
      // for anyone asking "why didn't my delete do anything?".
      logger.debug("pb-client.delete-missing", { collection, id });
      return false;
    }
    if (!res.ok) {
      throw new Error(`pb delete failed: ${res.status}`);
    }
    return true;
  }

  const client: PbClient = {
    async getOne<T>(collection: string, id: string): Promise<T | null> {
      const res = await request(
        `/api/collections/${encodeURIComponent(collection)}/records/${encodeURIComponent(id)}`,
      );
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`pb getOne failed: ${res.status}`);
      return (await res.json()) as T;
    },

    async getFirst<T>(collection: string, filter: string): Promise<T | null> {
      const qs = new URLSearchParams({
        filter,
        perPage: "1",
        skipTotal: "true",
      });
      const path = `/api/collections/${encodeURIComponent(collection)}/records?${qs.toString()}`;
      const res = await request(path);
      if (!res.ok) {
        // Carry the typed HTTP status so callers can branch on it (e.g.
        // assertCollectionExists distinguishes 404-missing from 401/403-auth)
        // instead of regex-matching the rendered message string.
        const bodyText = await res.text().catch(() => "");
        throw new PbHttpError({ statusCode: res.status, bodyText, path });
      }
      const body = (await res.json()) as { items: T[] };
      return body.items[0] ?? null;
    },

    async list<T>(
      collection: string,
      opts: ListOpts = {},
    ): Promise<ListResult<T>> {
      const qs = new URLSearchParams();
      if (opts.filter) qs.set("filter", opts.filter);
      if (opts.sort) qs.set("sort", opts.sort);
      if (opts.page) qs.set("page", String(opts.page));
      if (opts.perPage) qs.set("perPage", String(opts.perPage));
      // Pass the bool through explicitly so callers can force a total
      // count (`skipTotal: false`) even when PB's default is otherwise.
      // Previous `if (opts.skipTotal)` silently dropped explicit `false`.
      if (opts.skipTotal !== undefined) {
        qs.set("skipTotal", opts.skipTotal ? "true" : "false");
      }
      const path = `/api/collections/${encodeURIComponent(collection)}/records?${qs.toString()}`;
      const res = await request(path);
      if (!res.ok) {
        // Carry the typed HTTP status (PbHttpError.statusCode) so callers can
        // branch on it — e.g. CvdiagPbWriter.assertCollectionExists reads 404
        // as collection-missing and 401/403 as exists-but-auth, rather than
        // substring-matching the rendered error message.
        const bodyText = await res.text().catch(() => "");
        throw new PbHttpError({ statusCode: res.status, bodyText, path });
      }
      return (await res.json()) as ListResult<T>;
    },

    async create<T>(
      collection: string,
      record: Record<string, unknown>,
    ): Promise<T> {
      const res = await request(
        `/api/collections/${encodeURIComponent(collection)}/records`,
        {
          method: "POST",
          body: JSON.stringify(record),
        },
      );
      if (!res.ok) {
        const text = await res.text();
        // CVDIAG: a PB create failed. This is the choke point for EVERY
        // record write (status, probe_runs, resource_snapshots, diag_events,
        // worker registration). Surfacing it on stdout means a dropped
        // snapshot/claim/registration row is greppable even when the calling
        // boundary swallows the throw best-effort. Never log full record body.
        console.log(
          formatCvdiag({
            component: `pb-client:create:${collection}`,
            boundary: "als-snapshot",
            status: "error",
            error: `status=${res.status} ${text.slice(0, 120)}`,
          }),
        );
        throw new Error(`pb create failed: ${res.status} ${text}`);
      }
      return (await res.json()) as T;
    },

    async update<T>(
      collection: string,
      id: string,
      record: Record<string, unknown>,
    ): Promise<T> {
      const res = await request(
        `/api/collections/${encodeURIComponent(collection)}/records/${encodeURIComponent(id)}`,
        { method: "PATCH", body: JSON.stringify(record) },
      );
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`pb update failed: ${res.status} ${text}`);
      }
      return (await res.json()) as T;
    },

    async upsertByField<T>(
      collection: string,
      field: string,
      value: string,
      record: Record<string, unknown>,
    ): Promise<T> {
      const existing = await client.getFirst<{ id: string }>(
        collection,
        `${field} = ${JSON.stringify(value)}`,
      );
      if (existing) {
        return client.update<T>(collection, existing.id, record);
      }
      try {
        return await client.create<T>(collection, {
          ...record,
          [field]: value,
        });
      } catch (err) {
        // TOCTOU race mirroring alert-state-store.record: two concurrent
        // upserts for the same `field = value` both saw no existing row
        // and raced to create. The second hits the unique index — re-read
        // and update rather than surfacing a constraint violation.
        if (!isUniqueConstraintError(err)) throw err;
        const racer = await client.getFirst<{ id: string }>(
          collection,
          `${field} = ${JSON.stringify(value)}`,
        );
        if (!racer?.id) throw err;
        return client.update<T>(collection, racer.id, record);
      }
    },

    async delete(collection: string, id: string): Promise<void> {
      // Public surface preserves void — most callers don't care about
      // delete-of-missing vs real delete. `deleteByFilter` needs to
      // distinguish (F2.6) and uses the internal `deleteReturningBool`
      // helper instead.
      await deleteReturningBool(collection, id);
    },

    async deleteByFilter(collection: string, filter: string): Promise<number> {
      let deleted = 0;
      let iterations = 0;
      while (true) {
        iterations += 1;
        if (iterations > DELETE_BY_FILTER_MAX_ITERATIONS) {
          throw new Error(
            `pb deleteByFilter exceeded ${DELETE_BY_FILTER_MAX_ITERATIONS} iterations (collection=${collection}) — refusing to loop further`,
          );
        }
        // F2.5: long deletes silently consumed minutes of wall-clock on
        // large collections. Log progress every 10 iterations so
        // operators can watch retention runs make forward progress (and
        // spot stalls before the iteration cap trips).
        if (iterations > 1 && iterations % 10 === 1) {
          logger.info("pb-client.delete-by-filter-progress", {
            collection,
            filter,
            iterations: iterations - 1,
            deleted,
          });
        }
        const page = await client.list<{ id: string }>(collection, {
          filter,
          perPage: 200,
          skipTotal: true,
        });
        if (page.items.length === 0) break;
        for (const item of page.items) {
          // F2.6: only increment `deleted` when the server reports a
          // real removal. A 404 (raced with external delete) used to
          // bump the counter, overstating retention-run effectiveness.
          const removed = await deleteReturningBool(collection, item.id);
          if (removed) deleted += 1;
        }
        if (page.items.length < 200) break;
      }
      return deleted;
    },

    async createBackup(name: string): Promise<void> {
      const res = await request(`/api/backups`, {
        method: "POST",
        body: JSON.stringify({ name }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`pb createBackup failed: ${res.status} ${text}`);
      }
    },

    async downloadBackup(name: string): Promise<Uint8Array> {
      // PB serves the backup file at `/api/backups/<name>` for superusers
      // (GET). The response is a binary zip. Use `request()` so the
      // auth/retry envelope applies, then buffer into a Uint8Array for
      // the S3 uploader (multi-GB PB DBs will eventually want streaming;
      // see s3-backup.ts TODO).
      const res = await request(`/api/backups/${encodeURIComponent(name)}`);
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`pb downloadBackup failed: ${res.status} ${text}`);
      }
      const buf = await res.arrayBuffer();
      return new Uint8Array(buf);
    },

    async deleteBackup(name: string): Promise<void> {
      const res = await request(`/api/backups/${encodeURIComponent(name)}`, {
        method: "DELETE",
      });
      if (!res.ok && res.status !== 404) {
        const text = await res.text().catch(() => "");
        throw new Error(`pb deleteBackup failed: ${res.status} ${text}`);
      }
    },

    async health(): Promise<boolean> {
      try {
        const res = await fetchImpl(`${baseUrl}/api/health`);
        return res.ok;
      } catch (err) {
        // Elevated from debug → warn: PB outages are operationally
        // significant and were previously invisible at the default log
        // level. Health is called infrequently enough that warn-spam
        // isn't a concern.
        logger.warn("pb-client.health-error", { err: String(err) });
        // CVDIAG: PB is unreachable. The health() result is swallowed into a
        // bool that gates the worker /health probe — surface the underlying
        // error so a PB outage is greppable, not just a silent `false`.
        console.log(
          formatCvdiag({
            component: "pb-client:health",
            boundary: "als-snapshot",
            status: "error",
            error: String(err),
          }),
        );
        return false;
      }
    },
  };
  return client;
}
