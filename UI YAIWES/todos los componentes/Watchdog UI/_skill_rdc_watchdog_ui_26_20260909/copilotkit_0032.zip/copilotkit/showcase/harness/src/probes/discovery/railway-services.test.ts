import { describe, it, expect, vi } from "vitest";
import { promises as fsp } from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  classifyShape,
  railwayServicesSource,
  resolveShape,
} from "./railway-services.js";
import {
  DiscoverySourceAuthError,
  DiscoverySourceBackendError,
  DiscoverySourceSchemaError,
  DiscoverySourceTransportError,
} from "./errors.js";
import { logger } from "../../logger.js";
import type { DiscoveryContext } from "../types.js";

// Helpers -------------------------------------------------------------------

interface CallRecord {
  body: string;
}

/**
 * Build a scripted fetch-mock that returns responses from a queue in order.
 * Each entry is either a full `Response` or an object describing status +
 * body + headers. Queue exhaustion throws so a test asking for more
 * round-trips than scripted fails loud rather than silently stubbing a
 * default response.
 */
function makeFetch(
  queue: Array<
    { status: number; body: unknown; contentType?: string } | { throws: Error }
  >,
): { fetchImpl: typeof fetch; calls: CallRecord[] } {
  const calls: CallRecord[] = [];
  let idx = 0;
  const fetchImpl: typeof fetch = async (_url, init) => {
    const body = typeof init?.body === "string" ? init.body : "";
    calls.push({ body });
    if (idx >= queue.length) {
      throw new Error(
        `makeFetch: queue exhausted at call ${idx + 1} (queue size ${queue.length})`,
      );
    }
    const entry = queue[idx++]!;
    if ("throws" in entry) throw entry.throws;
    const contentType = entry.contentType ?? "application/json";
    const bodyStr =
      typeof entry.body === "string" ? entry.body : JSON.stringify(entry.body);
    return new Response(bodyStr, {
      status: entry.status,
      headers: { "content-type": contentType },
    });
  };
  return { fetchImpl, calls };
}

function railwayProjectResponse(
  services: Array<{
    id: string;
    name: string;
    image: string | null;
    domain?: string | null;
    variables?: Record<string, string>;
    /**
     * Optional `latestDeployment.meta` payload threaded into the project
     * GraphQL response. Pass `null` to simulate "no deployment yet"
     * (Railway returns `latestDeployment: null` for a service that has
     * never deployed). Pass an object to populate the meta scalar (the
     * source extracts `imageDigest` from this object). Omit to leave
     * `latestDeployment` field absent from the node entirely.
     */
    latestDeployment?: { meta?: Record<string, unknown> | null } | null;
  }>,
) {
  return {
    data: {
      project: {
        services: {
          edges: services.map((s) => {
            const node: Record<string, unknown> = {
              environmentId: "env-1",
              source: { image: s.image },
              domains: {
                serviceDomains: s.domain ? [{ domain: s.domain }] : [],
              },
            };
            if ("latestDeployment" in s) {
              node["latestDeployment"] = s.latestDeployment;
            }
            return {
              node: {
                id: s.id,
                name: s.name,
                serviceInstances: {
                  edges: [{ node }],
                },
              },
            };
          }),
        },
      },
    },
  };
}

const BASE_ENV = {
  RAILWAY_TOKEN: "rw-test",
  RAILWAY_PROJECT_ID: "proj-1",
  RAILWAY_ENVIRONMENT_ID: "env-1",
};

/**
 * Build a `DiscoveryContext` for tests. Defaults `abortSignal` to a fresh
 * `AbortController().signal` (never aborted) rather than `undefined` so
 * regressions that drop the signal forwarding fail loudly — every fetch
 * stub in the suite sees a real signal object and can assert identity.
 * Pass `abortSignal: undefined` explicitly to recover the legacy
 * "no signal" behaviour for a specific test.
 */
function makeCtx(
  fetchImpl: typeof fetch,
  env: Record<string, string | undefined> = BASE_ENV,
  opts: { abortSignal?: AbortSignal } = {},
): DiscoveryContext {
  const abortSignal =
    "abortSignal" in opts ? opts.abortSignal : new AbortController().signal;
  return { fetchImpl, logger, env, abortSignal };
}

// Tests ---------------------------------------------------------------------

describe("railwayServicesSource", () => {
  it("exposes name === 'railway-services'", () => {
    expect(railwayServicesSource.name).toBe("railway-services");
  });

  it("configSchema accepts empty object", () => {
    const parsed = railwayServicesSource.configSchema.safeParse({});
    expect(parsed.success).toBe(true);
  });

  it("configSchema accepts a filter with namePrefix + labels", () => {
    // configSchema is the filter block itself — the invoker hands
    // `cfg.discovery.filter` to enumerate() directly, so the schema
    // parses `{namePrefix, labels, nameExcludes}` at the top level
    // rather than nested under a `filter:` key.
    const parsed = railwayServicesSource.configSchema.safeParse({
      namePrefix: "showcase-",
      labels: { env: "prod" },
    });
    expect(parsed.success).toBe(true);
  });

  it("happy path: enumerates multiple services with imageRef + publicUrl + env", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: "showcase-a.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-b",
            image: "ghcr.io/copilotkit/showcase-b:latest",
            domain: "showcase-b.up.railway.app",
          },
        ]),
      },
      {
        status: 200,
        body: { data: { variables: { FOO: "bar" } } },
      },
      {
        status: 200,
        body: { data: { variables: { BAZ: "qux" } } },
      },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out).toHaveLength(2);
    expect(out[0]).toMatchObject({
      name: "showcase-a",
      imageRef: "ghcr.io/copilotkit/showcase-a:latest",
      publicUrl: "https://showcase-a.up.railway.app",
    });
    expect(out[0].env).toEqual({ FOO: "bar" });
    expect(out[1].name).toBe("showcase-b");
  });

  it("filters by namePrefix, dropping non-matching services before env fetch", async () => {
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: "showcase-a.up.railway.app",
          },
          {
            id: "s-2",
            name: "other-b",
            image: "ghcr.io/copilotkit/other-b:latest",
            domain: "other-b.up.railway.app",
          },
        ]),
      },
      // Only one variables call should happen because only one service
      // passes the namePrefix filter.
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {
      namePrefix: "showcase-",
    });
    expect(out).toHaveLength(1);
    expect(out[0].name).toBe("showcase-a");
    // Round-trips: 1 project query + 1 variables query only.
    expect(calls).toHaveLength(2);
  });

  it("filters by nameExcludes, dropping excluded services after namePrefix", async () => {
    // Applied AFTER namePrefix so the exclude list can target infra
    // services (showcase-aimock, showcase-harness, ...) without having to
    // maintain a parallel include-list — the e2e-smoke probe uses this
    // to skip services that don't run user-facing demos.
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-langgraph-python",
            image: "ghcr.io/copilotkit/showcase-langgraph-python:latest",
            domain: "showcase-langgraph-python.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-aimock",
            image: "ghcr.io/copilotkit/showcase-aimock:latest",
            domain: "showcase-aimock.up.railway.app",
          },
        ]),
      },
      // Only one variables call — the excluded service should not fetch vars.
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {
      namePrefix: "showcase-",
      nameExcludes: ["showcase-aimock"],
    });
    expect(out).toHaveLength(1);
    expect(out[0].name).toBe("showcase-langgraph-python");
    expect(calls).toHaveLength(2);
  });

  it("honours filter passed flat (invoker shape) — drops all 7 infra services in smoke.yml", async () => {
    // REGRESSION: the probe-invoker at `loader/probe-invoker.ts` calls
    // `source.enumerate(ctx, cfg.discovery.filter ?? {})` — i.e. it passes
    // the FILTER OBJECT DIRECTLY, not a `{filter: {...}}` wrapper. The
    // previous ConfigSchema wrapped FilterSchema in an outer `.filter`
    // key, so at runtime `cfg.filter` was undefined, BOTH `namePrefix`
    // and `nameExcludes` silently defaulted to undefined, and all 7
    // infra services (showcase-shell*, showcase-harness, showcase-pocketbase,
    // showcase-aimock) produced smoke:/health:/agent: ProbeResults every
    // tick → ~21 false-red rows in PocketBase.
    //
    // This test asserts the contract DiscoverySource.enumerate advertises
    // in `probes/types.ts`: the second argument is `discovery.filter`,
    // not the whole discovery block.
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          // Real user-facing showcase services — MUST be enumerated.
          {
            id: "s-1",
            name: "showcase-langgraph-python",
            image: "ghcr.io/copilotkit/showcase-langgraph-python:latest",
            domain: "showcase-langgraph-python.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
          // The 7 infra services from smoke.yml's `nameExcludes` — MUST
          // be dropped before per-service env fetch.
          {
            id: "i-1",
            name: "showcase-harness",
            image: "ghcr.io/copilotkit/showcase-harness:latest",
            domain: "showcase-harness.up.railway.app",
          },
          {
            id: "i-2",
            name: "showcase-pocketbase",
            image: "ghcr.io/copilotkit/showcase-pocketbase:latest",
            domain: "showcase-pocketbase.up.railway.app",
          },
          {
            id: "i-3",
            name: "showcase-shell",
            image: "ghcr.io/copilotkit/showcase-shell:latest",
            domain: "showcase-shell.up.railway.app",
          },
          {
            id: "i-4",
            name: "showcase-shell-dashboard",
            image: "ghcr.io/copilotkit/showcase-shell-dashboard:latest",
            domain: "showcase-shell-dashboard.up.railway.app",
          },
          {
            id: "i-5",
            name: "showcase-shell-docs",
            image: "ghcr.io/copilotkit/showcase-shell-docs:latest",
            domain: "showcase-shell-docs.up.railway.app",
          },
          {
            id: "i-6",
            name: "showcase-shell-dojo",
            image: "ghcr.io/copilotkit/showcase-shell-dojo:latest",
            domain: "showcase-shell-dojo.up.railway.app",
          },
          {
            id: "i-7",
            name: "showcase-aimock",
            image: "ghcr.io/copilotkit/showcase-aimock:latest",
            domain: "showcase-aimock.up.railway.app",
          },
        ]),
      },
      // Only TWO variables calls — one per user-facing showcase. If
      // excludes leak, the queue exhausts and makeFetch throws.
      { status: 200, body: { data: { variables: {} } } },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    // Invoker shape: flat filter object, no `{filter: ...}` wrapper.
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {
      namePrefix: "showcase-",
      nameExcludes: [
        "showcase-harness",
        "showcase-pocketbase",
        "showcase-shell",
        "showcase-shell-dashboard",
        "showcase-shell-docs",
        "showcase-shell-dojo",
        "showcase-aimock",
      ],
    });
    expect(out.map((s) => s.name).sort()).toEqual([
      "showcase-ag2",
      "showcase-langgraph-python",
    ]);
    // Project query + two per-service env queries only; the 7 infra
    // services must not cost a round-trip each.
    expect(calls).toHaveLength(3);
  });

  it("returns [] when namePrefix matches nothing (no variables calls)", async () => {
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "other-a",
            image: "ghcr.io/copilotkit/other-a:latest",
            domain: "other-a.up.railway.app",
          },
        ]),
      },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {
      namePrefix: "showcase-",
    });
    expect(out).toEqual([]);
    expect(calls).toHaveLength(1);
  });

  it("throws DiscoverySourceAuthError on 401", async () => {
    const { fetchImpl } = makeFetch([
      { status: 401, body: { errors: [{ message: "unauthenticated" }] } },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceAuthError);
  });

  it("throws DiscoverySourceAuthError on 403", async () => {
    const { fetchImpl } = makeFetch([
      { status: 403, body: { errors: [{ message: "forbidden" }] } },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceAuthError);
  });

  it("throws DiscoverySourceBackendError on 500", async () => {
    const { fetchImpl } = makeFetch([
      { status: 500, body: "internal error", contentType: "text/plain" },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceBackendError);
  });

  it("throws DiscoverySourceBackendError on non-auth 4xx (e.g. 404)", async () => {
    const { fetchImpl } = makeFetch([
      { status: 404, body: { errors: [{ message: "not found" }] } },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceBackendError);
  });

  it("throws DiscoverySourceTransportError when fetch throws (ECONNREFUSED)", async () => {
    const err: Error & { code?: string } = new Error("connect ECONNREFUSED");
    err.code = "ECONNREFUSED";
    const { fetchImpl } = makeFetch([{ throws: err }]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceTransportError);
  });

  it("throws DiscoverySourceSchemaError on malformed JSON body", async () => {
    const { fetchImpl } = makeFetch([
      { status: 200, body: "not-json{{{", contentType: "application/json" },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceSchemaError);
  });

  it("throws DiscoverySourceSchemaError on missing project.services field", async () => {
    const { fetchImpl } = makeFetch([
      { status: 200, body: { data: { project: null } } },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceSchemaError);
  });

  it("throws DiscoverySourceAuthError when env credentials are missing", async () => {
    const { fetchImpl } = makeFetch([]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl, {}), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceAuthError);
  });

  it("concurrent enumerate() calls don't share mutable state", async () => {
    // Each enumerate() creates its own fetch-driven adapter — running 5 in
    // parallel with distinct ctxs + distinct response queues must produce
    // 5 distinct result arrays, no cross-contamination.
    const runs = Array.from({ length: 5 }, (_, i) => {
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: `s-${i}`,
              name: `showcase-${i}`,
              image: `ghcr.io/copilotkit/showcase-${i}:latest`,
              domain: `showcase-${i}.up.railway.app`,
            },
          ]),
        },
        { status: 200, body: { data: { variables: { RUN: String(i) } } } },
      ]);
      return railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    });
    const results = await Promise.all(runs);
    expect(results).toHaveLength(5);
    for (let i = 0; i < 5; i++) {
      expect(results[i]).toHaveLength(1);
      expect(results[i][0].name).toBe(`showcase-${i}`);
      expect(results[i][0].env).toEqual({ RUN: String(i) });
    }
  });

  it("maps sealed Railway variables ('*****') to __SEALED__ sentinel", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: "showcase-a.up.railway.app",
          },
        ]),
      },
      {
        status: 200,
        body: {
          data: { variables: { OPEN: "plain", SECRET: "*****" } },
        },
      },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out[0].env).toEqual({ OPEN: "plain", SECRET: "__SEALED__" });
  });

  it("handles services without a public domain (publicUrl = '')", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: null,
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out[0].publicUrl).toBe("");
  });

  it("degrades per-service env to {} when variables query throws (partial-failure resilience)", async () => {
    // One of three variables fetches throws. The service's entry must
    // still appear in the output with `env: {}` rather than the whole
    // tick aborting — mirrors aimock-wiring's per-service try/catch
    // pattern.
    const transportErr = new Error("socket hangup");
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: "showcase-a.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-b",
            image: "ghcr.io/copilotkit/showcase-b:latest",
            domain: "showcase-b.up.railway.app",
          },
        ]),
      },
      { throws: transportErr },
      { status: 200, body: { data: { variables: { OK: "yes" } } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out).toHaveLength(2);
    expect(out[0].name).toBe("showcase-a");
    expect(out[0].env).toEqual({});
    expect(out[1].name).toBe("showcase-b");
    expect(out[1].env).toEqual({ OK: "yes" });
  });

  it("degrades per-service env to {} when variables response fails schema check", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: "ghcr.io/copilotkit/showcase-a:latest",
            domain: "showcase-a.up.railway.app",
          },
        ]),
      },
      // `variables` expected to be a flat string record; an array here
      // fails the Zod check and the source swallows + continues with {}.
      { status: 200, body: { data: { variables: ["not", "a", "map"] } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out).toHaveLength(1);
    expect(out[0].env).toEqual({});
  });

  // -----------------------------------------------------------------
  // Regression: Railway's current schema does NOT accept the
  // `environmentId` argument on `Service.serviceInstances`. Sending it
  // raises a GraphQL validation error (observed in production:
  //   "Unknown argument \"environmentId\" on field
  //    \"Service.serviceInstances\"")
  // which surfaces as a 400 and blocks every discovery tick. The source
  // MUST filter instances by environment client-side instead of passing
  // an argument to the field.
  // -----------------------------------------------------------------
  it("omits environmentId arg from Service.serviceInstances selection to match current Railway schema", async () => {
    // Simulate Railway's actual behaviour: reject any query that passes
    // `environmentId` as an argument to `serviceInstances`, accept the
    // arg-less form. Under the pre-fix code this queue runs the 400
    // branch and the source throws a backend error; under the fix it
    // runs the 200 branch and returns the service list.
    const fetchImpl: typeof fetch = async (_url, init) => {
      const raw = (init as RequestInit | undefined)?.body as string | undefined;
      const parsed = raw
        ? (JSON.parse(raw) as { query: string })
        : { query: "" };
      // Project-level query: validate shape against live Railway schema.
      if (parsed.query.includes("query project")) {
        if (/serviceInstances\s*\(/.test(parsed.query)) {
          return new Response(
            JSON.stringify({
              errors: [
                {
                  message:
                    'Unknown argument "environmentId" on field "Service.serviceInstances".',
                  extensions: { code: "GRAPHQL_VALIDATION_FAILED" },
                },
              ],
            }),
            {
              status: 400,
              headers: { "content-type": "application/json" },
            },
          );
        }
        return new Response(
          JSON.stringify(
            railwayProjectResponse([
              {
                id: "s-1",
                name: "showcase-a",
                image: "ghcr.io/copilotkit/showcase-a:latest",
                domain: "showcase-a.up.railway.app",
              },
            ]),
          ),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }
      // Variables round-trip.
      return new Response(JSON.stringify({ data: { variables: {} } }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    };
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out).toHaveLength(1);
    expect(out[0].name).toBe("showcase-a");
  });

  it("throws DiscoverySourceBackendError on 200 envelope with graphql errors[]", async () => {
    // Railway can return HTTP 200 with { errors: [...] } for invalid
    // queries or permission errors. These must surface as a backend
    // error (synthetic 500 status) so the invoker produces a keyed
    // synthetic-error ProbeResult rather than silently handing back an
    // empty service list.
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: { errors: [{ message: "Project not found" }] },
      },
    ]);
    await expect(
      railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceBackendError);
  });

  it("emits imageRef === '' when serviceInstance has no image source", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-a",
            image: null,
            domain: "showcase-a.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out[0].imageRef).toBe("");
  });

  // -----------------------------------------------------------------
  // Shape classification
  //
  // Each discovered service is tagged with `shape: "package"` so
  // downstream drivers (smoke, e2e-smoke) can branch on the URL
  // surface without re-parsing the service name. Packages are the
  // shell-based showcases with `/smoke`, `/health`, and `/demos/*`
  // routing.
  // -----------------------------------------------------------------

  it("tags `showcase-*` services as shape='package'", async () => {
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-langgraph-python",
            image: "ghcr.io/copilotkit/showcase-langgraph-python:latest",
            domain: "showcase-langgraph-python.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
    expect(out).toHaveLength(1);
    expect(out[0].shape).toBe("package");
  });

  it("classifies a batch of package services correctly without any warn", async () => {
    // Regression guard: prior iteration silently produced warns on the
    // hyphen-bearing package names below. The return-value check is not
    // enough — we also assert the classifier logger was not invoked,
    // otherwise the audit warn fires every tick in production.
    const warn = vi.fn();
    const ctxLogger = { ...logger, warn };
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-langgraph-python",
            image: "ghcr.io/copilotkit/showcase-langgraph-python:latest",
            domain: "showcase-langgraph-python.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const out = await railwayServicesSource.enumerate(
      { fetchImpl, logger: ctxLogger, env: BASE_ENV },
      {},
    );
    expect(out).toHaveLength(2);
    const byName = Object.fromEntries(out.map((s) => [s.name, s.shape]));
    expect(byName["showcase-ag2"]).toBe("package");
    expect(byName["showcase-langgraph-python"]).toBe("package");
    // No name-shape-unknown warn should have fired — every name above
    // matches the package regex.
    const shapeWarns = warn.mock.calls.filter(
      (c) => c[0] === "discovery.railway-services.name-shape-unknown",
    );
    expect(shapeWarns).toHaveLength(0);
  });

  // -----------------------------------------------------------------
  // Audit-warn branch on classifyShape: any `showcase-*` name that is
  // not a well-formed package root `showcase-<slug>`
  // (lowercase-alnum-hyphen) falls to `package` but logs an audit
  // warn. Covers underscore forms and future archetypes that would
  // otherwise silently misclassify.
  // -----------------------------------------------------------------

  it("classifyShape warns on an underscore-form name but still returns 'package'", () => {
    // Underscore forms fail the package regex because it only allows
    // hyphens. They still return "package" as the safe default but
    // log an audit warn.
    const warn = vi.fn();
    const shape = classifyShape("showcase_some_service", { logger: { warn } });
    expect(shape).toBe("package");
    expect(warn).toHaveBeenCalledTimes(1);
    expect(warn).toHaveBeenCalledWith(
      "discovery.railway-services.name-shape-unknown",
      { name: "showcase_some_service" },
    );
  });

  it("classifyShape does not warn on a well-formed package root", () => {
    const warn = vi.fn();
    const shape = classifyShape("showcase-ag2", { logger: { warn } });
    expect(shape).toBe("package");
    expect(warn).not.toHaveBeenCalled();
  });

  // Hyphen-bearing multi-segment package names. The prior single-segment
  // regex (`^showcase-[a-z0-9]+$`) rejected these and fired a warn per
  // tick for real production services. Widened pattern accepts them as
  // `"package"` without warning.
  it("classifyShape returns 'package' on `showcase-langgraph-python` without warning", () => {
    const warn = vi.fn();
    const shape = classifyShape("showcase-langgraph-python", {
      logger: { warn },
    });
    expect(shape).toBe("package");
    expect(warn).not.toHaveBeenCalled();
  });

  it("classifyShape returns 'package' on `showcase-claude-sdk-typescript` without warning", () => {
    const warn = vi.fn();
    const shape = classifyShape("showcase-claude-sdk-typescript", {
      logger: { warn },
    });
    expect(shape).toBe("package");
    expect(warn).not.toHaveBeenCalled();
  });

  it("classifyShape returns 'package' on `showcase-ms-agent-dotnet` without warning", () => {
    const warn = vi.fn();
    const shape = classifyShape("showcase-ms-agent-dotnet", {
      logger: { warn },
    });
    expect(shape).toBe("package");
    expect(warn).not.toHaveBeenCalled();
  });

  // Non-`showcase-*` names also trip the warn. A Railway service renamed
  // to drop the prefix, or an unrelated workload picked up by discovery,
  // otherwise silently gets the package contract and floods /smoke 404s.
  it("classifyShape warns on a non-`showcase-*` name but still returns 'package'", () => {
    const warn = vi.fn();
    const shape = classifyShape("my-random-service", { logger: { warn } });
    expect(shape).toBe("package");
    expect(warn).toHaveBeenCalledWith(
      "discovery.railway-services.name-shape-unknown",
      { name: "my-random-service" },
    );
  });

  it("classifyShape warns on a `copilotkit-*` workload name but still returns 'package'", () => {
    const warn = vi.fn();
    const shape = classifyShape("copilotkit-cloud", { logger: { warn } });
    expect(shape).toBe("package");
    expect(warn).toHaveBeenCalledWith(
      "discovery.railway-services.name-shape-unknown",
      { name: "copilotkit-cloud" },
    );
  });

  it("classifyShape warns on a mixed-case `showcase-*` name but still returns 'package'", () => {
    const warn = vi.fn();
    const shape = classifyShape("ShowCase-Ag2", { logger: { warn } });
    expect(shape).toBe("package");
    expect(warn).toHaveBeenCalledWith(
      "discovery.railway-services.name-shape-unknown",
      { name: "ShowCase-Ag2" },
    );
  });

  it("resolveShape debug-logs when neither name nor shape is supplied", () => {
    const debug = vi.fn();
    const shape = resolveShape({}, { logger: { debug } });
    expect(shape).toBe("package");
    expect(debug).toHaveBeenCalledWith(
      "discovery.railway-services.resolve-shape-fallback",
      { reason: "no-name-or-shape" },
    );
  });

  it("threads ctx.abortSignal into every Railway GraphQL fetch", async () => {
    // Invariant: a slow Railway endpoint must not keep sockets open past
    // the invoker's per-tick timeout. The source plumbs `ctx.abortSignal`
    // into every GraphQL round-trip; this test captures `init.signal` on
    // every fetch and asserts the controller signal ctx carries is the
    // one the source forwards.
    const captured: Array<AbortSignal | undefined> = [];
    const fetchImpl: typeof fetch = async (_url, init) => {
      captured.push((init as RequestInit | undefined)?.signal ?? undefined);
      const raw = (init as RequestInit | undefined)?.body as string | undefined;
      const parsed = raw
        ? (JSON.parse(raw) as { query: string })
        : { query: "" };
      if (parsed.query.includes("query project")) {
        return new Response(
          JSON.stringify(
            railwayProjectResponse([
              {
                id: "s1",
                name: "showcase-a",
                image: "ghcr.io/c/a:v1",
                domain: "a.up.railway.app",
              },
            ]),
          ),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }
      return new Response(JSON.stringify({ data: { variables: {} } }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    };
    const controller = new AbortController();
    const ctx: DiscoveryContext = {
      fetchImpl,
      logger,
      env: BASE_ENV,
      abortSignal: controller.signal,
    };
    await railwayServicesSource.enumerate(ctx, {});
    expect(captured.length).toBeGreaterThan(0);
    for (const sig of captured) {
      expect(sig).toBe(controller.signal);
    }
  });

  // -----------------------------------------------------------------
  // Demos enrichment from registry.json
  //
  // The `e2e_demos` probe sorts services by demo count BEFORE the
  // worker pool picks them up — that sort lives in the probe-invoker
  // and reads `input.demos`. The driver's lazy `demosResolver` runs
  // INSIDE the driver, AFTER dispatch, so it cannot feed the sort. To
  // make the documented "shortest-first" behaviour actually trigger in
  // production, the discovery source reads `registry.json` once per
  // enumerate() call and joins demos by slug onto every emitted record.
  //
  // Resilience: if the registry is unreadable, the source MUST log a
  // structured warning and emit `demos: []` for every record (siblings
  // need to keep working even when the registry is missing).
  // -----------------------------------------------------------------

  /**
   * Write a registry.json to a temp dir and return the path. Tests pass
   * the path through `REGISTRY_JSON_PATH` so the source overrides the
   * default `/app/data/registry.json` location.
   */
  async function writeRegistry(content: string): Promise<string> {
    const dir = await fsp.mkdtemp(
      path.join(os.tmpdir(), "railway-services-test-"),
    );
    const file = path.join(dir, "registry.json");
    await fsp.writeFile(file, content, "utf-8");
    return file;
  }

  it("joins demos by slug from registry.json (happy path)", async () => {
    const registryPath = await writeRegistry(
      JSON.stringify({
        integrations: [
          {
            slug: "ag2",
            demos: [
              { id: "agentic-chat", route: "/demos/agentic-chat" },
              { id: "human-in-the-loop", route: "/demos/human-in-the-loop" },
              {
                id: "tool-based-generative-ui",
                route: "/demos/tool-based-generative-ui",
              },
              {
                id: "cli-start",
                name: "CLI Start Command",
                command: "npx create-copilotkit@latest",
              },
            ],
          },
          {
            slug: "langgraph-python",
            demos: [{ id: "agentic-chat", route: "/demos/agentic-chat" }],
          },
        ],
      }),
    );
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-langgraph-python",
            image: "ghcr.io/copilotkit/showcase-langgraph-python:latest",
            domain: "showcase-langgraph-python.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
    const out = await railwayServicesSource.enumerate(
      makeCtx(fetchImpl, env),
      {},
    );
    expect(out).toHaveLength(2);
    const byName = Object.fromEntries(out.map((r) => [r.name, r.demos]));
    expect(byName["showcase-ag2"]).toEqual([
      "agentic-chat",
      "human-in-the-loop",
      "tool-based-generative-ui",
    ]);
    expect(byName["showcase-langgraph-python"]).toEqual(["agentic-chat"]);
  });

  it("emits demos: [] for services whose slug is missing from the registry", async () => {
    // Slug derived from `showcase-` prefix strip — `showcase-ag2` →
    // `ag2`. A service whose slug is not in the registry must still be
    // enumerated, but with `demos: []` so the invoker's sort treats it
    // as "no demos" rather than poisoning the tick.
    const registryPath = await writeRegistry(
      JSON.stringify({
        integrations: [
          {
            slug: "ag2",
            demos: [{ id: "agentic-chat", route: "/demos/agentic-chat" }],
          },
        ],
      }),
    );
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
          {
            id: "s-2",
            name: "showcase-mystery",
            image: "ghcr.io/copilotkit/showcase-mystery:latest",
            domain: "showcase-mystery.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
    const out = await railwayServicesSource.enumerate(
      makeCtx(fetchImpl, env),
      {},
    );
    expect(out).toHaveLength(2);
    const byName = Object.fromEntries(out.map((r) => [r.name, r.demos]));
    expect(byName["showcase-ag2"]).toEqual(["agentic-chat"]);
    expect(byName["showcase-mystery"]).toEqual([]);
  });

  it("emits demos: [] for every service when the registry is missing (info, not warn)", async () => {
    // Unreadable registry MUST NOT throw — sibling probes still need
    // their service list. ENOENT downgrades from warn to info because
    // non-demos consumers (image-drift, smoke, aimock-wiring) don't
    // mount the registry path; treating their steady-state as a warn
    // pulses every tick.
    const warn = vi.fn();
    const info = vi.fn();
    const ctxLogger = { ...logger, warn, info };
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const missingPath = path.join(
      os.tmpdir(),
      `does-not-exist-${Date.now()}-${Math.random()}.json`,
    );
    const env = { ...BASE_ENV, REGISTRY_JSON_PATH: missingPath };
    const out = await railwayServicesSource.enumerate(
      { fetchImpl, logger: ctxLogger, env },
      {},
    );
    expect(out).toHaveLength(1);
    expect(out[0].demos).toEqual([]);
    const warnReadFailed = warn.mock.calls.filter(
      (c) => c[0] === "discovery.railway-services.registry-read-failed",
    );
    expect(warnReadFailed).toHaveLength(0);
    const infoReadFailed = info.mock.calls.filter(
      (c) => c[0] === "discovery.railway-services.registry-read-failed",
    );
    expect(infoReadFailed).toHaveLength(1);
  });

  // -----------------------------------------------------------------
  // Registry shape guards + log-key separation.
  // -----------------------------------------------------------------

  describe("loadDemosMap registry shape guards (A)", () => {
    // Registry roots that aren't an integrations-bearing object — null,
    // numeric, string, or array. Each must NOT crash enumerate(), MUST
    // log `discovery.railway-services.registry-shape-invalid`, and the
    // emitted records carry `demos: []`.
    const cases: Array<{ name: string; raw: string }> = [
      { name: "literal null", raw: "null" },
      { name: "numeric", raw: "42" },
      { name: "string", raw: '"a string"' },
      { name: "array root", raw: "[]" },
    ];
    for (const { name, raw } of cases) {
      it(`degrades + logs registry-shape-invalid on ${name} root`, async () => {
        const registryPath = await writeRegistry(raw);
        const warn = vi.fn();
        const ctxLogger = { ...logger, warn };
        const { fetchImpl } = makeFetch([
          {
            status: 200,
            body: railwayProjectResponse([
              {
                id: "s-1",
                name: "showcase-a",
                image: "ghcr.io/c/a:v1",
                domain: "a.up.railway.app",
              },
            ]),
          },
          { status: 200, body: { data: { variables: {} } } },
        ]);
        const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
        const out = await railwayServicesSource.enumerate(
          { fetchImpl, logger: ctxLogger, env },
          {},
        );
        expect(out).toHaveLength(1);
        expect(out[0].demos).toEqual([]);
        const shapeInvalid = warn.mock.calls.filter(
          (c) => c[0] === "discovery.railway-services.registry-shape-invalid",
        );
        expect(shapeInvalid).toHaveLength(1);
      });
    }
  });

  describe("registry log-key separation (B)", () => {
    it("logs registry-parse-failed (not registry-read-failed) on malformed JSON", async () => {
      const registryPath = await writeRegistry("{not valid json");
      const warn = vi.fn();
      const ctxLogger = { ...logger, warn };
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:v1",
              domain: "a.up.railway.app",
            },
          ]),
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
      const out = await railwayServicesSource.enumerate(
        { fetchImpl, logger: ctxLogger, env },
        {},
      );
      expect(out).toHaveLength(1);
      expect(out[0].demos).toEqual([]);
      const parseFailed = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.registry-parse-failed",
      );
      expect(parseFailed).toHaveLength(1);
      const readFailed = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.registry-read-failed",
      );
      // Parse failure must NOT share the read-failure log key.
      expect(readFailed).toHaveLength(0);
    });
  });

  it("honours REGISTRY_JSON_PATH env override over the /app/data default", async () => {
    // Env override is the test/dev hook — production reads
    // /app/data/registry.json (mounted by the Dockerfile). When the env
    // var is set the source MUST read that path verbatim.
    const registryPath = await writeRegistry(
      JSON.stringify({
        integrations: [
          {
            slug: "ag2",
            demos: [
              { id: "demo-from-override", route: "/demos/demo-from-override" },
            ],
          },
        ],
      }),
    );
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
    const out = await railwayServicesSource.enumerate(
      makeCtx(fetchImpl, env),
      {},
    );
    expect(out[0].demos).toEqual(["demo-from-override"]);
  });

  it("honours ctx.abortSignal during loadDemosMap and degrades to demos: [] when aborted (A2)", async () => {
    // Discovery context can carry an abortSignal that fires when the
    // probe-invoker's `timeout_ms` elapses. `fs.readFile` previously
    // ignored it, so a stalled volume mount could orphan past the
    // tick. After A2 readFile honours the signal — pre-aborted reads
    // reject with AbortError, the warn fires, and we degrade to an
    // empty demos map (NOT an exception that aborts the whole tick).
    const registryPath = await writeRegistry(
      JSON.stringify({
        integrations: [
          {
            slug: "ag2",
            demos: [{ id: "agentic-chat", route: "/demos/agentic-chat" }],
          },
        ],
      }),
    );
    const { fetchImpl } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "s-1",
            name: "showcase-ag2",
            image: "ghcr.io/copilotkit/showcase-ag2:latest",
            domain: "showcase-ag2.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);

    // Pre-aborted signal — readFile sees a fired signal at call time
    // and rejects synchronously with AbortError. Mimics the case
    // where the per-tick timer fired while another phase was still
    // resolving.
    const abortCtrl = new AbortController();
    abortCtrl.abort(new Error("simulated tick timeout"));

    const warn = vi.fn();
    const ctxLogger = { ...logger, warn };
    const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
    const ctx: DiscoveryContext = {
      fetchImpl,
      logger: ctxLogger,
      env,
      abortSignal: abortCtrl.signal,
    };
    // The aborted signal is also what the GraphQL fetch sees, so the
    // overall enumerate() either:
    //   (a) completes with `demos: []` and a warn from the registry
    //       read failure; OR
    //   (b) throws because the GraphQL call rejected with AbortError.
    // Both branches confirm the readFile honours the signal — we
    // assert via the warn-was-called path which is the load-bearing
    // contract for A2 (registry-read-failed with empty map).
    let outOrError: unknown;
    try {
      outOrError = await railwayServicesSource.enumerate(ctx, {});
    } catch (err) {
      outOrError = err;
    }

    // Either way, the readFile MUST have observed the abort and
    // logged the registry-read-failed warn. That's the
    // observable-contract assertion for A2.
    const readFailed = warn.mock.calls.filter(
      (c) => c[0] === "discovery.railway-services.registry-read-failed",
    );
    expect(readFailed).toHaveLength(1);
    // Should mention the abort in the err string.
    const meta = readFailed[0][1] as { err?: string };
    expect(meta.err).toBeTruthy();

    // If enumerate() returned (i.e. the GraphQL fetch wasn't aborted
    // — happens because makeFetch ignores AbortSignal), every record
    // MUST have demos: [] since the registry read collapsed.
    if (Array.isArray(outOrError)) {
      for (const record of outOrError) {
        expect(record.demos).toEqual([]);
      }
    }
  });

  // -----------------------------------------------------------------
  // Per-service variables loop error bucketing.
  // -----------------------------------------------------------------

  // -----------------------------------------------------------------
  // GraphQL partial-data envelope handling.
  // -----------------------------------------------------------------

  describe("graphql partial-data handling (F)", () => {
    it("returns data when both data and errors[] are present (200 envelope)", async () => {
      // Railway can surface non-fatal graphql errors[] alongside a
      // populated `data` field — e.g. soft-deprecation warnings on a
      // nested field. The previous gql() helper threw on any non-empty
      // errors[], discarding the populated `data` payload.
      const warn = vi.fn();
      const ctxLogger = { ...logger, warn };
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: {
            data: railwayProjectResponse([
              {
                id: "s-1",
                name: "showcase-a",
                image: "ghcr.io/c/a:v1",
                domain: "a.up.railway.app",
              },
            ]).data,
            errors: [{ message: "deprecation: foo will be removed" }],
          },
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const out = await railwayServicesSource.enumerate(
        { fetchImpl, logger: ctxLogger, env: BASE_ENV },
        {},
      );
      expect(out).toHaveLength(1);
      expect(out[0].name).toBe("showcase-a");
      const partial = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.partial-errors",
      );
      expect(partial).toHaveLength(1);
    });
  });

  describe("per-service variables loop error bucketing (C, D)", () => {
    it("rethrows AuthError mid-loop instead of silently degrading", async () => {
      // Token rotation race: every per-service call returns 401. The
      // pre-fix code degraded all of them to `env: {}` and emitted a
      // green discovery — operators never saw the auth break.
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:v1",
              domain: "a.up.railway.app",
            },
            {
              id: "s-2",
              name: "showcase-b",
              image: "ghcr.io/c/b:v1",
              domain: "b.up.railway.app",
            },
          ]),
        },
        // First per-service call: 401 — must propagate, not degrade.
        { status: 401, body: { errors: [{ message: "token expired" }] } },
      ]);
      await expect(
        railwayServicesSource.enumerate(makeCtx(fetchImpl), {}),
      ).rejects.toBeInstanceOf(DiscoverySourceAuthError);
    });

    it("on abort mid-loop, breaks out cleanly (one log, not N)", async () => {
      // 3-service project, abort fires before service #2's variables
      // call resolves. Every remaining gql() rejects with AbortError.
      // Pre-fix: N variables-failed warns. Post-fix: at most one (or
      // zero — the loop exits before logging at all, depending on
      // whether the abort wins the race).
      const controller = new AbortController();
      const warn = vi.fn();
      const ctxLogger = { ...logger, warn };
      let callIdx = 0;
      const fetchImpl: typeof fetch = async (_url, init) => {
        callIdx += 1;
        const raw = (init as RequestInit | undefined)?.body as
          | string
          | undefined;
        const parsed = raw
          ? (JSON.parse(raw) as { query: string })
          : { query: "" };
        if (parsed.query.includes("query project")) {
          return new Response(
            JSON.stringify(
              railwayProjectResponse([
                {
                  id: "s-1",
                  name: "showcase-a",
                  image: "ghcr.io/c/a:v1",
                  domain: "a.up.railway.app",
                },
                {
                  id: "s-2",
                  name: "showcase-b",
                  image: "ghcr.io/c/b:v1",
                  domain: "b.up.railway.app",
                },
                {
                  id: "s-3",
                  name: "showcase-c",
                  image: "ghcr.io/c/c:v1",
                  domain: "c.up.railway.app",
                },
              ]),
            ),
            { status: 200, headers: { "content-type": "application/json" } },
          );
        }
        // After the first variables call, abort. Subsequent gql() calls
        // see signal.aborted at fetch-time and reject with AbortError.
        if (callIdx === 2) {
          controller.abort(new Error("tick timeout"));
          const err: Error & { name: string } = new Error("aborted");
          err.name = "AbortError";
          throw err;
        }
        if (init?.signal?.aborted) {
          const err: Error & { name: string } = new Error("aborted");
          err.name = "AbortError";
          throw err;
        }
        return new Response(JSON.stringify({ data: { variables: {} } }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      };
      const ctx: DiscoveryContext = {
        fetchImpl,
        logger: ctxLogger,
        env: BASE_ENV,
        abortSignal: controller.signal,
      };
      let threw = false;
      try {
        await railwayServicesSource.enumerate(ctx, {});
      } catch {
        threw = true;
      }
      // Either throws (preferred) or completes cleanly. Either way,
      // `variables-failed` warns must be at most 1 — never one per
      // remaining service.
      const variablesFailed = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.variables-failed",
      );
      expect(variablesFailed.length).toBeLessThanOrEqual(1);
      // Confidence check that abort actually fired.
      expect(controller.signal.aborted).toBe(true);
      void threw;
    });
  });

  // -----------------------------------------------------------------
  // Stronger abort propagation coverage (J): the existing identity
  // assertion never fires the controller, so a regression that
  // forwards a different (never-aborted) signal would still pass.
  // This block aborts mid-flight and asserts the next fetch sees
  // aborted state.
  // -----------------------------------------------------------------

  describe("abort propagation actually fires (J)", () => {
    it("aborts mid-flight: subsequent gql() calls see aborted signal", async () => {
      const controller = new AbortController();
      const seenSignals: AbortSignal[] = [];
      const fetchImpl: typeof fetch = async (_url, init) => {
        const sig = (init as RequestInit | undefined)?.signal;
        if (sig) seenSignals.push(sig);
        if (sig?.aborted) {
          const err: Error & { name: string } = new Error("aborted");
          err.name = "AbortError";
          throw err;
        }
        const raw = (init as RequestInit | undefined)?.body as
          | string
          | undefined;
        const parsed = raw
          ? (JSON.parse(raw) as { query: string })
          : { query: "" };
        if (parsed.query.includes("query project")) {
          // Fire abort BEFORE returning so the next gql() call sees
          // aborted state.
          controller.abort(new Error("tick timeout"));
          return new Response(
            JSON.stringify(
              railwayProjectResponse([
                {
                  id: "s-1",
                  name: "showcase-a",
                  image: "ghcr.io/c/a:v1",
                  domain: "a.up.railway.app",
                },
              ]),
            ),
            { status: 200, headers: { "content-type": "application/json" } },
          );
        }
        return new Response(JSON.stringify({ data: { variables: {} } }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      };
      const ctx: DiscoveryContext = {
        fetchImpl,
        logger,
        env: BASE_ENV,
        abortSignal: controller.signal,
      };
      let threw = false;
      try {
        await railwayServicesSource.enumerate(ctx, {});
      } catch {
        threw = true;
      }
      // The first call's signal must have been live (not aborted at
      // call time), the second must be aborted.
      expect(seenSignals.length).toBeGreaterThanOrEqual(1);
      if (seenSignals.length >= 2) {
        expect(seenSignals[1].aborted).toBe(true);
      }
      void threw;
    });
  });

  // -----------------------------------------------------------------
  // Concurrent-test noise isolation (H): the legacy concurrent test
  // fell through to the production /app/data/registry.json fallback
  // and emitted an info log per call into CI. This block uses a tmp
  // registry path so no production-fallback log fires; asserts no
  // registry-read-failed warns leak.
  // -----------------------------------------------------------------

  describe("registry path tmp-isolation in concurrent test (H)", () => {
    it("concurrent enumerate() calls don't emit ENOENT noise on /app/data", async () => {
      const warn = vi.fn();
      const ctxLogger = { ...logger, warn };
      const registryPath = await writeRegistry(
        JSON.stringify({ integrations: [] }),
      );
      const runs = Array.from({ length: 5 }, (_, i) => {
        const { fetchImpl } = makeFetch([
          {
            status: 200,
            body: railwayProjectResponse([
              {
                id: `s-${i}`,
                name: `showcase-${i}`,
                image: `ghcr.io/c/showcase-${i}:v1`,
                domain: `showcase-${i}.up.railway.app`,
              },
            ]),
          },
          { status: 200, body: { data: { variables: { RUN: String(i) } } } },
        ]);
        const env = { ...BASE_ENV, REGISTRY_JSON_PATH: registryPath };
        return railwayServicesSource.enumerate(
          {
            fetchImpl,
            logger: ctxLogger,
            env,
            abortSignal: new AbortController().signal,
          },
          {},
        );
      });
      const results = await Promise.all(runs);
      expect(results).toHaveLength(5);
      const readFailed = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.registry-read-failed",
      );
      expect(readFailed).toHaveLength(0);
    });
  });

  // -----------------------------------------------------------------
  // B1 — abort detection mid-loop must NOT over-rethrow unrelated
  // errors. The narrow contract: only AbortError (a real
  // signal-aborted fetch rejection) gets re-thrown out of the
  // per-service catch. A 500 from Railway in a later iteration —
  // even when ctx.abortSignal.aborted is already true — must be
  // treated as a per-service degradation (env: {}) so an external
  // abort doesn't poison the rest of the loop.
  // -----------------------------------------------------------------

  describe("per-service variables loop abort regression (B1)", () => {
    it("after abort fires, a 500 on a subsequent service degrades to env: {} (not rethrown)", async () => {
      // Sequence: project query OK; service-1's variables OK; abort
      // signal fires before service-2; service-2's variables 500s.
      // Pre-fix: the 500 catch saw `ctx.abortSignal.aborted === true`
      // and rethrew the (non-AbortError) backend error, killing the
      // whole tick. Post-fix: only AbortError-name errors rethrow,
      // so the 500 records as a `variables-failed` warn + env: {}.
      const controller = new AbortController();
      const warn = vi.fn();
      const ctxLogger = { ...logger, warn };
      let callIdx = 0;
      const fetchImpl: typeof fetch = async (_url, init) => {
        callIdx += 1;
        const raw = (init as RequestInit | undefined)?.body as
          | string
          | undefined;
        const parsed = raw
          ? (JSON.parse(raw) as { query: string })
          : { query: "" };
        if (parsed.query.includes("query project")) {
          return new Response(
            JSON.stringify(
              railwayProjectResponse([
                {
                  id: "s-1",
                  name: "showcase-a",
                  image: "ghcr.io/c/a:v1",
                  domain: "a.up.railway.app",
                },
                {
                  id: "s-2",
                  name: "showcase-b",
                  image: "ghcr.io/c/b:v1",
                  domain: "b.up.railway.app",
                },
              ]),
            ),
            { status: 200, headers: { "content-type": "application/json" } },
          );
        }
        // Service-1 variables: succeed.
        if (callIdx === 2) {
          return new Response(
            JSON.stringify({ data: { variables: { OK: "yes" } } }),
            { status: 200, headers: { "content-type": "application/json" } },
          );
        }
        // Between service-1 and service-2, abort fires (e.g. tick
        // timer expired). The signal flag flips to aborted but the
        // underlying fetch resolves normally — Railway returns 500
        // for some unrelated reason on this iteration.
        controller.abort(new Error("tick timeout"));
        return new Response("internal error", {
          status: 500,
          headers: { "content-type": "text/plain" },
        });
      };
      const ctx: DiscoveryContext = {
        fetchImpl,
        logger: ctxLogger,
        env: BASE_ENV,
        abortSignal: controller.signal,
      };
      // The 500 must NOT escape — it should land in the catch as a
      // DiscoverySourceBackendError, see that name !== "AbortError",
      // log a `variables-failed` warn, and continue.
      const out = await railwayServicesSource.enumerate(ctx, {});
      expect(out).toHaveLength(2);
      expect(out[0].name).toBe("showcase-a");
      expect(out[0].env).toEqual({ OK: "yes" });
      expect(out[1].name).toBe("showcase-b");
      expect(out[1].env).toEqual({});
      // Confidence: the abort actually fired AND the 500 was logged
      // as a per-service degradation rather than crashing the loop.
      expect(controller.signal.aborted).toBe(true);
      const variablesFailed = warn.mock.calls.filter(
        (c) => c[0] === "discovery.railway-services.variables-failed",
      );
      expect(variablesFailed).toHaveLength(1);
    });
  });

  // -----------------------------------------------------------------
  // B5 — `deployedDigest` extraction needs explicit unit coverage.
  // The fixture used to discard `latestDeployment` entirely, leaving
  // the digest extraction path uncovered.
  // -----------------------------------------------------------------

  describe("deployedDigest extraction (B5)", () => {
    it("extracts imageDigest from latestDeployment.meta", async () => {
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:latest",
              domain: "a.up.railway.app",
              latestDeployment: {
                meta: {
                  imageDigest:
                    "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
                },
              },
            },
          ]),
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
      expect(out[0].deployedDigest).toBe(
        "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
      );
    });

    it("emits deployedDigest === '' when latestDeployment is null", async () => {
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:latest",
              domain: "a.up.railway.app",
              latestDeployment: null,
            },
          ]),
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
      expect(out[0].deployedDigest).toBe("");
    });

    it("emits deployedDigest === '' when latestDeployment.meta is missing", async () => {
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:latest",
              domain: "a.up.railway.app",
              latestDeployment: { meta: null },
            },
          ]),
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
      expect(out[0].deployedDigest).toBe("");
    });

    it("emits deployedDigest === '' when imageDigest is non-string (defensive)", async () => {
      const { fetchImpl } = makeFetch([
        {
          status: 200,
          body: railwayProjectResponse([
            {
              id: "s-1",
              name: "showcase-a",
              image: "ghcr.io/c/a:latest",
              domain: "a.up.railway.app",
              latestDeployment: { meta: { imageDigest: 12345 } },
            },
          ]),
        },
        { status: 200, body: { data: { variables: {} } } },
      ]);
      const out = await railwayServicesSource.enumerate(makeCtx(fetchImpl), {});
      expect(out[0].deployedDigest).toBe("");
    });
  });

  // -----------------------------------------------------------------
  // B6 — resolveShape classifier-vs-supplied shape coverage.
  // -----------------------------------------------------------------

  describe("resolveShape (B6)", () => {
    it("returns 'package' when classifier and caller-supplied shape agree", () => {
      expect(resolveShape({ name: "showcase-ag2", shape: "package" })).toBe(
        "package",
      );
    });

    it("returns 'package' from classifier when no shape is supplied", () => {
      expect(resolveShape({ name: "showcase-ag2" })).toBe("package");
    });
  });
});

// ---------------------------------------------------------------------------
// LOCAL_SERVICES_JSON injection seam
// ---------------------------------------------------------------------------
//
// The local D6 gate (and any non-Railway driver) feeds the IDENTICAL
// RailwayServiceInfo[] shape into the probe path without querying Railway.
// The critical correctness contract: the injected `demos` array MUST survive
// onto the resolved RailwayServiceInfo, because the d6-all-pills driver derives
// its feature matrix via `demosToFeatureTypes(input.demos ?? [])`. An empty
// `demos` short-circuits the driver to a zero-cell false-green, so this seam
// is worthless unless `demos` is plumbed end-to-end.

// A fetch that fails loudly: the local-injection path must NOT touch Railway
// at all, so any fetch call here is a contract violation.
const NO_FETCH: typeof fetch = async () => {
  throw new Error(
    "LOCAL_SERVICES_JSON path must not query Railway (fetch called)",
  );
};

describe("railwayServicesSource — LOCAL_SERVICES_JSON injection", () => {
  it("returns the injected services WITH demos populated, without querying Railway", async () => {
    const localServices = [
      {
        name: "showcase-langgraph-python",
        publicUrl: "http://langgraph-python:10000",
        demos: ["agentic_chat", "human_in_the_loop"],
      },
    ];
    const env = {
      ...BASE_ENV,
      LOCAL_SERVICES_JSON: JSON.stringify(localServices),
    };
    const out = await railwayServicesSource.enumerate(
      makeCtx(NO_FETCH, env),
      {},
    );

    expect(out).toHaveLength(1);
    const svc = out[0]!;
    expect(svc.name).toBe("showcase-langgraph-python");
    expect(svc.publicUrl).toBe("http://langgraph-python:10000");
    // The load-bearing assertion: demos survive onto the resolved record so
    // the d6-all-pills driver's `demosToFeatureTypes(input.demos)` produces a
    // real feature matrix instead of a zero-cell false-green.
    expect(svc.demos).toEqual(["agentic_chat", "human_in_the_loop"]);
    // shape is recomputed from the name via classifyShape (single source of
    // truth) rather than trusted from the injected record.
    expect(svc.shape).toBe("package");
  });

  it("does NOT engage the injection seam when LOCAL_SERVICES_JSON is unset (Railway path unchanged)", async () => {
    // No LOCAL_SERVICES_JSON in env → the Railway discovery path runs exactly
    // as today. We assert byte-identical behaviour by driving the normal
    // scripted-fetch happy path and confirming the seam never short-circuits.
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "svc-1",
            name: "showcase-langgraph-python",
            image: "ghcr.io/org/langgraph-python:latest",
            domain: "langgraph-python.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    // BASE_ENV has no LOCAL_SERVICES_JSON → Railway path.
    const out = await railwayServicesSource.enumerate(
      makeCtx(fetchImpl, BASE_ENV),
      {},
    );
    expect(out).toHaveLength(1);
    expect(out[0]!.name).toBe("showcase-langgraph-python");
    expect(out[0]!.publicUrl).toBe("https://langgraph-python.up.railway.app");
    // The Railway path made its GraphQL round-trips — proof the seam was a
    // no-op and discovery behaviour is unchanged when the env var is absent.
    expect(calls.length).toBeGreaterThan(0);
  });

  it("treats empty-string LOCAL_SERVICES_JSON as unset (no-op, Railway path runs)", async () => {
    const { fetchImpl, calls } = makeFetch([
      {
        status: 200,
        body: railwayProjectResponse([
          {
            id: "svc-1",
            name: "showcase-langgraph-python",
            image: "ghcr.io/org/langgraph-python:latest",
            domain: "langgraph-python.up.railway.app",
          },
        ]),
      },
      { status: 200, body: { data: { variables: {} } } },
    ]);
    const env = { ...BASE_ENV, LOCAL_SERVICES_JSON: "" };
    const out = await railwayServicesSource.enumerate(
      makeCtx(fetchImpl, env),
      {},
    );
    expect(out).toHaveLength(1);
    expect(calls.length).toBeGreaterThan(0);
  });

  it("applies namePrefix + nameExcludes filters to injected services", async () => {
    const localServices = [
      {
        name: "showcase-langgraph-python",
        publicUrl: "http://langgraph-python:10000",
        demos: ["agentic_chat"],
      },
      {
        name: "showcase-crewai-python",
        publicUrl: "http://crewai-python:10000",
        demos: ["agentic_chat"],
      },
      {
        name: "smoke-runner",
        publicUrl: "http://smoke-runner:10000",
        demos: [],
      },
    ];
    const env = {
      ...BASE_ENV,
      LOCAL_SERVICES_JSON: JSON.stringify(localServices),
    };
    const out = await railwayServicesSource.enumerate(makeCtx(NO_FETCH, env), {
      namePrefix: "showcase-",
      nameExcludes: ["showcase-crewai-python"],
    });
    // smoke-runner dropped by namePrefix; crewai dropped by nameExcludes.
    expect(out.map((s) => s.name)).toEqual(["showcase-langgraph-python"]);
  });

  it("throws DiscoverySourceSchemaError when LOCAL_SERVICES_JSON is not valid JSON", async () => {
    const env = { ...BASE_ENV, LOCAL_SERVICES_JSON: "{not json" };
    await expect(
      railwayServicesSource.enumerate(makeCtx(NO_FETCH, env), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceSchemaError);
  });

  it("throws DiscoverySourceSchemaError when LOCAL_SERVICES_JSON has the wrong shape", async () => {
    // Missing required `publicUrl`.
    const env = {
      ...BASE_ENV,
      LOCAL_SERVICES_JSON: JSON.stringify([{ name: "showcase-x" }]),
    };
    await expect(
      railwayServicesSource.enumerate(makeCtx(NO_FETCH, env), {}),
    ).rejects.toBeInstanceOf(DiscoverySourceSchemaError);
  });

  it("defaults demos to [] when an injected record omits it", async () => {
    const localServices = [
      {
        name: "showcase-langgraph-python",
        publicUrl: "http://langgraph-python:10000",
      },
    ];
    const env = {
      ...BASE_ENV,
      LOCAL_SERVICES_JSON: JSON.stringify(localServices),
    };
    const out = await railwayServicesSource.enumerate(
      makeCtx(NO_FETCH, env),
      {},
    );
    expect(out[0]!.demos).toEqual([]);
  });

  it("does not require Railway credentials on the injection path", async () => {
    // No RAILWAY_* creds at all — the injection path must not throw
    // DiscoverySourceAuthError because it never consults Railway.
    const localServices = [
      {
        name: "showcase-langgraph-python",
        publicUrl: "http://langgraph-python:10000",
        demos: ["agentic_chat"],
      },
    ];
    const env = { LOCAL_SERVICES_JSON: JSON.stringify(localServices) };
    const out = await railwayServicesSource.enumerate(
      makeCtx(NO_FETCH, env),
      {},
    );
    expect(out).toHaveLength(1);
    expect(out[0]!.demos).toEqual(["agentic_chat"]);
  });
});
