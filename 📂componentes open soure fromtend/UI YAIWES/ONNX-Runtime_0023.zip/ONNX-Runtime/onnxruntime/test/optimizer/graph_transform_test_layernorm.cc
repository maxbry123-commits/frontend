// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4244)
#endif

#include <algorithm>
#include <cstdint>
#include <type_traits>

#include "gtest/gtest.h"

#include "core/graph/onnx_protobuf.h"

#include "core/graph/graph_utils.h"
#include "core/graph/graph_viewer.h"
#include "core/graph/model.h"
#include "core/mlas/inc/mlas.h"
#include "core/optimizer/initializer.h"

#include "core/optimizer/bias_skip_layer_norm_fusion.h"
#include "core/optimizer/embed_layer_norm_fusion.h"
#include "core/optimizer/group_query_attention_fusion.h"
#include "core/optimizer/layer_norm_fusion.h"
#include "core/optimizer/skip_layer_norm_fusion.h"
#include "core/session/onnxruntime_session_options_config_keys.h"

#include "test/capturing_sink.h"
#include "test/unittest_util/framework_test_utils.h"
#include "test/optimizer/graph_transform_test_fixture.h"
#include "test/providers/provider_test_utils.h"
#include "test/unittest_util/graph_transform_test_builder.h"

using namespace std;
using namespace ONNX_NAMESPACE;

namespace onnxruntime {
namespace test {

#define MODEL_FOLDER ORT_TSTR("testdata/transform/")

#ifndef DISABLE_CONTRIB_OPS

static int GetCurrentOnnxOpset() {
  const auto& map = ONNX_NAMESPACE::OpSchemaRegistry::DomainToVersionRange::Instance().Map();
  auto it = map.find(ONNX_NAMESPACE::ONNX_DOMAIN);
  EXPECT_TRUE(it != map.end()) << "ONNX domain not found in OpSchemaRegistry";
  return it != map.end() ? it->second.second : 0;
}

TEST_F(GraphTransformationTests, LayerNormFusionTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Div"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["Sub"] == 0);
  ASSERT_TRUE(op_to_count["ReduceMean"] == 0);
  ASSERT_TRUE(op_to_count["Pow"] == 0);
  ASSERT_TRUE(op_to_count["Sqrt"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "LayerNormalization") {
      // LayerNormalization should have three inputs.
      EXPECT_EQ(node.InputDefs().size(), 3u)
          << "LayerNormalization number of inputs does not equal to 3. Got:" << node.InputDefs().size();
      // LayerNormalization input "scale" and "bias" should have the same dimension.
      const TensorShapeProto* scale_shape = node.InputDefs()[1]->Shape();
      const TensorShapeProto* bias_shape = node.InputDefs()[2]->Shape();
      EXPECT_EQ(scale_shape->dim_size(), 1)
          << "LayerNormalization scale should be 1D. Got: " << scale_shape->dim_size();
      EXPECT_EQ(bias_shape->dim_size(), 1)
          << "LayerNormalization bias should be 1D. Got: " << bias_shape->dim_size();
      EXPECT_EQ(scale_shape->dim(0).dim_value(), bias_shape->dim(0).dim_value());
    } else {
      EXPECT_TRUE(false) << "Unexpected node " << node.Name();
    }
  }
}

TEST_F(GraphTransformationTests, TwoLayerNormShareSameInput) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_shared_input.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count.size() == 1);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 2);
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_with_cast.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);

#ifdef ENABLE_TRAINING_CORE
  ASSERT_TRUE(op_to_count["Cast"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 1);
#else
  ASSERT_TRUE(op_to_count["Cast"] == 1);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 0);
#endif
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_2) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_with_cast_2.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);

  ASSERT_TRUE(op_to_count["Cast"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 1);
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_3) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_with_cast_3.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);

  ASSERT_TRUE(op_to_count["Cast"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 1);
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_4) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_with_cast_4.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);

  ASSERT_TRUE(op_to_count["Cast"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 1);
}

/*
ReduceMean:
  axes - INTS : A list of integers, along which to reduce.
  The default is to reduce over all the dimensions of the input tensor.
  Accepted range is [-r, r-1] where r = rank(data).
*/
TEST_F(GraphTransformationTests, LayerNormWithSubDupFusionTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_sub_dup.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Div"] > 0);
  ASSERT_TRUE(op_to_count["Add"] > 0);
  ASSERT_TRUE(op_to_count["Sub"] > 0);
  ASSERT_TRUE(op_to_count["ReduceMean"] > 0);
  ASSERT_TRUE(op_to_count["Pow"] > 0);
  ASSERT_TRUE(op_to_count["Sqrt"] > 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 0);
  /*
  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "LayerNormalization") {
      // LayerNormalization should have three inputs.
      EXPECT_EQ(node.InputDefs().size(), 3u) << "LayerNormalization number of inputs does not equal to 3. Got:" << node.InputDefs().size();
      // LayerNormalization input "scale" and "bias" should have the same dimension.
      const TensorShapeProto* scale_shape = node.InputDefs()[1]->Shape();
      const TensorShapeProto* bias_shape = node.InputDefs()[2]->Shape();
      EXPECT_EQ(scale_shape->dim_size(), 1) << "LayerNormalization scale should be 1D. Got: " << scale_shape->dim_size();
      EXPECT_EQ(bias_shape->dim_size(), 1) << "LayerNormalization bias should be 1D. Got: " << bias_shape->dim_size();
      EXPECT_EQ(scale_shape->dim(0).dim_value(), bias_shape->dim(0).dim_value());
    } else {
      EXPECT_TRUE(false) << "Unexpected node " << node.Name();
    }
  }
  */
}

void BuildLayerNorm(ModelTestBuilder& builder, std::vector<int64_t> reduce1_axes = {-1},
                    std::vector<int64_t> reduce2_axes = {-1}) {
  std::vector<int64_t> input_shape = {2, 3, 3, 3};
  auto* data_arg = builder.MakeInput<MLFloat16>(input_shape);
  auto* pow_initializer = builder.MakeInitializer<float>({}, {2.0f});
  auto* add_initializer = builder.MakeInitializer<float>({}, {1e-5f});
  std::vector<int64_t> normalized_shape = {};
  int64_t normalized_shape_size = 1;
  auto raxes = reduce1_axes;
  std::transform(raxes.begin(), raxes.end(), raxes.begin(), [&input_shape](int64_t i) {
    return i < 0 ? i + input_shape.size() : i;
  });
  sort(raxes.begin(), raxes.end());
  for (auto axis : raxes) {
    normalized_shape.push_back(input_shape[axis]);
    normalized_shape_size *= input_shape[axis];
  }

  auto* weight_initializer = builder.MakeInitializer<MLFloat16>(
      normalized_shape, std::vector<MLFloat16>(normalized_shape_size, MLFloat16(1.0f)));
  auto* bias_initializer = builder.MakeInitializer<MLFloat16>(
      normalized_shape, std::vector<MLFloat16>(normalized_shape_size, MLFloat16(0.0f)));
  auto* reduce_mean_out_1 = builder.MakeIntermediate();
  auto* sub_out = builder.MakeIntermediate();
  auto* cast_out_1 = builder.MakeIntermediate();
  auto* pow_out = builder.MakeIntermediate();
  auto* reduce_mean_out_2 = builder.MakeIntermediate();
  auto* add_out_1 = builder.MakeIntermediate();
  auto* sqrt_out = builder.MakeIntermediate();
  auto* div_out = builder.MakeIntermediate();
  auto* cast_out_2 = builder.MakeIntermediate();
  auto* mul_out = builder.MakeIntermediate();
  auto* add_out_2 = builder.MakeOutput();
  auto opset = builder.DomainToVersionMap().find(kOnnxDomain)->second;

  if (opset >= 18) {
    int64_t rsize = static_cast<int64_t>(reduce1_axes.size());
    onnxruntime::NodeArg* axes = builder.MakeInitializer<int64_t>({rsize}, reduce1_axes);
    builder.AddNode("ReduceMean", {data_arg, axes}, {reduce_mean_out_1});
  } else {
    builder.AddNode("ReduceMean", {data_arg}, {reduce_mean_out_1}).AddAttribute("axes", reduce1_axes);
  }
  builder.AddNode("Sub", {data_arg, reduce_mean_out_1}, {sub_out});
  builder.AddNode("Cast", {sub_out}, {cast_out_1})
      .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));
  builder.AddNode("Pow", {cast_out_1, pow_initializer}, {pow_out});
  if (opset >= 18) {
    int64_t rsize = static_cast<int64_t>(reduce2_axes.size());
    onnxruntime::NodeArg* axes = builder.MakeInitializer<int64_t>({rsize}, reduce2_axes);
    builder.AddNode("ReduceMean", {pow_out, axes}, {reduce_mean_out_2});
  } else {
    builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out_2}).AddAttribute("axes", reduce2_axes);
  }
  builder.AddNode("Add", {reduce_mean_out_2, add_initializer}, {add_out_1});
  builder.AddNode("Sqrt", {add_out_1}, {sqrt_out});
  builder.AddNode("Div", {cast_out_1, sqrt_out}, {div_out});
  builder.AddNode("Cast", {div_out}, {cast_out_2})
      .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT16));
  builder.AddNode("Mul", {cast_out_2, weight_initializer}, {mul_out});
  builder.AddNode("Add", {mul_out, bias_initializer}, {add_out_2});
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_5) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildLayerNorm(builder, {-1}, {-1});
  };

  auto pre_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 2);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 2);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 2);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 1);
    return Status::OK();
  };

  auto post_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 0);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == 1);
    return Status::OK();
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  std::unique_ptr<GraphTransformer> transformer_1 = std::make_unique<LayerNormFusion>();
  std::unique_ptr<GraphTransformer> transformer_2 =
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2);
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 18, *logger_, std::move(transformer_1),
                                        TransformerLevel::Level1, 1, pre_graph_checker, post_graph_checker));
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 14, *logger_, std::move(transformer_2),
                                        TransformerLevel::Level2, 1, pre_graph_checker, post_graph_checker));
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_6) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildLayerNorm(builder, {-2}, {-1});
  };

  int num_of_layer_norm = 0;
  auto post_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == num_of_layer_norm);
    return Status::OK();
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  std::unique_ptr<GraphTransformer> transformer_1 = std::make_unique<LayerNormFusion>();
  std::unique_ptr<GraphTransformer> transformer_2 =
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2);
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 18, *logger_, std::move(transformer_1),
                                        TransformerLevel::Level1, 1, nullptr, post_graph_checker));
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 14, *logger_, std::move(transformer_2),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_7) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildLayerNorm(builder, {-2, -1}, {-1, -2});
  };
#ifdef ENABLE_TRAINING_CORE
  int num_of_layer_norm = 1;
#else
  int num_of_layer_norm = 0;
#endif
  auto post_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == num_of_layer_norm);
    return Status::OK();
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  std::unique_ptr<GraphTransformer> transformer_1 = std::make_unique<LayerNormFusion>();
  std::unique_ptr<GraphTransformer> transformer_2 =
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2);
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 18, *logger_, std::move(transformer_1),
                                        TransformerLevel::Level1, 1, nullptr, post_graph_checker));
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 14, *logger_, std::move(transformer_2),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_8) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildLayerNorm(builder, {-3, -2, -1}, {-1, -2});
  };

  int num_of_layer_norm = 0;
  auto post_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == num_of_layer_norm);
    return Status::OK();
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  std::unique_ptr<GraphTransformer> transformer_1 = std::make_unique<LayerNormFusion>();
  std::unique_ptr<GraphTransformer> transformer_2 =
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2);
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 18, *logger_, std::move(transformer_1),
                                        TransformerLevel::Level1, 1, nullptr, post_graph_checker));
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 14, *logger_, std::move(transformer_2),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, LayerNormWithCastFusionTest_9) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildLayerNorm(builder, {2, -1}, {-1, -2});
  };

#ifdef ENABLE_TRAINING_CORE
  int num_of_layer_norm = 1;
#else
  int num_of_layer_norm = 0;
#endif
  auto post_graph_checker = [&](Graph& graph) {
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["ReduceMean"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sub"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Cast"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Pow"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 2 - 2 * num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Sqrt"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Div"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Mul"] == 1 - num_of_layer_norm);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == num_of_layer_norm);
    return Status::OK();
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  std::unique_ptr<GraphTransformer> transformer_1 = std::make_unique<LayerNormFusion>();
  std::unique_ptr<GraphTransformer> transformer_2 =
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2);
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 18, *logger_, std::move(transformer_1),
                                        TransformerLevel::Level1, 1, nullptr, post_graph_checker));
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 14, *logger_, std::move(transformer_2),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_t5.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SimplifiedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Div"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["ReduceMean"] == 0);
  ASSERT_TRUE(op_to_count["Pow"] == 0);
  ASSERT_TRUE(op_to_count["Sqrt"] == 0);
  ASSERT_TRUE(op_to_count["SimplifiedLayerNormalization"] == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "SimplifiedLayerNormalization") {
      // LayerNormalization should have two inputs.
      EXPECT_EQ(node.InputDefs().size(), 2u) << "LayerNormalization number of inputs does not equal to 2. Got:" << node.InputDefs().size();
      // LayerNormalization input "scale" and "bias" should have the same dimension.
      const TensorShapeProto* scale_shape = node.InputDefs()[1]->Shape();
      EXPECT_EQ(scale_shape->dim_size(), 1) << "LayerNormalization scale should be 1D. Got: " << scale_shape->dim_size();
    } else {
      EXPECT_TRUE(false) << "Unexpected node " << node.Name();
    }
  }
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionSharedCastPowExponent) {
  for (const bool has_leading_cast : {false, true}) {
    auto build_test_case = [has_leading_cast](ModelTestBuilder& builder) {
      auto* pow_exponent_fp16 =
          builder.MakeInitializer<MLFloat16>({}, {MLFloat16(2.0f)});
      auto* pow_exponent = builder.MakeIntermediate();
      builder.AddNode("Cast", {pow_exponent_fp16}, {pow_exponent})
          .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));

      auto* epsilon = builder.MakeInitializer<float>({}, {1e-5f});
      auto* scale = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});

      auto add_simplified_layer_norm = [&](NodeArg* input) {
        NodeArg* layer_norm_input = input;
        if (has_leading_cast) {
          layer_norm_input = builder.MakeIntermediate();
          builder.AddNode("Cast", {input}, {layer_norm_input})
              .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));
        }

        auto* pow_out = builder.MakeIntermediate();
        auto* reduce_mean_out = builder.MakeIntermediate();
        auto* add_out = builder.MakeIntermediate();
        auto* sqrt_out = builder.MakeIntermediate();
        auto* div_out = builder.MakeIntermediate();
        auto* output = builder.MakeOutput();

        builder.AddNode("Pow", {layer_norm_input, pow_exponent}, {pow_out});
        builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out})
            .AddAttribute("axes", std::vector<int64_t>{-1});
        builder.AddNode("Add", {reduce_mean_out, epsilon}, {add_out});
        builder.AddNode("Sqrt", {add_out}, {sqrt_out});
        builder.AddNode("Div", {layer_norm_input, sqrt_out}, {div_out});
        builder.AddNode("Mul", {div_out, scale}, {output});
      };

      auto make_input = [&]() -> NodeArg* {
        return has_leading_cast ? builder.MakeInput<MLFloat16>({{2, 4}})
                                : builder.MakeInput<float>({{2, 4}});
      };

      add_simplified_layer_norm(make_input());
      add_simplified_layer_norm(make_input());
    };

    auto pre_graph_checker = [has_leading_cast](Graph& graph) {
      if (has_leading_cast) {
        for (Node& node : graph.Nodes()) {
          node.SetExecutionProviderType(kCudaExecutionProvider);
        }
      }

      const auto op_to_count = CountOpsInGraph(graph);
      const auto cast_it = op_to_count.find("Cast");
      const int expected_cast_count = has_leading_cast ? 3 : 1;
      TEST_RETURN_IF_NOT(cast_it != op_to_count.end() && cast_it->second == expected_cast_count);
      const auto pow_it = op_to_count.find("Pow");
      TEST_RETURN_IF_NOT(pow_it != op_to_count.end() && pow_it->second == 2);
      return Status::OK();
    };

    auto post_graph_checker = [has_leading_cast](Graph& graph) {
      const auto op_to_count = CountOpsInGraph(graph);
      const auto simplified_layer_norm_it = op_to_count.find("SimplifiedLayerNormalization");
      TEST_RETURN_IF_NOT(simplified_layer_norm_it != op_to_count.end() &&
                         simplified_layer_norm_it->second == 2);
      TEST_RETURN_IF_NOT(op_to_count.find("Cast") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("Pow") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("ReduceMean") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("Add") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("Sqrt") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("Div") == op_to_count.end());
      TEST_RETURN_IF_NOT(op_to_count.find("Mul") == op_to_count.end());

      if (has_leading_cast) {
        for (const Node& node : graph.Nodes()) {
          if (node.OpType() == "SimplifiedLayerNormalization") {
            TEST_RETURN_IF_NOT(node.GetExecutionProviderType() == kCudaExecutionProvider);
          }
        }
      }

      return Status::OK();
    };

    const InlinedHashSet<std::string_view> compatible_eps;
    ASSERT_STATUS_OK(TestGraphTransformer(
        build_test_case, 17, *logger_,
        std::make_unique<SimplifiedLayerNormFusion>(compatible_eps),
        TransformerLevel::Level2, 1, pre_graph_checker, post_graph_checker));
  }
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionAddEpsilonInput0) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* input = builder.MakeInput<float>({{2, 4}});
    auto* pow_exponent = builder.MakeInitializer<float>({}, {2.0f});
    auto* epsilon = builder.MakeInitializer<float>({}, {1e-4f});
    auto* scale = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});

    auto* pow_out = builder.MakeIntermediate();
    auto* reduce_mean_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sqrt_out = builder.MakeIntermediate();
    auto* div_out = builder.MakeIntermediate();
    auto* output = builder.MakeOutput();

    builder.AddNode("Pow", {input, pow_exponent}, {pow_out});
    builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out})
        .AddAttribute("axes", std::vector<int64_t>{-1});
    builder.AddNode("Add", {epsilon, reduce_mean_out}, {add_out});
    builder.AddNode("Sqrt", {add_out}, {sqrt_out});
    builder.AddNode("Div", {input, sqrt_out}, {div_out});
    builder.AddNode("Mul", {div_out, scale}, {output});
  };

  auto post_graph_checker = [](Graph& graph) {
    const auto op_to_count = CountOpsInGraph(graph);
    const auto simplified_layer_norm_it = op_to_count.find("SimplifiedLayerNormalization");
    TEST_RETURN_IF_NOT(simplified_layer_norm_it != op_to_count.end() &&
                       simplified_layer_norm_it->second == 1);

    for (const Node& node : graph.Nodes()) {
      if (node.OpType() == "SimplifiedLayerNormalization") {
        const auto& attributes = node.GetAttributes();
        const auto epsilon_it = attributes.find("epsilon");
        TEST_RETURN_IF_NOT(epsilon_it != attributes.end());
        TEST_RETURN_IF_NOT(epsilon_it->second.f() == 1e-4f);
      }
    }

    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(
      build_test_case, 17, *logger_,
      std::make_unique<SimplifiedLayerNormFusion>(),
      TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionAllowsIntegerPowExponentTwo) {
  auto run_test = [this](auto exponent_value) {
    using T = std::decay_t<decltype(exponent_value)>;

    auto build_test_case = [exponent_value](ModelTestBuilder& builder) {
      auto* input = builder.MakeInput<float>({{2, 4}});
      auto* pow_exponent = builder.MakeInitializer<T>({}, {exponent_value});
      auto* epsilon = builder.MakeInitializer<float>({}, {1e-5f});
      auto* scale = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});

      auto* pow_out = builder.MakeIntermediate();
      auto* reduce_mean_out = builder.MakeIntermediate();
      auto* add_out = builder.MakeIntermediate();
      auto* sqrt_out = builder.MakeIntermediate();
      auto* div_out = builder.MakeIntermediate();
      auto* output = builder.MakeOutput();

      builder.AddNode("Pow", {input, pow_exponent}, {pow_out});
      builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out})
          .AddAttribute("axes", std::vector<int64_t>{-1});
      builder.AddNode("Add", {reduce_mean_out, epsilon}, {add_out});
      builder.AddNode("Sqrt", {add_out}, {sqrt_out});
      builder.AddNode("Div", {input, sqrt_out}, {div_out});
      builder.AddNode("Mul", {div_out, scale}, {output});
    };

    auto post_graph_checker = [](Graph& graph) {
      const auto op_to_count = CountOpsInGraph(graph);
      const auto simplified_layer_norm_it = op_to_count.find("SimplifiedLayerNormalization");
      TEST_RETURN_IF_NOT(simplified_layer_norm_it != op_to_count.end() &&
                         simplified_layer_norm_it->second == 1);
      TEST_RETURN_IF_NOT(op_to_count.find("Pow") == op_to_count.end());
      return Status::OK();
    };

    ASSERT_STATUS_OK(TestGraphTransformer(
        build_test_case, 17, *logger_,
        std::make_unique<SimplifiedLayerNormFusion>(),
        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
  };

  run_test(int8_t{2});
  run_test(uint8_t{2});
  run_test(int32_t{2});
  run_test(int64_t{2});
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionRequiresPowExponentTwo) {
  for (const bool has_cast_exponent : {false, true}) {
    auto build_test_case = [has_cast_exponent](ModelTestBuilder& builder) {
      auto* input = builder.MakeInput<float>({{2, 4}});
      NodeArg* pow_exponent = nullptr;
      if (has_cast_exponent) {
        auto* pow_exponent_fp16 = builder.MakeInitializer<MLFloat16>({}, {MLFloat16(3.0f)});
        pow_exponent = builder.MakeIntermediate();
        builder.AddNode("Cast", {pow_exponent_fp16}, {pow_exponent})
            .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));
      } else {
        pow_exponent = builder.MakeInitializer<float>({}, {3.0f});
      }

      auto* epsilon = builder.MakeInitializer<float>({}, {1e-5f});
      auto* scale = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});

      auto* pow_out = builder.MakeIntermediate();
      auto* reduce_mean_out = builder.MakeIntermediate();
      auto* add_out = builder.MakeIntermediate();
      auto* sqrt_out = builder.MakeIntermediate();
      auto* div_out = builder.MakeIntermediate();
      auto* output = builder.MakeOutput();

      builder.AddNode("Pow", {input, pow_exponent}, {pow_out});
      builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out})
          .AddAttribute("axes", std::vector<int64_t>{-1});
      builder.AddNode("Add", {reduce_mean_out, epsilon}, {add_out});
      builder.AddNode("Sqrt", {add_out}, {sqrt_out});
      builder.AddNode("Div", {input, sqrt_out}, {div_out});
      builder.AddNode("Mul", {div_out, scale}, {output});
    };

    auto post_graph_checker = [](Graph& graph) {
      const auto op_to_count = CountOpsInGraph(graph);
      TEST_RETURN_IF_NOT(op_to_count.find("SimplifiedLayerNormalization") == op_to_count.end());
      const auto pow_it = op_to_count.find("Pow");
      TEST_RETURN_IF_NOT(pow_it != op_to_count.end() && pow_it->second == 1);
      return Status::OK();
    };

    ASSERT_STATUS_OK(TestGraphTransformer(
        build_test_case, 17, *logger_,
        std::make_unique<SimplifiedLayerNormFusion>(),
        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
  }
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormFusionOptimizationLoopSharedPowExponent) {
  if (MlasFp16AccelerationSupported()) {
    GTEST_SKIP() << "Skipping test because FP16 acceleration support can avoid the CPU fp16 fallback path.";
  }

  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* pow_exponent = builder.MakeInitializer<MLFloat16>({}, {MLFloat16(2.0f)});

    auto add_simplified_layer_norm = [&](const std::vector<MLFloat16>& input_data) {
      auto* input = builder.MakeInput<MLFloat16>({2, 4}, input_data);
      auto* epsilon = builder.MakeInitializer<MLFloat16>({}, {MLFloat16(1e-4f)});
      auto* scale = builder.MakeInitializer<MLFloat16>(
          {4}, {MLFloat16(1.0f), MLFloat16(1.0f), MLFloat16(1.0f), MLFloat16(1.0f)});

      auto* pow_out = builder.MakeIntermediate();
      auto* reduce_mean_out = builder.MakeIntermediate();
      auto* add_out = builder.MakeIntermediate();
      auto* sqrt_out = builder.MakeIntermediate();
      auto* div_out = builder.MakeIntermediate();
      auto* output = builder.MakeOutput();

      builder.AddNode("Pow", {input, pow_exponent}, {pow_out});
      builder.AddNode("ReduceMean", {pow_out}, {reduce_mean_out})
          .AddAttribute("axes", std::vector<int64_t>{-1});
      builder.AddNode("Add", {reduce_mean_out, epsilon}, {add_out});
      builder.AddNode("Sqrt", {add_out}, {sqrt_out});
      builder.AddNode("Div", {input, sqrt_out}, {div_out});
      builder.AddNode("Mul", {div_out, scale}, {output});
    };

    add_simplified_layer_norm({MLFloat16(0.5f), MLFloat16(1.0f), MLFloat16(1.5f), MLFloat16(2.0f),
                               MLFloat16(2.5f), MLFloat16(3.0f), MLFloat16(3.5f), MLFloat16(4.0f)});
    add_simplified_layer_norm({MLFloat16(1.0f), MLFloat16(1.25f), MLFloat16(1.5f), MLFloat16(1.75f),
                               MLFloat16(2.0f), MLFloat16(2.25f), MLFloat16(2.5f), MLFloat16(2.75f)});

    // This independent branch provides FuseInitializersTransformer with single-consumer FP16
    // initializer Casts to fold at L4. With loop level 1, that L4 modification triggers the next L2 pass.
    std::vector<MLFloat16> conv_input_data(25, MLFloat16(1.0f));
    auto* conv_input = builder.MakeInput<MLFloat16>({1, 1, 5, 5}, conv_input_data);
    auto* conv_weight = builder.MakeInitializer<MLFloat16>(
        {1, 1, 3, 3}, std::vector<MLFloat16>(9, MLFloat16(0.25f)));
    auto* conv_bias = builder.MakeInitializer<MLFloat16>({1}, {MLFloat16(0.0f)});
    auto* conv_output = builder.MakeOutput();
    builder.AddNode("Conv", {conv_input, conv_weight, conv_bias}, {conv_output});
  };

  auto op_count = [](const std::map<std::string, int>& op_to_count, const std::string& op_type) {
    const auto it = op_to_count.find(op_type);
    return it == op_to_count.end() ? 0 : it->second;
  };

  auto set_graph_optimization_loop_level = [](const char* loop_level) {
    return [loop_level](SessionOptions& session_options) {
      ASSERT_STATUS_OK(session_options.config_options.AddConfigEntry(
          kOrtSessionOptionsGraphOptimizationsLoopLevel, loop_level));
    };
  };

  auto check_without_l2_repeat = [&](InferenceSessionWrapper& session) {
    const auto op_to_count = CountOpsInGraph(session.GetGraph());
    EXPECT_EQ(op_count(op_to_count, "SimplifiedLayerNormalization"), 0);
    EXPECT_EQ(op_count(op_to_count, "Pow"), 2);

    int cpu_pow_count = 0;
    for (const Node& node : session.GetGraph().Nodes()) {
      if (node.OpType() == "Pow") {
        EXPECT_EQ(node.GetExecutionProviderType(), kCpuExecutionProvider);
        ++cpu_pow_count;
      }
    }
    EXPECT_EQ(cpu_pow_count, 2);
  };

  auto check_with_l2_repeat = [&](InferenceSessionWrapper& session) {
    const auto op_to_count = CountOpsInGraph(session.GetGraph());
    EXPECT_EQ(op_count(op_to_count, "SimplifiedLayerNormalization"), 2);
    EXPECT_EQ(op_count(op_to_count, "Pow"), 0);
    EXPECT_EQ(op_count(op_to_count, "ReduceMean"), 0);
    EXPECT_EQ(op_count(op_to_count, "Add"), 0);
    EXPECT_EQ(op_count(op_to_count, "Sqrt"), 0);
    EXPECT_EQ(op_count(op_to_count, "Div"), 0);
    EXPECT_EQ(op_count(op_to_count, "Mul"), 0);

    int cpu_simplified_layer_norm_count = 0;
    int inserted_cast_count = 0;
    for (const Node& node : session.GetGraph().Nodes()) {
      if (node.OpType() == "SimplifiedLayerNormalization") {
        EXPECT_EQ(node.GetExecutionProviderType(), kCpuExecutionProvider);
        ++cpu_simplified_layer_norm_count;
      } else if (node.OpType() == "Cast" &&
                 node.Name().find("InsertedPrecisionFreeCast_") == 0) {
        ++inserted_cast_count;
      }
    }
    EXPECT_EQ(cpu_simplified_layer_norm_count, 2);
    EXPECT_GE(inserted_cast_count, 2);
  };

  TransformerTester(build_test_case, check_without_l2_repeat,
                    TransformerLevel::Level1, TransformerLevel::MaxLevel, 17,
                    1e-3, 1e-3, nullptr, set_graph_optimization_loop_level("0"));
  TransformerTester(build_test_case, check_with_l2_repeat,
                    TransformerLevel::Level1, TransformerLevel::MaxLevel, 17,
                    1e-3, 1e-3, nullptr, set_graph_optimization_loop_level("1"));
}

// It tests the scenario when scale or bias are not Graph Inputs and not initialized in Graph
// To test this added a Identity node after Scale and Bias terms to ensure LayerNormFusion works properly
TEST_F(GraphTransformationTests, LayerNormScaleBiasTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/layer_norm_fusion_scale_bias.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_EQ(op_to_count["ReduceMean"], 0);
  ASSERT_EQ(op_to_count["Sub"], 0);
  ASSERT_EQ(op_to_count["Cast"], 0);
  ASSERT_EQ(op_to_count["Pow"], 0);
  ASSERT_EQ(op_to_count["Add"], 0);
  ASSERT_EQ(op_to_count["Sqrt"], 0);
  ASSERT_EQ(op_to_count["Div"], 0);
  ASSERT_EQ(op_to_count["Mul"], 0);
  ASSERT_EQ(op_to_count["LayerNormalization"], 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "LayerNormalization") {
      // LayerNormalization should have three inputs.
      EXPECT_EQ(node.InputDefs().size(), 3u) << "LayerNormalization number of inputs does not equal to 3. Got:" << node.InputDefs().size();
      // LayerNormalization input "scale" and "bias" should have the same dimension.
      const TensorShapeProto* scale_shape = node.InputDefs()[1]->Shape();
      EXPECT_EQ(scale_shape->dim_size(), 1) << "LayerNormalization scale should be 1D. Got: " << scale_shape->dim_size();
    }
  }
}

// If EP is non-GPU EP or unknown, the sub-graph will be not fused because CPU impl for SimplifiedLayerNormalization
// doesn't support input and scale having different data types.
TEST_F(GraphTransformationTests, SimplifiedLayerNormWithCastsFusionTest) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/simplified_layer_norm_with_casts.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  InlinedHashSet<std::string_view> compatible_eps;
  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SimplifiedLayerNormFusion>(compatible_eps),
                                                     TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["SimplifiedLayerNormalization"] == 0);
}

TEST_F(GraphTransformationTests, SimplifiedLayerNormWithCastsFusionTestCudaEp) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/simplified_layer_norm_with_casts.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();
  for (auto& node : graph.Nodes()) {
    node.SetExecutionProviderType(kCudaExecutionProvider);
  }

  InlinedHashSet<std::string_view> compatible_eps;
  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SimplifiedLayerNormFusion>(compatible_eps),
                                                     TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Div"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["ReduceMean"] == 0);
  ASSERT_TRUE(op_to_count["Pow"] == 0);
  ASSERT_TRUE(op_to_count["Sqrt"] == 0);
  ASSERT_TRUE(op_to_count["Cast"] == 0);
  ASSERT_TRUE(op_to_count["SimplifiedLayerNormalization"] == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "SimplifiedLayerNormalization") {
      // LayerNormalization should have two inputs.
      EXPECT_EQ(node.InputDefs().size(), 2u)
          << "LayerNormalization number of inputs does not equal to 2. Got:" << node.InputDefs().size();
      // LayerNormalization input "scale" and "bias" should have the same dimension.
      const TensorShapeProto* scale_shape = node.InputDefs()[1]->Shape();
      EXPECT_EQ(scale_shape->dim_size(), 1)
          << "LayerNormalization scale should be 1D. Got: " << scale_shape->dim_size();
    } else if (node.OpType() == "Cast") {
      continue;
    } else {
      EXPECT_TRUE(false) << "Unexpected node " << node.Name();
    }
  }
}

static void TestGQAFusion(const std::basic_string<ORTCHAR_T>& file_path, int matmulnbits_count, int matmul_count, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{3};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<GroupQueryAttentionFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["com.microsoft.RotaryEmbedding"] == 0);
  ASSERT_TRUE(op_to_count["com.microsoft.MatMulNBits"] == matmulnbits_count);
  ASSERT_TRUE(op_to_count["MatMul"] == matmul_count);
  ASSERT_TRUE(op_to_count["com.microsoft.GroupQueryAttention"] == 1);
}

static void TestQuantizedGQAFusionRejectsInitializerShape(const std::string& initializer_name,
                                                          logging::Logger* logger) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/gqa_fusion_quantized_simple.onnx";
  std::shared_ptr<Model> model;
  ASSERT_STATUS_OK(Model::Load(model_uri, model, nullptr, *logger));
  Graph& graph = model->MainGraph();

  const TensorProto* initializer = nullptr;
  ASSERT_TRUE(graph.GetInitializedTensor(initializer_name, initializer));
  TensorProto malformed_initializer = *initializer;
  malformed_initializer.clear_dims();
  malformed_initializer.add_dims(1);
  graph.RemoveInitializedTensor(initializer_name);
  graph.AddInitializedTensor(malformed_initializer);

  GraphTransformerManager graph_transformation_mgr{3};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<GroupQueryAttentionFusion>(),
                                                     TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  const auto op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count.at("com.microsoft.MatMulNBits"), 3);
  EXPECT_EQ(op_to_count.at("com.microsoft.RotaryEmbedding"), 2);
  EXPECT_EQ(op_to_count.at("com.microsoft.GroupQueryAttention"), 1);
}

enum class RotaryEmbeddingDomain {
  kOnnx,
  kMS,
};

static void BuildRotaryEmbeddingGQAFusionGraph(ModelTestBuilder& builder,
                                               RotaryEmbeddingDomain rotary_domain,
                                               bool include_position_ids,
                                               int64_t q_interleaved = 0,
                                               int64_t k_interleaved = 0,
                                               int64_t rotary_embedding_dim = 0,
                                               int64_t gqa_num_heads = 2) {
  constexpr int64_t batch_size = 1;
  constexpr int64_t sequence_length = 2;
  constexpr int64_t input_hidden_size = 8;
  constexpr int64_t num_heads = 2;
  constexpr int64_t kv_num_heads = 1;
  const int64_t head_size = rotary_embedding_dim == 0 ? 16 : 32;
  const int64_t q_hidden_size = num_heads * head_size;
  const int64_t kv_hidden_size = kv_num_heads * head_size;
  constexpr int64_t max_sequence_length = 8;
  const int64_t half_rotary_dim = (rotary_embedding_dim == 0 ? head_size : rotary_embedding_dim) / 2;

  auto make_weight = [&builder](int64_t rows, int64_t cols, float value) {
    return builder.MakeInitializer<MLFloat16>(
        {rows, cols}, std::vector<MLFloat16>(static_cast<size_t>(rows * cols), MLFloat16(value)));
  };

  NodeArg* input = builder.MakeInput<MLFloat16>({{batch_size, sequence_length, input_hidden_size}});
  NodeArg* q_weight = make_weight(input_hidden_size, q_hidden_size, 0.5f);
  NodeArg* k_weight = make_weight(input_hidden_size, kv_hidden_size, 0.25f);
  NodeArg* v_weight = make_weight(input_hidden_size, kv_hidden_size, 0.125f);

  NodeArg* q_matmul_out =
      builder.MakeIntermediate<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, q_hidden_size});
  NodeArg* k_matmul_out =
      builder.MakeIntermediate<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, kv_hidden_size});
  NodeArg* v_matmul_out =
      builder.MakeIntermediate<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, kv_hidden_size});
  builder.AddNode("MatMul", {input, q_weight}, {q_matmul_out});
  builder.AddNode("MatMul", {input, k_weight}, {k_matmul_out});
  builder.AddNode("MatMul", {input, v_weight}, {v_matmul_out});

  const std::vector<int64_t> cache_shape = include_position_ids
                                               ? std::vector<int64_t>{max_sequence_length, half_rotary_dim}
                                               : std::vector<int64_t>{batch_size, sequence_length, half_rotary_dim};
  NodeArg* cos_cache = builder.MakeInput<MLFloat16>(cache_shape);
  NodeArg* sin_cache = builder.MakeInput<MLFloat16>(cache_shape);
  NodeArg* position_ids = include_position_ids
                              ? builder.MakeInput<int64_t>({{batch_size, sequence_length}})
                              : nullptr;

  NodeArg* q_rotary_out =
      builder.MakeIntermediate<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, q_hidden_size});
  NodeArg* k_rotary_out =
      builder.MakeIntermediate<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, kv_hidden_size});

  std::vector<NodeArg*> q_rotary_inputs;
  std::vector<NodeArg*> k_rotary_inputs;
  const char* rotary_domain_name =
      rotary_domain == RotaryEmbeddingDomain::kMS ? kMSDomain : kOnnxDomain;
  if (rotary_domain == RotaryEmbeddingDomain::kMS) {
    q_rotary_inputs = {q_matmul_out, position_ids, cos_cache, sin_cache};
    k_rotary_inputs = {k_matmul_out, position_ids, cos_cache, sin_cache};
  } else {
    q_rotary_inputs = {q_matmul_out, cos_cache, sin_cache};
    k_rotary_inputs = {k_matmul_out, cos_cache, sin_cache};
    if (position_ids != nullptr) {
      q_rotary_inputs.push_back(position_ids);
      k_rotary_inputs.push_back(position_ids);
    }
  }

  Node& q_rotary = builder.AddNode("RotaryEmbedding", q_rotary_inputs, {q_rotary_out}, rotary_domain_name);
  q_rotary.AddAttribute("num_heads", num_heads);
  q_rotary.AddAttribute("interleaved", q_interleaved);
  q_rotary.AddAttribute("rotary_embedding_dim", rotary_embedding_dim);
  Node& k_rotary = builder.AddNode("RotaryEmbedding", k_rotary_inputs, {k_rotary_out}, rotary_domain_name);
  k_rotary.AddAttribute("num_heads", kv_num_heads);
  k_rotary.AddAttribute("interleaved", k_interleaved);
  k_rotary.AddAttribute("rotary_embedding_dim", rotary_embedding_dim);

  NodeArg* past_key =
      builder.MakeInput<MLFloat16>({{batch_size, kv_num_heads, max_sequence_length, head_size}});
  NodeArg* past_value =
      builder.MakeInput<MLFloat16>({{batch_size, kv_num_heads, max_sequence_length, head_size}});
  NodeArg* seqlens_k = builder.MakeInput<int32_t>({{batch_size}});
  NodeArg* total_sequence_length = builder.MakeInput<int32_t>({{1}});
  NodeArg* gqa_output =
      builder.MakeOutput<MLFloat16>(std::vector<int64_t>{batch_size, sequence_length, q_hidden_size});

  Node& gqa = builder.AddNode("GroupQueryAttention",
                              {q_rotary_out, k_rotary_out, v_matmul_out, past_key, past_value,
                               seqlens_k, total_sequence_length},
                              {gqa_output},
                              kMSDomain);
  gqa.AddAttribute("num_heads", gqa_num_heads);
  gqa.AddAttribute("kv_num_heads", kv_num_heads);
}

static Status CheckOnnxRotaryEmbeddingGQANotFused(Graph& graph) {
  const auto op_to_count = CountOpsInGraph(graph);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "RotaryEmbedding") == 2);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "MatMul") == 3);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "com.microsoft.GroupQueryAttention") == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() != "GroupQueryAttention") {
      continue;
    }

    TEST_RETURN_IF_NOT(node.InputDefs().size() == 7);
    const auto& attrs = node.GetAttributes();
    auto do_rotary_attr = attrs.find("do_rotary");
    TEST_RETURN_IF_NOT(do_rotary_attr == attrs.end() || do_rotary_attr->second.i() == 0);
  }

  return Status::OK();
}

static Status CheckMsRotaryEmbeddingGQANotFused(Graph& graph) {
  const auto op_to_count = CountOpsInGraph(graph);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "com.microsoft.RotaryEmbedding") == 2);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "MatMul") == 3);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "com.microsoft.GroupQueryAttention") == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() != "GroupQueryAttention") {
      continue;
    }

    TEST_RETURN_IF_NOT(node.InputDefs().size() == 7);
    const auto& attrs = node.GetAttributes();
    const auto do_rotary_attr = attrs.find("do_rotary");
    TEST_RETURN_IF_NOT(do_rotary_attr == attrs.end() || do_rotary_attr->second.i() == 0);
  }

  return Status::OK();
}

static Status CheckMsRotaryEmbeddingGQAFused(Graph& graph, int64_t expected_interleaved) {
  const auto op_to_count = CountOpsInGraph(graph);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "com.microsoft.RotaryEmbedding") == 0);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "MatMul") == 1);
  TEST_RETURN_IF_NOT(OpCount(op_to_count, "com.microsoft.GroupQueryAttention") == 1);

  for (const Node& node : graph.Nodes()) {
    if (node.OpType() != "GroupQueryAttention") {
      continue;
    }

    const auto& input_defs = node.InputDefs();
    TEST_RETURN_IF_NOT(input_defs.size() == 10);
    TEST_RETURN_IF_NOT(input_defs[9] != nullptr && input_defs[9]->Exists());

    const auto& attrs = node.GetAttributes();
    const auto do_rotary_attr = attrs.find("do_rotary");
    TEST_RETURN_IF_NOT(do_rotary_attr != attrs.end() && do_rotary_attr->second.i() == 1);
    const auto interleaved_attr = attrs.find("rotary_interleaved");
    TEST_RETURN_IF_NOT(interleaved_attr != attrs.end() &&
                       interleaved_attr->second.i() == expected_interleaved);
  }

  return Status::OK();
}

static void TestSkipLayerNormFusion(const std::basic_string<ORTCHAR_T>& file_path, int add_count, int ln_count,
                                    int skip_ln_count, int cast_count, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SkipLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Div"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == add_count);
  ASSERT_TRUE(op_to_count["Sub"] == 0);
  ASSERT_TRUE(op_to_count["ReduceMean"] == 0);
  ASSERT_TRUE(op_to_count["Pow"] == 0);
  ASSERT_TRUE(op_to_count["Sqrt"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == ln_count);
  ASSERT_TRUE(op_to_count["com.microsoft.SkipLayerNormalization"] == skip_ln_count);
  ASSERT_TRUE(op_to_count["Cast"] == cast_count);
}

// Current-opset regression tests for LayerNorm and SkipLayerNorm fusions.
// These construct minimal graphs at the current ONNX opset and verify the optimizer fires.

TEST_F(GraphTransformationTests, LayerNormFusionCurrentOpsetTest) {
  // LayerNorm pattern: ReduceMean -> Sub -> Pow(2) -> ReduceMean -> Add(eps) -> Sqrt -> Div -> Mul(gamma) -> Add(beta)
  int current_opset = GetCurrentOnnxOpset();
  auto build_test_case = [](ModelTestBuilder& builder) {
    constexpr int64_t hidden_size = 64;
    auto* input = builder.MakeInput<float>({{2, 3, hidden_size}});
    auto* gamma = builder.MakeInitializer<float>({hidden_size}, -1.0f, 1.0f);
    auto* beta = builder.MakeInitializer<float>({hidden_size}, -0.5f, 0.5f);
    auto* two = builder.MakeInitializer<float>({}, {2.0f});
    auto* eps = builder.MakeInitializer<float>({}, {1e-5f});

    auto* axes = builder.MakeInitializer<int64_t>({1}, {-1});
    auto* mean1_out = builder.MakeIntermediate();
    auto* sub_out = builder.MakeIntermediate();
    auto* pow_out = builder.MakeIntermediate();
    auto* mean2_out = builder.MakeIntermediate();
    auto* add_eps_out = builder.MakeIntermediate();
    auto* sqrt_out = builder.MakeIntermediate();
    auto* div_out = builder.MakeIntermediate();
    auto* mul_out = builder.MakeIntermediate();
    auto* output = builder.MakeOutput();

    builder.AddNode("ReduceMean", {input, axes}, {mean1_out});
    builder.AddNode("Sub", {input, mean1_out}, {sub_out});
    builder.AddNode("Pow", {sub_out, two}, {pow_out});
    builder.AddNode("ReduceMean", {pow_out, axes}, {mean2_out});
    builder.AddNode("Add", {mean2_out, eps}, {add_eps_out});
    builder.AddNode("Sqrt", {add_eps_out}, {sqrt_out});
    builder.AddNode("Div", {sub_out, sqrt_out}, {div_out});
    builder.AddNode("Mul", {div_out, gamma}, {mul_out});
    builder.AddNode("Add", {mul_out, beta}, {output});
  };

  auto post_graph_checker = [current_opset](Graph& graph) {
    auto op_to_count = CountOpsInGraph(graph);
    if (op_to_count["LayerNormalization"] == 1) {
      TEST_RETURN_IF_NOT(op_to_count["ReduceMean"] == 0);
      TEST_RETURN_IF_NOT(op_to_count["Sub"] == 0);
      TEST_RETURN_IF_NOT(op_to_count["Pow"] == 0);
      TEST_RETURN_IF_NOT(op_to_count["Sqrt"] == 0);
      TEST_RETURN_IF_NOT(op_to_count["Div"] == 0);
      return Status::OK();
    }
    return ORT_MAKE_STATUS(ONNXRUNTIME, FAIL,
                           "LayerNorm fusion failed at opset ", current_opset,
                           ". Remaining ops: ReduceMean=", op_to_count["ReduceMean"],
                           " Sub=", op_to_count["Sub"],
                           " Pow=", op_to_count["Pow"],
                           " Sqrt=", op_to_count["Sqrt"],
                           " Div=", op_to_count["Div"],
                           ". Either update version lists in "
                           "onnxruntime/core/optimizer/layer_norm_fusion.cc"
                           " or skip this opset in the test if the fusion is not expected to apply.");
  };

  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  // LayerNorm fusion at Level1 when opset >= 17 (ONNX LayerNormalization available).
  // At Level2, it skips if fuse_in_level_1 is true.
  // opset 27 is under development in ONNX 1.22 (released map-max 27 > last release 26), so strict legs
  // reject this *CurrentOpset model at load; allow the unreleased opset. Remove once opset 27 ships. #28966.
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, current_opset, *logger_,
                                        std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level1),
                                        TransformerLevel::Level1, 1, nullptr, post_graph_checker,
                                        ModelOptions{kAllowReleasedOpsetsOnly, /*strict_shape_type_inference*/ false}));
}

TEST_F(GraphTransformationTests, SkipLayerNormFusionCurrentOpsetTest) {
  // SkipLayerNorm pattern: Add(input, skip) -> LayerNormalization(gamma, beta)
  int current_opset = GetCurrentOnnxOpset();
  auto build_test_case = [](ModelTestBuilder& builder) {
    constexpr int64_t hidden_size = 64;
    auto* input = builder.MakeInput<float>({{2, 3, hidden_size}});
    auto* skip = builder.MakeInput<float>({{2, 3, hidden_size}});
    auto* gamma = builder.MakeInitializer<float>({hidden_size}, -1.0f, 1.0f);
    auto* beta = builder.MakeInitializer<float>({hidden_size}, -0.5f, 0.5f);

    auto* add_out = builder.MakeIntermediate();
    auto* output = builder.MakeOutput();

    builder.AddNode("Add", {input, skip}, {add_out});
    builder.AddNode("LayerNormalization", {add_out, gamma, beta}, {output})
        .AddAttribute("axis", static_cast<int64_t>(-1));
  };

  auto post_graph_checker = [current_opset](Graph& graph) {
    auto op_to_count = CountOpsInGraph(graph);
    if (op_to_count["com.microsoft.SkipLayerNormalization"] == 1) {
      TEST_RETURN_IF_NOT(op_to_count["Add"] == 0);
      TEST_RETURN_IF_NOT(op_to_count["LayerNormalization"] == 0);
      return Status::OK();
    }
    return ORT_MAKE_STATUS(ONNXRUNTIME, FAIL,
                           "SkipLayerNorm fusion failed at opset ", current_opset,
                           ". Remaining ops: Add=", op_to_count["Add"],
                           " LayerNormalization=", op_to_count["LayerNormalization"],
                           ". Either update version lists in "
                           "onnxruntime/core/optimizer/skip_layer_norm_fusion.cc"
                           " or skip this opset in the test if the fusion is not expected to apply.");
  };

  // opset 27 is under development in ONNX 1.22 (released map-max 27 > last release 26), so strict legs
  // reject this *CurrentOpset model at load; allow the unreleased opset. Remove once opset 27 ships. #28966.
  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, current_opset, *logger_,
                                        std::make_unique<SkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker,
                                        ModelOptions{kAllowReleasedOpsetsOnly, /*strict_shape_type_inference*/ false}));
}

TEST_F(GraphTransformationTests, SkipLayerNormFusionTest) {
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1.onnx", 0, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2.onnx", 0, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3.onnx", 0, 0, 1, 0, logger_.get());

  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1_partial.onnx", 1, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2_partial.onnx", 1, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3_no_fusion.onnx", 1, 1, 0, 0, logger_.get());

  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1_graph_output.onnx", 1, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2_graph_output.onnx", 1, 0, 1, 0, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3_graph_output.onnx", 1, 1, 0, 0, logger_.get());
}

// SkipLayerNorm fusion should not be applied when gamma/beta have more than 1 dimension,
// because the SkipLayerNormalization kernel requires 1D gamma/beta.
TEST_F(GraphTransformationTests, SkipLayerNormFusion_3DGamma_NoFusion) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    // Inputs: A and B are 3D [16, 32, 4]
    auto* input_a = builder.MakeInput<float>({16, 32, 4}, -1.0f, 1.0f);
    auto* input_b = builder.MakeInput<float>({16, 32, 4}, -1.0f, 1.0f);
    // gamma and beta have 3D shape [1, 1, 4] (not 1D)
    auto* gamma = builder.MakeInitializer<float>({1, 1, 4}, {1.0f, 2.0f, 3.0f, 4.0f});
    auto* beta = builder.MakeInitializer<float>({1, 1, 4}, {0.1f, 0.2f, 0.3f, 0.4f});
    auto* add_out = builder.MakeIntermediate();
    auto* ln_out = builder.MakeOutput();

    builder.AddNode("Add", {input_a, input_b}, {add_out});
    builder.AddNode("LayerNormalization", {add_out, gamma, beta}, {ln_out})
        .AddAttribute("axis", static_cast<int64_t>(-1));
  };

  auto post_graph_checker = [](Graph& graph) {
    // SkipLayerNormalization should NOT have been created because gamma/beta are 3D.
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["Add"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["LayerNormalization"] == 1);
    TEST_RETURN_IF_NOT(CountOpsInGraph(graph)["com.microsoft.SkipLayerNormalization"] == 0);
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<SkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionTest) {
  TestGQAFusion(MODEL_FOLDER "fusion/gqa_fusion_quantized_simple.onnx", 1, 0, logger_.get());
  TestGQAFusion(MODEL_FOLDER "fusion/gqa_fusion_different_head_sizes.onnx", 0, 1, logger_.get());
  TestGQAFusion(MODEL_FOLDER "fusion/gqa_fusion_quantized_different_head_sizes.onnx", 1, 0, logger_.get());
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsOnnxRotaryEmbeddingTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kOnnx, true);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckOnnxRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsOnnxRotaryEmbeddingInterleavedTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kOnnx, true, 1, 1);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckOnnxRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsOnnxRotaryEmbeddingPartialRotaryTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kOnnx, true, 0, 0, 16);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckOnnxRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionOnnxRotaryEmbeddingInterleavedMismatchTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kOnnx, true, 0, 1);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckOnnxRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionOnnxRotaryEmbeddingNoPositionIdsTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kOnnx, false);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckOnnxRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionMsRotaryEmbeddingForwardsPositionIdsTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kMS, true, 1, 1);
  };
  auto check_fused_graph = [](Graph& graph) {
    return CheckMsRotaryEmbeddingGQAFused(graph, 1);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        check_fused_graph));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsMismatchedProjectionSizesTest) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    BuildRotaryEmbeddingGQAFusionGraph(builder, RotaryEmbeddingDomain::kMS, true, 0, 0, 0, 3);
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 23, *logger_,
                                        std::make_unique<GroupQueryAttentionFusion>(),
                                        TransformerLevel::Level2, 3, nullptr,
                                        CheckMsRotaryEmbeddingGQANotFused));
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsMismatchedScaleShape) {
  TestQuantizedGQAFusionRejectsInitializerShape("scales_q", logger_.get());
}

TEST_F(GraphTransformationTests, GroupQueryAttentionFusionSkipsMismatchedZeroPointShape) {
  TestQuantizedGQAFusionRejectsInitializerShape("zero_points_q", logger_.get());
}

TEST_F(GraphTransformationTests, SkipLayerNormFusionWithCastTest) {
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1_with_cast.onnx", 0, 0, 1, 3, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2_with_cast.onnx", 0, 0, 1, 3, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3_with_cast.onnx", 0, 0, 1, 2, logger_.get());

  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1_partial_with_cast.onnx", 1, 0, 1, 2, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2_partial_with_cast.onnx", 1, 0, 1, 2, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3_no_fusion_with_cast.onnx", 1, 1, 0, 0, logger_.get());

  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format1_graph_output_with_cast.onnx", 1, 0, 1, 2, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format2_graph_output_with_cast.onnx", 1, 0, 1, 2, logger_.get());
  TestSkipLayerNormFusion(MODEL_FOLDER "fusion/skip_layer_norm_format3_graph_output_with_cast.onnx", 1, 1, 0, 0, logger_.get());
}

static void TestSkipLayerNormFusionInputOutputCheck(const std::basic_string<ORTCHAR_T>& model_uri, bool with_cast, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  const InlinedHashSet<std::string_view> no_limit_empty_ep_list = {};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(
      std::make_unique<LayerNormFusion>(no_limit_empty_ep_list, TransformerLevel::Level2), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SkipLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  for (Node& node : graph.Nodes()) {
    if (node.OpType() == "SkipLayerNormalization") {
      // check inputs
      std::vector<NodeArg*>& input_defs = node.MutableInputDefs();
      EXPECT_EQ(input_defs.size(), 5u) << "SkipLayerNormalization number of inputs does not equal to 5. Got:" << node.InputDefs().size();
      EXPECT_EQ(input_defs[0]->Name(), ((with_cast) ? "input.1_Float" : "input.1"));
      EXPECT_EQ(input_defs[1]->Name(), ((with_cast) ? "6_Float" : "6"));
      EXPECT_EQ(input_defs[2]->Name(), "1");
      EXPECT_EQ(input_defs[3]->Name(), "2");
      EXPECT_EQ(input_defs[4]->Name(), ((with_cast) ? "4_Float" : "4"));

      // check outputs
      std::vector<NodeArg*>& output_defs = node.MutableOutputDefs();
#ifdef ENABLE_TRAINING_CORE
      EXPECT_EQ(node.OutputDefs().size(), 3u) << "SkipLayerNormalization number of outputs does not equal to 3. Got:" << node.OutputDefs().size();
#else
      EXPECT_EQ(node.OutputDefs().size(), 1u) << "SkipLayerNormalization number of outputs does not equal to 1. Got:" << node.OutputDefs().size();
#endif
      EXPECT_EQ(output_defs[0]->Name(), "19");
    } else if (node.OpType() == "Cast") {
      EXPECT_TRUE(with_cast) << "Unexpected node: " << node.OpType() << "," << node.Name();
    } else {
      EXPECT_EQ(node.OpType(), "MatMul") << "Unexpected node: " << node.OpType() << "," << node.Name();
    }
  }
}

TEST_F(GraphTransformationTests, SkipLayerNormFusion_Input_Output_Check) {
  TestSkipLayerNormFusionInputOutputCheck(MODEL_FOLDER "fusion/skip_layer_norm_input_output_check.onnx", false, logger_.get());
  TestSkipLayerNormFusionInputOutputCheck(MODEL_FOLDER "fusion/skip_layer_norm_input_output_with_cast_check.onnx", true, logger_.get());
}

static void TestSkipLayerNormFusionNoBeta(const std::basic_string<ORTCHAR_T>& model_uri, bool with_cast, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SkipLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["LayerNormalization"] == 0);
  ASSERT_TRUE(op_to_count["com.microsoft.SkipLayerNormalization"] == 1);
  ASSERT_TRUE(op_to_count["Cast"] == ((with_cast) ? 2 : 0));
}

TEST_F(GraphTransformationTests, SkipLayerNormFusion_NoBeta) {
  TestSkipLayerNormFusionNoBeta(MODEL_FOLDER "fusion/skip_layer_norm_no_beta.onnx", false, logger_.get());
  TestSkipLayerNormFusionNoBeta(MODEL_FOLDER "fusion/skip_layer_norm_no_beta_with_cast.onnx", true, logger_.get());
}

// ---- BiasSkipLayerNormFusion tests ----
//
// All tests start with a pre-existing 4-input com.microsoft.SkipLayerNormalization node,
// mirroring the scenario where a model was already exported with SkipLayerNormalization (e.g.,
// via the Python transformer optimizer), and a bias Add upstream still needs to be absorbed.

// Verify that Add(MatMul_out, bias_1D) → SLN(4 inputs) is fused into SLN(5 inputs).
// Pattern: Add at SLN input[0], bias as Add input[1].
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_AddAtInput0) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Add", {matmul_out, bias}, {add_out});
    // 4-input SLN: add_out at input[0], skip at input[1]
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["Add"] == 0);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        // Bias absorbed as 5th input
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 5u);

        // Verify wiring: input[0] is produced by MatMul, input[1] is the original skip input,
        // and input[4] is an initializer (the fused bias).
        const auto& input_defs = node.InputDefs();
        auto* input0 = input_defs[0];
        auto* input1 = input_defs[1];
        auto* input4 = input_defs[4];

        // input[0] should come from MatMul
        const Node* input0_producer = graph.GetProducerNode(input0->Name());
        TEST_RETURN_IF_NOT(input0_producer != nullptr);
        TEST_RETURN_IF_NOT(input0_producer->OpType() == "MatMul");

        // input[1] should be the skip connection: a graph input (no producer)
        const Node* input1_producer = graph.GetProducerNode(input1->Name());
        TEST_RETURN_IF_NOT(input1_producer == nullptr);
        bool is_graph_input1 = false;
        for (const auto* gi : graph.GetInputs()) {
          if (gi->Name() == input1->Name()) {
            is_graph_input1 = true;
            break;
          }
        }
        TEST_RETURN_IF_NOT(is_graph_input1);

        // input[4] should be an initializer (the fused bias), identified by name
        const Node* input4_producer = graph.GetProducerNode(input4->Name());
        TEST_RETURN_IF_NOT(input4_producer == nullptr);
        const ONNX_NAMESPACE::TensorProto* bias_initializer = nullptr;
        TEST_RETURN_IF_NOT(graph.GetInitializedTensor(input4->Name(), bias_initializer));
        TEST_RETURN_IF_NOT(bias_initializer != nullptr);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Same as above, but bias is Add input[0] (not input[1]).
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_BiasAsFirstAddInput) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    // bias is Add input[0], MatMul output is Add input[1]
    builder.AddNode("Add", {bias, matmul_out}, {add_out});
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["Add"] == 0);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 5u);

        // Verify wiring for this scenario as well: input[0] from MatMul, input[1] is skip input,
        // and input[4] is an initializer (the fused bias).
        const auto& input_defs = node.InputDefs();
        auto* input0 = input_defs[0];
        auto* input1 = input_defs[1];
        auto* input4 = input_defs[4];

        // input[0] should come from MatMul
        const Node* input0_producer = graph.GetProducerNode(input0->Name());
        TEST_RETURN_IF_NOT(input0_producer != nullptr);
        TEST_RETURN_IF_NOT(input0_producer->OpType() == "MatMul");

        // input[1] should be the skip connection: a graph input (no producer)
        const Node* input1_producer = graph.GetProducerNode(input1->Name());
        TEST_RETURN_IF_NOT(input1_producer == nullptr);
        bool is_graph_input1 = false;
        for (const auto* gi : graph.GetInputs()) {
          if (gi->Name() == input1->Name()) {
            is_graph_input1 = true;
            break;
          }
        }
        TEST_RETURN_IF_NOT(is_graph_input1);

        // input[4] should be an initializer (the fused bias), identified by name
        const Node* input4_producer = graph.GetProducerNode(input4->Name());
        TEST_RETURN_IF_NOT(input4_producer == nullptr);
        const ONNX_NAMESPACE::TensorProto* bias_initializer = nullptr;
        TEST_RETURN_IF_NOT(graph.GetInitializedTensor(input4->Name(), bias_initializer));
        TEST_RETURN_IF_NOT(bias_initializer != nullptr);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Add(MatMul_out, bias_1D) is connected to SLN input[1] (the "skip" input).
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_AddAtSkipInput) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* input = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Add", {matmul_out, bias}, {add_out});
    // add_out at SLN input[1] (skip), primary input at input[0]
    builder.AddNode("SkipLayerNormalization", {input, add_out, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["Add"] == 0);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 5u);

        const auto& input_defs = node.InputDefs();

        // input[0] should be the original graph input (unchanged – Add fed SLN.input[1], so
        // only SLN.input[1] is replaced with the MatMul output; input[0] keeps its original value).
        const Node* input0_producer = graph.GetProducerNode(input_defs[0]->Name());
        TEST_RETURN_IF_NOT(input0_producer == nullptr);
        bool is_graph_input0 = false;
        for (const auto* gi : graph.GetInputs()) {
          if (gi->Name() == input_defs[0]->Name()) {
            is_graph_input0 = true;
            break;
          }
        }
        TEST_RETURN_IF_NOT(is_graph_input0);

        // input[1] should come from MatMul (the bias-Add was at SLN.input[1])
        const Node* input1_producer = graph.GetProducerNode(input_defs[1]->Name());
        TEST_RETURN_IF_NOT(input1_producer != nullptr);
        TEST_RETURN_IF_NOT(input1_producer->OpType() == "MatMul");

        // input[4] should be an initializer (the fused bias)
        const Node* input4_producer = graph.GetProducerNode(input_defs[4]->Name());
        TEST_RETURN_IF_NOT(input4_producer == nullptr);
        const ONNX_NAMESPACE::TensorProto* bias_initializer = nullptr;
        TEST_RETURN_IF_NOT(graph.GetInitializedTensor(input_defs[4]->Name(), bias_initializer));
        TEST_RETURN_IF_NOT(bias_initializer != nullptr);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Cast variant: MatMul → Cast → Add(bias_1D) → SLN(4 inputs).
// Models using fp16 precision commonly insert a Cast between MatMul and the bias Add.
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_WithCast) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<onnxruntime::MLFloat16>({2, 4, 8}, MLFloat16(-1.0f), MLFloat16(1.0f));
    auto* matmul_b = builder.MakeInitializer<onnxruntime::MLFloat16>({8, 4}, MLFloat16(-1.0f), MLFloat16(1.0f));
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* cast_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Cast", {matmul_out}, {cast_out})
        .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));
    builder.AddNode("Add", {cast_out, bias}, {add_out});
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["Add"] == 0);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 5u);

        const auto& input_defs = node.InputDefs();

        // input[0] should come from Cast (MatMul → Cast → fused SLN)
        const Node* input0_producer = graph.GetProducerNode(input_defs[0]->Name());
        TEST_RETURN_IF_NOT(input0_producer != nullptr);
        TEST_RETURN_IF_NOT(input0_producer->OpType() == "Cast");

        // input[1] should be the skip connection: a graph input (no producer)
        const Node* input1_producer = graph.GetProducerNode(input_defs[1]->Name());
        TEST_RETURN_IF_NOT(input1_producer == nullptr);
        bool is_graph_input1 = false;
        for (const auto* gi : graph.GetInputs()) {
          if (gi->Name() == input_defs[1]->Name()) {
            is_graph_input1 = true;
            break;
          }
        }
        TEST_RETURN_IF_NOT(is_graph_input1);

        // input[4] should be an initializer (the fused bias)
        const Node* input4_producer = graph.GetProducerNode(input_defs[4]->Name());
        TEST_RETURN_IF_NOT(input4_producer == nullptr);
        const ONNX_NAMESPACE::TensorProto* bias_initializer = nullptr;
        TEST_RETURN_IF_NOT(graph.GetInitializedTensor(input_defs[4]->Name(), bias_initializer));
        TEST_RETURN_IF_NOT(bias_initializer != nullptr);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Cast variant negative test: bias is 1D but its length is incompatible with gamma/beta.
// This guards against fusing dimension-mismatched biases when hidden-size validation is applied
// on the Cast path.
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_WithCast_BiasHiddenSizeMismatch) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<onnxruntime::MLFloat16>({2, 4, 8}, MLFloat16(-1.0f), MLFloat16(1.0f));
    auto* matmul_b = builder.MakeInitializer<onnxruntime::MLFloat16>({8, 4}, MLFloat16(-1.0f), MLFloat16(1.0f));
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    // Intentionally use a 1D bias whose length does not match gamma/beta (size 4).
    // bias{1} broadcasts validly with cast_out{2,4,4}, but bias_hidden_size(1) != sln_hidden_size(4)
    // so the fusion is blocked.
    auto* bias = builder.MakeInitializer<float>({1}, {0.5f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* cast_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Cast", {matmul_out}, {cast_out})
        .AddAttribute("to", static_cast<int64_t>(ONNX_NAMESPACE::TensorProto_DataType_FLOAT));
    builder.AddNode("Add", {cast_out, bias}, {add_out});
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    // Fusion should not occur: Add must remain, and SkipLayerNormalization must keep 4 inputs.
    TEST_RETURN_IF_NOT(op_count["Add"] == 1);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 4u);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Fusion must NOT occur when the bias is 2D (not 1D).
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_NoFusion_2DBias) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    // 2D bias – should prevent fusion
    auto* bias_2d = builder.MakeInitializer<float>({1, 4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Add", {matmul_out, bias_2d}, {add_out});
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    // Graph should be unchanged: Add and 4-input SLN both remain.
    TEST_RETURN_IF_NOT(op_count["Add"] == 1);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 4u);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Fusion must NOT occur when the SLN node already has 5 inputs (bias already absorbed).
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_NoFusion_SLNHas5Inputs) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* input = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});
    auto* sln_out = builder.MakeOutput();

    // SLN already has 5 inputs – no further fusion should happen.
    builder.AddNode("SkipLayerNormalization", {input, skip, gamma, beta, bias}, {sln_out}, kMSDomain);
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 5u);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Fusion must NOT occur when the Add node feeds multiple consumers (the output is used both by
// SLN and by another node, so removing Add would drop the other consumer's input).
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_NoFusion_AddHasMultipleConsumers) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeOutput();
    auto* identity_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Add", {matmul_out, bias}, {add_out});
    // add_out feeds both SLN and an Identity node – Add has 2 consumers.
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
    builder.AddNode("Identity", {add_out}, {identity_out});
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    // Add must NOT be removed because it has multiple consumers.
    TEST_RETURN_IF_NOT(op_count["Add"] == 1);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    for (auto& node : graph.Nodes()) {
      if (node.OpType() == "SkipLayerNormalization") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 4u);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

// Verify that fusion preserves downstream edges when the SLN output feeds another node.
// This exercises the edge-rewiring code path: the fused SLN node must inherit all consumers
// of the original SLN node.
TEST_F(GraphTransformationTests, BiasSkipLayerNormFusion_DownstreamConsumerPreserved) {
  auto build_test_case = [](ModelTestBuilder& builder) {
    auto* matmul_a = builder.MakeInput<float>({2, 4, 8}, -1.0f, 1.0f);
    auto* matmul_b = builder.MakeInitializer<float>({8, 4}, -1.0f, 1.0f);
    auto* skip = builder.MakeInput<float>({2, 4, 4}, -1.0f, 1.0f);
    auto* gamma = builder.MakeInitializer<float>({4}, {1.0f, 1.0f, 1.0f, 1.0f});
    auto* beta = builder.MakeInitializer<float>({4}, {0.0f, 0.0f, 0.0f, 0.0f});
    auto* bias = builder.MakeInitializer<float>({4}, {0.1f, 0.2f, 0.3f, 0.4f});

    auto* matmul_out = builder.MakeIntermediate();
    auto* add_out = builder.MakeIntermediate();
    auto* sln_out = builder.MakeIntermediate();  // intermediate: SLN output feeds Identity
    auto* identity_out = builder.MakeOutput();

    builder.AddNode("MatMul", {matmul_a, matmul_b}, {matmul_out});
    builder.AddNode("Add", {matmul_out, bias}, {add_out});
    builder.AddNode("SkipLayerNormalization", {add_out, skip, gamma, beta}, {sln_out}, kMSDomain);
    // Downstream consumer of the SLN output: must be preserved after fusion.
    builder.AddNode("Identity", {sln_out}, {identity_out});
  };

  auto post_graph_checker = [](Graph& graph) {
    auto op_count = CountOpsInGraph(graph);
    TEST_RETURN_IF_NOT(op_count["Add"] == 0);
    TEST_RETURN_IF_NOT(op_count["com.microsoft.SkipLayerNormalization"] == 1);
    TEST_RETURN_IF_NOT(op_count["Identity"] == 1);

    // The Identity node must still be wired to the fused SLN output.
    for (const auto& node : graph.Nodes()) {
      if (node.OpType() == "Identity") {
        TEST_RETURN_IF_NOT(node.InputDefs().size() == 1u);
        const Node* identity_input_producer = graph.GetProducerNode(node.InputDefs()[0]->Name());
        TEST_RETURN_IF_NOT(identity_input_producer != nullptr);
        TEST_RETURN_IF_NOT(identity_input_producer->OpType() == "SkipLayerNormalization");
        // The fused SLN must have 5 inputs.
        TEST_RETURN_IF_NOT(identity_input_producer->InputDefs().size() == 5u);
      }
    }
    return Status::OK();
  };

  ASSERT_STATUS_OK(TestGraphTransformer(build_test_case, 17, *logger_,
                                        std::make_unique<BiasSkipLayerNormFusion>(),
                                        TransformerLevel::Level2, 1, nullptr, post_graph_checker));
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat1) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format1.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Gather"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["ReduceSum"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.Attention"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.SkipLayerNormalization"] == 0);
  ASSERT_TRUE(op_to_count["com.microsoft.EmbedLayerNormalization"] == 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat2) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format2.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Shape"] == 0);
  ASSERT_TRUE(op_to_count["Expand"] == 0);
  ASSERT_TRUE(op_to_count["Gather"] == 0);
  ASSERT_TRUE(op_to_count["Unsqueeze"] == 0);
  ASSERT_TRUE(op_to_count["ConstantOfShape"] == 0);
  ASSERT_TRUE(op_to_count["NonZero"] == 0);
  ASSERT_TRUE(op_to_count["Transpose"] == 0);
  ASSERT_TRUE(op_to_count["Squeeze"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["ReduceSum"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.Attention"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.SkipLayerNormalization"] == 0);
  ASSERT_TRUE(op_to_count["com.microsoft.EmbedLayerNormalization"] == 1);
}

// These tests verify that EmbedLayerNorm fusion fires at the CURRENT max ONNX opset.
// When the ONNX opset advances, nodes will report a new SinceVersion(). If the
// optimizer's version lists are not updated, the fusion will fail to match.
//
// To fix: update the EdgeEndToMatch version lists in
// onnxruntime/core/optimizer/embed_layer_norm_fusion.cc

// Loads a model and upgrades it to the current ONNX opset. Currently handles converting
// Squeeze/Unsqueeze/Reduce* ops from attribute-based axes to input-based (opset 13+/18+).
// Extend this function if additional op conversions are needed for new test models.
static void LoadModelAtCurrentOpset(const ORTCHAR_T* base_model_uri,
                                    std::shared_ptr<Model>& p_model,
                                    const logging::Logger& logger) {
  int current_opset = GetCurrentOnnxOpset();
  ONNX_NAMESPACE::ModelProto model_proto;
  {
    std::shared_ptr<Model> base_model;
    ASSERT_STATUS_OK(Model::Load(base_model_uri, base_model, nullptr, logger));
    model_proto = base_model->ToProto();
  }
  for (auto& opset_import : *model_proto.mutable_opset_import()) {
    if (opset_import.domain().empty() || opset_import.domain() == "ai.onnx") {
      opset_import.set_version(current_opset);
      break;
    }
  }

  // Convert attribute-based Squeeze/Unsqueeze to input-based for opset 13+ compatibility.
  // Also convert ReduceSum/ReduceMean axes attribute to input for opset 18+ compatibility.
  auto* graph_proto = model_proto.mutable_graph();
  int next_init_id = 0;
  for (auto& node : *graph_proto->mutable_node()) {
    bool is_squeeze_unsqueeze = (node.op_type() == "Squeeze" || node.op_type() == "Unsqueeze");
    bool is_reduce = (node.op_type() == "ReduceSum" || node.op_type() == "ReduceMean" ||
                      node.op_type() == "ReduceMax" || node.op_type() == "ReduceMin" ||
                      node.op_type() == "ReduceProd");
    if (!is_squeeze_unsqueeze && !is_reduce) {
      continue;
    }
    int axes_attr_idx = -1;
    for (int i = 0; i < node.attribute_size(); ++i) {
      if (node.attribute(i).name() == "axes") {
        axes_attr_idx = i;
        break;
      }
    }
    if (axes_attr_idx < 0) {
      continue;
    }
    const auto& axes_attr = node.attribute(axes_attr_idx);
    std::string init_name = "__axes_init_" + std::to_string(next_init_id++);
    auto* init = graph_proto->add_initializer();
    init->set_name(init_name);
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_INT64);
    init->add_dims(axes_attr.ints_size());
    for (int i = 0; i < axes_attr.ints_size(); ++i) {
      init->add_int64_data(axes_attr.ints(i));
    }
    // For Squeeze/Unsqueeze, axes is input[1]. For Reduce ops, axes is also input[1].
    node.add_input(init_name);
    node.mutable_attribute()->SwapElements(axes_attr_idx, node.attribute_size() - 1);
    node.mutable_attribute()->RemoveLast();
  }

  // EmbedLayerNorm fixtures are rewritten to the current ONNX opset, which may still be
  // under development (e.g. opset 27 in ONNX 1.22). Allow the unreleased opset so the model
  // loads on strict (ALLOW_RELEASED_ONNX_OPSET_ONLY default) CI legs as well.
  // Remove once opset 27 is released. Tracked by #28966.
  ASSERT_STATUS_OK(Model::Load(std::move(model_proto), p_model, nullptr, logger,
                               ModelOptions{kAllowReleasedOpsetsOnly, /*strict_shape_type_inference*/ false}));
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat1CurrentOpset) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format1.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_NO_FATAL_FAILURE(LoadModelAtCurrentOpset(model_uri, p_model, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1)
      << "EmbedLayerNorm fusion (format 1) failed at opset " << GetCurrentOnnxOpset() << ". "
      << "Update version lists in onnxruntime/core/optimizer/embed_layer_norm_fusion.cc "
      << "(MatchInputToConcatSubgraph, MatchPositionEmbeddingSubgraph).";
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Add"], 0);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat2CurrentOpset) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format2.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_NO_FATAL_FAILURE(LoadModelAtCurrentOpset(model_uri, p_model, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1)
      << "EmbedLayerNorm fusion (format 2: NonZero+Transpose+Squeeze path) failed at opset "
      << GetCurrentOnnxOpset() << ". "
      << "Update version lists in onnxruntime/core/optimizer/embed_layer_norm_fusion.cc "
      << "(parent_path_1, parent_path_2).";
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Expand"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat3CurrentOpset) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format3.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_NO_FATAL_FAILURE(LoadModelAtCurrentOpset(model_uri, p_model, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1)
      << "EmbedLayerNorm fusion (format 3: Range-based path) failed at opset "
      << GetCurrentOnnxOpset() << ". "
      << "Update version lists in onnxruntime/core/optimizer/embed_layer_norm_fusion.cc "
      << "(parent_path_3, parent_path_4).";
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
}

static void EmbedLayerNormFusionFormat3(const std::basic_string<ORTCHAR_T>& file_path, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Expand"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["LayerNormalization"], 0);
  EXPECT_EQ(op_to_count["com.microsoft.SkipLayerNormalization"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
  EXPECT_EQ(op_to_count["MatMul"], 1);
  EXPECT_EQ(op_to_count["Add"], 2);
  EXPECT_EQ(op_to_count["Cast"], 3);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat3) {
  EmbedLayerNormFusionFormat3(MODEL_FOLDER "fusion/embed_layer_norm_format3.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat3_OpSet13) {
  EmbedLayerNormFusionFormat3(MODEL_FOLDER "fusion/embed_layer_norm_format3_opset13.onnx", logger_.get());
}

static void EmbedLayerNormFusionFormat3NoCast(const std::basic_string<ORTCHAR_T>& file_path, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Expand"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["LayerNormalization"], 0);
  EXPECT_EQ(op_to_count["com.microsoft.SkipLayerNormalization"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
  EXPECT_EQ(op_to_count["MatMul"], 1);
  EXPECT_EQ(op_to_count["Add"], 2);
  EXPECT_EQ(op_to_count["Cast"], 3);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat3NoCast) {
  EmbedLayerNormFusionFormat3NoCast(MODEL_FOLDER "fusion/embed_layer_norm_format3_no_cast.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat3NoCast_OpSet13) {
  EmbedLayerNormFusionFormat3NoCast(MODEL_FOLDER "fusion/embed_layer_norm_format3_no_cast_opset13.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat4) {
  constexpr const ORTCHAR_T* model_uri = MODEL_FOLDER "fusion/embed_layer_norm_format4.onnx";
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger_));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger_));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  ASSERT_TRUE(op_to_count["Shape"] == 0);
  ASSERT_TRUE(op_to_count["Expand"] == 0);
  ASSERT_TRUE(op_to_count["Gather"] == 0);
  ASSERT_TRUE(op_to_count["Concat"] == 0);
  ASSERT_TRUE(op_to_count["Unsqueeze"] == 0);
  ASSERT_TRUE(op_to_count["ConstantOfShape"] == 0);
  ASSERT_TRUE(op_to_count["NonZero"] == 0);
  ASSERT_TRUE(op_to_count["Transpose"] == 0);
  ASSERT_TRUE(op_to_count["Squeeze"] == 0);
  ASSERT_TRUE(op_to_count["Add"] == 0);
  ASSERT_TRUE(op_to_count["ReduceSum"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.Attention"] == 1);
  ASSERT_TRUE(op_to_count["com.microsoft.SkipLayerNormalization"] == 0);
  ASSERT_TRUE(op_to_count["com.microsoft.EmbedLayerNormalization"] == 1);
}

static void EmbedLayerNormFusionFormat5(const std::basic_string<ORTCHAR_T>& file_path, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["LayerNormalization"], 0);
  EXPECT_EQ(op_to_count["com.microsoft.SkipLayerNormalization"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
  EXPECT_EQ(op_to_count["MatMul"], 1);
  EXPECT_EQ(op_to_count["Add"], 2);
  EXPECT_EQ(op_to_count["Cast"], 3);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);

  // Validate the position embedding input.
  double expected_value[] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 8.0, 7.0, 6.0};
  for (const Node& node : graph.Nodes()) {
    if (node.OpType() == "EmbedLayerNormalization") {
      const ONNX_NAMESPACE::TensorProto* tensor_proto = graph_utils::GetConstantInitializer(graph, node.InputDefs()[3]->Name());
      ASSERT_TRUE(tensor_proto != nullptr);
      EXPECT_EQ(tensor_proto->data_type(), ONNX_NAMESPACE::TensorProto_DataType_FLOAT);

      Initializer initializer{graph, *tensor_proto, graph.ModelPath()};
      EXPECT_EQ(initializer.size(), std::size(expected_value));

      const float* data = initializer.data<float>();
      for (size_t i = 0; i < std::size(expected_value); i++) {
        EXPECT_EQ(data[i], static_cast<float>(expected_value[i]));
      }
    }
  }
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat5) {
  EmbedLayerNormFusionFormat5(MODEL_FOLDER "fusion/embed_layer_norm_format5.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat5_OpSet13) {
  EmbedLayerNormFusionFormat5(MODEL_FOLDER "fusion/embed_layer_norm_format5_opset13.onnx", logger_.get());
}

static void EmbedLayerNormFusionFormat6(const std::basic_string<ORTCHAR_T>& file_path, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Expand"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["Reshape"], 0);
  EXPECT_EQ(op_to_count["Equal"], 0);
  EXPECT_EQ(op_to_count["Where"], 0);
  EXPECT_EQ(op_to_count["LayerNormalization"], 0);
  EXPECT_EQ(op_to_count["com.microsoft.SkipLayerNormalization"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
  EXPECT_EQ(op_to_count["MatMul"], 1);
  EXPECT_EQ(op_to_count["Add"], 2);
  EXPECT_EQ(op_to_count["Cast"], 3);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat6) {
  EmbedLayerNormFusionFormat6(MODEL_FOLDER "fusion/embed_layer_norm_format6.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat6_OpSet13) {
  EmbedLayerNormFusionFormat6(MODEL_FOLDER "fusion/embed_layer_norm_format6_opset13.onnx", logger_.get());
}

static void TestEmbedLayerNormFusionDistilBert(const std::basic_string<ORTCHAR_T>& model_uri,
                                               std::map<std::string, int>& op_to_count,
                                               logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_STATUS_OK(Model::Load(model_uri, p_model, nullptr, *logger));
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  op_to_count = CountOpsInGraph(graph);
}

// DistilBert
TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat7) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format7.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat7_OpSet13) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format7_opset13.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat8) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format8.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat8_OpSet13) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format8_opset13.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat9) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format9.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 1);
  EXPECT_EQ(op_to_count["Gather"], 2);
  EXPECT_EQ(op_to_count["Unsqueeze"], 2);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionFormat9_OpSet13) {
  std::map<std::string, int> op_to_count;
  TestEmbedLayerNormFusionDistilBert(MODEL_FOLDER "fusion/embed_layer_norm_format9_opset13.onnx", op_to_count, logger_.get());
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 1);
  EXPECT_EQ(op_to_count["Cast"], 2);
  EXPECT_EQ(op_to_count["Shape"], 1);
  EXPECT_EQ(op_to_count["Gather"], 2);
  EXPECT_EQ(op_to_count["Unsqueeze"], 2);
  EXPECT_EQ(op_to_count["ReduceSum"], 1);
}

static void EmbedLayerNormFusionFormatMultiple(const std::basic_string<ORTCHAR_T>& file_path, logging::Logger* logger) {
  std::shared_ptr<Model> p_model;
  ASSERT_TRUE(Model::Load(file_path, p_model, nullptr, *logger).IsOK());
  Graph& graph = p_model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<EmbedLayerNormFusion>(), TransformerLevel::Level2));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level2, *logger));

  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["Shape"], 0);
  EXPECT_EQ(op_to_count["Expand"], 0);
  EXPECT_EQ(op_to_count["Gather"], 0);
  EXPECT_EQ(op_to_count["Unsqueeze"], 0);
  EXPECT_EQ(op_to_count["LayerNormalization"], 0);
  EXPECT_EQ(op_to_count["com.microsoft.SkipLayerNormalization"], 0);
  EXPECT_EQ(op_to_count["ReduceSum"], 2);
  EXPECT_EQ(op_to_count["MatMul"], 2);
  EXPECT_EQ(op_to_count["Add"], 5);
  EXPECT_EQ(op_to_count["Cast"], 6);
  EXPECT_EQ(op_to_count["com.microsoft.Attention"], 2);
  EXPECT_EQ(op_to_count["com.microsoft.EmbedLayerNormalization"], 2);
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionMultiple) {
  EmbedLayerNormFusionFormatMultiple(MODEL_FOLDER "fusion/embed_layer_norm_multiple.onnx", logger_.get());
}

TEST_F(GraphTransformationTests, EmbedLayerNormFusionMultiple_OpSet13) {
  EmbedLayerNormFusionFormatMultiple(MODEL_FOLDER "fusion/embed_layer_norm_multiple_opset13.onnx", logger_.get());
}

// Test: LayerNormFusion gracefully handles a zero-element epsilon initializer.
// A zero-element constant (shape [0], 0 bytes) is valid ONNX.
// The optimizer must check size() before accessing data<float>().
TEST_F(GraphTransformationTests, LayerNormFusion_ZeroElementEpsilon) {
  // Build a minimal LayerNorm pattern with a zero-element epsilon.
  // Use dynamic input shapes so shape inference doesn't reject the model.
  ONNX_NAMESPACE::ModelProto model_proto;
  model_proto.set_ir_version(8);
  auto* opset = model_proto.add_opset_import();
  opset->set_version(17);  // Use opset 17 so ReduceMean uses the 'axes' attribute (moved to input in opset 18)

  auto* graph_proto = model_proto.mutable_graph();
  graph_proto->set_name("LayerNormFusion_ZeroElem");

  // Input with dynamic shape
  {
    auto* input = graph_proto->add_input();
    input->set_name("X");
    auto* type = input->mutable_type()->mutable_tensor_type();
    type->set_elem_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    // No shape = dynamic
  }

  // Zero-element epsilon initializer
  {
    auto* init = graph_proto->add_initializer();
    init->set_name("epsilon");
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_dims(0);
    // Note: epsilon is intentionally NOT added as a graph input so it remains a constant initializer.
  }

  // Scalar initializers
  auto add_scalar_init = [&](const char* name, float value) {
    auto* init = graph_proto->add_initializer();
    init->set_name(name);
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_float_data(value);
    // scalar = no dims
  };
  add_scalar_init("pow_exp", 2.0f);

  // 1D scale and bias
  auto add_1d_init = [&](const char* name, int size, float value) {
    auto* init = graph_proto->add_initializer();
    init->set_name(name);
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_dims(size);
    for (int i = 0; i < size; i++) init->add_float_data(value);
  };
  add_1d_init("scale", 4, 1.0f);
  add_1d_init("bias", 4, 0.0f);

  // Output
  {
    auto* output = graph_proto->add_output();
    output->set_name("output");
    auto* type = output->mutable_type()->mutable_tensor_type();
    type->set_elem_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
  }

  // ReduceMean1 -> Sub -> Pow -> ReduceMean2 -> Add(epsilon) -> Sqrt -> Div -> Mul -> Add
  auto add_node = [&](const char* op, const std::vector<std::string>& inputs,
                      const std::vector<std::string>& outputs) -> ONNX_NAMESPACE::NodeProto* {
    auto* node = graph_proto->add_node();
    node->set_op_type(op);
    for (auto& i : inputs) node->add_input(i);
    for (auto& o : outputs) node->add_output(o);
    return node;
  };

  auto* rm1 = add_node("ReduceMean", {"X"}, {"rm1_out"});
  auto* axes1 = rm1->add_attribute();
  axes1->set_name("axes");
  axes1->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INTS);
  axes1->add_ints(-1);
  auto* kd1 = rm1->add_attribute();
  kd1->set_name("keepdims");
  kd1->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INT);
  kd1->set_i(1);

  add_node("Sub", {"X", "rm1_out"}, {"sub_out"});
  add_node("Pow", {"sub_out", "pow_exp"}, {"pow_out"});

  auto* rm2 = add_node("ReduceMean", {"pow_out"}, {"rm2_out"});
  auto* axes2 = rm2->add_attribute();
  axes2->set_name("axes");
  axes2->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INTS);
  axes2->add_ints(-1);
  auto* kd2 = rm2->add_attribute();
  kd2->set_name("keepdims");
  kd2->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INT);
  kd2->set_i(1);

  add_node("Add", {"rm2_out", "epsilon"}, {"add_eps_out"});
  add_node("Sqrt", {"add_eps_out"}, {"sqrt_out"});
  add_node("Div", {"sub_out", "sqrt_out"}, {"div_out"});
  add_node("Mul", {"div_out", "scale"}, {"mul_out"});
  add_node("Add", {"mul_out", "bias"}, {"output"});

  std::shared_ptr<Model> model;
  ASSERT_STATUS_OK(Model::Load(model_proto, model, nullptr, *logger_));
  Graph& graph = model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<LayerNormFusion>(), TransformerLevel::Level1));
  // Must handle zero-element epsilon gracefully.
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));

  // Verify the fusion fired and produced a LayerNormalization with the
  // default epsilon (1e-5f), per the zero-element fallback in
  // layer_norm_fusion.cc.
  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["LayerNormalization"], 1);
  EXPECT_EQ(op_to_count["ReduceMean"], 0);
  EXPECT_EQ(op_to_count["Sub"], 0);
  EXPECT_EQ(op_to_count["Pow"], 0);
  EXPECT_EQ(op_to_count["Sqrt"], 0);
  EXPECT_EQ(op_to_count["Div"], 0);
  EXPECT_EQ(op_to_count["Mul"], 0);

  for (const auto& node : graph.Nodes()) {
    if (node.OpType() == "LayerNormalization") {
      const auto& attrs = node.GetAttributes();
      auto it = attrs.find("epsilon");
      ASSERT_NE(it, attrs.end());
      EXPECT_FLOAT_EQ(it->second.f(), 1e-5f);
    }
  }
}

// Test: SimplifiedLayerNormFusion gracefully handles a zero-element epsilon initializer.
TEST_F(GraphTransformationTests, SimplifiedLayerNormFusion_ZeroElementEpsilon) {
  ONNX_NAMESPACE::ModelProto model_proto;
  model_proto.set_ir_version(8);
  auto* opset = model_proto.add_opset_import();
  opset->set_version(17);

  auto* graph_proto = model_proto.mutable_graph();
  graph_proto->set_name("SimplifiedLayerNormFusion_ZeroElem");

  // Input with dynamic shape
  {
    auto* input = graph_proto->add_input();
    input->set_name("X");
    auto* type = input->mutable_type()->mutable_tensor_type();
    type->set_elem_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
  }

  // Zero-element epsilon
  {
    auto* init = graph_proto->add_initializer();
    init->set_name("epsilon");
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_dims(0);
    // Note: epsilon is intentionally NOT added as a graph input so it remains a constant initializer.
  }

  // Scalar pow exponent
  {
    auto* init = graph_proto->add_initializer();
    init->set_name("pow_exp");
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_float_data(2.0f);
  }

  // 1D scale
  {
    auto* init = graph_proto->add_initializer();
    init->set_name("scale");
    init->set_data_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
    init->add_dims(4);
    for (int i = 0; i < 4; i++) init->add_float_data(1.0f);
  }

  // Output
  {
    auto* output = graph_proto->add_output();
    output->set_name("output");
    auto* type = output->mutable_type()->mutable_tensor_type();
    type->set_elem_type(ONNX_NAMESPACE::TensorProto_DataType_FLOAT);
  }

  // Pow -> ReduceMean -> Add(epsilon) -> Sqrt -> Div -> Mul
  auto add_node = [&](const char* op, const std::vector<std::string>& inputs,
                      const std::vector<std::string>& outputs) -> ONNX_NAMESPACE::NodeProto* {
    auto* node = graph_proto->add_node();
    node->set_op_type(op);
    for (auto& i : inputs) node->add_input(i);
    for (auto& o : outputs) node->add_output(o);
    return node;
  };

  add_node("Pow", {"X", "pow_exp"}, {"pow_out"});

  auto* rm = add_node("ReduceMean", {"pow_out"}, {"rm_out"});
  auto* axes = rm->add_attribute();
  axes->set_name("axes");
  axes->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INTS);
  axes->add_ints(-1);
  auto* kd = rm->add_attribute();
  kd->set_name("keepdims");
  kd->set_type(ONNX_NAMESPACE::AttributeProto_AttributeType_INT);
  kd->set_i(1);

  add_node("Add", {"rm_out", "epsilon"}, {"add_eps_out"});
  add_node("Sqrt", {"add_eps_out"}, {"sqrt_out"});
  add_node("Div", {"X", "sqrt_out"}, {"div_out"});
  add_node("Mul", {"div_out", "scale"}, {"output"});

  std::shared_ptr<Model> model;
  ASSERT_STATUS_OK(Model::Load(model_proto, model, nullptr, *logger_));
  Graph& graph = model->MainGraph();

  onnxruntime::GraphTransformerManager graph_transformation_mgr{5};
  ASSERT_STATUS_OK(graph_transformation_mgr.Register(std::make_unique<SimplifiedLayerNormFusion>(), TransformerLevel::Level1));
  ASSERT_STATUS_OK(graph_transformation_mgr.ApplyTransformers(graph, TransformerLevel::Level1, *logger_));

  // Verify the fusion fired and produced a SimplifiedLayerNormalization with
  // the default epsilon (1e-5f), per the zero-element fallback in
  // layer_norm_fusion.cc.
  std::map<std::string, int> op_to_count = CountOpsInGraph(graph);
  EXPECT_EQ(op_to_count["SimplifiedLayerNormalization"], 1);
  EXPECT_EQ(op_to_count["Pow"], 0);
  EXPECT_EQ(op_to_count["ReduceMean"], 0);
  EXPECT_EQ(op_to_count["Sqrt"], 0);
  EXPECT_EQ(op_to_count["Div"], 0);
  EXPECT_EQ(op_to_count["Mul"], 0);

  for (const auto& node : graph.Nodes()) {
    if (node.OpType() == "SimplifiedLayerNormalization") {
      const auto& attrs = node.GetAttributes();
      auto it = attrs.find("epsilon");
      ASSERT_NE(it, attrs.end());
      EXPECT_FLOAT_EQ(it->second.f(), 1e-5f);
    }
  }
}

#endif

}  // namespace test
}  // namespace onnxruntime
