/*++

Copyright (c) Microsoft Corporation. All rights reserved.

Licensed under the MIT License.

Module Name:

    qnbitgemm.cpp

Abstract:

    This module implements the float/quantized n-bit integer matrix
    multiplication hardware agnostic entrypoint, MlasQNBitGemmBatch,
    as well as some SQNBitGemm-related query functions.
--*/

#include "qnbitgemm.h"
#include "sqnbitgemm_q8_block.h"

#include <cassert>
#include <vector>

// N-strip width the CompInt8 compute path tiles by, and the M-tile height
// MlasQNBitGemmBatch's StrideM is derived from.
constexpr size_t kQNBitGemmComputeStrideM = 128;
constexpr size_t kQNBitGemmComputeStrideN = 128;

namespace
{

enum QNBitGemmVariant {
    SQNBitGemmVariantInvalid = -1,

    // Valid variants

    SQ4BitGemmVariant_CompFp32 = 0,
    SQ4BitGemmVariant_CompInt8,
    HQ4BitGemmVariant_CompFp16,
    SQ8BitGemmVariant_CompInt8,
    HQ8BitGemmVariant_CompFp16,
    SQ2BitGemmVariant_CompInt8,

    // End of valid variants

    // Keep this element last and ensure that its value is the number of valid QNBitGemmVariant values.
    // Its value is used as an array size.
    SQNBitGemmVariantCount,
};

QNBitGemmVariant
GetQNBitGemmVariant(
    size_t BlkBitWidth,
    size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType
)
{
    // BlkLen support varies by BlkBitWidth:
    //   W4 / W8 : {16, 32, 64, 128, 256}
    //   W2      : {32, 64, 128}  (the native non-LUT kernel does not implement 16 or 256;
    //              the pack-size helper returns 0 for those, and we must report
    //              this truthfully via MlasIsQNBitGemmAvailable for direct MLAS
    //              callers who rely on availability as the support contract.)
    if (BlkLen == 16 || BlkLen == 32 || BlkLen == 64 || BlkLen == 128 || BlkLen == 256) {
        if (BlkBitWidth == 4) {
            if (ComputeType == SQNBIT_CompFp32) {
                return SQ4BitGemmVariant_CompFp32;
            } else if (ComputeType == HQNBIT_CompFp16) {
                return HQ4BitGemmVariant_CompFp16;
            } else if (ComputeType == SQNBIT_CompInt8) {
                return SQ4BitGemmVariant_CompInt8;
            }
        } else if (BlkBitWidth == 8) {
            if (ComputeType == SQNBIT_CompInt8) {
                return SQ8BitGemmVariant_CompInt8;
            } else if (ComputeType == HQNBIT_CompFp16) {
                return HQ8BitGemmVariant_CompFp16;
            }
        }
    }

    if (BlkBitWidth == 2 && (BlkLen == 32 || BlkLen == 64 || BlkLen == 128)) {
        if (ComputeType == SQNBIT_CompInt8) {
            return SQ2BitGemmVariant_CompInt8;
        }
    }

    return SQNBitGemmVariantInvalid;
}

bool
QNBitGemmOverrideIsSupported(
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    bool HasZeroPoint,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    const auto IsSupported = GetMlasPlatform().MlasQNBitGemmIsSupportedOverride;
    return IsSupported != nullptr &&
           IsSupported(K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig);
}

}  // namespace

bool MLASCALL
MlasIsQNBitGemmAvailable(
    size_t BlkBitWidth,
    size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType
)
{
    // HQNBIT_CompInt8 uses the same MLAS kernels as SQNBIT_CompInt8.
    // The operator handles fp16<->fp32 conversion and delegates to the SQ path.
    if (ComputeType == HQNBIT_CompInt8) {
        ComputeType = SQNBIT_CompInt8;
    }

    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr) {
        return false;
    }

    const auto Variant = GetQNBitGemmVariant(BlkBitWidth, BlkLen, ComputeType);

    switch (Variant) {
        case SQ4BitGemmVariant_CompFp32: {
            return Dispatch->SQ4BitGemmM1Kernel_CompFp32 != nullptr &&
                   Dispatch->SQ4BitBlkDequantBForSgemm_CompFp32 != nullptr;
        }
        case HQ4BitGemmVariant_CompFp16: {
            return Dispatch->HQ4BitGemmPackQuantBData != nullptr &&
                   Dispatch->HQ4BitGemmKernel_CompFp16 != nullptr &&
                   Dispatch->HQ4BitBlkDequantBForHgemm_CompFp16 != nullptr;
        }
        case SQ4BitGemmVariant_CompInt8: {
            return (Dispatch->SQ4BitGemmKernel_CompInt8 != nullptr && Dispatch->QuantizeARow_CompInt8 != nullptr) ||
                   (Dispatch->SQ4BitGemmKernel_BlkSum_CompInt8 != nullptr &&
                    Dispatch->QuantizeARowComputeBlkSum_CompInt8 != nullptr);
        }
        case SQ8BitGemmVariant_CompInt8: {
            return Dispatch->SQ8BitGemmPackQuantBDataAndBlkSum != nullptr &&
                   Dispatch->SQ8BitGemmKernel_BlkSum_CompInt8 != nullptr &&
                   Dispatch->QuantizeARowComputeBlkSum_CompInt8 != nullptr;
        }
        case HQ8BitGemmVariant_CompFp16: {
            return Dispatch->HQ8BitGemmPackQuantBData != nullptr &&
                   Dispatch->HQ8BitBlkDequantBForHgemm_CompFp16 != nullptr &&
                   Dispatch->HQ4BitGemmKernel_CompFp16 != nullptr;
        }
        case SQ2BitGemmVariant_CompInt8: {
            return Dispatch->Q2BitGemmPackQuantBDataSize != nullptr &&
                   Dispatch->SQ2BitGemmPackQuantBDataAndBlkSum != nullptr &&
                   Dispatch->SQ2BitGemmKernel_BlkSum_CompInt8 != nullptr &&
                   Dispatch->QuantizeARowComputeBlkSum_CompInt8 != nullptr;
        }
        default: {
            return false;
        }
    }
}

bool MLASCALL
MlasQNBitGemmFp16DirectQuantASupported()
{
    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    return Dispatch != nullptr && Dispatch->QuantizeARowComputeBlkSum_CompInt8_Fp16 != nullptr;
}

bool MLASCALL
MlasQNBitGemmFp16DirectCOutputSupported(size_t BlkBitWidth, MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType)
{
    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr) {
        return false;
    }

    if (ComputeType == SQNBIT_CompInt8) {
        // Wired for the 2, 4 and 8 bit CompInt8 compute ops on x64, where the fp16 A
        // quantizer is also present.
        const bool supported_bit_width = BlkBitWidth == 2 || BlkBitWidth == 4 || BlkBitWidth == 8;
        return supported_bit_width && Dispatch->QuantizeARowComputeBlkSum_CompInt8_Fp16 != nullptr;
    }

    if (ComputeType == SQNBIT_CompFp32) {
        // The strip conversion in SQ4BitGemm_CompFp32 is portable, so it only needs the
        // CompFp32 kernels themselves.
        return BlkBitWidth == 4 &&
               Dispatch->SQ4BitGemmM1Kernel_CompFp32 != nullptr &&
               Dispatch->SQ4BitBlkDequantBForSgemm_CompFp32 != nullptr;
    }

    return false;
}

namespace
{

size_t
QNBitGemmPerGemmWorkspaceSize(
    size_t M,
    size_t N,
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    bool HasZeroPoint,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr || Dispatch->QNBitGemmPerGemmWorkspaceSize == nullptr) {
        return 0;
    }

    if (BlkBitWidth == 4 || BlkBitWidth == 8 || BlkBitWidth == 2) {
        return Dispatch->QNBitGemmPerGemmWorkspaceSize(M, N, K, BlkLen, HasZeroPoint, ComputeType, BlkBitWidth, BackendKernelSelectorConfig);
    }

    return 0;
}

size_t
QNBitGemmPerGemmWorkspaceAlignment(
    size_t BlkBitWidth,
    size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType
)
{
    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr || Dispatch->QNBitGemmPerGemmWorkspaceAlignment == nullptr) {
        return 1;
    }

    if (BlkBitWidth == 4 || BlkBitWidth == 8 || BlkBitWidth == 2) {
        return Dispatch->QNBitGemmPerGemmWorkspaceAlignment(BlkLen, ComputeType);
    }

    return 1;
}

size_t
QNBitGemmPerGemmWorkspaceStride(
    size_t M,
    size_t N,
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    bool HasZeroPoint,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    const auto Size = QNBitGemmPerGemmWorkspaceSize(M, N, K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig);
    const auto Alignment = QNBitGemmPerGemmWorkspaceAlignment(BlkBitWidth, BlkLen, ComputeType);
    return MlasDivRoundup(Size, Alignment) * Alignment;
}

}  // namespace

size_t MLASCALL
MlasQNBitGemmBatchWorkspaceSize(
    size_t M,
    size_t N,
    size_t K,
    size_t BatchN,
    size_t BlkBitWidth,
    size_t BlkLen,
    bool HasZeroPoint,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    if (QNBitGemmOverrideIsSupported(
            K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
        )) {
        const auto WorkspaceSize = GetMlasPlatform().MlasQNBitGemmBatchWorkspaceSizeOverride;
        assert(WorkspaceSize != nullptr);
        return WorkspaceSize(
            M, N, K, BatchN, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType,
            BackendKernelSelectorConfig
        );
    }

    const size_t PerGemmWorkspaceStride =
        QNBitGemmPerGemmWorkspaceStride(M, N, K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig);
    if (PerGemmWorkspaceStride == 0) {
        return 0;
    }

    const size_t Alignment = QNBitGemmPerGemmWorkspaceAlignment(BlkBitWidth, BlkLen, ComputeType);

    const size_t WorkspaceSize = BatchN * PerGemmWorkspaceStride;

    return WorkspaceSize + Alignment - 1;
}

size_t MLASCALL
MlasQNBitGemmPackQuantBDataSize(
    size_t N,
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    bool HasZeroPoint,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    if (QNBitGemmOverrideIsSupported(
            K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
        )) {
        const auto PackSize = GetMlasPlatform().MlasQNBitGemmPackQuantBDataSizeOverride;
        assert(PackSize != nullptr);
        return PackSize(
            N, K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
        );
    }

    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr) {
        return 0;
    }

    if (BlkBitWidth == 4 && Dispatch->Q4BitGemmPackQuantBDataSize != nullptr) {
        return Dispatch->Q4BitGemmPackQuantBDataSize(
            N, K, BlkLen, HasZeroPoint, ComputeType,
            BackendKernelSelectorConfig
        );
    } else if (BlkBitWidth == 8 && Dispatch->Q8BitGemmPackQuantBDataSize != nullptr) {
        return Dispatch->Q8BitGemmPackQuantBDataSize(
            N, K, BlkLen, HasZeroPoint, ComputeType,
            BackendKernelSelectorConfig
        );
    } else if (BlkBitWidth == 2 && Dispatch->Q2BitGemmPackQuantBDataSize != nullptr) {
        return Dispatch->Q2BitGemmPackQuantBDataSize(
            N, K, BlkLen, HasZeroPoint, ComputeType,
            BackendKernelSelectorConfig
        );
    }

    return 0;
}

struct PerGemmQuantAWorkspace {
    PerGemmQuantAWorkspace(void* PerGemmWorkspace, size_t M, size_t BlockCountK, size_t BlkLen)
        : PerGemmWorkspace_(PerGemmWorkspace), M_(M), BlockCountK_(BlockCountK), BlkLen_(BlkLen)
    {
        QuantData = (std::byte*)PerGemmWorkspace;
        QuantScale = (float*)(QuantData + M * BlockCountK * BlkLen);
        BlockSum = QuantScale + M * BlockCountK;
    }
    std::byte* QuantData;     // NxBlockCountKxBlkLen
    float* QuantScale;        // NxBlockCountK
    float* BlockSum;          // NxBlockCountK
    void* PerGemmWorkspace_;  // memory for above data
    size_t M_, BlockCountK_, BlkLen_;
};

void MLASCALL
MlasQNBitGemmPackQuantBData(
    size_t N,
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const void* QuantBData,
    void* PackedQuantBDataAndOrBlkSumWorkspace,
    const void* QuantBScale,
    bool HasZeroPoint,
    const void* QuantBZeroPoint,
    MLAS_THREADPOOL* ThreadPool,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    if (QNBitGemmOverrideIsSupported(
            K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
        )) {
        const auto Pack = GetMlasPlatform().MlasQNBitGemmPackQuantBDataOverride;
        assert(Pack != nullptr);
        Pack(
            N, K, BlkBitWidth, BlkLen, ComputeType, QuantBData, PackedQuantBDataAndOrBlkSumWorkspace,
            QuantBScale, HasZeroPoint, QuantBZeroPoint, ThreadPool, BackendKernelSelectorConfig
        );
        return;
    }

    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr) {
        return;
    }

    if (BlkBitWidth == 4) {
        if (ComputeType == SQNBIT_CompInt8 && Dispatch->SQ4BitGemmPackQuantBDataAndBlkSum != nullptr) {
            const size_t BlockCountK = MlasDivRoundup(K, BlkLen);
            PackedQuantBDataStruct<float, 4> packed_quant_b(PackedQuantBDataAndOrBlkSumWorkspace, N, BlockCountK, BlkLen, false);
            Dispatch->SQ4BitGemmPackQuantBDataAndBlkSum(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<const float*>(QuantBScale),
                HasZeroPoint,
                static_cast<const std::byte*>(QuantBZeroPoint),
                packed_quant_b,
                ThreadPool,
                BackendKernelSelectorConfig
            );
        } else if (ComputeType == HQNBIT_CompFp16 && Dispatch->HQ4BitGemmPackQuantBData != nullptr) {
            Dispatch->HQ4BitGemmPackQuantBData(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<std::byte*>(PackedQuantBDataAndOrBlkSumWorkspace),
                ThreadPool,
                BackendKernelSelectorConfig
            );
        } else if (Dispatch->SQ4BitGemmPackQuantBData != nullptr) {
          // TODO: these assertions are true if called from matmul_nbits kernel but not from mlas tests.
            //assert(QuantBScale == nullptr);
            //assert(QuantBZeroPoint == nullptr);
            Dispatch->SQ4BitGemmPackQuantBData(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<std::byte*>(PackedQuantBDataAndOrBlkSumWorkspace),
                ThreadPool,
                BackendKernelSelectorConfig
            );
            return;
        }
    } else if (BlkBitWidth == 8) {
        if (ComputeType == HQNBIT_CompFp16 && Dispatch->HQ8BitGemmPackQuantBData != nullptr) {
            Dispatch->HQ8BitGemmPackQuantBData(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<std::byte*>(PackedQuantBDataAndOrBlkSumWorkspace),
                ThreadPool,
                BackendKernelSelectorConfig
            );
        } else if (ComputeType == SQNBIT_CompInt8 && Dispatch->SQ8BitGemmPackQuantBDataAndBlkSum != nullptr) {
            const size_t BlockCountK = MlasDivRoundup(K, BlkLen);
            PackedQuantBDataStruct<float, 8> packed_quant_b(PackedQuantBDataAndOrBlkSumWorkspace, N, BlockCountK,
                                                            BlkLen, GetMlasPlatform().ArmNeonIsQuantActivationsUnsigned);
            Dispatch->SQ8BitGemmPackQuantBDataAndBlkSum(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<const float*>(QuantBScale),
                HasZeroPoint,
                static_cast<const std::byte*>(QuantBZeroPoint),
                packed_quant_b,
                ThreadPool,
                BackendKernelSelectorConfig
            );
        }
    } else if (BlkBitWidth == 2) {
        if (ComputeType == SQNBIT_CompInt8 && Dispatch->SQ2BitGemmPackQuantBDataAndBlkSum != nullptr) {
            const size_t BlockCountK = MlasDivRoundup(K, BlkLen);
            PackedQuantBDataStruct<float, 2> packed_quant_b(PackedQuantBDataAndOrBlkSumWorkspace, N, BlockCountK, BlkLen, false);
            Dispatch->SQ2BitGemmPackQuantBDataAndBlkSum(
                N,
                K,
                BlkLen,
                ComputeType,
                static_cast<const std::byte*>(QuantBData),
                static_cast<const float*>(QuantBScale),
                HasZeroPoint,
                static_cast<const std::byte*>(QuantBZeroPoint),
                packed_quant_b,
                ThreadPool,
                BackendKernelSelectorConfig
            );
        }
    }
}

bool MLASCALL
MlasQNBitGemmScalesPacked(
    size_t K,
    size_t BlkBitWidth,
    size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    bool HasZeroPoint,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
) {
    return QNBitGemmOverrideIsSupported(
        K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
    );
}

namespace
{

MLAS_FORCEINLINE void
AddBiasForGemm(const float* Bias, float* C, size_t CountM, size_t CountN, size_t ldc)
{
    for (size_t m = 0; m < CountM; m++) {
        const float* bias = Bias;
        float* sum = C;
        for (size_t n = 0; n < CountN; n += 4) {
            if (CountN - n < 4) {
                for (size_t nn = n; nn < CountN; nn++) {
                    *sum += *bias;
                    sum++;
                    bias++;
                }
                break;
            }

            MLAS_FLOAT32X4 acc_x = MlasLoadFloat32x4(sum);
            acc_x = MlasAddFloat32x4(acc_x, MlasLoadFloat32x4(bias));
            MlasStoreFloat32x4(sum, acc_x);
            bias += 4;
            sum += 4;
        }
        C += ldc;
    }
}

// fp32 scratch for the fp16 output path below. One buffer per thread, shared by every bit
// width and compute type, grown to the largest strip that thread has computed. Only threads
// that take the fp16 path ever allocate.
float*
GetStripCFp16Scratch(size_t Elements)
{
    static thread_local std::vector<float> c_scratch;
    if (c_scratch.size() < Elements) {
        c_scratch.resize(Elements);
    }
    return c_scratch.data();
}

// Runs one GEMM kernel pass into that scratch and converts the strip to fp16, so the full
// fp32 result never lands in a caller buffer. RunKernel is handed the scratch and its
// leading dimension and must produce the strip over the whole M range exactly as the fp32
// branch does, which is what keeps the converted values bitwise identical to the fp32
// path. CFp16Strip points at the first element of the strip.
template <typename KernelFn>
void
StripCToFp16(
    KernelFn&& RunKernel,
    MLAS_FP16* CFp16Strip,
    size_t RangeCountM,
    size_t CountN,
    size_t ldc
)
{
    float* scratch = GetStripCFp16Scratch(RangeCountM * CountN);

    RunKernel(scratch, CountN);

    for (size_t m = 0; m < RangeCountM; ++m) {
        MlasConvertFloatToHalfBuffer(scratch + m * CountN, CFp16Strip + m * ldc, CountN);
    }
}

void
SQ4BitGemm_CompFp32(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    constexpr size_t BlkBitWidth = 4;

    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);
    MLAS_UNREFERENCED_PARAMETER(PerGemmWorkspace);

    const size_t lda = DataParams->lda;
    const size_t ldc = DataParams->ldc;

    const size_t k_blks = MlasDivRoundup(K, BlkLen);
    const size_t ldb = k_blks * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t k_blks_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blks);

    const float* A = DataParams->A + RangeStartM * lda;

    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * ldb;
    const float* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blks;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_blks_zp_bytes;

    const bool to_fp16 = DataParams->CFp16 != nullptr;
    MLAS_FP16* CFp16 = to_fp16 ? DataParams->CFp16 + RangeStartM * ldc + RangeStartN : nullptr;
    float* C = (DataParams->C == nullptr) ? nullptr : DataParams->C + RangeStartM * ldc + RangeStartN;

    const float* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;

    if (RangeCountM == 1) {
        size_t CountN;
        for (size_t n = 0; n < RangeCountN; n += CountN) {
            CountN = std::min(RangeCountN - n, size_t{128});

            const float* a_row = A;
            const std::byte* b_col = QuantBData + n * ldb;
            const float* b_col_scale = QuantBScale + n * k_blks;
            const std::byte* b_col_zp =
                (QuantBZeroPoint == nullptr) ? nullptr : QuantBZeroPoint + n * k_blks_zp_bytes;
            float* c_blk = (C == nullptr) ? nullptr : C + n;
            const float* bias = (Bias == nullptr) ? nullptr : Bias + n;

            if (to_fp16) {
                // fp16 output and a post-processor are never set together by the operator;
                // assert rather than silently drop it.
                assert(DataParams->PostProcessor == nullptr);
                StripCToFp16(
                    [&](float* c_out, size_t /*c_out_ldc*/) {
                        GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmM1Kernel_CompFp32(
                            BlkLen,
                            a_row, b_col, b_col_scale, b_col_zp, c_out, CountN, K, k_blks, bias
                        );
                    },
                    CFp16 + n, RangeCountM, CountN, ldc
                );
                continue;
            }

            GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmM1Kernel_CompFp32(
                BlkLen,
                a_row, b_col, b_col_scale, b_col_zp, c_blk, CountN, K, k_blks, bias
            );

            if (DataParams->PostProcessor != nullptr) {
                DataParams->PostProcessor->Process(
                    DataParams->C, RangeStartM, RangeStartN + n,
                    RangeCountM, CountN, ldc
                );
            }
        }
        return;
    }

    constexpr size_t StrideN = 32;
    size_t bufsize = k_blks * BlkLen * StrideN * sizeof(float);
    MlasThreadedBufAlloc(bufsize);
    auto* dequant_b = reinterpret_cast<float*>(ThreadedBufHolder.get());

    //
    // Step through each slice of matrix B along the N dimension.
    //
    size_t CountN;
    for (size_t n = 0; n < RangeCountN; n += CountN) {
        CountN = std::min(RangeCountN - n, StrideN);

        //
        // Step through each slice of matrix A along the M dimension.
        //
        const float* a_row = A;
        const std::byte* b_col = QuantBData + n * ldb;
        const float* b_col_scale = QuantBScale + n * k_blks;
        const std::byte* b_col_zp =
            (QuantBZeroPoint == nullptr) ? nullptr : QuantBZeroPoint + n * k_blks_zp_bytes;
        float* c_blk = (C == nullptr) ? nullptr : C + n;
        const float* bias = (Bias == nullptr) ? nullptr : Bias + n;

        GetMlasPlatform().QNBitGemmDispatch->SQ4BitBlkDequantBForSgemm_CompFp32(
            BlkLen,
            dequant_b, b_col, b_col_scale, b_col_zp, CountN, K, k_blks
        );

        if (to_fp16) {
            // fp16 output and a post-processor are never set together by the operator;
            // assert rather than silently drop it.
            assert(DataParams->PostProcessor == nullptr);
            StripCToFp16(
                [&](float* c_out, size_t c_out_ldc) {
                    const float* a_strip = a_row;
                    float* c_strip = c_out;
                    size_t RowsRemaining = RangeCountM;
                    while (RowsRemaining > 0) {
#if defined(MLAS_TARGET_AMD64_IX86) || defined(MLAS_TARGET_POWER) || defined(MLAS_TARGET_S390X) || defined(MLAS_TARGET_LARCH64)
                        auto RowsHandled = GetMlasPlatform().GemmFloatKernel(
                            a_strip, dequant_b, c_strip, K, RowsRemaining, CountN, lda, c_out_ldc, 1.f, true
                        );
#else
                        auto RowsHandled = MlasSgemmKernelZero(a_strip, dequant_b, c_strip, K, RowsRemaining, CountN, lda, c_out_ldc, 1.f);
#endif

                        if (bias) {
                            AddBiasForGemm(bias, c_strip, RowsHandled, CountN, c_out_ldc);
                        }

                        c_strip += c_out_ldc * RowsHandled;
                        a_strip += lda * RowsHandled;
                        RowsRemaining -= RowsHandled;
                    }
                },
                CFp16 + n, RangeCountM, CountN, ldc
            );
            continue;
        }

        size_t RowsRemaining = RangeCountM;
        while (RowsRemaining > 0) {
#if defined(MLAS_TARGET_AMD64_IX86) || defined(MLAS_TARGET_POWER) || defined(MLAS_TARGET_S390X) || defined(MLAS_TARGET_LARCH64)
            auto RowsHandled = GetMlasPlatform().GemmFloatKernel(
                a_row, dequant_b, c_blk, K, RowsRemaining, CountN, lda, ldc, 1.f, true
            );
#else
            auto RowsHandled = MlasSgemmKernelZero(a_row, dequant_b, c_blk, K, RowsRemaining, CountN, lda, ldc, 1.f);
#endif

            if (bias) {
                AddBiasForGemm(bias, c_blk, RowsHandled, CountN, ldc);
            }
            if (DataParams->PostProcessor != nullptr) {
                DataParams->PostProcessor->Process(
                    DataParams->C, RangeStartM + RangeCountM - RowsRemaining, RangeStartN + n,
                    RowsHandled, CountN, ldc
                );
            }

            c_blk += ldc * RowsHandled;
            a_row += lda * RowsHandled;
            RowsRemaining -= RowsHandled;
        }
    }
}

void
HQ4BitGemm_CompFp16(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<MLAS_FP16>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    constexpr size_t BlkBitWidth = 4;
    MLAS_UNREFERENCED_PARAMETER(PerGemmWorkspace);
    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);

    const size_t lda = DataParams->lda;
    const size_t ldc = DataParams->ldc;
    const size_t k_blk_num = MlasDivRoundup(K, BlkLen);
    const size_t qldb = k_blk_num * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t ldb = k_blk_num * BlkLen;
    const size_t k_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blk_num);

    const MLAS_FP16* A = DataParams->A + RangeStartM * lda;
    MLAS_FP16* C = DataParams->C + RangeStartM * ldc + RangeStartN;
    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * qldb;
    const MLAS_FP16* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blk_num;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_zp_bytes;
    const MLAS_FP16* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;

    // 32N is the sweet spot of cache utilization. It is machine dependent though.
    constexpr size_t StrideM = 2;
    constexpr size_t StrideN = 32;

    // TODO(fajin): move allocation up to the op.
    size_t bufsize = ldb * StrideN * sizeof(MLAS_FP16);
    MlasThreadedBufAlloc(bufsize);
    auto* dequant_b = reinterpret_cast<MLAS_FP16*>(ThreadedBufHolder.get());

    for (size_t n = 0, countN; n < RangeCountN; n += countN) {
        countN = std::min(StrideN, RangeCountN - n);
        GetMlasPlatform().QNBitGemmDispatch->HQ4BitBlkDequantBForHgemm_CompFp16(
            BlkLen, dequant_b, QuantBData, QuantBScale, QuantBZeroPoint, countN, K, k_blk_num
        );

        const MLAS_FP16* a = A;
        MLAS_FP16* c = C;
        for (size_t m = 0, countM; m < RangeCountM; m += countM) {
            countM = std::min(StrideM, RangeCountM - m);
            GetMlasPlatform().QNBitGemmDispatch->HQ4BitGemmKernel_CompFp16(
                a, dequant_b, Bias, c, countM, countN, K, lda, ldb, ldc
            );

            if (DataParams->PostProcessor != nullptr) {
                DataParams->PostProcessor->Process(
                    DataParams->C, RangeStartM + m, RangeStartN + n, countM, countN, ldc
                );
            }

            a += countM * lda;
            c += countM * ldc;
        }

        QuantBData += countN * qldb;
        QuantBScale += countN * k_blk_num;
        QuantBZeroPoint = QuantBZeroPoint ? QuantBZeroPoint + countN * k_zp_bytes : nullptr;
        Bias = Bias ? Bias + countN : nullptr;
        C += countN;
    }
}

void
HQ8BitGemm_CompFp16(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<MLAS_FP16>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    constexpr size_t BlkBitWidth = 8;
    MLAS_UNREFERENCED_PARAMETER(PerGemmWorkspace);
    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);

    const size_t lda = DataParams->lda;
    const size_t ldc = DataParams->ldc;
    const size_t k_blk_num = MlasDivRoundup(K, BlkLen);
    const size_t qldb = k_blk_num * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t ldb = k_blk_num * BlkLen;
    const size_t k_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blk_num);

    const MLAS_FP16* A = DataParams->A + RangeStartM * lda;
    MLAS_FP16* C = DataParams->C + RangeStartM * ldc + RangeStartN;
    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * qldb;
    const MLAS_FP16* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blk_num;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_zp_bytes;
    const MLAS_FP16* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;

    constexpr size_t StrideM = 2;
    constexpr size_t StrideN = 32;

    size_t bufsize = ldb * StrideN * sizeof(MLAS_FP16);
    MlasThreadedBufAlloc(bufsize);
    auto* dequant_b = reinterpret_cast<MLAS_FP16*>(ThreadedBufHolder.get());

    for (size_t n = 0, countN; n < RangeCountN; n += countN) {
        countN = std::min(StrideN, RangeCountN - n);
        GetMlasPlatform().QNBitGemmDispatch->HQ8BitBlkDequantBForHgemm_CompFp16(
            BlkLen, dequant_b, QuantBData, QuantBScale, QuantBZeroPoint, countN, K, k_blk_num
        );

        const MLAS_FP16* a = A;
        MLAS_FP16* c = C;
        for (size_t m = 0, countM; m < RangeCountM; m += countM) {
            countM = std::min(StrideM, RangeCountM - m);
            // Reuse the same fp16 GEMM kernel - it operates on dequantized fp16 data
            GetMlasPlatform().QNBitGemmDispatch->HQ4BitGemmKernel_CompFp16(
                a, dequant_b, Bias, c, countM, countN, K, lda, ldb, ldc
            );

            if (DataParams->PostProcessor != nullptr) {
                DataParams->PostProcessor->Process(
                    DataParams->C, RangeStartM + m, RangeStartN + n, countM, countN, ldc
                );
            }

            a += countM * lda;
            c += countM * ldc;
        }

        QuantBData += countN * qldb;
        QuantBScale += countN * k_blk_num;
        QuantBZeroPoint = QuantBZeroPoint ? QuantBZeroPoint + countN * k_zp_bytes : nullptr;
        Bias = Bias ? Bias + countN : nullptr;
        C += countN;
    }
}

void
SQ4BitGemm_CompInt8(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);

#ifdef MLAS_TARGET_AMD64_IX86
    PerGemmQuantAWorkspace* const per_gemm_quant_a_workspace = static_cast<PerGemmQuantAWorkspace*>(PerGemmWorkspace);
    constexpr size_t BlkBitWidth = 4;

    const size_t k_blks = MlasDivRoundup(K, BlkLen);

    // quant A scale is embedded in QuantData if QuantScale is nullptr.
    const size_t lda = k_blks * (per_gemm_quant_a_workspace->QuantScale ? BlkLen : Q8BlkSize(BlkLen));
    const size_t ldc = DataParams->ldc;
    const size_t ldb = k_blks * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t k_blks_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blks);

    const std::byte* QuantA = per_gemm_quant_a_workspace->QuantData + RangeStartM * lda;
    const float* QuantAScale = per_gemm_quant_a_workspace->QuantScale + RangeStartM * k_blks;

    assert(RangeStartN % 4 == 0);
    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * ldb;
    const float* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blks;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_blks_zp_bytes;
    const float* ABlockSum = per_gemm_quant_a_workspace->BlockSum + RangeStartM * k_blks;
    const float* QuantBBlkSum = DataParams->QuantBBlkSum + RangeStartN * k_blks;

    // fp16 output: let the kernel write each N-strip into a per-thread fp32 scratch, then
    // convert that strip straight to fp16, so the full fp32 result never lands in a caller
    // buffer. The scratch is grown to the strip actually computed (RangeCountM x CountN) and
    // reused across calls; it only ever allocates on threads that take this path.
    // In this mode DataParams->C is not a full result buffer, so leave the fp32 C base null.
    const bool to_fp16 = DataParams->CFp16 != nullptr;
    MLAS_FP16* CFp16 = to_fp16 ? DataParams->CFp16 + RangeStartM * ldc + RangeStartN : nullptr;
    float* C = to_fp16 ? nullptr : DataParams->C + RangeStartM * ldc + RangeStartN;

    const float* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;
#else
    constexpr size_t BlkBitWidth = 4;

    const size_t k_blks = MlasDivRoundup(K, BlkLen);

    const size_t lda = k_blks * Q8BlkSize(BlkLen);
    const size_t ldc = DataParams->ldc;
    const size_t ldb = k_blks * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t k_blks_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blks);

    const std::byte* QuantA = static_cast<const std::byte*>(PerGemmWorkspace) + RangeStartM * lda;

    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * ldb;
    const float* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blks;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_blks_zp_bytes;

    float* C = DataParams->C + RangeStartM * ldc + RangeStartN;

    const float* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;
#endif

    size_t CountN;
    for (size_t n = 0; n < RangeCountN; n += CountN) {
        CountN = std::min(RangeCountN - n, kQNBitGemmComputeStrideN);

        const std::byte* a_row = QuantA;
        const std::byte* b_col = QuantBData + n * ldb;
        const float* b_col_scale = QuantBScale + n * k_blks;
        const std::byte* b_col_zp =
            (QuantBZeroPoint == nullptr) ? nullptr : QuantBZeroPoint + n * k_blks_zp_bytes;
        float* c_blk = (C == nullptr) ? nullptr : C + n;
        const float* bias = (Bias == nullptr) ? nullptr : Bias + n;

        if (GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_CompInt8 != nullptr) {
            size_t RowsRemaining = RangeCountM;
            while (RowsRemaining > 0) {
                const auto RowsHandled = GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_CompInt8(
                    BlkLen,
                    a_row, b_col, b_col_scale, b_col_zp, c_blk, RowsRemaining, CountN, K, k_blks, ldc, bias
                );

                if (DataParams->PostProcessor != nullptr) {
                    DataParams->PostProcessor->Process(
                        DataParams->C, RangeStartM + RangeCountM - RowsRemaining, RangeStartN + n,
                        RowsHandled, CountN, ldc
                    );
                }

                c_blk += RowsHandled * ldc;
                a_row += RowsHandled * lda;

                RowsRemaining -= RowsHandled;
            }
        }
#ifdef MLAS_TARGET_AMD64_IX86
        else if (GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_BlkSum_CompInt8 != nullptr)
        {
            const float* b_blk_sum = QuantBBlkSum + n * k_blks;
            if (to_fp16) {
                // fp16 output and a post-processor are never set together by the operator, so the
                // fp32-branch post-processing does not apply here; assert rather than silently
                // drop it.
                assert(DataParams->PostProcessor == nullptr);
                StripCToFp16(
                    [&](float* c_out, size_t c_out_ldc) {
                        GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_BlkSum_CompInt8(
                            BlkLen,
                            QuantA,
                            QuantAScale,
                            b_col,
                            b_col_scale,
                            b_col_zp,
                            c_out,
                            RangeCountM,
                            CountN,
                            K,
                            k_blks,
                            bias,
                            c_out_ldc,
                            ABlockSum,
                            b_blk_sum
                        );
                    },
                    CFp16 + n, RangeCountM, CountN, ldc
                );
            } else {
                GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_BlkSum_CompInt8(
                    BlkLen,
                    QuantA,
                    QuantAScale,
                    b_col,
                    b_col_scale,
                    b_col_zp,
                    c_blk,
                    RangeCountM,
                    CountN,
                    K,
                    k_blks,
                    bias,
                    ldc,
                    ABlockSum,
                    b_blk_sum
                );
                if (DataParams->PostProcessor != nullptr) {
                    DataParams->PostProcessor->Process(
                        DataParams->C, RangeStartM, RangeStartN + n,
                        RangeCountM, CountN, ldc
                    );
                }
            }
        }
#endif
    }
}

void
SQ8BitGemm_CompInt8(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);
    PerGemmQuantAWorkspace* const per_gemm_quant_a_workspace = static_cast<PerGemmQuantAWorkspace*>(PerGemmWorkspace);
    constexpr size_t BlkBitWidth = 8;

    const size_t k_blks = MlasDivRoundup(K, BlkLen);

    // quant A scale is embedded in QuantData if QuantScale is nullptr.
    const size_t lda = k_blks * (per_gemm_quant_a_workspace->QuantScale ? BlkLen : Q8BlkSize(BlkLen));
    const size_t ldc = DataParams->ldc;
    const size_t ldb = k_blks * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);
    const size_t k_blks_zp_bytes = MlasQNBitZeroPointsForBlksSizeInBytes<BlkBitWidth>(k_blks);

    const std::byte* QuantA = per_gemm_quant_a_workspace->QuantData + RangeStartM * lda;
    const float* QuantAScale = per_gemm_quant_a_workspace->QuantScale + RangeStartM * k_blks;

    assert(RangeStartN % 16 == 0);
    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * ldb;
    const float* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blks;
    const std::byte* QuantBZeroPoint =
        (DataParams->QuantBZeroPoint == nullptr)
            ? nullptr
            : static_cast<const std::byte*>(DataParams->QuantBZeroPoint) + RangeStartN * k_blks_zp_bytes;
    const float* ABlockSum = per_gemm_quant_a_workspace->BlockSum + RangeStartM * k_blks;
    const float* QuantBBlkSum = DataParams->QuantBBlkSum + RangeStartN * k_blks;
    const float* BlkUnsignedQuantAZeroPointCorrection =
        DataParams->BlkUnsignedQuantAZeroPointCorrection ? DataParams->BlkUnsignedQuantAZeroPointCorrection + RangeStartN * k_blks : nullptr;

    const bool to_fp16 = DataParams->CFp16 != nullptr;
    MLAS_FP16* CFp16 = to_fp16 ? DataParams->CFp16 + RangeStartM * ldc + RangeStartN : nullptr;
    float* C = to_fp16 ? nullptr : DataParams->C + RangeStartM * ldc + RangeStartN;

    const float* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;

    size_t CountN;
    for (size_t n = 0; n < RangeCountN; n += CountN) {
        CountN = std::min(RangeCountN - n, size_t{128});

        const std::byte* b_col = QuantBData + n * ldb;
        const float* b_col_scale = QuantBScale + n * k_blks;
        const std::byte* b_col_zp =
            (QuantBZeroPoint == nullptr) ? nullptr : QuantBZeroPoint + n * k_blks_zp_bytes;
        float* c_blk = (C == nullptr) ? nullptr : C + n;
        const float* bias = (Bias == nullptr) ? nullptr : Bias + n;

        if (GetMlasPlatform().QNBitGemmDispatch->SQ8BitGemmKernel_BlkSum_CompInt8 != nullptr) {
            const float* b_blk_sum = QuantBBlkSum + n * k_blks;
            const float* blk_unsigned_quant_A_zp_correction = BlkUnsignedQuantAZeroPointCorrection ?
                BlkUnsignedQuantAZeroPointCorrection + n * k_blks : nullptr;
            if (to_fp16) {
                assert(DataParams->PostProcessor == nullptr);
                StripCToFp16(
                    [&](float* c_out, size_t c_out_ldc) {
                        GetMlasPlatform().QNBitGemmDispatch->SQ8BitGemmKernel_BlkSum_CompInt8(
                            BlkLen,
                            QuantA,
                            QuantAScale,
                            b_col,
                            b_col_scale,
                            b_col_zp,
                            c_out,
                            RangeCountM,
                            CountN,
                            K,
                            k_blks,
                            bias,
                            c_out_ldc,
                            ABlockSum,
                            b_blk_sum,
                            blk_unsigned_quant_A_zp_correction
                        );
                    },
                    CFp16 + n, RangeCountM, CountN, ldc
                );
            } else {
                GetMlasPlatform().QNBitGemmDispatch->SQ8BitGemmKernel_BlkSum_CompInt8(
                    BlkLen,
                    QuantA,
                    QuantAScale,
                    b_col,
                    b_col_scale,
                    b_col_zp,
                    c_blk,
                    RangeCountM,
                    CountN,
                    K,
                    k_blks,
                    bias,
                    ldc,
                    ABlockSum,
                    b_blk_sum,
                    blk_unsigned_quant_A_zp_correction
                );

                if (DataParams->PostProcessor != nullptr) {
                    DataParams->PostProcessor->Process(
                        DataParams->C, RangeStartM, RangeStartN + n,
                        RangeCountM, CountN, ldc
                    );
                }
            }
        }
    }
}

//
// 2-bit weight CompInt8 wrapper. Mirrors SQ4BitGemm_CompInt8 but specialised
// for BlkBitWidth=2 (kBlkBytes = BlkLen/4). QuantBBlkSum uses the existing
// SGEMM-style width-16 chunked layout produced by the PackQuantBDataAndBlkSum
// helpers (same as the W4 CompInt8 path); see the comment on
// Q2BitGemmEffectiveBlockCountK in qnbitgemm.h for how the W2 packed-B
// stride differs from the BlkSum stride.
//
void
SQ2BitGemm_CompInt8(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* /*BackendKernelSelectorConfig*/
)
{
    constexpr size_t BlkBitWidth = 2;

    const auto* Dispatch = GetMlasPlatform().QNBitGemmDispatch;
    if (Dispatch == nullptr || Dispatch->SQ2BitGemmKernel_BlkSum_CompInt8 == nullptr) {
        return;
    }

    PerGemmQuantAWorkspace* const per_gemm_quant_a_workspace =
        static_cast<PerGemmQuantAWorkspace*>(PerGemmWorkspace);

    const size_t k_blks = MlasDivRoundup(K, BlkLen);

    // The packed-B-data and per-block-scale buffers may use a layout that
    // addresses each N-col at a stride larger than `k_blks` (e.g. the AVX-512
    // W2 kernel rounds up to a multiple of 4 to amortize unpack across 4
    // K-blocks). Ask the dispatch for the effective per-N-col block count;
    // default to logical k_blks if the dispatch doesn't override.
    // BlkSum keeps the logical stride because the SGEMM correction step
    // expects width-16 chunked PackB layout independent of the W2 packed-B
    // stride convention.
    const size_t k_blks_eff = (Dispatch->Q2BitGemmEffectiveBlockCountK != nullptr)
                                  ? Dispatch->Q2BitGemmEffectiveBlockCountK(k_blks)
                                  : k_blks;

    const size_t lda = k_blks * (per_gemm_quant_a_workspace->QuantScale ? BlkLen : Q8BlkSize(BlkLen));
    const size_t ldc = DataParams->ldc;
    const size_t ldb = k_blks_eff * MlasQNBitBlkDataSizeInBytes(BlkBitWidth, BlkLen);  // BlkLen / 4 bytes per block

    const std::byte* QuantA = per_gemm_quant_a_workspace->QuantData + RangeStartM * lda;
    const float* QuantAScale = per_gemm_quant_a_workspace->QuantScale + RangeStartM * k_blks;

    // QuantBBlkSum uses the width-16 chunked layout produced by
    // ComputePackBlkSum (BlockSum[n] lives at chunk (n/16) at intra-chunk
    // offset n%16), so the flat `QuantBBlkSum + RangeStartN * k_blks`
    // addressing below is only correct when RangeStartN is a multiple of 16.
    // The work partitioner enforces this via MLAS_QGEMM_STRIDEN_THREAD_ALIGN
    // (= 16); the assert documents the contract and would catch a future
    // partitioner regression.
    assert(RangeStartN % 16 == 0);
    const std::byte* QuantBData = static_cast<const std::byte*>(DataParams->PackedQuantBData) + RangeStartN * ldb;
    const float* QuantBScale = DataParams->QuantBScale + RangeStartN * k_blks_eff;
    const float* ABlockSum = per_gemm_quant_a_workspace->BlockSum + RangeStartM * k_blks;
    const float* QuantBBlkSum = DataParams->QuantBBlkSum + RangeStartN * k_blks;

    const bool to_fp16 = DataParams->CFp16 != nullptr;
    MLAS_FP16* CFp16 = to_fp16 ? DataParams->CFp16 + RangeStartM * ldc + RangeStartN : nullptr;
    float* C = to_fp16 ? nullptr : DataParams->C + RangeStartM * ldc + RangeStartN;

    const float* Bias = (DataParams->Bias == nullptr) ? nullptr : DataParams->Bias + RangeStartN;

    size_t CountN;
    for (size_t n = 0; n < RangeCountN; n += CountN) {
        CountN = std::min(RangeCountN - n, size_t{128});

        const std::byte* b_col = QuantBData + n * ldb;
        const float* b_col_scale = QuantBScale + n * k_blks_eff;
        float* c_blk = (C == nullptr) ? nullptr : C + n;
        const float* bias = (Bias == nullptr) ? nullptr : Bias + n;
        const float* b_blk_sum = QuantBBlkSum + n * k_blks;

        if (to_fp16) {
            assert(DataParams->PostProcessor == nullptr);
            StripCToFp16(
                [&](float* c_out, size_t c_out_ldc) {
                    Dispatch->SQ2BitGemmKernel_BlkSum_CompInt8(
                        BlkLen,
                        QuantA,
                        QuantAScale,
                        b_col,
                        b_col_scale,
                        /*QuantBZeroPoint*/ nullptr,
                        c_out,
                        RangeCountM,
                        CountN,
                        K,
                        k_blks,
                        bias,
                        c_out_ldc,
                        ABlockSum,
                        b_blk_sum
                    );
                },
                CFp16 + n, RangeCountM, CountN, ldc
            );
            continue;
        }

        Dispatch->SQ2BitGemmKernel_BlkSum_CompInt8(
            BlkLen,
            QuantA,
            QuantAScale,
            b_col,
            b_col_scale,
            /*QuantBZeroPoint*/ nullptr,
            c_blk,
            RangeCountM,
            CountN,
            K,
            k_blks,
            bias,
            ldc,
            ABlockSum,
            b_blk_sum
        );

        if (DataParams->PostProcessor != nullptr) {
            DataParams->PostProcessor->Process(
                DataParams->C, RangeStartM, RangeStartN + n,
                RangeCountM, CountN, ldc
            );
        }
    }
}

template <typename T>
void
InitializeWorkspace_CompInt8(
    size_t M,
    size_t N,
    size_t K,
    size_t BatchN,
    size_t BlkLen,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<T>* DataParams,
    void* Workspace,
    size_t PerGemmWorkspaceStride,
    MLAS_THREADPOOL* ThreadPool,
    size_t BlkBitWidth,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
);

template <>
void
InitializeWorkspace_CompInt8<float>(
    size_t M,
    size_t N,
    size_t K,
    size_t BatchN,
    size_t BlkLen,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* DataParams,
    void* Workspace,
    size_t PerGemmWorkspaceStride,
    MLAS_THREADPOOL* ThreadPool,
    size_t BlkBitWidth,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    MLAS_UNREFERENCED_PARAMETER(N);
    MLAS_UNREFERENCED_PARAMETER(BackendKernelSelectorConfig);

    const auto QuantizeARow = GetMlasPlatform().QNBitGemmDispatch->QuantizeARow_CompInt8;
    const auto QuantizeARow2 = GetMlasPlatform().QNBitGemmDispatch->QuantizeARowComputeBlkSum_CompInt8;
    const auto QuantizeARow2Fp16 = GetMlasPlatform().QNBitGemmDispatch->QuantizeARowComputeBlkSum_CompInt8_Fp16;

    const size_t BlockCountK = MlasDivRoundup(K, BlkLen);
    const size_t QuantAStride = BlockCountK * Q8BlkSize(BlkLen);

    // TODO: try parallel on BatchN * M threads because BatchN is usually 1.
    // TODO(hasesh): The (BlkBitWidth x A-layout x A-signedness) matrix below is
    // resolved by a hand-rolled cascade because the dispatch exposes both an
    // interleaved-scale (W4-style) and a separate-scale (W8-style) quantize fn,
    // plus a W2-specific signed-A override. Ideally the dispatch itself would
    // expose a single "correct quantize fn for this (bit-width, kernel)" pointer
    // so this call-site would not have to reason about layout/sign compatibility.
    if (BlkBitWidth == 4 || BlkBitWidth == 2) {
        // W2 requires the W8-style separate-scale layout produced by
        // QuantizeARowComputeBlkSum_CompInt8 because the W2 SQ2BitGemm
        // kernel reads QuantData (M*K int8 flat) and QuantScale
        // (M*BlockCountK float) as independent buffers. The W4-style
        // interleaved layout produced by QuantizeARow_CompInt8 packs the
        // scale inside each Q8Blk and is therefore incompatible. On hosts
        // that register both (e.g. NEON FEAT_DotProd, which uses
        // QuantizeARow for the W4 path and QuantizeARowComputeBlkSum for
        // W8), force W2 down the W8-compatible branch.
        const bool prefer_compute_blksum = (BlkBitWidth == 2);
        if (QuantizeARow && !prefer_compute_blksum) {
            MlasTrySimpleParallel(ThreadPool, BatchN, [&](ptrdiff_t gemm_idx) {
                const auto& data = DataParams[gemm_idx];

                const float* ARowPtr = data.A;
                std::byte* QuantARowPtr = static_cast<std::byte*>(Workspace) + gemm_idx * PerGemmWorkspaceStride;
                for (size_t m = 0; m < M; ++m) {
                    QuantizeARow(BlkLen, ARowPtr, K, QuantARowPtr);

                    ARowPtr += data.lda;
                    QuantARowPtr += QuantAStride;
                }
            });
        } else if (QuantizeARow2) {
            // W2 needs SIGNED int8 A (NEON DotProd-only hosts wire the
            // shared QuantizeARowComputeBlkSum_CompInt8 to the UNSIGNED
            // u8 = i8+128 W8-compatible variant). Prefer the W2-specific
            // override when set so the W2 kernel always sees signed A.
            const auto QuantizeARow2_W2 =
                (BlkBitWidth == 2 && GetMlasPlatform().QNBitGemmDispatch->QuantizeARowComputeBlkSum_CompInt8_W2 != nullptr)
                    ? GetMlasPlatform().QNBitGemmDispatch->QuantizeARowComputeBlkSum_CompInt8_W2
                    : QuantizeARow2;
            MlasTrySimpleParallel(ThreadPool, BatchN, [&](ptrdiff_t gemm_idx) {
                const auto& data = DataParams[gemm_idx];
                const float* ARowPtr = data.A;
                const MLAS_FP16* AFp16RowPtr = data.AFp16;
                const bool quant_from_fp16 = AFp16RowPtr != nullptr && QuantizeARow2Fp16 != nullptr;

                void* PerGemmWorkspace = static_cast<std::byte*>(Workspace) + gemm_idx * PerGemmWorkspaceStride;
                PerGemmQuantAWorkspace quant_a_data(PerGemmWorkspace, M, BlockCountK, BlkLen);
                std::byte* QuantARowPtr = quant_a_data.QuantData;
                float* QuantARowScalePtr = quant_a_data.QuantScale;
                float* QuantARowBlkSum = quant_a_data.BlockSum;
                for (size_t m = 0; m < M; ++m) {
                    if (quant_from_fp16) {
                        QuantizeARow2Fp16(BlkLen, AFp16RowPtr, K, QuantARowPtr, QuantARowScalePtr, QuantARowBlkSum);
                        AFp16RowPtr += data.lda;
                    } else {
                        QuantizeARow2_W2(BlkLen, ARowPtr, K, QuantARowPtr, QuantARowScalePtr, QuantARowBlkSum);
                        ARowPtr += data.lda;
                    }
                    QuantARowPtr += BlockCountK * BlkLen;
                    QuantARowScalePtr += BlockCountK;
                    QuantARowBlkSum += BlockCountK;
                }
            });
        }
    } else if (BlkBitWidth == 8) {
        if (QuantizeARow2) {
            MlasTrySimpleParallel(ThreadPool, BatchN, [&](ptrdiff_t gemm_idx) {
                const auto& data = DataParams[gemm_idx];
                const float* ARowPtr = data.A;
                const MLAS_FP16* AFp16RowPtr = data.AFp16;
                const bool quant_from_fp16 = AFp16RowPtr != nullptr && QuantizeARow2Fp16 != nullptr;

                void* PerGemmWorkspace = static_cast<std::byte*>(Workspace) + gemm_idx * PerGemmWorkspaceStride;
                PerGemmQuantAWorkspace quant_a_data(PerGemmWorkspace, M, BlockCountK, BlkLen);
                std::byte* QuantARowPtr = quant_a_data.QuantData;
                float* QuantARowScalePtr = quant_a_data.QuantScale;
                float* QuantARowBlkSum = quant_a_data.BlockSum;
                for (size_t m = 0; m < M; ++m) {
                    if (quant_from_fp16) {
                        QuantizeARow2Fp16(BlkLen, AFp16RowPtr, K, QuantARowPtr, QuantARowScalePtr, QuantARowBlkSum);
                        AFp16RowPtr += data.lda;
                    } else {
                        QuantizeARow2(BlkLen, ARowPtr, K, QuantARowPtr, QuantARowScalePtr, QuantARowBlkSum);
                        ARowPtr += data.lda;
                    }
                    QuantARowPtr += BlockCountK * BlkLen;
                    QuantARowScalePtr += BlockCountK;
                    QuantARowBlkSum += BlockCountK;
                }
            });
        }
    }
}

template <typename T>
using InitializeWorkspaceFn = std::function<void(
    size_t M,
    size_t N,
    size_t K,
    size_t BatchN,
    size_t BlkLen,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<T>* DataParams,
    void* Workspace,
    size_t PerGemmWorkspaceStride,
    MLAS_THREADPOOL* ThreadPool,
    size_t BlkBitWidth,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)>;

template <typename T>
InitializeWorkspaceFn<T>
GetInitializeWorkspace(QNBitGemmVariant variant);

template <>
InitializeWorkspaceFn<float>
GetInitializeWorkspace(QNBitGemmVariant variant)
{
    switch (variant) {
        case SQ4BitGemmVariant_CompInt8:
        case SQ8BitGemmVariant_CompInt8:
        case SQ2BitGemmVariant_CompInt8:
            return InitializeWorkspace_CompInt8<float>;
        default:
            return nullptr;
    }
}

template <>
InitializeWorkspaceFn<MLAS_FP16>
GetInitializeWorkspace(QNBitGemmVariant variant)
{
    MLAS_UNREFERENCED_PARAMETER(variant);
    return nullptr;
}

template <typename T>
using QNBitGemmFn = std::function<void(
    const size_t BlkLen,
    const size_t K,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<T>* const DataParams,
    void* const PerGemmWorkspace,
    const size_t RangeStartM,
    const size_t RangeCountM,
    const size_t RangeStartN,
    const size_t RangeCountN,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)>;

template <typename T>
QNBitGemmFn<T>
GetQNBitGemm(QNBitGemmVariant variant);

template <>
QNBitGemmFn<float>
GetQNBitGemm(QNBitGemmVariant variant)
{
    switch (variant) {
        case SQ4BitGemmVariant_CompFp32:
            return SQ4BitGemm_CompFp32;
        case SQ4BitGemmVariant_CompInt8:
            return SQ4BitGemm_CompInt8;
        case SQ8BitGemmVariant_CompInt8:
            return SQ8BitGemm_CompInt8;
        case SQ2BitGemmVariant_CompInt8:
            // W2 CompInt8 compute kernel registered by the AVX-512 /
            // AVX-512-VNNI dispatch tables.
            return SQ2BitGemm_CompInt8;
        default:
            return nullptr;
    }
}

template <>
QNBitGemmFn<MLAS_FP16>
GetQNBitGemm(QNBitGemmVariant variant)
{
    switch (variant) {
        case HQ4BitGemmVariant_CompFp16:
            return HQ4BitGemm_CompFp16;
        case HQ8BitGemmVariant_CompFp16:
            return HQ8BitGemm_CompFp16;
        default:
            return nullptr;
    }
}
}  // namespace

template <typename T>
void MLASCALL
MlasQNBitGemmBatch(
    const size_t M,
    const size_t N,
    const size_t K,
    const size_t BatchN,
    const size_t BlkBitWidth,
    const size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<T>* DataParams,
    void* Workspace,
    MLAS_THREADPOOL* ThreadPool,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
)
{
    if constexpr (std::is_same_v<T, float>) {
        const bool HasZeroPoint = DataParams->QuantBZeroPoint != nullptr;
        if (QNBitGemmOverrideIsSupported(
                K, BlkBitWidth, BlkLen, HasZeroPoint, ComputeType, BackendKernelSelectorConfig
            )) {
            const auto Batch = GetMlasPlatform().MlasQNBitGemmBatchOverride;
            assert(Batch != nullptr);
            Batch(
                M, N, K, BatchN, BlkBitWidth, BlkLen, ComputeType, DataParams, Workspace, ThreadPool,
                BackendKernelSelectorConfig
            );
            return;
        }
    }

    const auto Variant = GetQNBitGemmVariant(BlkBitWidth, BlkLen, ComputeType);
    assert(Variant != SQNBitGemmVariantInvalid);

    //
    // Ensure `Workspace` has correct alignment.
    //
    if (Workspace != nullptr) {
        const size_t Alignment = QNBitGemmPerGemmWorkspaceAlignment(BlkBitWidth, BlkLen, ComputeType);
        const uintptr_t WorkspaceAddress = reinterpret_cast<uintptr_t>(Workspace);
        Workspace = reinterpret_cast<void*>(
            (WorkspaceAddress + Alignment - 1) & (~(Alignment - 1))
        );
    }

    const bool has_zp_input = DataParams->QuantBZeroPoint != nullptr;
    const size_t PerGemmWorkspaceStride =
        QNBitGemmPerGemmWorkspaceStride(M, N, K, BlkBitWidth, BlkLen, has_zp_input, ComputeType, BackendKernelSelectorConfig);

    if (const auto InitializeWorkspaceOperation = GetInitializeWorkspace<T>(Variant);
        InitializeWorkspaceOperation != nullptr) {
        InitializeWorkspaceOperation(
            M, N, K, BatchN, BlkLen, DataParams, Workspace, PerGemmWorkspaceStride, ThreadPool, BlkBitWidth, BackendKernelSelectorConfig
        );
    }

    const auto ComputeOperation = GetQNBitGemm<T>(Variant);

    const size_t BlockCountK = MlasDivRoundup(K, BlkLen);

    if (ThreadPool == nullptr) {
        for (size_t gemm_i = 0; gemm_i < BatchN; gemm_i++) {
            const auto* Data = &DataParams[gemm_i];
            void* PerGemmWorkspace =
                reinterpret_cast<std::byte*>(Workspace) + gemm_i * PerGemmWorkspaceStride;
            if (Variant == SQ4BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_BlkSum_CompInt8 != nullptr) {
                PackedQuantBDataStruct<T, 4> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, false);
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;
                PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
                ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, 0, M, 0, N, BackendKernelSelectorConfig);
            } else if (Variant == SQ8BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ8BitGemmKernel_BlkSum_CompInt8 != nullptr) {
                PackedQuantBDataStruct<T, 8> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, GetMlasPlatform().ArmNeonIsQuantActivationsUnsigned);
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->BlkUnsignedQuantAZeroPointCorrection = packed_quant_b.BlkUnsignedQuantAZeroPointCorrection;

                PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
                ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, 0, M, 0, N, BackendKernelSelectorConfig);
            } else if (Variant == SQ2BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ2BitGemmKernel_BlkSum_CompInt8 != nullptr) {
                PackedQuantBDataStruct<T, 2> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, false);
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
                const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;
                PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
                ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, 0, M, 0, N, BackendKernelSelectorConfig);
            } else {
                ComputeOperation(BlkLen, K, Data, PerGemmWorkspace, 0, M, 0, N, BackendKernelSelectorConfig);
            }
        }
        return;
    }

    //
    // Compute the number of target threads given the complexity of the SGEMM
    // operation. Small requests should run using the single threaded path.
    //

    const double Complexity = double(M) * double(N) * double(K) * double(BatchN);

    ptrdiff_t TargetThreadCount = ptrdiff_t(Complexity / double(MLAS_QGEMM_THREAD_COMPLEXITY)) + 1;

    ptrdiff_t MaximumThreadCount = MlasGetMaximumThreadCount(ThreadPool) * 8;

    if (TargetThreadCount >= MaximumThreadCount) {
        TargetThreadCount = MaximumThreadCount;
    }

    ptrdiff_t ThreadsPerGemm = TargetThreadCount / BatchN;
    if (ThreadsPerGemm < 1) {
        ThreadsPerGemm = 1;
    }

    constexpr size_t StrideM = kQNBitGemmComputeStrideM;

    constexpr size_t StrideNThreadAlign = MLAS_QGEMM_STRIDEN_THREAD_ALIGN;

    size_t nc = N;
    if (ThreadsPerGemm > 1) {
        // more than one thread per GEMM

        const size_t BlockedM = MlasDivRoundup(M, StrideM);
        const size_t max_nc = MlasDivRoundup(N * BlockedM, ThreadsPerGemm);
        if (max_nc < nc) {
            nc = std::min(
                nc, MlasDivRoundup(max_nc, StrideNThreadAlign) * StrideNThreadAlign
            );
        }
    }
    const size_t StrideN = nc;

    const size_t ThreadCountM = MlasDivRoundup(M, StrideM);
    const size_t ThreadCountN = MlasDivRoundup(N, StrideN);
    ThreadsPerGemm = ThreadCountM * ThreadCountN;

    MlasTrySimpleParallel(ThreadPool, ThreadsPerGemm * BatchN, [&](ptrdiff_t tid) {
        const auto gemm_i = tid / ThreadsPerGemm;
        const auto blk_i = tid % ThreadsPerGemm;
        const auto* Data = &DataParams[gemm_i];

        const ptrdiff_t ThreadIdN = blk_i / ThreadCountM;
        const ptrdiff_t ThreadIdM = blk_i % ThreadCountM;

        const size_t RangeStartM = ThreadIdM * StrideM;
        const size_t RangeCountM = std::min(M - RangeStartM, (size_t)StrideM);

        const size_t RangeStartN = ThreadIdN * StrideN;
        const size_t RangeCountN = std::min(N - RangeStartN, (size_t)StrideN);

        void* PerGemmWorkspace =
            reinterpret_cast<std::byte*>(Workspace) + gemm_i * PerGemmWorkspaceStride;
        if (Variant == SQ4BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ4BitGemmKernel_BlkSum_CompInt8 != nullptr) {
            PackedQuantBDataStruct<T, 4> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, false);
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;

            PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
            ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, RangeStartM, RangeCountM, RangeStartN, RangeCountN, BackendKernelSelectorConfig);
        } else if (Variant == SQ8BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ8BitGemmKernel_BlkSum_CompInt8 != nullptr) {
            PackedQuantBDataStruct<T, 8> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, GetMlasPlatform().ArmNeonIsQuantActivationsUnsigned);
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->BlkUnsignedQuantAZeroPointCorrection = packed_quant_b.BlkUnsignedQuantAZeroPointCorrection;

            PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
            ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, RangeStartM, RangeCountM, RangeStartN, RangeCountN, BackendKernelSelectorConfig);
        } else if (Variant == SQ2BitGemmVariant_CompInt8 && GetMlasPlatform().QNBitGemmDispatch->SQ2BitGemmKernel_BlkSum_CompInt8 != nullptr) {
            PackedQuantBDataStruct<T, 2> packed_quant_b(const_cast<void*>(Data->QuantBDataWorkspace), N, BlockCountK, BlkLen, false);
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->PackedQuantBData = packed_quant_b.PackedQuantBData;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBBlkSum = packed_quant_b.QuantBBlkSum;
            const_cast<MLAS_QNBIT_GEMM_DATA_PARAMS<T>*>(Data)->QuantBScale = packed_quant_b.PackedQuantBScale;

            PerGemmQuantAWorkspace per_gemm_quant_a_workspace(PerGemmWorkspace, M, BlockCountK, BlkLen);
            ComputeOperation(BlkLen, K, Data, &per_gemm_quant_a_workspace, RangeStartM, RangeCountM, RangeStartN, RangeCountN, BackendKernelSelectorConfig);
        } else {
            ComputeOperation(BlkLen, K, Data, PerGemmWorkspace, RangeStartM, RangeCountM, RangeStartN, RangeCountN, BackendKernelSelectorConfig);
        }
    });
}

template
void MLASCALL
MlasQNBitGemmBatch(
    const size_t M,
    const size_t N,
    const size_t K,
    const size_t BatchN,
    const size_t BlkBitWidth,
    const size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<float>* DataParams,
    void* Workspace,
    MLAS_THREADPOOL* ThreadPool,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
);

template
void MLASCALL
MlasQNBitGemmBatch(
    const size_t M,
    const size_t N,
    const size_t K,
    const size_t BatchN,
    const size_t BlkBitWidth,
    const size_t BlkLen,
    MLAS_QNBIT_GEMM_COMPUTE_TYPE ComputeType,
    const MLAS_QNBIT_GEMM_DATA_PARAMS<MLAS_FP16>* DataParams,
    void* Workspace,
    MLAS_THREADPOOL* ThreadPool,
    const MLAS_BACKEND_KERNEL_SELECTOR_CONFIG* BackendKernelSelectorConfig
);
