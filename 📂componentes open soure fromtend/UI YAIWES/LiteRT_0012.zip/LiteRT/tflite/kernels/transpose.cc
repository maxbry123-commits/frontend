/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include "tflite/kernels/internal/reference/transpose.h"

#include <stdint.h>

#include <cstddef>
#include <memory>

#include "tflite/core/c/common.h"
#include "tflite/kernels/internal/portable_tensor_utils.h"
#include "tflite/kernels/internal/tensor_ctypes.h"
#include "tflite/kernels/internal/types.h"
#include "tflite/kernels/kernel_util.h"

namespace tflite {
namespace ops {
namespace builtin {
namespace transpose {

struct TransposeContext {
  TransposeContext(TfLiteContext* context, TfLiteNode* node) {
    input = GetInput(context, node, 0);
    perm = GetInput(context, node, 1);
    output = GetOutput(context, node, 0);
  }
  const TfLiteTensor* input;
  const TfLiteTensor* perm;
  TfLiteTensor* output;
};

TfLiteStatus ResizeOutputTensor(TfLiteContext* context,
                                TransposeContext* op_context) {
  int dims = NumDimensions(op_context->input);
  const int* perm_data = GetTensorData<int32_t>(op_context->perm);
  std::vector<int> new_perm_data(dims);

  // Ensure validity of the permutations tensor as a 1D tensor.
  TF_LITE_ENSURE_EQ(context, NumDimensions(op_context->perm), 1);
  TF_LITE_ENSURE_EQ(context, op_context->perm->dims->data[0], dims);
  // `perm` must be a permutation of [0, dims), not merely a set of in-range
  // values: the output shape and the element offsets are both derived from it,
  // and a repeated entry makes them disagree with the input extent.
  // `dims` is bounded by kTransposeMaxDimensions, which Prepare() enforces
  // before this function is reachable, so a 64-bit mask is sufficient and
  // avoids a heap allocation in the kernel.
  static_assert(kTransposeMaxDimensions <= 64,
                "Permutation bitmask assumes at most 64 dimensions.");
  uint64_t seen = 0;
  for (int idx = 0; idx < dims; ++idx) {
    TF_LITE_ENSURE_MSG(context,
                       (perm_data[idx] >= -dims && perm_data[idx] < dims),
                       "Transpose op permutations array is out of bounds.");
    new_perm_data[idx] = perm_data[idx];
    if (new_perm_data[idx] < 0) new_perm_data[idx] += dims;
    const uint64_t bit = uint64_t{1} << new_perm_data[idx];
    TF_LITE_ENSURE_MSG(
        context, (seen & bit) == 0,
        "Transpose op permutations array must not contain duplicate values.");
    seen |= bit;
  }

  // Determine size of output tensor.
  TfLiteIntArray* input_size = op_context->input->dims;
  TfLiteIntArray* output_size = TfLiteIntArrayCopy(input_size);
  for (int idx = 0; idx < dims; ++idx) {
    output_size->data[idx] = input_size->data[new_perm_data[idx]];
  }

  return context->ResizeTensor(context, op_context->output, output_size);
}

TfLiteStatus Prepare(TfLiteContext* context, TfLiteNode* node) {
  TF_LITE_ENSURE_EQ(context, NumInputs(node), 2);
  TF_LITE_ENSURE_EQ(context, NumOutputs(node), 1);

  TransposeContext op_context(context, node);

  // Ensure validity of input tensor.
  TF_LITE_ENSURE_MSG(context,
                     NumDimensions(op_context.input) <= kTransposeMaxDimensions,
                     "Transpose op only supports 1D-8D input arrays.");
  TF_LITE_ENSURE_TYPES_EQ(context, op_context.input->type,
                          op_context.output->type);

  if (!IsConstantOrPersistentTensor(op_context.perm)) {
    SetTensorToDynamic(op_context.output);
    return kTfLiteOk;
  }
  return ResizeOutputTensor(context, &op_context);
}

TfLiteStatus Eval(TfLiteContext* context, TfLiteNode* node) {
  TransposeContext op_context(context, node);

  // Resize the output tensor if the output tensor is dynamic.
  if (IsDynamicTensor(op_context.output)) {
    TF_LITE_ENSURE_OK(context, ResizeOutputTensor(context, &op_context));
  }

  const int* perm_data = GetTensorData<int32_t>(op_context.perm);
  const int size = op_context.perm->dims->data[0];
  TransposeParams params;
  params.perm_count = size;
  for (int i = 0; i < size; ++i) {
    int perm = perm_data[i];
    if (perm < 0) perm += size;
    params.perm[i] = perm;
  }
#define TF_LITE_TRANSPOSE(type, scalar)                     \
  type::Transpose(params, GetTensorShape(op_context.input), \
                  GetTensorData<scalar>(op_context.input),  \
                  GetTensorShape(op_context.output),        \
                  GetTensorData<scalar>(op_context.output))

  // Transpose kernel only does rearranging values not numeric evaluations on
  // each cell. It's safe to implement per size of scalar type and this trick
  // keeps the total code size in a reasonable range.
  switch (TfLiteTypeGetSizeBits(op_context.input->type)) {
    case 4: {
      const size_t bytes_unpacked = op_context.input->bytes * 2;
      auto unpacked_input_data = std::make_unique<int8_t[]>(bytes_unpacked);
      auto unpacked_output_data = std::make_unique<int8_t[]>(bytes_unpacked);

      tflite::tensor_utils::UnpackPackedIntToInt8(
          GetTensorData<int8_t>(op_context.input),
          GetTensorShape(op_context.input).FlatSize(),
          /*bit_width=*/4, unpacked_input_data.get());
      reference_ops::Transpose(
          params, GetTensorShape(op_context.input), unpacked_input_data.get(),
          GetTensorShape(op_context.output), unpacked_output_data.get());
      // Pack the output back to int4.
      tflite::tensor_utils::PackInt8IntoDenseInt(
          unpacked_output_data.get(),
          GetTensorShape(op_context.input).FlatSize(),
          /*bit_width=*/4, GetTensorData<int8_t>(op_context.output));
      break;
    }
    case 8:
      TF_LITE_TRANSPOSE(reference_ops, int8_t);
      break;
    case 16:
      TF_LITE_TRANSPOSE(reference_ops, int16_t);
      break;
    case 32:
      TF_LITE_TRANSPOSE(reference_ops, int32_t);
      break;
    case 64:
      TF_LITE_TRANSPOSE(reference_ops, int64_t);
      break;
    default:
      TF_LITE_KERNEL_LOG(context,
                         "Type %s is currently not supported by Transpose.",
                         TfLiteTypeGetName(op_context.input->type));
      return kTfLiteError;
  }
#undef TF_LITE_TRANSPOSE

  return kTfLiteOk;
}

}  // namespace transpose

TfLiteRegistration* Register_TRANSPOSE_REF() {
  static TfLiteRegistration r = {nullptr, nullptr, transpose::Prepare,
                                 transpose::Eval};
  return &r;
}

TfLiteRegistration* Register_TRANSPOSE() { return Register_TRANSPOSE_REF(); }

}  // namespace builtin
}  // namespace ops
}  // namespace tflite
