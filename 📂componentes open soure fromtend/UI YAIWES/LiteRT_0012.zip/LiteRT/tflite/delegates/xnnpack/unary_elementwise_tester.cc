/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tflite/delegates/xnnpack/unary_elementwise_tester.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <limits>
#include <memory>
#include <numeric>
#include <random>
#include <vector>

#include <gtest/gtest.h>
#include "flatbuffers/buffer.h"  // from @flatbuffers
#include "flatbuffers/flatbuffer_builder.h"  // from @flatbuffers
#include "flatbuffers/string.h"  // from @flatbuffers
#include "tflite/core/interpreter_builder.h"
#include "tflite/core/kernels/register.h"
#include "tflite/delegates/xnnpack/test_util.h"
#include "tflite/interpreter.h"
#include "tflite/profiling/buffered_profiler.h"
#include "tflite/schema/schema_conversion_utils.h"
#include "tflite/schema/schema_generated.h"
#include "tflite/version.h"

namespace tflite {
namespace xnnpack {

void UnaryElementwiseTester::Test(tflite::BuiltinOperator unary_op,
                                  TfLiteDelegate* delegate) const {
  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  std::uniform_real_distribution<float> input_distribution(-15.0f, 15.0f);
  switch (unary_op) {
    case BuiltinOperator_SQRT:
      input_distribution = std::uniform_real_distribution<float>(0.0f, 10.0f);
      break;
    case BuiltinOperator_RSQRT:
      input_distribution = std::uniform_real_distribution<float>(
          std::numeric_limits<float>::epsilon(), 10.0f);
      break;
    default:
      break;
  }
  auto input_rng = std::bind(input_distribution, std::ref(rng));

  std::vector<char> buffer = CreateTfLiteModel(unary_op);
  const Model* model = GetModel(buffer.data());

  std::unique_ptr<Interpreter> delegate_interpreter;
  ASSERT_EQ(
      InterpreterBuilder(
          model,
          ::tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates())(
          &delegate_interpreter),
      kTfLiteOk);
  std::unique_ptr<Interpreter> default_interpreter;
  ASSERT_EQ(
      InterpreterBuilder(
          model,
          ::tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates())(
          &default_interpreter),
      kTfLiteOk);

  ASSERT_TRUE(delegate_interpreter);
  ASSERT_TRUE(default_interpreter);

  ASSERT_EQ(delegate_interpreter->inputs().size(), 1);
  ASSERT_EQ(default_interpreter->inputs().size(), 1);

  ASSERT_EQ(delegate_interpreter->outputs().size(), 1);
  ASSERT_EQ(default_interpreter->outputs().size(), 1);

  ASSERT_EQ(delegate_interpreter->AllocateTensors(), kTfLiteOk);
  ASSERT_EQ(default_interpreter->AllocateTensors(), kTfLiteOk);

  std::unique_ptr<::tflite::profiling::BufferedProfiler> profiler;
  if (yield_fp16_precision_) {
    profiler = std::make_unique<::tflite::profiling::BufferedProfiler>(1024);
    delegate_interpreter->SetProfiler(profiler.get());
  }

  ASSERT_EQ(delegate_interpreter->ModifyGraphWithDelegate(delegate), kTfLiteOk);

  float* default_input_data = default_interpreter->typed_input_tensor<float>(0);
  std::generate_n(default_input_data, Size(), std::ref(input_rng));

  float* delegate_input_data =
      delegate_interpreter->typed_input_tensor<float>(0);
  std::copy_n(default_input_data, Size(), delegate_input_data);

  if (profiler) {
    profiler->StartProfiling();
  }

  ASSERT_EQ(default_interpreter->Invoke(), kTfLiteOk);
  ASSERT_EQ(delegate_interpreter->Invoke(), kTfLiteOk);

  if (profiler) {
    profiler->StopProfiling();
    EXPECT_TRUE(HasConvertNode(profiler.get()))
        << "Expected Convert nodes in FP16 rewrite";
  }

  float* default_output_data =
      default_interpreter->typed_output_tensor<float>(0);
  float* delegate_output_data =
      delegate_interpreter->typed_output_tensor<float>(0);

  if (yield_fp16_precision_) {
    const float tolerance_scale = 1.0f;
    for (size_t i = 0; i < Size(); i++) {
      ASSERT_NEAR(default_output_data[i], delegate_output_data[i],
                  std::max(AbsoluteTolerance() * tolerance_scale,
                           std::max(std::abs(default_output_data[i]),
                                    std::abs(delegate_output_data[i])) *
                               RelativeTolerance() * tolerance_scale));
    }
  } else {
    switch (unary_op) {
      case BuiltinOperator_ABS:
      case BuiltinOperator_CEIL:
      case BuiltinOperator_FLOOR:
      case BuiltinOperator_NEG:
      case BuiltinOperator_RELU:
      case BuiltinOperator_RELU_N1_TO_1:
      case BuiltinOperator_RELU6:
      case BuiltinOperator_ROUND:
      case BuiltinOperator_SQUARE:
        for (size_t i = 0; i < Size(); i++) {
          ASSERT_EQ(default_output_data[i], delegate_output_data[i]);
        }
        break;
      default:
        const float tolerance_scale = std::numeric_limits<float>::epsilon();
        for (size_t i = 0; i < Size(); i++) {
          ASSERT_NEAR(default_output_data[i], delegate_output_data[i],
                      std::max(AbsoluteTolerance() * tolerance_scale,
                               std::max(std::abs(default_output_data[i]),
                                        std::abs(delegate_output_data[i])) *
                                   RelativeTolerance() * tolerance_scale));
        }
        break;
    }
  }
}

std::vector<char> UnaryElementwiseTester::CreateTfLiteModel(
    tflite::BuiltinOperator unary_op) const {
  flatbuffers::FlatBufferBuilder builder;
  flatbuffers::Offset<OperatorCode> operator_code =
      CreateOperatorCode(builder, unary_op);

  const std::array<flatbuffers::Offset<Buffer>, 1> buffers{{
      CreateBuffer(builder, builder.CreateVector({})),
  }};

  const std::array<flatbuffers::Offset<Tensor>, 2> tensors{{
      CreateTensor(
          builder,
          builder.CreateVector<int32_t>(Shape().data(), Shape().size()),
          TensorType_FLOAT32),
      CreateTensor(
          builder,
          builder.CreateVector<int32_t>(Shape().data(), Shape().size()),
          TensorType_FLOAT32),
  }};

  const std::array<int32_t, 1> op_inputs{{0}};
  const std::array<int32_t, 1> op_outputs{{1}};
  flatbuffers::Offset<Operator> op = CreateOperator(
      builder, /*opcode_index=*/0,
      builder.CreateVector<int32_t>(op_inputs.data(), op_inputs.size()),
      builder.CreateVector<int32_t>(op_outputs.data(), op_outputs.size()));

  const std::array<int32_t, 1> subgraph_inputs{{0}};
  const std::array<int32_t, 1> subgraph_outputs{{1}};
  flatbuffers::Offset<SubGraph> subgraph = CreateSubGraph(
      builder, builder.CreateVector(tensors.data(), tensors.size()),
      builder.CreateVector<int32_t>(subgraph_inputs.data(),
                                    subgraph_inputs.size()),
      builder.CreateVector<int32_t>(subgraph_outputs.data(),
                                    subgraph_outputs.size()),
      builder.CreateVector(&op, 1));

  flatbuffers::Offset<flatbuffers::String> description =
      builder.CreateString("Unary operator model");

  flatbuffers::Offset<Model> model_buffer = CreateModel(
      builder, TFLITE_SCHEMA_VERSION, builder.CreateVector(&operator_code, 1),
      builder.CreateVector(&subgraph, 1), description,
      builder.CreateVector(buffers.data(), buffers.size()));

  builder.Finish(model_buffer);

  return std::vector<char>(builder.GetBufferPointer(),
                           builder.GetBufferPointer() + builder.GetSize());
}

int32_t UnaryElementwiseTester::ComputeSize(const std::vector<int32_t>& shape) {
  return std::accumulate(shape.cbegin(), shape.cend(), 1,
                         std::multiplies<int32_t>());
}

}  // namespace xnnpack
}  // namespace tflite
