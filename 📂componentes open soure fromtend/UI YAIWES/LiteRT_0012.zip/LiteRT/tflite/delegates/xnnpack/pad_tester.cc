/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tflite/delegates/xnnpack/pad_tester.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <numeric>
#include <random>
#include <vector>

#include <gtest/gtest.h>
#include "fp16.h"  // from @FP16
#include "flatbuffers/buffer.h"  // from @flatbuffers
#include "flatbuffers/flatbuffer_builder.h"  // from @flatbuffers
#include "flatbuffers/string.h"  // from @flatbuffers
#include "tflite/converter/schema/schema_conversion_utils.h"
#include "tflite/core/interpreter_builder.h"
#include "tflite/core/kernels/register.h"
#include "tflite/interpreter.h"
#include "tflite/schema/schema_generated.h"
#include "tflite/version.h"

namespace tflite {
namespace xnnpack {

std::vector<int32_t> PadTester::OutputShape() const {
  std::vector<int32_t> output_shape;
  output_shape.reserve(InputShape().size());
  for (size_t i = 0; i < InputShape().size(); i++) {
    int32_t output_dim = InputShape()[i];
    if (i < InputPrePaddings().size()) {
      output_dim += InputPrePaddings()[i];
    }
    if (i < InputPostPaddings().size()) {
      output_dim += InputPostPaddings()[i];
    }
    output_shape.push_back(output_dim);
  }
  return output_shape;
}

void PadTester::Test(TfLiteDelegate* delegate) const {
  ASSERT_EQ(InputPrePaddings().size(), InputPostPaddings().size());
  ASSERT_LE(InputPrePaddings().size(), InputShape().size());

  std::random_device random_device;
  auto rng = std::mt19937(random_device());
  auto input_rng =
      std::bind(std::uniform_real_distribution<float>(), std::ref(rng));

  std::vector<char> buffer = CreateTfLiteModel();
  const Model* model = GetModel(buffer.data());

  std::unique_ptr<Interpreter> delegate_interpreter;
  ASSERT_EQ(
      InterpreterBuilder(
          model,
          ::tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates())(
          &delegate_interpreter),
      kTfLiteOk);
  std::unique_ptr<Interpreter> default_interpreter;
  ASSERT_EQ(
      InterpreterBuilder(
          model,
          ::tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates())(
          &default_interpreter),
      kTfLiteOk);

  ASSERT_TRUE(delegate_interpreter);
  ASSERT_TRUE(default_interpreter);

  ASSERT_EQ(delegate_interpreter->inputs().size(), 1);
  ASSERT_EQ(default_interpreter->inputs().size(), 1);

  ASSERT_EQ(delegate_interpreter->outputs().size(), 1);
  ASSERT_EQ(default_interpreter->outputs().size(), 1);

  ASSERT_EQ(delegate_interpreter->AllocateTensors(), kTfLiteOk);
  ASSERT_EQ(default_interpreter->AllocateTensors(), kTfLiteOk);

  ASSERT_EQ(delegate_interpreter->ModifyGraphWithDelegate(delegate), kTfLiteOk);

  if (FP16()) {
    TfLiteFloat16* default_input_data =
        default_interpreter->typed_input_tensor<TfLiteFloat16>(0);
    std::generate_n(
        default_input_data, ComputeSize(InputShape()), [&]() -> TfLiteFloat16 {
          return TfLiteFloat16{fp16_ieee_from_fp32_value(input_rng())};
        });

    TfLiteFloat16* delegate_input_data =
        delegate_interpreter->typed_input_tensor<TfLiteFloat16>(0);
    std::copy_n(default_input_data, ComputeSize(InputShape()),
                delegate_input_data);

    ASSERT_EQ(default_interpreter->Invoke(), kTfLiteOk);
    ASSERT_EQ(delegate_interpreter->Invoke(), kTfLiteOk);

    TfLiteFloat16* default_output_data =
        default_interpreter->typed_output_tensor<TfLiteFloat16>(0);
    TfLiteFloat16* delegate_output_data =
        delegate_interpreter->typed_output_tensor<TfLiteFloat16>(0);

    for (size_t i = 0; i < ComputeSize(OutputShape()); i++) {
      ASSERT_EQ(default_output_data[i].data, delegate_output_data[i].data);
    }
  } else {
    float* default_input_data =
        default_interpreter->typed_input_tensor<float>(0);
    std::generate_n(default_input_data, ComputeSize(InputShape()),
                    std::ref(input_rng));

    float* delegate_input_data =
        delegate_interpreter->typed_input_tensor<float>(0);
    std::copy_n(default_input_data, ComputeSize(InputShape()),
                delegate_input_data);

    ASSERT_EQ(default_interpreter->Invoke(), kTfLiteOk);
    ASSERT_EQ(delegate_interpreter->Invoke(), kTfLiteOk);

    float* default_output_data =
        default_interpreter->typed_output_tensor<float>(0);
    float* delegate_output_data =
        delegate_interpreter->typed_output_tensor<float>(0);

    for (size_t i = 0; i < ComputeSize(OutputShape()); i++) {
      ASSERT_EQ(default_output_data[i], delegate_output_data[i]);
    }
  }
}

std::vector<char> PadTester::CreateTfLiteModel() const {
  flatbuffers::FlatBufferBuilder builder;
  flatbuffers::Offset<OperatorCode> operator_code =
      CreateOperatorCode(builder, BuiltinOperator_PAD);

  std::vector<int32_t> paddings(InputPrePaddings().size() +
                                InputPostPaddings().size());
  for (size_t i = 0; i < InputPrePaddings().size(); i++) {
    paddings[i * 2] = InputPrePaddings()[i];
    paddings[i * 2 + 1] = InputPostPaddings()[i];
  }
  const std::array<flatbuffers::Offset<Buffer>, 2> buffers{{
      CreateBuffer(builder, builder.CreateVector({})),
      CreateBuffer(builder,
                   builder.CreateVector(
                       reinterpret_cast<const uint8_t*>(paddings.data()),
                       sizeof(int32_t) * paddings.size())),
  }};

  const std::vector<int32_t> output_shape = OutputShape();
  const std::array<int32_t, 2> paddings_shape{
      {static_cast<int32_t>(InputPrePaddings().size()), 2}};
  const std::array<flatbuffers::Offset<Tensor>, 3> tensors{{
      CreateTensor(builder,
                   builder.CreateVector<int32_t>(InputShape().data(),
                                                 InputShape().size()),
                   FP16() ? TensorType_FLOAT16 : TensorType_FLOAT32),
      CreateTensor(builder,
                   builder.CreateVector<int32_t>(paddings_shape.data(),
                                                 paddings_shape.size()),
                   TensorType_INT32, /*buffer=*/1),
      CreateTensor(builder,
                   builder.CreateVector<int32_t>(output_shape.data(),
                                                 output_shape.size()),
                   FP16() ? TensorType_FLOAT16 : TensorType_FLOAT32),
  }};

  const std::array<int32_t, 2> op_inputs{{0, 1}};
  const std::array<int32_t, 1> op_outputs{{2}};
  flatbuffers::Offset<Operator> op = CreateOperator(
      builder, /*opcode_index=*/0,
      builder.CreateVector<int32_t>(op_inputs.data(), op_inputs.size()),
      builder.CreateVector<int32_t>(op_outputs.data(), op_outputs.size()));

  const std::array<int32_t, 1> subgraph_inputs{{0}};
  const std::array<int32_t, 1> subgraph_outputs{{2}};
  flatbuffers::Offset<SubGraph> subgraph = CreateSubGraph(
      builder, builder.CreateVector(tensors.data(), tensors.size()),
      builder.CreateVector<int32_t>(subgraph_inputs.data(),
                                    subgraph_inputs.size()),
      builder.CreateVector<int32_t>(subgraph_outputs.data(),
                                    subgraph_outputs.size()),
      builder.CreateVector(&op, 1));

  flatbuffers::Offset<flatbuffers::String> description =
      builder.CreateString("Pad model");

  flatbuffers::Offset<Model> model_buffer = CreateModel(
      builder, TFLITE_SCHEMA_VERSION, builder.CreateVector(&operator_code, 1),
      builder.CreateVector(&subgraph, 1), description,
      builder.CreateVector(buffers.data(), buffers.size()));

  builder.Finish(model_buffer);

  return std::vector<char>(builder.GetBufferPointer(),
                           builder.GetBufferPointer() + builder.GetSize());
}

int32_t PadTester::ComputeSize(const std::vector<int32_t>& shape) {
  return std::accumulate(shape.cbegin(), shape.cend(), 1,
                         std::multiplies<int32_t>());
}

}  // namespace xnnpack
}  // namespace tflite
