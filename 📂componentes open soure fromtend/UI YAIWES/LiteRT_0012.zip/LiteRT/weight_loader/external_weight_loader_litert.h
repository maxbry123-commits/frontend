// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_EXTERNAL_WEIGHT_EXTERNAL_WEIGHT_LOADER_LITERT_H_
#define THIRD_PARTY_ODML_LITERT_EXTERNAL_WEIGHT_EXTERNAL_WEIGHT_LOADER_LITERT_H_

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>

#include "absl/container/flat_hash_map.h"  // from @com_google_absl
#include "absl/status/status.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#ifdef __EMSCRIPTEN__
// copybara:comment_begin
#include <webgpu/webgpu_cpp.h>
// copybara:comment_end
// copybara:uncomment_begin
// #include "ml_drift/webgpu/webgpu_headers.h"  // from @ml_drift
// copybara:uncomment_end
#else
namespace wgpu {
class Buffer;
}  // namespace wgpu
#endif  // __EMSCRIPTEN__
#include "litert/c/internal/litert_runtime_context.h"
#include "litert/c/litert_common.h"
#include "litert/cc/internal/scoped_weight_source.h"
#include "tflite/schema/schema_generated.h"

class LiteRtEnvironmentT;

// This header defines the interface for loading external weights in LiteRT.
// External weights are model parameters (e.g., weights of a convolutional
// layer) that are not stored in the model flatbuffer itself, but in external
// files. This is useful for large models where the weights can be several
// gigabytes in size.
//
// The main components of this interface are:
// - `WeightLoader`: An abstract class that defines the interface for loading
//   external weights.
// - `WeightInfo`: A struct that contains information about a single external
//   weight tensor.
// - `WeightAccess`: A struct that provides access to the data of an external
//   weight tensor.
// - `CreateLiteRtWeightLoader`: A factory function that creates a
// `WeightLoader`
//   instance from a TFLite model flatbuffer.
//
// The typical usage of this interface is as follows:
// 1. Create a `WeightLoader` instance using `CreateLiteRtWeightLoader`.
// 2. Get the list of external weight tensors using `GetWeightInfo`.
// 3. For each external weight tensor, prepare access to its data using
//    `PrepareAccess`.
// 4. Get access to the data of an external weight tensor using
//    `GetExternalWeightByBuffer`.
// 5. Set the external weight tensor in the LiteRT model using
//    `SetExternalWeightByBuffer`.

// Weight loader contains functionality for loading external weights in LiteRT.
namespace weight_loader {

struct LiteRtTensorBufferDeleter {
  LiteRtRuntimeContext* runtime_context = nullptr;
  void operator()(LiteRtTensorBufferT* buffer) const {
    if (buffer && runtime_context) {
      runtime_context->destroy_tensor_buffer(buffer);
    }
  }
};

using LiteRtTensorBufferPtr =
    std::unique_ptr<LiteRtTensorBufferT, LiteRtTensorBufferDeleter>;

struct WeightInfo {
  // The ID of the external buffer that contains the tensor data.
  uint32_t external_buffer_id;
  // The packing format of the tensor data.
  absl::string_view packing;
};

// A request to access the data of an external weight tensor.
struct WeightAccessRequest {
  // Whether to access the data on the CPU.
  bool cpu = true;
  // Whether to access the data on an OpenCL device.
  bool opencl = false;
  // Whether to access the data on a Metal device.
  bool metal = false;
};

struct WeightAccess;

// An abstract class that defines the interface for loading external weights.
class WeightLoader {
 public:
  virtual ~WeightLoader() = default;

  // Returns a list of all external weight tensors in the model.
  virtual absl::Span<const WeightInfo> GetWeightInfo() const = 0;

  // Prepares access to the data of the external weight tensors. This function
  // should be called before `GetExternalWeightByBuffer` or
  // `SetExternalWeightByBuffer`. The `request` parameter specifies how the
  // data should be accessed (e.g., on the CPU or on an OpenCL device). The
  // `env` parameter is the LiteRT environment.
  virtual absl::Status PrepareAccess(const WeightAccessRequest& request,
                                     LiteRtEnvironmentT* env) = 0;

  // Prepares access to one external weight tensor. This is used by delegates
  // that only need a CPU mapping while a specific tensor is being uploaded.
  virtual absl::Status PrepareAccessForBuffer(
      uint32_t external_buffer_id, const WeightAccessRequest& request,
      LiteRtEnvironmentT* env) = 0;

  // Finds the `WeightInfo` for the external weight tensor with the given
  // buffer ID. Returns `nullptr` if no such tensor exists.
  virtual const WeightInfo* FindWeightInfoByBuffer(
      uint32_t external_buffer_id) const = 0;

  // Returns the first external buffer ID that references the same backing
  // weight slice. Unknown IDs are returned unchanged.
  virtual uint32_t GetCanonicalExternalBufferId(
      uint32_t external_buffer_id) const = 0;

  // Sets the external weight tensor with the given buffer ID. The `access`
  // parameter provides access to the tensor data.
  virtual absl::Status SetExternalWeightByBuffer(uint32_t external_buffer_id,
                                                 WeightAccess access) = 0;

  // Gets access to the data of the external weight tensor with the given
  // buffer ID. Returns `nullptr` if no such tensor exists.
  virtual const WeightAccess* GetExternalWeightByBuffer(
      uint32_t external_buffer_id) const = 0;

  virtual absl::Status UploadWeightsOnWeb(
      const absl::flat_hash_map<int, wgpu::Buffer>& tfl_id_to_wgpu_buffer) {
    return absl::UnimplementedError(
        "UploadWeightsOnWeb is not implemented by default.");
  }

  // Marks the host mapping for the external weight tensor as discardable.
  virtual absl::Status DiscardExternalWeightByBuffer(
      uint32_t external_buffer_id) = 0;

  // Releases the prepared host/device access for one external weight tensor.
  // Callers must only use this after all consumers have finished reading the
  // data returned by GetExternalWeightByBuffer().
  virtual absl::Status ReleaseExternalWeightByBuffer(
      uint32_t external_buffer_id) = 0;
};

// Provides access to the data of an external weight tensor.
struct WeightAccess {
  WeightAccess();
  WeightAccess(const WeightAccess&) = delete;
  WeightAccess& operator=(const WeightAccess&) = delete;
  WeightAccess(WeightAccess&& other) noexcept;
  WeightAccess& operator=(WeightAccess&& other) noexcept;
  ~WeightAccess();

  // Resets the `WeightAccess` to its initial state.
  void Reset();

  // Sets the host buffer for the tensor data.
  void SetHostBuffer(LiteRtTensorBufferPtr buffer);
  // Sets the device buffer for the tensor data.
  void SetDeviceBuffer(LiteRtTensorBufferPtr buffer);

  // Returns the host buffer for the tensor data.
  LiteRtTensorBuffer GetHostBuffer() const { return host_tensor_buffer.get(); }
  // Returns the device buffer for the tensor data.
  LiteRtTensorBuffer GetDeviceBuffer() const {
    return device_tensor_buffer.get();
  }

 private:
  // TODO(b/456581477): Use a single tensor buffer for both host and device.
  LiteRtTensorBufferPtr host_tensor_buffer;
  LiteRtTensorBufferPtr device_tensor_buffer;
};

// Map from group ID (string) to weight data in host memory.
using WeightInMemoryMap =
    absl::flat_hash_map<std::string, absl::Span<const std::byte>>;

// Creates a `WeightLoader` instance from a TFLite model flatbuffer.
// - flatbuffer: the TFLite model flatbuffer.
// - model_directory: the directory where the external weight files are located.
//     If not specified, treat the group path as the absolute path.
// - scoped_weight_source: a `ScopedWeightSource` instance that owns the
//     external weight files.
// - weight_in_memory_map: a map from group ID to weight data in host memory.
//     If specified, the `WeightLoader` will use the weight data in the map
//     in addition to the external weight files.
std::unique_ptr<WeightLoader> CreateLiteRtWeightLoader(
    LiteRtRuntimeContext* runtime_context, const tflite::Model* flatbuffer,
    std::optional<std::string> model_directory = std::nullopt,
    std::unique_ptr<litert::ScopedWeightSource> scoped_weight_source = nullptr,
    const WeightInMemoryMap* weight_in_memory_map = nullptr);

}  // namespace weight_loader

#endif  // THIRD_PARTY_ODML_LITERT_EXTERNAL_WEIGHT_EXTERNAL_WEIGHT_LOADER_LITERT_H_
