/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include "tflite/python/interpreter_wrapper/interpreter_wrapper.h"

#include <stdarg.h>

#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "absl/memory/memory.h"
#include "absl/strings/match.h"
#include "absl/strings/str_format.h"
#include "tflite/core/api/op_resolver.h"
#include "tflite/core/c/common.h"
#include "tflite/core/interpreter.h"
#include "tflite/core/kernels/register.h"
#include "tflite/core/model.h"
#include "tflite/delegates/xnnpack/xnnpack_delegate.h"
#include "tflite/kernels/internal/compatibility.h"
#include "tflite/kernels/register_ref.h"
#include "tflite/mutable_op_resolver.h"
#include "tflite/python/interpreter_wrapper/numpy.h"
#include "tflite/python/interpreter_wrapper/python_error_reporter.h"
#include "tflite/python/interpreter_wrapper/python_utils.h"
#include "tflite/shared_library.h"
#include "tflite/string_util.h"
#include "tflite/util.h"

#define TFLITE_PY_CHECK(x)               \
  if ((x) != kTfLiteOk) {                \
    return error_reporter_->exception(); \
  }

#define TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(i, subgraph_index)             \
  if (i >= interpreter_->subgraph(subgraph_index)->tensors_size() || i < 0) { \
    PyErr_Format(PyExc_ValueError,                                            \
                 "Invalid tensor index %d exceeds max tensor index %lu", i,   \
                 interpreter_->subgraph(subgraph_index)->tensors_size());     \
    return nullptr;                                                           \
  }

#define TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(i)                                   \
  if (i >= interpreter_->subgraphs_size() || i < 0) {                        \
    PyErr_Format(PyExc_ValueError,                                           \
                 "Invalid subgraph index %d exceeds max subgraph index %lu", \
                 i, interpreter_->subgraphs_size());                         \
    return nullptr;                                                          \
  }

#define TFLITE_PY_NODES_BOUNDS_CHECK(i)                   \
  if (i >= interpreter_->nodes_size() || i < 0) {         \
    PyErr_Format(PyExc_ValueError, "Invalid node index"); \
    return nullptr;                                       \
  }

#define TFLITE_PY_ENSURE_VALID_INTERPRETER()                               \
  if (!interpreter_) {                                                     \
    PyErr_SetString(PyExc_ValueError, "Interpreter was not initialized."); \
    return nullptr;                                                        \
  }

namespace tflite {
namespace interpreter_wrapper {

namespace {

using python_utils::PyDecrefDeleter;

std::unique_ptr<Interpreter> CreateInterpreter(
    const InterpreterWrapper::Model* model,
    const tflite::MutableOpResolver& resolver, bool preserve_all_tensors,
    bool disable_delegate_clustering, int num_threads,
    bool default_delegate_latest_features,
    bool compress_quantization_zero_points, bool disable_delegate_node_fusion,
    bool force_delegate_node_profiling) {
  if (!model) {
    return nullptr;
  }

  ::tflite::python::ImportNumpy();

  TfLiteDelegate* xnnpack_delegate = nullptr;
  if (default_delegate_latest_features) {
    auto opts = TfLiteXNNPackDelegateOptionsDefault();
    opts.flags |= TFLITE_XNNPACK_DELEGATE_FLAG_ENABLE_LATEST_OPERATORS;
    opts.flags |= TFLITE_XNNPACK_DELEGATE_FLAG_ENABLE_SUBGRAPH_RESHAPING;
    opts.num_threads = num_threads;
    xnnpack_delegate = TfLiteXNNPackDelegateCreate(&opts);
  }
  std::unique_ptr<Interpreter> interpreter;
  InterpreterOptions options;
  options.SetPreserveAllTensors(preserve_all_tensors);
  options.SetDisableDelegateClustering(disable_delegate_clustering);
  options.SetCompressQuantizationZeroPoints(compress_quantization_zero_points);
  options.SetDisableDelegateNodeFusion(disable_delegate_node_fusion);
  options.SetForceDelegateNodeProfiling(force_delegate_node_profiling);
  InterpreterBuilder builder(*model, resolver, &options);
  if (default_delegate_latest_features) {
    builder.AddDelegate(xnnpack_delegate);
  }
  builder.SetNumThreads(num_threads);
  if (builder(&interpreter) != kTfLiteOk) {
    return nullptr;
  }
  return interpreter;
}

PyObject* PyArrayFromFloatVector(const float* data, npy_intp size) {
  if (size == 0) {
    return PyArray_SimpleNew(1, &size,
                             NPY_FLOAT32);  // NOLINT(misc-include-cleaner)
  }
  void* pydata = malloc(size * sizeof(float));
  if (pydata == nullptr) {
    PyErr_NoMemory();
    return nullptr;
  }
  if (data != nullptr) {
    memcpy(pydata, data, size * sizeof(float));
  } else {
    memset(pydata, 0, size * sizeof(float));
  }
  PyObject* obj = PyArray_SimpleNewFromData(
      1, &size, NPY_FLOAT32, pydata);  // NOLINT(misc-include-cleaner)
  if (obj == nullptr) {
    free(pydata);
    return nullptr;
  }
  PyArray_ENABLEFLAGS(reinterpret_cast<PyArrayObject*>(obj), NPY_ARRAY_OWNDATA);
  return obj;
}

PyObject* PyArrayFromFloat16Vector(const uint16_t* data, npy_intp size) {
  if (size == 0) {
    return PyArray_SimpleNew(1, &size,
                             NPY_FLOAT16);  // NOLINT(misc-include-cleaner)
  }
  void* pydata = malloc(size * sizeof(uint16_t));
  if (pydata == nullptr) {
    PyErr_NoMemory();
    return nullptr;
  }
  if (data != nullptr) {
    memcpy(pydata, data, size * sizeof(uint16_t));
  } else {
    memset(pydata, 0, size * sizeof(uint16_t));
  }
  PyObject* obj = PyArray_SimpleNewFromData(
      1, &size, NPY_FLOAT16, pydata);  // NOLINT(misc-include-cleaner)
  if (obj == nullptr) {
    free(pydata);
    return nullptr;
  }
  PyArray_ENABLEFLAGS(reinterpret_cast<PyArrayObject*>(obj), NPY_ARRAY_OWNDATA);
  return obj;
}

PyObject* PyArrayFromIntVector(const int* data, npy_intp size) {
  if (size == 0) {
    return PyArray_SimpleNew(1, &size,
                             NPY_INT32);  // NOLINT(misc-include-cleaner)
  }
  void* pydata = malloc(size * sizeof(int));
  if (pydata == nullptr) {
    PyErr_NoMemory();
    return nullptr;
  }
  if (data != nullptr) {
    memcpy(pydata, data, size * sizeof(int));
  } else {
    memset(pydata, 0, size * sizeof(int));
  }
  PyObject* obj = PyArray_SimpleNewFromData(
      1, &size, NPY_INT32, pydata);  // NOLINT(misc-include-cleaner)
  if (obj == nullptr) {
    free(pydata);
    return nullptr;
  }
  PyArray_ENABLEFLAGS(reinterpret_cast<PyArrayObject*>(obj), NPY_ARRAY_OWNDATA);
  return obj;
}

PyObject* PyTupleFromQuantizationParam(const TfLiteQuantizationParams& param) {
  PyObject* result = PyTuple_New(2);
  PyTuple_SET_ITEM(result, 0, PyFloat_FromDouble(param.scale));
  PyTuple_SET_ITEM(result, 1, PyLong_FromLong(param.zero_point));
  return result;
}

PyObject* PyDictFromSparsityParam(const TfLiteSparsity& param) {
  PyObject* result = PyDict_New();
  if (result == nullptr) return nullptr;

  PyObject* traversal_order = PyArrayFromIntVector(param.traversal_order->data,
                                                   param.traversal_order->size);
  if (traversal_order == nullptr) {
    Py_DECREF(result);
    return nullptr;
  }
  if (PyDict_SetItemString(result, "traversal_order", traversal_order) < 0) {
    Py_DECREF(traversal_order);
    Py_DECREF(result);
    return nullptr;
  }
  Py_DECREF(traversal_order);

  if (param.block_map != nullptr) {
    PyObject* block_map =
        PyArrayFromIntVector(param.block_map->data, param.block_map->size);
    if (block_map == nullptr) {
      Py_DECREF(result);
      return nullptr;
    }
    if (PyDict_SetItemString(result, "block_map", block_map) < 0) {
      Py_DECREF(block_map);
      Py_DECREF(result);
      return nullptr;
    }
    Py_DECREF(block_map);
  }

  PyObject* dim_metadata = PyList_New(param.dim_metadata_size);
  if (dim_metadata == nullptr) {
    Py_DECREF(result);
    return nullptr;
  }

  for (int i = 0; i < param.dim_metadata_size; i++) {
    PyObject* dim_metadata_i = PyDict_New();
    if (dim_metadata_i == nullptr) {
      Py_DECREF(dim_metadata);
      Py_DECREF(result);
      return nullptr;
    }

    if (param.dim_metadata[i].format == kTfLiteDimDense) {
      PyObject* format = PyLong_FromSize_t(0);
      PyObject* dense_size =
          PyLong_FromSize_t(param.dim_metadata[i].dense_size);
      if (format == nullptr || dense_size == nullptr ||
          PyDict_SetItemString(dim_metadata_i, "format", format) < 0 ||
          PyDict_SetItemString(dim_metadata_i, "dense_size", dense_size) < 0) {
        Py_XDECREF(format);
        Py_XDECREF(dense_size);
        Py_DECREF(dim_metadata_i);
        Py_DECREF(dim_metadata);
        Py_DECREF(result);
        return nullptr;
      }
      Py_DECREF(format);
      Py_DECREF(dense_size);
    } else {
      PyObject* format = PyLong_FromSize_t(1);
      const auto* array_segments = param.dim_metadata[i].array_segments;
      const auto* array_indices = param.dim_metadata[i].array_indices;
      PyObject* segments =
          PyArrayFromIntVector(array_segments->data, array_segments->size);
      PyObject* indices =
          PyArrayFromIntVector(array_indices->data, array_indices->size);
      if (format == nullptr || segments == nullptr || indices == nullptr ||
          PyDict_SetItemString(dim_metadata_i, "format", format) < 0 ||
          PyDict_SetItemString(dim_metadata_i, "array_segments", segments) <
              0 ||
          PyDict_SetItemString(dim_metadata_i, "array_indices", indices) < 0) {
        Py_XDECREF(format);
        Py_XDECREF(segments);
        Py_XDECREF(indices);
        Py_DECREF(dim_metadata_i);
        Py_DECREF(dim_metadata);
        Py_DECREF(result);
        return nullptr;
      }
      Py_DECREF(format);
      Py_DECREF(segments);
      Py_DECREF(indices);
    }
    if (PyList_SetItem(dim_metadata, i, dim_metadata_i) < 0) {
      Py_DECREF(dim_metadata_i);
      Py_DECREF(dim_metadata);
      Py_DECREF(result);
      return nullptr;
    }
  }

  if (PyDict_SetItemString(result, "dim_metadata", dim_metadata) < 0) {
    Py_DECREF(dim_metadata);
    Py_DECREF(result);
    return nullptr;
  }
  Py_DECREF(dim_metadata);
  return result;
}

bool RegisterCustomOpByName(const char* registerer_name,
                            tflite::MutableOpResolver* resolver,
                            std::string* error_msg) {
  // Registerer functions take a pointer to a BuiltinOpResolver as an input
  // parameter and return void.
  // TODO(b/137576229): We should implement this functionality in a more
  // principled way.
  typedef void (*RegistererFunctionType)(tflite::MutableOpResolver*);

  // Look for the Registerer function by name.
  RegistererFunctionType registerer = reinterpret_cast<RegistererFunctionType>(
      SharedLibrary::GetSymbol(registerer_name));

  // Try to load the pywrap_genai_ops library if the function was not found.
  if (registerer == nullptr) {
    const std::string kPywrapGenaiOpsPrefix = "pywrap_genai_ops.";
    if (absl::StartsWith(registerer_name, kPywrapGenaiOpsPrefix)) {
      const std::string kPywrapGenaiOpsFileName =
          absl::StrFormat("%sso", kPywrapGenaiOpsPrefix);
#if defined(_WIN32)
      void* lib_genai_ops = SharedLibrary::LoadLibrary(L"pywrap_genai_ops.pyd");
#else
      void* lib_genai_ops =
          SharedLibrary::LoadLibrary(kPywrapGenaiOpsFileName.c_str());
#endif
      if (lib_genai_ops == nullptr) {
        *error_msg =
            absl::StrFormat("Loading library '%s' failed with error '%s'.",
                            kPywrapGenaiOpsFileName, SharedLibrary::GetError());
        return false;
      }
      const std::string registerer_name_str(registerer_name);
      registerer = reinterpret_cast<RegistererFunctionType>(
          SharedLibrary::GetLibrarySymbol(
              lib_genai_ops,
              registerer_name_str.substr(kPywrapGenaiOpsPrefix.size())
                  .c_str()));
    }

    // Fail in an informative way if the function was not found.
    if (registerer == nullptr) {
      *error_msg =
          absl::StrFormat("Looking up symbol '%s' failed with error '%s'.",
                          registerer_name, SharedLibrary::GetError());
      return false;
    }
  }

  // Call the registerer with the resolver.
  registerer(resolver);
  return true;
}

}  // namespace

static constexpr int kBuiltinOpResolver = 1;
static constexpr int kBuiltinRefOpResolver = 2;
static constexpr int kBuiltinOpResolverWithoutDefaultDelegates = 3;

InterpreterWrapper* InterpreterWrapper::CreateInterpreterWrapper(
    std::unique_ptr<InterpreterWrapper::Model> model, int op_resolver_id,
    std::unique_ptr<PythonErrorReporter> error_reporter,
    const std::vector<std::string>& registerers_by_name,
    const std::vector<std::function<void(uintptr_t)>>& registerers_by_func,
    std::string* error_msg, bool preserve_all_tensors,
    bool disable_delegate_clustering, int num_threads,
    bool default_delegate_latest_features,
    bool compress_quantization_zero_points, bool disable_delegate_node_fusion,
    bool force_delegate_node_profiling) {
  if (!model) {
    *error_msg = error_reporter->message();
    return nullptr;
  }

  std::unique_ptr<tflite::MutableOpResolver> resolver;
  if (default_delegate_latest_features) {
    resolver = std::make_unique<
        tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates>();
  } else {
    switch (op_resolver_id) {
      case kBuiltinOpResolver:
        resolver = std::make_unique<tflite::ops::builtin::BuiltinOpResolver>();
        break;
      case kBuiltinRefOpResolver:
        resolver =
            std::make_unique<tflite::ops::builtin::BuiltinRefOpResolver>();
        break;
      case kBuiltinOpResolverWithoutDefaultDelegates:
        resolver = std::make_unique<
            tflite::ops::builtin::BuiltinOpResolverWithoutDefaultDelegates>();
        break;
      default:
        // This should not never happen because the eventual caller in
        // interpreter.py should have passed a valid id here.
        TFLITE_DCHECK(false);
        return nullptr;
    }
  }

  for (const auto& registerer : registerers_by_name) {
    if (!RegisterCustomOpByName(registerer.c_str(), resolver.get(), error_msg))
      return nullptr;
  }
  for (const auto& registerer : registerers_by_func) {
    registerer(reinterpret_cast<uintptr_t>(resolver.get()));
  }
  auto interpreter = CreateInterpreter(
      model.get(), *resolver, preserve_all_tensors, disable_delegate_clustering,
      num_threads, default_delegate_latest_features,
      compress_quantization_zero_points, disable_delegate_node_fusion,
      force_delegate_node_profiling);
  if (!interpreter) {
    *error_msg = error_reporter->message();
    return nullptr;
  }

  InterpreterWrapper* wrapper =
      new InterpreterWrapper(std::move(model), std::move(error_reporter),
                             std::move(resolver), std::move(interpreter));
  return wrapper;
}

InterpreterWrapper::InterpreterWrapper(
    std::unique_ptr<InterpreterWrapper::Model> model,
    std::unique_ptr<PythonErrorReporter> error_reporter,
    std::unique_ptr<tflite::MutableOpResolver> resolver,
    std::unique_ptr<Interpreter> interpreter)
    : model_(std::move(model)),
      error_reporter_(std::move(error_reporter)),
      resolver_(std::move(resolver)),
      interpreter_(std::move(interpreter)) {}

InterpreterWrapper::~InterpreterWrapper() = default;

// LINT.IfChange
static constexpr int kUndeterminedSubgraphIndex = -1;
// LINT.ThenChange(//tflite/python/interpreter_wrapper/interpreter_wrapper_pybind11.cc)
PyObject* InterpreterWrapper::AllocateTensors(int subgraph_index) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  if (subgraph_index == kUndeterminedSubgraphIndex) {
    TFLITE_PY_CHECK(interpreter_->AllocateTensors());
  } else {
    // We don't check the return of this call. Failing is a real possiblity as
    // the default XNNPack delegate may fail to apply on certain graphs.
    interpreter_->ApplyLazyDelegateProviders();
    TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(subgraph_index);
    TFLITE_PY_CHECK(interpreter_->subgraph(subgraph_index)->AllocateTensors());
  }
  Py_RETURN_NONE;
}

PyObject* InterpreterWrapper::Invoke(int subgraph_index) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(subgraph_index);

  // Release the GIL so that we can run multiple interpreters in parallel
  TfLiteStatus status_code = kTfLiteOk;
  Py_BEGIN_ALLOW_THREADS;  // To return can happen between this and end!
  tflite::Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  status_code = subgraph->Invoke();

  if (!interpreter_->allow_buffer_handle_output_) {
    for (int tensor_index : subgraph->outputs()) {
      subgraph->EnsureTensorDataIsReadable(tensor_index);
    }
  }
  Py_END_ALLOW_THREADS;

  TFLITE_PY_CHECK(
      status_code);  // don't move this into the Py_BEGIN/Py_End block

  Py_RETURN_NONE;
}

PyObject* InterpreterWrapper::InputIndices() const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  PyObject* np_array = PyArrayFromIntVector(interpreter_->inputs().data(),
                                            interpreter_->inputs().size());

  return PyArray_Return(reinterpret_cast<PyArrayObject*>(np_array));
}

PyObject* InterpreterWrapper::OutputIndices() const {
  PyObject* np_array = PyArrayFromIntVector(interpreter_->outputs().data(),
                                            interpreter_->outputs().size());

  return PyArray_Return(reinterpret_cast<PyArrayObject*>(np_array));
}

PyObject* InterpreterWrapper::ResizeInputTensorImpl(int i, PyObject* value) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();

  std::unique_ptr<PyObject, PyDecrefDeleter> array_safe(
      PyArray_FromAny(value, nullptr, 0, 0, NPY_ARRAY_CARRAY, nullptr));
  if (!array_safe) {
    PyErr_SetString(PyExc_ValueError,
                    "Failed to convert numpy value into readable tensor.");
    return nullptr;
  }

  PyArrayObject* array = reinterpret_cast<PyArrayObject*>(array_safe.get());

  if (PyArray_NDIM(array) != 1) {
    PyErr_Format(PyExc_ValueError, "Shape should be 1D instead of %d.",
                 PyArray_NDIM(array));
    return nullptr;
  }

  if (PyArray_TYPE(array) != NPY_INT32) {
    PyErr_Format(PyExc_ValueError, "Shape must be type int32 (was %d).",
                 PyArray_TYPE(array));
    return nullptr;
  }

  return PyArray_Return(reinterpret_cast<PyArrayObject*>(array_safe.release()));
}

PyObject* InterpreterWrapper::ResizeInputTensor(int i, PyObject* value,
                                                bool strict,
                                                int subgraph_index) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(subgraph_index);

  PyArrayObject* array =
      reinterpret_cast<PyArrayObject*>(ResizeInputTensorImpl(i, value));
  if (array == nullptr) {
    return nullptr;
  }

  std::vector<int> dims(PyArray_SHAPE(array)[0]);
  memcpy(dims.data(), PyArray_BYTES(array), dims.size() * sizeof(int));
  Py_DECREF(array);

  if (strict) {
    TFLITE_PY_CHECK(interpreter_->subgraph(subgraph_index)
                        ->ResizeInputTensorStrict(i, dims));
  } else {
    TFLITE_PY_CHECK(
        interpreter_->subgraph(subgraph_index)->ResizeInputTensor(i, dims));
  }
  Py_RETURN_NONE;
}

int InterpreterWrapper::NumTensors(int subgraph_index) const {
  if (!interpreter_) {
    return 0;
  }
  return interpreter_->subgraph(subgraph_index)->tensors_size();
}

int InterpreterWrapper::NumSubgraphs() const {
  if (interpreter_ == nullptr) {
    return 0;
  }
  return interpreter_->subgraphs_size();
}

std::string InterpreterWrapper::TensorName(int tensor_index,
                                           int subgraph_index) const {
  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  if (!interpreter_ || tensor_index >= subgraph->tensors_size() ||
      tensor_index < 0) {
    return "";
  }

  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  return tensor->name ? tensor->name : "";
}

PyObject* InterpreterWrapper::TensorType(int tensor_index,
                                         int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  if (tensor->type == kTfLiteNoType) {
    PyErr_Format(PyExc_ValueError, "Tensor with no type found.");
    return nullptr;
  }

  int code = python_utils::TfLiteTypeToPyArrayType(tensor->type);
  if (code == -1) {
    PyErr_Format(PyExc_ValueError, "Invalid tflite type code %d", code);
    return nullptr;
  }
  return PyArray_TypeObjectFromType(code);
}

PyObject* InterpreterWrapper::TensorSize(int tensor_index,
                                         int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  if (tensor->dims == nullptr) {
    PyErr_Format(PyExc_ValueError, "Tensor with no shape found.");
    return nullptr;
  }
  PyObject* np_array =
      PyArrayFromIntVector(tensor->dims->data, tensor->dims->size);

  return PyArray_Return(reinterpret_cast<PyArrayObject*>(np_array));
}

PyObject* InterpreterWrapper::TensorSizeSignature(int tensor_index,
                                                  int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  const TfLiteIntArray* dims_signature = TfLiteTensorGetDimsSignature(tensor);
  PyObject* np_array =
      PyArrayFromIntVector(dims_signature->data, dims_signature->size);

  return PyArray_Return(reinterpret_cast<PyArrayObject*>(np_array));
}

PyObject* InterpreterWrapper::TensorSparsityParameters(
    int tensor_index, int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  if (tensor->sparsity == nullptr) {
    return PyDict_New();
  }

  return PyDictFromSparsityParam(*tensor->sparsity);
}

PyObject* InterpreterWrapper::TensorQuantization(int tensor_index,
                                                 int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  return PyTupleFromQuantizationParam(tensor->params);
}

PyObject* InterpreterWrapper::TensorQuantizationParameters(
    int tensor_index, int subgraph_index) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  const Subgraph* subgraph = interpreter_->subgraph(subgraph_index);
  const TfLiteTensor* tensor = subgraph->tensor(tensor_index);
  const TfLiteQuantization quantization = tensor->quantization;
  float* scales_data = nullptr;
  int32_t* zero_points_data = nullptr;
  int32_t scales_size = 0;
  int32_t zero_points_size = 0;
  int32_t quantized_dimension = 0;
  int32_t block_size = 0;
  PyObject* scales_array = nullptr;

  if (quantization.type == kTfLiteAffineQuantization) {
    const TfLiteAffineQuantization* q_params =
        reinterpret_cast<const TfLiteAffineQuantization*>(quantization.params);
    if (q_params->scale) {
      scales_data = q_params->scale->data;
      scales_size = q_params->scale->size;
    }
    if (q_params->zero_point) {
      zero_points_data = q_params->zero_point->data;
      zero_points_size = q_params->zero_point->size;
    }
    quantized_dimension = q_params->quantized_dimension;
    scales_array = PyArrayFromFloatVector(scales_data, scales_size);
  } else if (quantization.type == kTfLiteBlockwiseQuantization) {
    const TfLiteBlockwiseQuantization* bq_params =
        reinterpret_cast<const TfLiteBlockwiseQuantization*>(
            quantization.params);
    TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(bq_params->scale, subgraph_index);
    const TfLiteTensor* scale_tensor = subgraph->tensor(bq_params->scale);
    auto* scales_data =
        reinterpret_cast<const uint16_t*>(scale_tensor->data.f16);
    scales_size = scale_tensor->bytes / sizeof(uint16_t);
    scales_array = PyArrayFromFloat16Vector(scales_data, scales_size);
    if (bq_params->zero_point != -1) {
      TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(bq_params->zero_point,
                                             subgraph_index);
      const TfLiteTensor* zero_point_tensor =
          subgraph->tensor(bq_params->zero_point);
      zero_points_data = zero_point_tensor->data.i32;
      zero_points_size = zero_point_tensor->bytes / sizeof(int32_t);
    } else {
      zero_points_data = nullptr;
      zero_points_size = 0;
    }
    quantized_dimension = bq_params->quantized_dimension;
    block_size = bq_params->blocksize;
  } else {
    scales_array = PyArrayFromFloatVector(scales_data, scales_size);
  }
  PyObject* zero_points_array =
      PyArrayFromIntVector(zero_points_data, zero_points_size);

  PyObject* result = PyTuple_New(4);
  PyTuple_SET_ITEM(result, 0, scales_array);
  PyTuple_SET_ITEM(result, 1, zero_points_array);
  PyTuple_SET_ITEM(result, 2, PyLong_FromLong(quantized_dimension));
  PyTuple_SET_ITEM(result, 3, PyLong_FromLong(block_size));
  return result;
}

PyObject* InterpreterWrapper::SetTensor(int tensor_index, PyObject* value,
                                        int subgraph_index) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(subgraph_index);
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  std::unique_ptr<PyObject, PyDecrefDeleter> array_safe(
      PyArray_FromAny(value, nullptr, 0, 0, NPY_ARRAY_CARRAY, nullptr));
  if (!array_safe) {
    PyErr_SetString(PyExc_ValueError,
                    "Failed to convert value into readable tensor.");
    return nullptr;
  }

  PyArrayObject* array = reinterpret_cast<PyArrayObject*>(array_safe.get());
  TfLiteTensor* tensor =
      interpreter_->subgraph(subgraph_index)->tensor(tensor_index);

  if (tensor->type == kTfLiteInt4 || tensor->type == kTfLiteUInt4) {
    return python_utils::Set4BitTensor(tensor, array, tensor_index);
  }

  TfLiteType incoming_type = python_utils::TfLiteTypeFromPyArray(array);
  if (incoming_type != tensor->type) {
    bool allow_raw_bytes =
        (tensor->type == kTfLiteFloat8E4M3FN ||
         tensor->type == kTfLiteFloat8E5M2) &&
        (incoming_type == kTfLiteInt8 || incoming_type == kTfLiteUInt8);
    if (!allow_raw_bytes) {
      PyErr_Format(
          PyExc_ValueError,
          "Cannot set tensor:"
          " Got value of type %s"
          " but expected type %s for input %d, name: %s ",
          TfLiteTypeGetName(python_utils::TfLiteTypeFromPyArray(array)),
          TfLiteTypeGetName(tensor->type), tensor_index, tensor->name);
      return nullptr;
    }
  }

  if (PyArray_NDIM(array) != tensor->dims->size) {
    PyErr_Format(PyExc_ValueError,
                 "Cannot set tensor: Dimension mismatch."
                 " Got %d"
                 " but expected %d for input %d.",
                 PyArray_NDIM(array), tensor->dims->size, tensor_index);
    return nullptr;
  }

  for (int j = 0; j < PyArray_NDIM(array); j++) {
    if (tensor->dims->data[j] != PyArray_SHAPE(array)[j]) {
      PyErr_Format(PyExc_ValueError,
                   "Cannot set tensor: Dimension mismatch."
                   " Got %ld"
                   " but expected %d for dimension %d of input %d.",
                   PyArray_SHAPE(array)[j], tensor->dims->data[j], j,
                   tensor_index);
      return nullptr;
    }
  }

  if (tensor->type != kTfLiteString) {
    // Only allow empty tensors.
    if (tensor->data.raw == nullptr && tensor->bytes) {
      PyErr_Format(PyExc_ValueError,
                   "Cannot set tensor:"
                   " Tensor is unallocated. Try calling allocate_tensors()"
                   " first");
      return nullptr;
    }

    size_t size = PyArray_NBYTES(array);
    if (size != tensor->bytes) {
      PyErr_Format(PyExc_ValueError,
                   "numpy array had %zu bytes but expected %zu bytes.", size,
                   tensor->bytes);
      return nullptr;
    }
    memcpy(tensor->data.raw, PyArray_DATA(array), size);
  } else {
    DynamicBuffer dynamic_buffer;
    if (!python_utils::FillStringBufferWithPyArray(value, &dynamic_buffer)) {
      return nullptr;
    }
    dynamic_buffer.WriteToTensor(tensor, nullptr);
  }
  Py_RETURN_NONE;
}

int InterpreterWrapper::NumNodes() const {
  if (!interpreter_) {
    return 0;
  }
  return interpreter_->nodes_size();
}

PyObject* InterpreterWrapper::NodeInputs(int i) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_NODES_BOUNDS_CHECK(i);

  const TfLiteNode* node = &(interpreter_->node_and_registration(i)->first);
  PyObject* inputs =
      PyArrayFromIntVector(node->inputs->data, node->inputs->size);
  return inputs;
}

PyObject* InterpreterWrapper::NodeOutputs(int i) const {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_NODES_BOUNDS_CHECK(i);

  const TfLiteNode* node = &(interpreter_->node_and_registration(i)->first);
  PyObject* outputs =
      PyArrayFromIntVector(node->outputs->data, node->outputs->size);
  return outputs;
}

std::string InterpreterWrapper::NodeName(int i) const {
  if (!interpreter_ || i >= interpreter_->nodes_size() || i < 0) {
    return "";
  }
  // Get op name from registration
  const TfLiteRegistration* node_registration =
      &(interpreter_->node_and_registration(i)->second);
  int32_t op_code = node_registration->builtin_code;
  std::string op_name;
  if (op_code == tflite::BuiltinOperator_CUSTOM) {
    const char* custom_name = node_registration->custom_name;
    op_name = custom_name ? custom_name : "UnknownCustomOp";
  } else {
    op_name = tflite::EnumNamesBuiltinOperator()[op_code];
  }
  std::string op_name_str(op_name);
  return op_name_str;
}

namespace {

// Checks to see if a tensor access can succeed (returns nullptr on error).
// Otherwise returns Py_None.
PyObject* CheckGetTensorArgs(Interpreter* interpreter_, int tensor_index,
                             TfLiteTensor** tensor, int* type_num,
                             int subgraph_index) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_SUBGRAPH_BOUNDS_CHECK(subgraph_index);
  TFLITE_PY_SUBGRAPH_TENSOR_BOUNDS_CHECK(tensor_index, subgraph_index);

  *tensor = interpreter_->subgraph(subgraph_index)->tensor(tensor_index);
  // Invalid size only when bytes are 0 but pointer is allocated.
  if ((*tensor)->bytes == 0 && (*tensor)->data.raw) {
    PyErr_SetString(PyExc_ValueError, "Invalid tensor size.");
    return nullptr;
  }

  *type_num = python_utils::TfLiteTypeToPyArrayType((*tensor)->type);
  if (*type_num == -1) {
    PyErr_SetString(PyExc_ValueError, "Unknown tensor type.");
    return nullptr;
  }

  // Tensor data can't be null if size is > 0. 0 bytes is valid if tensor
  // is empty.
  if (!(*tensor)->data.raw && (*tensor)->bytes) {
    PyErr_SetString(PyExc_ValueError,
                    "Tensor data is null."
                    " Run allocate_tensors() first");
    return nullptr;
  }

  Py_RETURN_NONE;
}

}  // namespace

PyObject* InterpreterWrapper::GetSignatureDefs() const {
  PyObject* result = PyDict_New();
  if (result == nullptr) return nullptr;

  for (const auto& sig_key : interpreter_->signature_keys()) {
    PyObject* signature_def = PyDict_New();
    PyObject* inputs = PyDict_New();
    PyObject* outputs = PyDict_New();
    if (signature_def == nullptr || inputs == nullptr || outputs == nullptr) {
      Py_XDECREF(signature_def);
      Py_XDECREF(inputs);
      Py_XDECREF(outputs);
      Py_DECREF(result);
      return nullptr;
    }

    const auto& signature_def_inputs =
        interpreter_->signature_inputs(sig_key->c_str());
    const auto& signature_def_outputs =
        interpreter_->signature_outputs(sig_key->c_str());

    for (const auto& input : signature_def_inputs) {
      PyObject* val = PyLong_FromLong(input.second);
      if (val == nullptr ||
          PyDict_SetItemString(inputs, input.first.c_str(), val) < 0) {
        Py_XDECREF(val);
        Py_DECREF(signature_def);
        Py_DECREF(inputs);
        Py_DECREF(outputs);
        Py_DECREF(result);
        return nullptr;
      }
      Py_DECREF(val);
    }

    for (const auto& output : signature_def_outputs) {
      PyObject* val = PyLong_FromLong(output.second);
      if (val == nullptr ||
          PyDict_SetItemString(outputs, output.first.c_str(), val) < 0) {
        Py_XDECREF(val);
        Py_DECREF(signature_def);
        Py_DECREF(inputs);
        Py_DECREF(outputs);
        Py_DECREF(result);
        return nullptr;
      }
      Py_DECREF(val);
    }

    if (PyDict_SetItemString(signature_def, "inputs", inputs) < 0 ||
        PyDict_SetItemString(signature_def, "outputs", outputs) < 0 ||
        PyDict_SetItemString(result, sig_key->c_str(), signature_def) < 0) {
      Py_DECREF(inputs);
      Py_DECREF(outputs);
      Py_DECREF(signature_def);
      Py_DECREF(result);
      return nullptr;
    }
    Py_DECREF(inputs);
    Py_DECREF(outputs);
    Py_DECREF(signature_def);
  }
  return result;
}

PyObject* InterpreterWrapper::GetSubgraphIndexFromSignature(
    const char* signature_key) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();

  int32_t subgraph_index =
      interpreter_->GetSubgraphIndexFromSignature(signature_key);

  if (subgraph_index < 0) {
    PyErr_SetString(PyExc_ValueError, "No matching signature.");
    return nullptr;
  }
  return PyLong_FromLong(static_cast<int64_t>(subgraph_index));
}

PyObject* InterpreterWrapper::GetTensor(int tensor_index,
                                        int subgraph_index) const {
  // Sanity check accessor
  TfLiteTensor* tensor = nullptr;
  int type_num = 0;

  PyObject* check_result = CheckGetTensorArgs(
      interpreter_.get(), tensor_index, &tensor, &type_num, subgraph_index);
  if (check_result == nullptr) return check_result;
  Py_XDECREF(check_result);

  std::vector<npy_intp> dims(tensor->dims->data,
                             tensor->dims->data + tensor->dims->size);
  if (tensor->type != kTfLiteString && tensor->type != kTfLiteResource &&
      tensor->type != kTfLiteVariant) {
    // Make a buffer copy but we must tell Numpy It owns that data or else
    // it will leak.
    size_t numpy_bytes = tensor->bytes;
    if (tensor->type == kTfLiteInt4 || tensor->type == kTfLiteUInt4) {
      // Numpy doesn't have int4 type, so we double the size of the buffer
      // to hold int8 type for each (4-bit packed) element.
      numpy_bytes *= 2;
    } else if (tensor->type == kTfLiteInt2) {
      // Numpy doesn't have int2 type, so we quadruple the size of the buffer
      // to hold int8 type for each (2-bit packed) element.
      numpy_bytes *= 4;
    }
    void* data = malloc(numpy_bytes);
    if (!data) {
      PyErr_NoMemory();
      return nullptr;
    }
    if (tensor->type == kTfLiteInt4) {
      int8_t* tensor_data = reinterpret_cast<int8_t*>(tensor->data.raw);
      int8_t* numpy_data = static_cast<int8_t*>(data);
      // Unpack each 4-bit value to an 8-bit container.
      for (size_t i = 0; i < tensor->bytes; i++) {
        int8_t byte = tensor_data[i];
        int8_t lower = static_cast<int8_t>(byte << 4) >> 4;
        int8_t upper = static_cast<int8_t>(byte >> 4);
        numpy_data[2 * i] = lower;
        numpy_data[2 * i + 1] = upper;
      }
    } else if (tensor->type == kTfLiteUInt4) {
      uint8_t* tensor_data = reinterpret_cast<uint8_t*>(tensor->data.raw);
      uint8_t* numpy_data = static_cast<uint8_t*>(data);
      // Unpack each 4-bit value to an 8-bit container.
      for (size_t i = 0; i < tensor->bytes; i++) {
        uint8_t byte = tensor_data[i];
        uint8_t lower = byte & 0x0F;
        uint8_t upper = byte >> 4;
        numpy_data[2 * i] = lower;
        numpy_data[2 * i + 1] = upper;
      }
    } else if (tensor->type == kTfLiteInt2) {
      int8_t* tensor_data = reinterpret_cast<int8_t*>(tensor->data.raw);
      int8_t* numpy_data = static_cast<int8_t*>(data);
      // Unpack each 2-bit value to an 8-bit container.
      for (size_t i = 0; i < tensor->bytes; i++) {
        int8_t byte = tensor_data[i];
        int8_t first = static_cast<int8_t>(byte << 6) >> 6;
        int8_t second = static_cast<int8_t>(byte << 4) >> 6;
        int8_t third = static_cast<int8_t>(byte << 2) >> 6;
        int8_t fourth = static_cast<int8_t>(byte) >> 6;
        numpy_data[4 * i] = first;
        numpy_data[4 * i + 1] = second;
        numpy_data[4 * i + 2] = third;
        numpy_data[4 * i + 3] = fourth;
      }
    } else {
      memcpy(data, tensor->data.raw, tensor->bytes);
    }

    PyObject* np_array;
    if (tensor->sparsity == nullptr) {
      np_array =
          PyArray_SimpleNewFromData(dims.size(), dims.data(), type_num, data);
    } else {
      std::vector<npy_intp> sparse_buffer_dims(1);
      size_t size_of_type;
      if (GetSizeOfType(nullptr, tensor->type, &size_of_type) != kTfLiteOk) {
        PyErr_SetString(PyExc_ValueError, "Unknown tensor type.");
        free(data);
        return nullptr;
      }
      sparse_buffer_dims[0] = tensor->bytes / size_of_type;
      np_array = PyArray_SimpleNewFromData(
          sparse_buffer_dims.size(), sparse_buffer_dims.data(), type_num, data);
    }
    if (np_array == nullptr) {
      free(data);
      return nullptr;
    }
    PyArray_ENABLEFLAGS(reinterpret_cast<PyArrayObject*>(np_array),
                        NPY_ARRAY_OWNDATA);
    return PyArray_Return(reinterpret_cast<PyArrayObject*>(np_array));
  } else {
    // Create a C-order array so the data is contiguous in memory.
    const int32_t kCOrder = 0;
    PyObject* py_object =
        PyArray_EMPTY(dims.size(), dims.data(), NPY_OBJECT, kCOrder);

    if (py_object == nullptr) {
      PyErr_SetString(PyExc_MemoryError, "Failed to allocate PyArray.");
      return nullptr;
    }

    PyArrayObject* py_array = reinterpret_cast<PyArrayObject*>(py_object);
    PyObject** data = reinterpret_cast<PyObject**>(PyArray_DATA(py_array));
    auto num_strings = GetStringCount(tensor);
    for (int j = 0; j < num_strings; ++j) {
      auto ref = GetString(tensor, j);

      PyObject* bytes = PyBytes_FromStringAndSize(ref.str, ref.len);
      if (bytes == nullptr) {
        Py_DECREF(py_object);
        PyErr_Format(PyExc_ValueError,
                     "Could not create PyBytes from string %d of input %d.", j,
                     tensor_index);
        return nullptr;
      }
      // PyArray_EMPTY produces an array full of Py_None, which we must decref.
      Py_DECREF(data[j]);
      data[j] = bytes;
    }
    return py_object;
  }
}

PyObject* InterpreterWrapper::tensor(PyObject* base_object, int tensor_index,
                                     int subgraph_index) {
  // Sanity check accessor
  TfLiteTensor* tensor = nullptr;
  int type_num = 0;

  PyObject* check_result = CheckGetTensorArgs(
      interpreter_.get(), tensor_index, &tensor, &type_num, subgraph_index);
  if (check_result == nullptr) return check_result;
  Py_XDECREF(check_result);

  std::vector<npy_intp> dims(tensor->dims->data,
                             tensor->dims->data + tensor->dims->size);
  PyArrayObject* np_array =
      reinterpret_cast<PyArrayObject*>(PyArray_SimpleNewFromData(
          dims.size(), dims.data(), type_num, tensor->data.raw));
  Py_INCREF(base_object);  // SetBaseObject steals, so we need to add.
  PyArray_SetBaseObject(np_array, base_object);
  return PyArray_Return(np_array);
}

InterpreterWrapper* InterpreterWrapper::CreateWrapperCPPFromFile(
    const char* model_path, int op_resolver_id,
    const std::vector<std::string>& registerers_by_name,
    const std::vector<std::function<void(uintptr_t)>>& registerers_by_func,
    std::string* error_msg, bool preserve_all_tensors,
    bool disable_delegate_clustering, int num_threads,
    bool default_delegate_latest_features,
    bool compress_quantization_zero_points, bool disable_delegate_node_fusion,
    bool force_delegate_node_profiling) {
  std::unique_ptr<PythonErrorReporter> error_reporter =
      std::make_unique<PythonErrorReporter>();
  std::unique_ptr<InterpreterWrapper::Model> model =
      Model::VerifyAndBuildFromFile(model_path, /*extra_verifier=*/nullptr,
                                    error_reporter.get());
  return CreateInterpreterWrapper(
      std::move(model), op_resolver_id, std::move(error_reporter),
      registerers_by_name, registerers_by_func, error_msg, preserve_all_tensors,
      disable_delegate_clustering, num_threads,
      default_delegate_latest_features, compress_quantization_zero_points,
      disable_delegate_node_fusion, force_delegate_node_profiling);
}

InterpreterWrapper* InterpreterWrapper::CreateWrapperCPPFromFile(
    const char* model_path, int op_resolver_id,
    const std::vector<std::string>& registerers, std::string* error_msg,
    bool preserve_all_tensors, bool disable_delegate_clustering) {
  return CreateWrapperCPPFromFile(
      model_path, op_resolver_id, registerers, {} /*registerers_by_func*/,
      error_msg, preserve_all_tensors, disable_delegate_clustering,
      /*num_threads=*/1, /*default_delegate_latest_features=*/false,
      /*compress_quantization_zero_points=*/false,
      /*disable_delegate_node_fusion=*/false,
      /*force_delegate_node_profiling=*/false);
}

InterpreterWrapper* InterpreterWrapper::CreateWrapperCPPFromBuffer(
    PyObject* data, int op_resolver_id,
    const std::vector<std::string>& registerers_by_name,
    const std::vector<std::function<void(uintptr_t)>>& registerers_by_func,
    std::string* error_msg, bool preserve_all_tensors,
    bool disable_delegate_clustering, int num_threads,
    bool default_delegate_latest_features,
    bool compress_quantization_zero_points, bool disable_delegate_node_fusion,
    bool force_delegate_node_profiling) {
  char* buf = nullptr;
  Py_ssize_t length;
  std::unique_ptr<PythonErrorReporter> error_reporter =
      std::make_unique<PythonErrorReporter>();

  if (python_utils::ConvertFromPyString(data, &buf, &length) == -1) {
    return nullptr;
  }
  std::unique_ptr<InterpreterWrapper::Model> model =
      Model::VerifyAndBuildFromBuffer(buf, length, /*extra_verifier=*/nullptr,
                                      error_reporter.get());
  return CreateInterpreterWrapper(
      std::move(model), op_resolver_id, std::move(error_reporter),
      registerers_by_name, registerers_by_func, error_msg, preserve_all_tensors,
      disable_delegate_clustering, num_threads,
      default_delegate_latest_features, compress_quantization_zero_points,
      disable_delegate_node_fusion, force_delegate_node_profiling);
}

InterpreterWrapper* InterpreterWrapper::CreateWrapperCPPFromBuffer(
    PyObject* data, int op_resolver_id,
    const std::vector<std::string>& registerers, std::string* error_msg,
    bool preserve_all_tensors, bool disable_delegate_clustering) {
  return CreateWrapperCPPFromBuffer(
      data, op_resolver_id, registerers, {}, error_msg, preserve_all_tensors,
      disable_delegate_clustering, /*num_threads=*/1,
      /*default_delegate_latest_features=*/false,
      /*compress_quantization_zero_points=*/false,
      /*disable_delegate_node_fusion=*/false,
      /*force_delegate_node_profiling=*/false);
}

PyObject* InterpreterWrapper::ResetVariableTensors() {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_CHECK(interpreter_->ResetVariableTensors());
  Py_RETURN_NONE;
}

PyObject* InterpreterWrapper::SetNumThreads(int num_threads) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  interpreter_->SetNumThreads(num_threads);
  Py_RETURN_NONE;
}

PyObject* InterpreterWrapper::ModifyGraphWithDelegate(
    TfLiteDelegate* delegate) {
  TFLITE_PY_ENSURE_VALID_INTERPRETER();
  TFLITE_PY_CHECK(interpreter_->ModifyGraphWithDelegate(delegate));
  Py_RETURN_NONE;
}

}  // namespace interpreter_wrapper
}  // namespace tflite
