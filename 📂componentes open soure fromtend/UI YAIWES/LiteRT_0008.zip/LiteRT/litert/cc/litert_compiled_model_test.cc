// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "litert/cc/litert_compiled_model.h"

#include <cstdint>
#include <cstring>
#include <string>
#include <utility>
#include <vector>

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "absl/container/flat_hash_map.h"  // from @com_google_absl
#include "absl/log/absl_log.h"  // from @com_google_absl
#include "absl/strings/str_format.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#include "litert/c/internal/litert_scheduling_info.h"
#include "litert/c/litert_common.h"
#include "litert/c/litert_tensor_buffer_types.h"
#include "litert/cc/litert_common.h"
#include "litert/cc/litert_element_type.h"
#include "litert/cc/litert_environment.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_layout.h"
#include "litert/cc/litert_model.h"
#include "litert/cc/litert_model_types.h"
#include "litert/cc/litert_options.h"
#include "litert/cc/litert_ranked_tensor_type.h"
#include "litert/cc/litert_string_util.h"
#include "litert/cc/litert_tensor_buffer.h"
#include "litert/cc/litert_tensor_buffer_requirements.h"
#include "litert/cc/litert_tensor_buffer_types.h"
#include "litert/cc/options/litert_runtime_options.h"
// copybara:uncomment_begin(google internal)
// #include "litert/runtime/compiled_model.h"
// copybara:uncomment_end
#include "litert/test/common.h"
#include "litert/test/matchers.h"
#include "litert/test/testdata/simple_model_test_vectors.h"
// copybara:uncomment_begin(google internal)
// #include "tflite/core/subgraph.h"
// #include "tflite/interpreter.h"
// copybara:uncomment_end

using ::testing::ElementsAre;
using ::testing::ElementsAreArray;
using ::testing::FloatNear;
using ::testing::Pointwise;
using ::testing::SizeIs;
using ::testing::litert::IsOkAndHolds;

namespace litert {
namespace {

class CompiledModelTestPeer : public CompiledModel {
 public:
  using CompiledModel::Create;
};

#if defined(_WIN32)
constexpr bool kSupportsErrorReporterApi = false;
#else
constexpr bool kSupportsErrorReporterApi = true;
#endif

// copybara:uncomment_begin(google internal)
// tflite::Subgraph::SubgraphAllocInfo GetPrimarySubgraphAllocInfo(
//     tflite::Interpreter& interpreter) {
//   tflite::Subgraph::SubgraphAllocInfo alloc_info{};
//   interpreter.primary_subgraph().GetMemoryAllocInfo(&alloc_info);
//   return alloc_info;
// }
// copybara:uncomment_end

TEST(CompiledModelTest, Basic) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Check fully accelerated.
  LITERT_ASSERT_OK_AND_ASSIGN(auto fullyAccelerated,
                              compiled_model.IsFullyAccelerated());
  ASSERT_TRUE(fullyAccelerated);

  LITERT_ASSERT_OK_AND_ASSIGN(auto nonCpuFullyAccelerated,
                              compiled_model.IsNonCpuFullyAccelerated());
  ASSERT_FALSE(nonCpuFullyAccelerated);

  // Check CompiledModel buffer requirements.
  // input and output expect host memory.
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg0,
      compiled_model.GetInputBufferRequirements(/*input_name=*/"arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBufferType> input_buffer_types_arg0,
      input_buffer_requirements_arg0.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg0,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg1,
      compiled_model.GetInputBufferRequirements(/*input_name=*/"arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBufferType> input_buffer_types_arg1,
      input_buffer_requirements_arg1.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg1,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements output_buffer_requirements,
      compiled_model.GetOutputBufferRequirements(/*output_name=*/"tfl.add"));
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBufferType> output_buffer_types,
                              output_buffer_requirements.SupportedTypes());
  EXPECT_THAT(output_buffer_types, ElementsAre(TensorBufferType::kHostMemory));

  // Create and fill input and output buffers.
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> input_buffers,
                              compiled_model.CreateInputBuffers());

  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
                              compiled_model.CreateOutputBuffers());

  ASSERT_TRUE(input_buffers[0].Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffers[1].Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  // Execute model with input and output buffers.
  compiled_model.Run(input_buffers, output_buffers);

  // Check model output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[0], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t" << kTestOutputTensor[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
  }
}

TEST(CompiledModelTest, OwningCreateRejectsNonOwnedModel) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, Environment::Create({}));
  LITERT_ASSERT_OK_AND_ASSIGN(
      Model owned_model,
      Model::CreateFromFile(env, testing::GetTestFilePath(kModelFileName)));
  Model non_owned_model = Model::CreateFromNonOwnedHandle(owned_model.Get());
  Options options;
  options.SetHardwareAccelerators(HwAccelerators::kCpu);

  auto compiled_model =
      CompiledModelTestPeer::Create(env, std::move(non_owned_model), options);

  ASSERT_FALSE(compiled_model.HasValue());
  EXPECT_EQ(compiled_model.Error().Status(), kLiteRtStatusErrorInvalidArgument);
  EXPECT_TRUE(owned_model);
}

TEST(CompiledModelTest, OwningCreateRunsAfterModelMove) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, Environment::Create({}));
  LITERT_ASSERT_OK_AND_ASSIGN(
      Model model,
      Model::CreateFromFile(env, testing::GetTestFilePath(kModelFileName)));
  Options options;
  options.SetHardwareAccelerators(HwAccelerators::kCpu);

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModelTestPeer::Create(env, std::move(model), options));
  EXPECT_FALSE(model);
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> input_buffers,
                              compiled_model.CreateInputBuffers());
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
                              compiled_model.CreateOutputBuffers());
  ASSERT_TRUE(input_buffers[0].Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffers[1].Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  LITERT_ASSERT_OK(compiled_model.Run(input_buffers, output_buffers));

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto lock_and_addr,
      TensorBufferScopedLock::Create<const float>(
          output_buffers[0], TensorBuffer::LockMode::kRead));
  auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
  EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
}

// copybara:uncomment_begin(google internal)
// TEST(CompiledModelTest, CreateOutputBuffersDoesNotAllocateKnownOutputLayouts) {
//   LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));
//   LITERT_ASSERT_OK_AND_ASSIGN(
//       CompiledModel compiled_model,
//       CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
//                             HwAccelerators::kCpu));
//   LITERT_ASSERT_OK_AND_ASSIGN(tflite::Interpreter * interpreter,
//                               GetInterpreter(compiled_model.Get()));
// 
//   const auto before = GetPrimarySubgraphAllocInfo(*interpreter);
//   LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
//                               compiled_model.CreateOutputBuffers());
//   const auto after = GetPrimarySubgraphAllocInfo(*interpreter);
// 
//   EXPECT_EQ(after.arena_size, before.arena_size);
//   EXPECT_EQ(after.arena_persist_size, before.arena_persist_size);
//   EXPECT_EQ(after.dynamic_size, before.dynamic_size);
//   EXPECT_EQ(after.resource_size, before.resource_size);
// }
// 
// TEST(CompiledModelTest,
//      CreateOutputBuffersDoesNotAllocateUnknownOutputLayouts) {
//   LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));
//   LITERT_ASSERT_OK_AND_ASSIGN(
//       CompiledModel compiled_model,
//       CompiledModel::Create(env,
//                             testing::GetTestFilePath(kDynamicModelFileName),
//                             HwAccelerators::kCpu));
//   LITERT_ASSERT_OK_AND_ASSIGN(tflite::Interpreter * interpreter,
//                               GetInterpreter(compiled_model.Get()));
// 
//   const auto before = GetPrimarySubgraphAllocInfo(*interpreter);
//   LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
//                               compiled_model.CreateOutputBuffers());
//   const auto after = GetPrimarySubgraphAllocInfo(*interpreter);
// 
//   EXPECT_NE(after.arena_size, before.arena_size);
//   EXPECT_EQ(after.arena_persist_size, before.arena_persist_size);
//   EXPECT_EQ(after.dynamic_size, before.dynamic_size);
//   EXPECT_EQ(after.resource_size, before.resource_size);
// }
// copybara:uncomment_end

TEST(CompiledModelTest,
     ResizeInputTensorReflectsInCreatedInputBufferForSignature) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env,
                            testing::GetTestFilePath(kDynamicModelFileName),
                            HwAccelerators::kCpu));

  absl::string_view signature_key = compiled_model.DefaultSignatureKey();

  const std::vector<int> resized_dims = {4, 2, 3};
  LITERT_ASSERT_OK_AND_ASSIGN(
      const auto& input_names,
      compiled_model.GetSignatureInputNames(signature_key));
  absl::flat_hash_map<absl::string_view, TensorBuffer> input_map;
  for (const auto& input_name : input_names) {
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        signature_key, input_name, absl::MakeConstSpan(resized_dims)));
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBuffer input_buffer,
        compiled_model.CreateInputBuffer(signature_key, input_name));
    LITERT_ASSERT_OK_AND_ASSIGN(RankedTensorType buffer_type,
                                input_buffer.TensorType());
    EXPECT_THAT(buffer_type.Layout().Dimensions(),
                ElementsAre(resized_dims[0], resized_dims[1], resized_dims[2]));
    input_map[input_name] = std::move(input_buffer);
  }

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBuffer output_buffer,
      compiled_model.CreateOutputBuffer(signature_key, "tfl.add"));
  LITERT_ASSERT_OK_AND_ASSIGN(RankedTensorType buffer_type,
                              output_buffer.TensorType());
  EXPECT_THAT(buffer_type.Layout().Dimensions(),
              ElementsAre(resized_dims[0], resized_dims[1], resized_dims[2]));
  absl::flat_hash_map<absl::string_view, TensorBuffer> output_map;
  output_map["tfl.add"] = std::move(output_buffer);

  LITERT_ASSERT_OK(compiled_model.Run(input_map, output_map));
}

TEST(CompiledModelTest, BasicSignatureIndex) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel and check signatures.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  EXPECT_EQ(compiled_model.GetNumSignatures(), 1);
  size_t signature_index = 0;

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto input_names, compiled_model.GetSignatureInputNames(signature_index));
  EXPECT_THAT(input_names, ElementsAre("arg0", "arg1"));

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto output_names,
      compiled_model.GetSignatureOutputNames(signature_index));
  EXPECT_THAT(output_names, ElementsAre("tfl.add"));

  // Check CompiledModel buffer requirements.
  // input and output expect host memory.
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg0,
      compiled_model.GetInputBufferRequirements(signature_index,
                                                /*input_name=*/"arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(const auto input_buffer_types_arg0,
                              input_buffer_requirements_arg0.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg0,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg1,
      compiled_model.GetInputBufferRequirements(signature_index,
                                                /*input_name=*/"arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      const std::vector<TensorBufferType> input_buffer_types_arg1,
      input_buffer_requirements_arg1.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg1,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements output_buffer_requirements,
      compiled_model.GetOutputBufferRequirements(signature_index,
                                                 /*output_name=*/"tfl.add"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      const std::vector<TensorBufferType> output_buffer_types,
      output_buffer_requirements.SupportedTypes());
  EXPECT_THAT(output_buffer_types, ElementsAre(TensorBufferType::kHostMemory));

  // Create and fill input and output buffers.
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> input_buffers,
      compiled_model.CreateInputBuffers(signature_index));

  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> output_buffers,
      compiled_model.CreateOutputBuffers(signature_index));

  ASSERT_TRUE(input_buffers[0].Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffers[1].Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  // Execute model with input and output buffers.
  compiled_model.Run(signature_index, input_buffers, output_buffers);

  // Check model output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[0], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t" << kTestOutputTensor[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
  }
}

TEST(CompiledModelTest, RunWithInputOutputMap) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel and check signatures.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  EXPECT_EQ(compiled_model.GetNumSignatures(), 1);

  LITERT_ASSERT_OK_AND_ASSIGN(auto input_names,
                              compiled_model.GetSignatureInputNames());
  EXPECT_THAT(input_names, ElementsAre("arg0", "arg1"));

  LITERT_ASSERT_OK_AND_ASSIGN(auto output_names,
                              compiled_model.GetSignatureOutputNames());
  EXPECT_THAT(output_names, ElementsAre("tfl.add"));

  // Check CompiledModel buffer requirements.
  // input and output expect host memory.
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg0,
      compiled_model.GetInputBufferRequirements(
          /*input_name=*/"arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBufferType> input_buffer_types_arg0,
      input_buffer_requirements_arg0.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg0,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_buffer_requirements_arg1,
      compiled_model.GetInputBufferRequirements(
          /*input_name=*/"arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBufferType> input_buffer_types_arg1,
      input_buffer_requirements_arg1.SupportedTypes());
  EXPECT_THAT(input_buffer_types_arg1,
              ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements output_buffer_requirements,
      compiled_model.GetOutputBufferRequirements(
          /*output_name=*/"tfl.add"));
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBufferType> output_buffer_types,
                              output_buffer_requirements.SupportedTypes());
  EXPECT_THAT(output_buffer_types, ElementsAre(TensorBufferType::kHostMemory));

  // Create and fill input and output buffers.
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input_buffer0,
                              compiled_model.CreateInputBuffer("arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input_buffer1,
                              compiled_model.CreateInputBuffer("arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer output_buffer0,
                              compiled_model.CreateOutputBuffer("tfl.add"));

  ASSERT_TRUE(input_buffer0.Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffer1.Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  // Create input and output map.
  absl::flat_hash_map<absl::string_view, TensorBuffer> input_map;
  input_map["arg0"] = std::move(input_buffer0);
  input_map["arg1"] = std::move(input_buffer1);

  absl::flat_hash_map<absl::string_view, TensorBuffer> output_map;
  output_map["tfl.add"] = std::move(output_buffer0);

  // Execute model with input and output maps instead of buffers.
  compiled_model.Run(input_map, output_map);

  // Check model output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_map["tfl.add"], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t" << kTestOutputTensor[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
  }
}

TEST(CompiledModelTest, RunTwoModelsPipelineWithSharedTensorBuffers) {
  // In this test, we create two CompiledModels and the second model uses the
  // output of the first model as its first input and the second input is shared
  // with the first model.
  //
  // Pipeline structure:
  //
  //        arg0                  arg1
  //          |                     |
  //          v                     v
  //      +----------------+        |
  //      | mode1(tfl.add) | <------+
  //      +----------------+        |
  //           |                    |
  //           | output1            |
  //           v                    |
  //      +-----------------+       |
  //      | model2(tfl.add) | <-----+
  //      +-----------------+
  //           |
  //           v
  //         output2

  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create the first CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel model1,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Create the second CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel model2,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Create and fill input and output buffers for the first model.
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input1_buffer0,
                              model1.CreateInputBuffer("arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input1_buffer1,
                              model1.CreateInputBuffer("arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer output1_buffer0,
                              model1.CreateOutputBuffer("tfl.add"));

  ASSERT_TRUE(input1_buffer0.Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input1_buffer1.Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  // Create input and output buffers for the second model.
  // TensorBuffer::Duplicate() creates a virtual copy of the TensorBuffer.
  // Their underlying memory is shared so we don't need to copy the data.
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input2_buffer0,
                              output1_buffer0.Duplicate());
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input2_buffer1,
                              input1_buffer1.Duplicate());
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer output2_buffer0,
                              model2.CreateOutputBuffer("tfl.add"));

  // Create input and output map for the first model.
  absl::flat_hash_map<absl::string_view, TensorBuffer> input1_map;
  input1_map["arg0"] = std::move(input1_buffer0);
  input1_map["arg1"] = std::move(input1_buffer1);
  absl::flat_hash_map<absl::string_view, TensorBuffer> output1_map;
  output1_map["tfl.add"] = std::move(output1_buffer0);

  // Create input and output map for the second model.
  absl::flat_hash_map<absl::string_view, TensorBuffer> input2_map;
  input2_map["arg0"] = std::move(input2_buffer0);
  input2_map["arg1"] = std::move(input2_buffer1);
  absl::flat_hash_map<absl::string_view, TensorBuffer> output2_map;
  output2_map["tfl.add"] = std::move(output2_buffer0);

  // Execute models sequentially.
  LITERT_ASSERT_OK(model1.Run(input1_map, output1_map));
  // The output of the first model is shared via TensorBuffer so no additional
  // copying is needed here.
  LITERT_ASSERT_OK(model2.Run(input2_map, output2_map));

  // Check model1 output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output1_map["tfl.add"], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t" << kTestOutputTensor[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
  }

  // Check model2 output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output2_map["tfl.add"], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    constexpr const float kTestOutputTensor2[] = {21, 42};  // 11 + 10, 22 + 20
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t"
                     << kTestOutputTensor2[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor2));
  }
}

// Tests Compiled Model signature accessors.
TEST(CompiledModelTest, SignatureAccessors) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Check signature keys.
  LITERT_ASSERT_OK_AND_ASSIGN(auto signature_keys,
                              compiled_model.GetSignatureKeys());
  EXPECT_THAT(signature_keys,
              ElementsAre(compiled_model.DefaultSignatureKey()));

  // Check signatures.
  LITERT_ASSERT_OK_AND_ASSIGN(auto signatures, compiled_model.GetSignatures());
  ASSERT_EQ(signatures.size(), 1);
  EXPECT_EQ(signatures[0].Key(), compiled_model.DefaultSignatureKey());
  EXPECT_THAT(signatures[0].InputNames(), ElementsAre("arg0", "arg1"));
  EXPECT_THAT(signatures[0].OutputNames(), ElementsAre("tfl.add"));

  // Check GetSignature by index.
  LITERT_ASSERT_OK_AND_ASSIGN(auto signature, compiled_model.GetSignature(0));
  EXPECT_EQ(signature.Key(), compiled_model.DefaultSignatureKey());

  // Check signature input names by key.
  LITERT_ASSERT_OK_AND_ASSIGN(auto input_names,
                              compiled_model.GetSignatureInputNames(
                                  compiled_model.DefaultSignatureKey()));
  EXPECT_THAT(input_names, ElementsAre("arg0", "arg1"));

  // Check signature output names by key.
  LITERT_ASSERT_OK_AND_ASSIGN(auto output_names,
                              compiled_model.GetSignatureOutputNames(
                                  compiled_model.DefaultSignatureKey()));
  EXPECT_THAT(output_names, ElementsAre("tfl.add"));
}

TEST(CompiledModelTest, SignatureAccessorsInvalidContext) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Check GetSignature with invalid index.
  EXPECT_FALSE(compiled_model.GetSignature(100).HasValue());

  // Check GetSignatureIndex with invalid key.
  auto sig_index = compiled_model.GetSignatureIndex("invalid_key_sig_index");
  ASSERT_FALSE(sig_index.HasValue());
  EXPECT_THAT(
      sig_index.Error().Message(),
      ::testing::HasSubstr("Signature not found: invalid_key_sig_index"));

  // Check GetSignatureInputNames with invalid key.
  auto input_names =
      compiled_model.GetSignatureInputNames("invalid_key_input_names");
  ASSERT_FALSE(input_names.HasValue());
  EXPECT_THAT(
      input_names.Error().Message(),
      ::testing::HasSubstr("Signature not found: invalid_key_input_names"));

  // Check GetSignatureOutputNames with invalid key.
  auto output_names =
      compiled_model.GetSignatureOutputNames("invalid_key_output_names");
  ASSERT_FALSE(output_names.HasValue());
  EXPECT_THAT(
      output_names.Error().Message(),
      ::testing::HasSubstr("Signature not found: invalid_key_output_names"));

  // Check buffer requirements with invalid signature / tensor names.
  auto input_buf_req_bad_sig = compiled_model.GetInputBufferRequirements(
      "invalid_key_sig", "invalid_input_req");
  ASSERT_FALSE(input_buf_req_bad_sig.HasValue());
  EXPECT_THAT(input_buf_req_bad_sig.Error().Message(),
              ::testing::HasSubstr("Signature not found: invalid_key_sig"));

  auto input_buf_req =
      compiled_model.GetInputBufferRequirements("invalid_input_req");
  ASSERT_FALSE(input_buf_req.HasValue());
  EXPECT_THAT(input_buf_req.Error().Message(),
              ::testing::HasSubstr("Failed to find input: invalid_input_req"));

  auto output_buf_req_bad_sig = compiled_model.GetOutputBufferRequirements(
      "invalid_key_sig", "invalid_output_req");
  ASSERT_FALSE(output_buf_req_bad_sig.HasValue());
  EXPECT_THAT(output_buf_req_bad_sig.Error().Message(),
              ::testing::HasSubstr("Signature not found: invalid_key_sig"));

  auto output_buf_req =
      compiled_model.GetOutputBufferRequirements("invalid_output_req");
  ASSERT_FALSE(output_buf_req.HasValue());
  EXPECT_THAT(
      output_buf_req.Error().Message(),
      ::testing::HasSubstr("Failed to find output: invalid_output_req"));

  // Check tensor types with invalid tensor names.
  auto input_type_bad_sig = compiled_model.GetInputTensorType(
      "invalid_key_sig", "invalid_input_type");
  ASSERT_FALSE(input_type_bad_sig.HasValue());
  EXPECT_THAT(input_type_bad_sig.Error().Message(),
              ::testing::HasSubstr("Signature not found: invalid_key_sig"));

  auto input_type =
      compiled_model.GetInputTensorType("invalid_input_type");
  ASSERT_FALSE(input_type.HasValue());
  EXPECT_THAT(
      input_type.Error().Message(),
      ::testing::HasSubstr("Input tensor not found: invalid_input_type"));

  auto output_type_bad_sig = compiled_model.GetOutputTensorType(
      "invalid_key_sig", "invalid_output_type");
  ASSERT_FALSE(output_type_bad_sig.HasValue());
  EXPECT_THAT(output_type_bad_sig.Error().Message(),
              ::testing::HasSubstr("Signature not found: invalid_key_sig"));

  auto output_type =
      compiled_model.GetOutputTensorType("invalid_output_type");
  ASSERT_FALSE(output_type.HasValue());
  EXPECT_THAT(
      output_type.Error().Message(),
      ::testing::HasSubstr("Output tensor not found: invalid_output_type"));
}

// Tests Compiled Model async API on CPU. In the CPU case, the async API should
// always return false.
TEST(CompiledModelTest, RunAsyncReturnsFalse) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Create input and output buffers.
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> input_buffers,
      compiled_model.CreateInputBuffers(compiled_model.DefaultSignatureKey()));
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> output_buffers,
      compiled_model.CreateOutputBuffers(compiled_model.DefaultSignatureKey()));

  // Confirm input and output buffers are host memory.
  EXPECT_THAT(input_buffers[0].BufferType(),
              IsOkAndHolds(TensorBufferType::kHostMemory));
  EXPECT_THAT(input_buffers[1].BufferType(),
              IsOkAndHolds(TensorBufferType::kHostMemory));
  EXPECT_THAT(output_buffers[0].BufferType(),
              IsOkAndHolds(TensorBufferType::kHostMemory));

  ASSERT_THAT(input_buffers, SizeIs(2));
  ASSERT_THAT(output_buffers, SizeIs(1));

  ASSERT_TRUE(input_buffers[0].Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffers[1].Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  // Execute model with input and output buffers.
  bool async;
  compiled_model.RunAsync(compiled_model.DefaultSignatureKey(), input_buffers,
                          output_buffers, async);
  // Since there are no events on the output buffers, async should be false.
  ASSERT_FALSE(async);

  // Check model output.
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[0], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
    for (auto i = 0; i < kTestOutputSize; ++i) {
      ABSL_LOG(INFO) << "Result: " << output[i] << "\t" << kTestOutputTensor[i];
    }
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
  }
}

TEST(CompiledModelTest, RunWithOptionsAndSchedulingInfoOverloads) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> input_buffers,
                              compiled_model.CreateInputBuffers());
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
                              compiled_model.CreateOutputBuffers());

  ASSERT_TRUE(input_buffers[0].Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffers[1].Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  LITERT_ASSERT_OK_AND_ASSIGN(Options run_options, Options::Create());

  LiteRtSchedulingInfo scheduling_info = {};
  scheduling_info.fields_mask = kLiteRtSchedulingInfoFieldJobPriority;
  scheduling_info.job_priority = 42;

  LITERT_ASSERT_OK(
      compiled_model.Run(input_buffers, output_buffers, &run_options));
  LITERT_ASSERT_OK(
      compiled_model.Run(input_buffers, output_buffers, scheduling_info));
  LITERT_ASSERT_OK(compiled_model.SetSchedulingInfo(scheduling_info));
  LITERT_ASSERT_OK(compiled_model.ClearSchedulingInfo());

  bool async = true;
  LITERT_ASSERT_OK(compiled_model.RunAsync(compiled_model.DefaultSignatureKey(),
                                           input_buffers, output_buffers, async,
                                           &run_options));
  EXPECT_FALSE(async);

  async = true;
  LITERT_ASSERT_OK(compiled_model.RunAsync(
      /*signature_index=*/size_t(0), input_buffers, output_buffers, async,
      scheduling_info));
  EXPECT_FALSE(async);

  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input_buffer0,
                              compiled_model.CreateInputBuffer("arg0"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer input_buffer1,
                              compiled_model.CreateInputBuffer("arg1"));
  LITERT_ASSERT_OK_AND_ASSIGN(TensorBuffer output_buffer,
                              compiled_model.CreateOutputBuffer("tfl.add"));

  ASSERT_TRUE(input_buffer0.Write<float>(
      absl::MakeConstSpan(kTestInput0Tensor, kTestInput0Size)));
  ASSERT_TRUE(input_buffer1.Write<float>(
      absl::MakeConstSpan(kTestInput1Tensor, kTestInput1Size)));

  absl::flat_hash_map<absl::string_view, TensorBuffer> input_map;
  input_map["arg0"] = std::move(input_buffer0);
  input_map["arg1"] = std::move(input_buffer1);

  absl::flat_hash_map<absl::string_view, TensorBuffer> output_map;
  output_map["tfl.add"] = std::move(output_buffer);

  LITERT_ASSERT_OK(compiled_model.Run(input_map, output_map, &run_options));
  LITERT_ASSERT_OK(compiled_model.Run(compiled_model.DefaultSignatureKey(),
                                      input_map, output_map, scheduling_info));

  async = true;
  LITERT_ASSERT_OK(compiled_model.RunAsync(compiled_model.DefaultSignatureKey(),
                                           input_map, output_map, async,
                                           scheduling_info));
  EXPECT_FALSE(async);

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto lock_and_addr,
      litert::TensorBufferScopedLock::Create<const float>(
          output_map["tfl.add"], TensorBuffer::LockMode::kRead));
  auto output = absl::MakeSpan(lock_and_addr.second, kTestOutputSize);
  EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kTestOutputTensor));
}

TEST(CompiledModelTest, DispatchAnnotations) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  LITERT_ASSERT_OK(compiled_model.SetDispatchAnnotation(0, "priority", "high"));

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto value_by_index, compiled_model.GetDispatchAnnotation(0, "priority"));
  ASSERT_TRUE(value_by_index.has_value());
  EXPECT_EQ(*value_by_index, "high");

  LITERT_ASSERT_OK(
      compiled_model.SetDispatchAnnotation("memory_type", "shared"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      auto value_by_default_signature,
      compiled_model.GetDispatchAnnotation("memory_type"));
  ASSERT_TRUE(value_by_default_signature.has_value());
  EXPECT_EQ(*value_by_default_signature, "shared");

  LITERT_ASSERT_OK(compiled_model.SetDispatchAnnotation(
      compiled_model.DefaultSignatureKey(), "precision", "fp16"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      auto value_by_signature_name,
      compiled_model.GetDispatchAnnotation(compiled_model.DefaultSignatureKey(),
                                           "precision"));
  ASSERT_TRUE(value_by_signature_name.has_value());
  EXPECT_EQ(*value_by_signature_name, "fp16");

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto missing_value, compiled_model.GetDispatchAnnotation(0, "missing"));
  EXPECT_FALSE(missing_value.has_value());

  LITERT_ASSERT_OK(
      compiled_model.SetDispatchAnnotation(0, "to_remove", "value"));
  LITERT_ASSERT_OK(compiled_model.RemoveDispatchAnnotation(0, "to_remove"));
  LITERT_ASSERT_OK_AND_ASSIGN(
      auto removed_value, compiled_model.GetDispatchAnnotation(0, "to_remove"));
  EXPECT_FALSE(removed_value.has_value());

  LITERT_ASSERT_OK(compiled_model.RemoveDispatchAnnotation("never_existed"));
}

TEST(CompiledModelTest, DispatchAnnotationsInvalidSignature) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  EXPECT_FALSE(
      compiled_model.SetDispatchAnnotation(999, "key", "value").HasValue());
  EXPECT_FALSE(compiled_model.GetDispatchAnnotation(999, "key").HasValue());
  EXPECT_FALSE(compiled_model.RemoveDispatchAnnotation(999, "key").HasValue());

  EXPECT_FALSE(
      compiled_model
          .SetDispatchAnnotation("nonexistent_signature", "key", "value")
          .HasValue());
  EXPECT_FALSE(
      compiled_model.GetDispatchAnnotation("nonexistent_signature", "key")
          .HasValue());
  EXPECT_FALSE(
      compiled_model.RemoveDispatchAnnotation("nonexistent_signature", "key")
          .HasValue());
}

TEST(CompiledModelTest, ResizeInputTensorWithDynamicModel) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env,
                            testing::GetTestFilePath(kDynamicModelFileName),
                            HwAccelerators::kCpu));

  // Test resizing input tensor by index - resize from (?, 2, 3) to (1, 2, 3)
  {
    const std::vector<int> new_dims = {1, 2, 3};
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        /*input_index=*/size_t(0), absl::MakeConstSpan(new_dims)));

    // Verify buffer requirements after resize
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements requirements,
        compiled_model.GetInputBufferRequirements(/*input_index=*/size_t(0)));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t buffer_size, requirements.BufferSize());
    EXPECT_EQ(buffer_size, 1 * 2 * 3 * sizeof(float));
  }

  // Test resizing input tensor by name - resize to (2, 2, 3)
  {
    const std::vector<int> new_dims = {2, 2, 3};
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        /*input_name=*/"arg0", absl::MakeConstSpan(new_dims)));

    // Verify buffer requirements after resize
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements requirements,
        compiled_model.GetInputBufferRequirements(/*input_name=*/"arg0"));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t buffer_size, requirements.BufferSize());
    EXPECT_EQ(buffer_size, 2 * 2 * 3 * sizeof(float));
  }

  // Test resizing with signature index
  {
    size_t signature_index = 0;
    const std::vector<int> new_dims = {3, 2, 3};
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        signature_index, /*input_index=*/size_t(0),
        absl::MakeConstSpan(new_dims)));

    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements requirements,
        compiled_model.GetInputBufferRequirements(signature_index,
                                                  /*input_index=*/size_t(0)));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t buffer_size, requirements.BufferSize());
    EXPECT_EQ(buffer_size, 3 * 2 * 3 * sizeof(float));
  }

  // Test execution after resize, using tensor buffer APIs.
  {
    // Resize to specific shape for execution
    const std::vector<int> exec_dims = {1, 2, 3};
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        /*input_index=*/size_t(0), absl::MakeConstSpan(exec_dims)));
    LITERT_ASSERT_OK(compiled_model.ResizeInputTensor(
        /*input_index=*/size_t(1), absl::MakeConstSpan(exec_dims)));

    LITERT_ASSERT_OK_AND_ASSIGN(
        Layout input_layout0,
        compiled_model.GetInputTensorLayout(
            /*signature_index=*/size_t(0), /*input_index=*/size_t(0)));
    EXPECT_THAT(input_layout0.Dimensions(),
                ElementsAre(exec_dims[0], exec_dims[1], exec_dims[2]));
    LITERT_ASSERT_OK_AND_ASSIGN(
        Layout input_layout1,
        compiled_model.GetInputTensorLayout(
            /*signature_index=*/size_t(0), /*input_index=*/size_t(1)));
    EXPECT_THAT(input_layout1.Dimensions(),
                ElementsAre(exec_dims[0], exec_dims[1], exec_dims[2]));

    // Create input and output buffers
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements req0,
        compiled_model.GetInputBufferRequirements(size_t(0)));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t size0, req0.BufferSize());
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements req1,
        compiled_model.GetInputBufferRequirements(size_t(1)));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t size1, req1.BufferSize());

    // Get the element type from the original model.
    LITERT_ASSERT_OK_AND_ASSIGN(const RankedTensorType& type0,
                                compiled_model.GetInputTensorType(0, "arg0"));
    LITERT_ASSERT_OK_AND_ASSIGN(const RankedTensorType& type1,
                                compiled_model.GetInputTensorType(0, "arg1"));

    // Manually create a new RankedTensorType with the new shape.
    auto new_type0 = RankedTensorType(
        type0.ElementType(),
        Layout(Dimensions(exec_dims.begin(), exec_dims.end())));
    auto new_type1 = RankedTensorType(
        type1.ElementType(),
        Layout(Dimensions(exec_dims.begin(), exec_dims.end())));

    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBuffer input_buffer0,
        TensorBuffer::CreateManaged(env, TensorBufferType::kHostMemory,
                                    new_type0, size0));
    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBuffer input_buffer1,
        TensorBuffer::CreateManaged(env, TensorBufferType::kHostMemory,
                                    new_type1, size1));
    std::vector<TensorBuffer> input_buffers;
    input_buffers.push_back(std::move(input_buffer0));
    input_buffers.push_back(std::move(input_buffer1));

    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBufferRequirements out_req,
        compiled_model.GetOutputBufferRequirements(size_t(0)));
    LITERT_ASSERT_OK_AND_ASSIGN(size_t out_size, out_req.BufferSize());
    LITERT_ASSERT_OK_AND_ASSIGN(
        const RankedTensorType& out_type,
        compiled_model.GetOutputTensorType(0, "tfl.add"));

    // Get the output tensor shape from the compiled model.
    LITERT_ASSERT_OK_AND_ASSIGN(
        std::vector<Layout> output_tensor_layouts,
        compiled_model.GetOutputTensorLayouts(
            /*signature_index=*/size_t(0), /*update_allocation=*/true));

    ASSERT_EQ(output_tensor_layouts.size(), 1);

    auto new_out_type = RankedTensorType(out_type.ElementType(),
                                         std::move(output_tensor_layouts[0]));

    LITERT_ASSERT_OK_AND_ASSIGN(
        TensorBuffer output_buffer,
        TensorBuffer::CreateManaged(env, TensorBufferType::kHostMemory,
                                    new_out_type, out_size));

    std::vector<TensorBuffer> output_buffers;
    output_buffers.push_back(std::move(output_buffer));

    // Fill input buffers with test data
    const float test_input[] = {1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f};
    ASSERT_TRUE(input_buffers[0].Write<float>(absl::MakeConstSpan(test_input)));
    ASSERT_TRUE(input_buffers[1].Write<float>(absl::MakeConstSpan(test_input)));

    // Execute model
    LITERT_ASSERT_OK(compiled_model.Run(input_buffers, output_buffers));
    // Verify output
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[0], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, 6);

    // For an add operation, expected output is input + input
    const float expected_output[] = {2.0f, 4.0f, 6.0f, 8.0f, 10.0f, 12.0f};
    EXPECT_THAT(output, Pointwise(FloatNear(1e-5), expected_output));
  }
}
// Test error reporter with BufferErrorReporter mode
TEST(CompiledModelTest, ErrorReporterBufferMode) {
  if constexpr (!kSupportsErrorReporterApi) {
    GTEST_SKIP() << "ReportError is not implemented on Windows.";
  }
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create compilation options with BufferErrorReporter
  LITERT_ASSERT_OK_AND_ASSIGN(Options compilation_options, Options::Create());
  compilation_options.SetHardwareAccelerators(HwAccelerators::kCpu);

  // Configure BufferErrorReporter mode
  LITERT_ASSERT_OK_AND_ASSIGN(auto& runtime_options,
                              compilation_options.GetRuntimeOptions());
  LITERT_ASSERT_OK(
      runtime_options.SetErrorReporterMode(kLiteRtErrorReporterModeBuffer));

  // Create CompiledModel with BufferErrorReporter
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            compilation_options));

  // Test 1: Basic ReportError functionality
  LITERT_ASSERT_OK(compiled_model.ReportError("Simple error message"));

  // Test 2: ReportError with formatting - integers
  LITERT_ASSERT_OK(compiled_model.ReportError("Error code: %d", 404));

  // Test 3: ReportError with formatting - strings
  LITERT_ASSERT_OK(
      compiled_model.ReportError("Failed operation: %s", "tensor_allocation"));

  // Test 4: ReportError with multiple format specifiers
  LITERT_ASSERT_OK(compiled_model.ReportError(
      "Complex error: %s at line %d with value %f", "overflow", 42, 3.14159));

  // Test 5: GetErrorMessages - verify all messages are captured
  LITERT_ASSERT_OK_AND_ASSIGN(std::string error_messages,
                              compiled_model.GetErrorMessages());
  EXPECT_THAT(error_messages, ::testing::HasSubstr("Simple error message"));
  EXPECT_THAT(error_messages, ::testing::HasSubstr("Error code: 404"));
  EXPECT_THAT(error_messages,
              ::testing::HasSubstr("Failed operation: tensor_allocation"));
  EXPECT_THAT(error_messages,
              ::testing::HasSubstr(
                  "Complex error: overflow at line 42 with value 3.14"));

  // Test 6: ClearErrors functionality
  LITERT_ASSERT_OK(compiled_model.ClearErrors());

  // Test 7: Verify errors are cleared
  LITERT_ASSERT_OK_AND_ASSIGN(error_messages,
                              compiled_model.GetErrorMessages());
  EXPECT_TRUE(error_messages.empty());

  // Test 8: Add errors after clearing
  LITERT_ASSERT_OK(compiled_model.ReportError("New error after clear"));
  LITERT_ASSERT_OK_AND_ASSIGN(error_messages,
                              compiled_model.GetErrorMessages());
  EXPECT_THAT(error_messages, ::testing::HasSubstr("New error after clear"));
  EXPECT_THAT(error_messages,
              ::testing::Not(::testing::HasSubstr("Simple error message")));
}

// Test error reporter with default StderrReporter mode
TEST(CompiledModelTest, ErrorReporterStderrMode) {
  if constexpr (!kSupportsErrorReporterApi) {
    GTEST_SKIP() << "ReportError is not implemented on Windows.";
  }
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel with default StderrReporter
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // ReportError should work with StderrReporter (prints to stderr)
  LITERT_ASSERT_OK(compiled_model.ReportError("This goes to stderr: %d", 123));

  // GetErrorMessages should fail with StderrReporter
  auto messages_result = compiled_model.GetErrorMessages();
  EXPECT_FALSE(messages_result.HasValue());

  // ClearErrors should fail with StderrReporter
  auto clear_result = compiled_model.ClearErrors();
  EXPECT_FALSE(clear_result.HasValue());
}

// Test error reporter with edge cases
TEST(CompiledModelTest, ErrorReporterEdgeCases) {
  if constexpr (!kSupportsErrorReporterApi) {
    GTEST_SKIP() << "ReportError is not implemented on Windows.";
  }
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create compilation options with BufferErrorReporter
  LITERT_ASSERT_OK_AND_ASSIGN(Options compilation_options, Options::Create());
  compilation_options.SetHardwareAccelerators(HwAccelerators::kCpu);

  LITERT_ASSERT_OK_AND_ASSIGN(auto& runtime_options,
                              compilation_options.GetRuntimeOptions());
  LITERT_ASSERT_OK(
      runtime_options.SetErrorReporterMode(kLiteRtErrorReporterModeBuffer));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            compilation_options));

  // Test 1: Empty error message
  LITERT_ASSERT_OK(compiled_model.ReportError(""));

  // Test 2: Very long error message
  std::string long_message(1000, 'A');
  LITERT_ASSERT_OK(compiled_model.ReportError("%s", long_message.c_str()));

  // Test 3: Special characters in error message
  LITERT_ASSERT_OK(
      compiled_model.ReportError("Special chars: \n\t\r %% %s", "test"));

  // Test 4: Multiple consecutive clears
  LITERT_ASSERT_OK(compiled_model.ClearErrors());
  LITERT_ASSERT_OK(compiled_model.ClearErrors());

  // Test 5: GetErrorMessages when no errors reported
  LITERT_ASSERT_OK_AND_ASSIGN(std::string error_messages,
                              compiled_model.GetErrorMessages());
  EXPECT_TRUE(error_messages.empty());

  // Test 6: Large number of error messages
  for (int i = 0; i < 100; ++i) {
    LITERT_ASSERT_OK(compiled_model.ReportError("Error number %d", i));
  }

  LITERT_ASSERT_OK_AND_ASSIGN(error_messages,
                              compiled_model.GetErrorMessages());
  // Verify we have all 100 error messages
  for (int i = 0; i < 100; ++i) {
    EXPECT_THAT(error_messages,
                ::testing::HasSubstr(absl::StrFormat("Error number %d", i)));
  }
}

// Test error reporter with None mode (no error reporting)
TEST(CompiledModelTest, ErrorReporterNoneMode) {
  if constexpr (!kSupportsErrorReporterApi) {
    GTEST_SKIP() << "ReportError is not implemented on Windows.";
  }
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create compilation options with no error reporter
  LITERT_ASSERT_OK_AND_ASSIGN(Options compilation_options, Options::Create());
  compilation_options.SetHardwareAccelerators(HwAccelerators::kCpu);

  LITERT_ASSERT_OK_AND_ASSIGN(auto& runtime_options,
                              compilation_options.GetRuntimeOptions());
  LITERT_ASSERT_OK(
      runtime_options.SetErrorReporterMode(kLiteRtErrorReporterModeNone));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            compilation_options));

  // ReportError should work but do nothing
  LITERT_ASSERT_OK(
      compiled_model.ReportError("This should be ignored: %d", 999));

  // GetErrorMessages should fail with None mode
  auto messages_result = compiled_model.GetErrorMessages();
  EXPECT_FALSE(messages_result.HasValue());

  // ClearErrors should fail with None mode
  auto clear_result = compiled_model.ClearErrors();
  EXPECT_FALSE(clear_result.HasValue());
}

// Test for constant output tensor support
TEST(CompiledModelTest, ConstantOutputTensor) {
  // Environment setup
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel with constant output tensor.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(
          env, testing::GetTestFilePath(kConstantOutputTensorModelFileName),
          HwAccelerators::kCpu));

  EXPECT_EQ(compiled_model.GetNumSignatures(), 1);
  size_t signature_index = 0;

  // Create input and output buffers
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> input_buffers,
      compiled_model.CreateInputBuffers(signature_index));
  ASSERT_EQ(input_buffers.size(), 1);

  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<TensorBuffer> output_buffers,
      compiled_model.CreateOutputBuffers(signature_index));
  ASSERT_EQ(output_buffers.size(), 2);  // normal_output and constant_output

  // Set input values
  const float input_data[] = {5.0f, 10.0f};
  ASSERT_TRUE(
      input_buffers[0].Write<float>(absl::MakeConstSpan(input_data, 2)));

  // Run the model
  LITERT_ASSERT_OK(
      compiled_model.Run(signature_index, input_buffers, output_buffers));

  // Note: TFLite might reorder outputs - check which is which by size
  // The constant output has 4 elements, the normal output has 2 elements
  int constant_output_idx = -1;
  int normal_output_idx = -1;

  // Determine which output is which based on size
  for (int i = 0; i < 2; i++) {
    LITERT_ASSERT_OK_AND_ASSIGN(auto size, output_buffers[i].Size());
    if (size == 4 * sizeof(float)) {
      constant_output_idx = i;
    } else if (size == 2 * sizeof(float)) {
      normal_output_idx = i;
    }
  }

  ASSERT_NE(constant_output_idx, -1) << "Could not find constant output";
  ASSERT_NE(normal_output_idx, -1) << "Could not find normal output";

  // Check normal output (should be [10.0, 20.0])
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[normal_output_idx], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, 2);
    EXPECT_THAT(output,
                ElementsAre(FloatNear(10.0f, 1e-5), FloatNear(20.0f, 1e-5)));
  }

  // Check constant output (should always be [1.0, 2.0, 3.0, 4.0])
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr, litert::TensorBufferScopedLock::Create<const float>(
                                output_buffers[constant_output_idx],
                                TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, 4);
    EXPECT_THAT(output,
                ElementsAre(FloatNear(1.0f, 1e-5), FloatNear(2.0f, 1e-5),
                            FloatNear(3.0f, 1e-5), FloatNear(4.0f, 1e-5)));
    ABSL_LOG(INFO) << "Constant output tensor test passed. Values: ["
                   << output[0] << ", " << output[1] << ", " << output[2]
                   << ", " << output[3] << "]";
  }

  // Run again with different input to verify constant output doesn't change
  const float input_data2[] = {100.0f, 200.0f};
  ASSERT_TRUE(
      input_buffers[0].Write<float>(absl::MakeConstSpan(input_data2, 2)));
  LITERT_ASSERT_OK(
      compiled_model.Run(signature_index, input_buffers, output_buffers));

  // Check normal output changed (should be [200.0, 400.0])
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr,
        litert::TensorBufferScopedLock::Create<const float>(
            output_buffers[normal_output_idx], TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, 2);
    EXPECT_THAT(output,
                ElementsAre(FloatNear(200.0f, 1e-5), FloatNear(400.0f, 1e-5)))
        << "Normal output should reflect new input values";
  }

  // Check that constant output is still [1.0, 2.0, 3.0, 4.0]
  {
    LITERT_ASSERT_OK_AND_ASSIGN(
        auto lock_and_addr, litert::TensorBufferScopedLock::Create<const float>(
                                output_buffers[constant_output_idx],
                                TensorBuffer::LockMode::kRead));
    auto output = absl::MakeSpan(lock_and_addr.second, 4);
    EXPECT_THAT(output,
                ElementsAre(FloatNear(1.0f, 1e-5), FloatNear(2.0f, 1e-5),
                            FloatNear(3.0f, 1e-5), FloatNear(4.0f, 1e-5)))
        << "Constant output should not change with different inputs";
  }
}

TEST(CompiledModelTest, ExternalTensorBinding) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create weight tensor buffer.
  alignas(LITERT_HOST_MEMORY_BUFFER_ALIGNMENT) float kWeightTensor[] = {1.0f,
                                                                        2.0f};
  constexpr int kWeightSize = sizeof(kWeightTensor);

  // Create Compilation options and bind weight tensor.
  LITERT_ASSERT_OK_AND_ASSIGN(Options compilation_options, Options::Create());
  compilation_options.SetHardwareAccelerators(HwAccelerators::kCpu);
  LITERT_ASSERT_OK(compilation_options.AddExternalTensorBinding(
      /*signature_name=*/"", /*tensor_name=*/"arg1", kWeightTensor,
      kWeightSize));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            compilation_options));

  // Create and fill input and output buffers.
  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBuffer> output_buffers,
                              compiled_model.CreateOutputBuffers());
  absl::flat_hash_map<absl::string_view, TensorBuffer> output_map;
  ASSERT_THAT(output_buffers, SizeIs(1));
  output_map["tfl.add"] = std::move(output_buffers[0]);

  absl::flat_hash_map<absl::string_view, TensorBuffer> input_map;
  float kInputTensor[] = {1.0f, 1.0f};
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBuffer arg0_buffer,
      TensorBuffer::CreateManaged(
          env, TensorBufferType::kHostMemory,
          RankedTensorType(ElementType::Float32, Layout(Dimensions({2}))),
          sizeof(kInputTensor)));
  LITERT_ASSERT_OK(
      arg0_buffer.Write<float>(absl::MakeConstSpan(kInputTensor, 2)));
  input_map["arg0"] = std::move(arg0_buffer);

  // Execute model with input and output buffers.
  LITERT_ASSERT_OK(compiled_model.Run(input_map, output_map));

  // Check model output.
  LITERT_ASSERT_OK_AND_ASSIGN(
      auto lock_and_addr,
      litert::TensorBufferScopedLock::Create<const float>(
          output_map["tfl.add"], TensorBuffer::LockMode::kRead));
  auto output = absl::MakeSpan(lock_and_addr.second, 2);
  constexpr float kExpectedOutput[] = {2.0f, 3.0f};
  EXPECT_THAT(output, Pointwise(FloatNear(1e-5), kExpectedOutput));
}

TEST(CompiledModelTest, ResizeInputTensorNonStrictAllowsStaticShapes) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, Environment::Create({}));
  LITERT_ASSERT_OK_AND_ASSIGN(Options compilation_options, Options::Create());
  compilation_options.SetHardwareAccelerators(HwAccelerators::kCpu);
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            compilation_options));

  const std::vector<int> new_dims = {4545};
  LITERT_ASSERT_ERROR(compiled_model.ResizeInputTensor(
      /*input_index=*/size_t(0), absl::MakeConstSpan(new_dims)));
  LITERT_ASSERT_OK(compiled_model.ResizeInputTensorNonStrict(
      /*input_index=*/size_t(0), absl::MakeConstSpan(new_dims)));
}

TEST(CompiledModelTest, GetBufferRequirementsDetailed) {
  // Environment setup.
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Create CompiledModel.
  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, testing::GetTestFilePath(kModelFileName),
                            HwAccelerators::kCpu));

  // Check input buffer requirements.
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements input_requirements,
      compiled_model.GetInputBufferRequirements(/*input_name=*/"arg0"));

  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBufferType> input_types,
                              input_requirements.SupportedTypes());
  EXPECT_THAT(input_types, ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(size_t input_size,
                              input_requirements.BufferSize());
  EXPECT_EQ(input_size, kTestInput0Size * sizeof(float));

  LITERT_ASSERT_OK_AND_ASSIGN(size_t input_alignment,
                              input_requirements.Alignment());
  EXPECT_GE(input_alignment, 0);

  LITERT_ASSERT_OK_AND_ASSIGN(auto input_strides, input_requirements.Strides());

  EXPECT_EQ(input_strides.size(), 0);

  // Check output buffer requirements.
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBufferRequirements output_requirements,
      compiled_model.GetOutputBufferRequirements(/*output_name=*/"tfl.add"));

  LITERT_ASSERT_OK_AND_ASSIGN(std::vector<TensorBufferType> output_types,
                              output_requirements.SupportedTypes());
  EXPECT_THAT(output_types, ElementsAre(TensorBufferType::kHostMemory));

  LITERT_ASSERT_OK_AND_ASSIGN(size_t output_size,
                              output_requirements.BufferSize());
  EXPECT_EQ(output_size, kTestOutputSize * sizeof(float));

  LITERT_ASSERT_OK_AND_ASSIGN(size_t output_alignment,
                              output_requirements.Alignment());
  EXPECT_GE(output_alignment, 0);

  LITERT_ASSERT_OK_AND_ASSIGN(auto output_strides,
                              output_requirements.Strides());
  EXPECT_EQ(output_strides.size(), 0);
}

TEST(CompiledModelTest, StringInput) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  // Load the gather_string model.
  std::string model_path = testing::GetTestFilePath("gather_string.tflite");

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(env, model_path, HwAccelerators::kCpu));

  // Check signatures.
  LITERT_ASSERT_OK_AND_ASSIGN(auto input_names,
                              compiled_model.GetSignatureInputNames());
  EXPECT_THAT(input_names, ElementsAre("input", "indices"));

  LITERT_ASSERT_OK_AND_ASSIGN(auto output_names,
                              compiled_model.GetSignatureOutputNames());
  EXPECT_THAT(output_names, ElementsAre("output"));

  // Prepare inputs.
  // 1. indices: [1, 2, 3] (int64)
  std::vector<int64_t> indices_data = {3, 9, 5};
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBuffer indices_buffer,
      TensorBuffer::CreateManaged(
          env,
          // We're using CPU Accelerator and the model only supports CPU.
          TensorBufferType::kHostMemory,
          RankedTensorType(ElementType::Int64, Layout(Dimensions({3}))),
          indices_data.size() * sizeof(int64_t)));
  LITERT_ASSERT_OK(
      indices_buffer.Write<int64_t>(absl::MakeConstSpan(indices_data)));

  // 2. input: 10 words (string)
  std::vector<std::string> input_strings = {
      "clean",  "efficient", "fast",   "Hello",  "intelligence",
      "LiteRT", "on-device", "robust", "simple", "world",
  };

  // Use the new utility to create and populate the input TensorBuffer
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBuffer input_buffer,
      litert::util::CreateTensorBufferFromStrings(env, input_strings));

  // Prepare output buffer.
  // We expect 3 strings.
  std::vector<std::string> expected_outputs = {"Hello", "world", "LiteRT"};

  // Allocate a larger buffer to be safe, e.g. 200 bytes.
  size_t kOutputBufferSize = 200;
  LITERT_ASSERT_OK_AND_ASSIGN(
      TensorBuffer output_buffer,
      TensorBuffer::CreateManaged(
          env, TensorBufferType::kHostMemory,
          RankedTensorType(ElementType::TfString,
                           Layout(Dimensions({static_cast<int32_t>(
                               expected_outputs.size())}))),
          kOutputBufferSize));

  // Run the model.
  absl::flat_hash_map<absl::string_view, TensorBuffer> input_map;
  input_map["indices"] = std::move(indices_buffer);
  input_map["input"] = std::move(input_buffer);

  absl::flat_hash_map<absl::string_view, TensorBuffer> output_map;
  output_map["output"] = std::move(output_buffer);

  LITERT_ASSERT_OK(compiled_model.Run(input_map, output_map));

  // Verify output using the new utility
  LITERT_ASSERT_OK_AND_ASSIGN(
      std::vector<std::string> actual_outputs,
      litert::util::GetStringsFromTensorBuffer(output_map["output"]));

  EXPECT_THAT(actual_outputs, ElementsAreArray(expected_outputs));
}

TEST(CompiledModelTest, QuantizationAccessors) {
  LITERT_ASSERT_OK_AND_ASSIGN(Environment env, litert::Environment::Create({}));

  LITERT_ASSERT_OK_AND_ASSIGN(
      CompiledModel compiled_model,
      CompiledModel::Create(
          env, testing::GetTestFilePath("simple_quantized_ops.tflite"),
          HwAccelerators::kCpu));

  LITERT_ASSERT_OK_AND_ASSIGN(QuantizationTypeId input_q_type,
                              compiled_model.GetInputTensorQTypeId(
                                  /*signature_index=*/0, /*input_index=*/0));
  EXPECT_EQ(input_q_type, QuantizationTypeId::PerTensor);

  LITERT_ASSERT_OK_AND_ASSIGN(
      QuantizationPerTensor input_per_tensor_q,
      compiled_model.GetInputTensorPerTensorQuantization(/*signature_index=*/0,
                                                         /*input_index=*/0));
  EXPECT_GT(input_per_tensor_q.scale, 0.0f);

  LITERT_ASSERT_OK_AND_ASSIGN(auto input_names,
                              compiled_model.GetSignatureInputNames());
  ASSERT_FALSE(input_names.empty());
  LITERT_ASSERT_OK_AND_ASSIGN(
      QuantizationTypeId input_q_type_by_name,
      compiled_model.GetInputTensorQTypeId(input_names[0]));
  EXPECT_EQ(input_q_type_by_name, QuantizationTypeId::PerTensor);

  LITERT_ASSERT_OK_AND_ASSIGN(QuantizationTypeId output_q_type,
                              compiled_model.GetOutputTensorQTypeId(
                                  /*signature_index=*/0, /*output_index=*/0));
  EXPECT_EQ(output_q_type, QuantizationTypeId::PerTensor);

  LITERT_ASSERT_OK_AND_ASSIGN(
      QuantizationPerTensor output_per_tensor_q,
      compiled_model.GetOutputTensorPerTensorQuantization(/*signature_index=*/0,
                                                          /*output_index=*/0));
  EXPECT_GT(output_per_tensor_q.scale, 0.0f);

  LITERT_ASSERT_OK_AND_ASSIGN(auto output_names,
                              compiled_model.GetSignatureOutputNames());
  ASSERT_FALSE(output_names.empty());
  LITERT_ASSERT_OK_AND_ASSIGN(
      QuantizationTypeId output_q_type_by_name,
      compiled_model.GetOutputTensorQTypeId(output_names[0]));
  EXPECT_EQ(output_q_type_by_name, QuantizationTypeId::PerTensor);
}

}  // namespace
}  // namespace litert
