// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "litert/core/model/model.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "absl/container/flat_hash_set.h"  // from @com_google_absl
#include "absl/log/absl_check.h"  // from @com_google_absl
#include "absl/strings/str_cat.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#include "litert/c/internal/litert_logging.h"
#include "litert/c/litert_common.h"
#include "litert/c/litert_layout.h"
#include "litert/c/litert_model_types.h"
#include "litert/c/litert_op_code.h"
#include "litert/cc/internal/litert_consts.h"
#include "litert/cc/internal/litert_detail.h"
#include "litert/cc/litert_buffer_ref.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/core/build_stamp.h"
#include "litert/core/util/flatbuffer_tools.h"
#include "tflite/converter/schema/schema_generated.h"

using ::litert::internal::AttachInput;
using ::litert::internal::AttachOutput;
using ::litert::internal::DCE;
using ::litert::internal::Drop;
using ::litert::internal::TflBuffer;
using ::litert::internal::TflBufferPtr;
using ::litert::internal::TflOpCode;
using ::litert::internal::TflOpCodePtr;
using ::litert::internal::TflOptions;
using ::litert::internal::TflOptions2;

std::optional<LiteRtModelT::BuildStamp> GetBuildStamp(
    const LiteRtModelT& model) {
  using ::litert::internal::kLiteRtBuildStampKey;
  using ::litert::internal::ParseBuildStamp;

  auto stamp_meta = model.FindMetadata(kLiteRtBuildStampKey);
  if (!stamp_meta) {
    return std::nullopt;
  }
  auto parsed_stamp = ParseBuildStamp(*stamp_meta);
  if (!parsed_stamp) {
    return std::nullopt;
  }
  auto [soc_manufacturer, soc_model] = *parsed_stamp;
  return LiteRtModelT::BuildStamp{soc_manufacturer, soc_model};
}

bool IsCompiled(const LiteRtModelT& model) {
  return GetBuildStamp(model).has_value();
}

std::optional<std::string> GetCustomOpCode(const LiteRtModelT& model,
                                           const LiteRtOpT& op) {
  if (op.OpCode() != kLiteRtOpCodeTflCustom) {
    return {};
  }
  const auto& tfl_op_codes = litert::internal::GetTflOpCodes(model);
  const auto tfl_op_code_ind = litert::internal::GetTflOpCodeInd(op);
  return tfl_op_codes[tfl_op_code_ind]->custom_code;
}

TensorType MakeRankedTensorType(LiteRtElementType element_type,
                                absl::Span<const int32_t> dims) {
  TensorType tensor_type;
  tensor_type.first = kLiteRtRankedTensorType;
  auto& ranked = tensor_type.second.ranked_tensor_type;
  ranked.element_type = element_type;
  ABSL_DCHECK_LE(dims.size(), LITERT_TENSOR_MAX_RANK);
  ranked.layout.rank = dims.size();
  std::copy(dims.begin(), dims.end(), ranked.layout.dimensions);
  // Strides not yet supported.
  ranked.layout.has_strides = false;
  return tensor_type;
}

Quantization MakePerTensorQuantization(float scale, int64_t zero_point) {
  Quantization quantization;
  quantization.first = kLiteRtQuantizationPerTensor;
  quantization.second.per_tensor.scale = scale;
  quantization.second.per_tensor.zero_point = zero_point;
  return quantization;
}

LiteRtSignatureT MakeDefaultSignature(LiteRtSubgraph subgraph) {
  std::vector<std::string> input_names;
  std::vector<LiteRtTensor> input_tensors;
  input_names.reserve(subgraph->NumInputs());
  input_tensors.reserve(subgraph->NumInputs());
  for (auto* tensor : subgraph->Inputs()) {
    input_names.push_back(std::string(tensor->Name()));
    input_tensors.push_back(tensor);
  }

  std::vector<std::string> output_names;
  std::vector<LiteRtTensor> output_tensors;
  output_names.reserve(subgraph->NumOutputs());
  output_tensors.reserve(subgraph->NumOutputs());
  for (auto* tensor : subgraph->Outputs()) {
    output_names.push_back(std::string(tensor->Name()));
    output_tensors.push_back(tensor);
  }

  std::string name(litert::kDefaultSignatureKey);
  return LiteRtSignatureT(subgraph, std::move(input_names),
                          std::move(input_tensors), std::move(output_names),
                          std::move(output_tensors), std::move(name));
}

::litert::Expected<LiteRtSubgraph> LookupSubgraph(
    const LiteRtModelT& model, absl::string_view signature_key) {
  auto sig = model.FindSignature(signature_key);
  if (!sig) {
    return sig.Error();
  }
  return &sig->get().GetSubgraph();
}

::litert::Expected<void> PruneModelToSignatures(
    LiteRtModelT& model,
    absl::Span<const absl::string_view> signature_keys) {
  if (signature_keys.empty()) {
    return {};
  }

  absl::flat_hash_set<std::string> retained_keys;
  retained_keys.reserve(signature_keys.size());
  for (absl::string_view key : signature_keys) {
    if (!model.FindSignature(key)) {
      return ::litert::Unexpected(
          kLiteRtStatusErrorNotFound,
          std::string("Cannot retain missing model signature: ") +
              std::string(key));
    }
    retained_keys.insert(std::string(key));
  }

  const auto subgraphs = model.Subgraphs();
  std::unordered_map<const LiteRtSubgraphT*, size_t> subgraph_indices;
  subgraph_indices.reserve(subgraphs.size());
  for (size_t i = 0; i < subgraphs.size(); ++i) {
    subgraph_indices.emplace(subgraphs[i], i);
  }

  std::vector<bool> reachable(subgraphs.size(), false);
  std::vector<size_t> pending;
  for (LiteRtSignature signature : model.Signatures()) {
    if (!retained_keys.contains(signature->Key())) {
      continue;
    }
    const auto it = subgraph_indices.find(&signature->GetSubgraph());
    if (it == subgraph_indices.end()) {
      return ::litert::Unexpected(kLiteRtStatusErrorRuntimeFailure,
                                  "Signature references an unknown subgraph");
    }
    if (!reachable[it->second]) {
      reachable[it->second] = true;
      pending.push_back(it->second);
    }
  }

  while (!pending.empty()) {
    const size_t subgraph_index = pending.back();
    pending.pop_back();
    for (LiteRtOp op : subgraphs[subgraph_index]->Ops()) {
      if (litert::internal::GetTflOptions2(*op).type ==
          tflite::BuiltinOptions2_StablehloCaseOptions) {
        return ::litert::Unexpected(
            kLiteRtStatusErrorUnsupported,
            "Signature pruning does not support StableHLO case subgraph "
            "references");
      }
      if (op->OpCode() == kLiteRtOpCodeShloComposite) {
        const auto* options = litert::internal::GetTflOptions2(*op)
                                  .AsStableHLOCompositeOptions();
        if (options == nullptr || options->decomposition_subgraph_index < -1) {
          return ::litert::Unexpected(
              kLiteRtStatusErrorInvalidArgument,
              "StableHLO composite references an invalid subgraph");
        }
        if (options->decomposition_subgraph_index == -1) {
          return ::litert::Unexpected(
              kLiteRtStatusErrorUnsupported,
              "Signature pruning does not support a StableHLO composite "
              "without a decomposition subgraph");
        }
        if (static_cast<size_t>(options->decomposition_subgraph_index) >=
            subgraphs.size()) {
          return ::litert::Unexpected(
              kLiteRtStatusErrorInvalidArgument,
              "StableHLO composite references an invalid subgraph");
        }
        const size_t dependency =
            static_cast<size_t>(options->decomposition_subgraph_index);
        if (!reachable[dependency]) {
          reachable[dependency] = true;
          pending.push_back(dependency);
        }
        continue;
      }

      // TransferSubgraphTo currently remaps StableHLO composite references.
      // Reject other control-flow references instead of silently producing a
      // model with stale subgraph indices.
      switch (op->OpCode()) {
        case kLiteRtOpCodeTflIf:
        case kLiteRtOpCodeTflWhile:
        case kLiteRtOpCodeTflCallOnce:
        case kLiteRtOpCodeShloCustomCall:
        case kLiteRtOpCodeShloReduce:
        case kLiteRtOpCodeShloScatter:
        case kLiteRtOpCodeShloWindow:
        case kLiteRtOpCodeShloSort:
        case kLiteRtOpCodeShloWhile:
          return ::litert::Unexpected(
              kLiteRtStatusErrorUnsupported,
              "Signature pruning does not support this subgraph reference "
              "operator");
        default:
          break;
      }
    }
  }

  const size_t removed_signatures = model.RemoveSignaturesIf(
      [&retained_keys](const LiteRtSignatureT& signature) {
        return !retained_keys.contains(signature.Key());
      });
  std::vector<size_t> removed_subgraph_indices;
  for (size_t i = 0; i < reachable.size(); ++i) {
    if (!reachable[i]) {
      removed_subgraph_indices.push_back(i);
    }
  }
  LiteRtSubgraphT::Alloc removed_subgraphs;
  model.TransferSubgraphTo(removed_subgraphs,
                           std::move(removed_subgraph_indices));
  for (LiteRtSubgraph removed_subgraph : removed_subgraphs.Elements()) {
    for (LiteRtOp removed_op : removed_subgraph->Ops()) {
      model.RemoveAssetFromOp(removed_op);
    }
  }
  LITERT_LOG(LITERT_INFO,
             "Pruned model to %zu signatures and %zu reachable subgraphs "
             "(%zu signatures and %zu subgraphs removed)",
             model.Signatures().size(), model.Subgraphs().size(),
             removed_signatures, removed_subgraphs.Size());
  return {};
}

void LiteRtModelT::TransferSubgraphTo(LiteRtSubgraphT::Alloc& dest,
                                      std::vector<size_t> indices) {
  if (indices.empty()) {
    return;
  }
  std::sort(indices.begin(), indices.end());
  std::vector<int> new_inds(subgraphs_.Size(), 0);
  auto num_removed = 0;
  auto i = indices.begin();
  for (size_t j = 0; j < new_inds.size(); ++j) {
    if (i != indices.end() && *i == j) {
      ++num_removed;
      // Keep track of removed sgs just for dcheck.
      new_inds[j] = -1;
      ++i;
      continue;
    }
    new_inds[j] = j - num_removed;
  }

  ForEachIr(
      this, [&](LiteRtSubgraph subgraph, int32_t subgraph_index, LiteRtOp op) {
        if (op->OpCode() != kLiteRtOpCodeShloComposite) {
          return;
        }
        auto opts = litert::internal::TakeTflOptions2(*op);
        auto& decomp_ind =
            opts.AsStableHLOCompositeOptions()->decomposition_subgraph_index;
        // Skip update for decomposition ops that are already removed.
        if (decomp_ind != -1) {
          const auto new_ind = new_inds[decomp_ind];
          decomp_ind = new_ind;
        }
        litert::internal::SetTflOptions2(*op, std::move(opts));
      });
  subgraphs_.TransferTo(dest, std::move(indices));
}

LiteRtModelT LiteRtModelT::Yank(std::vector<size_t> indices) {
  LiteRtSubgraphT::Alloc yanked;
  TransferSubgraphTo(yanked, std::move(indices));

  LiteRtModelT res;
  res.TransferSubgraphsFrom(std::move(yanked));

  // Copy op codes.
  const auto& op_codes = litert::internal::GetTflOpCodes(*this);

  LiteRtModelT::TflOpCodes codes;
  codes.reserve(op_codes.size());
  for (const auto& op_code : op_codes) {
    codes.emplace_back(
        std::make_unique<::litert::internal::TflOpCode>(*op_code));
  }

  litert::internal::SetTflOpCodes(res, std::move(codes));

  res.buffer_manager_ = LiteRtModelT::StoredBufferManager(Buffers());

  return res;
}

LiteRtWeightsT& LiteRtBuilderT::BuildWeights(const uint8_t* data, size_t size,
                                             LiteRtTensor tensor) {
  ABSL_DCHECK(tensor != nullptr) << "Tensor is null";
  ABSL_DCHECK(IsTensorAllocated(tensor))
      << "Tensor is not built by the builder";
  ::litert::OwningBufferRef<uint8_t> weights_buffer(data, size);
  SetWeightsFromOwnedBuffer(tensor->Weights(), std::move(weights_buffer));
  return tensor->Weights();
}

LiteRtTensorT& LiteRtBuilderT::BuildTensor(const LiteRtWeightsT& weights,
                                           Quantization quantization,
                                           TensorType tensor_type,
                                           std::optional<std::string> name) {
  LiteRtTensorT& tensor = subgraph_.EmplaceTensor();
  tensor.SetType(tensor_type);
  tensor.SetQarams(quantization);
  if (weights.GetBufferManager() != nullptr) {
    // In case of the weights have been registered in any buffer manager,
    // reassign the tensor to the same buffer manager.
    tensor.Weights().SetBufferId(weights.GetBufferId());
    tensor.Weights().SetBufferManager(weights.GetBufferManager());
  } else {
    tensor.Weights().SetBufferManager(subgraph_.GetBufferManager());
  }
  if (name.has_value()) {
    tensor.SetName(*name);
  }
  allocated_tensors_.insert(&tensor);
  return tensor;
}

LiteRtTensorT& LiteRtBuilderT::BuildTensor(const LiteRtTensorT& src) {
  return BuildTensor(src.Weights(), src.Qparams(), src.Type(),
                     std::string(src.Name()));
}

LiteRtOpT& LiteRtBuilderT::BuildOp(LiteRtOpCode code,
                                   std::vector<LiteRtTensor> inputs,
                                   std::vector<LiteRtTensor> outputs) {
  LiteRtOpT& op = subgraph_.EmplaceOp();
  op.SetOpCode(code);
  // Only use AttachInput/AttachOutput for tensors that are allocated in the
  // builder.
  for (const LiteRtTensor& input : inputs) {
    ABSL_DCHECK(input != nullptr) << "Input tensor is null";
    if (IsTensorAllocated(input)) {
      AttachInput(input, op);
    } else {
      op.Inputs().push_back(input);
      subgraph_.Inputs().push_back(input);
    }
  }
  for (const LiteRtTensor& output : outputs) {
    ABSL_DCHECK(output != nullptr) << "Output tensor is null";
    if (IsTensorAllocated(output)) {
      AttachOutput(output, op);
    } else {
      op.Outputs().push_back(output);
      subgraph_.Outputs().push_back(output);
    }
  }
  // LITERT_LOG(LITERT_INFO, "BuildOp: %d", code);
  allocated_ops_.insert(&op);
  return op;
}

LiteRtOpT& LiteRtBuilderT::BuildOp(LiteRtOpT& src,
                                   std::vector<LiteRtTensor> inputs,
                                   std::vector<LiteRtTensor> outputs) {
  return BuildOp(src.OpCode(), inputs, outputs);
}

void LiteRtBuilderT::EraseOp(LiteRtOp opToErase) {
  ABSL_DCHECK(opToErase != nullptr) << "Op to erase is null";
  erases_.insert(opToErase);
}

void LiteRtBuilderT::ApplyChanges(LiteRtSubgraphT* subgraph_to_apply) {
  // Remove all ops that are marked for erases.
  for (LiteRtOp op : erases_) {
    Drop(*op);
  }

  // Clear dead ops and tensors in user defined subgraph.
  DCE(subgraph_);

  // Recover the graph connectivity after transferring, for inputs and
  // outputs of the builder subgraph.
  auto const is_a_io_tensor = [](const LiteRtTensor& tensor,
                                 const std::vector<LiteRtTensor>& io_Tensors) {
    return std::any_of(
        io_Tensors.begin(), io_Tensors.end(),
        [&tensor](const LiteRtTensor& input) { return input == tensor; });
  };

  for (auto& op : subgraph_.Ops()) {
    for (size_t i = 0; i < op->Inputs().size(); ++i) {
      auto& input = op->Inputs()[i];
      if (is_a_io_tensor(input, subgraph_.Inputs())) {
        input->Users().push_back(op);
        input->UserArgInds().push_back(i);
      }
    }
    for (size_t i = 0; i < op->Outputs().size(); ++i) {
      auto& output = op->Outputs()[i];
      if (is_a_io_tensor(output, subgraph_.Outputs())) {
        output->SetDefiningOp(*op, i);
      }
    }
  }

  // Transfer ownership of tensors and ops to the root subgraph.
  // Note: Maintain the original topological order of the ops.
  size_t splice_index = subgraph_to_apply->Ops().size();
  LITERT_LOG(LITERT_DEBUG, "splice_index starting: %zu", splice_index);
  for (size_t original_op_index = 0;
       original_op_index < subgraph_to_apply->Ops().size();
       ++original_op_index) {
    for (LiteRtOp op_to_erase : erases_) {
      if (subgraph_to_apply->Ops().at(original_op_index) == op_to_erase) {
        splice_index = std::min(splice_index, original_op_index);
      }
    }
  }
  // Transfer ops from the subgraph to the root subgraph.
  subgraph_to_apply->TransferOpsFrom(subgraph_.OpsAllocation(), splice_index);
  DCE(*subgraph_to_apply);

  // Transfer ownership of Weights buffers to the root subgraph.
  auto src_buffer_manager = subgraph_.GetBufferManager();
  auto dst_buffer_manager = subgraph_to_apply->GetBufferManager();
  for (auto& tensor : subgraph_.Tensors()) {
    if ((tensor->Weights().Buffer().Size() > 0) &&
        (tensor->Weights().GetBufferManager() == src_buffer_manager)) {
      auto src_buffer_id = tensor->Weights().GetBufferId();
      auto src_buffer = src_buffer_manager->GetOwnedBuffer(src_buffer_id);
      auto new_buf_id = dst_buffer_manager->RegisterOwnedBuffer(
          std::move(src_buffer.Value()));
      tensor->Weights().SetBufferId(new_buf_id);
      tensor->Weights().SetBufferManager(dst_buffer_manager);
    }
  }
  // Transfer ownership of tensors to the root subgraph.
  subgraph_to_apply->TransferTensorsFrom(subgraph_.TensorsAllocation());

  erases_.clear();
  allocated_ops_.clear();
  allocated_tensors_.clear();
}

namespace litert::internal {

void SetTflOpCodeInd(LiteRtOpT& litert_op, int32_t tfl_op_code_ind) {
  litert_op.tfl_op_code_ind_ = tfl_op_code_ind;
}

int32_t GetTflOpCodeInd(const LiteRtOpT& litert_op) {
  return litert_op.tfl_op_code_ind_;
}

const TflOptions& GetTflOptions(const LiteRtOpT& litert_op) {
  return litert_op.tfl_option_;
}

const TflOptions2& GetTflOptions2(const LiteRtOpT& litert_op) {
  return litert_op.tfl_option_2_;
}

TflOptions&& TakeTflOptions(LiteRtOpT& litert_op) {
  return std::move(litert_op.tfl_option_);
}

TflOptions2&& TakeTflOptions2(LiteRtOpT& litert_op) {
  return std::move(litert_op.tfl_option_2_);
}

const std::vector<TflOpCodePtr>& GetTflOpCodes(
    const LiteRtModelT& litert_model) {
  return litert_model.tfl_operator_codes_;
}

std::vector<TflOpCodePtr>&& TakeTflOpCodes(LiteRtModelT& litert_model) {
  return std::move(litert_model.tfl_operator_codes_);
}

// new stuff start
void SetTflFlatbuffer(LiteRtModelT& litert_model,
                      LiteRtModelT::TflFlatbuffer&& tfl_flatbuffer) {
  litert_model.tfl_flatbuffer_ = std::move(tfl_flatbuffer);
}

const LiteRtModelT::TflFlatbuffer& GetTflFlatbuffer(
    const LiteRtModelT& litert_model) {
  return litert_model.tfl_flatbuffer_;
}
// new stuff end

namespace {

bool IsOpDead(const LiteRtOpT& op) {
  return op.Inputs().empty() && op.Outputs().empty();
}

bool IsTensorDead(const LiteRtTensorT& tensor) {
  return tensor.DefiningOp() == nullptr && tensor.NumUses() == 0;
}

}  // namespace

void CloneTo(const LiteRtTensorT& src, LiteRtTensorT& dest) {
  dest.SetName({src.Name().cbegin(), src.Name().cend()});
  dest.SetQarams(src.Qparams());
  dest.SetType(src.Type());
  dest.SetTensorIndex(src.TensorIndex());

  // Manully copy per-channel quantization params,quant array is owned by
  // tensor.
  if (src.Qparams().first == kLiteRtQuantizationPerChannel) {
    std::vector<float> scales(
        src.Qparams().second.per_channel.scales,
        src.Qparams().second.per_channel.scales +
            src.Qparams().second.per_channel.num_channels);
    std::vector<int64_t> zero_points(
        src.Qparams().second.per_channel.zero_points,
        src.Qparams().second.per_channel.zero_points +
            src.Qparams().second.per_channel.num_channels);
    Quantization dest_qparams = MakePerChannelQuantization(
        scales, zero_points,
        src.Qparams().second.per_channel.quantized_dimension,
        [&dest](auto s) { return dest.RequestScratchBuffer(s); });
    dest.SetQarams(std::move(dest_qparams));
  }

  // Move weight buffer from src to dest.
  const auto& src_weights = src.Weights();
  auto& dest_weights = dest.Weights();

  const auto same_manager =
      src_weights.GetBufferManager() == dest_weights.GetBufferManager();

  if (same_manager) {
    dest_weights.SetBufferId(src_weights.GetBufferId());
  } else if (src_weights.Buffer().Data() != nullptr &&
             src_weights.Buffer().Size() > 0) {
    OwningBufferRef<uint8_t> weights_buffer(src_weights.Buffer().Data(),
                                            src_weights.Buffer().Size());
    SetWeightsFromOwnedBuffer(dest_weights, std::move(weights_buffer));
  }
}

void CloneTo(const LiteRtOpT& src, LiteRtOpT& dest) {
  dest.SetCustomOptions(src.CustomOptions().Data(), src.CustomOptions().Size());
  litert::internal::SetTflOptions(dest, litert::internal::GetTflOptions(src));
  litert::internal::SetTflOptions2(dest, litert::internal::GetTflOptions2(src));
  litert::internal::SetTflOpCodeInd(dest,
                                    litert::internal::GetTflOpCodeInd(src));
  dest.SetOpCode(src.OpCode());
  if (auto custom_code = src.CustomCode(); custom_code.HasValue()) {
    dest.SetCustomCode(std::string(*custom_code));
  }
}

litert::Expected<LiteRtTensorT*> MakeClone(LiteRtSubgraphT& parent,
                                           const LiteRtTensorT& src) {
  switch (src.Qparams().first) {
    case kLiteRtQuantizationNone:
    case kLiteRtQuantizationPerTensor:
    case kLiteRtQuantizationPerChannel:
    case kLiteRtQuantizationBlockWise:
      break;
    default:
      LITERT_LOG(LITERT_ERROR, "Unsupported quantization type: %d",
                 static_cast<int>(src.Qparams().first));
      return litert::Error(
          kLiteRtStatusErrorInvalidArgument,
          absl::StrCat("Unsupported quantization type: ",
                       static_cast<int>(src.Qparams().first)));
  }

  auto& new_tensor = parent.EmplaceTensor();
  CloneTo(src, new_tensor);

  if (new_tensor.Qparams().first == kLiteRtQuantizationBlockWise) {
    auto& block_wise = new_tensor.Qparams().second.block_wise;
    if (block_wise.scales != nullptr) {
      LiteRtTensorT* scales_clone = nullptr;
      LITERT_ASSIGN_OR_RETURN(
          scales_clone, MakeClone(parent, *static_cast<const LiteRtTensorT*>(
                                              block_wise.scales)));
      block_wise.scales = scales_clone;
    }
    if (block_wise.zero_points != nullptr) {
      LiteRtTensorT* zp_clone = nullptr;
      LITERT_ASSIGN_OR_RETURN(
          zp_clone, MakeClone(parent, *static_cast<const LiteRtTensorT*>(
                                          block_wise.zero_points)));
      block_wise.zero_points = zp_clone;
    }
  }

  return &new_tensor;
}

LiteRtOpT& MakeClone(LiteRtSubgraphT& parent, const LiteRtOpT& src) {
  auto& new_op = parent.EmplaceOp();
  CloneTo(src, new_op);
  return new_op;
}

std::optional<LiteRtParamIndex> FindInput(const LiteRtOpT& op,
                                          const LiteRtTensorT& tensor) {
  return FindInd(op.Inputs().cbegin(), op.Inputs().cend(), &tensor);
}

std::optional<LiteRtParamIndex> FindOutput(const LiteRtOpT& op,
                                           const LiteRtTensorT& tensor) {
  return FindInd(op.Outputs().cbegin(), op.Outputs().cend(), &tensor);
}

std::optional<LiteRtParamIndex> FindInput(const LiteRtSubgraphT& subgraph,
                                          const LiteRtTensorT& tensor) {
  return FindInd(subgraph.Inputs().cbegin(), subgraph.Inputs().cend(), &tensor);
}

std::optional<LiteRtParamIndex> FindOutput(const LiteRtSubgraphT& subgraph,
                                           const LiteRtTensorT& tensor) {
  return FindInd(subgraph.Outputs().cbegin(), subgraph.Outputs().cend(),
                 &tensor);
}

UseIndices FindUseInds(const LiteRtTensorT& tensor, const LiteRtOpT& op) {
  UseIndices res;
  for (auto i = 0; i < tensor.NumUses(); ++i) {
    if (tensor.Users().at(i) == &op) {
      res.push_back(i);
    }
  }
  return res;
}

bool IsConstant(const LiteRtTensorT& tensor) {
  bool is_zero_sized = false;
  auto layout = tensor.Type().second.ranked_tensor_type.layout;
  if (layout.rank == 1) {
    if (layout.dimensions[0] == 0) {
      is_zero_sized = true;
    }
  }
  const auto is_const = tensor.Weights().Buffer().Size() > 0 || is_zero_sized;
  ABSL_DCHECK(!is_const || tensor.DefiningOp() == nullptr)
      << "Constant tensors should not be defined by an op";
  return is_const;
}
// TODO: reuse this in cc api.
bool IsSubgraphInput(const LiteRtTensorT& tensor) {
  return !IsConstant(tensor) && tensor.DefiningOp() == nullptr;
}

void AttachInput(LiteRtTensor tensor, LiteRtOpT& op) {
  op.Inputs().push_back(tensor);
  tensor->Users().push_back(&op);
  tensor->UserArgInds().push_back(op.Inputs().size() - 1);
}

void AttachOutput(LiteRtTensor tensor, LiteRtOpT& op) {
  ABSL_DCHECK(tensor->DefiningOp() == nullptr)
      << "Cannot add an already defined tensor as op output";
  op.Outputs().push_back(tensor);
  tensor->SetDefiningOp(op, op.Outputs().size() - 1);
}

LiteRtTensor DisconnectInput(LiteRtOpT& op, LiteRtParamIndex input_ind) {
  ABSL_DCHECK(input_ind < op.Inputs().size()) << "Removing tensor index oob";
  auto& input = op.Input(input_ind);

  // Find the index of the use for the given in edge.
  auto target_use_ind = -1;
  for (auto i = 0; i < input.NumUses(); ++i) {
    if (input.Users().at(i) == &op && input.UserArgInds().at(i) == input_ind) {
      target_use_ind = i;
    }
  }
  ABSL_DCHECK_GE(target_use_ind, 0) << "Malformed graph";

  // Slide latter input use arg inds to the left.
  for (auto i = input_ind + 1; i < op.Inputs().size(); ++i) {
    auto& r_in = op.Input(i);
    for (auto u = 0; u < r_in.NumUses(); ++u) {
      auto& r_arg_ind = r_in.UserArgInds().at(u);
      if (r_in.Users().at(u) == &op && r_arg_ind > input_ind) {
        r_arg_ind -= 1;
      }
    }
  }

  // Update the edges.
  input.RemoveUse(target_use_ind);
  op.RemoveInput(input_ind);

  return &input;
}

bool IsIO(const LiteRtSubgraphT& subgraph, const LiteRtTensorT& tensor) {
  return FindInput(subgraph, tensor) || FindOutput(subgraph, tensor);
}

namespace {

bool IsCompiledOp(const LiteRtModelT& graph, LiteRtOpT& op) {
  // If there hasn't been a round of serialization,
  // since dispatches were added, they won't be in the code
  // table.
  // TODO: Fix this once the code table is updated
  // dynamically.
  return litert::internal::GetTflOpCodeInd(op) ==
             litert::internal::kDispatchOpCodeTflInd ||
         GetCustomOpCode(graph, op) ==
             litert::internal::kLiteRtDispatchOpCustomName;
}

}  // namespace

bool IsFullyCompiled(const LiteRtModelT& graph) {
  bool res = true;
  ForEachIr(graph,
            [&res, &graph](LiteRtOp op) { res &= IsCompiledOp(graph, *op); });
  return res;
}

bool HasAnyCompiled(const LiteRtModelT& graph) {
  bool res = false;
  ForEachIr(graph,
            [&res, &graph](LiteRtOp op) { res |= IsCompiledOp(graph, *op); });
  return res;
}

LiteRtTensor DisconnectOutput(LiteRtOpT& op, LiteRtParamIndex output_ind) {
  ABSL_DCHECK(output_ind < op.Outputs().size()) << "Removing tensor index oob";
  auto& output = op.Output(output_ind);
  output.ClearDefiningOp();
  op.RemoveOutput(output_ind);
  return &output;
}

void Drop(LiteRtOpT& litert_op) {
  while (!litert_op.Inputs().empty()) {
    DisconnectInput(litert_op, 0);
  }
  while (!litert_op.Outputs().empty()) {
    DisconnectOutput(litert_op, 0);
  }
}

bool DCE(LiteRtSubgraphT& subgraph) {
  const auto ops_removed = subgraph.RemoveOpIf(IsOpDead);

  absl::flat_hash_set<const LiteRtTensorT*> referenced_tensors;
  for (const auto* tensor : subgraph.Tensors()) {
    if (tensor->Qparams().first == kLiteRtQuantizationBlockWise) {
      const auto& block_wise = tensor->Qparams().second.block_wise;
      if (block_wise.scales) {
        referenced_tensors.insert(
            static_cast<const LiteRtTensorT*>(block_wise.scales));
      }
      if (block_wise.zero_points) {
        referenced_tensors.insert(
            static_cast<const LiteRtTensorT*>(block_wise.zero_points));
      }
    }
  }

  auto rm_tensor = [&subgraph, &referenced_tensors](const auto& t) {
    return IsTensorDead(t) && !IsIO(subgraph, t) &&
           !referenced_tensors.contains(&t);
  };
  const auto tensors_removed = subgraph.RemoveTensorIf(rm_tensor);
  LITERT_LOG(LITERT_DEBUG, "DCE removed %d ops, %d tensors", ops_removed,
             tensors_removed);

  return (ops_removed + tensors_removed) > 0;
}

}  // namespace litert::internal
