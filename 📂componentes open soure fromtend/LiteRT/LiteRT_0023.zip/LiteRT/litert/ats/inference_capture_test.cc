// Copyright 2025 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "litert/ats/inference_capture.h"

#include <gtest/gtest.h>

namespace litert::testing {
namespace {

TEST(AtsCaptureTest, LatencyRow) {
  Latency l;
  l.Stop(l.Start());
  EXPECT_EQ(l.NumSamples(), 1);
  EXPECT_EQ(l.Avg(), l.Min());
  EXPECT_EQ(l.Avg(), l.Max());
  EXPECT_DOUBLE_EQ(l.StdDev(), 0.0);
}

TEST(AtsCaptureTest, Numerics) {
  Numerics n;
  n.NewMse(2.0);
  n.NewMse(4.0);
  EXPECT_EQ(n.AvgMse(), 3.0);
}

}  // namespace
}  // namespace litert::testing
