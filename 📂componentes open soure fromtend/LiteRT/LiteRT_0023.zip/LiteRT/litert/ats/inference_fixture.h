// Copyright 2025 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_LITERT_ATS_INFERENCE_FIXTURE_H_
#define THIRD_PARTY_ODML_LITERT_LITERT_ATS_INFERENCE_FIXTURE_H_

#include <sys/resource.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "absl/strings/str_cat.h"  // from @com_google_absl
#include "absl/strings/str_format.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#include "litert/ats/common.h"
#include "litert/ats/configure.h"
#include "litert/ats/executor.h"
#include "litert/ats/inference_capture.h"
#include "litert/c/internal/litert_logging.h"  // IWYU pragma: keep
#include "litert/c/litert_common.h"
#include "litert/cc/internal/litert_c_types_printing.h"  // IWYU pragma: keep
#include "litert/cc/litert_element_type.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/core/model/model.h"
#include "litert/test/generators/common.h"
#include "litert/test/matchers.h"
#include "litert/test/rng_fixture.h"
#include "litert/test/simple_buffer.h"
#include "tflite/types/half.h"

namespace litert::testing {

using ::testing::RegisterTest;
using ::testing::litert::MeanSquaredErrorLt;

// Helper to rate-limit failure logging and prevent log bloat on large tensors.
class FailureLimiter {
 public:
  explicit FailureLimiter(size_t max_logs = 5) : max_logs_(max_logs) {}

  template <typename MsgGenerator>
  void RecordFailure(MsgGenerator&& msg_gen) {
    if (failures_logged_ < max_logs_) {
      ADD_FAILURE() << msg_gen();
      ++failures_logged_;
    } else if (failures_logged_ == max_logs_) {
      ADD_FAILURE() << "Additional element mismatches omitted...";
      ++failures_logged_;
    }
  }

 private:
  size_t max_logs_;
  size_t failures_logged_ = 0;
};

// Fixture for tests that test execution on a given graph.
class AtsInferenceTest : public RngTest {
  template <typename T>
  using BufferView = SimpleBuffer::CView<T>;

 public:
  using Capture = InferenceCapture;

  static constexpr absl::string_view Name() { return "inference"; }

  static void Register(TestGraph::Ptr graph, const AtsConf& conf,
                       const TestNames& names, typename Capture::Entry& cap) {
    RegisterTest(names.suite.c_str(), names.test.c_str(), nullptr, nullptr,
                 __FILE__, __LINE__,
                 [graph = std::move(graph), &conf = std::as_const(conf), &cap,
                  names]() mutable {
                   return new AtsInferenceTest(std::move(graph), conf, names,
                                               cap);
                 });
  }

  void SetUp() override {
    cap_.model.SetFields(names_, Graph());
    if (names_.should_skip) {
      GTEST_SKIP() << "Filtered by dont_register";
    }
    ASSERT_EQ(Graph().NumSubgraphs(), 1);
    LITERT_LOG(LITERT_INFO, "Setting up test for %s",
               absl::StrFormat("%v", conf_.Backend()).c_str());
    cap_.run.num_iterations = conf_.ItersPerTest();
    cap_.numerics.reference_type =
        graph_->HasReference() ? ReferenceType::kCustom : ReferenceType::kCpu;
  }

  void TestBody() override {
    auto device = this->TracedDevice(conf_.DataSeed());
    LITERT_ASSERT_OK_AND_ASSIGN(exec_, MakeExecutor());
    const int num_warmup = conf_.WarmupRuns();
    if (num_warmup > 0) {
      LITERT_ASSERT_OK_AND_ASSIGN(auto warmup_inputs, MakeInputs(device));
      for (int w = 0; w < num_warmup; ++w) {
        LITERT_ASSERT_OK(exec_->Run(warmup_inputs));
      }
    }
    for (auto _ : this->FuzzBlock(conf_.ItersPerTest(), conf_.MaxMsPerTest())) {
      LITERT_ASSERT_OK_AND_ASSIGN(auto inputs, MakeInputs(device));
      LITERT_ASSERT_OK_AND_ASSIGN(auto ref, Reference(inputs));
      LITERT_ASSERT_OK_AND_ASSIGN(auto actual, Actual(inputs, exec_.get()));
      CheckOutputs(actual, ref);
    }
  }

  void TearDown() override {
    cap_.accelerator.SetFields(conf_);
    if (exec_) {
      if (auto metrics = exec_->GetMetrics(); metrics.HasValue()) {
        cap_.memory.SetFields(*metrics);
      }
    }

    if (conf_.IsNpu() && !cap_.accelerator.soc_man.empty()) {
      auto stamp = GetBuildStamp(Graph());
      if (stamp) {
        cap_.accelerator.soc_man = std::string(stamp->soc_manufacturer);
        cap_.accelerator.soc_model = std::string(stamp->soc_model);
      }
    }

    if (::testing::Test::IsSkipped()) {
      cap_.run.status = RunStatus::kSkipped;
      return;
    } else if (HasFailure()) {
      cap_.run.status = RunStatus::kError;
      return;
    } else if (TimedOut()) {
      cap_.run.status = RunStatus::kTimeout;
      return;
    } else {
      cap_.run.status = RunStatus::kOk;
    }
    LITERT_ASSERT_OK(
        conf_.SaveModel(names_.report_id, std::move(graph_->Graph())));
  }

 private:
  double Tol() const { return graph_->HasReference() ? 1e-4 : 1e2; }

  Expected<CompiledModelExecutor::Ptr> MakeExecutor() {
    auto& env = conf_.GetEnvironment();

    CompiledModelExecutor::Ptr exec;
    if (conf_.IsNpu()) {
      auto exec =
          NpuCompiledModelExecutor::Create(Graph(), conf_.TargetOptions(), env);
      cap_.compilation.SetFields(conf_, Graph(), !exec.HasValue());
      if (!exec) {
        return exec.Error();
      }
      auto res = std::make_unique<CompiledModelExecutor>(std::move(*exec));
      return res;
    }
    if (conf_.IsCpu()) {
      LITERT_ASSIGN_OR_RETURN(auto exec,
                              CpuCompiledModelExecutor::Create(
                                  Graph(), conf_.TargetOptions(), env));
      return std::make_unique<CompiledModelExecutor>(std::move(exec));
    }
    if (conf_.IsGpu()) {
      LITERT_ASSIGN_OR_RETURN(auto exec,
                              GpuCompiledModelExecutor::Create(
                                  Graph(), conf_.TargetOptions(), env));
      return std::make_unique<CompiledModelExecutor>(std::move(exec));
    }

    return Error(kLiteRtStatusErrorInvalidArgument, "Unsupported backend");
  }

  template <typename Rng>
  Expected<VarBuffers> MakeInputs(Rng& device) const {
    auto inputs = graph_->MakeInputs(device, conf_.DataBuilder());
    if (!inputs.HasValue()) return inputs.Error();
    return inputs;
  }

  Expected<VarBuffers> Actual(const VarBuffers& inputs,
                              CompiledModelExecutor* exec) {
    return exec->Run(inputs, cap_.latency);
  }

  Expected<VarBuffers> Reference(const VarBuffers& inputs) const {
    return graph_->HasReference() ? CustomReference(inputs)
                                  : CpuReference(inputs);
  }

  Expected<VarBuffers> CustomReference(const VarBuffers& inputs) const {
    LITERT_ASSIGN_OR_RETURN(auto outputs, MakeOutputs());
    LITERT_RETURN_IF_ERROR(graph_->Reference(inputs, outputs));
    return outputs;
  }

  Expected<VarBuffers> CpuReference(const VarBuffers& inputs) const {
    LITERT_ASSIGN_OR_RETURN(auto exec, CpuCompiledModelExecutor::Create(
                                           Graph(), conf_.ReferenceOptions(),
                                           conf_.GetEnvironment()));
    return exec.Run(inputs);
  }

  Expected<VarBuffers> MakeOutputs() const {
    return SimpleBuffer::LikeSignature(Graph().Subgraph(0).Outputs().begin(),
                                       Graph().Subgraph(0).Outputs().end());
  }

  ConformanceSpec Conformance() const { return graph_->GetConformanceSpec(); }

  template <typename T>
  static double MeanSquaredError(absl::Span<const T> actual,
                                 absl::Span<const T> ref) {
    if (actual.empty()) {
      return 0.0;
    }
    double mse = 0.0;
    for (size_t i = 0; i < actual.size(); ++i) {
      const double diff =
          static_cast<double>(actual[i]) - static_cast<double>(ref[i]);
      mse += diff * diff;
    }
    return mse / static_cast<double>(actual.size());
  }

  template <typename T>
  void CheckMseOutputImpl(const BufferView<T>& actual, const BufferView<T>& ref,
                          double tol) {
    double mse = std::numeric_limits<double>::max();
    EXPECT_THAT(actual.data, MeanSquaredErrorLt(ref.data, tol, &mse));
    if (mse > tol) {
      LITERT_LOG(LITERT_ERROR, "[NUMERICAL DISCREPANCY DETAIL]");
      LITERT_LOG(LITERT_ERROR, "Tolerance: %g, Actual MSE: %g", tol, mse);
      LITERT_LOG(LITERT_ERROR,
                 "Side-by-side comparison (showing first 10 mismatches):");
      size_t printed = 0;
      for (size_t i = 0; i < actual.data.size() && printed < 10; ++i) {
        double a_val = static_cast<double>(actual.data[i]);
        double r_val = static_cast<double>(ref.data[i]);
        double diff = std::abs(a_val - r_val);
        if (diff > tol) {
          LITERT_LOG(LITERT_ERROR,
                     "  Index %zu: Actual=%g\tExpected=%g\tDiff=%g", i, a_val,
                     r_val, diff);
          printed++;
        }
      }
      LITERT_LOG(LITERT_ERROR, "----------------------------------------");
    }
    cap_.numerics.NewMse(mse);
  }

  template <typename T>
  void CheckExactOutputImpl(const BufferView<T>& actual,
                            const BufferView<T>& ref) {
    ASSERT_EQ(actual.data.size(), ref.data.size());
    FailureLimiter limiter;
    for (size_t i = 0; i < actual.data.size(); ++i) {
      if (actual.data[i] != ref.data[i]) {
        limiter.RecordFailure([&] {
          return absl::StrCat("index=", i, ", expected=", ref.data[i],
                              ", actual=", actual.data[i]);
        });
      }
    }
    cap_.numerics.NewMse(MeanSquaredError(actual.data, ref.data));
  }

  void CheckExactOutputBytesImpl(const SimpleBuffer& actual,
                                 const SimpleBuffer& ref) {
    const auto actual_bytes = actual.Span<uint8_t>();
    const auto ref_bytes = ref.Span<uint8_t>();
    ASSERT_EQ(actual_bytes.size(), ref_bytes.size());
    FailureLimiter limiter;
    for (size_t i = 0; i < actual_bytes.size(); ++i) {
      if (actual_bytes[i] != ref_bytes[i]) {
        limiter.RecordFailure([&] {
          return absl::StrCat("byte=", i, ", expected=",
                              static_cast<int>(ref_bytes[i]), ", actual=",
                              static_cast<int>(actual_bytes[i]));
        });
      }
    }
    cap_.numerics.NewMse(0.0);
  }

  template <typename T>
  void CheckFloatAccumulationAwareOutputImpl(const BufferView<T>& actual,
                                             const BufferView<T>& ref,
                                             const ConformanceSpec& spec) {
    ASSERT_EQ(actual.data.size(), ref.data.size());
    const double half_eps = static_cast<double>(tflite::half::epsilon());
    const double eps =
        conf_.IsHalfPrecisionBackend()
            ? std::max(static_cast<double>(std::numeric_limits<T>::epsilon()),
                       half_eps)
            : static_cast<double>(std::numeric_limits<T>::epsilon());
    const double rtol = std::max(
        spec.relative_tolerance,
        10.0 * eps * std::sqrt(static_cast<double>(spec.accumulation_depth)));
    const double atol = std::max(spec.absolute_tolerance, 10.0 * eps);
    FailureLimiter limiter;
    for (size_t i = 0; i < actual.data.size(); ++i) {
      const double expected = static_cast<double>(ref.data[i]);
      const double actual_val = static_cast<double>(actual.data[i]);
      const double diff = std::abs(actual_val - expected);
      const double tol = atol + rtol * std::abs(expected);
      if (diff > tol) {
        limiter.RecordFailure([&] {
          return absl::StrCat("index=", i, ", expected=", expected,
                              ", actual=", actual_val, ", rtol=", rtol,
                              ", atol=", atol);
        });
      }
    }
    cap_.numerics.NewMse(MeanSquaredError(actual.data, ref.data));
  }

  template <typename T>
  void CheckFloatElementwiseOutputImpl(const BufferView<T>& actual,
                                       const BufferView<T>& ref,
                                       const ConformanceSpec& spec) {
    ASSERT_EQ(actual.data.size(), ref.data.size());
    const double half_eps =
        static_cast<double>(static_cast<float>(tflite::half::epsilon()));
    const double eps =
        conf_.IsHalfPrecisionBackend()
            ? std::max(static_cast<double>(std::numeric_limits<T>::epsilon()),
                       half_eps)
            : static_cast<double>(std::numeric_limits<T>::epsilon());
    const double rtol = std::max(spec.relative_tolerance, 10.0 * eps);
    const double atol = std::max(spec.absolute_tolerance, 10.0 * eps);
    FailureLimiter limiter;
    for (size_t i = 0; i < actual.data.size(); ++i) {
      const double expected = static_cast<double>(ref.data[i]);
      const double actual_val = static_cast<double>(actual.data[i]);
      const double diff = std::abs(actual_val - expected);
      const double tol = atol + rtol * std::abs(expected);
      if (diff > tol) {
        limiter.RecordFailure([&] {
          return absl::StrCat("index=", i, ", expected=", expected,
                              ", actual=", actual_val);
        });
      }
    }
    cap_.numerics.NewMse(MeanSquaredError(actual.data, ref.data));
  }

  template <typename T>
  void CheckQuantizedBucketOutputImpl(const BufferView<T>& actual,
                                      const BufferView<T>& ref,
                                      int64_t bucket_tolerance) {
    ASSERT_EQ(actual.data.size(), ref.data.size());
    FailureLimiter limiter;
    for (size_t i = 0; i < actual.data.size(); ++i) {
      const int64_t diff = std::llabs(static_cast<int64_t>(actual.data[i]) -
                                      static_cast<int64_t>(ref.data[i]));
      if (diff > bucket_tolerance) {
        limiter.RecordFailure([&] {
          return absl::StrCat("index=", i, ", expected=",
                              static_cast<int64_t>(ref.data[i]), ", actual=",
                              static_cast<int64_t>(actual.data[i]));
        });
      }
    }
    cap_.numerics.NewMse(MeanSquaredError(actual.data, ref.data));
  }

  void CheckOutputs(const VarBuffers& actual, const VarBuffers& ref) {
    const ConformanceSpec spec = Conformance();
    ASSERT_EQ(actual.size(), ref.size());
    for (size_t i = 0; i < actual.size(); ++i) {
      ASSERT_EQ(actual[i].Type(), ref[i].Type());
      if (spec.comparator_kind == ConformanceComparatorKind::kExact) {
        CheckExactOutputBytesImpl(actual[i], ref[i]);
      } else if (spec.comparator_kind ==
                 ConformanceComparatorKind::kQuantizedBucket) {
        if (actual[i].Type().ElementType() == ElementType::Int8) {
          CheckQuantizedBucketOutputImpl(actual[i].AsView<int8_t>(),
                                         ref[i].AsView<int8_t>(),
                                         spec.bucket_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::UInt8) {
          CheckQuantizedBucketOutputImpl(actual[i].AsView<uint8_t>(),
                                         ref[i].AsView<uint8_t>(),
                                         spec.bucket_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::Int16) {
          CheckQuantizedBucketOutputImpl(actual[i].AsView<int16_t>(),
                                         ref[i].AsView<int16_t>(),
                                         spec.bucket_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::Int32) {
          CheckQuantizedBucketOutputImpl(actual[i].AsView<int32_t>(),
                                         ref[i].AsView<int32_t>(),
                                         spec.bucket_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::Int64) {
          CheckQuantizedBucketOutputImpl(actual[i].AsView<int64_t>(),
                                         ref[i].AsView<int64_t>(),
                                         spec.bucket_tolerance);
        } else {
          FAIL() << "Unsupported quantized bucket element type";
        }
      } else if (spec.comparator_kind ==
                 ConformanceComparatorKind::kFloatElementwise) {
        if (actual[i].Type().ElementType() == ElementType::Float32) {
          CheckFloatElementwiseOutputImpl(actual[i].AsView<float>(),
                                          ref[i].AsView<float>(), spec);
        } else if (actual[i].Type().ElementType() == ElementType::Float16) {
          CheckFloatElementwiseOutputImpl(actual[i].AsView<tflite::half>(),
                                          ref[i].AsView<tflite::half>(), spec);
        } else {
          FAIL() << "Unsupported float elementwise element type";
        }
      } else if (spec.comparator_kind ==
                 ConformanceComparatorKind::kFloatAccumulationAware) {
        if (actual[i].Type().ElementType() == ElementType::Float32) {
          CheckFloatAccumulationAwareOutputImpl(actual[i].AsView<float>(),
                                                ref[i].AsView<float>(), spec);
        } else if (actual[i].Type().ElementType() == ElementType::Float16) {
          CheckFloatAccumulationAwareOutputImpl(
              actual[i].AsView<tflite::half>(), ref[i].AsView<tflite::half>(),
              spec);
        } else {
          FAIL() << "Unsupported float accumulation aware element type";
        }
      } else {
        // kMse
        if (actual[i].Type().ElementType() == ElementType::Float32) {
          CheckMseOutputImpl(actual[i].AsView<float>(), ref[i].AsView<float>(),
                             spec.absolute_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::Float16) {
          CheckMseOutputImpl(actual[i].AsView<tflite::half>(),
                             ref[i].AsView<tflite::half>(),
                             spec.absolute_tolerance);
        } else if (actual[i].Type().ElementType() == ElementType::Int32) {
          CheckMseOutputImpl(actual[i].AsView<int32_t>(),
                             ref[i].AsView<int32_t>(), spec.absolute_tolerance);
        } else {
          FAIL() << "Unsupported MSE element type";
        }
      }
    }
  }

  LiteRtModelT& Graph() const { return graph_->Graph(); }

  AtsInferenceTest(TestGraph::Ptr graph, const AtsConf& conf,
                   const TestNames& names, Capture::Entry& cap)
      : graph_(std::move(graph)), conf_(conf), names_(names), cap_(cap) {}

  TestGraph::Ptr graph_;
  const AtsConf& conf_;
  TestNames names_;
  Capture::Entry& cap_;
  CompiledModelExecutor::Ptr exec_ = nullptr;
};

}  // namespace litert::testing

#endif  // THIRD_PARTY_ODML_LITERT_LITERT_ATS_INFERENCE_FIXTURE_H_
