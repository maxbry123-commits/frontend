"""Contains the version of litert."""

# The next version of LiteRT.
# The minor version code should be bumped after every release.
LITERT_FULL_VERSION = "1.5.0"

# The next version of LiteRT V2.
#
# The patched version should be bumped after every release during
# alpha. Once leaving alpha, the version is 2.1.0.
LITERT_EXPERIMENTAL_VERSION = "2.3.0"

# The next version of LiteRT SDK for Qualcomm.
# The minor version code should be bumped after every release.
# It contains QAIRT 2.49.0.260730
LITERT_SDK_QUALCOMM_FULL_VERSION = "2.3.0"

# The next version of LiteRT SDK for MediaTek version.
# The minor version code should be bumped after every release.
# It contains NeuroPilot 8.0.10 and 9.0.3 VERSION
LITERT_SDK_MEDIATEK_FULL_VERSION = "2.3.0"

# The next version of LiteRT SDK for Google Tensor version.
# The minor version code should be bumped after every release.
# It contains Google Tensor ML SDK UNKNOWN VERSION
LITERT_SDK_GOOGLE_TENSOR_FULL_VERSION = "2.3.0"

# The next version of LiteRT SDK for MediaTek version.
# The minor version code should be bumped after every release.
# It contains Exynos AI LiteCore 1.1.0 VERSION
LITERT_SDK_SAMSUNG_FULL_VERSION = "2.3.0"

# The next version of LiteRT SDK for Intel version.
# The minor version code should be bumped after every release.
LITERT_SDK_INTEL_FULL_VERSION = "2.3.0"

# The next version of LiteRT Converter version.
# The minor version code should be bumped after every release.
LITERT_CONVERTER_VERSION = "0.5.0"

# Minimum Android API / SDK level supported by the LiteRT runtime, APIs, and native libraries.
LITERT_ANDROID_NDK_MIN_SDK_VERSION = 24
