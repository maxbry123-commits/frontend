# Copyright 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#!/bin/bash

source "${0%.sh}_lib.sh" || exit 1

extra_args=("${@:1}")
d_bin=$(device_bin)
d_libs=($(device_libs))
d_data=($(data_files))
d_env_vars=($(exec_env_vars))
d_args=()
provided_models=()

dry_run=""
no_push=""

# Resolves user provided data paths (files or directories) to absolute paths.
# If a directory is provided, it resolves all files within it (non-recursive).
# copybara:comment_begin(google-only)
source third_party/odml/litert/litert/integration_test/google/remote_path_helper.sh || exit 1
# copybara:comment_end

function handle_user_data() {
  local user_data=()
  for arg_f in "$@"; do
    local f="$arg_f"
    # copybara:comment_begin(google-only)
    if type handle_remote_path >/dev/null 2>&1; then
      f="$(handle_remote_path "$arg_f")"
    fi
    # copybara:comment_end



    local check_f="$f"
    if [[ ! -f "$check_f" && ! -d "$check_f" && -n "${BUILD_WORKING_DIRECTORY}" && "$check_f" != "/"* ]]; then
      check_f="${BUILD_WORKING_DIRECTORY}/${f}"
    fi

    if [[ -f "$check_f" ]]; then
      user_data+=($(realpath "${check_f}"))
    elif [[ -d "$check_f" ]]; then
      for ff in "${check_f%/}/"*; do
        if [[ -f "$ff" ]]; then
          user_data+=($(realpath "${ff}"))
        fi
      done
    else
      fatal "${f} is not a file or directory"
    fi
  done
  echo "${user_data[@]}"
}

function setup_context() {
  local in_flags=$1
  for a in ${in_flags[@]}; do
    if [[ $a == "--user_data="* ]]; then
      d_data+=($(handle_user_data "${a#*=}"))
    elif [[ $a == "--dry_run"* ]]; then
      dry_run="true"
    elif [[ $a == "--no_push"* ]]; then
      no_push="true"
    elif [[ $a == "--models="* ]]; then
      local m_path="${a#*=}"
      d_data+=($(handle_user_data "${m_path}"))

      local abs_path=$(realpath "${m_path}")
      local dev_path=$(device_path "${abs_path}")
      d_args+=("--extra_models=${dev_path}")
      d_args+=("--do_register='ExtraModel'")
      has_user_models="true"
    elif [[ $a == "--graph="* ]]; then
      local g_path="${a#*=}"
      local resolved_paths=($(handle_user_data "${g_path}"))
      if [[ ${#resolved_paths[@]} -gt 0 ]]; then
        d_data+=("${resolved_paths[@]}")
        local dev_path=$(device_path "${resolved_paths[0]}")
        d_args+=("--graph=${dev_path}")
      else
        d_args+=("${a}")
      fi
    else
      d_args+=("${a}")
    fi
  done

  if [[ -z "${no_push}" && -z "${has_user_models}" ]]; then
    provided_models=($(get_provided_models))
    if [ $? -ne 0 ]; then
      echo "Failed to get provided models."
      exit 1
    fi

    for f in "${provided_models[@]}"; do
      d_data+=("${f}")
    done
  fi
}

function print_args() {
  print_hightlight "<<< LiteRt Mobile Install Scripts >>>"

  print "libraries"
  for f in "${d_libs[@]}"; do
    print_file "${f}" "$(device_path "${f}")"
  done

  print "data"
  for f in "${d_data[@]}"; do
    print_file "${f}" "$(device_path "${f}")"
  done

  print "device_runfiles_root"
  print_file "${device_runfiles_root}"

  if [[ -n $d_bin ]]; then
    print "bin"
    print_file "${d_bin}" "$(device_path "${d_bin}")"
    if [[ -n "${d_args[@]}" ]]; then
      print "exec_args"
      echo "    ${d_args[*]}"
    fi
    if [[ -n "${d_env_vars[@]}" ]]; then
      print "exec_env_vars"
      echo "    ${d_env_vars[@]}"
    fi
  fi

  if [[ -n "${dry_run}" ]]; then
    print "dry_run"
    echo "    yes"
  fi

  if [[ -n "${no_push}" ]]; then
    print "no_push"
    echo "    yes"
  fi
}

# Push and execute #############################################################

setup_context "${extra_args[*]}"

print_args

function push_file() {
  if [[ -n "${no_push}" ]]; then
    echo "[no_push] ${1}"
  else
    local cmd="adb push --sync "$1" "$(device_path "$1")""
    if [[ -n "${dry_run}" ]]; then
      cmd="echo [dry run] ${cmd}"
    fi
    eval "${cmd}"
  fi
}

has_adb=$(adb devices | tail -n +2)
if [[ -z ${has_adb} && -z ${dry_run} ]]; then
  fatal "No usb device found."
fi

print "Pushing libraries to device..."
for f in "${d_libs[@]}"; do
  push_file "${f}"
done

print "Pushing data to device..."
for f in "${d_data[@]}"; do
  push_file "${f}"
done

if [[ -n $d_bin ]]; then
  print "Pushing binary to device..."
  push_file "${d_bin}"
  print "Running: ${hightlight_color}\"adb shell ${d_env_vars[*]} $(device_path "${d_bin}") ${d_args[*]}${host_color}\""
  if [[ -z "${dry_run}" ]]; then
    adb shell ${d_env_vars[*]} $(device_path "${d_bin}") ${d_args[*]}
  fi
fi
