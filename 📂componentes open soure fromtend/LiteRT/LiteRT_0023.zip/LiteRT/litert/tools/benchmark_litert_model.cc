/* Copyright 2025 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include "litert/tools/benchmark_litert_model.h"

#include <cstdint>
#include <cstdlib>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "absl/container/flat_hash_map.h"  // from @com_google_absl
#include "absl/strings/numbers.h"  // from @com_google_absl
#include "absl/strings/str_split.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#include "litert/c/internal/litert_logging.h"
#include "litert/c/litert_common.h"
#include "litert/cc/internal/litert_compiled_model_next.h"
#include "litert/cc/internal/litert_tflite_error_status_builder.h"
#include "litert/cc/litert_common.h"
#include "litert/cc/litert_compiled_model.h"
#include "litert/cc/litert_environment.h"
#include "litert/cc/litert_environment_options.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/cc/litert_model.h"
#include "litert/cc/litert_options.h"
#include "litert/cc/litert_profiler.h"
#include "litert/cc/litert_tensor_buffer.h"
#include "litert/cc/options/litert_cpu_options.h"
#include "litert/cc/options/litert_google_tensor_options.h"
#include "litert/cc/options/litert_gpu_options.h"
#include "litert/cc/options/litert_mediatek_options.h"
#include "litert/cc/options/litert_qualcomm_options.h"
#include "litert/cc/options/litert_runtime_options.h"
#include "litert/core/util/perfetto_profiling.h"
#include "litert/runtime/compiled_model.h"
#include "litert/tools/flags/options_parser_registry.h"
#include "tflite/c/c_api_types.h"
#include "tflite/c/common.h"
#include "tflite/interpreter.h"

namespace litert::benchmark {
namespace {
using ::litert::CompiledModelNext;
using ::litert::Options;
using ::litert::RuntimeOptions;
using ::litert::TensorBuffer;

HwAcceleratorSet GetRequestedHardwareAccelerators(
    const BenchmarkParams& params) {
  HwAcceleratorSet hardware_accelerators(HwAccelerators::kNone);
  if (params.Get<bool>("use_npu")) {
    hardware_accelerators |= HwAccelerators::kNpu;
  }
  if (params.Get<bool>("use_gpu")) {
    hardware_accelerators |= HwAccelerators::kGpu;
  }
  if (params.Get<bool>("use_cpu") ||
      !params.Get<bool>("require_full_delegation")) {
    hardware_accelerators |= HwAccelerators::kCpu;
  }
  return hardware_accelerators;
}

Options CreateCompiledModelOptions(const BenchmarkParams& params) {
  auto use_gpu = params.Get<bool>("use_gpu");
  auto use_npu = params.Get<bool>("use_npu");
  auto use_cpu = params.Get<bool>("use_cpu");
  auto gpu_backend = params.Get<std::string>("gpu_backend");
  auto gpu_precision = params.Get<std::string>("gpu-precision");
  auto gpu_low_priority = params.Get<bool>("gpu_low_priority");
  auto use_profiler = params.Get<bool>("use_profiler");
  auto require_full_delegation = params.Get<bool>("require_full_delegation");
  auto num_threads = params.Get<int>("num_threads");
  auto enable_weight_sharing = params.Get<bool>("enable_weight_sharing");
  auto convert_weights_on_gpu = params.Get<bool>("convert_weights_on_gpu");
  auto gpu_serialization_dir =
      params.Get<std::string>("gpu_serialization_dir");
  auto gpu_model_cache_key =
      params.Get<std::string>("gpu_model_cache_key");
  auto gpu_serialize_external_tensors =
      params.Get<bool>("gpu_serialize_external_tensors");
  auto gpu_prefer_texture_weights =
      params.Get<bool>("gpu_prefer_texture_weights");
  auto gpu_wait_for_weights_conversion_complete =
      params.Get<bool>("gpu_wait_for_weights_conversion_complete");
  auto gpu_cache_compiled_programs_only =
      params.Get<bool>("gpu_cache_compiled_programs_only");
  auto gpu_madvise_original_shared_tensors =
      params.Get<bool>("gpu_madvise_original_shared_tensors");
  auto xnnpack_weight_cache_file_path =
      params.Get<std::string>("xnnpack_weight_cache_file_path");
  auto mediatek_nerun_pilot_version =
      params.Get<std::string>("mediatek_nerun_pilot_version");
  LITERT_ASSIGN_OR_ABORT(Options compilation_options,
                         litert::Options::Create());

  if (use_cpu && require_full_delegation) {
    LITERT_LOG(
        LITERT_ERROR,
        "Requesting full delegation and CPU acceleration are incompatible.");
    std::abort();
  }

  HwAcceleratorSet hardware_accelerators =
      GetRequestedHardwareAccelerators(params);

  if (use_npu) {
    // Set default QNN options
    LITERT_ASSIGN_OR_ABORT(
        auto& qnn_opts,
        compilation_options.GetOptions<litert::qualcomm::QualcommOptions>());
    qnn_opts.SetLogLevel(litert::qualcomm::QualcommOptions::LogLevel::kOff);
    qnn_opts.SetHtpPerformanceMode(
        litert::qualcomm::QualcommOptions::HtpPerformanceMode::kBurst);
    qnn_opts.SetUseFoldReLU(false);
    qnn_opts.SetUseConvHMX(true);
    qnn_opts.SetOptimizationLevel(
        litert::qualcomm::QualcommOptions::OptimizationLevel::
            kOptimizeForInferenceO3);

    // Set default MTK options
    LITERT_ASSIGN_OR_ABORT(
        auto& mtk_opts,
        compilation_options.GetOptions<litert::mediatek::MediatekOptions>());
    if (mediatek_nerun_pilot_version == "version9") {
      mtk_opts.SetNeronSDKVersionType(
          litert::mediatek::MediatekOptions::NeronSDKVersion::kVersion9);
    }
    mtk_opts.SetPerformanceMode(
        litert::mediatek::MediatekOptions::PerformanceMode::kTurboBoost);
    mtk_opts.SetEnableL1CacheOptimizations(true);

    // Google Tensor options
    LITERT_ASSIGN_OR_ABORT(
        auto& google_tensor_opts,
        compilation_options
            .GetOptions<litert::google_tensor::GoogleTensorOptions>());
    google_tensor_opts.SetPerformanceMode(
        google_tensor::GoogleTensorOptions::PerformanceMode::kBurst);

    // Parser user provided NPU options
    auto status = tools::OptionsParserRegistry::GetInstance().RunAllParsers(
        compilation_options);
    if (!status) {
      LITERT_LOG(LITERT_ERROR, "Failed to run options parsers: %s",
                 status.Error().Message().c_str());
      std::abort();
    }
  }

  if (use_gpu) {
    LITERT_ASSIGN_OR_ABORT(auto& gpu_options,
                           compilation_options.GetGpuOptions());
    // Enable benchmark mode to run clFinish() after each inference.
    gpu_options.EnableBenchmarkMode(/*enabled=*/true);
    if (gpu_backend == "webgpu") {
      gpu_options.SetBackend(GpuOptions::Backend::kWebGpu);
    } else if (gpu_backend == "opengl" || gpu_backend == "gl") {
      gpu_options.SetBackend(GpuOptions::Backend::kOpenGl);
    }
    if (gpu_precision == "fp32") {
      gpu_options.SetPrecision(GpuOptions::Precision::kFp32);
    } else if (gpu_precision == "fp16") {
      gpu_options.SetPrecision(GpuOptions::Precision::kFp16);
    } else if (gpu_precision == "auto") {
      gpu_options.SetPrecision(GpuOptions::Precision::kDefault);
    } else {
      LITERT_LOG(LITERT_ERROR, "Invalid gpu-precision: %s",
                 gpu_precision.c_str());
      std::abort();
    }
    if (gpu_low_priority) {
      gpu_options.SetPriority(GpuOptions::Priority::kLow);
    }
    if (enable_weight_sharing) {
      gpu_options.EnableConstantTensorSharing(true);
    }
    if (convert_weights_on_gpu) {
      gpu_options.SetConvertWeightsOnGpu(true);
    }
    if (!gpu_serialization_dir.empty()) {
      gpu_options.SetSerializationDir(gpu_serialization_dir.c_str());
    }
    if (!gpu_model_cache_key.empty()) {
      gpu_options.SetModelCacheKey(gpu_model_cache_key.c_str());
    }
    if (gpu_serialize_external_tensors) {
      gpu_options.SetSerializeExternalTensors(true);
    }
    if (gpu_prefer_texture_weights) {
      gpu_options.SetPreferTextureWeights(true);
    }
    if (gpu_wait_for_weights_conversion_complete) {
      gpu_options.WaitForWeightsConversionComplete(true);
    }
    if (gpu_cache_compiled_programs_only) {
      gpu_options.CacheCompiledProgramsOnly(true);
    }
    gpu_options.SetMadviseOriginalSharedTensors(
        gpu_madvise_original_shared_tensors);

    auto use_profiler = params.Get<bool>("use_profiler");
    if (use_profiler) {
      gpu_options.SetPriority(GpuOptions::Priority::kLow);
    }
  }

  if (hardware_accelerators & HwAccelerators::kCpu) {
    const bool has_xnnpack_weight_cache_file_path =
        !xnnpack_weight_cache_file_path.empty();
    if (num_threads > 0 || has_xnnpack_weight_cache_file_path) {
      auto abort_on_error = [](Expected<void> result, const char* option_name) {
        if (!result.HasValue()) {
          LITERT_LOG(LITERT_ERROR, "Failed to set %s: %s", option_name,
                     result.Error().Message().c_str());
          std::abort();
        }
      };
      LITERT_ASSIGN_OR_ABORT(auto& cpu_options,
                             compilation_options.GetCpuOptions());
      if (num_threads > 0) {
        abort_on_error(cpu_options.SetNumThreads(num_threads), "num_threads");
      }
      if (has_xnnpack_weight_cache_file_path) {
        abort_on_error(cpu_options.SetXNNPackWeightCachePath(
                           xnnpack_weight_cache_file_path.c_str()),
                       "xnnpack_weight_cache_file_path");
      }
    }
  }

  compilation_options.SetHardwareAccelerators(hardware_accelerators);

  if (use_profiler) {
    LITERT_ASSIGN_OR_ABORT(auto& runtime_options,
                           compilation_options.GetRuntimeOptions());
    runtime_options.SetEnableProfiling(/*enabled=*/true);
  }

  return compilation_options;
}

litert::Expected<Environment> CreateDefaultEnvironment(
    const BenchmarkParams& params) {
  const int64_t requested_hardware_accelerators =
      GetRequestedHardwareAccelerators(params).value;
  if (!params.Get<bool>("use_npu")) {
    // Only auto-register accelerators required by the selected benchmark path.
    const std::vector<litert::EnvironmentOptions::Option> environment_options =
        {
            litert::EnvironmentOptions::Option{
                litert::EnvironmentOptions::Tag::kAutoRegisterAccelerators,
                requested_hardware_accelerators,
            },
        };
    return litert::Environment::Create(
        litert::EnvironmentOptions(absl::MakeConstSpan(environment_options)));
  }
  auto dispatch_library_path = params.Get<std::string>("dispatch_library_path");
  LITERT_LOG(LITERT_INFO, "dispatch_library_path: %s",
             dispatch_library_path.c_str());
  auto compiler_plugin_library_path =
      params.Get<std::string>("compiler_plugin_library_path");
  LITERT_LOG(LITERT_INFO, "compiler_plugin_library_path: %s",
             compiler_plugin_library_path.c_str());
  auto compiler_cache_path = params.Get<std::string>("compiler_cache_path");
  LITERT_LOG(LITERT_INFO, "compiler_cache_path: %s",
             compiler_cache_path.c_str());

  const std::vector<litert::EnvironmentOptions::Option> environment_options = {
      litert::EnvironmentOptions::Option{
          litert::EnvironmentOptions::Tag::kDispatchLibraryDir,
          dispatch_library_path.c_str(),
      },
      litert::EnvironmentOptions::Option{
          litert::EnvironmentOptions::Tag::kCompilerPluginLibraryDir,
          compiler_plugin_library_path.c_str(),
      },
      litert::EnvironmentOptions::Option{
          litert::EnvironmentOptions::Tag::kCompilerCacheDir,
          compiler_cache_path.c_str(),
      },
      litert::EnvironmentOptions::Option{
          litert::EnvironmentOptions::Tag::kAutoRegisterAccelerators,
          requested_hardware_accelerators,
      },
  };
  return litert::Environment::Create(
      litert::EnvironmentOptions(absl::MakeConstSpan(environment_options)));
}
}  // namespace

TfLiteStatus BenchmarkLiteRtModel::LoadModel() {
  std::string fd_or_graph_path = params_.Get<std::string>("graph");
  LITERT_LOG(LITERT_INFO, "Loading model from: %s", fd_or_graph_path.c_str());
  LITERT_ASSIGN_OR_RETURN(
      auto model_result,
      litert::Model::CreateFromFile(*environment_, fd_or_graph_path),
      AsTfLiteStatus(_ << "Failed to load model."));
  model_ = std::make_unique<litert::Model>(std::move(model_result));
  return kTfLiteOk;
}

TfLiteStatus PopulateInputValueRanges(
    const std::string& value_ranges_string,
    absl::flat_hash_map<std::string, BenchmarkLiteRtModel::ValueRange>*
        input_layer_value_range) {
  std::vector<std::string> value_ranges =
      absl::StrSplit(value_ranges_string, ':');
  for (const auto& val : value_ranges) {
    std::vector<std::string> name_range = absl::StrSplit(val, ',');
    if (name_range.size() != 3) {
      LITERT_LOG(LITERT_ERROR, "Wrong input value range item specified: %s",
                 val.c_str());
      return kTfLiteError;
    }

    // Parse the range value.
    float low, high;
    bool has_low = absl::SimpleAtof(name_range[1], &low);
    bool has_high = absl::SimpleAtof(name_range[2], &high);
    if (!has_low || !has_high || low > high) {
      LITERT_LOG(
          LITERT_ERROR,
          "Wrong low and high value of the input value range specified: %s",
          val.c_str());
      return kTfLiteError;
    }
    (*input_layer_value_range)[name_range[0]] = {low, high};
  }
  return kTfLiteOk;
}

TfLiteStatus BenchmarkLiteRtModel::Init() {
  auto value_ranges_string =
      params_.Get<std::string>("input_layer_value_range");
  if (!value_ranges_string.empty()) {
    TF_LITE_ENSURE_STATUS(PopulateInputValueRanges(value_ranges_string,
                                                   &input_layer_value_range_));
  }

  if (params_.Get<bool>("enable_perfetto")) {
    litert::internal::InitializePerfetto();
  }

  LITERT_ASSIGN_OR_RETURN(
      auto env_result, CreateDefaultEnvironment(params_),
      AsTfLiteStatus(_ << "Failed to create litert environment."));
  environment_ = std::make_unique<litert::Environment>(std::move(env_result));

  TF_LITE_ENSURE_STATUS(LoadModel());

  auto compilation_options = CreateCompiledModelOptions(params_);
  LITERT_ASSIGN_OR_RETURN(auto compiled_model_result,
                          litert::CompiledModelNext::Create(
                              *environment_, *model_, compilation_options),
                          AsTfLiteStatus(_ << "Failed to compile model."));

  compiled_model_ = std::make_unique<litert::CompiledModelNext>(
      std::move(compiled_model_result));

  LiteRtCompiledModelT* compiled_model_ptr = compiled_model_->Get();
  if (compiled_model_ptr == nullptr) {
    LITERT_LOG(LITERT_ERROR, "Compiled model is null");
    return kTfLiteError;
  }
  LITERT_ASSIGN_OR_RETURN(interpreter_, GetInterpreter(compiled_model_ptr),
                          AsTfLiteStatus(_ << "Failed to get interpreter."));

  if (!params_.Get<std::string>("model_runtime_info_output_file").empty()) {
    model_runtime_info_listener_ =
        std::make_unique<ModelRuntimeInfoListener>(interpreter_);
    AddListener(model_runtime_info_listener_.get());
  }

  auto use_profiler = params_.Get<bool>("use_profiler");
  if (use_profiler) {
    LITERT_ASSIGN_OR_ABORT(profiler_, compiled_model_->GetProfiler());
    profiler_.StartProfiling();
  }
  LITERT_ASSIGN_OR_RETURN(
      std::string signature, GetCurrentSignatureKey(),
      AsTfLiteStatus(_ << "Failed to get current signature key."));

  log_output_ = std::make_unique<BenchmarkLoggingListener>([this]() {
    if (profiler_) {
      auto res = profiler_.GetProfileSummary(compiled_model_->Get());
      if (res.HasValue()) {
        return res.Value();
      }
    }
    return std::string("");
  });
  log_output_->SetBenchmarkSubgraph(signature);
  AddListener(log_output_.get());
  LITERT_ASSIGN_OR_RETURN(
      auto input_buffers_result, compiled_model_->CreateInputBuffers(signature),
      AsTfLiteStatus(_ << "Failed to create input buffer."));
  input_buffers_ = std::make_unique<std::vector<litert::TensorBuffer>>(
      std::move(input_buffers_result));

  LITERT_ASSIGN_OR_RETURN(
      auto output_buffers_result,
      compiled_model_->CreateOutputBuffers(signature),
      AsTfLiteStatus(_ << "Failed to create output buffer."));
  output_buffers_ = std::make_unique<std::vector<litert::TensorBuffer>>(
      std::move(output_buffers_result));

  return kTfLiteOk;
}

TfLiteStatus BenchmarkLiteRtModel::PrepareInputData() {
  auto signature = params_.Get<std::string>("signature_to_run_for");
  LITERT_ASSIGN_OR_RETURN(auto input_names,
                          compiled_model_->GetSignatureInputNames(signature),
                          AsTfLiteStatus(_ << "Failed to get input names."));

  if (input_names.size() != input_buffers_->size()) {
    LITERT_LOG(LITERT_ERROR,
               "Input names count %zu does not match input buffers count %zu",
               input_names.size(), input_buffers_->size());
    return kTfLiteError;
  }

  int index = 0;
  for (auto& buffer : *input_buffers_) {
    std::string name(input_names[index]);
    float low = 0.0f;
    float high = 0.0f;
    if (auto it = input_layer_value_range_.find(name);
        it != input_layer_value_range_.end()) {
      low = it->second.low;
      high = it->second.high;
    }

    auto t_data = CreateRandomTensorData(buffer, name, low, high);
    auto res = buffer.Write<char>(absl::MakeSpan(
        reinterpret_cast<char*>(t_data.data.get()), t_data.bytes));
    if (!res.HasValue()) {
      LITERT_LOG(LITERT_ERROR, "PrepareInputData '%s' failed: %s", name.c_str(),
                 res.Error().Message().c_str());
      return kTfLiteError;
    }

    ++index;
  }
  return kTfLiteOk;
}

int BenchmarkLiteRtModel::TotalNodeCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()->GetDelegationMetrics().total_node_count
             : 0;
}

int BenchmarkLiteRtModel::NpuDelegatedNodeCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .npu_delegated_node_count
             : 0;
}

int BenchmarkLiteRtModel::NpuPartitionCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .npu_partition_count
             : 0;
}

int BenchmarkLiteRtModel::GpuDelegatedNodeCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .gpu_delegated_node_count
             : 0;
}

int BenchmarkLiteRtModel::GpuPartitionCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .gpu_partition_count
             : 0;
}

int BenchmarkLiteRtModel::CpuDelegatedNodeCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .cpu_delegated_node_count
             : 0;
}

int BenchmarkLiteRtModel::CpuPartitionCount() const {
  return (compiled_model_ && compiled_model_->Get())
             ? compiled_model_->Get()
                   ->GetDelegationMetrics()
                   .cpu_partition_count
             : 0;
}

}  // namespace litert::benchmark
