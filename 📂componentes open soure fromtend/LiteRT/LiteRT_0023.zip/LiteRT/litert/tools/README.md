# LiteRT Tools Overview

This directory contains a suite of command-line tools to help you develop,
debug, and benchmark your LiteRT models.

## `run_model`

A handy tool for executing LiteRT models using the CompiledModel API. It
supports running models on different hardware accelerators (CPU, GPU, NPU) with
various debugging and benchmarking options.

### Basic Usage

```bash
run_model --graph=<model_path>
```

### Complete Parameter Reference

#### Required Parameters

-   **`--graph`** (string): Path to the LiteRT model file (.tflite)

    ```bash
    run_model --graph=/path/to/model.tflite
    ```

#### Hardware Acceleration Parameters

-   **`--accelerator`** (string, default: "cpu"): Specifies which hardware
    backend to use

    -   Valid values: `cpu`, `gpu`, `npu`

        ```bash
        run_model --graph=model.tflite --accelerator=gpu
        ```

-   **`--dispatch_library_dir`** (string): Path to dispatch library directory
    (required for NPU)

    -   Contains libLiteRtDispatch_xxx.so files

        ```bash
        run_model
        --graph=model.tflite --accelerator=npu
        --dispatch_library_dir=/path/to/dispatch/libs
        ```

-   **`--compiler_plugin_library_dir`** (string): Path to compiler plugin
    directory (for JIT compilation)

    ```bash
    run_model --graph=model.tflite --compiler_plugin_library_dir=/path/to/compiler/plugins
    ```

#### Execution Parameters

-   **`--iterations`** (size_t, default: 1): Number of times to execute the
    model

    -   Reports timing statistics: first run, slowest, fastest, and average

        ```bash
        run_model --graph=model.tflite --iterations=100
        ```

-   **`--signature_index`** (size_t, default: 0): Index of model signature to
    run (for multi-signature models)

    ```bash
    run_model --graph=model.tflite --signature_index=1
    ```

-   **`--input_dir`** (string, default: ""): Path to a folder containing `.raw`
    input files named after model input tensor names (e.g. `<input_name>.raw`).

    ```bash
    run_model --graph=model.tflite --input_dir=/path/to/inputs
    ```

-   **`--quantize_inputs`** (bool, default: false): Automatically quantize
    unquantized (FP32) input data from `--input_dir` when model inputs are
    quantized (using the model's per-tensor scale and zero point).

    ```bash
    run_model --graph=model.tflite --input_dir=/path/to/inputs --quantize_inputs=true
    ```

#### Debug and Analysis Parameters

-   **`--print_tensors`** (bool, default: false): Print tensor values after
    execution

    ```bash
    run_model --graph=model.tflite --print_tensors=true
    ```

-   **`--compare_numerical`** (bool, default: false): Fill inputs with test
    pattern for numerical comparison

    -   Fills inputs with rotating values (0.0, 0.1, 0.2, ..., 0.9)
    -   Also enables tensor statistics printing

        ```bash
        run_model --graph=model.tflite --compare_numerical=true
        ```

-   **`--sample_size`** (size_t, default: 5): Number of sample elements to print
    from tensors

    -   Prints samples from beginning, middle, and end of tensors
    -   Only used with `--print_tensors` or `--compare_numerical`

        ```bash
        run_model --graph=model.tflite --print_tensors=true --sample_size=10
        ```

### Usage Examples

#### CPU Execution (default)

```bash
run_model --graph=model.tflite
```

#### GPU Execution

```bash
run_model --graph=model.tflite --accelerator=gpu
```

#### NPU Execution via Dispatch API

```bash
run_model --graph=model.tflite --accelerator=npu --dispatch_library_dir=/path/to/dispatch
```

#### Performance Benchmarking

```bash
# Run 50 iterations and report timing statistics
run_model --graph=model.tflite --accelerator=gpu --iterations=50
```

#### Debugging with Tensor Inspection

```bash
# Print all tensor values with 10 samples each
run_model --graph=model.tflite --print_tensors=true --sample_size=10

# Run with test pattern and compare numerical results
run_model --graph=model.tflite --compare_numerical=true
```

#### Multi-Signature Model

```bash
# Run the second signature (index 1) of a model
run_model --graph=model.tflite --signature_index=1 --print_tensors=true
```

#### Complete Example with All Debug Options

```bash
run_model \
  --graph=model.tflite \
  --accelerator=npu \
  --dispatch_library_dir=/path/to/dispatch \
  --iterations=10 \
  --print_tensors=true \
  --compare_numerical=true \
  --sample_size=20
```

### Test with Custom Inputs

#### Prepare Inputs

Prepare an input folder containing all input files in .raw format, with each
filename corresponding to the model's input signature. See Python example below:

```py
import numpy as np
from ai_edge_litert.compiled_model import CompiledModel
from pathlib import Path

MODEL_PATH = "/path/to/model.tflite"
OUTPUT_FOLDER = "/output/folder/for/raw_files"

Path(OUTPUT_FOLDER).mkdir(parents=True, exist_ok=True)

compiled_model = CompiledModel.from_file(MODEL_PATH)

# The signature key of the first signature is used in this example.
signature_key = compiled_model.get_signature_by_index(0)["key"]
input_details = compiled_model.get_input_tensor_details(signature_key)

for tensor_name, detail in input_details.items():
    # Random data is used below, or you can read inputs from images here.
    # Use np.random.randint with dtype for integer types.
    data = np.random.random(detail["shape"]).astype(detail["dtype"])
    data.tofile(Path(OUTPUT_FOLDER) / f"{tensor_name}.raw")
```

Then specify the input folder at `--input_dir`:

```bash
run_model --graph=model.tflite --signature_index=0 --input_dir=inputs
```

#### Automatic Input Quantization

When running quantized models, you can provide unquantized standard
floating-point (FP32) inputs in the `.raw` files (e.g. from float images or
preprocessing) and have `run_model` automatically quantize the inputs according
to the model's per-tensor quantization parameters:

```bash
run_model --graph=model.tflite --signature_index=0 --input_dir=inputs --quantize_inputs=true
```

The tool will read the FP32 floats, apply affine quantization
($q = \text{round}(x / \text{scale}) + \text{zero\_point}$) with boundary
clamping, and fill the target quantized tensor buffers (e.g. `INT8`, `UINT8`,
`INT16`, `UINT16`, `INT32`). Raw quantized inputs can also continue to be
passed directly.

### Vendor-Specific Flags

The tool also supports vendor-specific flags when compiled with appropriate
options: - Qualcomm: Additional logging and runtime configuration flags -
MediaTek: Hardware-specific optimization flags - Google Tensor: Custom runtime
parameters

Note: These flags are only available when the tool is built with the
corresponding vendor support enabled.

## `run_model_simple`

This is simpler version of `run_model` that only has basic CompiledModel usage.
It only requires single file (run_model_simple.cc) to build.

## `analyze_model_main`

Inspect the structure of a LiteRT model. It can provide a summary or a detailed
view of the model's subgraphs and operators.

### Model Summary

```bash
analyze_model_main --model_path=<model_path> --only_summarize
```

### Full Analysis

```bash
analyze_model_main --model_path=<model_path>
```

## `dump_ops`

Splits a LiteRT model into multiple smaller models, each containing a single
operator from the original model. This is useful for isolating specific operators
for debugging or benchmarking.

### Basic Usage

```bash
dump_ops --model_path=<model_path>
```

### Batch Mode

Process multiple models in a directory.

```bash
dump_ops --input_dir=<directory_path> --output_dir=<output_dir>
```

The tool will:
1.  Iterate through all files in the input directory.
2.  Attempt to load each file as a LiteRT model.
3.  Dump ops for valid models, prefixing output files with the model name.
4.  Report statistics at the end (models processed, unique op codes, etc.).

### Parameter Reference

-   **`--model_path`** (string, required for single mode): Path to the input
    LiteRT model file (.tflite).
-   **`--input_dir`** (string, required for batch mode): Directory containing
    tflite models for batch processing.
-   **`--output_dir`** (string, default: "/tmp/dump_ops"): Directory where the
    extracted single-op models will be saved.
-   **`--filter_opcode`** (string, optional): Only dump operators whose opcode
    contains this substring.
-   **`--unique`** (bool, default: false): If true, only dump unique operators
    (deduplicated by opcode and options).

## `benchmark_model`

Benchmark the performance of a LiteRT model on different hardware with improved
readability and control over output verbosity.

### Basic Usage

```bash
benchmark_model --graph=<model_path> --use_cpu
```

### Hardware Acceleration Options

-   `--use_cpu`: Use CPU acceleration (default: true)
-   `--use_gpu`: Use GPU acceleration
-   `--use_npu`: Use NPU acceleration

### Examples

#### Standard benchmark with clean output

```bash
benchmark_model --graph=model.tflite --use_gpu
```

### Benchmark Parameters

-   `--num_runs` (default: 50): Target number of benchmark iterations
-   `--min_secs` (default: 1.0): Minimum seconds to run, may increase actual
    runs
-   `--max_secs` (default: 150.0): Maximum seconds to run, may limit actual runs
-   `--warmup_runs` (default: 1): Number of warmup iterations before
    benchmarking
-   `--warmup_min_secs` (default: 0.5): Minimum warmup duration
-   `--input_layer_value_range`: A map-like string representing value range for
    integer and float input layers. Each item is separated by ':', and the item
    value consists of input layer name and range values (both low and high are
    inclusive) separated by ',', e.g., input1,1.0,2.0:input2,0,254

### Output Format

**Standard Output:**

```
========== BENCHMARK RESULTS ==========
Model initialization: 45.32 ms              # One-time model loading cost
First inference:      120.45 ms             # Very first run (often slower)
Warmup (avg):         98.76 ms (1 runs)     # Warmup to prime caches
Inference (avg):      85.23 ms (50 runs)    # Main benchmark result
Inference (min):      82.10 ms              # Fastest single run
Inference (max):      92.45 ms              # Slowest single run
Inference (std):      3.21 ms               # Standard deviation

Throughput:           12.45 MB/s            # Input data processed per second

Memory Usage:
Init footprint:       25.60 MB              # Memory after model load
Overall footprint:    32.40 MB              # Total memory used
Peak memory:          35.20 MB              # Maximum memory spike
======================================
```

### Understanding the Metrics

-   **Warmup runs**: Initial runs to "warm up" the system (fill caches, trigger
    JIT compilation). These are excluded from final statistics.
-   **Inference runs**: The actual benchmark iterations used for performance
    measurement.
-   **Throughput**: Calculated as (input_size_bytes × runs_per_second) / MB,
    showing data processing rate.
-   **First/curr**: First shows the first benchmark run time, curr shows the
    most recent run time.

## `apply_plugin`

Apply a hardware-specific compiler plugin to a model. This is used to
pre-compile a model for a specific hardware target, which can improve
performance and reduce on-device compilation time.

### Basic Usage

```bash
apply_plugin --model=<input_model_path> --soc_manufacturer=<manufacturer> --soc_model=<soc_model> --libs=<path_to_plugin> --o=<output_model_path>
```

## `build_custom_npu_model_main`

Construct a LiteRT model containing a custom NPU Dispatch operator and compiled
NPU bytecode binary payload (e.g., Qualcomm context binary, MediaTek binary).

### Basic Usage

```bash
blaze run //litert/tools/build_custom_npu_model:build_custom_npu_model_main -- \
  --model=/path/to/qnn_partition_0_0.bin \
  -o /path/to/output_model.tflite \
  --input_shapes="1x256x256x3" \
  --output_shapes="1x256x256x6" \
  --input_dtypes="f32" \
  --output_dtypes="f32" \
  --soc_manufacturer=Qualcomm \
  --soc_model=SM8750 \
  --entry_point=qnn_partition_0
```

### Parameter Reference

-   **`--model`** (string, required): Path to compiled NPU bytecode binary file
    (e.g., Qualcomm context binary).
-   **`-o` / `--output_model`** (string, required): Output `.tflite` model path.
-   **`--input_shapes`** (string, required): Input tensor dimensions in
    `AxBxCxD` format (e.g. `'1x256x256x3'` or `'1x256x256x3,1x128'` for multiple
    inputs).
-   **`--output_shapes`** (string, required): Output tensor dimensions in
    `AxBxCxD` format (e.g. `'1x256x256x6'` or `'1x1000,1x128'`).
-   **`--input_dtypes`** (string, default: `"f32"`): Input element types
    (`f32`, `i32`, `u8`, `i8`, `i16`, `f16`, `bool`).
-   **`--output_dtypes`** (string, default: `"f32"`): Output element types
    (`f32`, `i32`, `u8`, `i8`, `i16`, `f16`, `bool`).
-   **`--input_names`** (string, optional): Custom input tensor names (e.g.
    `'image,mask'`, default: `'input_0,input_1'`).
-   **`--output_names`** (string, optional): Custom output tensor names (e.g.
    `'logits,scores'`, default: `'output_0,output_1'`).
-   **`--soc_manufacturer`** (string, optional): Target SoC manufacturer (e.g.,
    `Qualcomm`, `MediaTek`).
-   **`--soc_model`** (string, optional): Target SoC model (e.g., `SM8750`,
    `PTL`).
-   **`--entry_point`** (string, default: `"main"`): Entry point graph/function
    name within NPU bytecode (e.g., `qnn_partition_0`).
-   **`--signature_key`** (string, default: `"serving_default"`): TFLite
    signature key name.

## `npu_numerics_check`

Compare the output of a model running on an NPU with the output from a CPU to
check for numerical differences. This is useful for verifying the correctness of
the NPU implementation.

### Basic Usage

```bash
npu_numerics_check --cpu_model=<cpu_model_path> --npu_model=<npu_model_path> --dispatch_library_dir=<path_to_dispatch_lib>
```

### Test with Custom Inputs

See [Prepare Inputs](#prepare-inputs) section for generating custom inputs.

Then specify the input folder at `--input_dir` when running
`npu_numerics_check`. `bash npu_numerics_check --cpu_model=<cpu_model_path>
--npu_model=<npu_model_path> --dispatch_library_dir=<path_to_dispatch_lib>
--input_dir=<path_to_input_folder>`

## `culprit_finder`

A powerful debugging tool to identify the specific operator ("culprit") in a
model that causes issues (e.g., crashes, numerical errors) when using hardware
acceleration. It performs a binary search over the model's operators to isolate
the problematic one. Please see the subdirectory for more detailed information.
