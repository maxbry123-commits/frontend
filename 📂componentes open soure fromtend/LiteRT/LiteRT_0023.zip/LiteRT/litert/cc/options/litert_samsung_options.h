// Copyright 2026 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_LITERT_CC_OPTIONS_LITERT_SAMSUNG_OPTIONS_H_
#define THIRD_PARTY_ODML_LITERT_LITERT_CC_OPTIONS_LITERT_SAMSUNG_OPTIONS_H_

#include <memory>

#include "litert/c/litert_common.h"
#include "litert/c/options/litert_samsung_options.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/cc/options/litert_concrete_options_base.h"

namespace litert::samsung {

class SamsungOptions : public ConcreteOptionsBase {
 public:
  SamsungOptions() = delete;
  explicit SamsungOptions(LrtSamsungOptions options)
      : options_(options, LrtDestroySamsungOptions) {}

  // Delete copy constructor and assignment, keep move constructor
  SamsungOptions(const SamsungOptions&) = delete;
  SamsungOptions& operator=(const SamsungOptions&) = delete;
  SamsungOptions(SamsungOptions&&) = default;
  SamsungOptions& operator=(SamsungOptions&&) = default;

  ~SamsungOptions() override = default;

  static const char* Discriminator() {
    return LrtSamsungOptionsGetIdentifier();
  }

  static Expected<SamsungOptions> Create() {
    LrtSamsungOptions options = nullptr;
    LITERT_RETURN_IF_ERROR(LrtCreateSamsungOptions(&options));
    return SamsungOptions(options);
  }

  LrtSamsungOptions Release() { return options_.release(); }
  LrtSamsungOptions Get() const { return options_.get(); }

  LiteRtStatus GetOpaqueOptionsData(
      const char** identifier, void** payload,
      void (**payload_deleter)(void*)) const override {
    return LrtGetOpaqueSamsungOptionsData(Get(), identifier, payload,
                                          payload_deleter);
  }

  /// @brief This option hints whether current model is LLM. This influences
  /// compilation behavior. Defaults to `false`.
  Expected<void> SetEnableLargeModelSupport(bool large_model_support) {
    LITERT_RETURN_IF_ERROR(LrtSamsungOptionsSetEnableLargeModelSupport(
        Get(), large_model_support));
    return {};
  }
  Expected<bool> GetEnableLargeModelSupport() const {
    bool large_model_support;
    LITERT_RETURN_IF_ERROR(LrtSamsungOptionsGetEnableLargeModelSupport(
        Get(), &large_model_support));
    return large_model_support;
  }
  Expected<void> SetSocModel(const char* soc_model) {
    LITERT_RETURN_IF_ERROR(LrtSamsungOptionsSetSocModel(Get(), soc_model));
    return {};
  }
  Expected<const char*> GetSocModel() const {
    const char* soc_model;
    LITERT_RETURN_IF_ERROR(LrtSamsungOptionsGetSocModel(Get(), &soc_model));
    return soc_model;
  }

 private:
  std::unique_ptr<LrtSamsungOptionsT, void (*)(LrtSamsungOptions)> options_;
};

}  // namespace litert::samsung

#endif  // THIRD_PARTY_ODML_LITERT_LITERT_CC_OPTIONS_LITERT_SAMSUNG_OPTIONS_H_
