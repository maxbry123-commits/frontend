// Copyright 2025 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// Copyright (c) Qualcomm Innovation Center, Inc. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#include "litert/cc/options/litert_compiler_options.h"

#include <gtest/gtest.h>
#include "litert/c/litert_common.h"
#include "litert/c/litert_opaque_options.h"
#include "litert/c/options/litert_compiler_options.h"
#include "litert/cc/internal/litert_handle.h"
#include "litert/cc/litert_opaque_options.h"
#include "litert/test/matchers.h"

namespace litert {
namespace {

TEST(CompilerOptionsTest, CreateSetAndGetDummyOptionWorks) {
  LITERT_ASSERT_OK_AND_ASSIGN(::litert::CompilerOptions options,
                              ::litert::CompilerOptions::Create());
  LITERT_EXPECT_OK(options.SetDummyOption(true));
  LITERT_ASSERT_OK_AND_ASSIGN(bool dummy_option, options.GetDummyOption());
  EXPECT_TRUE(dummy_option);
}

TEST(CompilerOptionsTest, CreateOpaqueOptionsWorks) {
  LITERT_ASSERT_OK_AND_ASSIGN(auto options, CompilerOptions::Create());
  LITERT_EXPECT_OK(options.SetDummyOption(true));

  const char* identifier;
  void* payload = nullptr;
  void (*payload_deleter)(void*) = nullptr;
  ASSERT_EQ(LrtGetOpaqueCompilerOptionsData(options.Get(), &identifier,
                                            &payload, &payload_deleter),
            kLiteRtStatusOk);

  LiteRtOpaqueOptions opaque_opts = nullptr;
  ASSERT_EQ(LiteRtCreateOpaqueOptions(identifier, payload, payload_deleter,
                                      &opaque_opts),
            kLiteRtStatusOk);

  litert::OpaqueOptions cpp_opaque_opts =
      litert::OpaqueOptions::WrapCObject(opaque_opts, litert::OwnHandle::kYes);
}

TEST(CompilerOptionsTest, SetAndGetPartitionStrategyReturnsSetValue) {
  LITERT_ASSERT_OK_AND_ASSIGN(::litert::CompilerOptions options,
                              ::litert::CompilerOptions::Create());
  LITERT_EXPECT_OK(options.SetPartitionStrategy(
      kLiteRtCompilerOptionsPartitionStrategyWeaklyConnected));
  LITERT_ASSERT_OK_AND_ASSIGN(auto partition_strategy,
                              options.GetPartitionStrategy());
  EXPECT_EQ(partition_strategy,
            kLiteRtCompilerOptionsPartitionStrategyWeaklyConnected);
}

}  // namespace
}  // namespace litert
