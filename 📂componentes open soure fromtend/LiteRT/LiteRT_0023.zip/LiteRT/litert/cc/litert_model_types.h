// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ODML_LITERT_LITERT_CC_LITERT_MODEL_TYPES_H_
#define ODML_LITERT_LITERT_CC_LITERT_MODEL_TYPES_H_

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "litert/c/litert_common.h"
#include "litert/c/litert_model_types.h"
#include "litert/cc/litert_api_types.h"
#include "litert/cc/litert_common.h"
#include "litert/cc/litert_element_type.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/cc/litert_ranked_tensor_type.h"

/// @file
/// @brief Defines C++ wrappers for the LiteRT model, signature, and tensor
/// types.

namespace litert {

/// @brief The type of quantization scheme. This is the C++ equivalent of
/// `LiteRtQuantizationTypeId`.
// LINT.IfChange(quantization_type_id)
enum class QuantizationTypeId {
  None = kLiteRtQuantizationNone,
  PerTensor = kLiteRtQuantizationPerTensor,
  PerChannel = kLiteRtQuantizationPerChannel,
  BlockWise = kLiteRtQuantizationBlockWise,
};
// LINT.ThenChange(../c/litert_model_types.h:quantization_type_id)

using QuantizationPerTensor = LiteRtQuantizationPerTensor;
using QuantizationPerChannel = LiteRtQuantizationPerChannel;
using QuantizationBlockWise = LiteRtQuantizationBlockWise;

inline bool operator==(QuantizationTypeId lhs, LiteRtQuantizationTypeId rhs) {
  return static_cast<LiteRtQuantizationTypeId>(lhs) == rhs;
}
inline bool operator==(LiteRtQuantizationTypeId lhs, QuantizationTypeId rhs) {
  return lhs == static_cast<LiteRtQuantizationTypeId>(rhs);
}
inline bool operator!=(QuantizationTypeId lhs, LiteRtQuantizationTypeId rhs) {
  return !(lhs == rhs);
}
inline bool operator!=(LiteRtQuantizationTypeId lhs, QuantizationTypeId rhs) {
  return !(lhs == rhs);
}

/// @brief A C++ wrapper for `LiteRtTensor` with limited functionality.
class SimpleTensor {
 public:
  virtual ~SimpleTensor() = default;

  /// @brief Constructs a SimpleTensor.
  /// @param index The index of the tensor.
  /// @param name The name of the tensor.
  /// @param type_id The type ID of the tensor.
  /// @param type The type of the tensor.
  /// @param quantization_type_id The quantization type ID of the tensor.
  /// @param per_tensor_quantization The per-tensor quantization of the tensor.
  /// @param per_channel_quantization The per-channel quantization of the
  /// tensor.
  /// @param block_wise_quantization The block-wise quantization of the tensor.
  explicit SimpleTensor(
      LiteRtParamIndex index, StringView name, LiteRtTensorTypeId type_id,
      std::variant<LiteRtUnrankedTensorType, litert::RankedTensorType>&& type,
      QuantizationTypeId quantization_type_id,
      QuantizationPerTensor per_tensor_quantization,
      QuantizationPerChannel per_channel_quantization,
      QuantizationBlockWise block_wise_quantization)
      : index_(index),
        name_(name),
        type_id_(type_id),
        type_(std::move(type)),
        quantization_type_id_(quantization_type_id),
        per_tensor_quantization_(per_tensor_quantization),
        per_channel_quantization_(per_channel_quantization),
        block_wise_quantization_(block_wise_quantization) {}

  // Allow copying SimpleTensors.
  SimpleTensor(const SimpleTensor& other) = default;
  SimpleTensor(SimpleTensor&&) = default;
  SimpleTensor& operator=(const SimpleTensor& other) = default;
  SimpleTensor& operator=(SimpleTensor&&) = default;

  /// @brief Returns the element type of the tensor.
  ::litert::ElementType ElementType() const {
    if (type_id_ == kLiteRtUnrankedTensorType) {
      LITERT_ASSIGN_OR_ABORT(auto tensor_type, UnrankedTensorType());
      return static_cast<enum ElementType>(tensor_type.element_type);
    } else {
      LITERT_ASSIGN_OR_ABORT(auto tensor_type, RankedTensorType());
      return tensor_type.ElementType();
    }
  }

  /// @brief Returns whether the tensor has the given ranked tensor type.
  /// @param type The ranked tensor type to check.
  bool HasType(const RankedTensorType& type) const {
    auto t = RankedTensorType();
    return t && *t == type;
  }

  /// @brief Returns whether the tensor has the given ranked tensor type.
  /// @param type The ranked tensor type to check.
  bool HasType(const LiteRtRankedTensorType& type) const {
    auto t = RankedTensorType();
    return t && *t == ::litert::RankedTensorType(type);
  }

  /// @brief Returns the type ID of the tensor.
  LiteRtTensorTypeId TypeId() const { return type_id_; }

  /// @brief Returns the unranked tensor type of the tensor.
  /// @return The unranked tensor type, or an error if the tensor is not
  /// unranked.
  Expected<LiteRtUnrankedTensorType> UnrankedTensorType() const {
    if (type_id_ != kLiteRtUnrankedTensorType) {
      return Error(Status::kErrorInvalidArgument,
                   "Not an unranked invalid tensor");
    }
    return std::get<LiteRtUnrankedTensorType>(type_);
  }

  /// @brief Returns the ranked tensor type of the tensor.
  /// @return The ranked tensor type, or an error if the tensor is not ranked.
  Expected<::litert::RankedTensorType> RankedTensorType() const {
    if (type_id_ != kLiteRtRankedTensorType) {
      return Error(Status::kErrorInvalidArgument, "Not a ranked tensor type");
    }
    return std::get<litert::RankedTensorType>(type_);
  }

  /// @brief Returns the name of the tensor.
  StringView Name() const { return name_; }

  /// @brief Returns the index of the tensor.
  std::uint32_t TensorIndex() const { return index_; }

  /// @brief Returns the quantization type ID of the tensor.
  QuantizationTypeId QTypeId() const { return quantization_type_id_; }

  /// @brief Returns whether the tensor has quantization.
  bool HasQuantization() const {
    return quantization_type_id_ != QuantizationTypeId::None;
  }

  /// @brief Returns the per-tensor quantization of the tensor.
  QuantizationPerTensor PerTensorQuantization() const {
    return per_tensor_quantization_;
  }

  /// @brief Returns the per-channel quantization of the tensor.
  QuantizationPerChannel PerChannelQuantization() const {
    return per_channel_quantization_;
  }

  /// @brief Returns the block-wise quantization of the tensor.
  QuantizationBlockWise BlockWiseQuantization() const {
    return block_wise_quantization_;
  }

 private:
  std::uint32_t index_;
  std::string_view name_;
  LiteRtTensorTypeId type_id_;
  std::variant<LiteRtUnrankedTensorType, litert::RankedTensorType> type_;
  QuantizationTypeId quantization_type_id_;
  QuantizationPerTensor per_tensor_quantization_;
  QuantizationPerChannel per_channel_quantization_;
  QuantizationBlockWise block_wise_quantization_;
};

/// @brief A simplified C++ wrapper for `LiteRtSignature`, representing a model
/// signature.
class SimpleSignature {
 public:
  virtual ~SimpleSignature() = default;

  /// @brief Constructs a SimpleSignature.
  /// @param key The key of the signature.
  /// @param input_names The names of the input tensors.
  /// @param input_tensors The input tensors.
  /// @param output_names The names of the output tensors.
  /// @param output_tensors The output tensors.
  explicit SimpleSignature(
      StringView key, std::vector<StringView> input_names,
      std::vector<std::unique_ptr<SimpleTensor>> input_tensors,
      std::vector<StringView> output_names,
      std::vector<std::unique_ptr<SimpleTensor>> output_tensors)
      : key_(key),
        input_names_(std::move(input_names)),
        input_tensors_(std::move(input_tensors)),
        output_names_(std::move(output_names)),
        output_tensors_(std::move(output_tensors)) {}

  SimpleSignature(SimpleSignature&&) = default;
  SimpleSignature& operator=(SimpleSignature&&) = default;

  /// @brief Returns the key of the signature.
  StringView Key() const { return key_; }

  /// @brief Returns the names of the input tensors.
  std::vector<StringView> InputNames() const {
    std::vector<StringView> input_names;
    input_names.reserve(input_names_.size());
    for (const auto& input_name : input_names_) {
      input_names.push_back(input_name);
    }
    return input_names;
  }

  /// @brief Returns the names of the output tensors.
  std::vector<StringView> OutputNames() const {
    std::vector<StringView> output_names;
    output_names.reserve(output_names_.size());
    for (const auto& output_name : output_names_) {
      output_names.push_back(output_name);
    }
    return output_names;
  }

  /// @brief Returns the input tensor type for the given input signature name.
  /// @param name The name of the input tensor.
  /// @return The ranked tensor type, or an error if the tensor is not found or
  /// not ranked.
  Expected<RankedTensorType> InputTensorType(StringView name) const {
    LITERT_ASSIGN_OR_RETURN(auto tensor, InputTensor(name));
    return tensor.RankedTensorType();
  }

  /// @brief Returns the input tensor type at the given index.
  /// @param index The index of the input tensor.
  /// @return The ranked tensor type, or an error if the index is out of bounds
  /// or the tensor is not ranked.
  Expected<RankedTensorType> InputTensorType(size_t index) const {
    LITERT_ASSIGN_OR_RETURN(auto tensor, InputTensor(index));
    return tensor.RankedTensorType();
  }

  /// @brief Returns the output tensor type for the given output signature
  /// name.
  /// @param name The name of the output tensor.
  /// @return The ranked tensor type, or an error if the tensor is not found or
  /// not ranked.
  Expected<RankedTensorType> OutputTensorType(StringView name) const {
    LITERT_ASSIGN_OR_RETURN(auto tensor, OutputTensor(name));
    return tensor.RankedTensorType();
  }

  /// @brief Returns the output tensor type at the given index.
  /// @param index The index of the output tensor.
  /// @return The ranked tensor type, or an error if the index is out of bounds
  /// or the tensor is not ranked.
  Expected<RankedTensorType> OutputTensorType(size_t index) const {
    LITERT_ASSIGN_OR_RETURN(auto tensor, OutputTensor(index));
    return tensor.RankedTensorType();
  }

  /// @brief Returns the input tensor for the given input signature name.
  /// @param name The name of the input tensor.
  /// @return The input tensor, or an error if the tensor is not found.
  Expected<const SimpleTensor&> InputTensor(StringView name) const {
    for (int i = 0; i < input_names_.size(); ++i) {
      if (input_names_[i] == name) {
        return *input_tensors_[i];
      }
    }
    return Error(Status::kErrorNotFound, "Input tensor not found");
  }

  /// @brief Returns the input tensor at the given index.
  /// @param index The index of the input tensor.
  /// @return The input tensor, or an error if the index is out of bounds.
  Expected<const SimpleTensor&> InputTensor(size_t index) const {
    if (index >= input_names_.size()) {
      return Error(Status::kErrorInvalidArgument, "Input index out of bounds");
    }
    return *input_tensors_[index];
  }

  /// @brief Returns the output tensor for the given output signature name.
  /// @param name The name of the output tensor.
  /// @return The output tensor, or an error if the tensor is not found.
  Expected<const SimpleTensor&> OutputTensor(StringView name) const {
    for (int i = 0; i < output_names_.size(); ++i) {
      if (output_names_[i] == name) {
        return *output_tensors_[i];
      }
    }
    return Error(Status::kErrorNotFound, "Output tensor not found");
  }

  /// @brief Returns the output tensor at the given index.
  /// @param index The index of the output tensor.
  /// @return The output tensor, or an error if the index is out of bounds.
  Expected<const SimpleTensor&> OutputTensor(size_t index) const {
    if (index >= output_names_.size()) {
      return Error(Status::kErrorInvalidArgument, "Output index out of bounds");
    }
    return *output_tensors_[index];
  }

 private:
  std::string_view key_;
  std::vector<StringView> input_names_;
  std::vector<std::unique_ptr<SimpleTensor>> input_tensors_;
  std::vector<StringView> output_names_;
  std::vector<std::unique_ptr<SimpleTensor>> output_tensors_;
};

}  // namespace litert

#endif  // ODML_LITERT_LITERT_CC_LITERT_MODEL_TYPES_H_
