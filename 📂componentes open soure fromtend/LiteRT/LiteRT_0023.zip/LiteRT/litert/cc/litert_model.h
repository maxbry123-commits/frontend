// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ODML_LITERT_LITERT_CC_LITERT_MODEL_H_
#define ODML_LITERT_LITERT_CC_LITERT_MODEL_H_

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "litert/c/litert_common.h"
#include "litert/c/litert_model.h"
#include "litert/c/litert_model_types.h"
#include "litert/cc/internal/litert_consts.h"
#include "litert/cc/internal/litert_detail.h"
#include "litert/cc/internal/litert_handle.h"
#include "litert/cc/litert_api_types.h"
#include "litert/cc/litert_buffer_ref.h"
#include "litert/cc/litert_common.h"
#include "litert/cc/litert_environment.h"
#include "litert/cc/litert_expected.h"
#include "litert/cc/litert_macros.h"
#include "litert/cc/litert_model_types.h"
#include "litert/cc/litert_ranked_tensor_type.h"
// copybara:uncomment_begin(google_only)
// #ifndef LITERT_NO_ABSL
// #include "tflite/converter/allocation.h"  // IWYU pragma: keep
// #endif  // LITERT_NO_ABSL
// copybara:uncomment_end

/// @file
/// @brief Defines C++ wrappers for the LiteRT model, signature, and tensor
/// types.

namespace litert {

namespace internal::model_detail {

inline StringView FetchTensorName(LiteRtTensor tensor) {
  const char* name;
  internal::AssertOk(LiteRtGetTensorName, tensor, &name);
  return name;
}

inline std::uint32_t FetchTensorIndex(LiteRtTensor tensor) {
  std::uint32_t index;
  internal::AssertOk(LiteRtGetTensorIndex, tensor, &index);
  return index;
}

inline LiteRtTensorTypeId FetchTensorTypeId(LiteRtTensor tensor) {
  LiteRtTensorTypeId type_id;
  internal::AssertOk(LiteRtGetTensorTypeId, tensor, &type_id);
  return type_id;
}

inline std::variant<LiteRtUnrankedTensorType, litert::RankedTensorType>
FetchTensorType(LiteRtTensor tensor, LiteRtTensorTypeId type_id) {
  if (type_id == kLiteRtRankedTensorType) {
    LiteRtRankedTensorType ranked_tensor_type;
    internal::AssertOk(LiteRtGetRankedTensorType, tensor, &ranked_tensor_type);
    return litert::RankedTensorType(ranked_tensor_type);
  } else {
    LiteRtUnrankedTensorType unranked_tensor_type;
    internal::AssertOk(LiteRtGetUnrankedTensorType, tensor,
                       &unranked_tensor_type);
    return unranked_tensor_type;
  }
}

inline QuantizationTypeId FetchTensorQuantizationTypeId(LiteRtTensor tensor) {
  LiteRtQuantizationTypeId quantization_type_id;
  internal::AssertOk(LiteRtGetQuantizationTypeId, tensor,
                     &quantization_type_id);
  return static_cast<QuantizationTypeId>(quantization_type_id);
}

inline QuantizationPerTensor FetchTensorQuantizationPerTensor(
    LiteRtTensor tensor) {
  if (FetchTensorQuantizationTypeId(tensor) != QuantizationTypeId::PerTensor) {
    return {};
  }
  QuantizationPerTensor per_tensor_quantization;
  internal::AssertOk(LiteRtGetPerTensorQuantization, tensor,
                     &per_tensor_quantization);
  return per_tensor_quantization;
}

inline QuantizationPerChannel FetchTensorQuantizationPerChannel(
    LiteRtTensor tensor) {
  if (FetchTensorQuantizationTypeId(tensor) != QuantizationTypeId::PerChannel) {
    return {};
  }
  QuantizationPerChannel per_channel_quantization;
  internal::AssertOk(LiteRtGetPerChannelQuantization, tensor,
                     &per_channel_quantization);
  return per_channel_quantization;
}

inline QuantizationBlockWise FetchTensorQuantizationBlockWise(
    LiteRtTensor tensor) {
  if (FetchTensorQuantizationTypeId(tensor) != QuantizationTypeId::BlockWise) {
    return {};
  }
  QuantizationBlockWise block_wise_quantization;
  internal::AssertOk(LiteRtGetBlockWiseQuantization, tensor,
                     &block_wise_quantization);
  return block_wise_quantization;
}

inline StringView FetchSignatureKey(LiteRtSignature signature) {
  const char* key;
  internal::AssertOk(LiteRtGetSignatureKey, signature, &key);
  return key;
}

inline std::vector<StringView> FetchSignatureInputNames(
    LiteRtSignature signature) {
  LiteRtParamIndex num_inputs;
  internal::AssertOk(LiteRtGetNumSignatureInputs, signature, &num_inputs);
  std::vector<StringView> input_names;
  input_names.reserve(num_inputs);
  for (int i = 0; i < num_inputs; ++i) {
    const char* name;
    internal::AssertOk(LiteRtGetSignatureInputName, signature, i, &name);
    input_names.push_back(name);
  }
  return input_names;
}

inline std::vector<StringView> FetchSignatureOutputNames(
    LiteRtSignature signature) {
  LiteRtParamIndex num_outputs;
  internal::AssertOk(LiteRtGetNumSignatureOutputs, signature, &num_outputs);
  std::vector<StringView> output_names;
  output_names.reserve(num_outputs);
  for (int i = 0; i < num_outputs; ++i) {
    const char* name;
    internal::AssertOk(LiteRtGetSignatureOutputName, signature, i, &name);
    output_names.push_back(name);
  }
  return output_names;
}

inline std::vector<std::unique_ptr<SimpleTensor>> FetchSignatureInputTensors(
    LiteRtSignature signature) {
  LiteRtParamIndex num_inputs;
  internal::AssertOk(LiteRtGetNumSignatureInputs, signature, &num_inputs);
  std::vector<std::unique_ptr<SimpleTensor>> input_tensors;
  input_tensors.reserve(num_inputs);
  for (int i = 0; i < num_inputs; ++i) {
    LiteRtTensor tensor;
    internal::AssertOk(LiteRtGetSignatureInputTensorByIndex, signature, i,
                       &tensor);
    input_tensors.push_back(std::make_unique<SimpleTensor>(
        FetchTensorIndex(tensor), FetchTensorName(tensor),
        FetchTensorTypeId(tensor),
        FetchTensorType(tensor, FetchTensorTypeId(tensor)),
        FetchTensorQuantizationTypeId(tensor),
        FetchTensorQuantizationPerTensor(tensor),
        FetchTensorQuantizationPerChannel(tensor),
        FetchTensorQuantizationBlockWise(tensor)));
  }
  return input_tensors;
}

inline std::vector<std::unique_ptr<SimpleTensor>> FetchSignatureOutputTensors(
    LiteRtSignature signature) {
  LiteRtParamIndex num_outputs;
  internal::AssertOk(LiteRtGetNumSignatureOutputs, signature, &num_outputs);
  std::vector<std::unique_ptr<SimpleTensor>> output_tensors;
  output_tensors.reserve(num_outputs);
  for (int i = 0; i < num_outputs; ++i) {
    LiteRtTensor tensor;
    internal::AssertOk(LiteRtGetSignatureOutputTensorByIndex, signature, i,
                       &tensor);
    output_tensors.push_back(std::make_unique<SimpleTensor>(
        FetchTensorIndex(tensor), FetchTensorName(tensor),
        FetchTensorTypeId(tensor),
        FetchTensorType(tensor, FetchTensorTypeId(tensor)),
        FetchTensorQuantizationTypeId(tensor),
        FetchTensorQuantizationPerTensor(tensor),
        FetchTensorQuantizationPerChannel(tensor),
        FetchTensorQuantizationBlockWise(tensor)));
  }
  return output_tensors;
}

inline std::unique_ptr<SimpleTensor> FetchSignatureOutputTensorByIndex(
    LiteRtSignature signature, LiteRtParamIndex output_index) {
  LiteRtTensor tensor;
  internal::AssertOk(LiteRtGetSignatureOutputTensorByIndex, signature,
                     output_index, &tensor);
  return std::make_unique<SimpleTensor>(
      FetchTensorIndex(tensor), FetchTensorName(tensor),
      FetchTensorTypeId(tensor),
      FetchTensorType(tensor, FetchTensorTypeId(tensor)),
      FetchTensorQuantizationTypeId(tensor),
      FetchTensorQuantizationPerTensor(tensor),
      FetchTensorQuantizationPerChannel(tensor),
      FetchTensorQuantizationBlockWise(tensor));
}

}  // namespace internal::model_detail

/// @brief A C++ wrapper for `LiteRtModel`, representing a LiteRT model.
///
/// \internal
class Model : public internal::BaseHandle<LiteRtModel> {
 public:
  Model() = default;

  static Model CreateFromOwnedHandle(LiteRtModel model) {
    return Model(model, OwnHandle::kYes);
  }

  static Model CreateFromNonOwnedHandle(LiteRtModel model) {
    return Model(model, OwnHandle::kNo);
  }

  static Expected<Model> CreateFromFile(Environment& env,
                                        const std::string& filename) {
    LiteRtModel model;
    if (auto status =
            LiteRtCreateModelFromFile(env.Get(), filename.c_str(), &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from file");
    }
    return CreateFromOwnedHandle(model);
  }

  /// @deprecated Use API with explicit Environment instead.
  [[deprecated("Use API with explicit Environment instead.")]]
  static Expected<Model> CreateFromFile(const std::string& filename) {
    const auto& env = GetDefaultEnvironment();
    LiteRtModel model;
    if (auto status =
            LiteRtCreateModelFromFile(env->Get(), filename.c_str(), &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from file");
    }
    return CreateFromOwnedHandle(model);
  }

  /// @brief Creates a model from a buffer.
  ///
  /// The caller must ensure that the buffer remains valid for the lifetime of
  /// the model.
  static Expected<Model> CreateFromBuffer(Environment& env,
                                          BufferRef<uint8_t> buffer) {
    LiteRtModel model;
    if (auto status = LiteRtCreateModelFromBuffer(env.Get(), buffer.Data(),
                                                  buffer.Size(), &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from buffer");
    }
    return CreateFromOwnedHandle(model);
  }

  /// @brief Creates a model from a buffer.
  ///
  /// The caller must ensure that the buffer remains valid for the lifetime of
  /// the model.
  /// @deprecated Use API with explicit Environment instead.
  static Expected<Model> CreateFromBuffer(BufferRef<uint8_t> buffer) {
    const auto& env = GetDefaultEnvironment();
    LiteRtModel model;
    if (auto status = LiteRtCreateModelFromBuffer(env->Get(), buffer.Data(),
                                                  buffer.Size(), &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from buffer");
    }
    return CreateFromOwnedHandle(model);
  }

  /// @brief Creates a model from a file descriptor region.
  ///
  /// LiteRT duplicates the file descriptor internally; the caller retains
  /// ownership of `fd`.
  static Expected<Model> CreateFromFd(Environment& env, int fd, size_t offset,
                                      size_t size) {
    LiteRtModel model;
    if (auto status =
            LiteRtCreateModelFromFd(env.Get(), fd, offset, size, &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from fd");
    }
    return CreateFromOwnedHandle(model);
  }

  /// @brief Creates a model from a file descriptor region.
  ///
  /// LiteRT duplicates the file descriptor internally; the caller retains
  /// ownership of `fd`.
  /// @deprecated Use API with explicit Environment instead.
  static Expected<Model> CreateFromFd(int fd, size_t offset, size_t size) {
    const auto& env = GetDefaultEnvironment();
    LiteRtModel model;
    if (auto status =
            LiteRtCreateModelFromFd(env->Get(), fd, offset, size, &model);
        status != kLiteRtStatusOk) {
      return Unexpected(ToStatus(status), "Failed to load model from fd");
    }
    return CreateFromOwnedHandle(model);
  }

#if !defined(LITERT_DYNAMIC_RUNTIME) && !defined(LITERT_NO_ABSL)
  // copybara:uncomment_begin(google_only)
  // /// @internal
  // /// @brief Creates a model from an owned TFLite allocation.
  // ///
  // /// @note This is an internal experimental API which is not available through
  // /// libLiteRt.so. It's not part of the official LiteRT public C++ API.
  // static Expected<Model> CreateFromAllocation(
      // Environment& env, std::unique_ptr<tflite::Allocation> allocation) {
    // LiteRtModel model;
    // LiteRtAllocation c_allocation = allocation.release();
    // if (auto status = LiteRtCreateModelFromAllocation(
            // env.Get(), c_allocation, &model);
        // status != kLiteRtStatusOk) {
      // return Unexpected(ToStatus(status),
                        // "Failed to load model from allocation");
    // }
    // return CreateFromOwnedHandle(model);
  // }
// 
  // /// @internal
  // /// @brief Creates a model from an owned TFLite allocation.
  // ///
  // /// @note This is an internal experimental API which is not available through
  // /// libLiteRt.so. It's not part of the official LiteRT public C++ API.
  // static Expected<Model> CreateFromAllocation(
      // std::unique_ptr<tflite::Allocation> allocation) {
    // LiteRtModel model;
    // LiteRtAllocation c_allocation = allocation.release();
    // if (auto status = LiteRtCreateModelFromAllocation(
            // /*environment=*/nullptr, c_allocation, &model);
        // status != kLiteRtStatusOk) {
      // return Unexpected(ToStatus(status),
                        // "Failed to load model from allocation");
    // }
    // return CreateFromOwnedHandle(model);
  // }
  // copybara:uncomment_end
#endif  // !defined(LITERT_DYNAMIC_RUNTIME) && !defined(LITERT_NO_ABSL)

  Expected<Span<const uint8_t>> Metadata(
      const std::string& metadata_key) const {
    const void* buffer;
    size_t buffer_size;
    if (LiteRtGetModelMetadata(Get(), metadata_key.data(), &buffer,
                               &buffer_size) != kLiteRtStatusOk) {
      return Unexpected(Status::kErrorNotFound, "Metadata key not found");
    }
    return internal::MakeLiteRtSpan(static_cast<const uint8_t*>(buffer),
                                    buffer_size);
  }

  size_t GetNumSignatures() const {
    LiteRtParamIndex num_signatures;
    internal::AssertOk(LiteRtGetNumModelSignatures, Get(), &num_signatures);
    return num_signatures;
  }

  /// @brief Returns the list of signatures defined in the model.
  Expected<std::vector<SimpleSignature>> GetSignatures() const {
    size_t num_signatures = GetNumSignatures();
    std::vector<SimpleSignature> signatures;
    signatures.reserve(num_signatures);
    for (int i = 0; i < num_signatures; ++i) {
      LITERT_ASSIGN_OR_RETURN(auto signature, GetSignature(i));
      signatures.push_back(std::move(signature));
    }
    return std::move(signatures);
  }

  /// @brief Returns the list of signature key names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureKeys() const {
    return GetSignatureKeysImpl();
  }

  /// @brief Returns the list of input names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureInputNames(
      size_t signature_index) const {
    return GetSignatureInputNamesImpl(signature_index);
  }

  /// @brief Returns the list of input names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureInputNames() const {
    return GetSignatureInputNames(/*signature_index=*/0);
  }

  /// @brief Returns the list of input names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureInputNames(
      StringView signature_key) const {
    LITERT_ASSIGN_OR_RETURN(auto signature, FindSignature(signature_key));
    return signature.InputNames();
  }

  /// @brief Returns the list of output names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureOutputNames(
      size_t signature_index) const {
    return GetSignatureOutputNamesImpl(signature_index);
  }

  /// @brief Returns the list of output names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureOutputNames() const {
    return GetSignatureOutputNames(/*signature_index=*/0);
  }

  /// @brief Returns the list of output names defined in the signature.
  Expected<std::vector<StringView>> GetSignatureOutputNames(
      StringView signature_key) const {
    LITERT_ASSIGN_OR_RETURN(auto signature, FindSignature(signature_key));
    return signature.OutputNames();
  }

  /// @brief Returns the signature at the given index.
  Expected<SimpleSignature> GetSignature(size_t signature_index) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    return SimpleSignature(
        internal::model_detail::FetchSignatureKey(lite_rt_signature),
        internal::model_detail::FetchSignatureInputNames(lite_rt_signature),
        internal::model_detail::FetchSignatureInputTensors(lite_rt_signature),
        internal::model_detail::FetchSignatureOutputNames(lite_rt_signature),
        internal::model_detail::FetchSignatureOutputTensors(lite_rt_signature));
  }

  /// @brief Returns the signature index for the given signature key.
  ///
  /// Returns 0 if the signature key is empty.
  Expected<size_t> GetSignatureIndex(StringView signature_key) const {
    if (signature_key.empty()) {
      return 0;
    }
    size_t num_signatures = GetNumSignatures();
    for (int i = 0; i < num_signatures; ++i) {
      LiteRtSignature lite_rt_signature;
      internal::AssertOk(LiteRtGetModelSignature, Get(), i, &lite_rt_signature);
      auto key = internal::model_detail::FetchSignatureKey(lite_rt_signature);
      if (key == signature_key) {
        return i;
      }
    }
    return Unexpected(Status::kErrorNotFound,
                      "Signature not found: " + std::string(signature_key));
  }

  /// @brief Returns the `SimpleSignature` object for the given signature key.
  ///
  /// Returns the default signature if the signature key is empty.
  Expected<SimpleSignature> FindSignature(StringView signature_key) const {
    LITERT_ASSIGN_OR_RETURN(auto signature_index,
                            GetSignatureIndex(signature_key));
    return GetSignature(signature_index);
  }

  static StringView DefaultSignatureKey() { return kDefaultSignatureKey; }

  /// @brief Returns the tensor type for the n-th input tensor.
  Expected<RankedTensorType> GetInputTensorType(size_t signature_index,
                                                size_t input_index) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    auto input_tensors =
        internal::model_detail::FetchSignatureInputTensors(lite_rt_signature);
    if (input_index >= input_tensors.size()) {
      return Error(Status::kErrorInvalidArgument, "Input index out of bounds");
    }
    return input_tensors[input_index]->RankedTensorType();
  }

  /// @brief Returns the tensor type for the given input tensor name.
  Expected<RankedTensorType> GetInputTensorType(size_t signature_index,
                                                StringView input_name) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    auto input_tensors =
        internal::model_detail::FetchSignatureInputTensors(lite_rt_signature);
    LiteRtParamIndex num_inputs;
    internal::AssertOk(LiteRtGetNumSignatureInputs, lite_rt_signature,
                       &num_inputs);
    for (LiteRtParamIndex i = 0; i < num_inputs; ++i) {
      const char* name;
      internal::AssertOk(LiteRtGetSignatureInputName, lite_rt_signature, i,
                         &name);
      if (StringView(name) == input_name) {
        return input_tensors[i]->RankedTensorType();
      }
    }
    // Keep accepting graph tensor names for callers that used that behavior.
    for (const auto& input_tensor : input_tensors) {
      if (input_tensor->Name() == input_name) {
        return input_tensor->RankedTensorType();
      }
    }
    return Error(Status::kErrorNotFound,
                 "Input tensor not found: " + std::string(input_name));
  }

  /// @brief Returns the tensor type for the given input tensor name.
  Expected<RankedTensorType> GetInputTensorType(StringView signature_key,
                                                StringView input_name) const {
    LITERT_ASSIGN_OR_RETURN(auto index, GetSignatureIndex(signature_key));
    return GetInputTensorType(index, input_name);
  }

  /// @brief Gets the input tensor type of the default signature for a given
  /// input name.
  Expected<RankedTensorType> GetInputTensorType(StringView input_name) const {
    return GetInputTensorType(/*signature_index=*/0, input_name);
  }

  /// @brief Returns the tensor type for the n-th output tensor.
  Expected<RankedTensorType> GetOutputTensorType(size_t signature_index,
                                                 size_t output_index) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    LiteRtParamIndex num_outputs;
    internal::AssertOk(LiteRtGetNumSignatureOutputs, lite_rt_signature,
                       &num_outputs);
    if (output_index >= static_cast<size_t>(num_outputs)) {
      return Error(Status::kErrorInvalidArgument, "Output index out of bounds");
    }
    return internal::model_detail::FetchSignatureOutputTensorByIndex(
               lite_rt_signature, static_cast<LiteRtParamIndex>(output_index))
        ->RankedTensorType();
  }

  /// @brief Returns the tensor type for the given output tensor name.
  Expected<RankedTensorType> GetOutputTensorType(size_t signature_index,
                                                 StringView output_name) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    LiteRtParamIndex num_outputs;
    internal::AssertOk(LiteRtGetNumSignatureOutputs, lite_rt_signature,
                       &num_outputs);
    for (int i = 0; i < num_outputs; ++i) {
      const char* name;
      internal::AssertOk(LiteRtGetSignatureOutputName, lite_rt_signature, i,
                         &name);
      if (StringView(name) == output_name) {
        return internal::model_detail::FetchSignatureOutputTensorByIndex(
                   lite_rt_signature, i)
            ->RankedTensorType();
      }
    }
    return Error(Status::kErrorNotFound,
                 "Output tensor not found: " + std::string(output_name));
  }

  /// @brief Returns the tensor type for the given output tensor name.
  Expected<RankedTensorType> GetOutputTensorType(StringView signature_key,
                                                 StringView output_name) const {
    LITERT_ASSIGN_OR_RETURN(auto index, GetSignatureIndex(signature_key));
    return GetOutputTensorType(index, output_name);
  }

  /// @brief Gets the output tensor type of the default signature for a given
  /// output name.
  Expected<RankedTensorType> GetOutputTensorType(StringView output_name) const {
    return GetOutputTensorType(/*signature_index=*/0, output_name);
  }

 protected:
  /// @param owned Indicates if the created `TensorBuffer` object should take
  /// ownership of the provided `tensor_buffer` handle.
  Model(LiteRtModel model, OwnHandle owned)
      : internal::BaseHandle<LiteRtModel>(model, LiteRtDestroyModel, owned) {}

  // This is only used for managing the lifetime of ad-hoc environment for
  // legacy cases.
  [[deprecated("Do not use this field.")]]
  static const Expected<Environment>& GetDefaultEnvironment() {
    static const Expected<Environment>* kDefaultEnvironment =
        new Expected<Environment>(Environment::Create({}));
    return *kDefaultEnvironment;
  }

 private:
  Expected<std::vector<StringView>> GetSignatureKeysImpl() const {
    size_t num_signatures = GetNumSignatures();
    std::vector<StringView> signature_keys;
    signature_keys.reserve(num_signatures);
    for (int i = 0; i < num_signatures; ++i) {
      LiteRtSignature lite_rt_signature;
      internal::AssertOk(LiteRtGetModelSignature, Get(), i, &lite_rt_signature);
      signature_keys.push_back(
          internal::model_detail::FetchSignatureKey(lite_rt_signature));
    }
    return signature_keys;
  }
  Expected<std::vector<StringView>> GetSignatureInputNamesImpl(
      size_t signature_index) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    return internal::model_detail::FetchSignatureInputNames(lite_rt_signature);
  }
  Expected<std::vector<StringView>> GetSignatureOutputNamesImpl(
      size_t signature_index) const {
    LiteRtSignature lite_rt_signature;
    internal::AssertOk(LiteRtGetModelSignature, Get(), signature_index,
                       &lite_rt_signature);
    return internal::model_detail::FetchSignatureOutputNames(lite_rt_signature);
  }
};

}  // namespace litert

#endif  // ODML_LITERT_LITERT_CC_LITERT_MODEL_H_
