// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "litert/cc/litert_model.h"

#include <cstddef>
#include <cstdint>
#include <string>

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
#include "litert/c/litert_common.h"
#include "litert/c/litert_layout.h"
#include "litert/c/litert_model.h"
#include "litert/c/litert_model_types.h"
#include "litert/cc/internal/litert_extended_model.h"
#include "litert/cc/internal/scoped_file.h"
#include "litert/cc/litert_element_type.h"
#include "litert/cc/litert_layout.h"
#include "litert/cc/litert_model_types.h"
#include "litert/cc/litert_ranked_tensor_type.h"
#include "litert/core/model/model.h"
#include "litert/test/common.h"
#include "litert/test/load_test_model.h"
#include "litert/test/matchers.h"
#include "tflite/converter/allocation.h"

// Tests for CC Wrapper classes around public C api.

namespace litert {

namespace {

constexpr int32_t kTensorDimensions[] = {1, 2, 3};

constexpr uint32_t kTensorStrides[] = {6, 3, 1};

constexpr LiteRtLayout kLayout = BuildLayout(kTensorDimensions);

constexpr LiteRtLayout kLayoutWithStrides =
    BuildLayout(kTensorDimensions, kTensorStrides);

constexpr LiteRtRankedTensorType kTensorType = {
    /*.element_type=*/kLiteRtElementTypeFloat32,
    /*.layout=*/kLayout,
};

//===----------------------------------------------------------------------===//
//                                CC Model                                    //
//===----------------------------------------------------------------------===//

TEST(CcModelTest, SimpleModel) {
  auto model = testing::LoadTestFileModel("one_mul.tflite");

  LiteRtParamIndex num_subgraphs;
  ASSERT_EQ(LiteRtGetNumModelSubgraphs(model.Get(), &num_subgraphs),
            kLiteRtStatusOk);
  EXPECT_EQ(num_subgraphs, 1);

  LiteRtParamIndex main_subgraph_index;
  ASSERT_EQ(LiteRtGetMainModelSubgraphIndex(model.Get(), &main_subgraph_index),
            kLiteRtStatusOk);
  EXPECT_EQ(main_subgraph_index, 0);

  LiteRtSubgraph litert_subgraph_0;
  ASSERT_EQ(LiteRtGetModelSubgraph(model.Get(), /*subgraph_index=*/0,
                                   &litert_subgraph_0),
            kLiteRtStatusOk);

  auto subgraph_0 = model.Subgraph(0);
  ASSERT_TRUE(subgraph_0);
  EXPECT_EQ(subgraph_0->Get(), litert_subgraph_0);

  auto main_subgraph = model.MainSubgraph();
  EXPECT_EQ(main_subgraph->Get(), subgraph_0->Get());
}

TEST(CcModelTest, SimpleModelSignature) {
  auto model = testing::LoadTestFileModel("reverse_signature_model.tflite");

  EXPECT_EQ(model.GetNumSignatures(), 1);
  auto signature_keys = model.GetSignatureKeys();
  ASSERT_TRUE(signature_keys);
  EXPECT_EQ(signature_keys->size(), 1);
  EXPECT_EQ(signature_keys->at(0), "serving_default");

  auto input_names = model.GetSignatureInputNames();
  ASSERT_TRUE(input_names);
  EXPECT_EQ(input_names->size(), 2);
  EXPECT_EQ(input_names->at(0), "y");
  EXPECT_EQ(input_names->at(1), "x");

  // Signature names may differ from the underlying graph tensor names.
  LITERT_ASSERT_OK(model.GetInputTensorType(0, input_names->at(0)));
  LITERT_ASSERT_OK(model.GetInputTensorType(0, input_names->at(1)));

  auto output_names = model.GetSignatureOutputNames();
  ASSERT_TRUE(output_names);
  EXPECT_EQ(output_names->size(), 2);
  EXPECT_EQ(output_names->at(0), "sum");
  EXPECT_EQ(output_names->at(1), "prod");
  LITERT_ASSERT_OK(model.GetOutputTensorType(0, output_names->at(0)));
  LITERT_ASSERT_OK(model.GetOutputTensorType(0, output_names->at(1)));
}

#if !defined(LITERT_WINDOWS_OS)
TEST(CcModelTest, CreateFromFd) {
  if (!tflite::MMAPAllocation::IsSupported()) {
    GTEST_SKIP() << "MMAPAllocation is not supported";
  }

  LITERT_ASSERT_OK_AND_ASSIGN(
      auto model_file,
      ScopedFile::Open(testing::GetTestFilePath("one_mul.tflite")));
  LITERT_ASSERT_OK_AND_ASSIGN(size_t model_size, model_file.GetSize());

  auto model = Model::CreateFromFd(model_file.file(), 0, model_size);
  ASSERT_TRUE(model);
  EXPECT_EQ(model->GetNumSignatures(), 1);

  auto signature = model->FindSignature(Model::DefaultSignatureKey());
  ASSERT_TRUE(signature);
  EXPECT_THAT(signature->InputNames(),
              ::testing::ElementsAreArray({"arg0", "arg1"}));
  EXPECT_THAT(signature->OutputNames(),
              ::testing::ElementsAreArray({"tfl.mul"}));
}
#endif  // !defined(LITERT_WINDOWS_OS)

#if !defined(LITERT_DYNAMIC_RUNTIME)
// copybara:uncomment_begin(google_only)
// TEST(CcModelTest, CreateFromMemoryAllocation) {
//   auto runtime = testing::MakeRuntimeFromTestFile("one_mul.tflite");
//   ASSERT_TRUE(runtime);
// 
//   const auto model_buffer = (*runtime)->Flatbuffer().Buf();
//   auto allocation = std::make_unique<tflite::MemoryAllocation>(
//       model_buffer.Data(), model_buffer.Size(), tflite::DefaultErrorReporter());
// 
//   auto model = Model::CreateFromAllocation(std::move(allocation));
//   ASSERT_TRUE(model);
//   EXPECT_EQ(model->GetNumSignatures(), 1);
// 
//   auto signature = model->FindSignature(Model::DefaultSignatureKey());
//   ASSERT_TRUE(signature);
//   EXPECT_THAT(signature->InputNames(),
//               ::testing::ElementsAreArray({"arg0", "arg1"}));
//   EXPECT_THAT(signature->OutputNames(),
//               ::testing::ElementsAreArray({"tfl.mul"}));
// }
// 
// TEST(CcModelTest, CreateFromNullAllocationFails) {
//   auto model =
//       Model::CreateFromAllocation(std::unique_ptr<tflite::Allocation>());
//   ASSERT_FALSE(model);
//   EXPECT_EQ(model.Error().Status(), kLiteRtStatusErrorFileIO);
// }
// copybara:uncomment_end
#endif  // !defined(LITERT_DYNAMIC_RUNTIME)

//===----------------------------------------------------------------------===//
//                                CC Signature                                //
//===----------------------------------------------------------------------===//

TEST(CcSignatureTest, Basic) {
  auto model = testing::LoadTestFileModel("one_mul.tflite");

  auto signatures = model.GetSignatures();
  ASSERT_TRUE(signatures);
  ASSERT_EQ(signatures->size(), 1);
  auto& signature = signatures->at(0);
  EXPECT_THAT(signature.Key(), Model::DefaultSignatureKey());
  auto input_names = signature.InputNames();
  EXPECT_THAT(input_names[0], "arg0");
  EXPECT_THAT(input_names[1], "arg1");
  LITERT_ASSERT_OK_AND_ASSIGN(const auto& input0, signature.InputTensor(0));
  EXPECT_THAT(input0.Name(), "arg0");
  LITERT_ASSERT_OK_AND_ASSIGN(const auto& input1, signature.InputTensor(1));
  EXPECT_THAT(input1.Name(), "arg1");
  auto output_names = signature.OutputNames();
  EXPECT_THAT(output_names[0], "tfl.mul");
  LITERT_ASSERT_OK_AND_ASSIGN(const auto& output0, signature.OutputTensor(0));
  EXPECT_THAT(output0.Name(), "tfl.mul");
}

TEST(CcSignatureTest, Lookup) {
  auto model = testing::LoadTestFileModel("one_mul.tflite");

  {
    auto signature = model.FindSignature("nonexistent_find_sig");
    ASSERT_FALSE(signature);
    EXPECT_THAT(
        signature.Error().Message(),
        ::testing::HasSubstr("Signature not found: nonexistent_find_sig"));

    auto sig_index = model.GetSignatureIndex("nonexistent_index_sig");
    ASSERT_FALSE(sig_index);
    EXPECT_THAT(
        sig_index.Error().Message(),
        ::testing::HasSubstr("Signature not found: nonexistent_index_sig"));

    auto input_names = model.GetSignatureInputNames("nonexistent_input_sig");
    ASSERT_FALSE(input_names);
    EXPECT_THAT(
        input_names.Error().Message(),
        ::testing::HasSubstr("Signature not found: nonexistent_input_sig"));

    auto output_names = model.GetSignatureOutputNames("nonexistent_output_sig");
    ASSERT_FALSE(output_names);
    EXPECT_THAT(
        output_names.Error().Message(),
        ::testing::HasSubstr("Signature not found: nonexistent_output_sig"));

    auto input_type = model.GetInputTensorType(0, "nonexistent_input_tensor");
    ASSERT_FALSE(input_type);
    EXPECT_THAT(input_type.Error().Message(),
                ::testing::HasSubstr(
                    "Input tensor not found: nonexistent_input_tensor"));

    auto output_type =
        model.GetOutputTensorType(0, "nonexistent_output_tensor");
    ASSERT_FALSE(output_type);
    EXPECT_THAT(output_type.Error().Message(),
                ::testing::HasSubstr(
                    "Output tensor not found: nonexistent_output_tensor"));
  }
  auto signature = model.FindSignature(Model::DefaultSignatureKey());
  ASSERT_TRUE(signature);
  EXPECT_THAT(signature->Key(), Model::DefaultSignatureKey());
  auto input_names = signature->InputNames();
  EXPECT_THAT(input_names[0], "arg0");
  EXPECT_THAT(input_names[1], "arg1");
  auto output_names = signature->OutputNames();
  EXPECT_THAT(output_names[0], "tfl.mul");
}

//===----------------------------------------------------------------------===//
//                                CC Layout                                   //
//===----------------------------------------------------------------------===//

TEST(CcLayoutTest, NoStrides) {
  Layout layout(kLayout);

  ASSERT_EQ(layout.Rank(), kLayout.rank);
  for (auto i = 0; i < layout.Rank(); ++i) {
    ASSERT_EQ(layout.Dimensions()[i], kLayout.dimensions[i]);
  }
  ASSERT_FALSE(layout.HasStrides());
}

TEST(CcLayoutTest, WithStrides) {
  Layout layout(kLayoutWithStrides);

  ASSERT_EQ(layout.Rank(), kLayoutWithStrides.rank);
  for (auto i = 0; i < layout.Rank(); ++i) {
    ASSERT_EQ(layout.Dimensions()[i], kLayoutWithStrides.dimensions[i]);
  }
  ASSERT_TRUE(layout.HasStrides());
  for (auto i = 0; i < layout.Rank(); ++i) {
    ASSERT_EQ(layout.Strides()[i], kLayoutWithStrides.strides[i]);
  }
}

TEST(CcLayoutTest, Equal) {
  Layout layout1(Dimensions({2, 2}));
  Layout layout2(Dimensions({2, 2}));
  ASSERT_TRUE(layout1 == layout2);
}

TEST(CcLayoutTest, NotEqual) {
  Layout layout1(Dimensions({2, 2}));
  Layout layout2(Dimensions({2, 2}), litert::Strides({6, 3, 1}));
  ASSERT_FALSE(layout1 == layout2);
}

TEST(CcLayoutTest, NumElements) {
  Layout layout(Dimensions({2, 2, 3}));
  auto num_elements = layout.NumElements();
  ASSERT_TRUE(num_elements);
  EXPECT_EQ(*num_elements, 12);
}

//===----------------------------------------------------------------------===//
//                           CC RankedTensorType                              //
//===----------------------------------------------------------------------===//

TEST(CcRankedTensorTypeTest, Accessors) {
  Layout layout(kLayout);
  RankedTensorType tensor_type(kTensorType);
  ASSERT_EQ(tensor_type.ElementType(),
            static_cast<ElementType>(kTensorType.element_type));
  ASSERT_TRUE(tensor_type.Layout() == layout);
}

TEST(CcTensorTest, Name) {
  constexpr absl::string_view kName = "foo";
  LiteRtTensorT tensor;
  tensor.SetName(std::string(kName));

  Tensor cc_tensor(&tensor);
  EXPECT_EQ(cc_tensor.Name(), kName);
}

TEST(CcTensorTest, Index) {
  constexpr std::uint32_t kIndex = 1;
  LiteRtTensorT tensor;
  tensor.SetTensorIndex(kIndex);

  Tensor cc_tensor(&tensor);
  EXPECT_EQ(cc_tensor.TensorIndex(), kIndex);
}

//===----------------------------------------------------------------------===//
//                               CC ElementType                               //
//===----------------------------------------------------------------------===//

TEST(CcElementTypeTest, GetByteWidth) {
  const auto width = GetByteWidth<ElementType::Bool>().NumBytes();
  EXPECT_EQ(width, 1);
}

TEST(CcElementTypeTest, GetElementType) {
  ElementType ty = GetElementType<float>();
  EXPECT_EQ(ty, ElementType::Float32);
}

//===----------------------------------------------------------------------===//
//                               CC SimpleTensor //
//===----------------------------------------------------------------------===//

TEST(CcSimpleTensorTest, QuantizationNone) {
  LiteRtTensorT litert_tensor;
  litert_tensor.Qparams().first = kLiteRtQuantizationNone;

  SimpleTensor tensor(/*index=*/0, /*name=*/"foo",
                      /*type_id=*/kLiteRtUnrankedTensorType,
                      /*type=*/LiteRtUnrankedTensorType{},
                      /*quantization_type_id=*/QuantizationTypeId::None,
                      /*per_tensor_quantization=*/{},
                      /*per_channel_quantization=*/{},
                      /*block_wise_quantization=*/{});
  QuantizationTypeId quantization_type_id = tensor.QTypeId();
  EXPECT_EQ(quantization_type_id, QuantizationTypeId::None);
}

TEST(CcSimpleTensorTest, QuantizationPerTensor) {
  constexpr auto kScale = 1.0;
  constexpr auto kZeroPoint = 1;

  LiteRtTensorT litert_tensor;
  litert_tensor.SetQarams(MakePerTensorQuantization(kScale, kZeroPoint));

  SimpleTensor tensor(/*index=*/0, /*name=*/"foo",
                      /*type_id=*/kLiteRtRankedTensorType,
                      /*type=*/RankedTensorType(kTensorType),
                      /*quantization_type_id=*/QuantizationTypeId::PerTensor,
                      /*per_tensor_quantization=*/{kScale, kZeroPoint},
                      /*per_channel_quantization=*/{},
                      /*block_wise_quantization=*/{});
  ASSERT_EQ(tensor.QTypeId(), QuantizationTypeId::PerTensor);
  ASSERT_TRUE(tensor.HasQuantization());

  auto per_tensor_quantization = tensor.PerTensorQuantization();
  EXPECT_EQ(per_tensor_quantization.scale, kScale);
  EXPECT_EQ(per_tensor_quantization.zero_point, kZeroPoint);
}

TEST(CcSimpleTensorTest, QuantizationPerChannel) {
  constexpr auto kNumChannels = 2;
  constexpr auto kQuantizedDimension = 0;
  constexpr float kScales[kNumChannels] = {1.0, 2.0};
  constexpr int64_t kZeroPoints[kNumChannels] = {0, 0};

  LiteRtTensorT litert_tensor;
  auto per_channel = MakePerChannelQuantization(
      kScales, kZeroPoints, kQuantizedDimension, litert_tensor);
  litert_tensor.SetQarams(per_channel);

  SimpleTensor tensor(
      /*index=*/0, /*name=*/"foo",
      /*type_id=*/kLiteRtRankedTensorType,
      /*type=*/RankedTensorType(kTensorType),
      /*quantization_type_id=*/QuantizationTypeId::PerChannel,
      /*per_tensor_quantization=*/{},
      /*per_channel_quantization=*/
      {kQuantizedDimension, kNumChannels, const_cast<float*>(kScales),
       const_cast<int64_t*>(kZeroPoints)},
      /*block_wise_quantization=*/{});
  ASSERT_EQ(tensor.QTypeId(), QuantizationTypeId::PerChannel);
  ASSERT_TRUE(tensor.HasQuantization());

  auto per_channel_quantization = tensor.PerChannelQuantization();
  EXPECT_THAT(
      absl::MakeConstSpan(per_channel_quantization.scales, kNumChannels),
      ::testing::ElementsAreArray(kScales));
  EXPECT_THAT(
      absl::MakeConstSpan(per_channel_quantization.zero_points, kNumChannels),
      ::testing::ElementsAreArray(kZeroPoints));
  EXPECT_EQ(per_channel_quantization.num_channels, kNumChannels);
  EXPECT_EQ(per_channel_quantization.quantized_dimension, kQuantizedDimension);
}

TEST(CcSimpleTensorTest, QuantizationBlockWise) {
  LiteRtTensorT scales_tensor;
  LiteRtTensorT zero_points_tensor;
  constexpr int32_t kBlockSize = 32;

  SimpleTensor tensor(
      /*index=*/0, /*name=*/"foo",
      /*type_id=*/kLiteRtRankedTensorType,
      /*type=*/RankedTensorType(kTensorType),
      /*quantization_type_id=*/QuantizationTypeId::BlockWise,
      /*per_tensor_quantization=*/{},
      /*per_channel_quantization=*/{},
      /*block_wise_quantization=*/
      {&scales_tensor, &zero_points_tensor, kBlockSize});
  ASSERT_EQ(tensor.QTypeId(), QuantizationTypeId::BlockWise);
  ASSERT_TRUE(tensor.HasQuantization());

  auto block_wise_quantization = tensor.BlockWiseQuantization();
  EXPECT_EQ(block_wise_quantization.scales, &scales_tensor);
  EXPECT_EQ(block_wise_quantization.zero_points, &zero_points_tensor);
  EXPECT_EQ(block_wise_quantization.block_size, kBlockSize);
}

}  // namespace
}  // namespace litert
