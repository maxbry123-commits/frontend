// Copyright 2025 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_TFLITE_ERROR_STATUS_BUILDER_H_
#define THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_TFLITE_ERROR_STATUS_BUILDER_H_

#include "litert/c/litert_common.h"
#include "litert/cc/litert_macros.h"
#include "tflite/c/c_api_types.h"

/// @file
/// @brief Provides a utility for converting LiteRT error statuses to
///        TensorFlow Lite statuses.

namespace litert {

/// @brief Converts a LiteRT `ErrorStatusBuilder` to a `TfLiteStatus`.
///
/// This function is used to propagate LiteRT errors through the TFLite C API.
inline TfLiteStatus AsTfLiteStatus(const ErrorStatusBuilder& e) {
  [[maybe_unused]] LiteRtStatus s = e;
  return kTfLiteError;
}

}  // namespace litert

#endif  // THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_TFLITE_ERROR_STATUS_BUILDER_H_
