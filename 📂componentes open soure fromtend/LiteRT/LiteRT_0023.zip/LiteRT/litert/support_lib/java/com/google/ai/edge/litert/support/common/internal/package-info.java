/* Copyright 2021 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

/**
 * @hide This package is for classes that are implementation details of
 *     com.google.ai.edge.litert.support AND are used from different packages within
 *     com.google.ai.edge.litert.support (and which cannot therefore simply be declared as
 *     package-private). Classes in this package should only be used from within other classes in
 *     com.google.ai.edge.litert.support.
 */
package com.google.ai.edge.litert.support.common.internal;
