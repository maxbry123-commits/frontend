/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
package com.google.ai.edge.litert.support.model;

import static com.google.common.truth.Truth.assertThat;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.tensorflow.lite.InterpreterApi.Options.TfLiteRuntime;

/**
 * Instrumented unit test for {@link GpuDelegateProxy}.
 *
 * <p>In this test, "tensorflow-lite-gpu" is provided.
 */
@RunWith(AndroidJUnit4.class)
public final class GpuDelegateProxyInstrumentedTest {

  @Test
  public void createGpuDelegateProxyShouldSucceed() {
    try (GpuDelegateProxy proxy =
        GpuDelegateProxy.maybeNewInstance(TfLiteRuntime.PREFER_SYSTEM_OVER_APPLICATION)) {
      assertThat(proxy).isNotNull();
      assertThat(proxy.getNativeHandle()).isNotEqualTo(0);
    }
  }

  @Test
  public void createApplicationGpuDelegateProxyShouldSucceed() {
    try (GpuDelegateProxy proxy =
        GpuDelegateProxy.maybeNewInstance(TfLiteRuntime.FROM_APPLICATION_ONLY)) {
      assertThat(proxy).isNotNull();
      assertThat(proxy.getNativeHandle()).isNotEqualTo(0);
    }
  }

  @Test
  public void createSystemGpuDelegateProxyShouldReturnNull() {
    try (GpuDelegateProxy proxy =
        GpuDelegateProxy.maybeNewInstance(TfLiteRuntime.FROM_SYSTEM_ONLY)) {
      assertThat(proxy).isNull();
    }
  }
}
