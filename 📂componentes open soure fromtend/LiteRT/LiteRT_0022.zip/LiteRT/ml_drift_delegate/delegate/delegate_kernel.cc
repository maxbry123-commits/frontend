// Copyright 2025 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "ml_drift_delegate/delegate/delegate_kernel.h"

#if defined(_WIN32)
#include <io.h>
#else
#include <unistd.h>
#endif

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "absl/container/flat_hash_map.h"  // from @com_google_absl
#include "absl/container/flat_hash_set.h"  // from @com_google_absl
#include "absl/log/absl_log.h"  // from @com_google_absl
#include "absl/status/status.h"  // from @com_google_absl
#include "absl/status/status_macros.h"  // from @com_google_absl
#include "absl/status/statusor.h"  // from @com_google_absl
#include "absl/strings/str_cat.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "absl/synchronization/blocking_counter.h"  // from @com_google_absl
#include "absl/types/span.h"  // from @com_google_absl
// copybara:uncomment #include "mediapipe/framework/profiler/perfetto_profiling.h"  // from @mediapipe
#include "ml_drift/common/gpu_info.h"  // from @ml_drift
#include "ml_drift/common/gpu_model.h"  // from @ml_drift
#include "ml_drift/common/gpu_model_builder.h"  // from @ml_drift
#include "ml_drift/common/gpu_model_util.h"  // from @ml_drift
#include "ml_drift/common/ir_model.h"  // from @ml_drift
#include "ml_drift/common/ir_model_util.h"  // from @ml_drift
#include "ml_drift/common/model.h"  // from @ml_drift
#include "ml_drift/common/model_hints.h"  // from @ml_drift
#include "ml_drift/common/precision.h"  // from @ml_drift
#include "ml_drift/common/shape.h"  // from @ml_drift
#include "ml_drift/common/task/gpu_tensor.h"  // from @ml_drift
#include "ml_drift/common/task/profiling_info.h"  // from @ml_drift
#include "ml_drift/common/task/tensor_desc.h"  // from @ml_drift
#include "ml_drift/common/tensor.h"  // from @ml_drift
#include "ml_drift_delegate/delegate/delegate_utils.h"
#include "ml_drift_delegate/delegate/precision.h"
// clang-format off
#include "ml_drift_delegate/delegate/quantization_util.h"
#include "ml_drift_delegate/delegate/serialization_program_cache/serialization_program_cache.h"
#include "ml_drift_delegate/delegate/serialization_weight_cache/mmap_handle.h"
#include "ml_drift_delegate/delegate/serialization_weight_cache/serialization_weight_cache.h"
// clang-format on
#include "ml_drift_delegate/delegate/composite/custom_parsers.h"
#include "ml_drift_delegate/delegate/composite/custom_transformations.h"
#include "ml_drift_delegate/delegate/composite/ir/custom_parsers.h"
#include "ml_drift_delegate/delegate/composite/ir/litert_op_selector.h"
#include "ml_drift_delegate/delegate/composite/litert_op_selector.h"
#include "ml_drift_delegate/delegate/gpu_backend.h"
#include "ml_drift_delegate/delegate/incrementable_blocking_counter.h"
#include "ml_drift_delegate/delegate/shared_memory_manager/gf32_graph_adapter.h"
#include "ml_drift_delegate/delegate/shared_memory_manager/graph_adapter.h"
#include "ml_drift_delegate/delegate/shared_memory_manager/ir_graph_adapter.h"
#include "ml_drift_delegate/delegate/shared_memory_manager/shared_memory_manager.h"
#include "ml_drift_delegate/delegate/tflite_profile.h"
#include "ml_drift_delegate/delegate/unowned_tensor_desc.h"
#include "ml_drift_delegate/tflite/ir_model_builder.h"
#include "ml_drift_delegate/tflite/ir_model_builder_helper.h"
#include "ml_drift_delegate/tflite/model_builder.h"
#include "ml_drift_delegate/tflite/object_reader.h"
#include "ml_drift_delegate/tflite/shared_const_tensor_map.h"
#include "weight_loader/external_weight_loader_litert.h"
#include "tflite/c/c_api_types.h"
#include "tflite/core/c/common.h"
#include "tflite/core/subgraph.h"
#include "tflite/delegates/serialization.h"
#include "tflite/kernels/kernel_util.h"
#include "tflite/profiling/memory_latency_logger.h"  // IWYU pragma: keep

namespace litert::ml_drift {
namespace {

// When Perfetto tracing is enabled, it may be desirable to also force the
// commands to complete (CPU sync) so the time taken by each command on the GPU
// is more accurately recorded. This is not ideal for general performance, but
// it is useful for tracing.
#ifdef LITERT_GPU_FORCE_COMPLETION
constexpr bool kForceCompletion = true;
#else
constexpr bool kForceCompletion = false;
#endif

}  // namespace

DelegateKernel::~DelegateKernel() {
  if (delegate_data_ && delegate_data_->weights_conversion_counter) {
    delegate_data_->weights_conversion_counter->Wait();
  }
}

absl::Status DelegateKernel::Dispatch(TfLiteContext* context) {
  // copybara:uncomment MEDIAPIPE_PERFETTO_TRACE_EVENT("Dispatch");

  if (delegate_data_->weights_conversion_counter) {
    delegate_data_->weights_conversion_counter->Wait();
    delegate_data_->weights_conversion_counter.reset();
  }

  if (::ml_drift::IsTfLiteProfilerActive(context)) {
    ::ml_drift::ProfilingInfo profiling_info;
    ABSL_RETURN_IF_ERROR(ctx_->Profile(profiling_info));
    AddTfLiteProfilerEvents(context, &profiling_info);
  }

  ABSL_RETURN_IF_ERROR(ctx_->Dispatch());
  if (kForceCompletion) {
    return backend_->WaitForCompletion();
  }

  return absl::OkStatus();
}

// Calls the delegate to get the list of tensors that need to be temporarily
// storage. It's usually needed for quantized tensors. And it's eventually
// stored in TfLiteNode::temporaries.
absl::Status DelegateKernel::GetRequiredTemporaries(
    TfLiteContext* context, TfLiteNode* node,
    TfLiteIntArray** temporaries_array_ptr) {
  if (!HasQuantizedTensors()) return absl::OkStatus();

  std::vector<int> temporary_tensors;
  temporary_tensors.reserve(input_indices_.size() + output_indices_.size());
  for (auto index : input_indices_) {
    if (quant_conversion_map_.find(index) != quant_conversion_map_.end()) {
      temporary_tensors.push_back(index);
    }
  }
  for (auto index : output_indices_) {
    if (quant_conversion_map_.find(index) != quant_conversion_map_.end()) {
      temporary_tensors.push_back(index);
    }
  }
#if defined(_WIN32)
  context->TfLiteIntArrayFree(*temporaries_array_ptr);
  *temporaries_array_ptr =
      context->TfLiteIntArrayCreate(temporary_tensors.size());
#else   // defined(_WIN32)
  TfLiteIntArrayFree(*temporaries_array_ptr);
  *temporaries_array_ptr = TfLiteIntArrayCreate(temporary_tensors.size());
#endif  // defined(_WIN32)
  for (size_t i = 0; i < temporary_tensors.size(); ++i) {
    (*temporaries_array_ptr)->data[i] = temporary_tensors[i];
  }
  return absl::OkStatus();
}

// Dequantizes the input tensors using `quant_conversion_map_`.
absl::Status DelegateKernel::DequantizeInputs(TfLiteContext* context) {
  return ::ml_drift::delegate::DequantizeInputs(context, input_indices_,
                                                quant_conversion_map_);
}

// Quantizes the output tensors using `quant_conversion_map_`.
absl::Status DelegateKernel::QuantizeOutputs(TfLiteContext* context) {
  return ::ml_drift::delegate::QuantizeOutputs(context, output_indices_,
                                               quant_conversion_map_);
}

// Returns the values of the graph that actually have a producer or
// consumers, to avoid creating unnecessary and unused tensors. For example,
// in the case of having a composite op where some inputs are needed for
// decomposition, but not for gpu, this can happen.
std::vector<::ml_drift::Value*> GetValuesUsed(
    const ::ml_drift::GraphFloat32& graph,
    const std::vector<::ml_drift::Value*>& values) {
  std::vector<::ml_drift::Value*> used_values;
  used_values.reserve(values.size());
  for (const auto& value : values) {
    auto producer = graph.FindProducer(value->id);
    auto consumers = graph.FindConsumers(value->id);
    if (producer != nullptr || !consumers.empty()) {
      used_values.push_back(value);
    }
  }
  return used_values;
}

absl::Status DelegateKernel::Initialize(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params) {
  delegate_data_ =
      reinterpret_cast<MlDriftDelegateData*>(delegate_params->delegate->data_);
  if (!delegate_data_) {
    return absl::InternalError(
        "Could not read MlDriftDelegateData from delegate data.");
  }
  if (delegate_data_->shared_backend) {
    backend_ = delegate_data_->shared_backend.get();
  } else {
    backend_ = delegate_data_->backend.get();
  }
  is_opencl_backend_ = backend_->GetBackendName() == "OpenCL";

  // Select the initialization pipeline at runtime: the IrModel pipeline when
  // options->use_ir_model is set, otherwise the legacy GraphFloat32 pipeline.
  // Both pipelines are always compiled and linked.
  if (delegate_data_->options->use_ir_model) {
    return InitializeIrModel(context, delegate_params);
  }
  return InitializeGraphFloat32(context, delegate_params);
}

absl::Status DelegateKernel::InitializeGraphFloat32(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params) {
  SharedConstTensorsMap shared_tensors;
  SharedConstTensorsMap* shared_tensors_ptr = nullptr;
  const TensorIndexToBufferIdMap* tensor_to_buffer_id_map = nullptr;
  const TensorIndexToExternalBufferIdMap* tensor_to_external_buffer_id_map =
      nullptr;
  TensorIndexToExternalBufferIdMap canonical_external_buffer_id_map;
  if (delegate_data_->options->enable_constant_tensors_sharing) {
    shared_tensors_ptr = &shared_tensors;
    tensor_to_buffer_id_map =
        &(reinterpret_cast<const tflite::Subgraph*>(context->impl_)
              ->GetTensorBufferIdentifiers());
    const auto& external_buffer_id_map =
        reinterpret_cast<const tflite::Subgraph*>(context->impl_)
            ->GetExternalTensorBufferIdentifiers();
    tensor_to_external_buffer_id_map = &external_buffer_id_map;
    if (delegate_data_->weight_loader != nullptr &&
        !external_buffer_id_map.empty()) {
      canonical_external_buffer_id_map.reserve(external_buffer_id_map.size());
      for (const auto& [tensor_id, external_buffer_id] :
           external_buffer_id_map) {
        canonical_external_buffer_id_map.emplace(
            tensor_id,
            delegate_data_->weight_loader->GetCanonicalExternalBufferId(
                static_cast<uint32_t>(external_buffer_id)));
      }
      tensor_to_external_buffer_id_map = &canonical_external_buffer_id_map;
    }
  }

  litert::ml_drift::ModelBuilderOptions options;
  options.enable_infinite_float_capping =
      delegate_data_->options->enable_infinite_float_capping;
  options.enable_reduced_precision = delegate_data_->calculation_precision !=
                                     ::ml_drift::CalculationsPrecision::F32;
  // Build GraphFloat32.
  ::ml_drift::GraphFloat32 graph;
  CustomOperationParserFactory custom_parser_factory;
  ABSL_RETURN_IF_ERROR(BuildFinalModel(
      context, delegate_params, options, &graph, &quant_conversion_map_,
      shared_tensors_ptr, tensor_to_buffer_id_map,
      tensor_to_external_buffer_id_map, &custom_parser_factory));

  ABSL_RETURN_IF_ERROR(::litert::ml_drift::ApplyCustomTransformations(
      &graph, *delegate_data_->options));

  const TfLiteIntArray* input_tensors = delegate_params->input_tensors;
  const std::vector<::ml_drift::Value*> inputs =
      GetValuesUsed(graph, graph.inputs());
  input_indices_.reserve(input_tensors->size);
  // Canonical BHWC shape/dtype for each non-constant input, taken from the
  // graph's inferred Value shapes and passed to the GF32 descriptor builder.
  std::vector<::ml_drift::TensorRef<::ml_drift::BHWC>> input_tensor_refs;
  input_tensor_refs.reserve(inputs.size());
  for (const ::ml_drift::Value* input : inputs) {
    const TfLiteTensor* tensor = context->tensors + input->tensor.ref;
    if (tflite::IsConstantTensor(tensor)) continue;
    input_ids_.push_back(input->id);
    input_indices_.push_back(input->tensor.ref);
    input_tensor_refs.push_back(input->tensor);
  }
  const TfLiteIntArray* output_tensors = delegate_params->output_tensors;
  const std::vector<::ml_drift::Value*> outputs =
      GetValuesUsed(graph, graph.outputs());
  const int output_size =
      std::min(static_cast<int>(graph.outputs().size()), output_tensors->size);
  output_indices_.reserve(output_size);
  output_ids_.reserve(output_size);
  std::vector<::ml_drift::TensorRef<::ml_drift::BHWC>> output_tensor_refs;
  output_tensor_refs.reserve(outputs.size());
  for (const ::ml_drift::Value* output : outputs) {
    output_ids_.push_back(output->id);
    output_indices_.push_back(output->tensor.ref);
    output_tensor_refs.push_back(output->tensor);
  }

  // Create inference context.
  ::ml_drift::CreateGpuModelInfo create_info;
  create_info.precision = delegate_data_->calculation_precision;
  create_info.storage_type = GetStorageType();
#ifdef __APPLE__
  create_info.hints.use_metal_argument_buffers =
      delegate_data_->options->use_metal_argument_buffers;
#endif  // __APPLE__

  create_info.hints.Add(::ml_drift::ModelHints::kAllowSpecialKernels);
  if (delegate_data_->options->prefer_texture_weights) {
    create_info.hints.Add(::ml_drift::ModelHints::kPreferTextureWeights);
  }
  if (delegate_data_->options->enable_fast_tuning) {
    create_info.hints.Add(::ml_drift::ModelHints::kFastTuning);
  }
  if (!delegate_data_->options->allow_src_quantized_fc_conv_ops) {
    create_info.hints.Add(::ml_drift::ModelHints::kDisallow8bitConvs);
  }
  if (delegate_data_->options->enable_constant_tensors_sharing) {
    ABSL_RETURN_IF_ERROR(InitializeExternalSharedConstantTensors(
        context, delegate_params, shared_tensors,
        std::make_unique<::ml_drift::GraphFloat32Adapter>(graph), create_info));
  }

  external_tensor_ids_.reserve(input_indices_.size() + output_indices_.size());
  ABSL_RETURN_IF_ERROR(UpdateCreateInfoWithExternalTensors(
      context, create_info, input_tensor_refs, output_tensor_refs));
  if (!external_tensor_ids_.empty()) {
    ABSL_LOG(INFO)
        << "Total " << external_tensor_ids_.size()
        << " external tensors are used for delegate inputs and outputs";
  }
  ABSL_RETURN_IF_ERROR(
      InitInferenceContext(context, delegate_params, create_info, &graph));

  if (delegate_data_->options->enable_op_profiling_detailed_report) {
    std::cout << create_info.external_mutable_tensors.size() << std::endl;
    ::ml_drift::ProfilingInfo profiling_info;
    ABSL_RETURN_IF_ERROR(ctx_->Profile(profiling_info));
    ::ml_drift::ProfilingInfo::DetailedReportOptions options;
    options.add_shapes_info = false;
    std::cout << profiling_info.GetDetailedReport(options) << std::endl;
    ABSL_ASSIGN_OR_RETURN(
        auto runtime_mem_bytes,
        ctx_->GetSizeOfMemoryAllocatedForIntermediateTensors());
    std::cout << "Memory for intermediate tensors - "
              << runtime_mem_bytes / 1024.0 / 1024.0 << " MB" << std::endl;
    ABSL_ASSIGN_OR_RETURN(auto const_mem_bytes,
                          ctx_->GetSizeOfMemoryAllocatedForConstantTensors());
    std::cout << "Memory for constant tensors - "
              << const_mem_bytes / 1024.0 / 1024.0 << " MB" << std::endl;
    std::cout << "Total tensors memory(const + intermediate) - "
              << (const_mem_bytes + runtime_mem_bytes) / 1024.0 / 1024.0
              << " MB" << std::endl;
    ABSL_ASSIGN_OR_RETURN(auto external_bytes,
                          ctx_->GetSizeOfMemoryAllocatedForExternalTensors());
    std::cout << "Memory for external tensors - "
              << external_bytes / 1024.0 / 1024.0 << " MB" << std::endl;
  }

  ctx_->ReportMemoryBenchmarkIfEnabled(create_info).IgnoreError();
  return absl::OkStatus();
}

absl::Status DelegateKernel::InitializeExternalSharedConstantTensors(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const SharedConstTensorsMap& shared_tensors,
    std::unique_ptr<::ml_drift::GraphAdapter> graph_adapter,
    ::ml_drift::CreateGpuModelInfo& create_info) {
#ifdef ML_DRIFT_MEM_STATS
  tflite::profiling::memory::MemoryLatencyLogger logger;
  logger.Start();
#endif

  ::ml_drift::SerializationWeightCache* shared_memory_serialization_cache;
#ifdef __EMSCRIPTEN__
  bool prepare_weights_in_batches = false;
#else
  bool prepare_weights_in_batches = true;
#endif
  ABSL_ASSIGN_OR_RETURN(
      shared_memory_serialization_cache,
      TryInitializingExternalTensorsSerialization(context, delegate_params,
                                                  prepare_weights_in_batches));

  ABSL_ASSIGN_OR_RETURN(
      auto shared_mem_manager,
      backend_->CreateSharedMemoryManager(create_info, std::move(graph_adapter),
                                          context, *delegate_data_,
                                          shared_memory_serialization_cache));

  bool convert_weights_on_gpu =
      delegate_data_->options->convert_weights_on_gpu &&
      delegate_data_->options->enable_constant_tensors_sharing;
  if (convert_weights_on_gpu) {
    ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
    if (!::ml_drift::WeightsManager::IsGpuWeightsPreparationSupported(
            gpu_info)) {
      convert_weights_on_gpu = false;
    } else {
      ABSL_ASSIGN_OR_RETURN(auto weights_manager,
                            backend_->CreateWeightsManager());
      shared_mem_manager->SetWeightsManager(weights_manager);
    }
  }

  // Iterate over shared tensors in sorted order to ensure that the order of
  // the external tensor allocations are consistent so their storage types
  // are consistent across runs. Allocate the largest tensors first to reduce
  // the peak memory usage.
  std::vector<::ml_drift::ValueId> shared_tensor_ids_ordered_by_size;
  for (const auto& [shared_tensor_id, _] : shared_tensors) {
    shared_tensor_ids_ordered_by_size.push_back(shared_tensor_id);
  }
  auto get_tensor = [&](::ml_drift::ValueId shared_tensor_id) -> TfLiteTensor& {
    return context->tensors[shared_tensors.find(shared_tensor_id)
                                ->second.tflite_tensor_id];
  };
  std::sort(shared_tensor_ids_ordered_by_size.begin(),
            shared_tensor_ids_ordered_by_size.end(),
            [&](::ml_drift::ValueId a, ::ml_drift::ValueId b) {
              // Sort by size first.
              if (get_tensor(a).bytes < get_tensor(b).bytes) {
                return true;
              }
              if (get_tensor(a).bytes > get_tensor(b).bytes) {
                return false;
              }
              // If the sizes are the same, sort by id to ensure a consistent
              // ordering.
              return a < b;
            });
  // The map contains the weight tensors from the current DelegateKernel
  // instance that will be registered and shared with other DelegateKernel
  // instances, in the form of ML Drift's GpuSpatialTensor, via the
  // SharedMemoryManager instance.
  //  * Key: the tensor's ID in the GraphFloat32 of the current DelegateKernel
  //  instance and it's only valid for the current DelegateKernel instance.
  //  * Value: the tensor's global ID that is valid for all DelegateKernel
  //  instances of the TFLite model, and it will be used to index the tensor's
  //  GpuSpatialTensor object.
  absl::flat_hash_map<::ml_drift::ValueId,
                      ::ml_drift::SharedMemoryManager::GlobalId>
      local_to_global_id_map;
  // Register the constant weight tensors to be shared with other
  // DelegateKernel instances.
  for (auto it = shared_tensor_ids_ordered_by_size.rbegin();
       it != shared_tensor_ids_ordered_by_size.rend(); ++it) {
    ::ml_drift::ValueId shared_tensor_id = *it;
    auto& shared_tflite_tensor = shared_tensors.find(shared_tensor_id)->second;
    ABSL_RETURN_IF_ERROR(shared_mem_manager->RegisterExternalConstantTensors(
        shared_tensor_id, shared_tflite_tensor, local_to_global_id_map));
  }
  // If GPU weights conversion is enabled, trigger the GPU conversion to produce
  // GPU tensors for weights.
  if (convert_weights_on_gpu) {
    ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
    auto& buffer_map = GetBufferIdToSpatialTensorMap(*delegate_data_);
    auto& quant_map = GetQuantParamIdToSpatialTensorMap(*delegate_data_);
    // TODO: b/403337563 - Enable prepare_weights_in_batches with options.
    if ((gpu_info.IsApple() || gpu_info.IsApiWebGpu()) &&
        prepare_weights_in_batches) {
      bool use_serialization_cache =
          shared_memory_serialization_cache != nullptr;
      bool is_cache_ready =
          use_serialization_cache &&
          !shared_memory_serialization_cache->IsReadyForInsert();

      if (is_cache_ready) {
        ABSL_RETURN_IF_ERROR(UpdateTensorsFromSerializationCache(
            shared_tensor_ids_ordered_by_size, local_to_global_id_map,
            shared_memory_serialization_cache));
      } else {
        // On Apple devices, reading weights from clean, file-backed, memory
        // mmapped pages is strongly preferred and it is worth forcing the first
        // load to use the serialization cache.
        bool require_serialization_cache_on_first_load =
            use_serialization_cache && gpu_info.IsApple();
        absl::flat_hash_set<::ml_drift::ValueId> prepared_tensor_ids;
        size_t total_shared_tensor_size = 0;
        for (const auto& shared_tensor_id : shared_tensor_ids_ordered_by_size) {
          total_shared_tensor_size += get_tensor(shared_tensor_id).bytes;
        }
        ABSL_ASSIGN_OR_RETURN(auto batches,
                              backend_->GetBatchesForWeightsPreparation(
                                  shared_mem_manager->GetWeightsManager(),
                                  total_shared_tensor_size));
        for (auto& batch : batches) {
          ABSL_ASSIGN_OR_RETURN(
              auto tensor_map_for_batch,
              backend_->PrepareWeightsInBatch(
                  shared_mem_manager->GetWeightsManager(), batch));
          for (auto& [main_model_id, tensor] : tensor_map_for_batch) {
            ::ml_drift::SharedMemoryManager::GlobalId global_id =
                local_to_global_id_map[main_model_id];
            if (use_serialization_cache) {
              // Download from GPU to CPU memory.
              ::ml_drift::TensorDescriptor descriptor = tensor->GetDescriptor();
              ABSL_RETURN_IF_ERROR(
                  backend_->ReadSpatialTensorToDescriptor(*tensor, descriptor));
              // Insert the descriptor to the cache.
              ABSL_RETURN_IF_ERROR(shared_memory_serialization_cache->Insert(
                  global_id.value, !global_id.IsSourceId(), descriptor));
              // Release the tensor memory.
              if (require_serialization_cache_on_first_load) {
                ABSL_RETURN_IF_ERROR(
                    backend_->ReleaseSpatialTensorMemory(tensor.get()));
              }
            }
            if (global_id.IsSourceId()) {
              buffer_map[global_id.value].weights = std::move(tensor);
            } else {
              quant_map[global_id.value].weights = std::move(tensor);
            }
            prepared_tensor_ids.insert(main_model_id);
          }
          for (auto& op_info : batch) {
            if (delegate_data_->options->madvise_original_shared_tensors) {
              ::ml_drift::MadviseData(const_cast<void*>(op_info.data_ptr),
                                      op_info.size);
            }
          }
        }

        if (require_serialization_cache_on_first_load) {
          // Flush the cache to disk.
          ABSL_RETURN_IF_ERROR(CleanupExternalTensorsSerialization(
              shared_memory_serialization_cache));

          // Load the cache from disk.
          ABSL_ASSIGN_OR_RETURN(
              shared_memory_serialization_cache,
              TryInitializingExternalTensorsSerialization(
                  context, delegate_params, prepare_weights_in_batches));

          ABSL_RETURN_IF_ERROR(UpdateTensorsFromSerializationCache(
              prepared_tensor_ids, local_to_global_id_map,
              shared_memory_serialization_cache));
        }
        // Flush the cache to disk.
        ABSL_RETURN_IF_ERROR(CleanupExternalTensorsSerialization(
            shared_memory_serialization_cache));
      }
    } else {
      ::ml_drift::GpuModel gpu_weights_conversion_model;
      absl::flat_hash_map<::ml_drift::ValueId, ::ml_drift::ValueId> io_mapping;
      std::vector<::ml_drift::WeightsManager::UploadWeightsInfo>
          upload_weights_infos;
      ABSL_RETURN_IF_ERROR(
          shared_mem_manager->GetWeightsManager()->CreateConversionGpuModel(
              gpu_info, &gpu_weights_conversion_model, &io_mapping,
              &upload_weights_infos));
      if (!upload_weights_infos.empty()) {
        ABSL_ASSIGN_OR_RETURN(conversion_context_,
                              backend_->CreateInferenceContext(
                                  create_info, gpu_weights_conversion_model));
        // The preferred number is picked based on the performance of Gemma3N
        // 4B running on Linux + Nvidia GTX 4090 with WebGPU backend. We
        // observed that the peak memory usage keeps dropping, as the
        // preferred number being reduced from 256, until it reaches the below
        // value.
        const int kPreferredNumNodesPerCommandEncoderForWeightsPreparation = 8;
        // Not all backends support customizing num_nodes_per_command_encoder
        // yet.
        conversion_context_
            ->SetCommandBufferHint(
                kPreferredNumNodesPerCommandEncoderForWeightsPreparation)
            .IgnoreError();
        if (delegate_data_->upload_executor) {
          weights_converting_ = std::make_unique<absl::BlockingCounter>(
              upload_weights_infos.size());
          if (delegate_data_->weights_conversion_counter) {
            delegate_data_->weights_conversion_counter->Increment();
          } else {
            delegate_data_->weights_conversion_counter =
                std::make_unique<IncrementableBlockingCounter>(1);
          }
        }
#ifdef __EMSCRIPTEN__
        ABSL_RETURN_IF_ERROR(conversion_context_->UploadWeightsOnWeb(
            delegate_data_->weight_loader, gpu_weights_conversion_model,
            io_mapping, shared_mem_manager->GetWeightIdToExternalBufferIdMap(),
            upload_weights_infos));
#else
        for (const auto& upload_info : upload_weights_infos) {
          auto upload_fn = [this, upload_info]() -> absl::Status {
            ABSL_RETURN_IF_ERROR(conversion_context_->WriteDataToWeightTensor(
                upload_info.input_id,
                absl::MakeConstSpan(
                    static_cast<const uint8_t*>(upload_info.data),
                    upload_info.size)));
            if (delegate_data_->options->madvise_original_shared_tensors) {
              ::ml_drift::MadviseData(const_cast<void*>(upload_info.data),
                                      upload_info.size);
            }
            return absl::OkStatus();
          };
          if (delegate_data_->upload_executor) {
            delegate_data_->upload_executor->Schedule(
                [this, upload_fn = std::move(upload_fn)]() {
                  if (auto s = upload_fn(); !s.ok()) {
                    ABSL_LOG(ERROR) << "Failed to upload weights: " << s;
                  }
                  weights_converting_->DecrementCount();
                });
          } else {
            ABSL_RETURN_IF_ERROR(upload_fn());
          }
        }
#endif  // __EMSCRIPTEN__
        if (delegate_data_->upload_executor) {
          delegate_data_->upload_executor->Schedule([this]() {
            weights_converting_->Wait();
            if (auto s = conversion_context_->Dispatch(); !s.ok()) {
              ABSL_LOG(ERROR) << "Failed to dispatch weights conversion: " << s;
            }
            delegate_data_->weights_conversion_counter->Decrement();
          });
        } else {
          ABSL_RETURN_IF_ERROR(conversion_context_->Dispatch());
        }
        ABSL_RETURN_IF_ERROR(backend_->WaitForCompletion());
        if (delegate_data_->options->wait_for_weights_conversion_complete &&
            delegate_data_->weights_conversion_counter) {
          delegate_data_->weights_conversion_counter->Wait();
          delegate_data_->weights_conversion_counter.reset();
        }
        for (const auto& [converted_weight_id, main_model_weight_id] :
             io_mapping) {
          ABSL_ASSIGN_OR_RETURN(
              auto* tensor,
              conversion_context_->GetSpatialTensor(converted_weight_id));
          ::ml_drift::SharedMemoryManager::GlobalId global_id =
              local_to_global_id_map[main_model_weight_id];
          if (global_id.IsSourceId()) {
            buffer_map[global_id.value].external_weights = tensor;
          } else {
            quant_map[global_id.value].external_weights = tensor;
          }
        }
      }
    }
  }
  // Register the shared tensors as the external immutable tensors for the
  // current DelegateKernel instance's execution with ML Drift.
  for (auto& [local_id, global_id] : local_to_global_id_map) {
    ABSL_ASSIGN_OR_RETURN(
        ::ml_drift::GpuSpatialTensor * tensor,
        shared_mem_manager->GetExternalConstantTensor(global_id));
    create_info.external_immutable_tensors.try_emplace(local_id, tensor);
  }

  external_shared_constant_tensor_ids_.clear();
  external_shared_constant_tensor_ids_.insert(
      shared_tensor_ids_ordered_by_size.begin(),
      shared_tensor_ids_ordered_by_size.end());

  ABSL_RETURN_IF_ERROR(
      CleanupExternalTensorsSerialization(shared_memory_serialization_cache));

#ifdef ML_DRIFT_MEM_STATS
  logger.Stop("Loading: created external tensors");
#endif  // ML_DRIFT_MEM_STATS

  return absl::OkStatus();
}

// Returns false if serialization prerequisites are not initialized. Otherwise
// initializes the serialization params and returns true.
bool DelegateKernel::ReadFromSerializedData() {
  bool has_valid_fd_with_model_token =
      delegate_data_->options->program_cache_fd > 0 &&
      !delegate_data_->model_token.empty();
  bool has_valid_path_with_model_token =
      !delegate_data_->serialization_dir.empty() &&
      !delegate_data_->model_token.empty();

  if ((!has_valid_fd_with_model_token && !has_valid_path_with_model_token) ||
      !delegate_data_->options->serialize_program_cache ||
      // Compiled programs are cached by backend directly.
      delegate_data_->options->cache_compiled_programs_only) {
    return false;
  }
  if (!serialization_) {
    tflite::delegates::SerializationParams params;
    params.model_token = delegate_data_->model_token.c_str();
    params.cache_dir = delegate_data_->serialization_dir.c_str();
    serialization_ = std::make_unique<tflite::delegates::Serialization>(params);
  }
  return true;
}

// Restores inference context from the serialized data.
absl::Status DelegateKernel::InitInferenceContextFromSerializedData(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::GraphFloat32* graph, LiteRtOpSelector& op_selector) {
  // Generate fingerprints for the relevant delegate data options.
  struct {
    MlDriftDelegatePrecision precision;
    bool convert_weights_on_gpu;
    bool use_f32_accum_for_fp16;
    bool allow_src_quantized_fc_conv_ops;
    bool prefer_texture_weights;
    bool use_buffer_storage_type;
    bool enable_infinite_float_capping;
    bool enable_fast_tuning;
#ifdef __APPLE__
    bool use_metal_argument_buffers;
#endif  // __APPLE__
  } options_to_fingerprint = {};
  options_to_fingerprint.precision = delegate_data_->options->precision;
  options_to_fingerprint.convert_weights_on_gpu =
      delegate_data_->options->convert_weights_on_gpu;
  options_to_fingerprint.use_f32_accum_for_fp16 =
      delegate_data_->options->use_f32_accum_for_fp16;
  options_to_fingerprint.allow_src_quantized_fc_conv_ops =
      delegate_data_->options->allow_src_quantized_fc_conv_ops;
  options_to_fingerprint.prefer_texture_weights =
      delegate_data_->options->prefer_texture_weights;
  options_to_fingerprint.use_buffer_storage_type =
      delegate_data_->options->use_buffer_storage_type;
  options_to_fingerprint.enable_infinite_float_capping =
      delegate_data_->options->enable_infinite_float_capping;
  options_to_fingerprint.enable_fast_tuning =
      delegate_data_->options->enable_fast_tuning;
#ifdef __APPLE__
  options_to_fingerprint.use_metal_argument_buffers =
      delegate_data_->options->use_metal_argument_buffers;
#endif  // __APPLE__
  std::string options_fingerprint = tflite::delegates::StrFingerprint(
      reinterpret_cast<const char*>(&options_to_fingerprint),
      sizeof(options_to_fingerprint));
  absl::StrAppend(&options_fingerprint, backend_->GetBackendName());

  std::unique_ptr<tflite::delegates::SerializationEntry> data_key;
  std::unique_ptr<::ml_drift::SerializationProgramCache> program_cache;
  uint64_t fingerprint_key;
  ::ml_drift::MMapHandle program_data_handle;
  if (delegate_data_->options->program_cache_fd > 0) {
    // Duplicate the fd since the program cache will take ownership of the fd.
    // The original fd is owned by the delegate options and may be used after
    // this function returns.
    int dup_fd = dup(delegate_data_->options->program_cache_fd);
    if (dup_fd < 0) {
      return absl::InternalError("Failed to duplicate program cache fd");
    }
    program_cache =
        std::make_unique<::ml_drift::SerializationProgramCache>(dup_fd);
    fingerprint_key = tflite::delegates::Serialization::GetFingerprint(
        delegate_data_->model_token, options_fingerprint, context,
        delegate_params);
    auto program_data = program_cache->LookUpHandle(fingerprint_key);
    if (program_data.ok()) {
      program_data_handle = std::move(program_data.value());
    }
  } else {
    program_cache = std::make_unique<::ml_drift::SerializationProgramCache>(
        delegate_data_->serialization_dir, delegate_data_->model_token);
    fingerprint_key = tflite::delegates::Serialization::GetFingerprint(
        delegate_data_->model_token, options_fingerprint, context,
        delegate_params);
    auto program_data = program_cache->LookUpHandle(fingerprint_key);
    if (program_data.ok()) {
      program_data_handle = std::move(program_data.value());
    }
  }

  if (program_data_handle.IsMapped()) {
    // Restore InferenceContext from serialized data.
    absl::Span<const uint8_t> model_span = absl::Span<const uint8_t>{
        program_data_handle.data(), program_data_handle.size()};

    // If convert_weights_on_gpu is enabled (prepare weights on GPU),
    // trigger weights preparation and register the prepared weights into
    // create_info before restoring the inference context.
    ::ml_drift::CreateGpuModelInfo create_info_main = create_info;
    if (delegate_data_->options->convert_weights_on_gpu &&
        !delegate_data_->options->enable_constant_tensors_sharing) {
      ::ml_drift::GpuModel gpu_model;
      ABSL_RETURN_IF_ERROR(GraphToGpuModelWithGpuConverters(
          *graph, create_info_main, &gpu_model, op_selector));
    }

    auto res = backend_->RestoreInferenceContext(create_info_main, model_span);
    if (res.ok()) {
      ctx_ = std::move(res.value());
      ABSL_LOG(INFO) << "Initialized InferenceContext from serialized data.";
      return absl::OkStatus();
    }
    ABSL_LOG(WARNING) << "Deserialization failed: " << res.status();
    // If the restore fails, fallback to the default graph initialization.
  }

  //  Init InferenceContext and serialize it.
  std::vector<uint8_t> serialized_model;
  ABSL_RETURN_IF_ERROR(
      InitInferenceContextFromGraph(context, delegate_params, create_info,
                                    graph, op_selector, &serialized_model));
  auto save_status = program_cache->Insert(
      fingerprint_key,
      absl::string_view(reinterpret_cast<const char*>(serialized_model.data()),
                        serialized_model.size()));
  if (!save_status.ok()) {
    ABSL_LOG(WARNING) << "Failed to save serialized data: " << save_status;
  }
  return absl::OkStatus();
}

absl::Status DelegateKernel::GraphToGpuModelWithGpuConverters(
    const ::ml_drift::GraphFloat32& graph,
    ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::GpuModel* gpu_model, LiteRtOpSelector& op_selector) {
  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
  ::ml_drift::CreateGpuModelInfo create_info_for_conversion = create_info;
  ::ml_drift::GpuModel gpu_weights_conversion_model;
  absl::flat_hash_map<::ml_drift::ValueId, ::ml_drift::ValueId> weights_mapping;
  std::vector<::ml_drift::WeightsManager::UploadWeightsInfo>
      upload_weights_info;

  ABSL_RETURN_IF_ERROR(::ml_drift::GraphToGpuModelWithWeightsConversion(
      graph, create_info_for_conversion, gpu_info, gpu_model,
      &gpu_weights_conversion_model, &weights_mapping, &upload_weights_info,
      &op_selector));
  ABSL_ASSIGN_OR_RETURN(conversion_context_, backend_->CreateInferenceContext(
                                                 create_info_for_conversion,
                                                 gpu_weights_conversion_model));

  // this can be done in a separate thread. Need to sync then with
  // main.enqueue. Upload data should be alive until completion of all
  // WriteData calls if we have async=true.
  for (const auto& upload_info : upload_weights_info) {
    ABSL_RETURN_IF_ERROR(conversion_context_->WriteDataToWeightTensor(
        upload_info.input_id,
        absl::MakeConstSpan(reinterpret_cast<const uint8_t*>(upload_info.data),
                            upload_info.size)));
    if (delegate_data_->options->madvise_original_shared_tensors) {
      ::ml_drift::MadviseData(const_cast<void*>(upload_info.data),
                              upload_info.size);
    }
  }

  // this can be called later(but before ctx_ enqueue calls) and without
  // explicit wait(if the same queue used for ctx_ enqueue calls).
  ABSL_RETURN_IF_ERROR(conversion_context_->Dispatch());
  ABSL_RETURN_IF_ERROR(backend_->WaitForCompletion());

  for (const auto& [converted_weight_id, main_model_weight_id] :
       weights_mapping) {
    ABSL_ASSIGN_OR_RETURN(auto* tensor, conversion_context_->GetSpatialTensor(
                                            converted_weight_id));
    create_info.external_immutable_tensors.insert(
        {main_model_weight_id, tensor});
  }
  return absl::OkStatus();
}

// Builds inference context from the graph.
absl::Status DelegateKernel::InitInferenceContextFromGraph(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::GraphFloat32* graph, LiteRtOpSelector& op_selector,
    std::vector<uint8_t>* serialized_model) {
  ::ml_drift::CreateGpuModelInfo create_info_main = create_info;
  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
  ::ml_drift::GpuModel gpu_model;
  if (delegate_data_->options->convert_weights_on_gpu &&
      !delegate_data_->options->enable_constant_tensors_sharing &&
      ::ml_drift::WeightsManager::IsGpuWeightsPreparationSupported(gpu_info)) {
    ABSL_RETURN_IF_ERROR(GraphToGpuModelWithGpuConverters(
        *graph, create_info_main, &gpu_model, op_selector));
  } else {
    ABSL_RETURN_IF_ERROR(::ml_drift::GraphToGpuModel(
        *graph, create_info, gpu_info, &gpu_model, &op_selector));
  }
  ABSL_ASSIGN_OR_RETURN(ctx_, backend_->CreateInferenceContext(
                                  create_info_main, gpu_model, serialized_model,
                                  /*may_share_memory_manager=*/true));
  return absl::OkStatus();
}

absl::Status DelegateKernel::InitInferenceContext(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::GraphFloat32* graph) {
#ifdef ML_DRIFT_MEM_STATS
  tflite::profiling::memory::MemoryLatencyLogger logger;
  logger.Start();
#endif  // ML_DRIFT_MEM_STATS

  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
  LiteRtOpSelector op_selector(&create_info, &gpu_info);
  if (ReadFromSerializedData()) {
    ABSL_LOG(INFO) << "Initializing " << backend_->GetBackendName()
                   << "-based API from serialized data.";
    ABSL_RETURN_IF_ERROR(InitInferenceContextFromSerializedData(
        context, delegate_params, create_info, graph, op_selector));
  } else {
    ABSL_LOG(INFO) << "Initializing " << backend_->GetBackendName()
                   << "-based API from graph.";
    ABSL_RETURN_IF_ERROR(InitInferenceContextFromGraph(
        context, delegate_params, create_info, graph, op_selector,
        /*serialized_model=*/nullptr));
  }

#ifdef ML_DRIFT_MEM_STATS
  logger.Stop("Loading: inference context init");
#endif
  return absl::OkStatus();
}

// Creates a new SerializationWeightCache and returns it. If the serialization
// is disabled, it will return a nullptr. If there is an error, it will return
// the error status.
absl::StatusOr<::ml_drift::SerializationWeightCache*>
DelegateKernel::TryInitializingExternalTensorsSerialization(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    bool prepare_weights_in_batches) {
  bool has_valid_fd = delegate_data_->options->weight_cache_fd > 0;
  bool has_valid_path = !delegate_data_->model_token.empty() &&
                        !delegate_data_->serialization_dir.empty();

  if ((!has_valid_fd && !has_valid_path) ||
      !delegate_data_->options->serialize_external_tensors) {
    return nullptr;
  }

  if (!delegate_data_->serialization_cache) {
    // Create the cache.
    delegate_data_->serialization_cache =
        std::make_unique<::ml_drift::SerializationWeightCache>();
  }

  // Create a unique identifier for this subgraph.
  uint64_t unique_model_identifier =
      ::ml_drift::SerializationWeightCache::GenerateUniqueModelIdentifier(
          delegate_data_->model_token, context, delegate_params,
          backend_->GetSerializedDataPrefix(),
          delegate_data_->options->precision,
          delegate_data_->options->prefer_texture_weights,
          delegate_data_->options->allow_src_quantized_fc_conv_ops,
          prepare_weights_in_batches,
          delegate_data_->options->serialize_external_tensors,
          /*ordered_by_size=*/true);

  // Try loading from the cache.
  absl::Status load_status;
  if (has_valid_fd) {
    // Duplicate the fd since the serialization cache will take ownership of the
    // fd. The original fd is owned by the delegate options and may be used
    // after this function returns.
    int dup_fd = dup(delegate_data_->options->weight_cache_fd);
    if (dup_fd < 0) {
      return absl::InternalError("Failed to duplicate weight cache fd");
    }
    load_status = delegate_data_->serialization_cache->Load(
        dup_fd, unique_model_identifier);
  } else {
    load_status = delegate_data_->serialization_cache->Load(
        delegate_data_->serialization_dir, delegate_data_->model_token,
        unique_model_identifier);
  }

  if (!load_status.ok() &&
      load_status.code() != absl::StatusCode::kUnimplemented) {
    if (has_valid_fd) {
      // Duplicate the fd since the serialization cache will take ownership of
      // the fd. The original fd is owned by the delegate options and may be
      // used after this function returns.
      int dup_fd = dup(delegate_data_->options->weight_cache_fd);
      if (dup_fd < 0) {
        return absl::InternalError("Failed to duplicate weight cache fd");
      }
      ABSL_RETURN_IF_ERROR(delegate_data_->serialization_cache->StartBuild(
          dup_fd, unique_model_identifier));
    } else {
      ABSL_RETURN_IF_ERROR(delegate_data_->serialization_cache->StartBuild(
          delegate_data_->serialization_dir, delegate_data_->model_token,
          unique_model_identifier));
    }
  }
  return delegate_data_->serialization_cache.get();
}

absl::Status DelegateKernel::CleanupExternalTensorsSerialization(
    ::ml_drift::SerializationWeightCache* shared_memory_serialization_cache) {
  // Cache was never initialized so there is nothing to clean up.
  if (shared_memory_serialization_cache == nullptr) {
    return absl::OkStatus();
  }
  // If the cache is ready for insert, we have called StartBuild() previously
  // and need to call StopBuild() before releasing the cache. If we have
  // inserted anything previously, this will cause the cache to be written to
  // disk.
  if (shared_memory_serialization_cache->IsReadyForInsert()) {
    ABSL_RETURN_IF_ERROR(shared_memory_serialization_cache->StopBuild());
  }
  return absl::OkStatus();
}

template <typename TensorIdContainer>
absl::Status DelegateKernel::UpdateTensorsFromSerializationCache(
    const TensorIdContainer& tensor_ids,
    const absl::flat_hash_map<::ml_drift::ValueId,
                              ::ml_drift::SharedMemoryManager::GlobalId>&
        local_to_global_id_map,
    ::ml_drift::SerializationWeightCache* shared_memory_serialization_cache) {
  if (shared_memory_serialization_cache == nullptr) {
    return absl::OkStatus();
  }

  auto& buffer_map = GetBufferIdToSpatialTensorMap(*delegate_data_);
  auto& quant_map = GetQuantParamIdToSpatialTensorMap(*delegate_data_);

  for (const auto& main_model_id : tensor_ids) {
    auto global_id_it = local_to_global_id_map.find(main_model_id);
    if (global_id_it == local_to_global_id_map.end()) {
      continue;
    }
    const auto& global_id = global_id_it->second;

    // Read the descriptor from the cache.
    UnownedDataTensorDescriptor unowned_data_tensor_desc;
    size_t page_adjusted_offset;
    ReleaseDataCallback release_data_callback;
    if (shared_memory_serialization_cache
            ->LookUp(global_id.value, global_id.IsParamId(),
                     unowned_data_tensor_desc, page_adjusted_offset,
                     release_data_callback)
            .ok()) {
      ::ml_drift::GpuSpatialTensor* spatial_tensor = nullptr;
      if (global_id.IsSourceId()) {
        auto it = buffer_map.find(global_id.value);
        if (it != buffer_map.end()) {
          spatial_tensor = it->second.GetWeights();
        }
      } else {
        auto it = quant_map.find(global_id.value);
        if (it != quant_map.end()) {
          spatial_tensor = it->second.GetWeights();
        }
      }

      // Only update the tensor if it is present and has allocated weights
      // in this delegate kernel instance.
      if (spatial_tensor != nullptr) {
        // Update tensor from cached descriptor.
        ABSL_RETURN_IF_ERROR(backend_->UpdateSpatialTensor(
            spatial_tensor, unowned_data_tensor_desc, page_adjusted_offset,
            std::move(release_data_callback)));
      } else if (release_data_callback) {
        // LookUp() maps the tensor data from disk via mmap and transfers
        // ownership of the cleanup callback. If spatial_tensor is null,
        // UpdateSpatialTensor() is not called to consume the callback, so
        // we must explicitly invoke it here to unmap the memory and avoid
        // leaking resources.
        (*release_data_callback)();
      }
    }
  }
  return absl::OkStatus();
}

// ===========================================================================
// IrModel initialization pipeline. Mirrors the GraphFloat32 pipeline above
// but operates on ::ml_drift::ir::IrModel. Selected at runtime via
// options->use_ir_model (see Initialize()).
// ===========================================================================
absl::Status DelegateKernel::InitializeIrModel(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params) {
  litert::ml_drift::ModelBuilderOptions options;
  options.enable_infinite_float_capping =
      delegate_data_->options->enable_infinite_float_capping;
  options.enable_reduced_precision = delegate_data_->calculation_precision !=
                                     ::ml_drift::CalculationsPrecision::F32;
  std::unique_ptr<::ml_drift::ir::IrModel> ir_model;

  const TfLiteIntArray* input_tensors = delegate_params->input_tensors;
  input_indices_.reserve(input_tensors->size);

  const TfLiteIntArray* output_tensors = delegate_params->output_tensors;

  ::litert::ml_drift::ir::IrModelBuilderOptions ir_options;
  ir_options.enable_infinite_float_capping =
      options.enable_infinite_float_capping;
  ir_options.enable_reduced_precision = options.enable_reduced_precision;

  auto custom_parsers = ::litert::ml_drift::ir::GetCustomParsers();

  // Constant tensor sharing: derive the shared/external buffer-id maps from the
  // TFLite subgraph so BuildIrModel can mark shared constants and populate
  // `shared_tensors`. The populated map is consumed below by
  // InitializeExternalSharedConstantTensors. When sharing is disabled these
  // remain null and BuildIrModel behaves as before.
  SharedConstTensorsMap shared_tensors;
  SharedConstTensorsMap* shared_tensors_ptr = nullptr;
  const TensorIndexToBufferIdMap* tensor_to_buffer_id_map = nullptr;
  const TensorIndexToExternalBufferIdMap* tensor_to_external_buffer_id_map =
      nullptr;
  TensorIndexToExternalBufferIdMap canonical_external_buffer_id_map;
  if (delegate_data_->options->enable_constant_tensors_sharing) {
    shared_tensors_ptr = &shared_tensors;
    tensor_to_buffer_id_map =
        &(reinterpret_cast<const tflite::Subgraph*>(context->impl_)
              ->GetTensorBufferIdentifiers());
    const auto& external_buffer_id_map =
        reinterpret_cast<const tflite::Subgraph*>(context->impl_)
            ->GetExternalTensorBufferIdentifiers();
    tensor_to_external_buffer_id_map = &external_buffer_id_map;
    if (delegate_data_->weight_loader != nullptr &&
        !external_buffer_id_map.empty()) {
      canonical_external_buffer_id_map.reserve(external_buffer_id_map.size());
      for (const auto& [tensor_id, external_buffer_id] :
           external_buffer_id_map) {
        canonical_external_buffer_id_map.emplace(
            tensor_id,
            delegate_data_->weight_loader->GetCanonicalExternalBufferId(
                static_cast<uint32_t>(external_buffer_id)));
      }
      tensor_to_external_buffer_id_map = &canonical_external_buffer_id_map;
    }
  }
  ir_model.reset(::litert::ml_drift::ir::BuildIrModel(
      *context, *delegate_params, ir_options, &custom_parsers,
      shared_tensors_ptr, tensor_to_buffer_id_map,
      tensor_to_external_buffer_id_map));
  if (!ir_model) {
    return absl::InternalError("Failed to build IrModel.");
  }

  ABSL_RETURN_IF_ERROR(::litert::ml_drift::ApplyCustomTransformations(
      ir_model.get(), *delegate_data_->options));

  input_indices_.reserve(input_tensors->size);
  for (auto tensor_id : ir_model->inputs()) {
    auto producer = ir_model->FindProducer(tensor_id);
    auto consumers = ir_model->FindConsumers(tensor_id);
    if (producer == nullptr && consumers.empty()) continue;
    const auto* t = ir_model->tensor(tensor_id);
    if (t != nullptr && t->buffer_source.tflite_tensor_id >= 0) {
      const TfLiteTensor* tensor =
          context->tensors + t->buffer_source.tflite_tensor_id;
      if (!tflite::IsConstantTensor(tensor)) {
        input_ids_.push_back(tensor_id);
        input_indices_.push_back(t->buffer_source.tflite_tensor_id);
      }
    }
  }

  output_indices_.reserve(output_tensors->size);
  for (auto tensor_id : ir_model->outputs()) {
    auto producer = ir_model->FindProducer(tensor_id);
    auto consumers = ir_model->FindConsumers(tensor_id);
    if (producer == nullptr && consumers.empty()) continue;
    const auto* t = ir_model->tensor(tensor_id);
    if (t != nullptr && t->buffer_source.tflite_tensor_id >= 0) {
      output_ids_.push_back(tensor_id);
      output_indices_.push_back(t->buffer_source.tflite_tensor_id);
    }
  }

  // Create inference context.
  ::ml_drift::CreateGpuModelInfo create_info;
  create_info.precision = delegate_data_->calculation_precision;
  create_info.storage_type = GetStorageType();
#ifdef __APPLE__
  create_info.hints.use_metal_argument_buffers =
      delegate_data_->options->use_metal_argument_buffers;
#endif  // __APPLE__

  create_info.hints.Add(::ml_drift::ModelHints::kAllowSpecialKernels);
  if (delegate_data_->options->prefer_texture_weights) {
    create_info.hints.Add(::ml_drift::ModelHints::kPreferTextureWeights);
  }
  if (delegate_data_->options->enable_fast_tuning) {
    create_info.hints.Add(::ml_drift::ModelHints::kFastTuning);
  }
  if (!delegate_data_->options->allow_src_quantized_fc_conv_ops) {
    create_info.hints.Add(::ml_drift::ModelHints::kDisallow8bitConvs);
  }
  if (delegate_data_->options->enable_constant_tensors_sharing) {
    ABSL_RETURN_IF_ERROR(InitializeExternalSharedConstantTensors(
        context, delegate_params, shared_tensors,
        std::make_unique<::ml_drift::IrModelAdapter>(*ir_model), create_info));
  }

  external_tensor_ids_.reserve(input_indices_.size() + output_indices_.size());
  std::vector<::ml_drift::TensorRef<::ml_drift::BHWC>> input_tensor_refs;
  input_tensor_refs.reserve(input_ids_.size());
  for (auto id : input_ids_) {
    const auto* t = ir_model->tensor(id);
    input_tensor_refs.push_back({
        .type = t->desc.GetDataType(),
        .shape = t->desc.GetBHWCShape(),
    });
  }

  std::vector<::ml_drift::TensorRef<::ml_drift::BHWC>> output_tensor_refs;
  output_tensor_refs.reserve(output_ids_.size());
  for (auto id : output_ids_) {
    const auto* t = ir_model->tensor(id);
    output_tensor_refs.push_back({
        .type = t->desc.GetDataType(),
        .shape = t->desc.GetBHWCShape(),
    });
  }

  ABSL_RETURN_IF_ERROR(UpdateCreateInfoWithExternalTensors(
      context, create_info, input_tensor_refs, output_tensor_refs));
  if (!external_tensor_ids_.empty()) {
    ABSL_LOG(INFO)
        << "Total " << external_tensor_ids_.size()
        << " external tensors are used for delegate inputs and outputs";
  }
  ABSL_RETURN_IF_ERROR(InitInferenceContext(context, delegate_params,
                                            create_info, ir_model.get()));

  if (delegate_data_->options->enable_op_profiling_detailed_report) {
    ABSL_LOG(INFO) << create_info.external_mutable_tensors.size();
    ::ml_drift::ProfilingInfo profiling_info;
    ABSL_RETURN_IF_ERROR(ctx_->Profile(profiling_info));
    ::ml_drift::ProfilingInfo::DetailedReportOptions report_options;
    report_options.add_shapes_info = false;
    ABSL_LOG(INFO) << profiling_info.GetDetailedReport(report_options)
                   << std::endl;
    ABSL_ASSIGN_OR_RETURN(
        auto runtime_mem_bytes,
        ctx_->GetSizeOfMemoryAllocatedForIntermediateTensors());
    ABSL_LOG(INFO) << "Memory for intermediate tensors - "
                   << runtime_mem_bytes / 1024.0 / 1024.0 << " MB";
    ABSL_ASSIGN_OR_RETURN(auto const_mem_bytes,
                          ctx_->GetSizeOfMemoryAllocatedForConstantTensors());
    ABSL_LOG(INFO) << "Memory for constant tensors - "
                   << const_mem_bytes / 1024.0 / 1024.0 << " MB";
    ABSL_LOG(INFO) << "Total tensors memory(const + intermediate) - "
                   << (const_mem_bytes + runtime_mem_bytes) / 1024.0 / 1024.0
                   << " MB";
    ABSL_ASSIGN_OR_RETURN(auto external_bytes,
                          ctx_->GetSizeOfMemoryAllocatedForExternalTensors());
    ABSL_LOG(INFO) << "Memory for external tensors - "
                   << external_bytes / 1024.0 / 1024.0 << " MB";
  }

  ctx_->ReportMemoryBenchmarkIfEnabled(create_info).IgnoreError();
  return absl::OkStatus();
}

absl::Status DelegateKernel::IrModelToGpuModelWithGpuConverters(
    ::ml_drift::ir::IrModel* model, ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::GpuModel* gpu_model,
    ::litert::ml_drift::ir::LiteRtOpSelector* op_selector) {
  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
  ::ml_drift::CreateGpuModelInfo create_info_for_conversion = create_info;
  ::ml_drift::GpuModel gpu_weights_conversion_model;
  absl::flat_hash_map<::ml_drift::ValueId, ::ml_drift::ValueId> weights_mapping;
  std::vector<::ml_drift::WeightsManager::UploadWeightsInfo>
      upload_weights_info;

  ABSL_RETURN_IF_ERROR(::ml_drift::ir::IrModelToGpuModelWithWeightsConversion(
      *model, create_info_for_conversion, gpu_info, gpu_model,
      &gpu_weights_conversion_model, &weights_mapping, &upload_weights_info,
      op_selector));

  ABSL_ASSIGN_OR_RETURN(conversion_context_, backend_->CreateInferenceContext(
                                                 create_info_for_conversion,
                                                 gpu_weights_conversion_model));

  // this can be done in a separate thread. Need to sync then with
  // main.enqueue. Upload data should be alive until completion of all
  // WriteData calls if we have async=true.
  for (const auto& upload_info : upload_weights_info) {
    ABSL_RETURN_IF_ERROR(conversion_context_->WriteDataToWeightTensor(
        upload_info.input_id,
        absl::MakeConstSpan(reinterpret_cast<const uint8_t*>(upload_info.data),
                            upload_info.size)));
    if (delegate_data_->options->madvise_original_shared_tensors) {
      ::ml_drift::MadviseData(const_cast<void*>(upload_info.data),
                              upload_info.size);
    }
  }

  // this can be called later(but before ctx_ enqueue calls) and without
  // explicit wait(if the same queue used for ctx_ enqueue calls).
  ABSL_RETURN_IF_ERROR(conversion_context_->Dispatch());
  ABSL_RETURN_IF_ERROR(backend_->WaitForCompletion());

  for (const auto& [converted_weight_id, main_model_weight_id] :
       weights_mapping) {
    ABSL_ASSIGN_OR_RETURN(auto* tensor, conversion_context_->GetSpatialTensor(
                                            converted_weight_id));
    create_info.external_immutable_tensors.insert(
        {main_model_weight_id, tensor});
  }
  return absl::OkStatus();
}

// Restores inference context from the serialized data.
absl::Status DelegateKernel::InitInferenceContextFromSerializedData(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::ir::IrModel* model,
    ::litert::ml_drift::ir::LiteRtOpSelector* op_selector) {
  // Generate fingerprints for the relevant delegate data options.
  struct {
    MlDriftDelegatePrecision precision;
    bool convert_weights_on_gpu;
    bool use_f32_accum_for_fp16;
  } options_to_fingerprint = {};
  options_to_fingerprint.precision = delegate_data_->options->precision;
  options_to_fingerprint.convert_weights_on_gpu =
      delegate_data_->options->convert_weights_on_gpu;
  options_to_fingerprint.use_f32_accum_for_fp16 =
      delegate_data_->options->use_f32_accum_for_fp16;
  std::string options_fingerprint = tflite::delegates::StrFingerprint(
      reinterpret_cast<const char*>(&options_to_fingerprint),
      sizeof(options_to_fingerprint));

  std::unique_ptr<tflite::delegates::SerializationEntry> data_key;
  std::unique_ptr<::ml_drift::SerializationProgramCache> program_cache;
  uint64_t fingerprint_key;
  ::ml_drift::MMapHandle program_data_handle;
  if (delegate_data_->options->program_cache_fd > 0) {
    // Duplicate the fd since the program cache will take ownership of the fd.
    // The original fd is owned by the delegate options and may be used after
    // this function returns.
    int dup_fd = dup(delegate_data_->options->program_cache_fd);
    if (dup_fd < 0) {
      return absl::InternalError("Failed to duplicate program cache fd");
    }
    program_cache =
        std::make_unique<::ml_drift::SerializationProgramCache>(dup_fd);
    fingerprint_key = tflite::delegates::Serialization::GetFingerprint(
        delegate_data_->model_token, options_fingerprint, context,
        delegate_params);
    auto program_data = program_cache->LookUpHandle(fingerprint_key);
    if (program_data.ok()) {
      program_data_handle = std::move(program_data.value());
    }
  } else {
    program_cache = std::make_unique<::ml_drift::SerializationProgramCache>(
        delegate_data_->serialization_dir, delegate_data_->model_token);
    fingerprint_key = tflite::delegates::Serialization::GetFingerprint(
        delegate_data_->model_token, options_fingerprint, context,
        delegate_params);
    auto program_data = program_cache->LookUpHandle(fingerprint_key);
    if (program_data.ok()) {
      program_data_handle = std::move(program_data.value());
    }
  }

  if (program_data_handle.IsMapped()) {
    // Restore InferenceContext from serialized data.
    absl::Span<const uint8_t> model_span = absl::Span<const uint8_t>{
        program_data_handle.data(), program_data_handle.size()};

    // If convert_weights_on_gpu is enabled (prepare weights on GPU),
    // trigger weights preparation and register the prepared weights into
    // create_info before restoring the inference context.
    ::ml_drift::CreateGpuModelInfo create_info_main = create_info;
    if (delegate_data_->options->convert_weights_on_gpu &&
        !delegate_data_->options->enable_constant_tensors_sharing) {
      ::ml_drift::GpuModel gpu_model;
      ABSL_RETURN_IF_ERROR(IrModelToGpuModelWithGpuConverters(
          model, create_info_main, &gpu_model, op_selector));
    }

    auto res = backend_->RestoreInferenceContext(create_info_main, model_span);
    if (res.ok()) {
      ctx_ = std::move(res.value());
      ABSL_LOG(INFO) << "Initialized InferenceContext from serialized data.";
      return absl::OkStatus();
    }
    ABSL_LOG(WARNING) << "Deserialization failed: " << res.status();
    // If the restore fails, fallback to the default graph initialization.
  }

  //  Init InferenceContext and serialize it.
  std::vector<uint8_t> serialized_model;
  ABSL_RETURN_IF_ERROR(
      InitInferenceContextFromGraph(context, delegate_params, create_info,
                                    model, op_selector, &serialized_model));
  auto save_status = program_cache->Insert(
      fingerprint_key,
      absl::string_view(reinterpret_cast<const char*>(serialized_model.data()),
                        serialized_model.size()));
  if (!save_status.ok()) {
    ABSL_LOG(WARNING) << "Failed to save serialized data: " << save_status;
  }
  return absl::OkStatus();
}

// Builds inference context from the graph.
absl::Status DelegateKernel::InitInferenceContextFromGraph(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::ir::IrModel* model,
    ::litert::ml_drift::ir::LiteRtOpSelector* op_selector,
    std::vector<uint8_t>* serialized_model) {
  ::ml_drift::CreateGpuModelInfo create_info_main = create_info;
  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());
  ::ml_drift::GpuModel gpu_model;
  if (delegate_data_->options->convert_weights_on_gpu &&
      !delegate_data_->options->enable_constant_tensors_sharing &&
      ::ml_drift::WeightsManager::IsGpuWeightsPreparationSupported(gpu_info)) {
    ABSL_RETURN_IF_ERROR(IrModelToGpuModelWithGpuConverters(
        model, create_info_main, &gpu_model, op_selector));
  } else {
    ABSL_RETURN_IF_ERROR(::ml_drift::ir::IrModelToGpuModel(
        *model, create_info, gpu_info, &gpu_model, op_selector));
  }
  ABSL_ASSIGN_OR_RETURN(ctx_, backend_->CreateInferenceContext(
                                  create_info_main, gpu_model, serialized_model,
                                  /*may_share_memory_manager=*/true));
  return absl::OkStatus();
}

absl::Status DelegateKernel::InitInferenceContext(
    TfLiteContext* context, const TfLiteDelegateParams* delegate_params,
    const ::ml_drift::CreateGpuModelInfo& create_info,
    ::ml_drift::ir::IrModel* model) {
#ifdef ML_DRIFT_MEM_STATS
  tflite::profiling::memory::MemoryLatencyLogger logger;
  logger.Start();
#endif  // ML_DRIFT_MEM_STATS

  ABSL_ASSIGN_OR_RETURN(auto gpu_info, backend_->GetInfo());

  auto ir_op_selector =
      std::make_unique<::litert::ml_drift::ir::LiteRtOpSelector>(&create_info,
                                                                 &gpu_info);

  if (ReadFromSerializedData()) {
    ABSL_LOG(INFO) << "Initializing " << backend_->GetBackendName()
                   << "-based API from serialized data.";
    ABSL_RETURN_IF_ERROR(InitInferenceContextFromSerializedData(
        context, delegate_params, create_info, model, ir_op_selector.get()));
  } else {
    ABSL_LOG(INFO) << "Initializing " << backend_->GetBackendName()
                   << "-based API from graph.";
    ABSL_RETURN_IF_ERROR(InitInferenceContextFromGraph(
        context, delegate_params, create_info, model, ir_op_selector.get(),
        /*serialized_model=*/nullptr));
  }

#ifdef ML_DRIFT_MEM_STATS
  logger.Stop("Loading: inference context init");
#endif
  return absl::OkStatus();
}

}  // namespace litert::ml_drift
