/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2024, Arnaud Roques
 *
 * Project Info:  https://plantuml.com
 * 
 * If you like this project or if you find it useful, you can support us at:
 * 
 * https://plantuml.com/patreon (only 1$ per month!)
 * https://plantuml.com/paypal
 * 
 * This file is part of PlantUML.
 *
 * PlantUML is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PlantUML distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 *
 * Original Author:  Arnaud Roques
 *
 *
 */
package net.sourceforge.plantuml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.sourceforge.plantuml.command.Command;
import net.sourceforge.plantuml.command.CommandExecutionResult;
import net.sourceforge.plantuml.command.ParserPass;
import net.sourceforge.plantuml.core.Diagram;
import net.sourceforge.plantuml.core.DiagramChromeFactory;
import net.sourceforge.plantuml.core.DiagramDescription;
import net.sourceforge.plantuml.core.TextBlockExporter;
import net.sourceforge.plantuml.core.UmlSource;
import net.sourceforge.plantuml.klimt.color.ColorMapper;
import net.sourceforge.plantuml.klimt.color.HColor;
import net.sourceforge.plantuml.klimt.color.NoSuchColorException;
import net.sourceforge.plantuml.klimt.shape.TextBlock;
import net.sourceforge.plantuml.klimt.shape.TextBlockUtils;
import net.sourceforge.plantuml.preproc.PreprocessingArtifact;
import net.sourceforge.plantuml.utils.BlocLines;

public class NewpagedDiagram extends UgDiagram {

	private final List<UgDiagram> diagrams = new ArrayList<>();

	public NewpagedDiagram(UmlSource source, UgDiagram diag1, UgDiagram diag2,
			PreprocessingArtifact preprocessingArtifact) {
		super(source, preprocessingArtifact);
		if (diag1 instanceof NewpagedDiagram)
			throw new IllegalArgumentException();

		if (diag2 instanceof NewpagedDiagram)
			throw new IllegalArgumentException();

		this.diagrams.add(diag1);
		this.diagrams.add(diag2);
	}

	@Override
	public String toString() {
		return super.toString() + " SIZE=" + diagrams.size() + " " + diagrams;
	}

	public UgDiagram getLastDiagram() {
		return diagrams.get(diagrams.size() - 1);
	}

	@Override
	public CommandExecutionResult executeCommand(Command cmd, BlocLines lines, ParserPass currentPass) {
		final int nb = diagrams.size();
		try {
			final CommandExecutionResult tmp = cmd.execute(diagrams.get(nb - 1), lines, currentPass);
			if (tmp.getNewDiagram() instanceof NewpagedDiagram) {
				final NewpagedDiagram new1 = (NewpagedDiagram) tmp.getNewDiagram();
				// System.err.println("this=" + this);
				// System.err.println("new1=" + new1);
				if (new1.size() != 2)
					throw new IllegalStateException();

				if (new1.diagrams.get(0) != this.diagrams.get(nb - 1))
					throw new IllegalStateException();

				this.diagrams.add(new1.diagrams.get(1));
				return tmp.withDiagram(this);

			}
			return tmp;
		} catch (NoSuchColorException e) {
			return CommandExecutionResult.badColor();
		}
	}

	private int size() {
		return diagrams.size();
	}

//	@Override
//	public final ImageData exportDiagram(OutputStream os, int num, FileFormatOption fileFormat) throws IOException {
//		return diagrams.get(num).exportDiagram(os, 0, fileFormat);
//	}

	@Override
	public TextBlock getTextBlock(int num, FileFormatOption fileFormatOption) throws Exception {
		final TitledDiagram titledDiagram = (TitledDiagram) diagrams.get(num);
		TextBlock result = titledDiagram.getTextBlock(num, fileFormatOption);
		result = DiagramChromeFactory.create(result, titledDiagram, titledDiagram.getSkinParam(),
				titledDiagram.getWarnings(), titledDiagram.getTitle());

		return result;
	}

	@Override
	protected TextBlockExporter getExporter(int num, FileFormatOption fileFormatOption) throws Exception {

		TextBlock result = getTextBlock(num, fileFormatOption);

		final HColor backColor = calculateBackColor();
		if (backColor != null)
			result = TextBlockUtils.addBackcolor(result, backColor);

		final ColorMapper mutedMapper = muteColorMapper(fileFormatOption.getColorMapper());
		final FileFormatOption effectiveFormat = fileFormatOption.withColorMapper(mutedMapper);

		final TitledDiagram titledDiagram = (TitledDiagram) diagrams.get(num);

		final TextBlockExporter.Builder builder = TextBlockExporter.builder(result, effectiveFormat,
				titledDiagram.isHandwritten());

		builder.styled(titledDiagram);

		return builder.build();

	}

	public int getCardinality() {
		int nb = 0;
		for (UgDiagram d : diagrams)
			nb += d.getNbImages();

		return nb;
	}

	public DiagramDescription getDescription() {
		final StringBuilder sb = new StringBuilder();
		for (UgDiagram d : diagrams) {
			if (sb.length() > 0)
				sb.append(" ");

			sb.append(d.getDescription());
		}
		return new DiagramDescription(sb.toString());
	}

//	public String getWarningOrError() {
//		final StringBuilder sb = new StringBuilder();
//		for (Diagram d : diagrams) {
//			if (sb.length() > 0)
//				sb.append(" ");
//
//			if (d.getWarningOrError() != null)
//				sb.append(d.getWarningOrError());
//
//		}
//		if (sb.length() == 0)
//			return null;
//
//		return sb.toString();
//	}

	@Override
	public void makeDiagramReady() {
		super.makeDiagramReady();
		for (UgDiagram diagram : diagrams)
			diagram.makeDiagramReady();

	}

	@Override
	public String checkFinalError() {
		for (UgDiagram p : getDiagrams()) {
			final String check = ((Diagram) p).checkFinalError();
			if (check != null)
				return check;

		}
		return super.checkFinalError();
	}

	public final List<UgDiagram> getDiagrams() {
		return Collections.unmodifiableList(diagrams);
	}

}
