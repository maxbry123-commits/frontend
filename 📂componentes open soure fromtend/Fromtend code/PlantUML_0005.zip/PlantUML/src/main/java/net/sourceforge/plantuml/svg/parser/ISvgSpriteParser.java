/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2024, Arnaud Roques
 *
 * Project Info:  https://plantuml.com
 *
 * If you like this project or if you find it useful, you can support us at:
 *
 * https://plantuml.com/patreon (only 1$ per month!)
 * https://plantuml.com/paypal
 *
 * This file is part of PlantUML.
 *
 * PlantUML is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PlantUML distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 *
 * Original Author:  Arnaud Roques
 *
 *
 */
package net.sourceforge.plantuml.svg.parser;

import net.sourceforge.plantuml.klimt.color.HColor;
import net.sourceforge.plantuml.klimt.drawing.UGraphic;
import net.sourceforge.plantuml.klimt.sprite.Sprite;

/**
 * Contract for SVG sprite parsers used by PlantUML to render sprite content
 * into a {@link net.sourceforge.plantuml.klimt.drawing.UGraphic}.
 *
 * <p>Implementations are responsible for interpreting SVG content and drawing
 * to the provided graphic context with scaling and color resolution applied.
 *
 * <p>Parsers are selected at runtime (for example via pragma) and may differ
 * in feature support and rendering fidelity.
 */
public interface ISvgSpriteParser extends Sprite {

	/**
	 * Render the sprite into the provided graphics context.
	 *
	 * @param ug the graphic context used for drawing
	 * @param scale scale factor applied to the SVG content
	 * @param fontColor default font color to use for text elements
	 * @param forcedColor optional override color for monochrome rendering
	 */
	void drawU(UGraphic ug, double scale, HColor fontColor, HColor forcedColor);

}
