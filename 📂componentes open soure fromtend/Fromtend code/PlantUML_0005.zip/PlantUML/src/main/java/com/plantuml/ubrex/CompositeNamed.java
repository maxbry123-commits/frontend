/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2024, Arnaud Roques
 *
 * Project Info:  https://plantuml.com
 *
 * If you like this project or if you find it useful, you can support us at:
 *
 * https://plantuml.com/patreon (only 1$ per month!)
 * https://plantuml.com/paypal
 *
 * This file is part of PlantUML.
 *
 * PlantUML is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PlantUML distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 *
 * Original Author:  Arnaud Roques
 *
 */
package com.plantuml.ubrex;

import java.util.Collections;
import java.util.List;

public class CompositeNamed implements Challenge {

	private final String name;
	private final List<Challenge> challenges;

	@Override
	public String toString() {
		return "(" + name + ") " + challenges.toString();
	}

	public CompositeNamed(String name, Challenge challenge) {
		this.name = name;
		this.challenges = Collections.singletonList(challenge);
	}

	public CompositeNamed(String name, List<Challenge> challenges) {
		this.name = name;
		this.challenges = challenges;
	}

	@Override
	public ChallengeResult runChallenge(TextNavigator string, int position) {

		Capture capture = Capture.EMPTY;

		int current = position;
		for (Challenge challenge : challenges) {
			final ChallengeResult shallWePass = challenge.runChallenge(string, current);
			if (shallWePass.getFullCaptureLength() < 0)
				return ChallengeResult.NO_MATCH;

			current += shallWePass.getFullCaptureLength();
			capture = capture.merge(shallWePass.getCapture());
		}

		final String value = string.subSequence(position, current).toString();
		capture = capture.withPrefixedKeys(name);
		capture = capture.withEntry(name, value);

		return new ChallengeResult(current - position, capture);
	}

}
