# Copyright (c) 2024, Frappe Technologies Pvt Ltd and contributors
# For license information, please see license.txt

import json
import os
import shutil

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.modules import scrub
from frappe.modules.export_file import export_to_files

from builder.utils import copy_img_to_asset_folder, get_template_assets_folder_path


class BlockTemplate(Document):
	def on_update(self):
		if not self.preview:
			frappe.throw(_("Preview Image is mandatory"))

		files = frappe.get_all("File", filters={"file_url": self.preview}, fields=["name"])
		if files:
			_file = frappe.get_doc("File", files[0].name)
			# block-template thumbnails always live in builder, never the template hub app
			assets_folder_path = get_template_assets_folder_path(self, app="builder")
			shutil.copy(_file.get_full_path(), assets_folder_path)
			self.preview = f"/builder_assets/{self.name}/{self.preview.split('/')[-1]}"
			self.db_set("preview", self.preview)

		block = frappe.parse_json(self.block)
		if block:
			copy_img_to_asset_folder(block, self, app="builder")
		self.db_set("block", json.dumps(block, separators=(",", ":")))

		export_to_files(
			record_list=[
				[
					"Block Template",
					self.name,
					"builder_block_template",
				],
			],
			record_module="builder",
		)

	def on_trash(self):
		block_template_folder = os.path.join(
			frappe.get_app_path("builder"), "builder", "builder_block_template", scrub(self.name)
		)
		shutil.rmtree(block_template_folder, ignore_errors=True)
		assets_folder_path = get_template_assets_folder_path(self, app="builder")
		shutil.rmtree(assets_folder_path, ignore_errors=True)
