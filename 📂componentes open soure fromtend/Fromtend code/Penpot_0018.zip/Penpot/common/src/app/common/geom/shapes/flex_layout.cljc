;; This Source Code Form is subject to the terms of the Mozilla Public
;; License, v. 2.0. If a copy of the MPL was not distributed with this
;; file, You can obtain one at http://mozilla.org/MPL/2.0/.
;;
;; Copyright (c) KALEIDOS SUBSIDIARY SL

(ns app.common.geom.shapes.flex-layout
  (:require
   [app.common.data.macros :as dm]
   [app.common.geom.shapes.flex-layout.bounds :as fbo]
   [app.common.geom.shapes.flex-layout.drop-area :as fdr]
   [app.common.geom.shapes.flex-layout.layout-data :as fld]
   [app.common.geom.shapes.flex-layout.modifiers :as fmo]
   [app.common.geom.shapes.flex-layout.params :as fp]))

(dm/export fbo/layout-content-bounds)
(dm/export fbo/layout-content-points)
(dm/export fbo/child-layout-bound-points)
(dm/export fdr/get-drop-index)
(dm/export fdr/get-drop-areas)
(dm/export fld/calc-layout-data)
(dm/export fmo/layout-child-modifiers)
(dm/export fp/calculate-params)
