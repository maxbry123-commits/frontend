/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
export default defineConfig({
  root: __dirname,
  server: {
    port: 4202,
    host: '0.0.0.0',
  },

  preview: {
    port: 4202,
    host: '0.0.0.0',
  },

  resolve: {
    tsconfigPaths: true,
  },

  build: {
    outDir: '../../dist/apps/example-styles',
    reportCompressedSize: true,
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },

  test: {
    globals: true,
    environment: 'jsdom',
    include: ['src/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}'],

    reporters: ['default'],
    coverage: {
      reportsDirectory: '../../coverage/apps/example-styles',
      provider: 'v8',
    },
  },
});
