import { z } from "zod";
import { type StyleProperty, styleValue } from "@webstudio-is/css-engine";
import type { Simplify } from "type-fest";

const styleDeclRaw = z.object({
  styleSourceId: z.string(),
  breakpointId: z.string(),
  state: z.optional(z.string()),
  // @todo can't figure out how to make property to be enum
  property: z.string(),
  value: styleValue,
  listed: z
    .boolean()
    .optional()
    .describe("Whether the style is from the Advanced panel"),
});

export type StyleDecl = Simplify<
  Omit<z.infer<typeof styleDeclRaw>, "property"> & {
    property: StyleProperty;
  }
>;
export const styleDecl = styleDeclRaw as z.ZodType<StyleDecl>;

export type StyleDeclKey = string;

export const getStyleDeclKey = (
  styleDecl: Omit<StyleDecl, "value">
): StyleDeclKey => {
  return `${styleDecl.styleSourceId}:${styleDecl.breakpointId}:${
    styleDecl.property
  }:${styleDecl.state ?? ""}`;
};

export const styles = z.map(z.string(), styleDecl);

export type Styles = Map<string, StyleDecl>;
