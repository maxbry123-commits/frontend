import {
  Box as Box,
  Text as Text,
  HtmlEmbed as HtmlEmbed,
} from "@webstudio-is/sdk-components-react/components";
import {
  Accordion as Accordion,
  AccordionItem as AccordionItem,
  AccordionHeader as AccordionHeader,
  AccordionTrigger as AccordionTrigger,
  AccordionContent as AccordionContent,
} from "../components";

const Component = () => {
  return (
    <Box className={`w-box`}>
      <Accordion collapsible={true} value={"0"} className={`w-accordion`}>
        <AccordionItem data-ws-index="0" className={`w-item w-item-1`}>
          <AccordionHeader className={`w-item-header w-item-header-1`}>
            <AccordionTrigger className={`w-item-trigger w-item-trigger-1`}>
              <Text className={`w-text`}>{"Is it accessible?"}</Text>
              <Box className={`w-box w-icon-container`}>
                <HtmlEmbed
                  code={
                    '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16" width="100%" height="100%" style="display: block;"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="m4 6 4 4 4-4"/></svg>'
                  }
                  className={`w-html-embed w-chevron-icon`}
                />
              </Box>
            </AccordionTrigger>
          </AccordionHeader>
          <AccordionContent
            forceMount={true}
            className={`w-item-content w-item-content-1`}
          >
            {"Yes. It adheres to the WAI-ARIA design pattern."}
          </AccordionContent>
        </AccordionItem>
        <AccordionItem data-ws-index="1" className={`w-item w-item-2`}>
          <AccordionHeader className={`w-item-header w-item-header-2`}>
            <AccordionTrigger className={`w-item-trigger w-item-trigger-2`}>
              <Text className={`w-text`}>{"Is it styled?"}</Text>
              <Box className={`w-box w-icon-container-1`}>
                <HtmlEmbed
                  code={
                    '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16" width="100%" height="100%" style="display: block;"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="m4 6 4 4 4-4"/></svg>'
                  }
                  className={`w-html-embed w-chevron-icon-1`}
                />
              </Box>
            </AccordionTrigger>
          </AccordionHeader>
          <AccordionContent
            forceMount={true}
            className={`w-item-content w-item-content-2`}
          >
            {
              "Yes. It comes with default styles that matches the other components' aesthetic."
            }
          </AccordionContent>
        </AccordionItem>
        <AccordionItem data-ws-index="2" className={`w-item w-item-3`}>
          <AccordionHeader className={`w-item-header w-item-header-3`}>
            <AccordionTrigger className={`w-item-trigger w-item-trigger-3`}>
              <Text className={`w-text`}>{"Is it animated?"}</Text>
              <Box className={`w-box w-icon-container-2`}>
                <HtmlEmbed
                  code={
                    '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16" width="100%" height="100%" style="display: block;"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="m4 6 4 4 4-4"/></svg>'
                  }
                  className={`w-html-embed w-chevron-icon-2`}
                />
              </Box>
            </AccordionTrigger>
          </AccordionHeader>
          <AccordionContent
            forceMount={true}
            className={`w-item-content w-item-content-3`}
          >
            {
              "Yes. It's animated by default, but you can disable it if you prefer."
            }
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Box>
  );
};

export default {
  title: "Components/Accordion",
};

const Story = {
  render() {
    return (
      <>
        <style>
          {`
@layer presets {
  div.w-box {
    box-sizing: border-box
  }
  div.w-html-embed {
    display: contents;
    white-space: normal;
    white-space-collapse: collapse
  }
  div.w-text {
    box-sizing: border-box;
    min-height: 1em
  }
  div.w-accordion {
    box-sizing: border-box
  }
  div.w-item-content {
    box-sizing: border-box
  }
  h3.w-item-header {
    box-sizing: border-box;
    margin-top: 0px;
    margin-bottom: 0px
  }
  div.w-item {
    box-sizing: border-box
  }
  button.w-item-trigger {
    font-family: inherit;
    font-size: 100%;
    line-height: 1.15;
    box-sizing: border-box;
    text-transform: none;
    background-color: transparent;
    background-image: none;
    border: 0px solid rgb(226 232 240 / 1);
    margin: 0;
    padding: 0px
  }
}
@media all {
  .w-item-1 {
    border-bottom: 1px solid rgb(226 232 240 / 1)
  }
  .w-item-header-1 {
    display: flex
  }
  .w-item-trigger-1 {
    display: flex;
    flex-grow: 1;
    flex-shrink: 1;
    flex-basis: 0;
    align-items: center;
    justify-content: space-between;
    padding-top: 1rem;
    padding-right: 0;
    padding-bottom: 1rem;
    padding-left: 0;
    font-weight: 500;
    --accordion-trigger-icon-transform: 0deg
  }
  .w-item-trigger-1:hover {
    text-decoration-line: underline
  }
  .w-item-trigger-1[data-state="open"] {
    --accordion-trigger-icon-transform: 180deg
  }
  .w-icon-container {
    rotate: var(--accordion-trigger-icon-transform);
    height: 1rem;
    width: 1rem;
    flex-shrink: 0;
    transition-property: all;
    transition-duration: 200ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-chevron-icon {
    display: block;
    width: 100%;
    height: 100%;
    line-height: 0
  }
  .w-item-content-1 {
    overflow-x: hidden;
    overflow-y: hidden;
    font-size: 0.875rem;
    line-height: 1.25rem;
    transition-property: all;
    transition-duration: 150ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-item-content-1[data-state="closed"] {
    height: 0
  }
  .w-item-content-1[data-state="open"] {
    height: var(--radix-accordion-content-height)
  }
  .w-item-2 {
    border-bottom: 1px solid rgb(226 232 240 / 1)
  }
  .w-item-header-2 {
    display: flex
  }
  .w-item-trigger-2 {
    display: flex;
    flex-grow: 1;
    flex-shrink: 1;
    flex-basis: 0;
    align-items: center;
    justify-content: space-between;
    padding-top: 1rem;
    padding-right: 0;
    padding-bottom: 1rem;
    padding-left: 0;
    font-weight: 500;
    --accordion-trigger-icon-transform: 0deg
  }
  .w-item-trigger-2:hover {
    text-decoration-line: underline
  }
  .w-item-trigger-2[data-state="open"] {
    --accordion-trigger-icon-transform: 180deg
  }
  .w-icon-container-1 {
    rotate: var(--accordion-trigger-icon-transform);
    height: 1rem;
    width: 1rem;
    flex-shrink: 0;
    transition-property: all;
    transition-duration: 200ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-chevron-icon-1 {
    display: block;
    width: 100%;
    height: 100%;
    line-height: 0
  }
  .w-item-content-2 {
    overflow-x: hidden;
    overflow-y: hidden;
    font-size: 0.875rem;
    line-height: 1.25rem;
    transition-property: all;
    transition-duration: 150ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-item-content-2[data-state="closed"] {
    height: 0
  }
  .w-item-content-2[data-state="open"] {
    height: var(--radix-accordion-content-height)
  }
  .w-item-3 {
    border-bottom: 1px solid rgb(226 232 240 / 1)
  }
  .w-item-header-3 {
    display: flex
  }
  .w-item-trigger-3 {
    display: flex;
    flex-grow: 1;
    flex-shrink: 1;
    flex-basis: 0;
    align-items: center;
    justify-content: space-between;
    padding-top: 1rem;
    padding-right: 0;
    padding-bottom: 1rem;
    padding-left: 0;
    font-weight: 500;
    --accordion-trigger-icon-transform: 0deg
  }
  .w-item-trigger-3:hover {
    text-decoration-line: underline
  }
  .w-item-trigger-3[data-state="open"] {
    --accordion-trigger-icon-transform: 180deg
  }
  .w-icon-container-2 {
    rotate: var(--accordion-trigger-icon-transform);
    height: 1rem;
    width: 1rem;
    flex-shrink: 0;
    transition-property: all;
    transition-duration: 200ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-chevron-icon-2 {
    display: block;
    width: 100%;
    height: 100%;
    line-height: 0
  }
  .w-item-content-3 {
    overflow-x: hidden;
    overflow-y: hidden;
    font-size: 0.875rem;
    line-height: 1.25rem;
    transition-property: all;
    transition-duration: 150ms;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-delay: 0s;
    transition-behavior: normal
  }
  .w-item-content-3[data-state="closed"] {
    height: 0
  }
  .w-item-content-3[data-state="open"] {
    height: var(--radix-accordion-content-height)
  }
}
      `}
        </style>
        <Component />
      </>
    );
  },
};

export { Story as Accordion };
