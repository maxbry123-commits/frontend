/**
 * Implementation of the "Select Button" component from:
 * https://www.figma.com/file/sfCE7iLS0k25qCxiifQNLE/%F0%9F%93%9A-Webstudio-Library?node-id=4-3263
 *
 * Primarily intended to be used as Trigger in <Select>.
 * Implemented separately in case we'll need it as a trigger for something else.
 */

import {
  forwardRef,
  type Ref,
  type ComponentProps,
  type ReactNode,
} from "react";
import { textVariants } from "./text";
import { theme, css, type CSS } from "../stitches.config";
import { ChevronDownIcon } from "@webstudio-is/icons";
import { cssVar, declareCssVar } from "../css-var";

const chevronColor = declareCssVar("--select-button-chevron-color");
const chevronStyle = css({ color: cssVar(chevronColor) });

const style = css({
  all: "unset", // reset <button>
  minWidth: 0,
  height: theme.sizes.controlHeight,
  boxSizing: "border-box",
  display: "flex",
  alignItems: "center",
  background: cssVar("--background-secondary"),
  border: `1px solid transparent`,
  borderRadius: theme.borderRadius[4],
  paddingRight: theme.spacing[1],
  paddingLeft: theme.spacing[1],
  color: cssVar("--foreground-primary"),
  [chevronColor]: cssVar("--foreground-secondary"),
  "&:hover": {
    borderColor: cssVar("--border-default"),
  },
  "&[data-placeholder]:not([data-state=open], :hover, :disabled)": {
    color: cssVar("--foreground-secondary"),
  },
  "&:hover:not(:disabled), &[data-state=open]": {
    [chevronColor]: cssVar("--foreground-primary"),
  },
  "&:disabled": {
    background: cssVar("--background-disabled"),
    color: cssVar("--foreground-disabled"),
    [chevronColor]: cssVar("--border-default"),
  },
  "&:focus-visible": {
    borderColor: cssVar("--border-focus"),
  },
  variants: {
    fullWidth: { true: { width: "100%" } },
    color: {
      ghost: {
        background: "transparent",
        "&:hover": {
          borderColor: "transparent",
          background: cssVar("--overlay-interaction-hover"),
        },
      },
    },
  },
});

const textStyle = css(textVariants.regular, {
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  flex: 1,
  paddingRight: theme.spacing[2],
  paddingLeft: theme.spacing[3],
});

type Props = Omit<ComponentProps<"button">, "prefix" | "color"> & {
  fullWidth?: boolean;
  color?: "ghost";
  css?: CSS;
  prefix?: ReactNode; // primarily for <NestedIconLabel>
};

export const SelectButton = forwardRef(
  (
    { prefix, children, css, className, fullWidth, color, ...rest }: Props,
    ref: Ref<HTMLButtonElement>
  ) => (
    <button
      {...rest}
      className={style({ css, className, fullWidth, color })}
      ref={ref}
    >
      {prefix}
      <span className={textStyle()}>{children}</span>
      <ChevronDownIcon className={chevronStyle()} />
    </button>
  )
);
SelectButton.displayName = "SelectButton";
