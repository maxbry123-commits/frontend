import fs from 'fs'
import { Page } from '@playwright/test'
import { DB } from '@tldraw/dotcom-shared'
import { Kysely, PostgresDialect, sql } from 'kysely'
import pg from 'pg'
import { OTHER_USERS, USERS } from '../consts'
import { getStorageStateFileName } from './helpers'

const db = new Kysely<DB>({
	dialect: new PostgresDialect({
		pool: new pg.Pool({
			connectionString: 'postgresql://user:password@127.0.0.1:6432/postgres',
			application_name: 'migrate',
			idleTimeoutMillis: 10_000,
			max: 10,
		}),
	}),
	log: ['error'],
})

export class Database {
	constructor(
		readonly page: Page | null,
		private parallelIndex: number
	) {}

	async reset() {
		await this.cleanUpUser(true)
		await this.cleanUpUser(false)
	}

	getEmail(isOther: boolean = false) {
		return getTestUserEmail(this.parallelIndex, isOther ? 'suppy' : 'huppy')
	}

	async getUserId(isOther: boolean = false) {
		return await this.getUserIdByEmail(this.getEmail(isOther))
	}

	async getUserIdByEmail(email: string) {
		const dbUser = await sql<{
			id: string
		}>`SELECT id FROM public.user WHERE email = ${email ?? ''}`.execute(db)
		if (!dbUser.rows[0]) return
		return dbUser.rows[0].id
	}

	private async cleanUpUser(isOther: boolean) {
		const fileName = getStorageStateFileName(this.parallelIndex, isOther ? 'suppy' : 'huppy')
		if (!fs.existsSync(fileName)) return
		const id = await this.getUserId(isOther)
		if (!id) return
		try {
			// eslint-disable-next-line no-restricted-globals
			await fetch(`http://localhost:3000/api/app/__test__/user/${id}/prepare-for-test`, {
				method: 'POST',
			})
		} catch (e) {
			console.error('Error', e)
		}
	}
}

export type TestUser = 'huppy' | 'suppy'

export function getTestUserEmail(index: number, user: TestUser) {
	return user === 'suppy' ? OTHER_USERS[index] : USERS[index]
}
