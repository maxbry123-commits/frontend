import { CommentTool, commentToolOverrides } from '@tldraw/commenting'
import { TLCustomServerEvent, getLicenseKey } from '@tldraw/dotcom-shared'
import { useSync } from '@tldraw/sync'
import { useCallback, useEffect, useMemo, useRef } from 'react'
import {
	DefaultDebugMenu,
	DefaultDebugMenuContent,
	Editor,
	TLComponents,
	TLSessionStateSnapshot,
	TLUiDialogsContextType,
	TLUserStore,
	Tldraw,
	TldrawUiMenuItem,
	UserRecordType,
	commentSchemaRecords,
	computed,
	createSessionStateSnapshotSignal,
	createUserId,
	parseDeepLinkString,
	react,
	throttle,
	tltime,
	useAtom,
	useDialogs,
	useEditor,
	useEvent,
	useValue,
} from 'tldraw'
import { SneakyMermaidHandler } from '../../../components/SneakyMermaidHandler/SneakyMermaidHandler'
import { ThemeUpdater } from '../../../components/ThemeUpdater/ThemeUpdater'
import { useOpenUrlAndTrack } from '../../../hooks/useOpenUrlAndTrack'
import { usePerformanceTracking } from '../../../hooks/usePerformanceTracking'
import { useRoomLoadTracking } from '../../../hooks/useRoomLoadTracking'
import { trackEvent, useHandleUiEvents } from '../../../utils/analytics'
import { assetUrls } from '../../../utils/assetUrls'
import { CLIENT_BUILD_TIMESTAMP, MULTIPLAYER_SERVER } from '../../../utils/config'
import { createAssetFromUrl } from '../../../utils/createAssetFromUrl'
import { embedShapeUtils } from '../../../utils/embedShapeUtil'
import { globalEditor } from '../../../utils/globalEditor'
import { multiplayerAssetStore } from '../../../utils/multiplayerAssetStore'
import { TldrawApp } from '../../app/TldrawApp'
import { useMaybeApp } from '../../hooks/useAppState'
import { useIsCommentingEnabled } from '../../hooks/useIsCommentingEnabled'
import { ReadyWrapper, useSetIsReady } from '../../hooks/useIsReady'
import { useNewRoomCreationTracking } from '../../hooks/useNewRoomCreationTracking'
import { useTldrawCurrentUser } from '../../hooks/useUser'
import { maybeSlurp } from '../../utils/slurping'
import { TlaAnonDotDevLink } from '../TlaAnonDotDevLink/TlaAnonDotDevLink'
import { CommentsOnCanvas, SignInToComment, useAnonCommentToolOverrides } from './CommentsOnCanvas'
import { TlaEditorErrorFallback } from './editor-components/TlaEditorErrorFallback'
import { TlaEditorMenuPanel } from './editor-components/TlaEditorMenuPanel'
import { TlaEditorSharePanel } from './editor-components/TlaEditorSharePanel'
import { TlaEditorTopPanel } from './editor-components/TlaEditorTopPanel'
import { SneakyCommentDeepLink } from './sneaky/SneakyCommentDeepLink'
import { SneakyDarkModeSync } from './sneaky/SneakyDarkModeSync'
import { SneakyDebugModeToast } from './sneaky/SneakyDebugModeToast'
import { SneakyTldrawFileDropHandler } from './sneaky/SneakyFileDropHandler'
import { SneakyLargeFileHander } from './sneaky/SneakyLargeFileHandler'
import { SneakySetDocumentTitle } from './sneaky/SneakySetDocumentTitle'
import { SneakyToolSwitcher } from './sneaky/SneakyToolSwitcher'
import { A11yAudit } from './TlaDebug'
import { TlaEditorWrapper } from './TlaEditorWrapper'
import { useExtraDragIconOverrides } from './useExtraToolDragIcons'
import { useFileEditorOverrides } from './useFileEditorOverrides'

// Composing needs a signed-in author and an editable canvas. Signed-out visitors on an
// editable canvas get a sign-in prompt where the composers would be; view-only sessions
// read threads without composers (the server rejects their writes in the authorizers).
const tlaCommentTools = [
	CommentTool.configure({
		canComment: ({ editor, currentUserId }) => currentUserId !== null && !editor.getIsReadonly(),
		components: { ComposerFallback: SignInToComment },
	}),
]

/** @internal */
export const components: TLComponents = {
	ErrorFallback: TlaEditorErrorFallback,
	MenuPanel: TlaEditorMenuPanel,
	TopPanel: TlaEditorTopPanel,
	SharePanel: TlaEditorSharePanel,
	Dialogs: null,
	Toasts: null,
	// No loading screen on tla editors: the editor only mounts once it's ready,
	// so a spinner would only flash before the content appears.
	LoadingScreen: null,
}

interface TlaEditorProps {
	fileSlug: string
	isEmbed?: boolean
	deepLinks?: boolean
}

export function TlaEditor(props: TlaEditorProps) {
	// force re-mount when the file slug changes to prevent state from leaking between files
	return (
		<>
			<SneakySetDocumentTitle />
			<ReadyWrapper key={props.fileSlug}>
				<TlaEditorInner {...props} key={props.fileSlug} />
			</ReadyWrapper>
		</>
	)
}

function TlaEditorInner({ fileSlug, deepLinks }: TlaEditorProps) {
	const handleUiEvent = useHandleUiEvents()
	const app = useMaybeApp()

	const fileId = fileSlug

	const setIsReady = useSetIsReady()

	const dialogs = useDialogs()
	// need to wrap this in a useEvent to prevent the context id from changing on us
	const addDialog: TLUiDialogsContextType['addDialog'] = useEvent((dialog) =>
		dialogs.addDialog(dialog)
	)

	// We cycle this flag to cause shapes to remount when slurping images/videos fails.
	// Because in that case we want to show the failure state for the images/videos.
	// i.e. where it appears that they are not present. so the user knows which ones failed.
	// There's probably a better way of doing this but I couldn't think of one.
	const hideAllShapes = useAtom('hideAllShapes', false)
	const getShapeVisibility = useCallback(
		() => (hideAllShapes.get() ? 'hidden' : 'inherit'),
		[hideAllShapes]
	)
	const remountImageShapes = useCallback(() => {
		hideAllShapes.set(true)
		requestAnimationFrame(() => {
			hideAllShapes.set(false)
		})
	}, [hideAllShapes])

	const trackRoomLoaded = useRoomLoadTracking()
	const trackNewRoomCreation = useNewRoomCreationTracking()
	const trackPerformance = usePerformanceTracking()

	const handleMount = useCallback(
		(editor: Editor) => {
			trackRoomLoaded(editor)
			trackNewRoomCreation(app, fileId)
			const cleanupPerf = trackPerformance(editor)
			;(window as any).app = app
			;(window as any).editor = editor
			// Register the editor globally
			globalEditor.set(editor)

			// Register the external asset handler
			editor.registerExternalAssetHandler('url', createAssetFromUrl)

			if (!app) {
				setIsReady()
				return
			}

			const fileState = app.getFileState(fileId)
			const deepLink = new URLSearchParams(window.location.search).get('d')
			if (fileState?.lastSessionState) {
				const sessionState = JSON.parse(fileState.lastSessionState.trim() || 'null')
				if (sessionState && deepLink) {
					// When using a deep link, only load preferences (not camera/page states)
					// since the deep link will control navigation
					const { pageStates: _, currentPageId: _cpid, ...preferencesOnly } = sessionState
					editor.loadSnapshot({ session: preferencesOnly }, { forceOverwriteSessionState: true })
					editor.navigateToDeepLink(parseDeepLinkString(deepLink))
				} else if (sessionState) {
					// No deep link - load the full session state including camera position
					editor.loadSnapshot({ session: sessionState }, { forceOverwriteSessionState: true })
				} else if (deepLink) {
					editor.navigateToDeepLink(parseDeepLinkString(deepLink))
				}
			} else if (deepLink) {
				editor.navigateToDeepLink(parseDeepLinkString(deepLink))
			}
			const fileStateUpdater = new FileStateUpdater(app, fileId, editor)

			const abortController = new AbortController()
			maybeSlurp({
				app,
				editor,
				fileId,
				abortSignal: abortController.signal,
				addDialog,
				remountImageShapes,
			}).then(setIsReady)

			return () => {
				cleanupPerf()
				fileStateUpdater.dispose()
				abortController.abort()
			}
		},
		[
			addDialog,
			trackRoomLoaded,
			trackNewRoomCreation,
			trackPerformance,
			app,
			fileId,
			remountImageShapes,
			setIsReady,
		]
	)

	const user = useTldrawCurrentUser()
	const getUserToken = useEvent(async () => {
		return (await user?.getToken()) ?? 'not-logged-in'
	})
	const hasUser = !!user
	const assets = useMemo(() => {
		return multiplayerAssetStore({ getFileId: () => fileId, getToken: getUserToken })
	}, [fileId, getUserToken])

	const users: TLUserStore | undefined = useMemo(() => {
		const prefs = app?.tlUser.userPreferences
		if (!prefs) return undefined
		const currentUser = computed('currentUser', () => {
			const p = prefs.get()
			return UserRecordType.create({
				id: createUserId(p.id),
				name: p.name ?? '',
				color: p.color ?? '',
			})
		})
		return {
			currentUser,
		}
	}, [app?.tlUser.userPreferences])

	const store = useSync({
		uri: useCallback(async () => {
			const url = new URL(`${MULTIPLAYER_SERVER}/app/file/${fileSlug}`)
			url.searchParams.set('v', CLIENT_BUILD_TIMESTAMP)
			if (hasUser) {
				url.searchParams.set('accessToken', await getUserToken())
			}
			return url.toString()
		}, [fileSlug, hasUser, getUserToken]),
		assets,
		users,
		// Register the opt-in `comment` record type so comment records sync through the file room.
		// Must match the server schema (see fileSyncSchema in TLFileDurableObject).
		records: commentSchemaRecords,
		onCustomMessageReceived: useCallback((message: TLCustomServerEvent) => {
			trackEvent(message.type)
		}, []),
	})

	// we need to prevent calling onFileExit if the store is in an error state
	const storeError = useRef(false)
	if (store.status === 'error') {
		storeError.current = true
	}

	// Handle entering and exiting the file, with some protection against rapid enters/exits
	useEffect(() => {
		if (!app) return
		if (store.status !== 'synced-remote') return
		let didEnter = false
		let timer: number

		const fileState = app.getFileState(fileId)

		if (fileState && fileState.firstVisitAt) {
			// If there's a file state already then wait a second before marking it as entered
			timer = tltime.setTimeout(
				'file enter timer',
				() => {
					app.onFileEnter(fileId)
					didEnter = true
				},
				1000
			)
		} else {
			// If there's not a file state yet (i.e. if we're visiting this for the first time) then do an enter
			app.onFileEnter(fileId)
			didEnter = true
		}

		return () => {
			clearTimeout(timer)
			if (didEnter && !storeError.current) {
				app.updateFileState(fileId, { lastVisitAt: Date.now() })
			}
		}
	}, [app, fileId, store.status])

	const overrides = useFileEditorOverrides({ fileSlug })
	const extraDragIconOverrides = useExtraDragIconOverrides()
	const anonCommentToolOverrides = useAnonCommentToolOverrides()
	const commentingEnabled = useIsCommentingEnabled()

	const instanceComponents = useMemo((): TLComponents => {
		return {
			...components,
			DebugMenu: () => <CustomDebugMenu />,
			InFrontOfTheCanvas: commentingEnabled
				? () => <CommentsOnCanvas fileId={fileId} />
				: undefined,
		}
	}, [fileId, commentingEnabled])

	// Without the tool and its overrides there's no comment button in Quick Actions and no `c`
	// shortcut, so commenting is fully absent for users the flag doesn't cover. On read-only
	// canvases the button and shortcut hide via the UI's readonly handling, and composing is
	// gated by the tool's `canComment`.
	const editorOverrides = useMemo(
		() =>
			commentingEnabled
				? [overrides, extraDragIconOverrides, commentToolOverrides, anonCommentToolOverrides]
				: [overrides, extraDragIconOverrides],
		[commentingEnabled, overrides, extraDragIconOverrides, anonCommentToolOverrides]
	)

	return (
		<TlaEditorWrapper>
			<Tldraw
				className="tla-editor"
				licenseKey={getLicenseKey()}
				store={store}
				assetUrls={assetUrls}
				shapeUtils={embedShapeUtils}
				tools={commentingEnabled ? tlaCommentTools : undefined}
				user={app?.tlUser}
				onMount={handleMount}
				onUiEvent={handleUiEvent}
				components={instanceComponents}
				options={{
					actionShortcutsLocation: 'toolbar',
					deepLinks: deepLinks ? true : undefined,
				}}
				overrides={editorOverrides}
				getShapeVisibility={getShapeVisibility}
			>
				<ThemeUpdater />
				<SneakyDarkModeSync />
				<SneakyToolSwitcher />
				<SneakyMermaidHandler />
				{app && <SneakyTldrawFileDropHandler />}
				<SneakyLargeFileHander />
				<SneakyDebugModeToast />
				{commentingEnabled && <SneakyCommentDeepLink />}
				<TlaAnonDotDevLink />
			</Tldraw>
		</TlaEditorWrapper>
	)
}

function CustomDebugMenu() {
	const app = useMaybeApp()
	const user = useTldrawCurrentUser()
	const openAndTrack = useOpenUrlAndTrack('unknown')
	const editor = useEditor()
	const isReadOnly = useValue('isReadOnly', () => editor.getIsReadonly(), [editor])
	return (
		<DefaultDebugMenu>
			<A11yAudit />
			{!isReadOnly && app && user?.isTldraw && (
				<TldrawUiMenuItem
					id="user-manual"
					label="File history"
					readonlyOk
					onSelect={() => {
						const url = new URL(window.location.href)
						url.pathname += '/history'
						openAndTrack(url.toString())
					}}
				/>
			)}
			<DefaultDebugMenuContent />
		</DefaultDebugMenu>
	)
}

const FILE_STATE_UPDATE_INTERVAL = 10_000
class FileStateUpdater {
	disposables = new Set<() => void>()
	constructor(
		private readonly app: TldrawApp,
		private readonly fileId: string,
		editor: Editor
	) {
		this.disposables.add(
			editor.store.listen(
				() => {
					this.didDocumentChange = true
					this.update()
				},
				{ scope: 'document', source: 'user' }
			)
		)
		const flush = () => {
			this.update.flush()
		}
		window.addEventListener('beforeunload', flush)
		this.disposables.add(() => {
			window.removeEventListener('beforeunload', flush)
		})

		const sessionState$ = createSessionStateSnapshotSignal(editor.store)
		let firstTime = true
		this.disposables.add(
			react('update session state', () => {
				const state = sessionState$.get()
				if (firstTime) {
					firstTime = false
					return
				}
				if (!state) return
				this.nextSessionState = state
				this.update()
			})
		)
	}

	private nextSessionState: TLSessionStateSnapshot | null = null
	private didDocumentChange = false

	private update = throttle(
		() => {
			if (!this.nextSessionState && !this.didDocumentChange) return
			const state = this.nextSessionState
			this.nextSessionState = null
			const didChange = this.didDocumentChange
			this.didDocumentChange = false
			this.app.updateFileState(this.fileId, {
				lastSessionState: state ? JSON.stringify(state) : undefined,
				lastEditAt: didChange ? Date.now() : undefined,
				lastVisitAt: Date.now(),
			})
		},
		FILE_STATE_UPDATE_INTERVAL,
		{ trailing: true, leading: false }
	)

	dispose() {
		this.update.flush()
		this.disposables.forEach((dispose) => dispose())
		this.disposables.clear()
	}
}
