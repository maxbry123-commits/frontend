import { EvaluatedFeatureFlag, FeatureFlagKey } from '@tldraw/dotcom-shared'
import { useEffect } from 'react'
import { fetch } from 'tldraw'

export type FeatureFlags = Record<FeatureFlagKey, EvaluatedFeatureFlag>

export const DEFAULT_FLAGS: FeatureFlags = {
	rum_enabled: { enabled: false },
	commenting_enabled: { enabled: false },
	// Nothing in the client reads this one — it gates the MCP server, which is enforced worker-side
	// for callers that are not this app. It rides along because the flags endpoint returns every flag;
	// a client-side check would not be a check at all, since the callers are Claude and ChatGPT.
	mcp_server_access: { enabled: false },
}

let currentFlags: FeatureFlags = { ...DEFAULT_FLAGS }
let flagsPromise: Promise<FeatureFlags> | null = null
let _wasAuthenticated = false
let _hasResolvedOnce = false

export function fetchFeatureFlags(): Promise<FeatureFlags> {
	if (!flagsPromise) {
		flagsPromise = (async () => {
			try {
				const r = await fetch('/api/app/feature-flags')
				if (!r.ok) throw new Error(`HTTP ${r.status}`)
				_wasAuthenticated = r.headers.get('x-authenticated') === '1'
				if (!_wasAuthenticated) {
					// Allow subsequent callers to refetch once auth is available
					flagsPromise = null
				}
				const flags = (await r.json()) as FeatureFlags
				currentFlags = flags
				_hasResolvedOnce = true
				return flags
			} catch (err) {
				console.error('[FeatureFlags] fetch failed:', err)
				flagsPromise = null
				_wasAuthenticated = false
				currentFlags = { ...DEFAULT_FLAGS }
				_hasResolvedOnce = true
				return { ...DEFAULT_FLAGS }
			}
		})()
	}
	return flagsPromise
}

export function wasAuthenticated(): boolean {
	return _wasAuthenticated
}

export function getCurrentFlags(): FeatureFlags {
	return currentFlags
}

/**
 * Whether the feature flag fetch has settled at least once (either
 * successfully or by falling back to defaults). Used by the A/B hook to
 * decide whether the values returned by `getCurrentFlags()` are meaningful
 * yet, or whether we should wait.
 */
export function hasResolvedFlagsOnce(): boolean {
	return _hasResolvedOnce
}

// Start fetching immediately — fast path for returning users with valid cookies.
// If the session cookie is missing/expired the response header indicates the flags
// were evaluated without auth, and useAppState will retry once Clerk is ready.
fetchFeatureFlags()

const REFETCH_INTERVAL = 60000 // 1 minute

/**
 * Polls for feature flag changes after the initial fetch, so changes
 * (e.g., rum_enabled) take effect without a reload.
 */
export function FeatureFlagPoller() {
	useEffect(() => {
		let mounted = true

		async function pollFlags() {
			try {
				const response = await fetch('/api/app/feature-flags')
				if (!response.ok) return
				const data = (await response.json()) as FeatureFlags
				if (!mounted) return
				currentFlags = data
			} catch (err) {
				console.warn('[FeatureFlags] poll error:', err)
			}
		}

		let interval: ReturnType<typeof setInterval>

		fetchFeatureFlags().then(() => {
			if (!mounted) return
			interval = setInterval(pollFlags, REFETCH_INTERVAL)
		})

		return () => {
			mounted = false
			clearInterval(interval)
		}
	}, [])

	return null
}
