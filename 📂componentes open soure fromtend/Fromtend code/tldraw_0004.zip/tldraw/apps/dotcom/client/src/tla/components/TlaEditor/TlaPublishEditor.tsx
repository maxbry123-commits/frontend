import { getLicenseKey } from '@tldraw/dotcom-shared'
import { useMemo } from 'react'
import { SerializedSchema, TLComponents, TLRecord, Tldraw } from 'tldraw'
import { ThemeUpdater } from '../../../components/ThemeUpdater/ThemeUpdater'
import { useLegacyUrlParams } from '../../../hooks/useLegacyUrlParams'
import { usePerformanceTracking } from '../../../hooks/usePerformanceTracking'
import { useHandleUiEvents } from '../../../utils/analytics'
import { assetUrls } from '../../../utils/assetUrls'
import { embedShapeUtils } from '../../../utils/embedShapeUtil'
import { globalEditor } from '../../../utils/globalEditor'
import { TlaEditorErrorFallback } from './editor-components/TlaEditorErrorFallback'
import { TlaEditorPublishedSharePanel } from './editor-components/TlaEditorPublishedSharePanel'
import { SneakyDarkModeSync } from './sneaky/SneakyDarkModeSync'
import { TlaEditorTopLeftPanel } from './TlaEditorTopLeftPanel'
import { useFileEditorOverrides } from './useFileEditorOverrides'
import styles from './editor.module.css'

const components: TLComponents = {
	ErrorFallback: TlaEditorErrorFallback,
	SharePanel: TlaEditorPublishedSharePanel,
	MenuPanel: () => <TlaEditorTopLeftPanel isAnonUser={true} />,
}

interface TlaPublishEditorProps {
	schema: SerializedSchema
	records: TLRecord[]
}

export function TlaPublishEditor({ schema, records }: TlaPublishEditorProps) {
	// make sure this runs before the editor is instantiated
	useLegacyUrlParams()

	const handleUiEvent = useHandleUiEvents()
	const trackPerformance = usePerformanceTracking()
	const fileEditorOverrides = useFileEditorOverrides({
		fileSlug: undefined,
	})

	const snapshot = useMemo(
		() => ({
			schema,
			store: Object.fromEntries(records.map((record) => [record.id, record])),
		}),
		[schema, records]
	)

	return (
		<div className={styles.editor} data-testid="tla-editor">
			<Tldraw
				licenseKey={getLicenseKey()}
				assetUrls={assetUrls}
				shapeUtils={embedShapeUtils}
				snapshot={snapshot}
				overrides={[fileEditorOverrides]}
				onUiEvent={handleUiEvent}
				onMount={(editor) => {
					;(window as any).app = editor
					;(window as any).editor = editor
					editor.updateInstanceState({ isReadonly: true })
					globalEditor.set(editor)
					return trackPerformance(editor)
				}}
				components={components}
				options={{ deepLinks: true }}
			>
				<ThemeUpdater />
				<SneakyDarkModeSync />
			</Tldraw>
		</div>
	)
}
