import { Role, TlaFile, TlaUser } from '@tldraw/dotcom-shared'
import { createContext, useContext } from 'react'
import { trackEvent } from '../../utils/analytics'
import { TldrawAppSessionState } from './local-session-state'

/** @public */
export type TLAppUiEventSource =
	| 'sidebar'
	| 'sidebar-context-menu'
	| 'user-preferences'
	| 'file-rename-dialog'
	| 'file-menu'
	| 'file-share-menu'
	| 'file-header'
	| 'anon-landing-page'
	| 'anon-top-bar'
	| 'comments'
	| 'account-menu'
	| 'top-bar'
	| 'legacy-import-button'
	| 'file-drop'
	| 'import-url'
	| 'new-page'
	| 'app'
	| 'cookie-settings'
	| 'dialog'
	| 'workspace-settings'

/** @public */
export interface TLAppUiEventMap {
	'create-file': null
	'create-workspace': null
	'rename-workspace': null
	'delete-workspace': null
	'leave-workspace': null
	'remove-workspace-member': null
	'set-workspace-member-role': { role: Role }
	'set-workspace-invite-link-enabled': { enabled: boolean }
	'regenerate-workspace-invite-secret': null
	'delete-file': null
	'rename-file': { name: string }
	'duplicate-file': null
	'download-file': null
	'drop-tldr-file': null
	'import-tldr-file': null
	'change-user-name': null
	'open-share-menu': null
	'change-share-menu-tab': { tab: TldrawAppSessionState['shareMenuActiveTab'] }
	'copy-share-link': null
	'copy-file-link': null
	'toggle-shared': { shared: boolean }
	'set-theme': { theme: 'dark' | 'light' | 'auto' }
	'toggle-export-padding': { padding: boolean }
	'toggle-export-background': { background: TlaUser['exportBackground'] }
	'set-export-format': { format: TlaUser['exportFormat'] }
	'set-export-theme': { theme: TlaUser['exportTheme'] }
	'export-image': {
		fullPage: boolean
		theme: TlaUser['exportTheme']
		format: TlaUser['exportFormat']
		padding: TlaUser['exportPadding']
		background: TlaUser['exportBackground']
	}
	'set-shared-link-type': { type: TlaFile['sharedLinkType'] | 'no-access' }
	'open-url': { destinationUrl: string }
	'publish-file': null
	'unpublish-file': null
	'copy-publish-link': null
	'sign-up-clicked': { ctaMessage: string }
	'sign-out-clicked': null
	'learn-more-button': null
	'sidebar-toggle': { value: boolean }
	'click-file-link': null
	'open-preview-sign-up-modal': null
	'create-user': null
	'room-size-warning-dialog-shown': null
	'room-size-limit-dialog-shown': null
	'accept-workspace-invite': null
	'set-color-theme': { theme: string }
	'post-comment': { operation: 'new-thread' | 'reply' }
	'edit-comment': null
	'delete-comment': null
	'delete-comment-thread': null
	'resolve-comment-thread': { operation: 'resolve' | 'reopen' }
	'react-to-comment': { operation: 'add' | 'remove' }
	'open-comment-thread': null
	'toggle-comments-sidebar': { open: boolean }
	'toggle-comments-visibility': { hidden: boolean }
	'set-comments-filter': {
		filter: 'onlyCurrentPage' | 'onlyMine' | 'onlyUnread' | 'showResolved'
		value: boolean
	}
}

/** @public */
export type TLAppUiHandler = <T extends keyof TLAppUiEventMap>(
	name: T,
	data: { source: TLAppUiEventSource } & (TLAppUiEventMap[T] extends null
		? object
		: TLAppUiEventMap[T])
) => void

/** @public */
export type TLAppUiContextType = TLAppUiHandler

/** @internal */
const defaultEventHandler: TLAppUiContextType = trackEvent

/** @internal */
export const EventsContext = createContext<TLAppUiContextType>(defaultEventHandler)

/** @public */
export function useTldrawAppUiEvents(): TLAppUiContextType {
	const eventHandler = useContext(EventsContext)
	return eventHandler
}
