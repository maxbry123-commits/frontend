import { variablesPlugin } from './variables.js'
import { setupStyleManager } from './style-manager.js'
import { registerCommands, registerCapabilities } from './capabilities.js'
import en from './locale/en.js'
import fr from './locale/fr.js'

export default (editor, opts = {}) => {
  const options = {
    // Which variable types to enable
    enableColors: true,
    enableSizes: true,
    enableTypography: true,
    // Pre-defined variables for first load
    presets: [],
    // i18n overrides
    i18n: {},
    ...opts,
  }

  editor.I18n && editor.I18n.addMessages({
    en,
    fr,
    ...options.i18n,
  })

  variablesPlugin(editor, options)
  setupStyleManager(editor, options)
  registerCommands(editor)

  // Register AI capabilities if grapesjs-ai-capabilities is loaded
  editor.on('ai-capabilities:ready', (addCapability) => {
    registerCapabilities(addCapability)
  })
}

export { cmdOpenVariables } from './variables.js'
export { cmdListVars, cmdSetVar, cmdRemoveVar, cmdRenameVar } from './capabilities.js'
