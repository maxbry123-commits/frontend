import { useRef } from "react";
import { computed } from "nanostores";
import { useStore } from "@nanostores/react";
import type { Instance } from "@webstudio-is/sdk";
import {
  theme,
  PanelTabs,
  PanelTabsList,
  PanelTabsTrigger,
  PanelTabsContent,
  Card,
  Text,
  EnhancedTooltipProvider,
  Flex,
  ScrollArea,
  Separator,
  Tooltip,
  Kbd,
} from "@webstudio-is/design-system";
import { ModeMenu, StylePanel } from "~/builder/features/style-panel";
import { SettingsPanel } from "~/builder/features/settings-panel";
import {
  $registeredComponentMetas,
  $dragAndDropState,
  $isDesignMode,
} from "~/shared/nano-states";
import { NavigatorTree } from "~/builder/features/navigator";
import type { Settings } from "~/builder/shared/client-settings";
import { $activeInspectorPanel } from "~/builder/shared/nano-states";
import {
  $allSelectedInstanceSelectors,
  $selectedInstance,
  $selectedInstanceKey,
  $selectedPage,
} from "~/shared/nano-states";
import { InstanceIcon, getInstanceLabel } from "./shared/instance-label";

const InstanceInfo = ({ instance }: { instance: Instance }) => {
  return (
    <Flex gap="1" align="center">
      <Flex shrink={false}>
        <InstanceIcon instance={instance} />
      </Flex>
      <Text truncate variant="labels">
        {getInstanceLabel(instance)}
      </Text>
    </Flex>
  );
};

type InspectorProps = {
  navigatorLayout: Settings["navigatorLayout"];
};

const contentStyle = {
  display: "flex",
  flexDirection: "column",
  overflow: "auto",
};

const $isDragging = computed([$dragAndDropState], (state) => state.isDragging);

const getInspectorEmptyStateMessage = (selectedInstanceCount: number) =>
  selectedInstanceCount > 1
    ? "Multiple instances selected"
    : "Select an instance on the canvas";

export const Inspector = ({ navigatorLayout }: InspectorProps) => {
  const selectedInstance = useStore($selectedInstance);
  const selectedInstanceKey = useStore($selectedInstanceKey);
  const selectedInstanceSelectors = useStore($allSelectedInstanceSelectors);
  const tabsRef = useRef<HTMLDivElement>(null);
  const isDragging = useStore($isDragging);
  const metas = useStore($registeredComponentMetas);
  const selectedPage = useStore($selectedPage);
  const activeInspectorPanel = useStore($activeInspectorPanel);
  const isDesignMode = useStore($isDesignMode);

  if (navigatorLayout === "docked" && isDragging) {
    return <NavigatorTree />;
  }

  if (selectedInstance === undefined || selectedInstanceKey === undefined) {
    return (
      <Flex css={{ p: theme.spacing[9] }}>
        {/* @todo: use this space for something more usefull: a-la figma's no instance selected sate, maybe create an issue with a more specific proposal? */}
        <Card css={{ p: theme.spacing[9], width: "100%" }}>
          <Text>
            {getInspectorEmptyStateMessage(selectedInstanceSelectors.length)}
          </Text>
        </Card>
      </Flex>
    );
  }

  const meta = metas.get(selectedInstance.component);
  const documentType = selectedPage?.meta.documentType ?? "html";

  type PanelName = "style" | "settings";

  const availablePanels = new Set<PanelName>();
  availablePanels.add("settings");
  if (
    // forbid styling body in xml document
    documentType === "html" &&
    // forbid styling components without preset
    meta?.presetStyle !== undefined &&
    isDesignMode
  ) {
    availablePanels.add("style");
  }

  return (
    <EnhancedTooltipProvider
      delayDuration={1200}
      disableHoverableContent={false}
      skipDelayDuration={0}
    >
      <PanelTabs
        ref={tabsRef}
        data-floating-panel-container
        value={
          availablePanels.has(activeInspectorPanel)
            ? activeInspectorPanel
            : Array.from(availablePanels)[0]
        }
        onValueChange={(panel) => {
          $activeInspectorPanel.set(panel as PanelName);
        }}
        asChild
      >
        <Flex direction="column">
          <PanelTabsList>
            {availablePanels.has("style") && (
              <Tooltip
                variant="wrapped"
                content={
                  <Text>
                    CSS for the selected instance&nbsp;&nbsp;
                    <Kbd value={["S"]} color="moreSubtle" />
                  </Text>
                }
              >
                <div>
                  <PanelTabsTrigger value="style">Style</PanelTabsTrigger>
                </div>
              </Tooltip>
            )}
            {availablePanels.has("settings") && (
              <Tooltip
                variant="wrapped"
                content={
                  <Text>
                    Settings, properties and attributes of the selected
                    instance&nbsp;&nbsp;
                    <Kbd value={["D"]} color="moreSubtle" />
                  </Text>
                }
              >
                <div>
                  <PanelTabsTrigger value="settings">Settings</PanelTabsTrigger>
                </div>
              </Tooltip>
            )}
          </PanelTabsList>
          <Separator />
          <PanelTabsContent value="style" css={contentStyle} tabIndex={-1}>
            <Flex
              justify="between"
              align="center"
              shrink={false}
              css={{
                paddingInline: theme.panel.paddingInline,
                height: theme.spacing[13],
              }}
            >
              <InstanceInfo instance={selectedInstance} />
              <ModeMenu />
            </Flex>
            <StylePanel />
          </PanelTabsContent>
          <PanelTabsContent value="settings" css={contentStyle} tabIndex={-1}>
            <ScrollArea>
              <Flex
                justify="between"
                align="center"
                shrink={false}
                css={{
                  paddingInline: theme.panel.paddingInline,
                  height: theme.spacing[13],
                }}
              >
                <InstanceInfo instance={selectedInstance} />
              </Flex>
              <SettingsPanel
                // Re-render when instance changes
                key={selectedInstance.id}
                selectedInstance={selectedInstance}
                selectedInstanceKey={selectedInstanceKey}
              />
            </ScrollArea>
          </PanelTabsContent>
        </Flex>
      </PanelTabs>
    </EnhancedTooltipProvider>
  );
};

export const __testing__ = {
  getInspectorEmptyStateMessage,
};
