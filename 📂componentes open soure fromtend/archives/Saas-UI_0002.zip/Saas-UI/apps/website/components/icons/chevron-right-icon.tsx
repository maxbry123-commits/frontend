import React from 'react'

export interface ChevronRightIconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string
}

/**
 * chevron-right
 * Lucide
 * @url https://icon-sets.iconify.design/lucide
 * @license ISC
 */
export const ChevronRightIcon: React.FC<ChevronRightIconProps> = ({
  size = '1em',
  ...props
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        fill="none"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="m9 18l6-6l-6-6"
      />
    </svg>
  )
}
