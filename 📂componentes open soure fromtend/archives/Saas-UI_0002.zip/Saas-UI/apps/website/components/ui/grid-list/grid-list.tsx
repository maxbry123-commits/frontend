'use client'

import type { HTMLChakraProps } from '@chakra-ui/react/styled-system'
import type { SlotRecipeProps } from '@saas-ui/chakra-preset'
import type { GridListVariantProps } from '@saas-ui/chakra-preset/slot-recipes/grid-list'
import { GridList } from '@saas-ui/react/grid-list'

import { withContext, withProvider } from './grid-list.context'

interface GridListRootProps
  extends
    HTMLChakraProps<'div'>,
    SlotRecipeProps<'suiGridList', GridListVariantProps> {}

const GridListRoot = withProvider<HTMLDivElement, GridListRootProps>(
  GridList.Root,
  'root',
)

interface GridListItemProps extends HTMLChakraProps<'div'> {
  disabled?: boolean
}

const GridListItem = withContext<HTMLDivElement, GridListItemProps>(
  GridList.Item,
  'item',
)

interface GridListHeaderProps extends HTMLChakraProps<'header'> {}

const GridListHeader = withContext<HTMLDivElement, GridListHeaderProps>(
  GridList.Header,
  'header',
)

interface GridListCellProps extends HTMLChakraProps<'div'> {}

const GridListCell = withContext<HTMLDivElement, GridListCellProps>(
  GridList.Cell,
  'cell',
)

export {
  GridListRoot as Root,
  GridListItem as Item,
  GridListHeader as Header,
  GridListCell as Cell,
}

export type {
  GridListRootProps as RootProps,
  GridListHeaderProps as HeaderProps,
  GridListItemProps as ItemProps,
  GridListCellProps as CellProps,
}
