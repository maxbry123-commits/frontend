﻿// Copyright (c) Microsoft. All rights reserved.

#pragma warning disable IDE0002 // Simplify Member Access

using Azure.AI.OpenAI;
using Azure.Identity;
using LongRunningTools;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AzureFunctions;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OpenAI.Chat;

// Get the Foundry project endpoint and model deployment name from environment variables.
string projectEndpoint = Environment.GetEnvironmentVariable("FOUNDRY_PROJECT_ENDPOINT")
    ?? throw new InvalidOperationException("FOUNDRY_PROJECT_ENDPOINT is not set.");
string deploymentName = Environment.GetEnvironmentVariable("FOUNDRY_MODEL")
    ?? throw new InvalidOperationException("FOUNDRY_MODEL is not set.");

// The Azure OpenAI endpoint is the authority (scheme + host) of the Foundry project endpoint.
string endpoint = new Uri(projectEndpoint).GetLeftPart(UriPartial.Authority);

// WARNING: DefaultAzureCredential is convenient for development but requires careful consideration in production.
// In production, consider using a specific credential (e.g., ManagedIdentityCredential) to avoid
// latency issues, unintended credential probing, and potential security risks from fallback mechanisms.
AzureOpenAIClient client = new(new Uri(endpoint), new DefaultAzureCredential());

// Agent used by the orchestration to write content.
const string WriterAgentName = "Writer";
const string WriterAgentInstructions =
    """
    You are a professional content writer who creates high-quality articles on various topics.
    You write engaging, informative, and well-structured content that follows best practices for readability and accuracy.
    """;

AIAgent writerAgent = client.GetChatClient(deploymentName).AsAIAgent(WriterAgentInstructions, WriterAgentName);

// Agent that can start content generation workflows using tools
const string PublisherAgentName = "Publisher";
const string PublisherAgentInstructions =
    """
    You are a publishing agent that can manage content generation workflows.
    You have access to tools to start, monitor, and raise events for content generation workflows.
    """;

using IHost app = FunctionsApplication
    .CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options =>
    {
        // Add the writer agent used by the orchestration
        options.AddAIAgent(writerAgent);

        // Define the agent that can start orchestrations from tool calls
        options.AddAIAgentFactory(PublisherAgentName, sp =>
        {
            // Initialize the tools to be used by the agent.
            Tools publisherTools = new(sp.GetRequiredService<ILogger<Tools>>());

            return client.GetChatClient(deploymentName).AsAIAgent(
                instructions: PublisherAgentInstructions,
                name: PublisherAgentName,
                services: sp,
                tools: [
                    AIFunctionFactory.Create(publisherTools.StartContentGenerationWorkflow),
                    AIFunctionFactory.Create(publisherTools.GetWorkflowStatusAsync),
                    AIFunctionFactory.Create(publisherTools.SubmitHumanApprovalAsync),
                ]);
        });
    })
    .Build();

app.Run();
