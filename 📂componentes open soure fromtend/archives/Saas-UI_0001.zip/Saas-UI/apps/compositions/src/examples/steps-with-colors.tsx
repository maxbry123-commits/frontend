'use client'

import { For, Group, Stack, Button } from '@chakra-ui/react'
import { Steps } from 'compositions/ui/steps'

import { colorPalettes } from '../lib/color-palettes'

export const StepsWithColors = () => {
  return (
    <Stack gap="10" width="full">
      <For each={colorPalettes}>
        {(colorPalette) => (
          <Steps.Root
            key={colorPalette}
            defaultStep={1}
            count={3}
            colorPalette={colorPalette}
          >
            <Steps.List>
              <Steps.Item index={0} title="Step 1" />
              <Steps.Item index={1} title="Step 2" />
              <Steps.Item index={2} title="Step 3" />
            </Steps.List>

            <Steps.Content index={0}>Step 1</Steps.Content>
            <Steps.Content index={1}>Step 2</Steps.Content>
            <Steps.Content index={2}>Step 3</Steps.Content>
            <Steps.CompletedContent>
              All steps are complete!
            </Steps.CompletedContent>

            <Group>
              <Steps.PrevTrigger asChild>
                <Button variant="outline" size="sm">
                  Prev
                </Button>
              </Steps.PrevTrigger>
              <Steps.NextTrigger asChild>
                <Button variant="outline" size="sm">
                  Next
                </Button>
              </Steps.NextTrigger>
            </Group>
          </Steps.Root>
        )}
      </For>
    </Stack>
  )
}
