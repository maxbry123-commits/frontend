'use client'

import { type AlertRootProps, For, Span } from '@chakra-ui/react'
import { useSlotRecipe } from '@chakra-ui/react/styled-system'
import { Alert } from 'compositions/ui/alert'

import { colorPalettes } from '../lib/color-palettes'
import { PlaygroundTable } from '../lib/playground-table'

export const AlertVariantTable = () => {
  const recipe = useSlotRecipe({ key: 'alert' })
  return (
    <PlaygroundTable>
      <thead>
        <tr>
          <td />
          <For each={recipe.variantMap.variant}>
            {(v) => <td key={v}>{v}</td>}
          </For>
        </tr>
      </thead>
      <tbody>
        <For each={colorPalettes}>
          {(c) => (
            <tr key={c}>
              <td>
                <Span fontSize="sm" color="fg.muted" minW="8ch">
                  {c}
                </Span>
              </td>
              <For each={recipe.variantMap.variant}>
                {(v) => (
                  <td key={v}>
                    <AlertDemo variant={v} colorPalette={c} />
                  </td>
                )}
              </For>
            </tr>
          )}
        </For>
      </tbody>
    </PlaygroundTable>
  )
}

const AlertDemo = (props: AlertRootProps) => {
  return (
    <Alert title="Alert Title" {...props}>
      Chakra UI v3 is the greatest
    </Alert>
  )
}
