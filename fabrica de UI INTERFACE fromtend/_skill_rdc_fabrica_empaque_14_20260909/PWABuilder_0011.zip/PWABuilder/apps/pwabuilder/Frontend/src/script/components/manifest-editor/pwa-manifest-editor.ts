import { LitElement, html } from 'lit';
import { pwaManifestEditorStyles } from "./pwa-manifest-editor.styles";
import { property, customElement, state } from 'lit/decorators.js';

import "./manifest-info-form"
import "./manifest-settings-form"
import "./manifest-platform-form"
import "./manifest-icons-form"
import "./manifest-screenshots-form"
import "./manifest-share-form"
import "./manifest-code-form"

import { ManifestInfoForm } from './manifest-info-form';
import { ManifestPlatformForm } from './manifest-platform-form';
import type WaDropdown from '@awesome.me/webawesome/dist/components/dropdown/dropdown.js';
import type WaTabGroup from '@awesome.me/webawesome/dist/components/tab-group/tab-group.js';
import type { Manifest } from "../../models/manifest";
import "./manifest-share-form";
import { prettyString } from "../../utils/prettyJson";
import '@awesome.me/webawesome/dist/components/tab/tab.js';
import '@awesome.me/webawesome/dist/components/tab-panel/tab-panel.js';
/* import { recordPWABuilderProcessStep } from '@pwabuilder/site-analyrics'; */

/**
 * @since 0.1
 * @status stable
 *
 * @property initialManifest - the initial manifest to be edited/tested.
 * @property manifestURL - used to fetch images (screenshots & icons).
 *
 * @event manifestUpdated - Emitted when any field in the manifest.
 * @event iconsUpdated - Emitted when changes are made to the icons field.
 * @event screenshotsUpdated - Emitted when changes are made to the screenshots field.
 *
 * @method resetManifest - Resets the manifest back to value of initialManifest.
 * @method downloadManifest - Writes and downloads the manifest to a file called manifest.json.
 * @method getIcons - Returns a list of the blobs all the icons.
 * @method getScreenshots - Returns a list of the blobs of all the screenshots.
 **/

@customElement('pwa-manifest-editor')
export class PWAManifestEditor extends LitElement {

    // For more information on using properties and state in lit
    // check out this link https://lit.dev/docs/components/properties/

    private _initialManifest: Manifest = {};

    set initialManifest(manifest: Manifest) {
        let oldVal = this._initialManifest;
        this._initialManifest = this.removeEmptyFields(manifest);
        this.manifest = JSON.parse(JSON.stringify(this.initialManifest));
        this.requestUpdate('initialManifest', oldVal);
    }

    @property({ type: Object }) get initialManifest() { return this._initialManifest; }
    @property({ type: String }) manifestURL: string = '';
    @property({ type: String }) baseURL: string = '';
    @property({ type: String }) startingTab: string = "info";
    @property({ type: String }) focusOn: string = "";
    @property({ type: String }) analysisId: string = "";
    @property({ type: String }) imageProxyUrl: string = "";


    @state() manifest: Manifest = {};
    @state() selectedTab: string = "info";
    @state() openTooltips: WaDropdown[] = [];

    static styles = [pwaManifestEditorStyles];

    constructor() {
        super();
    }

    async updated() {
        //console.log(await validateRequiredFields(this._initialManifest))
        (this.shadowRoot?.querySelector('wa-tab-group') as unknown as WaTabGroup).active = this.startingTab;
    }

    private removeEmptyFields(manifest: Manifest): Manifest {
        var new_manifest: Manifest = manifest;
        for (const key in manifest) {
            const value = manifest[key];
            if ((typeof value === "string" || Array.isArray(value)) && value.length === 0) {
                delete new_manifest[key];
            }
        }
        return new_manifest;
    }

    private updateManifest(e: CustomEvent) {

        let field = e.detail.field;
        let change = e.detail.change;
        let removal = e.detail.removal;

        // we want to add generated photos to the current
        // field instead of replacing them
        if (field === "screenshots" || field === "icons") {
            let cur = this.manifest[field] || [];
            change.forEach((ele: any) => {
                cur.push(ele);
            });
            change = cur;
        }

        if (removal) {
            delete this.manifest[field];
            this.manifest = { ...this.manifest };
            return;
        }

        this.manifest = { ...this.manifest, [field]: change };

        /* console.log("Manifest Successfuly Updated.")
    
        console.log(`updated manifest with new field ${field}`, this.manifest); */
    }

    public resetManifest() {
        this.manifest = JSON.parse(JSON.stringify(this.initialManifest));
        //console.log("manifest in reset fun", this.manifest);

        (this.shadowRoot!.getElementById("info-tab") as ManifestInfoForm).initMissingColors();

        (this.shadowRoot!.getElementById("platform-tab") as ManifestPlatformForm).reset();
    }

    public downloadManifest() {
        let filename = "manifest.json";
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(prettyString(this.manifest)));
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);

        let manifestDownloaded = new CustomEvent('manifestDownloaded', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(manifestDownloaded);

    }

    // Think about what this function should actually return?
    // Downloadable content?
    // The manifest field of screenshots?
    public getScreenshots() {
        return this.manifest.screenshots;
    }

    errorInTab(e: CustomEvent) {
        let tabs = this.shadowRoot!.querySelectorAll('wa-tab');
        let tab = tabs[0];

        let panel = e.detail.panel;
        let areThereErrors = e.detail.areThereErrors;

        tabs.forEach((temp: any) => {
            if (temp.panel === panel) {
                tab = temp;
            }
        });
        if (areThereErrors) {
            if (tab.childElementCount == 0) {
                tab.innerHTML = `${tab.innerHTML}<span class="error-indicator" style='color: #eb5757'>!</span>`;
            }
        } else {
            tab.innerHTML = tab.innerHTML.split("<")[0];
        }

    }

    cleanUrl(url: string): string {
        let cleanedUrl: string | undefined;

        if (url && !url.startsWith('http') && !url.startsWith('https')) {
            cleanedUrl = 'https://' + url;
        }

        if (cleanedUrl) {
            const test = this.isValidURL(cleanedUrl);

            if (test === false && !url.toLowerCase().startsWith('http://')) {
                throw new Error(
                    'This error means that you may have a bad https cert or the url may not be correct'
                );
            }

            return cleanedUrl;
        }

        // original URL is ok
        return url;
    }

    isValidURL(str: string) {
        // from https://stackoverflow.com/a/14582229 but removed the ip address section
        var pattern = new RegExp(
            '^((https?:)?\\/\\/)?' + // protocol
            '(?:\\S+(?::\\S*)?@)?(([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}' + // domain name
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
            '(\\\\#[-a-z\\\\d_]*)?', // fragment locator
            'i' // case insensitive
        );
        return !!pattern.test(str);
    }

    setSelectedTab(e: any) {
        this.selectedTab = e.detail.name;
        this.startingTab = this.selectedTab;
        let tabSwitched = new CustomEvent('tabSwitched', {
            detail: {
                tab: this.selectedTab,
            },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(tabSwitched);
    }

    handleShowingTooltip(e: CustomEvent) {
        if (e.detail.entering) {

            if (this.openTooltips.length > 0) {
                this.openTooltips[0].open = false;
                this.openTooltips = [];
            }

            e.detail.tooltip.show();
            this.openTooltips.push(e.detail.tooltip)
        } else {
            e.detail.tooltip.hide();
            this.openTooltips = [];
        }

    }

    render() {
        return html`
      <wa-tab-group 
        id="editor-tabs" 
        @wa-tab-show=${(e: any) => this.setSelectedTab(e)}
        @manifestUpdated=${(e: any) => this.updateManifest(e)}
        @errorInTab=${(e: CustomEvent) => this.errorInTab(e)}
        @trigger-hover=${(e: CustomEvent) => this.handleShowingTooltip(e)}
      >
        <wa-tab slot="nav" panel="info" ?active=${this.startingTab === "info"}>Info</wa-tab>
        <wa-tab slot="nav" panel="settings" ?active=${this.startingTab === "settings"}>Settings</wa-tab>
        <wa-tab slot="nav" panel="platform" ?active=${this.startingTab === "platform"}>Platform</wa-tab>
        <wa-tab slot="nav" panel="icons" ?active=${this.startingTab === "icons"}>Icons</wa-tab>
        <wa-tab slot="nav" panel="screenshots" ?active=${this.startingTab === "screenshots"}>Screenshots</wa-tab>
        <wa-tab slot="nav" panel="share" ?active=${this.startingTab === "share"}>Share Target</wa-tab>
        <wa-tab slot="nav" panel="code">Code</wa-tab>
        <wa-tab-panel name="info"><manifest-info-form id="info-tab" .manifest=${this.manifest} .focusOn=${this.focusOn}></manifest-info-form></wa-tab-panel>
        <wa-tab-panel name="settings"><manifest-settings-form .manifest=${this.manifest} .focusOn=${this.focusOn}></manifest-settings-form></wa-tab-panel>
        <wa-tab-panel name="platform"><manifest-platform-form id="platform-tab" .manifest=${this.manifest} .focusOn=${this.focusOn}></manifest-platform-form></wa-tab-panel>
        <wa-tab-panel name="icons">
          <manifest-icons-form .manifest=${this.manifest} .focusOn=${this.focusOn} .manifestURL=${this.cleanUrl(this.manifestURL)} imageProxyUrl=${this.imageProxyUrl} analysisId=${this.analysisId}></manifest-icons-form>
        </wa-tab-panel>
        <wa-tab-panel name="screenshots">
            <manifest-screenshots-form .manifest=${this.manifest} .focusOn=${this.focusOn} .manifestURL=${this.cleanUrl(this.manifestURL)} .baseURL=${this.cleanUrl(this.baseURL)}></manifest-screenshots-form>
        </wa-tab-panel>
        <wa-tab-panel name="share">
            <manifest-share-form .manifest=${this.manifest} .focusOn=${this.focusOn} .manifestURL=${this.cleanUrl(this.manifestURL)}></manifest-share-form>
        </wa-tab-panel>
        <wa-tab-panel name="code">
            <manifest-code-form .manifest=${this.manifest}></manifest-code-form>
        </wa-tab-panel>

      </wa-tab-group>
    `;
    }
}