// Local copy of the Manifest type (and its dependent interfaces) originally
// sourced from @pwabuilder/manifest-validation. Copied here so the frontend can
// drop the runtime dependency on that package for type-only usage.

export interface Manifest {
    background_color?: string;
    description?: string;
    dir?: "auto" | "ltr" | "rtl" | string;
    display?: "standalone" | "fullscreen" | "fullscreen-sticky";
    lang?: string | undefined;
    name?: string | undefined;
    orientation?: "any" | "natural" | "landscape" | "portrait" | "portrait-primary" | "portrait-secondary" | "landscape-primary" | "landscape-secondary";
    prefer_related_applications?: boolean;
    related_applications?: RelatedApplication[];
    scope?: string;
    short_name?: string;
    start_url?: string;
    theme_color?: string;
    generated?: boolean;
    shortcuts?: ShortcutItem[];
    categories?: string[];
    screenshots?: Screenshot[];
    iarc_rating_id?: string;
    iconBlobUrls?: string[];
    icons?: Icon[];
    share_target?: ShareTarget;
    protocol_handler?: ProtocolHandler;
    [key: string]: string | boolean | undefined | Array<any> | any;
}

export interface ProtocolHandler {
    protocol: string;
    url: string;
}

export interface ShortcutItem {
    name: string;
    url: string;
    description?: string;
    short_name?: string;
    icons?: Icon[];
}

export interface Icon {
    src: string;
    generated?: boolean;
    type?: string;
    sizes?: string;
    purpose?: "any" | "maskable" | "monochrome";
    label?: string;
}

export interface Screenshot extends Icon {
    platform?: "narrow" | "wide" | "android" | "chromeos" | "ios" | "kaios" | "macos" | "windows" | "xbox" | "chrome_web_store" | "play" | "itunes" | "microsoft-inbox" | "microsoft-store";
}

export interface RelatedApplication {
    platform: string;
    url?: string | null;
    id?: string | null;
    min_version?: string | null;
    fingerprints?: Fingerprint[];
}

export interface Fingerprint {
    type: string;
    value: string;
}

export interface ShareTarget {
    action?: string;
    method?: string;
    enctype?: string;
    params?: ShareTargetParams;
}

export interface ShareTargetParams {
    title?: string;
    text?: string;
    url?: string;
    files?: FilesParams[];
}

export interface FilesParams {
    name: string;
    accept: string[];
}
