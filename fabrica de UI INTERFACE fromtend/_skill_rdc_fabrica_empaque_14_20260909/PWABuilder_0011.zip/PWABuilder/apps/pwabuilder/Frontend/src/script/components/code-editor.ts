import { LitElement, html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { codeEditorStyles } from './code-editor.styles';
import { EditorState } from '@codemirror/state';
import { EditorView } from '@codemirror/view';
import { Lazy, CodeEditorEvents, CodeEditorSyncEvent, increment } from '../utils/helpers';
import { emitter, getEditorState } from "../utils/codemirror";
import { debounce } from "../utils/debounce";
import { resizeObserver } from "../utils/events";
import '@awesome.me/webawesome/dist/components/button/button.js';

@customElement('code-editor')
export class CodeEditor extends LitElement {
    @property({
        type: String,
    })
    startText: Lazy<string>;
    @property({ type: String }) copyText = 'Copy Manifest';
    @property({ type: String }) editorStateType: string = 'json';
    @property({ type: Boolean }) readOnly = false;

    @state()
    editorState: Lazy<EditorState>;

    @state() editorView: Lazy<EditorView>;

    @state() editorId: string;

    @state() editorEmitter = emitter;

    @state() copied = false;

    protected static editorIdGenerator = increment();

    static styles = [codeEditorStyles];

    constructor() {
        super();

        this.editorId = `editor-${CodeEditor.editorIdGenerator.next().value}`;

        this.editorEmitter.addEventListener(
            CodeEditorEvents.sync,
            (event: Event) => {
                const e = event as CustomEvent<CodeEditorSyncEvent>;

                this.startText = e.detail.text;
                this.updateEditor();
            }
        );

        this.editorEmitter.addEventListener(
            CodeEditorEvents.update,
            debounce((event: Event) => {
                this.dispatchEvent(event);
            }, 0)
        );

        resizeObserver.observe(this);
    }

    connectedCallback(): void {
        super.connectedCallback();
        this.updateEditor();
    }

    updated(changedProperties: Map<string, any>) {
        if (changedProperties.has('startText')) {
            this.editorState = getEditorState(this.startText || '', this.editorStateType, [], !this.readOnly);

            if (this.editorView) {
                this.editorView.setState(this.editorState);
            } else {
                this.editorView = new EditorView({
                    state: this.editorState,
                    root: this.shadowRoot || undefined,
                    parent: this.shadowRoot?.getElementById(this.editorId) || undefined,
                });
            }
        }
    }

    async copyCode() {

        let editorCopied = new CustomEvent('editorCopied', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(editorCopied);

        const doc = this.editorState?.doc;

        if (doc) {
            try {
                await navigator.clipboard.writeText(doc.toString());
                this.copyText = 'Copied';
                this.copied = true;
                setTimeout(() => { this.copyText = "Copy Manifest"; this.copied = false; }, 3000);
            } catch (err) {
                // We should never really end up here but just in case
                // lets put the error in the console
                console.warn('Copying failed with the following err', err);
            }
        }
    }

    render() {
        return html`
      <div id="copy-block">
        <slot>
          <wa-button
            ?disabled="${this.copied}"
            @click="${() => this.copyCode()}"
            class="copy-button"
          >
            ${this.copyText}</wa-button
          >
        </slot>
      </div>

      <div tabindex="0" id=${this.editorId} class="editor-container ${this.className}" ></div>
    `;
    }

    updateEditor = debounce(() => {
        this.editorState = getEditorState(this.startText || '', this.editorStateType, [], !this.readOnly);

        if (this.editorView) {
            this.editorView.setState(this.editorState);
        } else {
            this.editorView = new EditorView({
                state: this.editorState,
                root: this.shadowRoot || undefined,
                parent: this.shadowRoot?.getElementById(this.editorId) || undefined
            });
        }
    }, 2000);
}
