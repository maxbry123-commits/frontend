import {
    AndroidSdkTools,
    Config,
    DigitalAssetLinks,
    GradleWrapper,
    JdkHelper,
    TwaGenerator,
    TwaManifest,
    JarSigner,
    ConsoleLog,
    SigningKeyInfo,
} from '@bubblewrap/core';
import { ShortcutInfo } from '@bubblewrap/core/dist/lib/ShortcutInfo.js';
import { findSuitableIcon } from '@bubblewrap/core/dist/lib/util.js';
import { AndroidPackageOptions } from '../models/androidPackageOptions.js';
import fs from 'fs-extra';
import { WebManifestShortcutJson } from '@bubblewrap/core/dist/lib/types/WebManifest.js';
import { LocalKeyFileSigningOptions } from '../models/signingOptions.js';
import { GeneratedAppPackage } from '../models/generatedAppPackage.js';
import { createSigningCommandCredentials } from '../utils/signing-command-credentials.js';
import { CreateKeyOptions, SafeKeyTool } from './safe-key-tool.js';
import { TwaManifestJson } from '@bubblewrap/core/dist/lib/TwaManifest.js';
import { fetchUtils } from '@bubblewrap/core';
import { FetchEngine } from '@bubblewrap/core/dist/lib/FetchUtils.js';
import generatePassword from 'password-generator';
import { PackageCreationProgress } from "../models/packageCreationProgress.js";
import EventEmitter from "events";
import { validateAndroidOptionsRequest } from '../utils/android-options-validation.js';

/*
 * Wraps Google's bubblewrap to build a signed APK from a PWA.
 * https://github.com/GoogleChromeLabs/bubblewrap/tree/master/packages/core
 */
export class BubbleWrapper {
    private javaConfig: Config;
    private jdkHelper: JdkHelper;
    private androidSdkTools: AndroidSdkTools;
    private readonly eventEmitter = new EventEmitter();

    /**
     *
     * @param apkSettings The settings for the APK generation.
     * @param projectDirectory The directory where to generate the project files and signed APK.
     * @param signingKeyInfo Information about the signing key.
     */
    constructor(
        private apkSettings: AndroidPackageOptions,
        private projectDirectory: string,
        private signingKeyInfo: LocalKeyFileSigningOptions | null,
        fetchEngine: FetchEngine
    ) {
        this.javaConfig = new Config(
            process.env.JDK8PATH!,
            process.env.ANDROIDTOOLSPATH!
        );
        this.jdkHelper = new JdkHelper(process, this.javaConfig);
        this.androidSdkTools = new AndroidSdkTools(
            process,
            this.javaConfig,
            this.jdkHelper
        );
        fetchUtils.setFetchEngine(fetchEngine);
    }

    /**
     * Adds an event listener to the BubbleWrapper instance to listen for progress events.
     * @param type The type of event to listen for. Currently, only "progress" is supported.
     * @param listener The event listener to add.
     */
    addEventListener(type: "progress", listener: (e: PackageCreationProgress) => void) {
        this.eventEmitter.addListener(type, listener);
    }

    /**
     * Removes an event listener from the BubbleWrapper instance.
     * @param type The type of event to remove. Currently, only "progress" is supported.
     * @param listener The event listener to remove.
     */
    removeEventListener(type: "progress", listener: (e: PackageCreationProgress) => void) {
        this.eventEmitter.removeListener(type, listener);
    }

    /**
     * Generates app package from the PWA.
     */
    async generateAppPackage(): Promise<GeneratedAppPackage> {
        // Create an optimized APK.
        this.dispatchProgressEvent('Creating Trusted Web Activity (TWA) project...');
        await this.generateTwaProject();

        const apkPath = await this.buildApk();

        // Do we have a signing key?
        // If so, sign the APK, generate digital asset links file, and generate an app bundle.
        if (this.apkSettings.signingMode !== 'none' && this.signingKeyInfo) {
            if (this.apkSettings.signingMode === "new") {
                // temporary workaround for https://github.com/GoogleChromeLabs/bubblewrap/issues/693
                const passToUse = generatePassword(12, false);

                this.signingKeyInfo.keyPassword = passToUse;
                this.signingKeyInfo.storePassword = passToUse;
            }

            this.dispatchProgressEvent('Signing APK...');
            const signedApkPath = await this.signApk(apkPath, this.signingKeyInfo);
            const assetLinksPath = await this.tryGenerateAssetLinks(
                this.signingKeyInfo
            );

            this.dispatchProgressEvent('Building App Bundle...');
            const appBundlePath = await this.buildAppBundle(this.signingKeyInfo);
            this.dispatchProgressEvent("App bundle built successfully.");
            return {
                projectDirectory: this.projectDirectory,
                appBundleFilePath: appBundlePath,
                apkFilePath: signedApkPath,
                signingInfo: this.signingKeyInfo,
                assetLinkFilePath: assetLinksPath,
            };
        }

        // We generated an unsigned APK, so there will be no signing info, asset links, or app bundle.
        return {
            projectDirectory: this.projectDirectory,
            apkFilePath: apkPath,
            signingInfo: this.signingKeyInfo,
            assetLinkFilePath: null,
            appBundleFilePath: await this.buildAppBundle(),
        };
    }

    private async buildAppBundle(
        signingInfo?: LocalKeyFileSigningOptions
    ): Promise<string> {
        this.dispatchProgressEvent('Generating app bundle');

        // Build the app bundle file (.aab)
        const gradleWrapper = new GradleWrapper(
            process,
            this.androidSdkTools,
            this.projectDirectory
        );
        await gradleWrapper.bundleRelease();

        // Sign the app bundle file.
        const appBundleDir = 'app/build/outputs/bundle/release';
        const inputFile = `${this.projectDirectory}/${appBundleDir}/app-release.aab`;

        if (!signingInfo) {
            // returning unsigned app bundle
            return inputFile;
        }

        //const outputFile = './app-release-signed.aab';
        const outputFile = `${this.projectDirectory}/${appBundleDir}/app-release-signed.aab`;
        const jarSigner = new JarSigner(this.jdkHelper);
        const signingCommandCredentials = createSigningCommandCredentials(signingInfo);
        const jarSigningInfo: SigningKeyInfo = {
            path: signingInfo.keyFilePath,
            alias: signingCommandCredentials.alias,
        };

        try {
            await jarSigner.sign(
                jarSigningInfo,
                signingCommandCredentials.storePassword,
                signingCommandCredentials.keyPassword,
                inputFile,
                outputFile
            );
            return outputFile;
        } catch (signingError) {
            // Redact the key alias and passwords before logging or rethrowing, as the underlying
            // error may include the full signing command - including these secrets - in its
            // message, cmd, stdout, or stderr properties. See https://github.com/pwa-builder/PWABuilder/issues/6311
            const redactedSigningError = signingCommandCredentials.redactError(signingError);
            const signingErrorStr = `${redactedSigningError}`;
            if (signingErrorStr.includes("toDerInputStream rejects tag type 75") ||
                signingErrorStr.includes("DerValue.getBigIntegerInternal, not expected 6")) {
                this.dispatchProgressEvent("Error signing the app bundle due to what appears to be an invalid signing key file.", "error");
            } else {
                this.dispatchProgressEvent("Error signing the app bundle.", "error");
            }

            console.error("Error signing the app bundle", redactedSigningError);
            throw redactedSigningError;
        }
    }

    private async generateTwaProject(): Promise<TwaManifest> {
        const twaGenerator = new TwaGenerator();
        const twaManifest = this.createTwaManifest(this.apkSettings);
        try {
            await twaGenerator.createTwaProject(
                this.projectDirectory,
                twaManifest,
                new ConsoleLog()
            );
        } catch (error) {
            // Better handling for errors where fetching JSON (usually the web manifest) returns HTML result. 
            // Example: https://github.com/pwa-builder/PWABuilder/issues/5376
            if (error instanceof Error && error.message.includes("Unexpected token '<'")) {
                this.dispatchProgressEvent("It appears your web app manifest is broken. When PWABuilder's Google Play platform went to fetch it, your web app returned HTML instead of JSON. Make sure your web manifest can be loaded directly. Try opening your web app in the browser, open F12 dev tools -> Application -> Manifest, and ensure your web manifest is loading properly.", "error");
            } else if (error instanceof Error && error.message.includes("Could not find MIME for Buffer")) {
                // Better handling for icon-related errors where Bubblewrap can't figure out the mime type of an image.
                // This usually indicates an image is the wrong type (e.g. an SVG or ICO).
                // Exmaple: https://github.com/pwa-builder/PWABuilder/issues/5367
                this.dispatchProgressEvent("PWABuilder's Bubblewrap couldn't figure out the MIME type for one of the images in your web manifest. We recommend all your web manifest images should be PNG or JPG.", "error");
            }

            throw error;
        }
        return twaManifest;
    }

    private async createSigningKey(signingInfo: LocalKeyFileSigningOptions) {
        const keyTool = new SafeKeyTool(() => this.jdkHelper.getEnv());
        const overwriteExisting = true;
        if (
            !signingInfo.fullName ||
            !signingInfo.organization ||
            !signingInfo.organizationalUnit ||
            !signingInfo.countryCode
        ) {
            throw new Error(
                `Missing required signing info. Full name: ${signingInfo.fullName}, Organization: ${signingInfo.organization}, Organizational Unit: ${signingInfo.organizationalUnit}, Country Code: ${signingInfo.countryCode}.`
            );
        }

        const keyOptions: CreateKeyOptions = {
            path: signingInfo.keyFilePath,
            password: signingInfo.storePassword,
            keypassword: signingInfo.keyPassword,
            alias: signingInfo.alias,
            fullName: signingInfo.fullName,
            organization: signingInfo.organization,
            organizationalUnit: signingInfo.organizationalUnit,
            country: signingInfo.countryCode,
        };

        await keyTool.createSigningKey(keyOptions, overwriteExisting);
    }

    private async buildApk(): Promise<string> {

        const gradleWrapper = new GradleWrapper(
            process,
            this.androidSdkTools,
            this.projectDirectory
        );
        this.dispatchProgressEvent("Building the app package with Gradle. This can take a few minutes...");
        await gradleWrapper.assembleRelease();
        return `${this.projectDirectory}/app/build/outputs/apk/release/app-release-unsigned.apk`;
    }

    private async signApk(
        apkFilePath: string,
        signingInfo: LocalKeyFileSigningOptions
    ): Promise<string> {
        // Create a new signing key if necessary.
        if (this.apkSettings.signingMode === 'new') {
            await this.createSigningKey(signingInfo);
        }

        const outputFile = `${this.projectDirectory}/app-release-signed.apk`;
        const signingCommandCredentials = createSigningCommandCredentials(signingInfo);
        this.dispatchProgressEvent('Signing the app package...');
        try {
            await this.androidSdkTools.apksigner(
                signingInfo.keyFilePath,
                signingCommandCredentials.storePassword,
                signingCommandCredentials.alias,
                signingCommandCredentials.keyPassword,
                apkFilePath,
                outputFile
            );
        } catch (signingError) {
            // Redact the key alias and passwords before rethrowing, as the underlying error may
            // include the full apksigner command - including these secrets - in its message,
            // cmd, stdout, or stderr properties. See https://github.com/pwa-builder/PWABuilder/issues/6311
            throw signingCommandCredentials.redactError(signingError);
        }
        this.dispatchProgressEvent('App package signed successfully');
        return outputFile;
    }

    async tryGenerateAssetLinks(
        signingInfo: LocalKeyFileSigningOptions
    ): Promise<string | null> {
        try {
            const result = await this.generateAssetLinks(signingInfo);
            return result;
        } catch (error) {
            this.dispatchProgressEvent(`Asset links couldn't be generated. Proceeding without asset links. Error: ${error}`);
            return null;
        }
    }

    async generateAssetLinks(
        signingInfo: LocalKeyFileSigningOptions
    ): Promise<string> {
        this.dispatchProgressEvent('Generating asset links...');
        const keyTool = new SafeKeyTool(() => this.jdkHelper.getEnv());
        const assetLinksFilePath = `${this.projectDirectory}/app/build/outputs/apk/release/assetlinks.json`;
        const keyInfo = await keyTool.keyInfo({
            path: signingInfo.keyFilePath,
            alias: signingInfo.alias,
            keypassword: signingInfo.keyPassword,
            password: signingInfo.storePassword,
        });

        const sha256Fingerprint = keyInfo.fingerprints.get('SHA256');
        if (!sha256Fingerprint) {
            throw new Error("Couldn't find SHA256 fingerprint.");
        }

        const assetLinks = DigitalAssetLinks.generateAssetLinks(
            this.apkSettings.packageId,
            sha256Fingerprint
        );
        await fs.promises.writeFile(assetLinksFilePath, assetLinks);
        this.dispatchProgressEvent(`Digital Asset Links file generated at ${assetLinksFilePath}`);
        return assetLinksFilePath;
    }

    private createTwaManifest(pwaSettings: AndroidPackageOptions): TwaManifest {
        // Persisted jobs may predate HTTP validation. Revalidate before generating executable code.
        const request = validateAndroidOptionsRequest(pwaSettings);
        if (!request.options || request.validationErrors.length > 0) {
            throw new Error('Invalid PWA settings: ' + request.validationErrors.join(', '));
        }
        pwaSettings = request.options;

        const signingKey = {
            path: this.signingKeyInfo?.keyFilePath || '',
            alias: this.signingKeyInfo?.alias || '',
        };

        // Alpha dependencies must be turned on if Google Play Billing is enabled.
        // See https://github.com/pwa-builder/PWABuilder/issues/1832#issuecomment-926616538
        const alphaDependencies = pwaSettings.features?.playBilling?.enabled
            ? { enabled: true }
            : undefined;
        const manifestJson: TwaManifestJson = {
            // Do not spread untrusted JSON: undeclared Bubblewrap features can also emit build code.
            packageId: pwaSettings.packageId,
            host: pwaSettings.host,
            name: pwaSettings.name,
            launcherName: pwaSettings.launcherName,
            appVersion: pwaSettings.appVersion,
            appVersionCode: pwaSettings.appVersionCode,
            startUrl: pwaSettings.startUrl,
            display: pwaSettings.display,
            orientation: pwaSettings.orientation,
            themeColor: pwaSettings.themeColor,
            themeColorDark: pwaSettings.themeColorDark,
            backgroundColor: pwaSettings.backgroundColor,
            navigationColor: pwaSettings.navigationColor,
            navigationColorDark: pwaSettings.navigationColorDark,
            navigationDividerColor: pwaSettings.navigationDividerColor,
            navigationDividerColorDark: pwaSettings.navigationDividerColorDark,
            iconUrl: pwaSettings.iconUrl,
            maskableIconUrl: pwaSettings.maskableIconUrl,
            monochromeIconUrl: pwaSettings.monochromeIconUrl,
            splashScreenFadeOutDuration: pwaSettings.splashScreenFadeOutDuration,
            enableNotifications: pwaSettings.enableNotifications,
            enableSiteSettingsShortcut: pwaSettings.enableSiteSettingsShortcut,
            isChromeOSOnly: pwaSettings.isChromeOSOnly,
            isMetaQuest: pwaSettings.isMetaQuest,
            minSdkVersion: pwaSettings.minSdkVersion,
            webManifestUrl: pwaSettings.webManifestUrl,
            fullScopeUrl: pwaSettings.fullScopeUrl,
            fallbackType: pwaSettings.fallbackType,
            shareTarget: pwaSettings.shareTarget,
            additionalTrustedOrigins: pwaSettings.additionalTrustedOrigins,
            serviceAccountJsonFile: pwaSettings.serviceAccountJsonFile,
            features: {
                appsFlyer: pwaSettings.features?.appsFlyer,
                firstRunFlag: pwaSettings.features?.firstRunFlag,
                locationDelegation: pwaSettings.features?.locationDelegation,
                playBilling: pwaSettings.features?.playBilling,
            },
            shortcuts: this.createShortcuts(
                pwaSettings.shortcuts,
                pwaSettings.webManifestUrl
            ),
            signingKey: signingKey,
            generatorApp: 'PWABuilder',
            alphaDependencies: alphaDependencies,
        };
        const twaManifest = new TwaManifest(manifestJson);
        console.info('TWA manifest created', twaManifest);
        return twaManifest;
    }

    private createShortcuts(
        shortcutsJson: WebManifestShortcutJson[] | null | undefined,
        manifestUrl: string
    ): ShortcutInfo[] {
        if (!shortcutsJson) {
            return [];
        }
        if (!manifestUrl) {
            console.warn(
                'Skipping app shortcuts due to empty manifest URL',
                manifestUrl
            );
            return [];
        }

        const maxShortcuts = 4;
        return shortcutsJson
            .filter((s) => this.isValidShortcut(s))
            .map((s) => this.createShortcut(s, manifestUrl))
            .slice(0, 4);
    }

    private createShortcut(
        shortcut: WebManifestShortcutJson,
        manifestUrl: string
    ): ShortcutInfo {
        const shortNameMaxSize = 12;
        const name = shortcut.name || shortcut.short_name;
        const shortName =
            shortcut.short_name || shortcut.name!.substring(0, shortNameMaxSize);
        const url = new URL(shortcut.url!, manifestUrl).toString();
        const suitableIcon = findSuitableIcon(shortcut.icons!, 'any');
        const iconUrl = new URL(suitableIcon!.src, manifestUrl).toString();
        return new ShortcutInfo(name!, shortName!, url, iconUrl);
    }

    private isValidShortcut(
        shortcut: WebManifestShortcutJson | null | undefined
    ): boolean {
        if (!shortcut) {
            this.dispatchProgressEvent(`Shortcut is invalid due to being null or undefined ${shortcut}`);
            return false;
        }
        if (!shortcut.icons) {
            this.dispatchProgressEvent(`Shortcut is invalid due to not having any icons specified ${shortcut}`);
            return false;
        }
        if (!shortcut.url) {
            this.dispatchProgressEvent(`Shortcut is invalid due to not having a URL ${shortcut}`);
            return false;
        }
        if (!shortcut.name && !shortcut.short_name) {
            this.dispatchProgressEvent(`Shortcut is invalid due to having neither a name nor short_name ${shortcut}`);
            return false;
        }
        if (!findSuitableIcon(shortcut.icons, 'any')) {
            this.dispatchProgressEvent(`Shortcut is invalid due to not finding a suitable icon ${shortcut.icons}`);
            return false;
        }

        return true;
    }

    private dispatchProgressEvent(message: string, level: "info" | "warn" | "error" = "info"): void {
        const ev: PackageCreationProgress = { message, level };
        this.eventEmitter.emit("progress", ev);
    }
}
