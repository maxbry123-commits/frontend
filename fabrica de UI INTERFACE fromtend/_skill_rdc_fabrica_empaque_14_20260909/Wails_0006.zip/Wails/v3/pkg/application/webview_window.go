package application

import (
	"encoding/json"
	"fmt"
	"runtime"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"unsafe"

	"github.com/wailsapp/wails/v3/internal/assetserver"
	"github.com/wailsapp/wails/v3/internal/optional"
	"github.com/wailsapp/wails/v3/pkg/events"
)

// Enabled means the feature should be enabled
var Enabled = optional.True

// Disabled means the feature should be disabled
var Disabled = optional.False

var shouldSkipHideOnFocusLost = func() bool { return false }

// LRTB is a struct that holds Left, Right, Top, Bottom values
type LRTB struct {
	Left   int
	Right  int
	Top    int
	Bottom int
}

type (
	webviewWindowImpl interface {
		setTitle(title string)
		setSize(width, height int)
		setAlwaysOnTop(alwaysOnTop bool)
		setURL(url string)
		setResizable(resizable bool)
		setMinSize(width, height int)
		setMaxSize(width, height int)
		execJS(js string)
		setBackgroundColour(color RGBA)
		run()
		center()
		size() (int, int)
		width() int
		height() int
		destroy()
		reload()
		forceReload()
		openDevTools()
		zoomReset()
		zoomIn()
		zoomOut()
		getZoom() float64
		setZoom(zoom float64)
		close()
		zoom()
		setHTML(html string)
		on(eventID uint)
		minimise()
		unminimise()
		maximise()
		unmaximise()
		fullscreen()
		unfullscreen()
		isMinimised() bool
		isMaximised() bool
		isFullscreen() bool
		isNormal() bool
		isVisible() bool
		isFocused() bool
		focus()
		show()
		hide()
		getScreen() (*Screen, error)
		setFrameless(bool)
		openContextMenu(menu *Menu, data *ContextMenuData)
		nativeWindow() unsafe.Pointer
		startDrag() error
		startResize(border string) error
		print() error
		setEnabled(enabled bool)
		physicalBounds() Rect
		setPhysicalBounds(physicalBounds Rect)
		bounds() Rect
		setBounds(bounds Rect)
		position() (int, int)
		setPosition(x int, y int)
		centerOnScreen(screen *Screen)
		relativePosition() (int, int)
		setRelativePosition(x int, y int)
		flash(enabled bool)
		handleKeyEvent(acceleratorString string)
		getBorderSizes() *LRTB
		setMinimiseButtonState(state ButtonState)
		setMaximiseButtonState(state ButtonState)
		setCloseButtonState(state ButtonState)
		setFullscreenButtonState(state ButtonState)
		isIgnoreMouseEvents() bool
		setIgnoreMouseEvents(ignore bool)
		cut()
		copy()
		paste()
		undo()
		delete()
		selectAll()
		redo()
		showMenuBar()
		hideMenuBar()
		toggleMenuBar()
		setMenu(menu *Menu)
		snapAssist()
		setContentProtection(enabled bool)
		attachModal(modalWindow *WebviewWindow)
		setNonClientHitTestRegions([]nonClientHitTestRegion)
	}

	nonClientHitTestKind string

	// nonClientHitTestRegion is a frontend-owned client-area rectangle in physical pixels.
	nonClientHitTestRegion struct {
		Kind   nonClientHitTestKind `json:"kind,omitempty"`
		Left   int                  `json:"left"`
		Top    int                  `json:"top"`
		Right  int                  `json:"right"`
		Bottom int                  `json:"bottom"`
	}

	nonClientHitTestRegionsMessage struct {
		Version int                      `json:"version,omitempty"`
		Regions []nonClientHitTestRegion `json:"regions"`
	}
)

const (
	nonClientHitTestKindCaption  nonClientHitTestKind = "caption"
	nonClientHitTestKindMinimize nonClientHitTestKind = "minimize"
	nonClientHitTestKindMaximize nonClientHitTestKind = "maximize"
	nonClientHitTestKindClose    nonClientHitTestKind = "close"
)

type WindowEvent struct {
	ctx       *WindowEventContext
	cancelled atomic.Bool
}

func (w *WindowEvent) Context() *WindowEventContext {
	return w.ctx
}

func NewWindowEvent() *WindowEvent {
	return &WindowEvent{}
}

func (w *WindowEvent) IsCancelled() bool {
	return w.cancelled.Load()
}

func (w *WindowEvent) Cancel() {
	w.cancelled.Store(true)
}

type WindowEventListener struct {
	callback func(event *WindowEvent)
}

type WebviewWindow struct {
	options WebviewWindowOptions
	impl    webviewWindowImpl
	id      uint

	// notchWindow is set only by WindowManager.NewNotchWindow. It is kept
	// outside WebviewWindowOptions so the lower-level constructor cannot create
	// a partially configured notch window.
	notchWindow *notchWindowConfig

	eventListeners     map[uint][]*WindowEventListener
	eventListenersLock sync.RWMutex
	eventHooks         map[uint][]*WindowEventListener
	eventHooksLock     sync.RWMutex

	// A map of listener cancellation functions
	cancellersLock sync.RWMutex
	cancellers     []func()

	// keyBindings holds the keybindings for the window
	keyBindings     map[string]func(Window)
	keyBindingsLock sync.RWMutex

	// menuBindings holds the menu bindings for the window
	menuBindings     map[string]*MenuItem
	menuBindingsLock sync.RWMutex

	// Events are queued and drained by a single consumer on the UI thread so
	// that delivery order matches emit order. See enqueueEventJS.
	eventQueueMu     sync.Mutex
	eventQueueCond   *sync.Cond
	eventQueue       []string
	eventDraining    bool
	eventQueueClosed bool
	eventQueueHigh   int

	// Indicates that the window is destroyed
	destroyed     bool
	destroyedLock sync.RWMutex

	runtimeLoaded  bool
	pendingJS      []string
	pendingJSMutex sync.Mutex

	// unconditionallyClose marks the window to be unconditionally closed (atomic)
	unconditionallyClose uint32

	savedMinWidth    int
	savedMinHeight   int
	savedMaxWidth    int
	savedMaxHeight   int
	constraintsSaved bool
}

func (w *WebviewWindow) SetMenu(menu *Menu) {
	switch runtime.GOOS {
	case "darwin":
		return
	case "windows":
		w.options.Windows.Menu = menu
	case "linux":
		w.options.Linux.Menu = menu
	}
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setMenu(menu)
		})
	}
}

// EmitEvent emits a custom event with the specified name and associated data.
// It returns a boolean indicating whether the event was cancelled by a hook.
// The [CustomEvent.Sender] field will be set to the window name.
//
// If the given event name is registered, EmitEvent validates the data parameter
// against the expected data type. In case of a mismatch, EmitEvent reports an error
// to the registered error handler for the application and cancels the event.
func (w *WebviewWindow) EmitEvent(name string, data ...any) bool {
	event := &CustomEvent{
		Name:   name,
		Sender: w.Name(),
	}

	if len(data) == 1 {
		event.Data = data[0]
	} else if len(data) > 1 {
		event.Data = data
	}

	return globalApplication.Event.EmitEvent(event)
}

var windowID uint
var windowIDLock sync.RWMutex

func getWindowID() uint {
	windowIDLock.Lock()
	defer windowIDLock.Unlock()
	windowID++
	return windowID
}

// FIXME: This should like be an interface method (TDM)
// Use onApplicationEvent to register a callback for an application event from a window.
// This will handle tidying up the callback when the window is destroyed
func (w *WebviewWindow) onApplicationEvent(
	eventType events.ApplicationEventType,
	callback func(*ApplicationEvent),
) {
	cancelFn := globalApplication.Event.OnApplicationEvent(eventType, callback)
	w.addCancellationFunction(cancelFn)
}

func (w *WebviewWindow) markAsDestroyed() {
	w.destroyedLock.Lock()
	w.destroyed = true
	w.destroyedLock.Unlock()

	// Release anyone blocked on a full queue. Done outside destroyedLock so the
	// lock order between it and eventQueueMu is always one-way.
	w.closeEventQueue()

	// Anything parked for this window will never be fetched now. TTL would
	// eventually reclaim it, but the window is gone, so release immediately.
	if globalApplication != nil && globalApplication.eventPayloads != nil {
		globalApplication.eventPayloads.dropWindow(w.id)
	}

	// Same reasoning for streams: nothing in this window will ever poll again,
	// so close the connections now and let the handlers unblock.
	if globalApplication != nil && globalApplication.streams != nil {
		globalApplication.streams.dropWindow(w.id)
	}
}

func (w *WebviewWindow) setupEventMapping() {

	var mapping map[events.WindowEventType]events.WindowEventType
	switch runtime.GOOS {
	case "darwin":
		mapping = w.options.Mac.EventMapping
	case "windows":
		mapping = w.options.Windows.EventMapping
	case "linux":
		// TBD
	}
	if mapping == nil {
		mapping = events.DefaultWindowEventMapping()
	}

	for source, target := range mapping {
		source := source
		target := target
		w.OnWindowEvent(source, func(event *WindowEvent) {
			w.emit(target)
		})
	}
}

// NewWindow creates a new window with the given options
func NewWindow(options WebviewWindowOptions) *WebviewWindow {

	thisWindowID := getWindowID()

	if options.Width == 0 {
		options.Width = 800
	}
	if options.Height == 0 {
		options.Height = 600
	}
	if options.URL == "" {
		options.URL = "/"
	}

	if options.Name == "" {
		options.Name = fmt.Sprintf("window-%d", thisWindowID)
	}

	// Inject the minimal `window.wails.Events` shim into HTML-supplied
	// pages that opted into the simple postMessage emit path. Without this
	// they can't load /wails/runtime.js (their origin is "null") so they'd
	// have to hand-roll a dispatch receiver and an invoke caller every
	// time. See inline_event_shim.go.
	options.HTML = maybeInjectInlineEventShim(options.HTML, options.AllowSimpleEventEmit)

	result := &WebviewWindow{
		id:             thisWindowID,
		options:        options,
		eventListeners: make(map[uint][]*WindowEventListener),
		eventHooks:     make(map[uint][]*WindowEventListener),
		menuBindings:   make(map[string]*MenuItem),
	}

	result.setupEventMapping()

	// Listen for window closing events and de
	result.OnWindowEvent(events.Common.WindowClosing, func(event *WindowEvent) {
		atomic.StoreUint32(&result.unconditionallyClose, 1)
		InvokeSync(result.markAsDestroyed)
		InvokeSync(result.impl.close)
		globalApplication.Window.Remove(result.id)
	})

	// Process keybindings
	if result.options.KeyBindings != nil {
		result.keyBindings = processKeyBindingOptions(result.options.KeyBindings)
	}
	if result.options.HideOnEscape {
		result.RegisterKeyBinding("escape", func(window Window) {
			window.Hide()
		})
	}

	if result.options.HideOnFocusLost {
		result.setupHideOnFocusLost()
	}

	return result
}

func processKeyBindingOptions(
	keyBindings map[string]func(window Window),
) map[string]func(window Window) {
	result := make(map[string]func(window Window))
	for key, callback := range keyBindings {
		// Parse the key to an accelerator
		acc, err := parseAccelerator(key)
		if err != nil {
			globalApplication.error("invalid keybinding: %w", err)
			continue
		}
		result[acc.String()] = callback
		globalApplication.debug("Added Keybinding", "accelerator", acc.String())
	}
	return result
}

func (w *WebviewWindow) setupHideOnFocusLost() {
	if runtime.GOOS == "linux" && shouldSkipHideOnFocusLost() {
		return
	}
	w.OnWindowEvent(events.Common.WindowLostFocus, func(event *WindowEvent) {
		w.Hide()
	})
}

func (w *WebviewWindow) addCancellationFunction(canceller func()) {
	w.cancellersLock.Lock()
	defer w.cancellersLock.Unlock()
	w.cancellers = append(w.cancellers, canceller)
}

func (w *WebviewWindow) ID() uint {
	return w.id
}

// SetTitle sets the title of the window
func (w *WebviewWindow) SetTitle(title string) Window {
	w.options.Title = title
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setTitle(title)
		})
	}
	return w
}

// Name returns the name of the window
func (w *WebviewWindow) Name() string {
	return w.options.Name
}

// SetSize sets the size of the window
func (w *WebviewWindow) SetSize(width, height int) Window {
	// Don't set size if fullscreen
	if w.IsFullscreen() {
		return w
	}
	w.options.Width = width
	w.options.Height = height

	var newMaxWidth = w.options.MaxWidth
	var newMaxHeight = w.options.MaxHeight
	if width > w.options.MaxWidth && w.options.MaxWidth != 0 {
		newMaxWidth = width
	}
	if height > w.options.MaxHeight && w.options.MaxHeight != 0 {
		newMaxHeight = height
	}

	if newMaxWidth != 0 || newMaxHeight != 0 {
		w.SetMaxSize(newMaxWidth, newMaxHeight)
	}

	var newMinWidth = w.options.MinWidth
	var newMinHeight = w.options.MinHeight
	if width < w.options.MinWidth && w.options.MinWidth != 0 {
		newMinWidth = width
	}
	if height < w.options.MinHeight && w.options.MinHeight != 0 {
		newMinHeight = height
	}

	if newMinWidth != 0 || newMinHeight != 0 {
		w.SetMinSize(newMinWidth, newMinHeight)
	}

	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setSize(width, height)
		})
	}
	return w
}

func (w *WebviewWindow) Run() {
	if w.impl != nil {
		return
	}
	w.impl = newWindowImpl(w)

	// On Linux GTK4, we must wait for the application to be activated
	// before creating windows with gtk_application_window_new()
	if nativeApp := globalApplication.impl; nativeApp != nil {
		if waiter, ok := nativeApp.(interface{ waitForActivation() }); ok {
			waiter.waitForActivation()
		}
	}

	InvokeSync(w.impl.run)
}

// SetAlwaysOnTop sets the window to be always on top.
func (w *WebviewWindow) SetAlwaysOnTop(b bool) Window {
	w.options.AlwaysOnTop = b
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setAlwaysOnTop(b)
		})
	}
	return w
}

// Show shows the window.
func (w *WebviewWindow) Show() Window {
	if globalApplication.impl == nil {
		return w
	}
	if w.impl == nil || w.isDestroyed() {
		InvokeSync(w.Run)
		return w
	}
	w.options.Hidden = false
	InvokeSync(w.impl.show)
	return w
}

// Hide hides the window.
func (w *WebviewWindow) Hide() Window {
	w.options.Hidden = true
	if w.impl != nil {
		InvokeSync(w.impl.hide)
	}
	return w
}

func (w *WebviewWindow) SetURL(s string) Window {
	url, _ := assetserver.GetStartURL(s)
	w.options.URL = url
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setURL(url)
		})
	}
	return w
}

func (w *WebviewWindow) GetBorderSizes() *LRTB {
	if w.impl != nil {
		return InvokeSyncWithResult(w.impl.getBorderSizes)
	}
	return &LRTB{}
}

// SetZoom sets the zoom level of the window.
func (w *WebviewWindow) SetZoom(magnification float64) Window {
	w.options.Zoom = magnification
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setZoom(magnification)
		})
	}
	return w
}

// GetZoom returns the current zoom level of the window.
func (w *WebviewWindow) GetZoom() float64 {
	if w.impl != nil {
		return InvokeSyncWithResult(w.impl.getZoom)
	}
	return 1
}

// SetResizable sets whether the window is resizable.
func (w *WebviewWindow) SetResizable(b bool) Window {
	w.options.DisableResize = !b
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setResizable(b)
		})
	}
	return w
}

func (w *WebviewWindow) SetContentProtection(b bool) Window {
	if w.impl == nil {
		w.options.ContentProtectionEnabled = b
	} else {
		InvokeSync(func() {
			w.impl.setContentProtection(b)
		})
	}
	return w
}

// Resizable returns true if the window is resizable.
func (w *WebviewWindow) Resizable() bool {
	return !w.options.DisableResize
}

// SetMinSize sets the minimum size of the window.
func (w *WebviewWindow) SetMinSize(minWidth, minHeight int) Window {
	currentWidth, currentHeight := w.Size()
	newWidth, newHeight := currentWidth, currentHeight

	var newSize bool
	if minHeight != 0 && currentHeight < minHeight {
		newHeight = minHeight
		newSize = true
	}
	if minWidth != 0 && currentWidth < minWidth {
		newWidth = minWidth
		newSize = true
	}
	InvokeSync(func() {
		w.options.MinWidth = minWidth
		w.options.MinHeight = minHeight
		if newSize {
			w.options.Height = newHeight
			w.options.Width = newWidth
			if w.impl != nil {
				w.impl.setSize(newWidth, newHeight)
			}
		}
		if w.impl != nil {
			w.impl.setMinSize(minWidth, minHeight)
		}
	})
	return w
}

// SetMaxSize sets the maximum size of the window.
func (w *WebviewWindow) SetMaxSize(maxWidth, maxHeight int) Window {
	currentWidth, currentHeight := w.Size()
	newWidth, newHeight := currentWidth, currentHeight

	var newSize bool
	if maxHeight != 0 && currentHeight > maxHeight {
		newHeight = maxHeight
		newSize = true
	}
	if maxWidth != 0 && currentWidth > maxWidth {
		newWidth = maxWidth
		newSize = true
	}
	InvokeSync(func() {
		w.options.MaxWidth = maxWidth
		w.options.MaxHeight = maxHeight
		if newSize {
			w.options.Height = newHeight
			w.options.Width = newWidth
			if w.impl != nil {
				w.impl.setSize(newWidth, newHeight)
			}
		}
		if w.impl != nil {
			w.impl.setMaxSize(maxWidth, maxHeight)
		}
	})
	return w
}

// ExecJS executes the given javascript in the context of the window.
func (w *WebviewWindow) ExecJS(js string) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.pendingJSMutex.Lock()
	if w.runtimeLoaded {
		w.pendingJSMutex.Unlock()
		InvokeSync(func() {
			w.impl.execJS(js)
		})
	} else {
		w.pendingJS = append(w.pendingJS, js)
		w.pendingJSMutex.Unlock()
	}
}

// Fullscreen sets the window to fullscreen mode. Min/Max size constraints are disabled.
func (w *WebviewWindow) Fullscreen() Window {
	if w.impl == nil || w.isDestroyed() {
		w.options.StartState = WindowStateFullscreen
		return w
	}
	if !w.IsFullscreen() {
		w.DisableSizeConstraints()
		InvokeSync(w.impl.fullscreen)
	}
	return w
}

func (w *WebviewWindow) SetMinimiseButtonState(state ButtonState) Window {
	w.options.MinimiseButtonState = state
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setMinimiseButtonState(state)
		})
	}
	return w
}

func (w *WebviewWindow) SetMaximiseButtonState(state ButtonState) Window {
	w.options.MaximiseButtonState = state
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setMaximiseButtonState(state)
		})
	}
	return w
}

func (w *WebviewWindow) SetCloseButtonState(state ButtonState) Window {
	w.options.CloseButtonState = state
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setCloseButtonState(state)
		})
	}
	return w
}

func (w *WebviewWindow) SetFullscreenButtonState(state ButtonState) Window {
	w.options.FullscreenButtonState = state
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setFullscreenButtonState(state)
		})
	}
	return w
}

// Flash flashes the window's taskbar button/icon.
// Useful to indicate that attention is required. On Windows this flashes the
// taskbar button; on macOS it bounces the app's Dock icon (Linux: no-op).
func (w *WebviewWindow) Flash(enabled bool) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.flash(enabled)
	})
}

// IsMinimised returns true if the window is minimised
func (w *WebviewWindow) IsMinimised() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isMinimised)
}

// IsVisible returns true if the window is visible
func (w *WebviewWindow) IsVisible() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isVisible)
}

// IsMaximised returns true if the window is maximised
func (w *WebviewWindow) IsMaximised() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isMaximised)
}

// Size returns the size of the window
func (w *WebviewWindow) Size() (int, int) {
	if w.impl == nil || w.isDestroyed() {
		return 0, 0
	}
	var width, height int
	InvokeSync(func() {
		width, height = w.impl.size()
	})
	return width, height
}

// IsFocused returns true if the window is currently focused
func (w *WebviewWindow) IsFocused() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isFocused)
}

// IsFullscreen returns true if the window is fullscreen
func (w *WebviewWindow) IsFullscreen() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isFullscreen)
}

// SetBackgroundColour sets the background colour of the window
func (w *WebviewWindow) SetBackgroundColour(colour RGBA) Window {
	w.options.BackgroundColour = colour
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setBackgroundColour(colour)
		})
	}
	return w
}

func (w *WebviewWindow) HandleMessage(message string) {
	// Check for special messages
	switch true {
	case message == "wails:drag":
		if w.notchWindow != nil {
			return
		}
		if !w.IsFullscreen() {
			InvokeSync(func() {
				err := w.startDrag()
				if err != nil {
					w.Error("failed to start drag: %w", err)
				}
			})
		}
	case message == "wails:drag:doubleclick":
		if w.notchWindow != nil {
			return
		}
		w.handleTitlebarDoubleClick()
	case strings.HasPrefix(message, "wails:resize:"):
		if !w.IsFullscreen() {
			sl := strings.Split(message, ":")
			if len(sl) != 3 {
				w.Error("unknown message returned from dispatcher: %s", message)
				return
			}
			err := w.startResize(sl[2])
			if err != nil {
				w.Error("%w", err)
			}
		}
	case strings.HasPrefix(message, "wails:non-client-region:"):
		message = strings.Replace(message, "wails:non-client-region:", "", 1)
		w.handleNonClientRegionMessage(message)
	case message == "wails:runtime:ready":
		w.emit(events.Common.WindowRuntimeReady)
		w.pendingJSMutex.Lock()
		w.runtimeLoaded = true
		pending := w.pendingJS
		w.pendingJS = nil
		w.pendingJSMutex.Unlock()
		w.SetResizable(!w.options.DisableResize)
		for _, js := range pending {
			InvokeSync(func() {
				w.impl.execJS(js)
			})
		}
	case strings.HasPrefix(message, "wails:event:emit:"):
		// Forward an event from a page that can't reach the modern HTTP
		// runtime (e.g. an InitialHTML pop-up loaded with `baseURL:nil`
		// where `window.location.origin` is "null" and fetch fails). Sent
		// as `wails:event:emit:<event-name>`; bare names only (no payload).
		// Enough for the updater window's user-action buttons; pages that
		// need to send structured data should use the full runtime.
		//
		// Gated on WebviewWindowOptions.AllowSimpleEventEmit so a page
		// loaded into a webview cannot synthesise host-side custom events
		// unless its owning code explicitly opted in. See the comment on
		// that field for the threat model.
		if !w.options.AllowSimpleEventEmit {
			w.Error("wails:event:emit received but AllowSimpleEventEmit is not set on this window: %v", message)
			return
		}
		name := strings.TrimPrefix(message, "wails:event:emit:")
		if name == "" {
			w.Error("empty event name in wails:event:emit")
			return
		}
		evt := &CustomEvent{Name: name, Sender: w.Name()}
		globalApplication.Event.EmitEvent(evt)
	default:
		w.Error("unknown message sent via 'invoke' on frontend: %v", message)
	}
}

func (w *WebviewWindow) handleNonClientRegionMessage(payload string) {
	var message nonClientHitTestRegionsMessage
	if err := json.Unmarshal([]byte(payload), &message); err != nil {
		w.Error("failed to parse non-client regions: %w", err)
		return
	}

	regions := make([]nonClientHitTestRegion, 0, len(message.Regions))
	for i, region := range message.Regions {
		normalised, err := normaliseNonClientHitTestRegion(region)
		if err != nil {
			w.Error("region %d: %w", i, err)
			continue
		}
		regions = append(regions, normalised)
	}

	InvokeSync(func() {
		w.impl.setNonClientHitTestRegions(regions)
	})
}

func normaliseNonClientHitTestRegion(region nonClientHitTestRegion) (nonClientHitTestRegion, error) {
	if region.Right <= region.Left || region.Bottom <= region.Top {
		return nonClientHitTestRegion{}, fmt.Errorf("invalid rectangle")
	}

	kind := nonClientHitTestKind(strings.ToLower(string(region.Kind)))
	switch kind {
	case nonClientHitTestKindCaption,
		nonClientHitTestKindMinimize,
		nonClientHitTestKindMaximize,
		nonClientHitTestKindClose:
		region.Kind = kind
		return region, nil
	default:
		return nonClientHitTestRegion{}, fmt.Errorf("unknown region kind %q", region.Kind)
	}
}

func (w *WebviewWindow) startResize(border string) error {
	if w.impl == nil || w.isDestroyed() {
		return nil
	}
	return InvokeSyncWithResult(func() error {
		return w.impl.startResize(border)
	})
}

// Center centers the window on the screen
func (w *WebviewWindow) Center() {
	if w.impl == nil || w.isDestroyed() {
		w.options.InitialPosition = WindowCentered
		return
	}
	InvokeSync(w.impl.center)
}

// OnWindowEvent registers a callback for the given window event
func (w *WebviewWindow) OnWindowEvent(
	eventType events.WindowEventType,
	callback func(event *WindowEvent),
) func() {
	eventID := uint(eventType)
	windowEventListener := &WindowEventListener{
		callback: callback,
	}
	w.eventListenersLock.Lock()
	w.eventListeners[eventID] = append(w.eventListeners[eventID], windowEventListener)
	w.eventListenersLock.Unlock()
	if w.impl != nil {
		w.impl.on(eventID)
	}

	return func() {
		// Check if eventListener is already locked
		w.eventListenersLock.Lock()
		w.eventListeners[eventID] = slices.DeleteFunc(w.eventListeners[eventID], func(l *WindowEventListener) bool {
			return l == windowEventListener
		})
		w.eventListenersLock.Unlock()
	}
}

// RegisterHook registers a hook for the given window event
func (w *WebviewWindow) RegisterHook(
	eventType events.WindowEventType,
	callback func(event *WindowEvent),
) func() {
	eventID := uint(eventType)
	w.eventHooksLock.Lock()
	defer w.eventHooksLock.Unlock()
	windowEventHook := &WindowEventListener{
		callback: callback,
	}
	w.eventHooks[eventID] = append(w.eventHooks[eventID], windowEventHook)

	return func() {
		w.eventHooksLock.Lock()
		defer w.eventHooksLock.Unlock()
		w.eventHooks[eventID] = slices.DeleteFunc(w.eventHooks[eventID], func(l *WindowEventListener) bool {
			return l == windowEventHook
		})
	}
}

func (w *WebviewWindow) HandleWindowEvent(id uint) {
	// Get hooks
	w.eventHooksLock.RLock()
	hooks := w.eventHooks[id]
	w.eventHooksLock.RUnlock()

	// Create new WindowEvent
	thisEvent := NewWindowEvent()

	for _, thisHook := range hooks {
		thisHook.callback(thisEvent)
		if thisEvent.IsCancelled() {
			return
		}
	}

	// Copy the w.eventListeners
	w.eventListenersLock.RLock()
	var tempListeners = slices.Clone(w.eventListeners[id])
	w.eventListenersLock.RUnlock()

	for _, listener := range tempListeners {
		go func() {
			if thisEvent.IsCancelled() {
				return
			}
			defer handlePanic()
			listener.callback(thisEvent)
		}()
	}
	w.dispatchWindowEvent(id)
}

// Width returns the width of the window
func (w *WebviewWindow) Width() int {
	if w.impl == nil || w.isDestroyed() {
		return 0
	}
	return InvokeSyncWithResult(w.impl.width)
}

// Height returns the height of the window
func (w *WebviewWindow) Height() int {
	if w.impl == nil || w.isDestroyed() {
		return 0
	}
	return InvokeSyncWithResult(w.impl.height)
}

// PhysicalBounds returns the physical bounds of the window
func (w *WebviewWindow) PhysicalBounds() Rect {
	if w.impl == nil || w.isDestroyed() {
		return Rect{}
	}
	var rect Rect
	InvokeSync(func() {
		rect = w.impl.physicalBounds()
	})
	return rect
}

// SetPhysicalBounds sets the physical bounds of the window
func (w *WebviewWindow) SetPhysicalBounds(physicalBounds Rect) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.setPhysicalBounds(physicalBounds)
	})
}

// Bounds returns the DIP bounds of the window
func (w *WebviewWindow) Bounds() Rect {
	if w.impl == nil || w.isDestroyed() {
		return Rect{}
	}
	var rect Rect
	InvokeSync(func() {
		rect = w.impl.bounds()
	})
	return rect
}

// SetBounds sets the DIP bounds of the window
func (w *WebviewWindow) SetBounds(bounds Rect) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.setBounds(bounds)
	})
}

// Position returns the absolute position of the window
func (w *WebviewWindow) Position() (int, int) {
	if w.impl == nil || w.isDestroyed() {
		return 0, 0
	}
	var x, y int
	InvokeSync(func() {
		x, y = w.impl.position()
	})
	return x, y
}

// SetPosition sets the absolute position of the window.
func (w *WebviewWindow) SetPosition(x int, y int) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.setPosition(x, y)
	})
}

// SetScreen moves the window to the center of the given screen's WorkArea.
// If called before Run() (impl is nil), the screen is stored for deferred application.
func (w *WebviewWindow) SetScreen(screen *Screen) Window {
	if screen == nil {
		return w
	}
	w.options.Screen = screen
	if w.impl == nil || w.isDestroyed() {
		return w
	}
	InvokeSync(func() {
		w.impl.centerOnScreen(screen)
	})
	return w
}

// RelativePosition returns the position of the window relative to the screen WorkArea on which it is
func (w *WebviewWindow) RelativePosition() (int, int) {
	if w.impl == nil || w.isDestroyed() {
		return 0, 0
	}
	var x, y int
	InvokeSync(func() {
		x, y = w.impl.relativePosition()
	})
	return x, y
}

// SetRelativePosition sets the position of the window relative to the screen WorkArea on which it is.
func (w *WebviewWindow) SetRelativePosition(x, y int) Window {
	w.options.X = x
	w.options.Y = y
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setRelativePosition(x, y)
		})
	}
	return w
}

func (w *WebviewWindow) destroy() {
	if w.impl == nil || w.isDestroyed() {
		return
	}

	// Cancel all pending async calls for this window
	if globalApplication.messageProcessor != nil {
		globalApplication.messageProcessor.CancelWindowCalls(w.id)
	}

	// Cancel the callbacks
	for _, cancelFunc := range w.cancellers {
		cancelFunc()
	}

	InvokeSync(w.impl.destroy)
}

// Reload reloads the page assets
func (w *WebviewWindow) Reload() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.reload)
}

// ForceReload forces the window to reload the page assets
func (w *WebviewWindow) ForceReload() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.forceReload)
}

// ToggleFullscreen toggles the window between fullscreen and normal
func (w *WebviewWindow) ToggleFullscreen() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		if w.IsFullscreen() {
			w.UnFullscreen()
		} else {
			w.Fullscreen()
		}
	})
}

// ToggleMaximise toggles the window between maximised and normal
func (w *WebviewWindow) ToggleMaximise() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		if w.IsMaximised() {
			w.UnMaximise()
		} else {
			w.Maximise()
		}
	})
}

// ToggleFrameless toggles the window between frameless and normal
func (w *WebviewWindow) ToggleFrameless() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.SetFrameless(!w.options.Frameless)
	})
}

func (w *WebviewWindow) OpenDevTools() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.openDevTools)
}

// ZoomReset resets the zoom level of the webview content to 100%
func (w *WebviewWindow) ZoomReset() Window {
	if w.impl != nil {
		InvokeSync(w.impl.zoomReset)
	}
	return w
}

// ZoomIn increases the zoom level of the webview content
func (w *WebviewWindow) ZoomIn() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.zoomIn)
}

// ZoomOut decreases the zoom level of the webview content
func (w *WebviewWindow) ZoomOut() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.zoomOut)
}

// Close closes the window
func (w *WebviewWindow) Close() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.emit(events.Common.WindowClosing)
	})
}

func (w *WebviewWindow) Zoom() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.zoom)
}

// SetHTML sets the HTML of the window to the given html string.
func (w *WebviewWindow) SetHTML(html string) Window {
	w.options.HTML = html
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setHTML(html)
		})
	}
	return w
}

// Minimise minimises the window.
func (w *WebviewWindow) Minimise() Window {
	if w.impl == nil || w.isDestroyed() {
		w.options.StartState = WindowStateMinimised
		return w
	}
	if !w.IsMinimised() {
		InvokeSync(w.impl.minimise)
	}
	return w
}

// Maximise maximises the window. Min/Max size constraints are disabled.
func (w *WebviewWindow) Maximise() Window {
	if w.impl == nil || w.isDestroyed() {
		w.options.StartState = WindowStateMaximised
		return w
	}
	if !w.IsMaximised() {
		w.DisableSizeConstraints()
		InvokeSync(w.impl.maximise)
	}
	return w
}

// UnMinimise un-minimises the window. Min/Max size constraints are re-enabled.
func (w *WebviewWindow) UnMinimise() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	if w.IsMinimised() {
		InvokeSync(w.impl.unminimise)
	}
}

// UnMaximise un-maximises the window. Min/Max size constraints are re-enabled.
func (w *WebviewWindow) UnMaximise() {
	if w.IsMaximised() {
		w.EnableSizeConstraints()
		InvokeSync(w.impl.unmaximise)
	}
}

// UnFullscreen un-fullscreens the window. Min/Max size constraints are re-enabled.
func (w *WebviewWindow) UnFullscreen() {
	if w.IsFullscreen() {
		w.EnableSizeConstraints()
		InvokeSync(w.impl.unfullscreen)
	}
}

// Restore restores the window to its previous state if it was previously minimised, maximised or fullscreen.
func (w *WebviewWindow) Restore() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		if w.IsMinimised() {
			w.UnMinimise()
		} else if w.IsFullscreen() {
			w.UnFullscreen()
		} else if w.IsMaximised() {
			w.UnMaximise()
		}
	})
}

func (w *WebviewWindow) DisableSizeConstraints() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		if !w.constraintsSaved {
			w.savedMinWidth = w.options.MinWidth
			w.savedMinHeight = w.options.MinHeight
			w.savedMaxWidth = w.options.MaxWidth
			w.savedMaxHeight = w.options.MaxHeight
			w.constraintsSaved = true
		}
		if w.options.MinWidth > 0 || w.options.MinHeight > 0 {
			w.impl.setMinSize(0, 0)
		}
		if w.options.MaxWidth > 0 || w.options.MaxHeight > 0 {
			w.impl.setMaxSize(0, 0)
		}
	})
}

func (w *WebviewWindow) restoreSavedSizeConstraintOptions() bool {
	if !w.constraintsSaved {
		return false
	}
	w.options.MinWidth = w.savedMinWidth
	w.options.MinHeight = w.savedMinHeight
	w.options.MaxWidth = w.savedMaxWidth
	w.options.MaxHeight = w.savedMaxHeight
	w.constraintsSaved = false
	return true
}

func (w *WebviewWindow) EnableSizeConstraints() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.restoreSavedSizeConstraintOptions()
		if w.options.MinWidth > 0 || w.options.MinHeight > 0 {
			w.SetMinSize(w.options.MinWidth, w.options.MinHeight)
		}
		if w.options.MaxWidth > 0 || w.options.MaxHeight > 0 {
			w.SetMaxSize(w.options.MaxWidth, w.options.MaxHeight)
		}
	})
}

// GetScreen returns the screen that the window is on
func (w *WebviewWindow) GetScreen() (*Screen, error) {
	if w.impl == nil || w.isDestroyed() {
		return nil, nil
	}
	return InvokeSyncWithResultAndError(w.impl.getScreen)
}

// SetFrameless removes the window frame and title bar
func (w *WebviewWindow) SetFrameless(frameless bool) Window {
	w.options.Frameless = frameless
	if w.impl != nil {
		InvokeSync(func() {
			w.impl.setFrameless(frameless)
		})
	}
	return w
}

// Event delivery templates.
//
// All three keep the existing guard against the runtime not being mounted yet
// (during page reload WindowLoadFinished can fire before dispatchWailsEvent
// exists), and all three call the same public dispatchWailsEvent entry point,
// so no runtime JS or third-party page code has to change.
// Whether an event can be delivered synchronously depends on whether an
// earlier event for the same window is still being fetched. That decision is
// made in JavaScript rather than in Go, deliberately: evals execute serially on
// the UI thread in the order they were enqueued, so `w.__eq` is observed in
// delivery order and needs no locking. Deciding it in Go would require holding
// a lock across the ExecJS main-thread hop, which is the same shape as the
// deadlock documented in transport_event_ipc.go.
//
// Both templates terminate the chain with a catch. Without it a single throwing
// listener would leave `w.__eq` permanently rejected and silently stop every
// later event for that window.
const (
	// inline: small enough to splice directly. Dispatches synchronously unless
	// a fetch is already outstanding, in which case it queues behind it so it
	// cannot overtake.
	inlineEventJS = "if(window._wails&&window._wails.dispatchWailsEvent){var w=window._wails;" +
		"if(w.__eq){w.__eq=w.__eq.then(function(){w.dispatchWailsEvent(%s);}).catch(function(){});}" +
		"else{w.dispatchWailsEvent(%[1]s);}}"

	// ref: the payload is parked host-side; fetch it over the asset server
	// rather than passing it through evaluateJavaScript. Creating w.__eq is
	// what makes every subsequent event for this window queue behind it.
	refEventJS = "if(window._wails&&window._wails.dispatchWailsEvent){var w=window._wails;" +
		"w.__eq=(w.__eq||Promise.resolve()).then(function(){" +
		"return fetch(%q,{cache:'no-store'}).then(function(r){return r.json();})" +
		".then(function(e){w.dispatchWailsEvent(e);});}).catch(function(){});}"
)

func (w *WebviewWindow) DispatchWailsEvent(event *CustomEvent) {
	if w.impl == nil || w.isDestroyed() {
		return
	}

	payload := event.ToJSON()

	// Large payloads are delivered by reference. Splicing them into the eval
	// source makes WebKit transfer them out-of-line via shared memory, and the
	// host process retains ownership of those regions while the app keeps
	// emitting — 100 ev/s of 1 MB events reached 11.5 GB before this change.
	// See event_payload_store.go for the measurements.
	if len(payload) > maxInlineEventPayload {
		if store := globalApplication.eventPayloads; store != nil {
			if id, ok := store.put(w.id, []byte(payload)); ok {
				if w.enqueueEventJS(fmt.Sprintf(refEventJS, eventPayloadPath+id)) {
					return
				}
				// The window closed between put and enqueue, so nothing will
				// ever fetch this. dropWindow has already run by then and
				// cannot see it, so reclaim it here rather than leaving it for
				// the TTL sweep.
				store.take(id, w.id)
				return
			}
		}
		// Store unavailable, full, or shutting down: fall back to inline. This
		// event pays the out-of-line retention cost, which beats dropping it.
	}

	w.enqueueEventJS(fmt.Sprintf(inlineEventJS, payload))
}

// eventQueueCapacity bounds how many events may be waiting for the UI thread
// before an emitting goroutine is made to wait. Typical apps emit far below
// this, so the queue stays empty and the bound never engages; it exists to stop
// a runaway producer from growing the queue without limit.
//
// A main-thread emitter is never blocked by it — see enqueueEventJS.
//
// Chosen by measurement (v3/tests/event-performance, macOS, 25s runs). Ordering
// held at every size, and 5000 ev/s was sustained at every size, so the only
// thing that moved was tail latency, which grows with depth because an event
// waits behind whatever is already queued:
//
//	capacity   5000 ev/s        mixed-source p99
//	      16   5000/s, 0 inv    179us
//	      64   4991/s, 0 inv    257us
//	     256   4995/s, 0 inv    329us
//	    1024   5000/s, 0 inv    427us
//
// Shallow is better on both counts, so this is deliberately small: enough to
// absorb a burst without making a producer wait, not so much that an event can
// sit behind a long backlog. Raise it only with a measurement that shows a
// producer being throttled.
const eventQueueCapacity = 64

// enqueueEventJS appends an event's JavaScript to the window's queue and makes
// sure a drain is scheduled.
//
// This exists because dispatchOnMainThread runs inline when the caller is
// already on the UI thread. Without a queue, an event emitted from the UI
// thread executes its eval immediately while an event emitted moments earlier
// from a goroutine is still sitting in the dispatch queue, so the later event
// overtakes the earlier one. TestEventFromMainThreadDoesNotOvertakeQueuedEvent
// reproduces it deterministically.
//
// Appending under a mutex makes the queue the single ordering authority: the
// order events are added is the order one drainer emits them, whichever thread
// each came from.
//
// Returns false when the queue has been closed because the window is going
// away, so a caller that has already parked a payload can reclaim it.
func (w *WebviewWindow) enqueueEventJS(js string) bool {
	// Whether we are on the UI thread decides if we may block below, so it must
	// be read before taking the queue lock.
	onMainThread := globalApplication != nil &&
		globalApplication.impl != nil &&
		globalApplication.impl.isOnMainThread()

	w.eventQueueMu.Lock()
	if w.eventQueueCond == nil {
		w.eventQueueCond = sync.NewCond(&w.eventQueueMu)
	}

	// Backpressure for goroutine emitters only. The UI thread is the drainer,
	// so blocking it on a full queue could never be relieved — it would be a
	// guaranteed deadlock rather than a slow path. It is allowed past the bound
	// instead, and the drain it schedules runs inline immediately afterwards.
	for !onMainThread && !w.eventQueueClosed && len(w.eventQueue) >= eventQueueCapacity {
		w.eventQueueCond.Wait()
	}
	if w.eventQueueClosed {
		w.eventQueueMu.Unlock()
		return false
	}

	w.eventQueue = append(w.eventQueue, js)
	if n := len(w.eventQueue); n > w.eventQueueHigh {
		w.eventQueueHigh = n
	}

	scheduleDrain := !w.eventDraining
	if scheduleDrain {
		w.eventDraining = true
	}
	w.eventQueueMu.Unlock()

	if scheduleDrain {
		// Runs inline when already on the UI thread, which is what lets a
		// main-thread emitter make progress past the bound.
		InvokeAsync(w.drainEventQueue)
	}
	return true
}

// drainEventQueue empties the queue in order. It always runs on the UI thread,
// and only one drain is ever in flight per window.
func (w *WebviewWindow) drainEventQueue() {
	for {
		w.eventQueueMu.Lock()
		if len(w.eventQueue) == 0 || w.eventQueueClosed {
			w.eventDraining = false
			w.eventQueueMu.Unlock()
			return
		}
		// Take the whole batch rather than popping one at a time: repeatedly
		// reslicing the front would keep the original backing array alive.
		batch := w.eventQueue
		w.eventQueue = nil
		w.eventQueueCond.Broadcast() // space is available again
		w.eventQueueMu.Unlock()

		for _, js := range batch {
			if w.isDestroyed() {
				return
			}
			w.ExecJS(js)
		}
	}
}

// closeEventQueue discards anything still queued and wakes blocked emitters.
func (w *WebviewWindow) closeEventQueue() {
	w.eventQueueMu.Lock()
	w.eventQueueClosed = true
	w.eventQueue = nil
	if w.eventQueueCond != nil {
		w.eventQueueCond.Broadcast()
	}
	w.eventQueueMu.Unlock()
}

// eventQueueHighWater reports the deepest the window's event queue has been.
// Diagnostics for tests; deliberately unexported so it is not public API.
func (w *WebviewWindow) eventQueueHighWater() int {
	w.eventQueueMu.Lock()
	defer w.eventQueueMu.Unlock()
	return w.eventQueueHigh
}

func (w *WebviewWindow) dispatchWindowEvent(id uint) {
	// TODO: Make this more efficient by keeping a list of which events have been registered
	// and only dispatching those.
	jsEvent := &CustomEvent{
		Name: events.JSEvent(id),
	}
	w.DispatchWailsEvent(jsEvent)
}

func (w *WebviewWindow) Info(message string, args ...any) {
	var messageArgs []interface{}
	messageArgs = append(messageArgs, args...)
	messageArgs = append(messageArgs, "sender", w.Name())
	globalApplication.info(message, messageArgs...)
}

func (w *WebviewWindow) Error(message string, args ...any) {
	args = append([]any{w.Name()}, args...)
	globalApplication.error("in window '%s': "+message, args...)
}

func (w *WebviewWindow) handleDragAndDropMessage(filenames []string, dropTarget *DropTargetDetails) {
	thisEvent := NewWindowEvent()
	ctx := newWindowEventContext()
	ctx.setDroppedFiles(filenames)
	if dropTarget != nil {
		ctx.setDropTargetDetails(dropTarget)
	}
	thisEvent.ctx = ctx

	listeners := w.eventListeners[uint(events.Common.WindowFilesDropped)]
	for _, listener := range listeners {
		if listener == nil {
			continue
		}
		listener.callback(thisEvent)
	}
}

func (w *WebviewWindow) OpenContextMenu(data *ContextMenuData) {
	// try application level context menu
	menu, ok := globalApplication.ContextMenu.Get(data.Id)
	if !ok {
		w.Error("no context menu found for id: %s", data.Id)
		return
	}
	menu.setContextData(data)
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.openContextMenu(menu.Menu, data)
	})
}

// NativeWindow returns the platform-specific native window handle
func (w *WebviewWindow) NativeWindow() unsafe.Pointer {
	if w.impl == nil || w.isDestroyed() {
		return nil
	}
	return w.impl.nativeWindow()
}

// AttachModal attaches a modal window to this window, presenting it as a sheet on macOS.
func (w *WebviewWindow) AttachModal(modalWindow Window) {
	if w.impl == nil || w.isDestroyed() {
		return
	}

	modalWebviewWindow, ok := modalWindow.(*WebviewWindow)
	if !ok || modalWebviewWindow == nil {
		return
	}

	InvokeSync(func() {
		w.impl.attachModal(modalWebviewWindow)
	})
}

// shouldUnconditionallyClose returns whether the window should close unconditionally
func (w *WebviewWindow) shouldUnconditionallyClose() bool {
	return atomic.LoadUint32(&w.unconditionallyClose) != 0
}

func (w *WebviewWindow) Focus() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.focus)
}

func (w *WebviewWindow) emit(eventType events.WindowEventType) {
	windowEvents <- &windowEvent{
		WindowID: w.id,
		EventID:  uint(eventType),
	}
}

func (w *WebviewWindow) startDrag() error {
	if w.impl == nil || w.isDestroyed() {
		return nil
	}
	return InvokeSyncWithError(w.impl.startDrag)
}

func (w *WebviewWindow) Print() error {
	if w.impl == nil || w.isDestroyed() {
		return nil
	}
	return InvokeSyncWithError(w.impl.print)
}

func (w *WebviewWindow) SetEnabled(enabled bool) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.setEnabled(enabled)
	})
}

func (w *WebviewWindow) processKeyBinding(acceleratorString string) bool {
	// Check menu bindings
	if w.menuBindings != nil {
		w.menuBindingsLock.RLock()
		defer w.menuBindingsLock.RUnlock()
		if menuItem := w.menuBindings[acceleratorString]; menuItem != nil {
			menuItem.handleClick()
			return true
		}
	}

	// Check key bindings
	if w.keyBindings != nil {
		w.keyBindingsLock.RLock()
		defer w.keyBindingsLock.RUnlock()
		if callback := w.keyBindings[acceleratorString]; callback != nil {
			// Execute callback
			go func() {
				defer handlePanic()
				callback(w)
			}()
			return true
		}
	}

	return globalApplication.KeyBinding.Process(acceleratorString, w)
}

func (w *WebviewWindow) HandleKeyEvent(acceleratorString string) {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(func() {
		w.impl.handleKeyEvent(acceleratorString)
	})
}

func (w *WebviewWindow) isDestroyed() bool {
	w.destroyedLock.RLock()
	defer w.destroyedLock.RUnlock()
	return w.destroyed
}

func (w *WebviewWindow) RegisterKeyBinding(binding string, callback func(window Window)) *WebviewWindow {
	acc, err := parseAccelerator(binding)
	if err != nil {
		globalApplication.error("invalid keybinding: %w", err)
		return w
	}
	w.keyBindingsLock.Lock()
	defer w.keyBindingsLock.Unlock()
	if w.keyBindings == nil {
		w.keyBindings = make(map[string]func(Window))
	}
	w.keyBindings[acc.String()] = callback
	return w
}

func (w *WebviewWindow) removeMenuBinding(a *accelerator) {
	w.menuBindingsLock.Lock()
	defer w.menuBindingsLock.Unlock()
	w.menuBindings[a.String()] = nil
}

func (w *WebviewWindow) addMenuBinding(a *accelerator, menuItem *MenuItem) {
	w.menuBindingsLock.Lock()
	defer w.menuBindingsLock.Unlock()
	w.menuBindings[a.String()] = menuItem
}

func (w *WebviewWindow) IsIgnoreMouseEvents() bool {
	if w.impl == nil || w.isDestroyed() {
		return false
	}
	return InvokeSyncWithResult(w.impl.isIgnoreMouseEvents)
}

func (w *WebviewWindow) SetIgnoreMouseEvents(ignore bool) Window {
	w.options.IgnoreMouseEvents = ignore
	if w.impl == nil || w.isDestroyed() {
		return w
	}
	InvokeSync(func() {
		w.impl.setIgnoreMouseEvents(ignore)
	})
	return w
}

func (w *WebviewWindow) cut() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.cut()
}

func (w *WebviewWindow) copy() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.copy()
}

func (w *WebviewWindow) paste() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.paste()
}

func (w *WebviewWindow) selectAll() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.selectAll()
}

func (w *WebviewWindow) undo() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.undo()
}

func (w *WebviewWindow) delete() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.delete()
}

func (w *WebviewWindow) redo() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	w.impl.redo()
}

// ShowMenuBar shows the menu bar for the window.
func (w *WebviewWindow) ShowMenuBar() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.showMenuBar)
}

// HideMenuBar hides the menu bar for the window.
func (w *WebviewWindow) HideMenuBar() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.hideMenuBar)
}

// ToggleMenuBar toggles the menu bar for the window.
func (w *WebviewWindow) ToggleMenuBar() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.toggleMenuBar)
}

func (w *WebviewWindow) InitiateFrontendDropProcessing(filenames []string, x int, y int) {
	if w.impl == nil || w.isDestroyed() {
		return
	}

	filenamesJSON, err := json.Marshal(filenames)
	if err != nil {
		w.Error("Error marshalling filenames for drop processing: %s", err)
		return
	}

	jsCall := fmt.Sprintf(
		"window._wails.handlePlatformFileDrop(%s, %d, %d);",
		string(filenamesJSON),
		x,
		y,
	)

	w.pendingJSMutex.Lock()
	if !w.runtimeLoaded {
		w.pendingJS = append(w.pendingJS, jsCall)
		w.pendingJSMutex.Unlock()
		return
	}
	w.pendingJSMutex.Unlock()

	InvokeSync(func() {
		w.impl.execJS(jsCall)
	})
}

// HandleDragEnter is called when drag enters the window (Linux only, since GTK intercepts drag events)
func (w *WebviewWindow) HandleDragEnter() {
	if w.impl == nil || w.isDestroyed() || !w.runtimeLoaded {
		return
	}

	// Reset drag hover state for new drag session
	dragHover.lastSentX = 0
	dragHover.lastSentY = 0

	w.impl.execJS("window._wails.handleDragEnter();")
}

// Drag hover throttle state
var dragHover struct {
	lastSentX int
	lastSentY int
}

// HandleDragOver is called during drag-motion to update hover state in JS
// This is called from the GTK main thread, so we can call execJS directly
func (w *WebviewWindow) HandleDragOver(x int, y int) {
	if w.impl == nil || w.isDestroyed() || !w.runtimeLoaded {
		return
	}

	// Throttle: only send if moved at least 5 pixels
	dx := x - dragHover.lastSentX
	dy := y - dragHover.lastSentY
	if dx < 0 {
		dx = -dx
	}
	if dy < 0 {
		dy = -dy
	}
	if dx < 5 && dy < 5 {
		return
	}
	dragHover.lastSentX = x
	dragHover.lastSentY = y

	// Use platform-specific zero-alloc implementation if available
	if impl, ok := w.impl.(interface{ execJSDragOver(x, y int) }); ok {
		impl.execJSDragOver(x, y)
	} else {
		w.impl.execJS(fmt.Sprintf("window._wails.handleDragOver(%d,%d)", x, y))
	}
}

// HandleDragLeave is called when drag leaves the window
func (w *WebviewWindow) HandleDragLeave() {
	if w.impl == nil || w.isDestroyed() || !w.runtimeLoaded {
		return
	}

	// Don't use InvokeSync - execJS already handles main thread dispatch internally
	w.impl.execJS("window._wails.handleDragLeave();")
}

// SnapAssist triggers the Windows Snap Assist feature by simulating Win+Z key combination.
// On Windows, this opens the snap layout options. On Linux and macOS, this is a no-op.
func (w *WebviewWindow) SnapAssist() {
	if w.impl == nil || w.isDestroyed() {
		return
	}
	InvokeSync(w.impl.snapAssist)
}
