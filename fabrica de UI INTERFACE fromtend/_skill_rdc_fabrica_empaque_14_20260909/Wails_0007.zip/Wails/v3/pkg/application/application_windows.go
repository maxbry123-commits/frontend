//go:build windows && !server

package application

import (
	"errors"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"

	"github.com/wailsapp/wails/v3/internal/webview2/webviewloader"

	"github.com/wailsapp/wails/v3/internal/operatingsystem"

	"github.com/wailsapp/wails/v3/pkg/events"
	"github.com/wailsapp/wails/v3/pkg/w32"
)

var (
	wmTaskbarCreated = w32.RegisterWindowMessage(w32.MustStringToUTF16Ptr("TaskbarCreated"))
)

type windowsApp struct {
	parent *App

	windowClass w32.WNDCLASSEX
	instance    w32.HINSTANCE

	windowMap     map[w32.HWND]*windowsWebviewWindow
	windowMapLock sync.RWMutex

	systrayMap     map[w32.HMENU]*windowsSystemTray
	systrayMapLock sync.RWMutex

	mainThreadID         w32.HANDLE
	mainThreadWindowHWND w32.HWND

	// Windows hidden by application.Hide()
	hiddenWindows []*windowsWebviewWindow
	focusedWindow w32.HWND

	// system theme
	isCurrentlyDarkMode       bool
	isSystemCurrentlyDarkMode bool
	currentWindowID           uint

	// Restart taskbar flag
	restartingTaskbar atomic.Bool
}

func (m *windowsApp) isDarkMode() bool {
	return w32.IsCurrentlyDarkMode()
}

func (m *windowsApp) getAccentColor() string {
	accentColor, err := w32.GetAccentColor()
	if err != nil {
		m.parent.error("failed to get accent color: %w", err)
		return "rgb(0,122,255)"
	}

	return accentColor
}

func (m *windowsApp) isOnMainThread() bool {
	return m.mainThreadID == w32.GetCurrentThreadId()
}

func (m *windowsApp) GetFlags(options Options) map[string]any {
	if options.Flags == nil {
		options.Flags = make(map[string]any)
	}
	options.Flags["system"] = map[string]any{
		"resizeHandleWidth":  w32.GetSystemMetrics(w32.SM_CXSIZEFRAME),
		"resizeHandleHeight": w32.GetSystemMetrics(w32.SM_CYSIZEFRAME),
	}
	return options.Flags
}

func (m *windowsApp) getWindowForHWND(hwnd w32.HWND) *windowsWebviewWindow {
	m.windowMapLock.RLock()
	defer m.windowMapLock.RUnlock()
	return m.windowMap[hwnd]
}

func getNativeApplication() *windowsApp {
	return globalApplication.impl.(*windowsApp)
}

func (m *windowsApp) hide() {
	// Get the current focussed window
	m.focusedWindow = w32.GetForegroundWindow()

	// Iterate over all windows and hide them if they aren't already hidden
	for _, window := range m.windowMap {
		if window.isVisible() {
			// Add to hidden windows
			m.hiddenWindows = append(m.hiddenWindows, window)
			window.hide()
		}
	}
	// Switch focus to the next application
	hwndNext := w32.GetWindow(m.mainThreadWindowHWND, w32.GW_HWNDNEXT)
	w32.SetForegroundWindow(hwndNext)
}

func (m *windowsApp) show() {
	// Iterate over all windows and show them if they were previously hidden
	for _, window := range m.hiddenWindows {
		window.show()
	}
	// Show the foreground window
	w32.SetForegroundWindow(m.focusedWindow)
}

func (m *windowsApp) on(_ uint) {
}

func (m *windowsApp) setIcon(_ []byte) {
}

func (m *windowsApp) name() string {
	// appName := C.getAppName()
	// defer C.free(unsafe.Pointer(appName))
	// return C.GoString(appName)
	return ""
}

func (m *windowsApp) getCurrentWindowID() uint {
	return m.currentWindowID
}

func (m *windowsApp) setApplicationMenu(menu *Menu) {
	if menu == nil {
		// Create a default menu for windows
		menu = DefaultApplicationMenu()
	}
	menu.Update()

	m.parent.applicationMenu = menu
}

func (m *windowsApp) run() error {
	m.setupCommonEvents()
	for eventID := range m.parent.applicationEventListeners {
		m.on(eventID)
	}
	// EmitEvent application started event
	applicationEvents <- &ApplicationEvent{
		Id:  uint(events.Windows.ApplicationStarted),
		ctx: blankApplicationEventContext,
	}

	if len(os.Args) == 2 { // Case: program + 1 argument
		arg1 := os.Args[1]
		// Check if the argument is likely a URL from a custom protocol invocation
		if strings.Contains(arg1, "://") {
			m.parent.debug("Application launched with argument, potentially a URL from custom protocol", "url", arg1)
			eventContext := newApplicationEventContext()
			eventContext.setURL(arg1)
			applicationEvents <- &ApplicationEvent{
				Id:  uint(events.Common.ApplicationLaunchedWithUrl),
				ctx: eventContext,
			}
		} else {
			// If not a URL-like string, check for file association
			if m.parent.options.FileAssociations != nil {
				ext := filepath.Ext(arg1)
				if slices.Contains(m.parent.options.FileAssociations, ext) {
					m.parent.debug("Application launched with file via file association", "file", arg1)
					eventContext := newApplicationEventContext()
					eventContext.setOpenedWithFile(arg1)
					applicationEvents <- &ApplicationEvent{
						Id:  uint(events.Common.ApplicationOpenedWithFile),
						ctx: eventContext,
					}
				}
			}
		}
	} else if len(os.Args) > 2 {
		// Log if multiple arguments are passed, though typical protocol/file launch is a single arg.
		m.parent.debug("Application launched with multiple arguments", "args", os.Args[1:])
	}

	_ = m.runMainLoop()

	return nil
}

func (m *windowsApp) destroy() {
	if !globalApplication.shouldQuit() {
		return
	}
	globalApplication.cleanup()
	// destroy the main thread window
	w32.DestroyWindow(m.mainThreadWindowHWND)
	// Post a quit message to the main thread
	w32.PostQuitMessage(0)
}

func (m *windowsApp) init() {
	// Register the window class

	icon := w32.LoadIconWithResourceID(m.instance, w32.IDI_APPLICATION)

	m.windowClass.Size = uint32(unsafe.Sizeof(m.windowClass))
	m.windowClass.Style = w32.CS_HREDRAW | w32.CS_VREDRAW
	m.windowClass.WndProc = syscall.NewCallback(m.wndProc)
	m.windowClass.Instance = m.instance
	m.windowClass.Background = w32.COLOR_BTNFACE + 1
	m.windowClass.Icon = icon
	m.windowClass.Cursor = w32.LoadCursorWithResourceID(0, w32.IDC_ARROW)
	m.windowClass.ClassName = w32.MustStringToUTF16Ptr(m.parent.options.Windows.WndClass)
	m.windowClass.MenuName = nil
	m.windowClass.IconSm = icon

	if ret := w32.RegisterClassEx(&m.windowClass); ret == 0 {
		panic(syscall.GetLastError())
	}
	m.isCurrentlyDarkMode = w32.IsCurrentlyDarkMode()
	m.isSystemCurrentlyDarkMode = w32.IsSystemCurrentlyDarkMode()
}

func (m *windowsApp) wndProc(hwnd w32.HWND, msg uint32, wParam, lParam uintptr) uintptr {

	// Handle the invoke callback
	if msg == wmInvokeCallback {
		m.invokeCallback(wParam, lParam)
		return 0
	}

	// If the WndProcInterceptor is set in options, pass the message on
	if m.parent.options.Windows.WndProcInterceptor != nil {
		returnValue, shouldReturn := m.parent.options.Windows.WndProcInterceptor(hwnd, msg, wParam, lParam)
		if shouldReturn {
			return returnValue
		}
	}

	// Handle the main thread window
	// Quit the application if requested
	// Reprocess and cache screens when display settings change
	if hwnd == m.mainThreadWindowHWND {
		if msg == w32.WM_ENDSESSION || msg == w32.WM_DESTROY || msg == w32.WM_CLOSE {
			globalApplication.Quit()
		}
		if msg == w32.WM_DISPLAYCHANGE || (msg == w32.WM_SETTINGCHANGE && wParam == w32.SPI_SETWORKAREA) {
			err := m.processAndCacheScreens()
			if err != nil {
				m.parent.handleError(err)
			}
		}
	}

	switch msg {
	case w32.WM_HOTKEY:
		// A global shortcut fired. wParam holds the id we passed to
		// RegisterHotKey. Route it to the global shortcut manager.
		if app := globalApplication; app != nil && app.GlobalShortcut != nil {
			app.GlobalShortcut.dispatch(int(wParam))
		}
		return 0
	case wmTaskbarCreated:
		if m.restartingTaskbar.Load() {
			break
		}
		m.restartingTaskbar.Store(true)
		m.reshowSystrays()
		go func() {
			// 1 second debounce
			time.Sleep(1000)
			m.restartingTaskbar.Store(false)
		}()
	case w32.WM_SETTINGCHANGE:
		settingChanged := w32.UTF16PtrToString((*uint16)(unsafe.Pointer(lParam)))
		if settingChanged == "ImmersiveColorSet" {
			isDarkMode := w32.IsCurrentlyDarkMode()
			isSystemDarkMode := w32.IsSystemCurrentlyDarkMode()
			if isDarkMode != m.isCurrentlyDarkMode || isSystemDarkMode != m.isSystemCurrentlyDarkMode {
				m.isCurrentlyDarkMode = isDarkMode
				m.isSystemCurrentlyDarkMode = isSystemDarkMode

				eventContext := newApplicationEventContext()
				eventContext.setIsDarkMode(isDarkMode)
				applicationEvents <- &ApplicationEvent{
					Id:  uint(events.Windows.SystemThemeChanged),
					ctx: eventContext,
				}
			}
		}
		return 0
	case w32.WM_POWERBROADCAST:
		switch wParam {
		case w32.PBT_APMPOWERSTATUSCHANGE:
			applicationEvents <- newApplicationEvent(events.Windows.APMPowerStatusChange)
		case w32.PBT_APMSUSPEND:
			applicationEvents <- newApplicationEvent(events.Windows.APMSuspend)
		case w32.PBT_APMRESUMEAUTOMATIC:
			applicationEvents <- newApplicationEvent(events.Windows.APMResumeAutomatic)
		case w32.PBT_APMRESUMESUSPEND:
			applicationEvents <- newApplicationEvent(events.Windows.APMResumeSuspend)
		case w32.PBT_POWERSETTINGCHANGE:
			applicationEvents <- newApplicationEvent(events.Windows.APMPowerSettingChange)
		}
		return 0
	}

	if window, ok := m.windowMap[hwnd]; ok {
		return window.WndProc(msg, wParam, lParam)
	}

	m.systrayMapLock.Lock()
	systray, ok := m.systrayMap[hwnd]
	m.systrayMapLock.Unlock()
	if ok {
		return systray.wndProc(msg, wParam, lParam)
	}

	// Dispatch the message to the appropriate window

	return w32.DefWindowProc(hwnd, msg, wParam, lParam)
}

func (m *windowsApp) registerWindow(result *windowsWebviewWindow) {
	m.windowMapLock.Lock()
	m.windowMap[result.hwnd] = result
	m.windowMapLock.Unlock()
}

func (m *windowsApp) registerSystemTray(result *windowsSystemTray) {
	m.systrayMapLock.Lock()
	defer m.systrayMapLock.Unlock()
	m.systrayMap[result.hwnd] = result
}

func (m *windowsApp) unregisterSystemTray(result *windowsSystemTray) {
	m.systrayMapLock.Lock()
	defer m.systrayMapLock.Unlock()
	delete(m.systrayMap, result.hwnd)
}

func (m *windowsApp) unregisterWindow(w *windowsWebviewWindow) {
	m.windowMapLock.Lock()
	delete(m.windowMap, w.hwnd)
	m.windowMapLock.Unlock()

	// If this was the last window...
	if len(m.windowMap) == 0 && !m.parent.options.Windows.DisableQuitOnLastWindowClosed {
		w32.PostQuitMessage(0)
	}
}

func (m *windowsApp) reshowSystrays() {
	m.systrayMapLock.Lock()
	defer m.systrayMapLock.Unlock()
	for _, systray := range m.systrayMap {
		if _, err := systray.show(); err != nil {
			globalApplication.warning("failed to re-add system tray icon: %v", err)
		}
	}
}

func setupDPIAwareness() error {
	// https://learn.microsoft.com/en-us/windows/win32/hidpi/setting-the-default-dpi-awareness-for-a-process
	// https://learn.microsoft.com/en-us/windows/win32/hidpi/high-dpi-desktop-application-development-on-windows

	// Check if DPI awareness has already been set (e.g., via application manifest).
	// Windows only allows setting DPI awareness once per process - either via manifest
	// or API, not both. If already set, skip the API call to avoid "Access is denied" errors.
	// See: https://github.com/wailsapp/wails/issues/4803 and #4835

	// Prefer the newer GetThreadDpiAwarenessContext (Windows 10 1607+) over the older
	// GetProcessDpiAwareness (SHCORE) because a manifest entry with permonitorv2 sets the
	// context via SetProcessDpiAwarenessContext, which GetProcessDpiAwareness may not reflect.
	if w32.HasGetThreadDpiAwarenessContextFunc() && w32.HasAreDpiAwarenessContextsEqualFunc() {
		ctx := w32.GetThreadDpiAwarenessContext()
		if !w32.AreDpiAwarenessContextsEqual(ctx, w32.DPI_AWARENESS_CONTEXT_UNAWARE) {
			// DPI awareness already set (likely via manifest), skip API call
			return nil
		}
	} else if w32.HasGetProcessDpiAwarenessFunc() {
		awareness, err := w32.GetProcessDpiAwareness()
		if err == nil && awareness != w32.PROCESS_DPI_UNAWARE {
			// DPI awareness already set (likely via manifest), skip API call
			return nil
		}
	}

	if w32.HasSetProcessDpiAwarenessContextFunc() {
		// This is most recent version with the best results
		// supported beginning with Windows 10, version 1703
		return w32.SetProcessDpiAwarenessContext(w32.DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)
	}

	if w32.HasSetProcessDpiAwarenessFunc() {
		// Supported beginning with Windows 8.1
		return w32.SetProcessDpiAwareness(w32.PROCESS_PER_MONITOR_DPI_AWARE)
	}

	if w32.HasSetProcessDPIAwareFunc() {
		// If none of the above is supported, fallback to SetProcessDPIAware
		// which is supported beginning with Windows Vista
		return w32.SetProcessDPIAware()
	}

	return errors.New("no DPI awareness method supported")
}

func newPlatformApp(app *App) *windowsApp {

	// Force WebView2 visual hosting before any WebView2 environment is
	// initialised. This is the documented Microsoft workaround for the
	// "DPI-context-change hang" — most commonly seen when the Microsoft
	// Remote Desktop iOS client provisions a Retina-optimised virtual
	// monitor mid-session and every subsequent WebView2 controller call
	// blocks the UI thread for ~2 s on synchronous DComp re-marshal.
	// See WindowsOptions.UseVisualHosting for the full rationale.
	if app.options.Windows.UseVisualHosting {
		_ = os.Setenv("COREWEBVIEW2_FORCED_HOSTING_MODE",
			"COREWEBVIEW2_HOSTING_MODE_WINDOW_TO_VISUAL")
	}

	err := setupDPIAwareness()
	if err != nil {
		app.handleError(err)
	}

	result := &windowsApp{
		parent:     app,
		instance:   w32.GetModuleHandle(""),
		windowMap:  make(map[w32.HWND]*windowsWebviewWindow),
		systrayMap: make(map[w32.HWND]*windowsSystemTray),
	}

	err = result.processAndCacheScreens()
	if err != nil {
		app.handleFatalError(err)
	}

	result.init()
	result.initMainLoop()

	return result
}

func (a *App) logPlatformInfo() {
	var args []any
	args = append(args, "Go-WebView2Loader", webviewloader.UsingGoWebview2Loader)
	webviewVersion, err := webviewloader.GetAvailableCoreWebView2BrowserVersionString(
		a.options.Windows.WebviewBrowserPath,
	)
	if err != nil {
		args = append(args, "WebView2", "Error: "+err.Error())
	} else {
		args = append(args, "WebView2", webviewVersion)
	}

	osInfo, _ := operatingsystem.Info()
	args = append(args, osInfo.AsLogSlice()...)

	a.info("Platform Info:", args...)
}

func (a *App) platformEnvironment() map[string]any {
	result := map[string]any{}
	webviewVersion, _ := webviewloader.GetAvailableCoreWebView2BrowserVersionString(
		a.options.Windows.WebviewBrowserPath,
	)
	result["Go-WebView2Loader"] = webviewloader.UsingGoWebview2Loader
	result["WebView2"] = webviewVersion
	return result
}

func fatalHandler(errFunc func(error)) {
	w32.Fatal = errFunc
	return
}
