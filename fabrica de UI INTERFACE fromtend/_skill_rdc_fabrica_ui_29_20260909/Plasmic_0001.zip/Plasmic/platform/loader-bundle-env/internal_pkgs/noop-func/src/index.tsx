export default function NoopFunc() {}
