export const FIGMA = "";
