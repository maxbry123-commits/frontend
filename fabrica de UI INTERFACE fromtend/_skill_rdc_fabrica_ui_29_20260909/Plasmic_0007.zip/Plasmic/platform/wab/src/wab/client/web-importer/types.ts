import { WIError } from "@/wab/client/web-importer/errors";
import { SpecificityWithPosition } from "@/wab/client/web-importer/specificity";
import { VariantGroupType } from "@/wab/shared/Variants";

export interface WIRule {
  styles: Record<string, string>;
  selector: string;
  specificity: SpecificityWithPosition;
}

export type WISafeStyles = Record<string, string>;
export type WIUnsafeStyles = Record<string, string>;
export type WIUnsanitizedStyles = Record<string, string>;

export interface WIBaseVariant {
  type: "base";
}

export interface WIScreenVariant {
  type: typeof VariantGroupType.GlobalScreen;
  width: number;
}

export interface WIStyleVariant {
  type: "style";
  selectors: string[];
}

export type WIVariant = WIBaseVariant | WIScreenVariant | WIStyleVariant;

export interface WIVariantSettings {
  /** Unsanitized styles store the raw css styles applied on the element in the html without any transformation */
  unsanitizedStyles: WIUnsanitizedStyles;
  /** Css style props/values in correct format supported by Plasmic and that is not considered a site invariant such as color, paddingTop, paddingRight */
  safeStyles: WISafeStyles;
  /** Css style props/values that is considered a site invariant such as padding */
  unsafeStyles: WIUnsafeStyles;
  variantCombo: WIVariant[];
}

export interface WIBase {
  type: "container" | "text" | "svg" | "component" | "slot-target";
  tag: string;
  /**
   * Source HTML locator for each WI node to enrich WIErrors raised during parsing.
   */
  path: string;
  attrs: Record<string, string>;
  variantSettings: WIVariantSettings[];
}

export interface WIContainer extends WIBase {
  type: "container";
  children: WIElement[];
}

export interface WIText extends WIBase {
  type: "text";
  /**
   * The element's content as a nested structure for RichText content.
   */
  content: (string | WIText)[];
}

export interface WISVG extends WIBase {
  type: "svg";
  outerHtml: string;
  width: string;
  height: string;
}

export interface WIComponent extends WIBase {
  type: "component";
  component: string;
  /**
   * Optional projectId of the source project dependency.
   * When omitted, a local site will be used for lookup.
   */
  depProjectId?: string;
  props: Record<string, any>;
  slots: Record<string, WIElement[]>;
}

/** A slot definition (`<slot-target name>`); children are the default contents. */
export interface WISlotTarget extends WIBase {
  type: "slot-target";
  name: string;
  defaultChildren: WIElement[];
}

/** A fragment is a transparent wrapper — only its children are pasted. */
export interface WIFragment {
  type: "fragment";
  children: WIElement[];
}

export type WIElement =
  | WIContainer
  | WIText
  | WISVG
  | WIComponent
  | WISlotTarget
  | WIFragment;

export interface WIKeyFrame {
  percentage: number;
  /** Css style props/values in correct format supported by Plasmic and that is not considered a site invariant such as color, paddingTop, paddingRight */
  safeStyles: WISafeStyles;
  /** Css style props/values that are not safe. */
  unsafeStyles: WIUnsafeStyles;
}

export interface WIAnimationSequence {
  name: string;
  keyframes: WIKeyFrame[];
}

/** Result payload of parsing an HTML string into a web-importer tree. */
export interface WITree {
  wiTree: WIElement;
  fontDefinitions: string[];
  animationSequences: WIAnimationSequence[];
  /** Partial errors collected while parsing HTML. */
  errors: WIError[];
}

export const getWIVariantKey = (variant: WIVariant) => {
  if (variant.type === "base") {
    return "base";
  }

  if (variant.type === "style") {
    return `${variant.type}:${variant.selectors.sort().join(",")}`;
  }

  return `${variant.type}:${variant.width}`;
};

export const getWIVariantComboKey = (variantCombo: WIVariant[]): string => {
  return variantCombo
    .map((v) => getWIVariantKey(v))
    .sort()
    .join("|");
};

export const hasStyleVariant = (vs: WIVariantSettings) =>
  vs.variantCombo.some((v) => v.type === "style");

export const isWIBaseVariantSettings = (vs: WIVariantSettings) =>
  vs.variantCombo.length === 1 && vs.variantCombo[0].type === "base";
