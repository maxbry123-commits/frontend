import Editor from '../../../src/editor';
import { DEFAULT_CMPS } from '../../common';

const { keys } = Object;

describe('Editor', () => {
  let editor: Editor;

  beforeEach((done) => {
    editor = new Editor();
    editor.getModel().loadOnStart();
    editor.on('change:readyLoad', () => done());
  });

  afterEach(() => {
    editor.destroy();
  });

  test('Object exists', () => {
    expect(editor).toBeTruthy();
  });

  test('Has no components', () => {
    const all = editor.Components.allById();
    const allKeys = keys(all);
    // By default 1 wrapper components is created
    expect(allKeys.length).toBe(DEFAULT_CMPS);
    expect(all[allKeys[0]].get('type')).toBe('wrapper');
  });

  test('Has no CSS rules', () => {
    const all = editor.Css.getAll();
    expect(all.length).toBe(0);
  });

  test('Has one default frame', () => {
    const all = editor.Canvas.getFrames();
    expect(all.length).toBe(1);
  });

  test('The default frame has the same main component and css', () => {
    const wrapper = editor.getWrapper();
    const style = editor.getStyle();
    const frame = editor.Canvas.getFrame();
    expect(wrapper).toBe(frame.getComponent());
    expect(style).toBe(frame.get('styles'));
  });

  test('Components are correctly tracked on add', () => {
    const all = editor.Components.allById();
    const wrapper = editor.getWrapper()!;
    wrapper.append('<div>Component</div>'); // Div component + textnode
    expect(keys(all).length).toBe(2 + DEFAULT_CMPS);
  });

  test('Components are correctly tracked on add and remove', () => {
    const all = editor.Components.allById();
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append(`
        <div>Component 1</div>
        <div></div>
    `);
    expect(keys(all).length).toBe(3 + DEFAULT_CMPS);
    const secComp = added[1];
    secComp.append(`
        <div>Component 2</div>
        <div>Component 3</div>
    `);
    expect(keys(all).length).toBe(7 + DEFAULT_CMPS);
    wrapper.empty();
    expect(wrapper.components().length).toBe(0);
    expect(keys(all).length).toBe(DEFAULT_CMPS);
  });

  test('Components are correctly tracked with UndoManager', () => {
    const all = editor.Components.allById();
    const um = editor.UndoManager;
    const umStack = um.getStack();
    const wrapper = editor.getWrapper()!;
    expect(umStack.length).toBe(0);
    wrapper.append('<div>Component 1</div>')[0];
    expect(umStack.length).toBe(1);
    wrapper.empty();
    expect(umStack.length).toBe(2);
    expect(keys(all).length).toBe(DEFAULT_CMPS);
    um.undo(false);
    expect(keys(all).length).toBe(2 + DEFAULT_CMPS);
  });

  test('Components are correctly tracked with UndoManager and mutiple operations', () => {
    const all = editor.Components.allById();
    const um = editor.UndoManager;
    const umStack = um.getStack();
    const wrapper = editor.getWrapper()!;
    expect(umStack.length).toBe(0);
    wrapper.append(`<div>
        <div>Component 1</div>
        <div>Component 2</div>
    </div>`);
    expect(umStack.length).toBe(1); // UM counts first children
    expect(keys(all).length).toBe(5 + DEFAULT_CMPS);
    wrapper.components().at(0).components().at(0).remove(); // Remove 1 component

    expect(umStack.length).toBe(2);
    expect(keys(all).length).toBe(3 + DEFAULT_CMPS);
    wrapper.empty();
    expect(umStack.length).toBe(3);
    expect(keys(all).length).toBe(DEFAULT_CMPS);
  });

  test('One component can be selected at a time without shift', () => {
    const all = editor.Components.allById();
    const em = editor.em;
    em.getConfig().multipleSelection = true;
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append(`
      <div>Component 1</div>
      <div>Component 2</div>
    `);
    em.setSelected(added[0]);
    em.setSelected(added[1]);
    expect(editor.getSelectedAll().length).toBe(1);
  });

  test('Shift key should allow selecting multiple components', () => {
    const all = editor.Components.allById();
    const em = editor.em;
    em.getConfig().multipleSelection = true;
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append(`
      <div>Component 1</div>
      <div>Component 2</div>
    `);

    const callSelectedOptions = {
      event: {
        shiftKey: true,
      },
    } as any;

    em.setSelected(added[0], callSelectedOptions);
    em.setSelected(added[1], callSelectedOptions);
    expect(editor.getSelectedAll().length).toBe(2);
  });

  test('Shift key selecting a component that is being edited should should be ignored', () => {
    const all = editor.Components.allById();
    const em = editor.em;
    em.getConfig().multipleSelection = true;
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append(`
      <div>Component 1</div>
      <div>Component 2</div>
    `);

    const callSelectedOptions = {
      event: {
        shiftKey: true,
      },
    } as any;

    const firstComponent = all[keys(all)[0]];
    firstComponent.em.setEditing(true);
    em.setSelected(added[0], callSelectedOptions);
    expect(editor.getSelectedAll().length).toBe(0);
  });

  test('Removing a selected component removes it from the selection', () => {
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append('<div>Component 1</div>');
    editor.select(added[0]);
    expect(editor.getSelectedAll().length).toBe(1);

    added[0].remove();
    expect(editor.getSelectedAll().length).toBe(0);
  });

  test('Replacing a selected component removes it from the selection', () => {
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append('<div>Component 1</div>');
    editor.select(added[0]);

    added[0].replaceWith('<span>Replacement</span>');
    expect(editor.getSelectedAll().length).toBe(0);
  });

  test('Undo after replaceWith inside component:selected restores content without orphan selection', () => {
    const um = editor.UndoManager;
    const wrapper = editor.getWrapper()!;
    wrapper.append('<div data-id="a">A</div><div data-id="b">B</div>');
    um.clear();

    let replaced = false;
    editor.on('component:selected', (cmp) => {
      if (replaced) return;
      replaced = true;
      cmp.replaceWith('<span data-id="c">C</span>');
    });

    editor.select(wrapper.components().at(0));
    expect(replaced).toBe(true);
    expect(wrapper.getInnerHTML()).toBe('<span data-id="c">C</span><div data-id="b">B</div>');

    um.undo();
    expect(wrapper.getInnerHTML()).toBe('<div data-id="a">A</div><div data-id="b">B</div>');
    // Whatever selection the undo restored must reference components still in the tree
    editor.getSelectedAll().forEach((cmp) => {
      expect(cmp.parent()).toBeTruthy();
    });
  });

  test.skip('Shift key selecting a component that is being edited should not clear any text selections', () => {
    const all = editor.Components.allById();
    const em = editor.em;
    em.getConfig().multipleSelection = true;
    const wrapper = editor.getWrapper()!;
    const added = wrapper.append(`
      <div>Component 1</div>
      <div>Component 2</div>
    `);

    const callSelectedOptions = {
      event: {
        shiftKey: true,
      },
    } as any;

    const firstComponent = all[keys(all)[0]];
    firstComponent.em.setEditing(true);
    // TODO: highlight the text of the first component

    em.setSelected(added[0], callSelectedOptions);
    // TODO: check if the text of the first component is still highlighted
    expect(editor.getSelectedAll().length).toBe(0);
  });
});
