"use client";

import {
  Config,
  DndConfig,
  IframeConfig,
  Overrides,
  AppState,
  UiState,
  Plugin,
  UserGenerics,
  Field,
  ComponentConfig,
  Metadata,
  ComponentData,
  RootDataWithProps,
  ResolveDataTrigger,
  RichtextField,
} from "../types";
import { createReducer, PuckAction } from "../reducer";
import { getItem } from "../lib/data/get-item";
import { defaultViewports } from "../components/ViewportControls/default-viewports";
import { Viewports } from "../types";
import { create, useStore } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { createContext, useContext } from "react";
import { createHistorySlice, type HistorySlice } from "./slices/history";
import { createNodesSlice, type NodesSlice } from "./slices/nodes";
import {
  createPermissionsSlice,
  type PermissionsSlice,
} from "./slices/permissions";
import { createFieldsSlice, type FieldsSlice } from "./slices/fields";
import { resolveComponentData } from "../lib/resolve-component-data";
import { walkAppState } from "../lib/data/walk-app-state";
import { toRoot } from "../lib/data/to-root";
import { generateId } from "../lib/generate-id";
import { defaultAppState } from "./default-app-state";
import { FieldTransforms } from "../types/API/FieldTransforms";
import type { Dictionary } from "../lib/dictionary";
import type { Editor } from "@tiptap/react";

export { defaultAppState };

export type Status = "LOADING" | "MOUNTED" | "READY";

type ZoomConfig = {
  autoZoom: number;
  rootHeight: number;
  zoom: number;
};

type ComponentState = Record<string, { loadingCount: number }>;

export type AppStore<
  UserConfig extends Config = Config,
  G extends UserGenerics<UserConfig> = UserGenerics<UserConfig>
> = {
  instanceId: string;
  state: G["UserAppState"];
  dispatch: (action: PuckAction) => void;
  config: UserConfig;
  componentState: ComponentState;
  setComponentState: (componentState: ComponentState) => void;
  setComponentLoading: (
    id: string,
    loading?: boolean,
    defer?: number
  ) => () => void;
  unsetComponentLoading: (id: string) => void;
  pendingLoadTimeouts: Record<string, NodeJS.Timeout>;
  resolveComponentData: <T extends ComponentData | RootDataWithProps>(
    componentData: T,
    trigger: ResolveDataTrigger
  ) => Promise<{ node: T; didChange: boolean }>;
  resolveAndCommitData: () => void;
  plugins: Plugin[];
  overrides: Partial<Overrides>;
  viewports: Viewports;
  zoomConfig: ZoomConfig;
  setZoomConfig: (zoomConfig: ZoomConfig) => void;
  status: Status;
  setStatus: (status: Status) => void;
  iframe: IframeConfig;
  _experimentalFullScreenCanvas: boolean;
  _experimentalVirtualization: boolean;
  selectedItem?: G["UserData"]["content"][0] | null;
  getCurrentData: () => G["UserData"]["content"][0] | G["UserData"]["root"];
  setUi: (ui: Partial<UiState>, recordHistory?: boolean) => void;
  getComponentConfig: (type?: string) => ComponentConfig | null | undefined;
  onAction?: (action: PuckAction, newState: AppState, state: AppState) => void;
  metadata: Metadata;
  dictionary: Dictionary;
  dnd?: DndConfig;
  fields: FieldsSlice;
  history: HistorySlice;
  nodes: NodesSlice;
  permissions: PermissionsSlice;
  fieldTransforms: FieldTransforms;
  currentRichText?: {
    inlineComponentId?: string;
    inline: boolean;
    field: RichtextField;
    editor: Editor;
    id: string;
  } | null;
};

const defaultPageFields: Record<string, Field> = {
  title: { type: "text" },
};

export const createAppStore = (initialAppStore?: Partial<AppStore>) =>
  create<AppStore>()(
    subscribeWithSelector((set, get) => ({
      instanceId: generateId(),
      state: defaultAppState,
      config: { components: {} },
      componentState: {},
      plugins: [],
      overrides: {},
      viewports: defaultViewports,
      zoomConfig: {
        autoZoom: 1,
        rootHeight: 0,
        zoom: 1,
      },
      status: "LOADING",
      iframe: {},
      _experimentalFullScreenCanvas: false,
      _experimentalVirtualization: false,
      metadata: {},
      dictionary: {},
      dnd: {},
      fieldTransforms: {},
      ...initialAppStore,
      fields: createFieldsSlice(set, get),
      history: createHistorySlice(set, get),
      nodes: createNodesSlice(set, get),
      permissions: createPermissionsSlice(set, get),
      getCurrentData: () => {
        const s = get();

        return s.selectedItem ?? s.state.data.root;
      },
      getComponentConfig: (type?: string) => {
        const { config, selectedItem } = get();
        const rootFields = config.root?.fields || defaultPageFields;

        return type && type !== "root"
          ? config.components[type]
          : selectedItem
          ? config.components[selectedItem.type]
          : ({ ...config.root, fields: rootFields } as ComponentConfig);
      },
      selectedItem: initialAppStore?.state?.ui.itemSelector
        ? getItem(
            initialAppStore?.state?.ui.itemSelector,
            initialAppStore.state
          )
        : null,
      dispatch: (action: PuckAction) =>
        set((s) => {
          const { record } = get().history;

          const dispatch = createReducer({
            record,
            appStore: s,
          });

          const state = dispatch(s.state, action);

          const selectedItem = state.ui.itemSelector
            ? getItem(state.ui.itemSelector, state)
            : null;

          get().onAction?.(action, state, get().state);

          return { ...s, state, selectedItem };
        }),
      setZoomConfig: (zoomConfig) => set({ zoomConfig }),
      setStatus: (status) => set({ status }),
      setComponentState: (componentState) => set({ componentState }),
      pendingLoadTimeouts: {},
      setComponentLoading: (
        id: string,
        loading: boolean = true,
        defer: number = 0
      ) => {
        const { setComponentState, pendingLoadTimeouts } = get();

        const loadId = generateId();

        const setLoading = () => {
          const { componentState } = get();

          setComponentState({
            ...componentState,
            [id]: {
              ...componentState[id],
              loadingCount: (componentState[id]?.loadingCount || 0) + 1,
            },
          });
        };

        const unsetLoading = () => {
          const { componentState } = get();

          clearTimeout(timeout);

          delete pendingLoadTimeouts[loadId];

          set({ pendingLoadTimeouts });

          setComponentState({
            ...componentState,
            [id]: {
              ...componentState[id],
              loadingCount: Math.max(
                (componentState[id]?.loadingCount || 0) - 1,
                0
              ),
            },
          });
        };

        const timeout = setTimeout(() => {
          if (loading) {
            setLoading();
          } else {
            unsetLoading();
          }

          delete pendingLoadTimeouts[loadId];

          set({ pendingLoadTimeouts });
        }, defer);

        set({
          pendingLoadTimeouts: {
            ...pendingLoadTimeouts,
            [id]: timeout,
          },
        });

        return unsetLoading;
      },
      unsetComponentLoading: (id: string) => {
        const { setComponentLoading } = get();

        setComponentLoading(id, false);
      },
      // Helper
      setUi: (ui: Partial<UiState>, recordHistory?: boolean) =>
        set((s) => {
          const dispatch = createReducer({
            record: () => {},
            appStore: s,
          });

          const state = dispatch(s.state, {
            type: "setUi",
            ui,
            recordHistory,
          });

          const selectedItem = state.ui.itemSelector
            ? getItem(state.ui.itemSelector, state)
            : null;

          return { ...s, state, selectedItem };
        }),
      resolveComponentData: async (componentData, trigger) => {
        const { config, metadata, setComponentLoading, permissions, state } =
          get();
        const componentId =
          "id" in componentData.props ? componentData.props.id : "root";
        const parentId = state.indexes.nodes[componentId]?.parentId;
        const parentNode = parentId ? state.indexes.nodes[parentId] : null;
        const parentData = parentNode?.data ?? null;

        const timeouts: Record<string, () => void> = {};

        return await resolveComponentData(
          componentData,
          config,
          metadata,
          (item) => {
            const id = "id" in item.props ? item.props.id : "root";
            timeouts[id] = setComponentLoading(id, true, 50);
          },
          async (item) => {
            const id = "id" in item.props ? item.props.id : "root";

            if ("type" in item) {
              await permissions.refreshPermissions({ item });
            } else {
              await permissions.refreshPermissions({ root: true });
            }

            timeouts[id]();
          },
          trigger,
          parentData,
          state.data.root
        );
      },
      resolveAndCommitData: async () => {
        const { config, state, dispatch, resolveComponentData } = get();

        walkAppState(
          state,
          config,
          (content) => content,
          (childItem, path) => {
            // Skip nested items as these get processed by the parent's resolveComponentData
            // Perf: wasteful to use walkAppState, which walks the entire tree
            if (path.length > 1) return childItem;

            resolveComponentData(childItem, "load").then((resolved) => {
              const { state } = get();

              const node = state.indexes.nodes[resolved.node.props.id];

              // Ensure node hasn't been deleted whilst resolution happens
              if (node && resolved.didChange) {
                if (resolved.node.props.id === "root") {
                  dispatch({
                    type: "replaceRoot",
                    root: toRoot(resolved.node),
                  });
                } else {
                  // Use latest position, in case it's moved
                  const zoneCompound = `${node.parentId}:${node.zone}`;
                  const parentZone = state.indexes.zones[zoneCompound];

                  const index = parentZone.contentIds.indexOf(
                    resolved.node.props.id
                  );

                  dispatch({
                    type: "replace",
                    data: resolved.node,
                    destinationIndex: index,
                    destinationZone: zoneCompound,
                  });
                }
              }
            });

            return childItem;
          }
        );
      },
    }))
  );

// Derived from createAppStore so it keeps the zustand middleware augmentations
// (e.g. subscribeWithSelector's two-argument subscribe overload).
export type AppStoreApi = ReturnType<typeof createAppStore>;

export const appStoreContext = createContext<AppStoreApi | null>(null);

// Fallback store used only when a component reads the store outside of a <Puck> provider (e.g. <Render> for SSR).
// Created lazily instead of at module scope so that importing @puckeditor/core has no side effects that might
// be unsupported in edge runtimes
let defaultAppStore: AppStoreApi | null = null;

const getDefaultAppStore = (): AppStoreApi => {
  if (!defaultAppStore) {
    defaultAppStore = createAppStore();
  }

  return defaultAppStore;
};

export function useAppStore<T>(selector: (state: AppStore) => T) {
  const context = useContext(appStoreContext) ?? getDefaultAppStore();

  return useStore(context, selector);
}

export function useAppStoreApi() {
  return useContext(appStoreContext) ?? getDefaultAppStore();
}
