import { expect, test } from "@playwright/test";

import {
  NextJsContext,
  setupNextJs,
  teardownNextJs,
} from "../../nextjs/nextjs-setup";
import {
  POKEDEX_SEED_SQL,
  PostgresTestDatabase,
  createPostgresTestDatabase,
} from "../../postgres-test-db";
import { createPostgresDataSource, removeDataSource } from "../../utils";

test.describe(`Data Source basic`, async () => {
  let ctx: NextJsContext;
  let testDatabase: PostgresTestDatabase | undefined;
  let dataSourceId: string | undefined;
  test.beforeEach(async () => {
    testDatabase = await createPostgresTestDatabase(POKEDEX_SEED_SQL);
    dataSourceId = await createPostgresDataSource(
      `Pokedex ${testDatabase.connection.name}`,
      testDatabase.connection
    );
    ctx = await setupNextJs({
      bundleFile: "data-source-basic.json",
      projectName: "Data Source basic",
      removeComponentsPage: true,
      dataSourceReplacement: {
        fakeSourceId: dataSourceId,
      },
    });
  });

  test.afterEach(async () => {
    try {
      await teardownNextJs(ctx);
    } finally {
      if (dataSourceId) {
        await removeDataSource(dataSourceId);
      }
      await testDatabase?.dispose();
    }
  });

  test(`it works`, async ({ page }) => {
    await page.goto(`${ctx.host}/pokedex`);

    await page.getByText("New pokemon").click();
    await page.getByLabel("Name").type("Totodile");
    await page.getByLabel("Description").type("Friendly alligator");
    await page
      .getByLabel("Image URL")
      .type("https://assets.pokemon.com/assets/cms2/img/pokedex/full/158.png");

    await page.getByRole("button", { name: "Submit" }).click();
    await expect(page.getByText("Totodile")).toBeVisible();
    await expect(page.getByText("Friendly alligator")).toBeVisible();
    await expect(
      page.locator(
        `img[src="https://assets.pokemon.com/assets/cms2/img/pokedex/full/158.png"]`
      )
    ).toBeVisible();
    await page.getByText("Edit").last().click();
    await page
      .getByLabel("Update pokemon")
      .locator("#description")
      .type("Ferocious alligator");
    await page.getByRole("button", { name: "OK", exact: true }).click();
    await expect(page.getByText("Ferocious alligator")).toBeVisible();
    await page.getByText("Delete").last().click();
    await page.getByText("Totodile").waitFor({ state: "detached" });
  });
});
