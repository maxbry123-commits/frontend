import activeScreenVariantGroupBundle from "./active-screen-variant-group.json";
import cloneProjectBundle from "./clone-project.json";
import codeLibs from "./code-libs.json";
import dataTokensBundle from "./data-tokens.json";
import formsBundle from "./forms.json";
import pageReplacementBundle from "./page-replacement.json";
import staleMigrationBundle from "./stale-bundle.json";
import stateManagementBundle from "./state-management.json";

// https://studio.plasmic.app/projects/8eH4mLFb7TqLYDMGjj5BLd
import tutorialPortfolioBundle from "./tutorial-portfolio.json";

export default {
  "state-management": stateManagementBundle,
  "tutorial-portfolio": tutorialPortfolioBundle,
  "stale-bundle": staleMigrationBundle,
  "clone-project": cloneProjectBundle,
  forms: formsBundle,
  "code-libs": codeLibs,
  "page-replacement": pageReplacementBundle,
  "active-screen-variant-group": activeScreenVariantGroupBundle,
  // https://studio.plasmic.app/projects/5Eu6NQAbiR1RUMwXAW9y2J/
  "data-tokens": dataTokensBundle,
};
