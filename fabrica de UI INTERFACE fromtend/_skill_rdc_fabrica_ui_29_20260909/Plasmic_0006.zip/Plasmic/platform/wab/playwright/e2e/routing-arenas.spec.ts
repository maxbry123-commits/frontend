import { expect } from "@playwright/test";
import { test } from "../fixtures/test";
import { goToProject } from "../utils/studio-utils";

test.describe("routing", () => {
  let projectId: string;

  test.afterEach(async ({ apiClient }) => {
    if (projectId) {
      await apiClient.removeProject(projectId);
    }
  });

  test("should switch arenas", async ({ models, page, apiClient }) => {
    projectId = await apiClient.setupNewProject({
      name: "routing-arenas",
    });

    await goToProject(page, `/projects/${projectId}`);

    await expect(page).toHaveURL(
      new RegExp(
        `/-/Custom-arena-1\\?arena_type=custom&arena=Custom%20arena%201`
      )
    );

    const projNavButton = models.studio.frame.locator("#proj-nav-button");
    await projNavButton.click();
    await page.waitForTimeout(1000);

    const selectedArenaItem = models.studio.frame
      .locator(
        '[class*="plasmic_kit_style_controls-PlasmicRowItem-module__rootisSelected"]'
      )
      .filter({ hasText: "Custom arena 1" });

    await selectedArenaItem.waitFor({ state: "visible", timeout: 5000 });
    await selectedArenaItem.click({ button: "right" });
    await page.waitForTimeout(500);

    const renameOption = models.studio.frame.locator(
      'li[data-menu-id="proj-item-menu-rename"]'
    );
    await renameOption.waitFor({ state: "visible", timeout: 5000 });
    await renameOption.click();

    await page.waitForTimeout(500);
    await page.keyboard.type("FirstArena");
    await page.keyboard.press("Enter");

    await page.waitForTimeout(1000);
    await page.keyboard.press("Escape");
    await page.waitForTimeout(500);

    await expect(page).toHaveURL(
      new RegExp(`/-/FirstArena\\?arena_type=custom&arena=FirstArena`)
    );

    await models.studio.leftPanel.createNewPage("My/Page");
    await page.waitForTimeout(1000);

    await models.studio.leftPanel.addComponent("MyComponent");
    await page.waitForTimeout(1000);

    await models.studio.projectPanel();
    const myComponentItem = models.studio.frame
      .locator(
        '[class*="plasmic_kit_style_controls-PlasmicRowItem-module__root-"]'
      )
      .filter({ hasText: "MyComponent" });
    await myComponentItem.click();

    await expect(page).toHaveURL(
      new RegExp(`/-/MyComponent\\?arena_type=component&arena=`)
    );

    await models.studio.projectPanel();
    const myPageItem = models.studio.frame
      .locator(
        '[class*="plasmic_kit_style_controls-PlasmicRowItem-module__root-"]'
      )
      .filter({ hasText: "/my/page" });
    await myPageItem.click();

    await expect(page).toHaveURL(
      new RegExp(`/-/My-Page\\?arena_type=page&arena=`)
    );

    await goToProject(page, `/projects/${projectId}`);

    await expect(page).toHaveURL(
      new RegExp(`/-/FirstArena\\?arena_type=custom&arena=FirstArena`)
    );

    const projNavButtonCheck = models.studio.frame.locator("#proj-nav-button");
    await expect(projNavButtonCheck).toContainText("FirstArena");

    await goToProject(
      page,
      `/projects/${projectId}/-/NonExistentArena?arena_type=arena&arena=NonExistentArena`
    );

    await expect(page).toHaveURL(
      new RegExp(`/-/FirstArena\\?arena_type=custom&arena=FirstArena`)
    );

    const projNavButtonCheck2 = models.studio.frame.locator("#proj-nav-button");
    await expect(projNavButtonCheck2).toContainText("FirstArena");
  });
});
