# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [8.1.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.1.1...@capacitor/push-notifications@8.1.2) (2026-07-15)

**Note:** Version bump only for package @capacitor/push-notifications

## [8.1.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.1.0...@capacitor/push-notifications@8.1.1) (2026-05-15)

**Note:** Version bump only for package @capacitor/push-notifications

# [8.1.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.4...@capacitor/push-notifications@8.1.0) (2026-05-15)

### Features

- **push-notifications:** add banner and list presentation options for iOS ([#2529](https://github.com/ionic-team/capacitor-plugins/issues/2529)) ([f266d2e](https://github.com/ionic-team/capacitor-plugins/commit/f266d2e86b76148343d364e252d629383a56bbee))

## [8.0.4](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.3...@capacitor/push-notifications@8.0.4) (2026-05-07)

### Bug Fixes

- add Importance 0 for notification channels ([#2507](https://github.com/ionic-team/capacitor-plugins/issues/2507)) ([b98c4f9](https://github.com/ionic-team/capacitor-plugins/commit/b98c4f9ee368b66dc92fb54865129df777bf38e5))

## [8.0.3](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.2...@capacitor/push-notifications@8.0.3) (2026-03-25)

**Note:** Version bump only for package @capacitor/push-notifications

## [8.0.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.1...@capacitor/push-notifications@8.0.2) (2026-03-06)

### Bug Fixes

- **android:** notification Bundles with non-string values ([#2445](https://github.com/ionic-team/capacitor-plugins/issues/2445)) ([2788f81](https://github.com/ionic-team/capacitor-plugins/commit/2788f81d5dfe53e5d72b32e3b724e0f1a41e8373))

## [8.0.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.0...@capacitor/push-notifications@8.0.1) (2026-02-12)

### Bug Fixes

- AGP 9.0 no longer supporting `proguard-android.txt` ([#2468](https://github.com/ionic-team/capacitor-plugins/issues/2468)) ([a8760a9](https://github.com/ionic-team/capacitor-plugins/commit/a8760a989f594bc406d0ec7da58125d17447cae4))

# [8.0.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.0-beta.0...@capacitor/push-notifications@8.0.0) (2025-12-08)

**Note:** Version bump only for package @capacitor/push-notifications

# [8.0.0-beta.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@8.0.0-alpha.1...@capacitor/push-notifications@8.0.0-beta.0) (2025-11-14)

**Note:** Version bump only for package @capacitor/push-notifications

# [8.0.0-alpha.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.3...@capacitor/push-notifications@8.0.0-alpha.1) (2025-09-08)

**Note:** Version bump only for package @capacitor/push-notifications

## [7.0.3](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.2...@capacitor/push-notifications@7.0.3) (2025-09-05)

**Note:** Version bump only for package @capacitor/push-notifications

## [7.0.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.1...@capacitor/push-notifications@7.0.2) (2025-08-05)

**Note:** Version bump only for package @capacitor/push-notifications

## [7.0.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.0...@capacitor/push-notifications@7.0.1) (2025-04-02)

**Note:** Version bump only for package @capacitor/push-notifications

# [7.0.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.0-rc.0...@capacitor/push-notifications@7.0.0) (2025-01-20)

**Note:** Version bump only for package @capacitor/push-notifications

# [7.0.0-rc.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.0-alpha.2...@capacitor/push-notifications@7.0.0-rc.0) (2025-01-13)

**Note:** Version bump only for package @capacitor/push-notifications

# [7.0.0-alpha.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@7.0.0-alpha.1...@capacitor/push-notifications@7.0.0-alpha.2) (2024-12-19)

**Note:** Version bump only for package @capacitor/push-notifications

# [7.0.0-alpha.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.2...@capacitor/push-notifications@7.0.0-alpha.1) (2024-12-16)

**Note:** Version bump only for package @capacitor/push-notifications

## [6.0.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.1...@capacitor/push-notifications@6.0.2) (2024-08-08)

**Note:** Version bump only for package @capacitor/push-notifications

## [6.0.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0...@capacitor/push-notifications@6.0.1) (2024-06-13)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-rc.1...@capacitor/push-notifications@6.0.0) (2024-04-15)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-rc.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-rc.0...@capacitor/push-notifications@6.0.0-rc.1) (2024-03-25)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-rc.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-beta.1...@capacitor/push-notifications@6.0.0-rc.0) (2024-02-07)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-beta.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-beta.0...@capacitor/push-notifications@6.0.0-beta.1) (2023-12-14)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-beta.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-alpha.2...@capacitor/push-notifications@6.0.0-beta.0) (2023-12-13)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-alpha.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@6.0.0-alpha.1...@capacitor/push-notifications@6.0.0-alpha.2) (2023-11-15)

**Note:** Version bump only for package @capacitor/push-notifications

# [6.0.0-alpha.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.6...@capacitor/push-notifications@6.0.0-alpha.1) (2023-11-08)

### Features

- use Firebase SDK for creating foreground notifications ([#1657](https://github.com/ionic-team/capacitor-plugins/issues/1657)) ([530029c](https://github.com/ionic-team/capacitor-plugins/commit/530029ce5125999dde6e8eed216cd7d0f4bee513))

# [5.1.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.6...@capacitor/push-notifications@5.1.0) (2023-09-14)

### Features

- **push-notifications:** use Firebase SDK for creating foreground notifications ([#1786](https://github.com/ionic-team/capacitor-plugins/issues/1786)) ([1fce150](https://github.com/ionic-team/capacitor-plugins/commit/1fce150f3d44e5bc61820a7be7883e1450bcb877))

## [5.0.6](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.5...@capacitor/push-notifications@5.0.6) (2023-07-12)

### Bug Fixes

- **push-notifications:** make requestPermissions resolve if granted ([#1677](https://github.com/ionic-team/capacitor-plugins/issues/1677)) ([798f788](https://github.com/ionic-team/capacitor-plugins/commit/798f788452f1f21e868cbab32743db3875d930e9))

## [5.0.5](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.4...@capacitor/push-notifications@5.0.5) (2023-06-29)

**Note:** Version bump only for package @capacitor/push-notifications

## [5.0.4](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.3...@capacitor/push-notifications@5.0.4) (2023-06-08)

**Note:** Version bump only for package @capacitor/push-notifications

## [5.0.3](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.2...@capacitor/push-notifications@5.0.3) (2023-06-08)

**Note:** Version bump only for package @capacitor/push-notifications

## [5.0.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.1...@capacitor/push-notifications@5.0.2) (2023-05-09)

**Note:** Version bump only for package @capacitor/push-notifications

## [5.0.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.0...@capacitor/push-notifications@5.0.1) (2023-05-05)

### Bug Fixes

- Use Capacitor 5 final ([#1574](https://github.com/ionic-team/capacitor-plugins/issues/1574)) ([139c18b](https://github.com/ionic-team/capacitor-plugins/commit/139c18b86a11d31246e952d1a74335ff8ce5dbc2))

# [5.0.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.0-beta.1...@capacitor/push-notifications@5.0.0) (2023-05-03)

**Note:** Version bump only for package @capacitor/push-notifications

# [5.0.0-beta.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.0-beta.0...@capacitor/push-notifications@5.0.0-beta.1) (2023-04-21)

### Features

- Update gradle to 8.0.2 and gradle plugin to 8.0.0 ([#1542](https://github.com/ionic-team/capacitor-plugins/issues/1542)) ([e7210b4](https://github.com/ionic-team/capacitor-plugins/commit/e7210b47867644f5983e37acdbf0247214ec232d))

# [5.0.0-beta.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@5.0.0-alpha.1...@capacitor/push-notifications@5.0.0-beta.0) (2023-03-31)

### Features

- **push-notifications:** add unregister functions ([#1498](https://github.com/ionic-team/capacitor-plugins/issues/1498)) ([878e295](https://github.com/ionic-team/capacitor-plugins/commit/878e2950b4113af49d2856a11b6e02d01ba62bb6))

# [5.0.0-alpha.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@4.1.2...@capacitor/push-notifications@5.0.0-alpha.1) (2023-03-16)

### Bug Fixes

- **push-notifications:** fixing Android deprecations ([#1467](https://github.com/ionic-team/capacitor-plugins/issues/1467)) ([6558c5e](https://github.com/ionic-team/capacitor-plugins/commit/6558c5ede8649e272649f374229107b138ae6115))

### Features

- **android:** Removing enableJetifier ([d66f9cb](https://github.com/ionic-team/capacitor-plugins/commit/d66f9cbd9da7e3b1d8c64ca6a5b45156867d4a04))
- **push-notifications:** support Android 13+ permissions ([#1463](https://github.com/ionic-team/capacitor-plugins/issues/1463)) ([b152c88](https://github.com/ionic-team/capacitor-plugins/commit/b152c885e40a88055c374e3b33ac6fa2c963e77a))

## [4.1.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@4.1.1...@capacitor/push-notifications@4.1.2) (2022-11-16)

**Note:** Version bump only for package @capacitor/push-notifications

## [4.1.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@4.1.0...@capacitor/push-notifications@4.1.1) (2022-10-21)

**Note:** Version bump only for package @capacitor/push-notifications

# [4.1.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.9...@capacitor/push-notifications@4.1.0) (2022-09-12)

### Bug Fixes

- **push-notifications:** properly get the configured icon from manifest ([#1118](https://github.com/ionic-team/capacitor-plugins/issues/1118)) ([20e87d3](https://github.com/ionic-team/capacitor-plugins/commit/20e87d3da337e12050cbfd6d7dd336b369b558b7))

## [4.0.1](https://github.com/ionic-team/capacitor-plugins/compare/4.0.0...4.0.1) (2022-07-28)

**Note:** Version bump only for package @capacitor/push-notifications

# [4.0.0](https://github.com/ionic-team/capacitor-plugins/compare/4.0.0-beta.2...4.0.0) (2022-07-27)

**Note:** Version bump only for package @capacitor/push-notifications

# [4.0.0-beta.2](https://github.com/ionic-team/capacitor-plugins/compare/4.0.0-beta.0...4.0.0-beta.2) (2022-07-08)

**Note:** Version bump only for package @capacitor/push-notifications

# 4.0.0-beta.0 (2022-06-27)

### Bug Fixes

- **push-notifications:** use id and tag for canceling active notification ([#1041](https://github.com/ionic-team/capacitor-plugins/issues/1041)) ([fa710a6](https://github.com/ionic-team/capacitor-plugins/commit/fa710a63ea87f0ec0a7b0059baacfad7a45f8558))
- correct addListeners links ([#655](https://github.com/ionic-team/capacitor-plugins/issues/655)) ([f9871e7](https://github.com/ionic-team/capacitor-plugins/commit/f9871e7bd53478addb21155e148829f550c0e457))
- inline source code in esm map files ([#760](https://github.com/ionic-team/capacitor-plugins/issues/760)) ([a960489](https://github.com/ionic-team/capacitor-plugins/commit/a960489a19db0182b90d187a50deff9dfbe51038))
- Make removeAllListeners return a promise ([#895](https://github.com/ionic-team/capacitor-plugins/issues/895)) ([e5c49d6](https://github.com/ionic-team/capacitor-plugins/commit/e5c49d64445dca70286334e6a0441d8021197b13))
- remove postpublish scripts ([#656](https://github.com/ionic-team/capacitor-plugins/issues/656)) ([ed6ac49](https://github.com/ionic-team/capacitor-plugins/commit/ed6ac499ebf4a47525071ccbfc36c27503e11f60))
- **ios:** Coerce 'extra' field to add missing notification data on events ([#231](https://github.com/ionic-team/capacitor-plugins/issues/231)) ([46ce6b2](https://github.com/ionic-team/capacitor-plugins/commit/46ce6b2a72e4b107702b0cfb97007aaf385a3106))
- **ios:** do not show notifications when in foreground ([#209](https://github.com/ionic-team/capacitor-plugins/issues/209)) ([1994997](https://github.com/ionic-team/capacitor-plugins/commit/1994997a100d7c57477305d933fb835cf9f7c9c8))
- **push-notifications:** bump iOS deployment target to 12.0 ([#183](https://github.com/ionic-team/capacitor-plugins/issues/183)) ([d5b6503](https://github.com/ionic-team/capacitor-plugins/commit/d5b650312cded1606e39bbddc62acc6af9545997))
- **push-notifications:** make removeAllListeners available ([#454](https://github.com/ionic-team/capacitor-plugins/issues/454)) ([d92c925](https://github.com/ionic-team/capacitor-plugins/commit/d92c92566b15d3b339e9a4c54471b65fda49a7f0))
- **push-notifications:** proper return of push notification object properties ([#349](https://github.com/ionic-team/capacitor-plugins/issues/349)) ([733fc06](https://github.com/ionic-team/capacitor-plugins/commit/733fc06af7b62a576fb6214a7fe42838a3bcb93a))
- **push-notifications:** Throw errors if missing mandatory channel fields ([#576](https://github.com/ionic-team/capacitor-plugins/issues/576)) ([50f4e70](https://github.com/ionic-team/capacitor-plugins/commit/50f4e7026e5cae5f0871d4863bfab36989208064))
- add es2017 lib to tsconfig ([#180](https://github.com/ionic-team/capacitor-plugins/issues/180)) ([2c3776c](https://github.com/ionic-team/capacitor-plugins/commit/2c3776c38ca025c5ee965dec10ccf1cdb6c02e2f))
- export all TS definitions ([6cd2996](https://github.com/ionic-team/capacitor-plugins/commit/6cd299660fdeb27382ec7f45f0b3a55224cd0ad1)
  )
- support deprecated types from Capacitor 2 ([#210](https://github.com/ionic-team/capacitor-plugins/issues/210)) ([b559e24](https://github.com/ionic-team/capacitor-plugins/commit/b559e24b24174be60129217e87c0bff14bcdd573))
- **push-notifications:** remove unused Firebase/Messaging dependency ([#186](https://github.com/ionic-team/capacitor-plugins/issues/186)) ([0f4ca7c](https://github.com/ionic-team/capacitor-plugins/commit/0f4ca7ceaf67ced40b2cf2b359001b1ab060a3a6))

### Features

- set targetSDK default value to 32 ([#970](https://github.com/ionic-team/capacitor-plugins/issues/970)) ([fa70d96](https://github.com/ionic-team/capacitor-plugins/commit/fa70d96f141af751aae53ceb5642c46b204f5958))
- **push-notifications:** Allow to show while in foreground ([#919](https://github.com/ionic-team/capacitor-plugins/issues/919)) ([a90b5fd](https://github.com/ionic-team/capacitor-plugins/commit/a90b5fd4fe82d660c96a8be55e360d15f9e5e8c6))
- Use java 11 ([#910](https://github.com/ionic-team/capacitor-plugins/issues/910)) ([5acb2a2](https://github.com/ionic-team/capacitor-plugins/commit/5acb2a288a413492b163e4e97da46a085d9e4be0))
- **push-notifications:** Add new type for registrationError ([#808](https://github.com/ionic-team/capacitor-plugins/issues/808)) ([e5e78bb](https://github.com/ionic-team/capacitor-plugins/commit/e5e78bbbff020e625ccfd49c8ae36b4f1609a242))
- add commonjs output format ([#179](https://github.com/ionic-team/capacitor-plugins/issues/179)) ([8e9e098](https://github.com/ionic-team/capacitor-plugins/commit/8e9e09862064b3f6771d7facbc4008e995d9b463))
- Push Notifications plugin ([#126](https://github.com/ionic-team/capacitor-plugins/issues/126)) ([0bcd833](https://github.com/ionic-team/capacitor-plugins/commit/0bcd833a6503061be45253b21fca9bd75576efc8))
- set targetSDK default value to 31 ([#824](https://github.com/ionic-team/capacitor-plugins/issues/824)) ([3ee10de](https://github.com/ionic-team/capacitor-plugins/commit/3ee10de98067984c1a4e75295d001c5a895c47f4))
- Upgrade gradle to 7.4 ([#826](https://github.com/ionic-team/capacitor-plugins/issues/826)) ([5db0906](https://github.com/ionic-team/capacitor-plugins/commit/5db0906f6264287c4f8e69dbaecf19d4d387824b))

## [1.0.9](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.8...@capacitor/push-notifications@1.0.9) (2022-01-19)

### Bug Fixes

- inline source code in esm map files ([#760](https://github.com/ionic-team/capacitor-plugins/issues/760)) ([a960489](https://github.com/ionic-team/capacitor-plugins/commit/a960489a19db0182b90d187a50deff9dfbe51038))

## [1.0.8](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.7...@capacitor/push-notifications@1.0.8) (2022-01-10)

**Note:** Version bump only for package @capacitor/push-notifications

## [1.0.7](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.6...@capacitor/push-notifications@1.0.7) (2021-11-03)

**Note:** Version bump only for package @capacitor/push-notifications

## [1.0.6](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.5...@capacitor/push-notifications@1.0.6) (2021-10-14)

### Bug Fixes

- remove postpublish scripts ([#656](https://github.com/ionic-team/capacitor-plugins/issues/656)) ([ed6ac49](https://github.com/ionic-team/capacitor-plugins/commit/ed6ac499ebf4a47525071ccbfc36c27503e11f60))

## [1.0.5](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.4...@capacitor/push-notifications@1.0.5) (2021-10-13)

### Bug Fixes

- correct addListeners links ([#655](https://github.com/ionic-team/capacitor-plugins/issues/655)) ([f9871e7](https://github.com/ionic-team/capacitor-plugins/commit/f9871e7bd53478addb21155e148829f550c0e457))

## [1.0.4](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.3...@capacitor/push-notifications@1.0.4) (2021-09-01)

### Bug Fixes

- **push-notifications:** Throw errors if missing mandatory channel fields ([#576](https://github.com/ionic-team/capacitor-plugins/issues/576)) ([50f4e70](https://github.com/ionic-team/capacitor-plugins/commit/50f4e7026e5cae5f0871d4863bfab36989208064))

## [1.0.3](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.2...@capacitor/push-notifications@1.0.3) (2021-07-07)

**Note:** Version bump only for package @capacitor/push-notifications

## [1.0.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.1...@capacitor/push-notifications@1.0.2) (2021-06-23)

**Note:** Version bump only for package @capacitor/push-notifications

## [1.0.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@1.0.0...@capacitor/push-notifications@1.0.1) (2021-06-09)

### Bug Fixes

- **push-notifications:** make removeAllListeners available ([#454](https://github.com/ionic-team/capacitor-plugins/issues/454)) ([d92c925](https://github.com/ionic-team/capacitor-plugins/commit/d92c92566b15d3b339e9a4c54471b65fda49a7f0))

# [1.0.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.10...@capacitor/push-notifications@1.0.0) (2021-05-19)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.10](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.9...@capacitor/push-notifications@0.3.10) (2021-05-11)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.9](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.8...@capacitor/push-notifications@0.3.9) (2021-05-10)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.8](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.7...@capacitor/push-notifications@0.3.8) (2021-05-07)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.7](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.6...@capacitor/push-notifications@0.3.7) (2021-04-29)

### Bug Fixes

- **push-notifications:** proper return of push notification object properties ([#349](https://github.com/ionic-team/capacitor-plugins/issues/349)) ([733fc06](https://github.com/ionic-team/capacitor-plugins/commit/733fc06af7b62a576fb6214a7fe42838a3bcb93a))

## [0.3.6](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.5...@capacitor/push-notifications@0.3.6) (2021-03-10)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.5](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.4...@capacitor/push-notifications@0.3.5) (2021-03-02)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.4](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.3...@capacitor/push-notifications@0.3.4) (2021-02-27)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.3](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.2...@capacitor/push-notifications@0.3.3) (2021-02-10)

**Note:** Version bump only for package @capacitor/push-notifications

## [0.3.2](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.1...@capacitor/push-notifications@0.3.2) (2021-02-05)

### Bug Fixes

- **ios:** Coerce 'extra' field to add missing notification data on events ([#231](https://github.com/ionic-team/capacitor-plugins/issues/231)) ([46ce6b2](https://github.com/ionic-team/capacitor-plugins/commit/46ce6b2a72e4b107702b0cfb97007aaf385a3106))

## [0.3.1](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.3.0...@capacitor/push-notifications@0.3.1) (2021-01-26)

### Bug Fixes

- support deprecated types from Capacitor 2 ([#210](https://github.com/ionic-team/capacitor-plugins/issues/210)) ([b559e24](https://github.com/ionic-team/capacitor-plugins/commit/b559e24b24174be60129217e87c0bff14bcdd573))
- **ios:** do not show notifications when in foreground ([#209](https://github.com/ionic-team/capacitor-plugins/issues/209)) ([1994997](https://github.com/ionic-team/capacitor-plugins/commit/1994997a100d7c57477305d933fb835cf9f7c9c8))

# [0.3.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.2.0...@capacitor/push-notifications@0.3.0) (2021-01-14)

**Note:** Version bump only for package @capacitor/push-notifications

# [0.2.0](https://github.com/ionic-team/capacitor-plugins/compare/@capacitor/push-notifications@0.1.0...@capacitor/push-notifications@0.2.0) (2021-01-13)

### Bug Fixes

- add es2017 lib to tsconfig ([#180](https://github.com/ionic-team/capacitor-plugins/issues/180)) ([2c3776c](https://github.com/ionic-team/capacitor-plugins/commit/2c3776c38ca025c5ee965dec10ccf1cdb6c02e2f))
- export all TS definitions ([6cd2996](https://github.com/ionic-team/capacitor-plugins/commit/6cd299660fdeb27382ec7f45f0b3a55224cd0ad1)
  )

### Features

- add commonjs output format ([#179](https://github.com/ionic-team/capacitor-plugins/issues/179)) ([8e9e098](https://github.com/ionic-team/capacitor-plugins/commit/8e9e09862064b3f6771d7facbc4008e995d9b463))

# 0.1.0 (2021-01-13)

### Bug Fixes

- **push-notifications:** bump iOS deployment target to 12.0 ([#183](https://github.com/ionic-team/capacitor-plugins/issues/183)) ([d5b6503](https://github.com/ionic-team/capacitor-plugins/commit/d5b650312cded1606e39bbddc62acc6af9545997))
- **push-notifications:** remove unused Firebase/Messaging dependency ([#186](https://github.com/ionic-team/capacitor-plugins/issues/186)) ([0f4ca7c](https://github.com/ionic-team/capacitor-plugins/commit/0f4ca7ceaf67ced40b2cf2b359001b1ab060a3a6))

### Features

- Push Notifications plugin ([#126](https://github.com/ionic-team/capacitor-plugins/issues/126)) ([0bcd833](https://github.com/ionic-team/capacitor-plugins/commit/0bcd833a6503061be45253b21fca9bd75576efc8))
