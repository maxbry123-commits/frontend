
/*
 * Copyright 2019 Google Inc. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

import {FileHandlerJson} from './FileHandler';
import {ProtocolHandler} from './ProtocolHandler';

export interface WebManifestIcon {
  src: string;
  sizes?: string;
  purpose?: string;
  mimeType?: string;
  size?: number;
}

export interface WebManifestShortcutJson {
  name?: string;
  short_name?: string;
  url?: string;
  icons?: Array<WebManifestIcon>;
}

type WebManifestDisplayMode = 'browser' | 'minimal-ui' | 'standalone' | 'fullscreen';

export type WebManifestDisplayOverrideValue = 'window-controls-overlay' | 'tabbed' | 'browser' |
    'minimal-ui' | 'standalone' | 'fullscreen';

export type OrientationLock = 'any' | 'natural' | 'landscape'| 'portrait' | 'portrait-primary'|
    'portrait-secondary' | 'landscape-primary' | 'landscape-secondary';

// These interfaces follows the implementation from: https://w3c.github.io/web-share-target/.
export interface ShareTargetParams {
  title?: string;
  text?: string;
  url?: string;
  files?: FilesParams[];
}

export interface FilesParams {
  name: string;
  accept: string[];
}

export interface ShareTarget {
  action?: string;
  method?: string;
  enctype?: string;
  params?: ShareTargetParams;
}

export interface WebManifestJson {
  name?: string;
  short_name?: string;
  start_url?: string;
  scope?: string;
  display?: WebManifestDisplayMode;
  display_override?: WebManifestDisplayOverrideValue[];
  theme_color?: string;
  background_color?: string;
  icons?: Array<WebManifestIcon>;
  shortcuts?: Array<WebManifestShortcutJson>;
  share_target?: ShareTarget;
  orientation?: OrientationLock;
  protocol_handlers?: Array<ProtocolHandler>;
  file_handlers?: Array<FileHandlerJson>;
  launch_handler?: {
    client_mode?: string;
  };
}
