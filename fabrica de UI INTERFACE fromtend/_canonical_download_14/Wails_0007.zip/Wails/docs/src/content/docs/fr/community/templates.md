---
title: Modèles
description: Modèles de projets et kits de démarrage pour Wails
---

:::caution

Cette page est peut-être obsolète pour Wails v3.

:::

<!-- TODO: Update this link -->

Cette page sert de liste pour les modèles pris en charge par la communauté. Pour créer votre propre
modèle, veuillez consulter le guide [Modèles](https://wails.io/docs/guides/templates).

:::tip[Comment soumettre un modèle]

Vous pouvez cliquer sur `Modifier cette page` en bas pour inclure vos modèles.

:::

Pour utiliser ces modèles, exécutez
`wails init -n "Your Project Name" -t [le lien ci-dessous[@version]]`

S'il n'y a pas de suffixe de version, le modèle de code de la branche principale est utilisé par défaut.
S'il y a un suffixe de version, le modèle de code correspondant au tag de cette
version est utilisé.

Exemple :
`wails init -n "Your Project Name" -t https://github.com/misitebao/wails-template-vue`

:::danger[Attention]

**Le projet Wails ne maintient pas, n'est pas responsable ni responsable des modèles
tiers !**

Si vous avez des doutes sur un modèle, inspectez `package.json` et `wails.json` pour
voir quels scripts sont exécutés et quels packages sont installés.

:::

## Vue

- [wails-template-vue](https://github.com/misitebao/wails-template-vue) - Modèle
  Wails basé sur l'écosystème Vue (TypeScript intégré, thème sombre,
  internationalisation, routage single page, TailwindCSS)
- [wails-template-quasar-js](https://github.com/sgosiaco/wails-template-quasar-js) -
  Un modèle utilisant JavaScript + Quasar V2 (Vue 3, Vite, Sass, Pinia, ESLint,
  Prettier)
- [wails-template-quasar-ts](https://github.com/sgosiaco/wails-template-quasar-ts) -
  Un modèle utilisant TypeScript + Quasar V2 (Vue 3, Vite, Sass, Pinia, ESLint,
  Prettier, Composition API avec &lt;script setup&gt;)
- [wails-template-naive](https://github.com/tk103331/wails-template-naive) -
  Modèle Wails basé sur Naive UI (Une bibliothèque de composants Vue 3)
- [wails-template-nuxt](https://github.com/gornius/wails-template-nuxt) - Modèle
  Wails utilisant Nuxt3 propre et TypeScript avec des importations automatiques pour le
  runtime JS de Wails
- [Wails-Tool-Template](https://github.com/xisuo67/Wails-Tool-Template) - Modèle
  Wails utilisant Vue+TypeScript+Vite+Element-plus(imitation NetEase Cloud)

## Angular

- [wails-template-angular](https://github.com/mateothegreat/wails-template-angular) -
  Angular 15+ chargé d'actions et prêt pour la production.
- [wails-angular-template](https://github.com/TAINCER/wails-angular-template) -
  Angular avec TypeScript, Sass, rechargement à chaud, fractionnement de code et i18n

## React

- [wails-react-template](https://github.com/AlienRecall/wails-react-template) -
  Un modèle utilisant reactjs
- [wails-react-template](https://github.com/flin7/wails-react-template) - Un
  modèle minimal pour React qui prend en charge le développement en direct
- [wails-template-nextjs](https://github.com/LGiki/wails-template-nextjs) - Un
  modèle utilisant Next.js et TypeScript
- [wails-template-nextjs-app-router](https://github.com/thisisvk-in/wails-template-nextjs-app-router) -
  Un modèle utilisant Next.js et TypeScript avec le routeur App
- [wails-template-nextjs-app-router-src](https://github.com/edai-git/wails-template-nextjs-app-router) -
  Un modèle utilisant Next.js et TypeScript avec le routeur App src + exemple
- [wails-vite-react-ts-tailwind-template](https://github.com/hotafrika/wails-vite-react-ts-tailwind-template) -
  Un modèle pour React + TypeScript + Vite + TailwindCSS
- [wails-vite-react-ts-tailwind-shadcnui-template](https://github.com/Mahcks/wails-vite-react-tailwind-shadcnui-ts) -
  Un modèle avec Vite, React, TypeScript, TailwindCSS, et shadcn/ui

## Svelte

- [wails-svelte-template](https://github.com/raitonoberu/wails-svelte-template) -
  Un modèle utilisant Svelte
- [wails-vite-svelte-template](https://github.com/BillBuilt/wails-vite-svelte-template) -
  Un modèle utilisant Svelte et Vite
- [wails-vite-svelte-tailwind-template](https://github.com/BillBuilt/wails-vite-svelte-tailwind-template) -
  Un modèle utilisant Svelte et Vite avec TailwindCSS v3
- [wails-svelte-tailwind-vite-template](https://github.com/PylotLight/wails-vite-svelte-tailwind-template/tree/master) -
  Un modèle mis à jour utilisant Svelte v4.2.0 et Vite avec TailwindCSS v3.3.3
- [wails-sveltekit-template](https://github.com/h8gi/wails-sveltekit-template) -
  Un modèle utilisant SvelteKit
- [wails-template-shadcn-svelte](https://github.com/xijaja/wails-template-shadcn-svelte) -
  Un modèle utilisant Sveltekit et Shadcn-Svelte

## Solid

- [wails-template-vite-solid-ts](https://github.com/xijaja/wails-template-solid-ts) -
  Un modèle utilisant Solid + Ts + Vite
- [wails-template-vite-solid-js](https://github.com/xijaja/wails-template-solid-js) -
  Un modèle utilisant Solid + Js + Vite

## Elm

- [wails-elm-template](https://github.com/benjamin-thomas/wails-elm-template) -
  Développez votre application GUI avec la programmation fonctionnelle et une configuration de
  rechargement à chaud **rapide** :tada: :rocket:
- [wails-template-elm-tailwind](https://github.com/rnice01/wails-template-elm-tailwind) -
  Combinez les puissances :muscle: d'Elm + Tailwind CSS + Wails ! Le rechargement à chaud
  est pris en charge.

## HTMX

- [wails-htmx-templ-chi-tailwind](https://github.com/PylotLight/wails-hmtx-templ-template) -
  Utilisez une combinaison unique de htmx pur pour l'interactivité ainsi que templ pour
  créer des composants et des formulaires

## JavaScript pur (Vanilla)

- [wails-pure-js-template](https://github.com/KiddoV/wails-pure-js-template) - Un
  modèle avec rien d'autre que du JavaScript de base, HTML et CSS

## Lit (composants web)

- [wails-lit-shoelace-esbuild-template](https://github.com/Braincompiler/wails-lit-shoelace-esbuild-template) -
  Modèle Wails fournissant au frontend lit, la bibliothèque de composants Shoelace +
  prettier et typescript pré-configurés.