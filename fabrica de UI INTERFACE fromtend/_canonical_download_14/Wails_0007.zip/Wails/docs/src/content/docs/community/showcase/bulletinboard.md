---
title: BulletinBoard
description: "A desktop application built with Wails"
---

![BulletinBoard](../../../../assets/showcase-images/bboard.webp)

The [BulletinBoard](https://github.com/raguay/BulletinBoard) application is a
versital message board for static messages or dialogs to get information from
the user for a script. It has a TUI for creating new dialogs that can latter be
used to get information from the user. It's design is to stay running on your
system and show the information as needed and then hide away. I have a process
for watching a file on my system and sending the contents to BulletinBoard when
changed. It works great with my workflows. T here is also an
[Alfred workflow](https://github.com/raguay/MyAlfred/blob/master/Alfred%205/EmailIt.alfredworkflow)
for sending information to the program. The workflow is also for working with
[EmailIt](https://github.com/raguay/EmailIt).
