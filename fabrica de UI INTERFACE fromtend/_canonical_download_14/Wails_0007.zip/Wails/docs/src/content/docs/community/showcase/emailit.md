---
title: EmailIt
description: "A desktop application built with Wails"
---

![EmailIt](../../../../assets/showcase-images/emailit.webp)

[EmailIt](https://github.com/raguay/EmailIt/) is a Wails 2 program that is a
markdown based email sender only with nine notepads, scripts to manipulate the
text, and templates. It also has a scripts terminal to run scripts in EmailIt on
files in your system. The scripts and templates can be used from the commandline
itself or with the Alfred, Keyboard Maestro, Dropzone, or PopClip extensions. It
also supports scripts and themes downloaded form GitHub. Documentation is not
complete, but the programs works. It’s built using Wails2 and Svelte, and the
download is a universal macOS application.
