package generator

import (
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"golang.org/x/tools/go/packages"

	"github.com/wailsapp/wails/v3/internal/flags"
	"github.com/wailsapp/wails/v3/internal/generator/collect"
	"github.com/wailsapp/wails/v3/internal/generator/config"
	"github.com/wailsapp/wails/v3/internal/generator/render"
)

// Generator wraps all bookkeeping data structures that are needed
// to generate bindings for a set of packages.
type Generator struct {
	options *flags.GenerateBindingsOptions
	creator config.FileCreator

	// serviceFiles maps service file paths to their type object.
	// It is used for lower/upper-case collision detection.
	// Keys are strings, values are *types.TypeName.
	serviceFiles sync.Map

	collector *collect.Collector
	renderer  *render.Renderer

	// Default output dir for the obfuscated bindings file, plus any
	// auto-detection error to surface only when -obfuscated-output is unset.
	mainPackageDir    string
	mainPackageDirErr error

	// dirToPkgPath maps a loaded package's source directory to its import path.
	// Used so the obfuscated bindings file can elide the self-import when a
	// service lives in the same package as the metadata file.
	dirToPkgPath map[string]string

	// Binding-ID registrations gathered during the per-package pass.
	obfuscatedMu            sync.Mutex
	obfuscatedRegistrations []bindingIDRegistration

	logger    *ErrorReport
	scheduler scheduler
}

// NewGenerator configures a new generator instance.
// The options argument must not be nil.
// If creator is nil, no output file will be created.
// If logger is not nil, it is used to report messages interactively.
func NewGenerator(options *flags.GenerateBindingsOptions, creator config.FileCreator, logger config.Logger) *Generator {
	if creator == nil {
		creator = config.NullCreator
	}

	report := NewErrorReport(logger)

	return &Generator{
		options: options,
		creator: config.FileCreatorFunc(func(path string) (io.WriteCloser, error) {
			report.Debugf("writing output file %s", path)
			return creator.Create(path)
		}),

		logger: report,
	}
}

// Generate runs the binding generation process
// for the packages specified by the given patterns.
//
// Concurrent or repeated calls to Generate with the same receiver
// are not allowed.
//
// The stats result field is never nil.
//
// The error result field is nil in case of complete success (no warning).
// Otherwise, it may either report errors that occured while loading
// the initial set of packages, or errors returned by the static analyser,
// or be an [ErrorReport] instance.
//
// If error is an ErrorReport, it may have accumulated no errors, just warnings.
// When this is the case, all bindings have been generated successfully.
//
// Parsing/type-checking errors or errors encountered while writing
// individual files will be printed directly to the [config.Logger] instance
// provided during initialisation.
func (generator *Generator) Generate(patterns ...string) (stats *collect.Stats, err error) {
	stats = &collect.Stats{}
	stats.Start()
	defer stats.Stop()

	// Validate file names.
	err = generator.validateFileNames()
	if err != nil {
		return
	}

	// Parse build flags.
	buildFlags, err := generator.options.BuildFlags()
	if err != nil {
		return
	}

	// Start package loading feedback.
	var lpkgMutex sync.Mutex
	generator.logger.Statusf("Loading packages...")
	go func() {
		time.Sleep(5 * time.Second)
		if lpkgMutex.TryLock() {
			generator.logger.Statusf("Loading packages... (this may take a long time)")
			lpkgMutex.Unlock()
		}
	}()

	systemPaths, err := ResolveSystemPaths(buildFlags)
	if err != nil {
		return
	}

	// Load initial packages.
	pkgs, err := LoadPackages(buildFlags, patterns...)

	// Suppress package loading feedback.
	lpkgMutex.Lock()

	// Check for loading errors.
	if err != nil {
		return
	}
	if len(patterns) > 0 && len(pkgs) == 0 {
		err = ErrNoPackages
		return
	}

	// Report parsing/type-checking errors.
	for _, pkg := range pkgs {
		for _, err := range pkg.Errors {
			generator.logger.Warningf("%v", err)
		}
	}

	if generator.options.Obfuscated {
		generator.dirToPkgPath = buildDirToPkgPath(pkgs)
		if generator.options.ObfuscatedOutput == "" {
			generator.mainPackageDir, generator.mainPackageDirErr = findUniqueMainPackageDir(pkgs)
		}
	}

	// Panic on repeated calls.
	if generator.collector != nil {
		panic("Generate() must not be called more than once on the same receiver")
	}

	// Update status.
	if generator.options.NoEvents {
		generator.logger.Statusf("Looking for services...")
	} else {
		generator.logger.Statusf("Looking for services and events...")
	}
	serviceOrEventFound := sync.OnceFunc(func() { generator.logger.Statusf("Generating bindings...") })

	// Run static analysis.
	services, registerEvent, err := FindServices(pkgs, systemPaths, generator.logger)

	// Initialise subcomponents.
	generator.collector = collect.NewCollector(pkgs, registerEvent, systemPaths, generator.options, &generator.scheduler, generator.logger)
	generator.renderer = render.NewRenderer(generator.collector, generator.options)

	// Check for analyser errors.
	if err != nil {
		return
	}

	// Discard unneeded data.
	pkgs = nil

	// Schedule collection and code generation for event data types.
	if !generator.options.NoEvents {
		generator.scheduler.Schedule(func() {
			events := generator.collector.EventMap().Collect()
			if len(events.Defs) > 0 {
				serviceOrEventFound()
				// Not a data race because we wait for this scheduled task
				// to complete before accessing stats again.
				stats.Add(events.Stats())
			}
			generator.generateEvents(events)
		})
	}

	// Schedule code generation for each found service.
	for obj := range services {
		serviceOrEventFound()
		generator.scheduler.Schedule(func() {
			generator.generateService(obj)
		})
	}

	// Wait until all services have been generated and all models collected.
	generator.scheduler.Wait()

	// Invariants:
	//   - Service files have been generated for all discovered services;
	//   - ModelInfo.Collect has been called on all discovered models, and therefore
	//   - all required models have been discovered.

	// Update status.
	if generator.options.NoIndex {
		generator.logger.Statusf("Generating models...")
	} else {
		generator.logger.Statusf("Generating models and index files...")
	}

	// Schedule models, index and included files generation for each package.
	for pkg := range generator.collector.Iterate {
		generator.scheduler.Schedule(func() {
			generator.generateModelsIndexIncludes(pkg)
		})
	}

	// Wait until all models and indices have been generated.
	generator.scheduler.Wait()

	if generator.options.Obfuscated {
		generator.generateBindingIDMetadataAggregate()
	}

	// Populate stats.
	generator.logger.Statusf("Collecting stats...")
	for info := range generator.collector.Iterate {
		stats.Add(info.Stats())
	}

	// Return non-empty error report.
	if generator.logger.HasErrors() || generator.logger.HasWarnings() {
		err = generator.logger
	}

	return
}

// generateModelsIndexIncludes schedules generation of public/private model
// files, included files and, if allowed by the options, of an index file for
// the given package. Also records the package's binding-ID registrations when
// obfuscation is enabled.
func (generator *Generator) generateModelsIndexIncludes(pkg *collect.PackageInfo) {
	index := pkg.Index(generator.options.TS)

	// info.Index implies info.Collect: goroutines spawned below
	// can access package information freely.

	if generator.options.Obfuscated {
		generator.recordObfuscatedRegistrations(index)
	}

	if len(index.Models) > 0 {
		generator.scheduler.Schedule(func() {
			generator.generateModels(pkg, index.Models)
		})
	}

	if len(index.Package.Includes) > 0 {
		generator.scheduler.Schedule(func() {
			generator.generateIncludes(index)
		})
	}

	if !generator.options.NoIndex && !index.IsEmpty() {
		generator.generateIndex(index)
	}
}

// validateFileNames validates user-provided filenames and rejects
// incompatible flag combinations.
func (generator *Generator) validateFileNames() error {
	switch {
	case generator.options.ModelsFilename == "":
		return fmt.Errorf("models filename must not be empty")

	case !generator.options.NoIndex && generator.options.IndexFilename == "":
		return fmt.Errorf("package index filename must not be empty")

	case generator.options.ModelsFilename != strings.ToLower(generator.options.ModelsFilename):
		return fmt.Errorf("models filename must not contain uppercase characters")

	case generator.options.IndexFilename != strings.ToLower(generator.options.IndexFilename):
		return fmt.Errorf("package index filename must not contain uppercase characters")

	case !generator.options.NoIndex && generator.options.ModelsFilename == generator.options.IndexFilename:
		return fmt.Errorf("models and package indexes cannot share the same filename")

	case generator.options.Obfuscated && generator.options.UseNames:
		return fmt.Errorf("obfuscated bindings cannot use name-based calls")
	}

	return nil
}

var (
	errNoMainPackage        = errors.New("no `package main` found among loaded packages")
	errAmbiguousMainPackage = errors.New("multiple `package main` directories found among loaded packages")
)

// findUniqueMainPackageDir returns the source directory of the unique loaded
// `package main`, or a sentinel error when zero or multiple were found.
func findUniqueMainPackageDir(pkgs []*packages.Package) (string, error) {
	var dir string
	for _, pkg := range pkgs {
		if pkg.Name != "main" || len(pkg.GoFiles) == 0 {
			continue
		}
		candidate := filepath.Dir(pkg.GoFiles[0])
		if dir != "" && dir != candidate {
			return "", errAmbiguousMainPackage
		}
		dir = candidate
	}
	if dir == "" {
		return "", errNoMainPackage
	}
	return dir, nil
}

// buildDirToPkgPath snapshots a directory→import-path map for every loaded
// package. Used by the obfuscated bindings emitter to detect when the metadata
// file lives in the same package as a service and elide the self-import.
func buildDirToPkgPath(pkgs []*packages.Package) map[string]string {
	out := make(map[string]string, len(pkgs))
	for _, pkg := range pkgs {
		if len(pkg.GoFiles) == 0 || pkg.PkgPath == "" {
			continue
		}
		out[filepath.Dir(pkg.GoFiles[0])] = pkg.PkgPath
	}
	return out
}

// scheduler provides an implementation of the [collect.Scheduler] interface.
type scheduler struct {
	sync.WaitGroup
}

// Schedule runs the given function concurrently,
// registering it on the scheduler's wait group.
func (sched *scheduler) Schedule(task func()) {
	sched.Add(1)
	go func() {
		defer sched.Done()
		task()
	}()
}
