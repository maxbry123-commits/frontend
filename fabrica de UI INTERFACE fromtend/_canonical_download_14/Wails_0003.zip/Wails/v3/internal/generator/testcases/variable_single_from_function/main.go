package main

import (
	"log"

	"github.com/wailsapp/wails/v3/pkg/application"
)

// GreetService is great
type GreetService struct {
	SomeVariable int
	lowerCase    string
}

// Greet someone
func (*GreetService) Greet(name string) string {
	return "Hello " + name
}

func NewGreetService() application.Service {
	return application.NewService(&GreetService{})
}

func main() {
	greetService := NewGreetService()
	app := application.New(application.Options{
		Services: []application.Service{
			greetService,
		},
	})

	_ = app.Window.New() // discard
	// or: win := app.Window.New() // keep for later

	err := app.Run()

	if err != nil {
		log.Fatal(err)
	}

}
