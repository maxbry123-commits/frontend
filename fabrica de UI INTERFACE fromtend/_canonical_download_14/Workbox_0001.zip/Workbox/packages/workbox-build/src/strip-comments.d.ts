declare module 'strip-comments';
