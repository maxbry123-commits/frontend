//go:build windows

/*
 * Copyright (C) 2019 Tad Vizbaras. All Rights Reserved.
 * Copyright (C) 2010-2012 The W32 Authors. All Rights Reserved.
 */

package w32

import (
	"fmt"
	"runtime"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

var (
	moduser32 = syscall.NewLazyDLL("user32.dll")

	procRegisterClassEx               = moduser32.NewProc("RegisterClassExW")
	procGetClassName                  = moduser32.NewProc("GetClassNameW")
	procLoadIcon                      = moduser32.NewProc("LoadIconW")
	procLoadCursor                    = moduser32.NewProc("LoadCursorW")
	procShowWindow                    = moduser32.NewProc("ShowWindow")
	procGetDesktopWindow              = moduser32.NewProc("GetDesktopWindow")
	procShowWindowAsync               = moduser32.NewProc("ShowWindowAsync")
	procIsZoomed                      = moduser32.NewProc("IsZoomed")
	procUpdateWindow                  = moduser32.NewProc("UpdateWindow")
	procCreateWindowEx                = moduser32.NewProc("CreateWindowExW")
	procAdjustWindowRect              = moduser32.NewProc("AdjustWindowRect")
	procAdjustWindowRectEx            = moduser32.NewProc("AdjustWindowRectEx")
	procDestroyWindow                 = moduser32.NewProc("DestroyWindow")
	procDefWindowProc                 = moduser32.NewProc("DefWindowProcW")
	procDefDlgProc                    = moduser32.NewProc("DefDlgProcW")
	procPostQuitMessage               = moduser32.NewProc("PostQuitMessage")
	procGetMessage                    = moduser32.NewProc("GetMessageW")
	procTranslateMessage              = moduser32.NewProc("TranslateMessage")
	procDispatchMessage               = moduser32.NewProc("DispatchMessageW")
	procSendMessage                   = moduser32.NewProc("SendMessageW")
	procPostMessage                   = moduser32.NewProc("PostMessageW")
	procWaitMessage                   = moduser32.NewProc("WaitMessage")
	procSetWindowText                 = moduser32.NewProc("SetWindowTextW")
	procGetWindowTextLength           = moduser32.NewProc("GetWindowTextLengthW")
	procGetWindowText                 = moduser32.NewProc("GetWindowTextW")
	procGetWindowRect                 = moduser32.NewProc("GetWindowRect")
	procGetWindowInfo                 = moduser32.NewProc("GetWindowInfo")
	procGetWindow                     = moduser32.NewProc("GetWindow")
	procSetWindowCompositionAttribute = moduser32.NewProc("SetWindowCompositionAttribute")
	procMoveWindow                    = moduser32.NewProc("MoveWindow")
	procScreenToClient                = moduser32.NewProc("ScreenToClient")
	procCallWindowProc                = moduser32.NewProc("CallWindowProcW")
	procSetWindowLong                 = moduser32.NewProc("SetWindowLongW")
	procSetWindowLongPtr              = moduser32.NewProc("SetWindowLongW")
	procGetWindowLong                 = moduser32.NewProc("GetWindowLongW")
	procGetWindowLongPtr              = moduser32.NewProc("GetWindowLongW")
	procEnableWindow                  = moduser32.NewProc("EnableWindow")
	procIsWindowEnabled               = moduser32.NewProc("IsWindowEnabled")
	procIsWindowVisible               = moduser32.NewProc("IsWindowVisible")
	procSetFocus                      = moduser32.NewProc("SetFocus")
	procGetFocus                      = moduser32.NewProc("GetFocus")
	procSetActiveWindow               = moduser32.NewProc("SetActiveWindow")
	procSetForegroundWindow           = moduser32.NewProc("SetForegroundWindow")
	procBringWindowToTop              = moduser32.NewProc("BringWindowToTop")
	procInvalidateRect                = moduser32.NewProc("InvalidateRect")
	procGetClientRect                 = moduser32.NewProc("GetClientRect")
	procGetDC                         = moduser32.NewProc("GetDC")
	procReleaseDC                     = moduser32.NewProc("ReleaseDC")
	procSetCapture                    = moduser32.NewProc("SetCapture")
	procReleaseCapture                = moduser32.NewProc("ReleaseCapture")
	procGetWindowThreadProcessId      = moduser32.NewProc("GetWindowThreadProcessId")
	procMessageBox                    = moduser32.NewProc("MessageBoxW")
	procMessageBoxIndirect            = moduser32.NewProc("MessageBoxIndirectW")
	procGetSystemMetrics              = moduser32.NewProc("GetSystemMetrics")
	procPostThreadMessageW            = moduser32.NewProc("PostThreadMessageW")
	procRegisterHotKey                = moduser32.NewProc("RegisterHotKey")
	procUnregisterHotKey              = moduser32.NewProc("UnregisterHotKey")
	procRegisterWindowMessageA        = moduser32.NewProc("RegisterWindowMessageA")
	procCopyRect                      = moduser32.NewProc("CopyRect")
	procEqualRect                     = moduser32.NewProc("EqualRect")
	procInflateRect                   = moduser32.NewProc("InflateRect")
	procIntersectRect                 = moduser32.NewProc("IntersectRect")
	procIsRectEmpty                   = moduser32.NewProc("IsRectEmpty")
	procOffsetRect                    = moduser32.NewProc("OffsetRect")
	procPtInRect                      = moduser32.NewProc("PtInRect")
	procSetRect                       = moduser32.NewProc("SetRect")
	procSetRectEmpty                  = moduser32.NewProc("SetRectEmpty")
	procSubtractRect                  = moduser32.NewProc("SubtractRect")
	procUnionRect                     = moduser32.NewProc("UnionRect")
	procCreateDialogParam             = moduser32.NewProc("CreateDialogParamW")
	procDialogBoxParam                = moduser32.NewProc("DialogBoxParamW")
	procGetDlgItem                    = moduser32.NewProc("GetDlgItem")
	procDrawIcon                      = moduser32.NewProc("DrawIcon")
	procCreateMenu                    = moduser32.NewProc("CreateMenu")
	procRemoveMenu                    = moduser32.NewProc("RemoveMenu")
	procGetMenuItemPosition           = moduser32.NewProc("GetMenuItemPosition")
	procDestroyMenu                   = moduser32.NewProc("DestroyMenu")
	procCreatePopupMenu               = moduser32.NewProc("CreatePopupMenu")
	procCheckMenuRadioItem            = moduser32.NewProc("CheckMenuRadioItem")
	procCreateIconFromResourceEx      = moduser32.NewProc("CreateIconFromResourceEx")
	procInsertMenuItem                = moduser32.NewProc("InsertMenuItemW")
	procCheckMenuItem                 = moduser32.NewProc("CheckMenuItem")
	procClientToScreen                = moduser32.NewProc("ClientToScreen")
	procIsDialogMessage               = moduser32.NewProc("IsDialogMessageW")
	procIsWindow                      = moduser32.NewProc("IsWindow")
	procEndDialog                     = moduser32.NewProc("EndDialog")
	procPeekMessage                   = moduser32.NewProc("PeekMessageW")
	procTranslateAccelerator          = moduser32.NewProc("TranslateAcceleratorW")
	procSetWindowPos                  = moduser32.NewProc("SetWindowPos")
	procFillRect                      = moduser32.NewProc("FillRect")
	procFrameRect                     = moduser32.NewProc("FrameRect")
	procDrawText                      = moduser32.NewProc("DrawTextW")
	procAddClipboardFormatListener    = moduser32.NewProc("AddClipboardFormatListener")
	procRemoveClipboardFormatListener = moduser32.NewProc("RemoveClipboardFormatListener")
	procOpenClipboard                 = moduser32.NewProc("OpenClipboard")
	procCloseClipboard                = moduser32.NewProc("CloseClipboard")
	procEnumClipboardFormats          = moduser32.NewProc("EnumClipboardFormats")
	procGetClipboardData              = moduser32.NewProc("GetClipboardData")
	procSetClipboardData              = moduser32.NewProc("SetClipboardData")
	procEmptyClipboard                = moduser32.NewProc("EmptyClipboard")
	procGetClipboardFormatName        = moduser32.NewProc("GetClipboardFormatNameW")
	procIsClipboardFormatAvailable    = moduser32.NewProc("IsClipboardFormatAvailable")
	procBeginPaint                    = moduser32.NewProc("BeginPaint")
	procEndPaint                      = moduser32.NewProc("EndPaint")
	procGetKeyboardState              = moduser32.NewProc("GetKeyboardState")
	procMapVirtualKey                 = moduser32.NewProc("MapVirtualKeyW")
	procMapVirtualKeyEx               = moduser32.NewProc("MapVirtualKeyExW")
	procGetAsyncKeyState              = moduser32.NewProc("GetAsyncKeyState")
	procToAscii                       = moduser32.NewProc("ToAscii")
	procSwapMouseButton               = moduser32.NewProc("SwapMouseButton")
	procGetCursorPos                  = moduser32.NewProc("GetCursorPos")
	procSetCursorPos                  = moduser32.NewProc("SetCursorPos")
	procSetCursor                     = moduser32.NewProc("SetCursor")
	procCreateIcon                    = moduser32.NewProc("CreateIcon")
	procDestroyIcon                   = moduser32.NewProc("DestroyIcon")
	procMonitorFromPoint              = moduser32.NewProc("MonitorFromPoint")
	procMonitorFromRect               = moduser32.NewProc("MonitorFromRect")
	procMonitorFromWindow             = moduser32.NewProc("MonitorFromWindow")
	procGetMonitorInfo                = moduser32.NewProc("GetMonitorInfoW")
	procGetDpiForSystem               = moduser32.NewProc("GetDpiForSystem")
	procGetDpiForWindow               = moduser32.NewProc("GetDpiForWindow")
	procSetProcessDPIAware            = moduser32.NewProc("SetProcessDPIAware")
	procSetProcessDpiAwarenessContext = moduser32.NewProc("SetProcessDpiAwarenessContext")
	procGetThreadDpiAwarenessContext  = moduser32.NewProc("GetThreadDpiAwarenessContext")
	procAreDpiAwarenessContextsEqual  = moduser32.NewProc("AreDpiAwarenessContextsEqual")
	procEnumDisplayMonitors           = moduser32.NewProc("EnumDisplayMonitors")
	procEnumDisplayDevices            = moduser32.NewProc("EnumDisplayDevicesW")
	procEnumDisplaySettings           = moduser32.NewProc("EnumDisplaySettingsW")
	procEnumDisplaySettingsEx         = moduser32.NewProc("EnumDisplaySettingsExW")
	procEnumWindows                   = moduser32.NewProc("EnumWindows")
	procEnumChildWindows              = moduser32.NewProc("EnumChildWindows")
	procChangeDisplaySettingsEx       = moduser32.NewProc("ChangeDisplaySettingsExW")
	procSetTimer                      = moduser32.NewProc("SetTimer")
	procKillTimer                     = moduser32.NewProc("KillTimer")
	procKeybdEvent                    = moduser32.NewProc("keybd_event")
	procSendInput                     = moduser32.NewProc("SendInput")
	procSetWindowsHookEx              = moduser32.NewProc("SetWindowsHookExW")
	procUnhookWindowsHookEx           = moduser32.NewProc("UnhookWindowsHookEx")
	procCallNextHookEx                = moduser32.NewProc("CallNextHookEx")
	procGetForegroundWindow           = moduser32.NewProc("GetForegroundWindow")
	procUpdateLayeredWindow           = moduser32.NewProc("UpdateLayeredWindow")
	procSetLayeredWindowAttributes    = moduser32.NewProc("SetLayeredWindowAttributes")
	getDisplayConfig                  = moduser32.NewProc("GetDisplayConfigBufferSizes")
	queryDisplayConfig                = moduser32.NewProc("QueryDisplayConfig")

	procSystemParametersInfo = moduser32.NewProc("SystemParametersInfoW")
	procSetClassLong         = moduser32.NewProc("SetClassLongW")
	procSetClassLongPtr      = moduser32.NewProc("SetClassLongPtrW")

	procSetMenu          = moduser32.NewProc("SetMenu")
	procAppendMenu       = moduser32.NewProc("AppendMenuW")
	procSetMenuItemInfo  = moduser32.NewProc("SetMenuItemInfoW")
	procDrawMenuBar      = moduser32.NewProc("DrawMenuBar")
	procTrackPopupMenu   = moduser32.NewProc("TrackPopupMenu")
	procTrackPopupMenuEx = moduser32.NewProc("TrackPopupMenuEx")
	procGetMenuBarInfo   = moduser32.NewProc("GetMenuBarInfo")
	procMapWindowPoints  = moduser32.NewProc("MapWindowPoints")
	procGetKeyState      = moduser32.NewProc("GetKeyState")
	procGetSysColorBrush = moduser32.NewProc("GetSysColorBrush")
	procGetSysColor      = moduser32.NewProc("GetSysColor")

	procGetWindowPlacement = moduser32.NewProc("GetWindowPlacement")
	procSetWindowPlacement = moduser32.NewProc("SetWindowPlacement")
	procGetWindowDC        = moduser32.NewProc("GetWindowDC")

	procGetScrollInfo = moduser32.NewProc("GetScrollInfo")
	procSetScrollInfo = moduser32.NewProc("SetScrollInfo")

	procFlashWindowEx = moduser32.NewProc("FlashWindowEx")

	procSetMenuItemBitmaps = moduser32.NewProc("SetMenuItemBitmaps")

	procRedrawWindow = moduser32.NewProc("RedrawWindow")

	procRegisterWindowMessageW   = moduser32.NewProc("RegisterWindowMessageW")
	procSetWindowDisplayAffinity = moduser32.NewProc("SetWindowDisplayAffinity")

	mainThread HANDLE
)

func init() {
	runtime.LockOSThread()
	mainThread = GetCurrentThreadId()
}

func GetWindowDC(hwnd HWND) HDC {
	ret, _, _ := procGetWindowDC.Call(hwnd)
	return ret
}

func GET_X_LPARAM(lp uintptr) int32 {
	return int32(int16(LOWORD(uint32(lp))))
}

func GET_Y_LPARAM(lp uintptr) int32 {
	return int32(int16(HIWORD(uint32(lp))))
}

func RegisterClassEx(wndClassEx *WNDCLASSEX) ATOM {
	ret, _, _ := procRegisterClassEx.Call(uintptr(unsafe.Pointer(wndClassEx)))
	return ATOM(ret)
}

func SetMenuItemBitmaps(hMenu HMENU, uPosition, uFlags uint32, hBitmapUnchecked HBITMAP, hBitmapChecked HBITMAP) error {
	ret, _, _ := procSetMenuItemBitmaps.Call(
		hMenu,
		uintptr(uPosition),
		uintptr(uFlags),
		hBitmapUnchecked,
		hBitmapChecked)

	if ret == 0 {
		return windows.GetLastError()
	}
	return nil
}

func GetDesktopWindow() HWND {
	ret, _, _ := procGetDesktopWindow.Call()
	return ret
}

func LoadIcon(instance HINSTANCE, iconName *uint16) HICON {
	ret, _, _ := procLoadIcon.Call(
		uintptr(instance),
		uintptr(unsafe.Pointer(iconName)))

	return HICON(ret)
}

func LoadIconWithResourceID(instance HINSTANCE, res uint16) HICON {
	ret, _, _ := procLoadIcon.Call(
		uintptr(instance),
		uintptr(res))

	return HICON(ret)
}

func LoadCursor(instance HINSTANCE, cursorName *uint16) HCURSOR {
	ret, _, _ := procLoadCursor.Call(
		uintptr(instance),
		uintptr(unsafe.Pointer(cursorName)))

	return HCURSOR(ret)
}

func LoadCursorWithResourceID(instance HINSTANCE, res uint16) HCURSOR {
	ret, _, _ := procLoadCursor.Call(
		uintptr(instance),
		uintptr(res))

	return HCURSOR(ret)
}

func MessageBoxIndirect(msgbox *MSGBOXPARAMS) int32 {
	ret, _, _ := procMessageBoxIndirect.Call(
		uintptr(unsafe.Pointer(msgbox)))

	return int32(ret)
}

func ShowWindow(hwnd HWND, cmdshow int) bool {
	ret, _, _ := procShowWindow.Call(
		uintptr(hwnd),
		uintptr(cmdshow))

	return ret != 0
}

func IsZoomed(hwnd HWND) bool {
	ret, _, _ := procIsZoomed.Call(uintptr(hwnd))
	return ret != 0
}

func ShowWindowAsync(hwnd HWND, cmdshow int) bool {
	ret, _, _ := procShowWindowAsync.Call(
		uintptr(hwnd),
		uintptr(cmdshow))

	return ret != 0
}

func UpdateWindow(hwnd HWND) bool {
	ret, _, _ := procUpdateWindow.Call(
		uintptr(hwnd))
	return ret != 0
}

func UpdateLayeredWindow(hwnd HWND, hdcDst HDC, pptDst *POINT, psize *SIZE,
	hdcSrc HDC, pptSrc *POINT, crKey COLORREF, pblend *BLENDFUNCTION, dwFlags DWORD) bool {
	ret, _, _ := procUpdateLayeredWindow.Call(
		hwnd,
		hdcDst,
		uintptr(unsafe.Pointer(pptDst)),
		uintptr(unsafe.Pointer(psize)),
		hdcSrc,
		uintptr(unsafe.Pointer(pptSrc)),
		uintptr(crKey),
		uintptr(unsafe.Pointer(pblend)),
		uintptr(dwFlags))
	return ret != 0
}

// SetLayeredWindowAttributes sets the opacity and transparency color key of a layered window.
func SetLayeredWindowAttributes(hwnd HWND, crKey COLORREF, bAlpha byte, dwFlags DWORD) bool {
	ret, _, _ := procSetLayeredWindowAttributes.Call(
		uintptr(hwnd),
		uintptr(crKey),
		uintptr(bAlpha),
		uintptr(dwFlags))
	return ret != 0
}

func PostThreadMessage(threadID HANDLE, msg int, wp, lp uintptr) {
	procPostThreadMessageW.Call(threadID, uintptr(msg), wp, lp)
}

func RegisterWindowMessage(name *uint16) uint32 {
	ret, _, _ := procRegisterWindowMessageW.Call(uintptr(unsafe.Pointer(name)))
	return uint32(ret)
}

func PostMainThreadMessage(msg uint32, wp, lp uintptr) bool {
	ret, _, _ := procPostThreadMessageW.Call(mainThread, uintptr(msg), wp, lp)
	return ret != 0
}

func CreateWindowEx(exStyle uint, className, windowName *uint16,
	style uint, x, y, width, height int, parent HWND, menu HMENU,
	instance HINSTANCE, param unsafe.Pointer) HWND {
	ret, _, _ := procCreateWindowEx.Call(
		uintptr(exStyle),
		uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(windowName)),
		uintptr(style),
		uintptr(x),
		uintptr(y),
		uintptr(width),
		uintptr(height),
		uintptr(parent),
		uintptr(menu),
		uintptr(instance),
		uintptr(param))

	return HWND(ret)
}

func AdjustWindowRectEx(rect *RECT, style uint, menu bool, exStyle uint) bool {
	ret, _, _ := procAdjustWindowRectEx.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(style),
		uintptr(BoolToBOOL(menu)),
		uintptr(exStyle))

	return ret != 0
}

func AdjustWindowRect(rect *RECT, style uint, menu bool) bool {
	ret, _, _ := procAdjustWindowRect.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(style),
		uintptr(BoolToBOOL(menu)))

	return ret != 0
}

func DestroyWindow(hwnd HWND) bool {
	ret, _, _ := procDestroyWindow.Call(hwnd)
	return ret != 0
}

func HasGetDpiForWindowFunc() bool {
	err := procGetDpiForWindow.Find()
	return err == nil
}

func GetDpiForWindow(hwnd HWND) UINT {
	dpi, _, _ := procGetDpiForWindow.Call(hwnd)
	return uint(dpi)
}

func HasSetProcessDPIAwareFunc() bool {
	err := procSetProcessDPIAware.Find()
	return err == nil
}

func GetClassName(hwnd HWND) string {
	var buf [256]uint16
	procGetClassName.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&buf[0])),
		uintptr(len(buf)))

	return syscall.UTF16ToString(buf[:])
}

func SetProcessDPIAware() error {
	status, r, err := procSetProcessDPIAware.Call()
	if status == 0 {
		return fmt.Errorf("SetProcessDPIAware failed %d: %v %v", status, r, err)
	}
	return nil
}

func HasSetProcessDpiAwarenessContextFunc() bool {
	err := procSetProcessDpiAwarenessContext.Find()
	return err == nil
}

func SetProcessDpiAwarenessContext(ctx uintptr) error {
	status, r, err := procSetProcessDpiAwarenessContext.Call(ctx)
	if status == 0 {
		return fmt.Errorf("SetProcessDpiAwarenessContext failed %d: %v %v", status, r, err)
	}
	return nil
}

func HasGetThreadDpiAwarenessContextFunc() bool {
	return procGetThreadDpiAwarenessContext.Find() == nil
}

// GetThreadDpiAwarenessContext returns the DPI awareness context for the current thread.
// Available on Windows 10 version 1607 and later.
func GetThreadDpiAwarenessContext() uintptr {
	ctx, _, _ := procGetThreadDpiAwarenessContext.Call()
	return ctx
}

func HasAreDpiAwarenessContextsEqualFunc() bool {
	return procAreDpiAwarenessContextsEqual.Find() == nil
}

// AreDpiAwarenessContextsEqual compares two DPI awareness context values.
func AreDpiAwarenessContextsEqual(ctx1, ctx2 uintptr) bool {
	ret, _, _ := procAreDpiAwarenessContextsEqual.Call(ctx1, ctx2)
	return ret != 0
}

func GetForegroundWindow() HWND {
	ret, _, _ := procGetForegroundWindow.Call()
	return HWND(ret)
}

func SetWindowCompositionAttribute(hwnd HWND, data *WINDOWCOMPOSITIONATTRIBDATA) bool {
	if procSetWindowCompositionAttribute != nil {
		ret, _, _ := procSetWindowCompositionAttribute.Call(
			hwnd,
			uintptr(unsafe.Pointer(data)),
		)
		return ret != 0
	}
	return false
}

func DefWindowProc(hwnd HWND, msg uint32, wParam, lParam uintptr) uintptr {
	ret, _, _ := procDefWindowProc.Call(
		uintptr(hwnd),
		uintptr(msg),
		wParam,
		lParam)

	return ret
}

func DefDlgProc(hwnd HWND, msg uint32, wParam, lParam uintptr) uintptr {
	ret, _, _ := procDefDlgProc.Call(
		uintptr(hwnd),
		uintptr(msg),
		wParam,
		lParam)

	return ret
}

func PostQuitMessage(exitCode int) {
	procPostQuitMessage.Call(
		uintptr(exitCode))
}

func GetMessage(msg *MSG, hwnd HWND, msgFilterMin, msgFilterMax uint32) int {
	ret, _, _ := procGetMessage.Call(
		uintptr(unsafe.Pointer(msg)),
		uintptr(hwnd),
		uintptr(msgFilterMin),
		uintptr(msgFilterMax))

	return int(ret)
}

func TranslateMessage(msg *MSG) bool {
	ret, _, _ := procTranslateMessage.Call(
		uintptr(unsafe.Pointer(msg)))

	return ret != 0

}

func DispatchMessage(msg *MSG) uintptr {
	ret, _, _ := procDispatchMessage.Call(
		uintptr(unsafe.Pointer(msg)))

	return ret

}

func SendMessage(hwnd HWND, msg uint32, wParam, lParam uintptr) uintptr {
	ret, _, _ := procSendMessage.Call(
		uintptr(hwnd),
		uintptr(msg),
		wParam,
		lParam)

	return ret
}

func PostMessage(hwnd HWND, msg uint32, wParam, lParam uintptr) bool {
	ret, _, _ := procPostMessage.Call(
		uintptr(hwnd),
		uintptr(msg),
		wParam,
		lParam)

	return ret != 0
}

func WaitMessage() bool {
	ret, _, _ := procWaitMessage.Call()
	return ret != 0
}

// RegisterHotKey registers a system-wide hot key. When the hot key is pressed a
// WM_HOTKEY message (with wParam set to id) is posted to the message queue of
// the thread that owns hwnd. fsModifiers is a combination of MOD_* flags and vk
// is a virtual-key code.
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey
func RegisterHotKey(hwnd HWND, id int, fsModifiers uint, vk uint) bool {
	ret, _, _ := procRegisterHotKey.Call(
		uintptr(hwnd),
		uintptr(id),
		uintptr(fsModifiers),
		uintptr(vk))
	return ret != 0
}

// UnregisterHotKey releases a hot key previously registered with RegisterHotKey.
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-unregisterhotkey
func UnregisterHotKey(hwnd HWND, id int) bool {
	ret, _, _ := procUnregisterHotKey.Call(
		uintptr(hwnd),
		uintptr(id))
	return ret != 0
}

func SetWindowText(hwnd HWND, text string) {
	procSetWindowText.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(text))))
}

func GetWindowTextLength(hwnd HWND) int {
	ret, _, _ := procGetWindowTextLength.Call(
		uintptr(hwnd))

	return int(ret)
}

func GetWindowInfo(hwnd HWND, info *WINDOWINFO) int {
	ret, _, _ := procGetWindowInfo.Call(
		hwnd,
		uintptr(unsafe.Pointer(info)),
	)
	return int(ret)
}

func GetWindow(hwnd HWND, cmd uint32) HWND {
	ret, _, _ := procGetWindow.Call(
		hwnd,
		uintptr(cmd),
	)
	return HWND(ret)
}

func GetWindowText(hwnd HWND) string {
	textLen := GetWindowTextLength(hwnd) + 1

	buf := make([]uint16, textLen)
	procGetWindowText.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&buf[0])),
		uintptr(textLen))

	return syscall.UTF16ToString(buf)
}

func GetWindowRect(hwnd HWND) *RECT {
	var rect RECT
	procGetWindowRect.Call(
		hwnd,
		uintptr(unsafe.Pointer(&rect)))

	return &rect
}

func MoveWindow(hwnd HWND, x, y, width, height int, repaint bool) bool {
	ret, _, _ := procMoveWindow.Call(
		uintptr(hwnd),
		uintptr(x),
		uintptr(y),
		uintptr(width),
		uintptr(height),
		uintptr(BoolToBOOL(repaint)))

	return ret != 0

}

func ScreenToClient(hwnd HWND, x, y int) (X, Y int, ok bool) {
	pt := POINT{X: int32(x), Y: int32(y)}
	ret, _, _ := procScreenToClient.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&pt)))

	return int(pt.X), int(pt.Y), ret != 0
}

func CallWindowProc(preWndProc uintptr, hwnd HWND, msg uint32, wParam, lParam uintptr) uintptr {
	ret, _, _ := procCallWindowProc.Call(
		preWndProc,
		uintptr(hwnd),
		uintptr(msg),
		wParam,
		lParam)

	return ret
}

func SetWindowLong(hwnd HWND, index int, value uint32) uint32 {
	ret, _, _ := procSetWindowLong.Call(
		uintptr(hwnd),
		uintptr(index),
		uintptr(value))

	return uint32(ret)
}

func SetWindowLongPtr(hwnd HWND, index int, value uintptr) uintptr {
	ret, _, _ := procSetWindowLongPtr.Call(
		uintptr(hwnd),
		uintptr(index),
		value)

	return ret
}

func GetWindowLong(hwnd HWND, index int) int32 {
	ret, _, _ := procGetWindowLong.Call(
		uintptr(hwnd),
		uintptr(index))

	return int32(ret)
}

func GetWindowLongPtr(hwnd HWND, index int) uintptr {
	ret, _, _ := procGetWindowLongPtr.Call(
		uintptr(hwnd),
		uintptr(index))

	return ret
}

func EnableWindow(hwnd HWND, b bool) bool {
	ret, _, _ := procEnableWindow.Call(
		uintptr(hwnd),
		uintptr(BoolToBOOL(b)))
	return ret != 0
}

func IsWindowEnabled(hwnd HWND) bool {
	ret, _, _ := procIsWindowEnabled.Call(
		uintptr(hwnd))

	return ret != 0
}

func IsWindowVisible(hwnd HWND) bool {
	ret, _, _ := procIsWindowVisible.Call(
		uintptr(hwnd))

	return ret != 0
}

func SetFocus(hwnd HWND) HWND {
	ret, _, _ := procSetFocus.Call(
		uintptr(hwnd))

	return HWND(ret)
}

func SetActiveWindow(hwnd HWND) HWND {
	ret, _, _ := procSetActiveWindow.Call(
		uintptr(hwnd))

	return HWND(ret)
}

func BringWindowToTop(hwnd HWND) bool {
	ret, _, _ := procBringWindowToTop.Call(uintptr(hwnd))
	return ret != 0
}

func SetForegroundWindow(hwnd HWND) HWND {
	ret, _, _ := procSetForegroundWindow.Call(
		uintptr(hwnd))

	return HWND(ret)
}

func GetFocus() HWND {
	ret, _, _ := procGetFocus.Call()
	return HWND(ret)
}

func InvalidateRect(hwnd HWND, rect *RECT, erase bool) bool {
	ret, _, _ := procInvalidateRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(rect)),
		uintptr(BoolToBOOL(erase)))

	return ret != 0
}

func GetClientRect(hwnd HWND) *RECT {
	var rect RECT
	ret, _, _ := procGetClientRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&rect)))

	if ret == 0 {
		panic(fmt.Sprintf("GetClientRect(%d) failed", hwnd))
	}

	return &rect
}

func GetDC(hwnd HWND) HDC {
	ret, _, _ := procGetDC.Call(
		uintptr(hwnd))

	return HDC(ret)
}

func ReleaseDC(hwnd HWND, hDC HDC) bool {
	ret, _, _ := procReleaseDC.Call(
		uintptr(hwnd),
		uintptr(hDC))

	return ret != 0
}

func SetCapture(hwnd HWND) HWND {
	ret, _, _ := procSetCapture.Call(
		uintptr(hwnd))

	return HWND(ret)
}

func ReleaseCapture() bool {
	ret, _, _ := procReleaseCapture.Call()

	return ret != 0
}

func EnumWindows(enumFunc uintptr, lparam uintptr) bool {
	ret, _, _ := procEnumWindows.Call(
		enumFunc,
		lparam)

	return ret != 0
}

func GetWindowThreadProcessId(hwnd HWND) (HANDLE, int) {
	var processId int
	ret, _, _ := procGetWindowThreadProcessId.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&processId)))

	return HANDLE(ret), processId
}

func MessageBox(hwnd HWND, title, caption string, flags uint) int {
	ret, _, _ := procMessageBox.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(title))),
		uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(caption))),
		uintptr(flags))

	return int(ret)
}

func GetSystemMetrics(index int) int {
	ret, _, _ := procGetSystemMetrics.Call(
		uintptr(index))

	return int(ret)
}

func GetSysColorBrush(nIndex int) HBRUSH {
	ret, _, _ := procGetSysColorBrush.Call(1,
		uintptr(nIndex),
		0,
		0)

	return HBRUSH(ret)
}

func GetSysColor(nIndex int) COLORREF {
	ret, _, _ := procGetSysColor.Call(
		uintptr(nIndex))

	return COLORREF(ret)
}

func CopyRect(dst, src *RECT) bool {
	ret, _, _ := procCopyRect.Call(
		uintptr(unsafe.Pointer(dst)),
		uintptr(unsafe.Pointer(src)))

	return ret != 0
}

func EqualRect(rect1, rect2 *RECT) bool {
	ret, _, _ := procEqualRect.Call(
		uintptr(unsafe.Pointer(rect1)),
		uintptr(unsafe.Pointer(rect2)))

	return ret != 0
}

func InflateRect(rect *RECT, dx, dy int) bool {
	ret, _, _ := procInflateRect.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(dx),
		uintptr(dy))

	return ret != 0
}

func IntersectRect(dst, src1, src2 *RECT) bool {
	ret, _, _ := procIntersectRect.Call(
		uintptr(unsafe.Pointer(dst)),
		uintptr(unsafe.Pointer(src1)),
		uintptr(unsafe.Pointer(src2)))

	return ret != 0
}

func IsRectEmpty(rect *RECT) bool {
	ret, _, _ := procIsRectEmpty.Call(
		uintptr(unsafe.Pointer(rect)))

	return ret != 0
}

func OffsetRect(rect *RECT, dx, dy int) bool {
	ret, _, _ := procOffsetRect.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(dx),
		uintptr(dy))

	return ret != 0
}

func PtInRect(rect *RECT, x, y int) bool {
	pt := POINT{X: int32(x), Y: int32(y)}
	ret, _, _ := procPtInRect.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(unsafe.Pointer(&pt)))

	return ret != 0
}

func RectInRect(rect1, rect2 *RECT) bool {
	return rect1.Left >= rect2.Left && rect1.Right <= rect2.Right &&
		rect1.Top >= rect2.Top && rect1.Bottom <= rect2.Bottom
}

func SetRect(rect *RECT, left, top, right, bottom int) bool {
	ret, _, _ := procSetRect.Call(
		uintptr(unsafe.Pointer(rect)),
		uintptr(left),
		uintptr(top),
		uintptr(right),
		uintptr(bottom))

	return ret != 0
}

func SetRectEmpty(rect *RECT) bool {
	ret, _, _ := procSetRectEmpty.Call(
		uintptr(unsafe.Pointer(rect)))

	return ret != 0
}

func SubtractRect(dst, src1, src2 *RECT) bool {
	ret, _, _ := procSubtractRect.Call(
		uintptr(unsafe.Pointer(dst)),
		uintptr(unsafe.Pointer(src1)),
		uintptr(unsafe.Pointer(src2)))

	return ret != 0
}

func UnionRect(dst, src1, src2 *RECT) bool {
	ret, _, _ := procUnionRect.Call(
		uintptr(unsafe.Pointer(dst)),
		uintptr(unsafe.Pointer(src1)),
		uintptr(unsafe.Pointer(src2)))

	return ret != 0
}

func CreateDialog(hInstance HINSTANCE, lpTemplate *uint16, hWndParent HWND, lpDialogProc uintptr) HWND {
	ret, _, _ := procCreateDialogParam.Call(
		uintptr(hInstance),
		uintptr(unsafe.Pointer(lpTemplate)),
		uintptr(hWndParent),
		lpDialogProc,
		0)

	return HWND(ret)
}

func DialogBox(hInstance HINSTANCE, lpTemplateName *uint16, hWndParent HWND, lpDialogProc uintptr) int {
	ret, _, _ := procDialogBoxParam.Call(
		uintptr(hInstance),
		uintptr(unsafe.Pointer(lpTemplateName)),
		uintptr(hWndParent),
		lpDialogProc,
		0)

	return int(ret)
}

func GetDlgItem(hDlg HWND, nIDDlgItem int) HWND {
	ret, _, _ := procGetDlgItem.Call(
		uintptr(unsafe.Pointer(hDlg)),
		uintptr(nIDDlgItem))

	return HWND(ret)
}

func DrawIcon(hDC HDC, x, y int, hIcon HICON) bool {
	ret, _, _ := procDrawIcon.Call(
		uintptr(unsafe.Pointer(hDC)),
		uintptr(x),
		uintptr(y),
		uintptr(unsafe.Pointer(hIcon)))

	return ret != 0
}

func CreateMenu() HMENU {
	ret, _, _ := procCreateMenu.Call(0,
		0,
		0,
		0)

	return HMENU(ret)
}

func SetMenu(hWnd HWND, hMenu HMENU) bool {

	ret, _, _ := procSetMenu.Call(hWnd, hMenu)
	return ret != 0
}

func AppendMenu(hMenu HMENU, uFlags uint32, uIDNewItem uintptr, lpNewItem *uint16) bool {
	ret, _, _ := procAppendMenu.Call(
		hMenu,
		uintptr(uFlags),
		uIDNewItem,
		uintptr(unsafe.Pointer(lpNewItem)))

	return ret != 0
}

// https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-checkmenuradioitem
func SelectRadioMenuItem(menuID uint16, startID uint16, endID uint16, hwnd HWND) bool {
	ret, _, _ := procCheckMenuRadioItem.Call(
		hwnd,
		uintptr(startID),
		uintptr(endID),
		uintptr(menuID),
		MF_BYCOMMAND)
	return ret != 0

}

func CreatePopupMenu() PopupMenu {
	ret, _, _ := procCreatePopupMenu.Call(0,
		0,
		0,
		0)

	return PopupMenu(ret)
}

func TrackPopupMenuEx(hMenu HMENU, fuFlags uint32, x, y int32, hWnd HWND, lptpm *TPMPARAMS) bool {

	ret, _, _ := procTrackPopupMenuEx.Call(
		hMenu,
		uintptr(fuFlags),
		uintptr(x),
		uintptr(y),
		hWnd,
		uintptr(unsafe.Pointer(lptpm)))

	return ret != 0
}

func DrawMenuBar(hWnd HWND) bool {
	ret, _, _ := procDrawMenuBar.Call(hWnd, 0, 0)
	return ret != 0
}

func InsertMenuItem(hMenu HMENU, uItem uint32, fByPosition bool, lpmii *MENUITEMINFO) bool {
	ret, _, _ := procInsertMenuItem.Call(
		hMenu,
		uintptr(uItem),
		uintptr(BoolToBOOL(fByPosition)),
		uintptr(unsafe.Pointer(lpmii)),
		0,
		0)

	return ret != 0
}

func SetMenuItemInfo(hMenu HMENU, uItem uint32, fByPosition bool, lpmii *MENUITEMINFO) bool {
	ret, _, _ := procSetMenuItemInfo.Call(
		hMenu,
		uintptr(uItem),
		uintptr(BoolToBOOL(fByPosition)),
		uintptr(unsafe.Pointer(lpmii)),
		0,
		0)

	return ret != 0
}

func ClientToScreen(hwnd HWND, x, y int) (int, int) {
	pt := POINT{X: int32(x), Y: int32(y)}

	procClientToScreen.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&pt)))

	return int(pt.X), int(pt.Y)
}

func IsDialogMessage(hwnd HWND, msg *MSG) bool {
	ret, _, _ := procIsDialogMessage.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(msg)))

	return ret != 0
}

func IsWindow(hwnd HWND) bool {
	ret, _, _ := procIsWindow.Call(
		uintptr(hwnd))

	return ret != 0
}

func EndDialog(hwnd HWND, nResult uintptr) bool {
	ret, _, _ := procEndDialog.Call(
		uintptr(hwnd),
		nResult)

	return ret != 0
}

func PeekMessage(lpMsg *MSG, hwnd HWND, wMsgFilterMin, wMsgFilterMax, wRemoveMsg uint32) bool {
	ret, _, _ := procPeekMessage.Call(
		uintptr(unsafe.Pointer(lpMsg)),
		uintptr(hwnd),
		uintptr(wMsgFilterMin),
		uintptr(wMsgFilterMax),
		uintptr(wRemoveMsg))

	return ret != 0
}

func TranslateAccelerator(hwnd HWND, hAccTable HACCEL, lpMsg *MSG) bool {
	ret, _, _ := procTranslateMessage.Call(
		uintptr(hwnd),
		uintptr(hAccTable),
		uintptr(unsafe.Pointer(lpMsg)))

	return ret != 0
}

func SetWindowPos(hwnd, hWndInsertAfter HWND, x, y, cx, cy int, uFlags uint) bool {
	ret, _, _ := procSetWindowPos.Call(
		uintptr(hwnd),
		uintptr(hWndInsertAfter),
		uintptr(x),
		uintptr(y),
		uintptr(cx),
		uintptr(cy),
		uintptr(uFlags))

	return ret != 0
}

func FillRect(hDC HDC, lprc *RECT, hbr HBRUSH) bool {
	ret, _, _ := procFillRect.Call(
		uintptr(hDC),
		uintptr(unsafe.Pointer(lprc)),
		uintptr(hbr))

	return ret != 0
}

func DrawText(hDC HDC, text []uint16, uCount int, lpRect *RECT, uFormat uint32) int {

	// Convert the string to a UTF16 pointer
	// This is necessary because the DrawText function expects a UTF16 pointer

	ret, _, _ := procDrawText.Call(
		uintptr(hDC),
		uintptr(unsafe.Pointer(&text[0])),
		uintptr(uCount),
		uintptr(unsafe.Pointer(lpRect)),
		uintptr(uFormat))

	return int(ret)
}

func AddClipboardFormatListener(hwnd HWND) bool {
	ret, _, _ := procAddClipboardFormatListener.Call(
		uintptr(hwnd))
	return ret != 0
}

func RemoveClipboardFormatListener(hwnd HWND) bool {
	ret, _, _ := procRemoveClipboardFormatListener.Call(
		uintptr(hwnd))
	return ret != 0
}

func OpenClipboard(hWndNewOwner HWND) bool {
	ret, _, _ := procOpenClipboard.Call(
		uintptr(hWndNewOwner))
	return ret != 0
}

func CloseClipboard() bool {
	ret, _, _ := procCloseClipboard.Call()
	return ret != 0
}

func EnumClipboardFormats(format uint) uint {
	ret, _, _ := procEnumClipboardFormats.Call(
		uintptr(format))
	return uint(ret)
}

func GetClipboardData(uFormat uint) HANDLE {
	ret, _, _ := procGetClipboardData.Call(
		uintptr(uFormat))
	return HANDLE(ret)
}

func SetClipboardData(uFormat uint, hMem HANDLE) HANDLE {
	ret, _, _ := procSetClipboardData.Call(
		uintptr(uFormat),
		uintptr(hMem))
	return HANDLE(ret)
}

func EmptyClipboard() bool {
	ret, _, _ := procEmptyClipboard.Call()
	return ret != 0
}

func GetClipboardFormatName(format uint) (string, bool) {
	cchMaxCount := 255
	buf := make([]uint16, cchMaxCount)
	ret, _, _ := procGetClipboardFormatName.Call(
		uintptr(format),
		uintptr(unsafe.Pointer(&buf[0])),
		uintptr(cchMaxCount))

	if ret > 0 {
		return syscall.UTF16ToString(buf), true
	}

	return "Requested format does not exist or is predefined", false
}

func IsClipboardFormatAvailable(format uint) bool {
	ret, _, _ := procIsClipboardFormatAvailable.Call(uintptr(format))
	return ret != 0
}

func BeginPaint(hwnd HWND, paint *PAINTSTRUCT) HDC {
	ret, _, _ := procBeginPaint.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(paint)))
	return HDC(ret)
}

func EndPaint(hwnd HWND, paint *PAINTSTRUCT) {
	procEndPaint.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(paint)))
}

func GetKeyboardState(keyState []byte) bool {
	if len(keyState) != 256 {
		panic("keyState slice must have a size of 256 bytes")
	}
	ret, _, _ := procGetKeyboardState.Call(uintptr(unsafe.Pointer(&keyState[0])))
	return ret != 0
}

func MapVirtualKeyEx(uCode, uMapType uint, dwhkl HKL) uint {
	ret, _, _ := procMapVirtualKeyEx.Call(
		uintptr(uCode),
		uintptr(uMapType),
		uintptr(dwhkl))
	return uint(ret)
}

func MapVirtualKey(uCode uint, uMapType uint) uint {
	ret, _, _ := procMapVirtualKey.Call(uintptr(uCode), uintptr(uMapType))
	return uint(ret)
}

func GetAsyncKeyState(vKey int) uint16 {
	ret, _, _ := procGetAsyncKeyState.Call(uintptr(vKey))
	return uint16(ret)
}

func ToAscii(uVirtKey, uScanCode uint, lpKeyState *byte, lpChar *uint16, uFlags uint) int {
	ret, _, _ := procToAscii.Call(
		uintptr(uVirtKey),
		uintptr(uScanCode),
		uintptr(unsafe.Pointer(lpKeyState)),
		uintptr(unsafe.Pointer(lpChar)),
		uintptr(uFlags))
	return int(ret)
}

func SwapMouseButton(fSwap bool) bool {
	ret, _, _ := procSwapMouseButton.Call(
		uintptr(BoolToBOOL(fSwap)))
	return ret != 0
}

func GetCursorPos() (x, y int, ok bool) {
	pt := POINT{}
	ret, _, _ := procGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	return int(pt.X), int(pt.Y), ret != 0
}

func SetCursorPos(x, y int) bool {
	ret, _, _ := procSetCursorPos.Call(
		uintptr(x),
		uintptr(y),
	)
	return ret != 0
}

func SetCursor(cursor HCURSOR) HCURSOR {
	ret, _, _ := procSetCursor.Call(
		uintptr(cursor),
	)
	return HCURSOR(ret)
}

func CreateIcon(instance HINSTANCE, nWidth, nHeight int, cPlanes, cBitsPerPixel byte, ANDbits, XORbits *byte) HICON {
	ret, _, _ := procCreateIcon.Call(
		uintptr(instance),
		uintptr(nWidth),
		uintptr(nHeight),
		uintptr(cPlanes),
		uintptr(cBitsPerPixel),
		uintptr(unsafe.Pointer(ANDbits)),
		uintptr(unsafe.Pointer(XORbits)),
	)
	return HICON(ret)
}

func DestroyIcon(icon HICON) bool {
	ret, _, _ := procDestroyIcon.Call(
		uintptr(icon),
	)
	return ret != 0
}

func MonitorFromPoint(x, y int, dwFlags uint32) HMONITOR {
	ret, _, _ := procMonitorFromPoint.Call(
		uintptr(x),
		uintptr(y),
		uintptr(dwFlags),
	)
	return HMONITOR(ret)
}

func MonitorFromRect(rc *RECT, dwFlags uint32) HMONITOR {
	ret, _, _ := procMonitorFromRect.Call(
		uintptr(unsafe.Pointer(rc)),
		uintptr(dwFlags),
	)
	return HMONITOR(ret)
}

func MonitorFromWindow(hwnd HWND, dwFlags uint32) HMONITOR {
	ret, _, _ := procMonitorFromWindow.Call(
		uintptr(hwnd),
		uintptr(dwFlags),
	)
	return HMONITOR(ret)
}

func GetMonitorInfo(hMonitor HMONITOR, lmpi *MONITORINFO) bool {
	ret, _, _ := procGetMonitorInfo.Call(
		uintptr(hMonitor),
		uintptr(unsafe.Pointer(lmpi)),
	)
	return ret != 0
}

func GetMonitorInfoEx(hMonitor HMONITOR, lmpi *MONITORINFOEX) bool {
	ret, _, _ := procGetMonitorInfo.Call(
		uintptr(hMonitor),
		uintptr(unsafe.Pointer(lmpi)),
	)
	return ret != 0
}

func EnumDisplayMonitors(hdc HDC, clip *RECT, fnEnum uintptr, dwData unsafe.Pointer) bool {
	ret, _, _ := procEnumDisplayMonitors.Call(
		hdc,
		uintptr(unsafe.Pointer(clip)),
		fnEnum,
		uintptr(dwData),
	)
	return ret != 0
}

func EnumDisplaySettingsEx(szDeviceName *uint16, iModeNum uint32, devMode *DEVMODE, dwFlags uint32) bool {
	ret, _, _ := procEnumDisplaySettingsEx.Call(
		uintptr(unsafe.Pointer(szDeviceName)),
		uintptr(iModeNum),
		uintptr(unsafe.Pointer(devMode)),
		uintptr(dwFlags),
	)
	return ret != 0
}

func ChangeDisplaySettingsEx(szDeviceName *uint16, devMode *DEVMODE, hwnd HWND, dwFlags uint32, lParam uintptr) int32 {
	ret, _, _ := procChangeDisplaySettingsEx.Call(
		uintptr(unsafe.Pointer(szDeviceName)),
		uintptr(unsafe.Pointer(devMode)),
		uintptr(hwnd),
		uintptr(dwFlags),
		lParam,
	)
	return int32(ret)
}

/*
func SendInput(inputs []INPUT) uint32 {
	var validInputs []C.INPUT

	for _, oneInput := range inputs {
		input := C.INPUT{_type: C.DWORD(oneInput.Type)}

		switch oneInput.Type {
		case INPUT_MOUSE:
			(*MouseInput)(unsafe.Pointer(&input)).mi = oneInput.Mi
		case INPUT_KEYBOARD:
			(*KbdInput)(unsafe.Pointer(&input)).ki = oneInput.Ki
		case INPUT_HARDWARE:
			(*HardwareInput)(unsafe.Pointer(&input)).hi = oneInput.Hi
		default:
			panic("unkown type")
		}

		validInputs = append(validInputs, input)
	}

	ret, _, _ := procSendInput.Call(
		uintptr(len(validInputs)),
		uintptr(unsafe.Pointer(&validInputs[0])),
		uintptr(unsafe.Sizeof(C.INPUT{})),
	)
	return uint32(ret)
}*/

func SetWindowsHookEx(idHook int, lpfn HOOKPROC, hMod HINSTANCE, dwThreadId DWORD) HHOOK {
	ret, _, _ := procSetWindowsHookEx.Call(
		uintptr(idHook),
		uintptr(syscall.NewCallback(lpfn)),
		uintptr(hMod),
		uintptr(dwThreadId),
	)
	return HHOOK(ret)
}

func UnhookWindowsHookEx(hhk HHOOK) bool {
	ret, _, _ := procUnhookWindowsHookEx.Call(
		uintptr(hhk),
	)
	return ret != 0
}

func CallNextHookEx(hhk HHOOK, nCode int, wParam WPARAM, lParam LPARAM) LRESULT {
	ret, _, _ := procCallNextHookEx.Call(
		uintptr(hhk),
		uintptr(nCode),
		uintptr(wParam),
		uintptr(lParam),
	)
	return LRESULT(ret)
}

func GetKeyState(nVirtKey int32) int16 {
	ret, _, _ := procGetKeyState.Call(
		uintptr(nVirtKey),
		0,
		0)

	return int16(ret)
}

func DestroyMenu(hMenu HMENU) bool {
	ret, _, _ := procDestroyMenu.Call(uintptr(hMenu))
	return ret != 0
}

func GetWindowPlacement(hWnd HWND, lpwndpl *WINDOWPLACEMENT) bool {
	ret, _, _ := procGetWindowPlacement.Call(
		uintptr(hWnd),
		uintptr(unsafe.Pointer(lpwndpl)),
		0)

	return ret != 0
}

func SetWindowPlacement(hWnd HWND, lpwndpl *WINDOWPLACEMENT) bool {
	ret, _, _ := procSetWindowPlacement.Call(
		uintptr(hWnd),
		uintptr(unsafe.Pointer(lpwndpl)),
		0)

	return ret != 0
}

func SetScrollInfo(hwnd HWND, fnBar int32, lpsi *SCROLLINFO, fRedraw bool) int32 {
	ret, _, _ := procSetScrollInfo.Call(
		hwnd,
		uintptr(fnBar),
		uintptr(unsafe.Pointer(lpsi)),
		uintptr(BoolToBOOL(fRedraw)),
		0,
		0)

	return int32(ret)
}

func GetScrollInfo(hwnd HWND, fnBar int32, lpsi *SCROLLINFO) bool {
	ret, _, _ := procGetScrollInfo.Call(
		hwnd,
		uintptr(fnBar),
		uintptr(unsafe.Pointer(lpsi)))

	return ret != 0
}

func RedrawWindow(hwnd HWND, lprcUpdate *RECT, hrgnUpdate HRGN, flags uint32) bool {
	ret, _, _ := procRedrawWindow.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(lprcUpdate)),
		uintptr(hrgnUpdate),
		uintptr(flags))
	return ret != 0
}

func FrameRect(hDC HDC, lprc *RECT, hbr HBRUSH) int {
	ret, _, _ := procFrameRect.Call(
		uintptr(hDC),
		uintptr(unsafe.Pointer(lprc)),
		uintptr(hbr))
	return int(ret)
}

func GetMenuBarInfo(hwnd HWND, idObject int32, idItem uint32, pmbi *MENUBARINFO) bool {
	ret, _, _ := procGetMenuBarInfo.Call(
		uintptr(hwnd),
		uintptr(idObject),
		uintptr(idItem),
		uintptr(unsafe.Pointer(pmbi)))
	return ret != 0
}

func MapWindowPoints(hwndFrom, hwndTo HWND, lpPoints *POINT, cPoints uint) int {
	ret, _, _ := procMapWindowPoints.Call(
		uintptr(hwndFrom),
		uintptr(hwndTo),
		uintptr(unsafe.Pointer(lpPoints)),
		uintptr(cPoints))
	return int(ret)
}

func TrackPopupMenu(hmenu HMENU, flags uint32, x, y int32, reserved int32, hwnd HWND, prcRect *RECT) bool {
	ret, _, _ := procTrackPopupMenu.Call(
		uintptr(hmenu),
		uintptr(flags),
		uintptr(x),
		uintptr(y),
		uintptr(reserved),
		uintptr(hwnd),
		uintptr(unsafe.Pointer(prcRect)))
	return ret != 0
}

// KeybdEvent synthesizes a keystroke. The system can use such a synthesized keystroke to generate a WM_KEYUP or WM_KEYDOWN message.
// bVk: Virtual-key code
// bScan: Hardware scan code
// dwFlags: Controls various aspects of function operation (KEYEVENTF_EXTENDEDKEY or KEYEVENTF_KEYUP)
// dwExtraInfo: Additional value associated with the keystroke
func KeybdEvent(bVk byte, bScan byte, dwFlags uint32, dwExtraInfo uintptr) {
	procKeybdEvent.Call(
		uintptr(bVk),
		uintptr(bScan),
		uintptr(dwFlags),
		dwExtraInfo,
	)
}
